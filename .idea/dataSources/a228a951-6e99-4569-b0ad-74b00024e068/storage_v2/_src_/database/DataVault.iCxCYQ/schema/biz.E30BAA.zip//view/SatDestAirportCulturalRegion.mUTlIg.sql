


CREATE VIEW [biz].[SatDestAirportCulturalRegion] AS
SELECT [AirportHashKey]
      ,[LoadDate]
      ,[LoadEndDate]
      ,'SR9376' AS [RecordSource]
      ,[HashDiff]
      ,[DestCityName]
      ,[DestState]
      ,[DestStateName]
      ,[DestCityMarketID]
      ,[DestStateFips]
      ,[DestWac]
	  ,CASE 
		WHEN DestState IN ('CT', 'ME', 'MA', 'NH', 'RI', 'VT') THEN 'New England'
		WHEN DestState IN ('DE', 'MD', 'NJ', 'NY', 'PA', 'DC') THEN 'Mid Atlantic'
		WHEN DestState IN ('AL', 'AR', 'FL', 'GA', 'KY', 'LA') THEN 'The South'
		WHEN DestState IN ('MS', 'NC', 'SC', 'TN', 'VA', 'WV') THEN 'The South'
		WHEN DestState IN ('IL', 'IN', 'IA', 'KS', 'MI', 'MN') THEN 'Midwest'
		WHEN DestState IN ('MO', 'NE', 'ND', 'OH', 'SD', 'WI') THEN 'Midwest'
		WHEN DestState IN ('AZ', 'NM', 'OK', 'TX') THEN 'The Southwest'
		WHEN DestState IN ('AK', 'CO', 'CA', 'HI', 'ID', 'MT') THEN 'The West'
		WHEN DestState IN ('NV', 'OR', 'UT', 'WA', 'WY') THEN 'The West'
		ELSE NULL 
	   END AS CulturalRegion
  FROM 
	[DataVault].[raw].[SatDestAirport] src


go

