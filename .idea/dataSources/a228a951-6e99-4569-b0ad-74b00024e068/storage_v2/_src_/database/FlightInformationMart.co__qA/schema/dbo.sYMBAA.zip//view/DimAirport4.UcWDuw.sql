CREATE VIEW [dbo].[DimAirport4] AS 
SELECT 
	pit.AirportKey
	,pit.AirportCodeHashKey
	,pit.SnapshotDate
	,CASE
		WHEN hub.AirportCode IS NOT NULL AND hub.AirportCode <> '' THEN hub.AirportCode
		ELSE '?'
	 END AS AirportCode	
	,CASE
		WHEN pit.DestAirportHashKey = '00000000000000000000000000000000' THEN sato.[OriginCityName]
		ELSE satd.[DestCityName]
	 END AS CityName
    ,CASE
		WHEN pit.DestAirportHashKey = '00000000000000000000000000000000' THEN sato.[OriginState]
		ELSE satd.[DestState]
	 END AS [State]
    ,CASE
		WHEN pit.DestAirportHashKey = '00000000000000000000000000000000' THEN sato.[OriginStateName]
		ELSE satd.[DestStateName]
	 END AS StateName
    ,CASE
		WHEN pit.DestAirportHashKey = '00000000000000000000000000000000' THEN sato.[OriginCityMarketID]
		ELSE satd.[DestCityMarketID]
	 END AS CityMarketID
    ,CASE 
		WHEN pit.DestAirportHashKey = '00000000000000000000000000000000' THEN sato.[OriginStateFips]
		ELSE satd.[DestStateFips]
	 END AS StateFips
    ,CASE
		WHEN pit.DestAirportHashKey = '00000000000000000000000000000000' THEN sato.[OriginWac]
		ELSE satd.[DestWac]
	 END AS Wac
FROM
	DataVault.[biz].[PITAirportCode] pit
INNER JOIN DataVault.[raw].HubAirportCode hub ON (
	pit.AirportCodeHashKey = hub.AirportCodeHashKey
)
INNER JOIN DataVault.[raw].SatOriginAirportMod sato ON (
	sato.AirportHashKey = pit.OriginAirportHashKey 
	AND sato.LoadDate = pit.OriginLoadDate
)
INNER JOIN DataVault.[raw].SatDestAirportMod satd ON (
	satd.AirportHashKey = pit.DestAirportHashKey 
	AND satd.LoadDate = pit.DestLoadDate
)
WHERE 
	SnapshotDate BETWEEN '1995-01-01' AND '2018-12-31'
go

