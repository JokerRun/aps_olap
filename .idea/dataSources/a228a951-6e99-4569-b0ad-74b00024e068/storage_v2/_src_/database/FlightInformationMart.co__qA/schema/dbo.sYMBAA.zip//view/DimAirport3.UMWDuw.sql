CREATE VIEW [dbo].[DimAirport3] AS 
SELECT 
	pit.AirportKey
	,pit.AirportCodeHashKey
	,pit.SnapshotDate
	,CASE 
		WHEN hub.AirportCode IS NOT NULL AND hub.AirportCode <> '' THEN hub.AirportCode
		ELSE '?'
	 END AS AirportCode	
	,COALESCE(satd.[DestCityName], sato.[OriginCityName], 'Unknown') AS CityName
    ,COALESCE(satd.[DestState], sato.[OriginState], '?') AS [State]
    ,COALESCE(satd.[DestStateName], sato.[OriginStateName], 'Unknown') AS StateName
    ,COALESCE(satd.[DestCityMarketID], sato.[OriginCityMarketID], 0) AS CityMarketID
    ,COALESCE(satd.[DestStateFips], sato.[OriginStateFips], 0) AS StateFips
    ,COALESCE(satd.[DestWac], sato.[OriginWac], 0) AS Wac
FROM
	DataVault.[biz].[PITAirportCode] pit
INNER JOIN DataVault.[raw].HubAirportCode hub ON (
	pit.AirportCodeHashKey = hub.AirportCodeHashKey
)
INNER JOIN DataVault.[raw].SatOriginAirportMod sato ON (
	sato.AirportHashKey = pit.OriginAirportHashKey 
	AND sato.LoadDate = pit.OriginLoadDate
)
INNER JOIN DataVault.[raw].SatDestAirportMod satd ON (
	satd.AirportHashKey = pit.DestAirportHashKey 
	AND satd.LoadDate = pit.DestLoadDate
)
WHERE 
	SnapshotDate BETWEEN '1995-01-01' AND '2018-12-31'
go

