CREATE VIEW DimCarrier2 AS 
SELECT
	hub.CarrierHashKey AS CarrierKey 
	, CASE WHEN hub.Carrier IS NOT NULL AND hub.Carrier <> ''
	    THEN hub.Carrier
		ELSE '?'
	  END AS Carrier
	, CASE WHEN sat.Code IS NOT NULL AND sat.Code <> ''
	    THEN sat.Code
		ELSE '?'
	  END AS Code
	, CASE WHEN sat.Name IS NOT NULL AND sat.Name <> ''
	    THEN sat.Name
	    ELSE 'Unknown'
	  END AS Name
	, COALESCE(sat.[Corporate Name], '') AS [Corporate Name]
	, COALESCE(sat.Abbreviation, '') AS Abbreviation
	, COALESCE(sat.[Unique Abbreviation], '') AS [Unique Abbreviation]
	, COALESCE(sat.[Group_Code], '') AS [Group Code]
	, COALESCE(sat.[Region_Code], '') AS [Region Code]
	, COALESCE(sat.[Satisfaction Rank], 9999) AS [Satisfaction Rank]
	, COALESCE(sat.[Sort Order], 9999) AS [Sort Order]
	, COALESCE(sat.[External Reference], '') AS [External Reference]
	, COALESCE(sat.Comments, '') AS Comments
FROM
	DataVault.[raw].HubCarrier hub
LEFT JOIN 
	DataVault.[raw].SatCarrier sat ON (
		sat.CarrierHashKey = hub.CarrierHashKey
	)
WHERE
	sat.LoadEndDate IS NULL
UNION ALL
SELECT 
	REPLICATE('0', 32)	
	, '?'
	, '?'
	, 'Unknown'
	, 'Unknown'
	, '?'
	, '?'
	, '?'
	, '?'
	, 9999
	, 0
	, ''
	, ''

go

