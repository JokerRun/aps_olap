

CREATE VIEW [dbo].[DimAirportCalif] AS 
SELECT 
	pit.AirportKey
	,pit.AirportCodeHashKey
	,pit.SnapshotDate
	,CASE
		WHEN hub.AirportCode IS NOT NULL AND hub.AirportCode <> '' THEN hub.AirportCode
		ELSE '?'
	 END AS AirportCode	
	,satd.[DestCityName]
    ,satd.[DestState]
    ,satd.[DestStateName]
    ,satd.[DestCityMarketID]
    ,satd.[DestStateFips]
    ,satd.[DestWac] 
FROM
	DataVault.[biz].[PITAirportCode] pit
INNER JOIN DataVault.[raw].HubAirportCode hub ON (
	pit.AirportCodeHashKey = hub.AirportCodeHashKey
)
INNER JOIN DataVault.[raw].SatDestAirportMod satd ON (
	satd.AirportHashKey = pit.DestAirportHashKey 
	AND satd.LoadDate = pit.DestLoadDate
)
WHERE 
	SnapshotDate BETWEEN '1995-01-01' AND '2018-12-31'
	AND satd.DestState = 'CA'

go

