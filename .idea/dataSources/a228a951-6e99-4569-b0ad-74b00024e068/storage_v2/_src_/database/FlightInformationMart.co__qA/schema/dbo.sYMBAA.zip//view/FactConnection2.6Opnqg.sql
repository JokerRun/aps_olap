
CREATE VIEW dbo.FactConnection2 AS
SELECT 
      link.CarrierHashKey AS CarrierKey
      ,UPPER(CONVERT(char(32), HASHBYTES('MD5', CONCAT(UPPER(RTRIM(LTRIM(hubOrigin.AirportCode))), ';', CONVERT(NVARCHAR(30), SatOrigin.LoadDate, 126))),2)) AS OriginKey
	  ,UPPER(CONVERT(char(32), HASHBYTES('MD5', CONCAT(UPPER(RTRIM(LTRIM(hubDest.AirportCode))), ';', CONVERT(NVARCHAR(30), SatDest.LoadDate, 126))),2)) AS DestKey
	  ,DATEPART(YEAR, link.FlightDate)*10000+DATEPART(MONTH, link.FlightDate)*100+DATEPART(DAY, link.FlightDate) AS FlightDateKey
      ,link.[FlightDate]
	  ,sat.[Year]
      ,sat.[Quarter]
      ,sat.[Month]
      ,sat.[DayOfMonth]
      ,sat.[DayOfWeek]
      ,SUM(sat.[DepDelay]) AS SumDepDelay
      ,SUM(sat.[DepDelayMinutes]) AS SumDepDelayMinutes
      ,SUM(sat.[TaxiOut]) AS SumTaxiOut
      ,SUM(sat.[WheelsOff]) AS SumWheelsOff
      ,SUM(sat.[WheelsOn]) AS SumWheelsOn
      ,SUM(sat.[TaxiIn]) AS SumTaxiIn
      ,SUM(sat.[ArrDelay]) AS SumArrDelay
      ,SUM(sat.[ArrDelayMinutes]) AS SumArrDelayMinutes
      ,SUM(CASE WHEN sat.Cancelled=1 THEN 1 ELSE 0 END) AS SumCancelled 
      ,SUM(CASE WHEN sat.Diverted=1 THEN 1 ELSE 0 END) AS SumDiverted
      ,SUM(sat.[AirTime]) AS SumAirTime
      ,SUM(sat.[Flights]) AS SumFlights
      ,SUM(sat.[Distance]) AS SumDistance      
      ,SUM(sat.[CarrierDelay]) AS SumCArrierDelay
      ,SUM(sat.[WeatherDelay]) AS SumWeatherDelay
      ,SUM(sat.[NASDelay]) AS SumNASDelay
      ,SUM(sat.[SecurityDelay]) AS SumSecurityDelay
      ,SUM(sat.[LateAircraftDelay]) AS SumLateAircraftDelay      
  FROM [DataVault].[raw].[TLinkFlight] link
  INNER JOIN [DataVault].[raw].[HubAirportCode] HubOrigin ON (
		HubOrigin.AirportCodeHashKey = link.OriginHashKey
  )
  INNER JOIN [DataVault].[raw].[SatOriginAirportMod2] SatOrigin ON (
		SatOrigin.AirportHashKey = link.OriginHashKey
		AND link.LoadDate BETWEEN SatOrigin.LoadDate AND COALESCE(SatOrigin.LoadEndDate, '9999-12-31 23:59:59.999')
  )
  INNER JOIN [DataVault].[raw].[HubAirportCode] HubDest ON (
		HubDest.AirportCodeHashKey = link.DestHashKey
  )
  INNER JOIN [DataVault].[raw].[SatDestAirportMod2] SatDest ON (
		SatDest.AirportHashKey = link.DestHashKey
		AND link.LoadDate BETWEEN SatDest.LoadDate AND COALESCE(SatDest.LoadEndDate, '9999-12-31 23:59:59.999')
  )
  INNER JOIN DataVault.[raw].TSatFlight sat ON (
	sat.FlightHashKey = link.FlightHashKey
  )
  GROUP BY 
	link.FlightDate, sat.[Year], sat.[Quarter], sat.[Month], sat.[DayOfMonth], sat.[DayOfWeek]
	,link.CarrierHashKey, hubOrigin.AirportCode, SatOrigin.LoadDate, hubDest.AirportCode, SatDest.LoadDate
go

