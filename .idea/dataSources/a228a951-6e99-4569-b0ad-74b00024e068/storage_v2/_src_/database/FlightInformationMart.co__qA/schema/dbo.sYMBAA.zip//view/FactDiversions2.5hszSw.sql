CREATE VIEW FactDiversions2 AS
SELECT 
      lflight.FlightDate
	  ,DATEPART(YEAR, lflight.FlightDate)*10000+DATEPART(MONTH, lflight.FlightDate)*100+DATEPART(DAY, lflight.FlightDate) AS FlightDateKey
      ,c.Carrier
      ,CONCAT(fn.Carrier, fn.FlightNum) AS FlightNum
      ,tn.TailNum
      ,oa.AirportCode
	  ,soa.OriginCityName
	  ,soa.OriginState
	  ,soa.OriginStateName
      ,pitDest.AirportKey AS DestAirportKey
      ,dtn.TailNum AS DivTailNum
      ,pitDivAirport.AirportKey AS DivAirportKey
      ,br.Diversion
      ,sat.[CRSDepTime]
      ,sat.[DepTime]
      ,sat.[DepDelay]
      ,sat.[DepDelayMinutes]
      ,sat.[DepDel15]
      ,sat.[DepartureDelayGroups]
      ,sat.[DepTimeBlk]
      ,sat.[TaxiOut]
      ,sat.[WheelsOff]
      ,sat.[WheelsOn]
      ,sat.[TaxiIn]
      ,sat.[CRSArrTime]
      ,sat.[ArrTime]
      ,sat.[ArrDelay]
      ,sat.[ArrDelayMinutes]
      ,sat.[ArrDel15]
      ,sat.[ArrivalDelayGroups]
      ,sat.[ArrTimeBlk]
      ,sat.[Cancelled]
      ,sat.[CancellationCode]
      ,sat.[Diverted]
      ,sat.[CRSElapsedTime]
      ,sat.[ActualElapsedTime]
      ,sat.[AirTime]
      ,sat.[Flights]
      ,sat.[Distance]
      ,sat.[DistanceGroup]
      ,sat.[CarrierDelay]
      ,sat.[WeatherDelay]
      ,sat.[NASDelay]
      ,sat.[SecurityDelay]
      ,sat.[LateAircraftDelay]
      ,sat.[FirstDepTime]
      ,sat.[TotalAddGTime]
      ,sat.[LongestAddGTime]

  FROM 
	  [DataVault].[biz].[BrDiversionFlight] br
  INNER JOIN [DataVault].[raw].[TLinkFlight] lflight ON (
	  lflight.FlightHashKey = br.FlightHashKey
  )
  INNER JOIN DataVault.[raw].TSatFlight sat ON (
		sat.FlightHashKey = br.FlightHashKey
  )
  INNER JOIN [DataVault].[raw].[HubCarrier] c ON (
      c.CarrierHashKey = br.CarrierHashKey
  )
  INNER JOIN [DataVault].[raw].[HubFlightNum] fn ON (
      fn.FlightNumHashKey = br.FlightNumHashKey
  )
  INNER JOIN [DataVault].[raw].[HubTailNum] tn ON (
      tn.TailNumHashKey = br.TailNumHashKey
  )
  INNER JOIN [DataVault].[biz].[PITAirportCode] pitOrigin ON (
      pitOrigin.AirportCodeHashKey = br.OriginHashKey 
	  AND pitOrigin.SnapshotDate = br.SnapshotDate
  )
  INNER JOIN [DataVault].[raw].[HubAirportCode] oa ON (
	  oa.AirportCodeHashKey = br.OriginHashKey
  )
  INNER JOIN [DataVault].[raw].[SatOriginAirportMod] soa ON (
	  soa.AirportHashKey = pitOrigin.OriginAirportHashKey
	  AND soa.LoadDate = pitOrigin.OriginLoadDate
  )
  INNER JOIN [DataVault].[biz].[PITAirportCode] pitDest ON (
      pitDest.AirportCodeHashKey = br.DestHashKey
	  AND pitDest.SnapshotDate = br.SnapshotDate
  )
  INNER JOIN [DataVault].[raw].[HubTailNum] dtn ON (
      dtn.TailNumHashKey = br.DivTailNumHashKey
  )
  INNER JOIN [DataVault].[biz].[PITAirportCode] pitDivAirport ON (
      pitDivAirport.AirportCodeHashKey = br.DivAirportHashKey
	  AND pitDivAirport.SnapshotDate = br.SnapshotDate
  )
go

