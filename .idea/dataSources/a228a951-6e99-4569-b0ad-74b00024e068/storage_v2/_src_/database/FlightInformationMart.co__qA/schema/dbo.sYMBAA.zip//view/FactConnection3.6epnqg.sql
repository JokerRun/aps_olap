CREATE VIEW FactConnection3 AS
SELECT 
	  c.Carrier
      ,pitOrigin.AirportKey AS OriginAirportKey
      ,pitDest.AirportKey AS DestAirportKey
	  ,DATEPART(YEAR, br.FlightDate)*10000+DATEPART(MONTH, br.FlightDate)*100+DATEPART(DAY, br.FlightDate) AS FlightDateKey
      ,br.[FlightDate]
      ,br.[Year]
      ,br.[Quarter]
      ,br.[Month]
      ,br.[DayOfMonth]
      ,br.[DayOfWeek]
      ,br.[SumDepDelay]
      ,br.[SumDepDelayMinutes]
      ,br.[SumTaxiOut]
      ,br.[SumWheelsOff]
      ,br.[SumWheelsOn]
      ,br.[SumTaxiIn]
      ,br.[SumArrDelay]
      ,br.[SumArrDelayMinutes]
      ,br.[SumCancelled]
      ,br.[SumDiverted]
      ,br.[SumAirTime]
      ,br.[SumFlights]
      ,br.[SumDistance]
      ,br.[SumCArrierDelay]
      ,br.[SumWeatherDelay]
      ,br.[SumNASDelay]
      ,br.[SumSecurityDelay]
      ,br.[SumLateAircraftDelay]
  FROM
	  [DataVault].[biz].[BrConnection] br
  INNER JOIN [DataVault].[raw].[HubCarrier] c ON (
      c.CarrierHashKey = br.CarrierHashKey
  )
  INNER JOIN [DataVault].[biz].[PITAirportCode] pitOrigin ON (
      pitOrigin.AirportCodeHashKey = br.OriginHashKey 
	  AND pitOrigin.SnapshotDate = br.SnapshotDate
  )
  INNER JOIN [DataVault].[biz].[PITAirportCode] pitDest ON (
      pitDest.AirportCodeHashKey = br.DestHashKey
	  AND pitDest.SnapshotDate = br.SnapshotDate
  )
go

