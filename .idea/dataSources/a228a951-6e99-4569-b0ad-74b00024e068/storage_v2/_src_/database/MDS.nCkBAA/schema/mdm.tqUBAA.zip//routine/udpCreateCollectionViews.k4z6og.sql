/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    EXEC mdm.udpCreateCollectionViews 1,1,1, 'test';  
    EXEC mdm.udpCreateCollectionViews 5111; --invalid  
  
*/  
CREATE PROCEDURE mdm.udpCreateCollectionViews   
(  
    @Entity_ID			 INT,  
    @Version_ID          INT ,  
    @VersionFlag_ID      INT,  
    @SubscriptionViewName sysname,  
    @IncludeSoftDeletedMembers BIT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    --Defer view generation if we are in the middle of an upgrade or demo-rebuild  
    IF APPLOCK_MODE(N'public', N'DeferViewGeneration', N'Session') = N'NoLock' BEGIN  
  
        DECLARE @EntityTable  			sysname,  
                @HierarchyParentTable  	sysname,  
                @IsHierarchyEnabled      BIT,  
                @CollectionTable 		sysname,  
                @CollectionMemberTable	sysname,  
                @SQL					NVARCHAR(MAX),  
                @ViewName				sysname;  
  
        --Initialize the variables  
        SELECT  
            @EntityTable = EntityTable,  
            @HierarchyParentTable = HierarchyParentTable,  
            @IsHierarchyEnabled = CASE WHEN HierarchyParentTable IS NULL THEN 0 ELSE 1 END,  
            @CollectionTable = CollectionTable,  
            @CollectionMemberTable = CollectionMemberTable,  
            @ViewName = @SubscriptionViewName  
        FROM mdm.tblEntity  
        WHERE   ID = @Entity_ID  
            AND CollectionTable IS NOT NULL -- Only get entities that support collections  
  
        --Test for invalid parameters  
        IF @ViewName IS NULL -- Could mean that @Entity_ID and/or @SubscriptionViewName was invalid   
            OR (@Version_ID IS NOT NULL AND NOT EXISTS(SELECT ID FROM mdm.tblModelVersion WHERE ID = @Version_ID)) -- Invalid @Version_ID  
        BEGIN  
            RAISERROR('MDSERR100010|The Parameters are not valid.', 16, 1);  
            RETURN;  
        END; --if  
          
        SET @SQL = N'  
            /*WITH ENCRYPTION*/  
            AS SELECT  
                V.Name          AS VersionName,  
                V.Display_ID    AS VersionNumber,  
                DV.Name         AS VersionFlag,  
                CN.Code         AS Code,  
                CN.Name         AS Name,  
                CASE CM.ChildType_ID  
                    WHEN 1 THEN E.Code' +  
            CASE @IsHierarchyEnabled WHEN 1 THEN N'  
                    WHEN 2 THEN HP.Code' ELSE N'' END + N'  
                    WHEN 3 THEN CN2.Code  
                END             AS MemberCode,   
                CASE CM.ChildType_ID  
                    WHEN 1 THEN E.Name ' +  
            CASE @IsHierarchyEnabled WHEN 1 THEN N'  
                    WHEN 2 THEN HP.Name' ELSE N'' END + N'  
                    WHEN 3 THEN CN2.Name   
                END             AS MemberName,  
                CONVERT(DECIMAL(18,2), CM.Weight) AS Weight,  
                CM.SortOrder    AS SortOrder,  
                CN.EnterDTM     AS EnterDateTime  
                ,UE.UserName    AS EnterUserName  
                ,VE.Display_ID  AS EnterVersionNumber  
                ,CN.LastChgDTM AS LastChgDateTime  
                ,UC.UserName AS LastChgUserName  
                ,VC.Display_ID  AS LastChgVersionNumber' +  
                CASE WHEN @IncludeSoftDeletedMembers = 1 THEN N'  
                ,L.ListOption AS State' ELSE N'' END + N'  
            FROM   
                mdm.' + quotename(@CollectionTable) + N' AS CN  
            INNER JOIN mdm.' + quotename(@CollectionMemberTable) + N' AS CM   
                ON CN.ID = CM.Parent_CN_ID  
                AND CN.Version_ID = CM.Version_ID   
                AND CN.Status_ID = CM.Status_ID   
            INNER JOIN mdm.tblModelVersion V ON CN.Version_ID = V.ID '  
        --Restrict by Version or Version Flag  
        IF (@Version_ID IS NOT NULL)  
        BEGIN   
            SET @SQL = @SQL + N'   
                AND V.ID = ' + CAST(@Version_ID AS NVARCHAR(50))   
        END  
        ELSE IF (@VersionFlag_ID IS NOT NULL) BEGIN  
            SET @SQL = @SQL + N'   
                AND V.VersionFlag_ID = ' + CAST(@VersionFlag_ID AS NVARCHAR(50))   
        END  
  
        SET @SQL = @SQL + N'   
            LEFT JOIN mdm.tblUser UE ON CN.EnterUserID = UE.ID  
            LEFT JOIN mdm.tblUser UC ON CN.LastChgUserID = UC.ID   
            LEFT JOIN mdm.tblModelVersion VE ON CN.EnterVersionID = VE.ID  
            LEFT JOIN mdm.tblModelVersion VC ON CN.LastChgVersionID = VC.ID  
            LEFT JOIN mdm.tblModelVersionFlag AS DV ON DV.ID = V.VersionFlag_ID';  
  
        IF @IncludeSoftDeletedMembers = 0  
        BEGIN  
            SET @SQL += N'  
            LEFT JOIN mdm.' + quotename(@EntityTable) + N' AS E   
                ON CM.Child_EN_ID = E.ID   
                AND CM.Version_ID = E.Version_ID   
                AND E.Version_ID = CN.Version_ID  
                AND CM.Parent_CN_ID = CN.ID  
                AND CM.ChildType_ID = 1   
                AND E.Status_ID = 1' +  
                CASE @IsHierarchyEnabled WHEN 1 THEN N'    
            LEFT JOIN mdm.' + quotename(@HierarchyParentTable) + N' AS HP   
                ON CM.Child_HP_ID = HP.ID   
                AND CM.Version_ID = HP.Version_ID   
                AND HP.Version_ID = CN.Version_ID  
                AND CM.Parent_CN_ID = CN.ID   
                AND CM.ChildType_ID = 2   
                AND HP.Status_ID = 1' ELSE N'' END + N'  
            LEFT JOIN mdm.' + quotename(@CollectionTable) + N' AS CN2   
                ON CM.Child_CN_ID = CN2.ID    
                AND CM.Version_ID = CN2.Version_ID   
                AND CN2.Version_ID = CN.Version_ID   
                AND CM.Parent_CN_ID = CN.ID   
                AND CM.ChildType_ID = 3   
                AND CN2.Status_ID = 1  
            WHERE   
                CN.Status_ID = 1   
                AND (   E.ID IS NOT NULL' +   
                CASE @IsHierarchyEnabled WHEN 1 THEN N'   
                        OR HP.ID IS NOT NULL ' ELSE N'' END + N'   
                        OR CN2.ID IS NOT NULL);';  
        END  
        ELSE -- no Status_ID = 1 filtering  
        BEGIN  
            SET @SQL += N'  
            LEFT JOIN mdm.tblList L ON L.OptionID = CN.Status_ID AND L.ListCode = ''lstStatus''      
            LEFT JOIN mdm.' + quotename(@EntityTable) + N' AS E   
                ON CM.Child_EN_ID = E.ID   
                AND CM.Version_ID = E.Version_ID   
                AND E.Version_ID = CN.Version_ID  
                AND CM.Parent_CN_ID = CN.ID  
                AND CM.ChildType_ID = 1' +  
                CASE @IsHierarchyEnabled WHEN 1 THEN N'    
            LEFT JOIN mdm.' + quotename(@HierarchyParentTable) + N' AS HP   
                ON CM.Child_HP_ID = HP.ID   
                AND CM.Version_ID = HP.Version_ID   
                AND HP.Version_ID = CN.Version_ID  
                AND CM.Parent_CN_ID = CN.ID   
                AND CM.ChildType_ID = 2' ELSE N'' END + N'  
            LEFT JOIN mdm.' + quotename(@CollectionTable) + N' AS CN2   
                ON CM.Child_CN_ID = CN2.ID    
                AND CM.Version_ID = CN2.Version_ID   
                AND CN2.Version_ID = CN.Version_ID   
                AND CM.Parent_CN_ID = CN.ID   
                AND CM.ChildType_ID = 3   
            WHERE   
                    E.ID IS NOT NULL ' +   
                CASE @IsHierarchyEnabled WHEN 1 THEN N'   
                        OR HP.ID IS NOT NULL ' ELSE N'' END + N'   
                        OR CN2.ID IS NOT NULL;';  
        END;  
  
        SET @SQL = CASE   
            WHEN EXISTS(SELECT 1 FROM sys.views WHERE [name] = @ViewName AND [schema_id] = SCHEMA_ID('mdm')) THEN N'ALTER'  
            ELSE N'CREATE' END + N' VIEW mdm.' + quotename(@ViewName)  
            + @SQL;  
  
        --PRINT(@SQL);  
        EXEC sp_executesql @SQL;  
  
    END; --if  
  
    SET NOCOUNT OFF;  
END; --proc
go

