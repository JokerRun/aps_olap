/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    --Run this the first time to kick off the timer  
    DECLARE @handle UNIQUEIDENTIFIER;  
    BEGIN DIALOG CONVERSATION @handle  
        FROM SERVICE [microsoft/mdm/service/notification]  
        TO SERVICE N'microsoft/mdm/service/system'  
        WITH ENCRYPTION = OFF;  
    BEGIN CONVERSATION TIMER (@handle) TIMEOUT = 1;  
  
    ALTER QUEUE mdm.[microsoft/mdm/queue/notification]  
    WITH ACTIVATION  
    (  
        STATUS = ON,  
        PROCEDURE_NAME = [mdm].[udpNotificationQueueActivate],  
        MAX_QUEUE_READERS = 1,  
        --In the original queue declaration we used the standard mds_ssb_user context  
        --since the appropriate login/user we needed did not exist yet.  
        --So here we execute using the context we actually require.  
        EXECUTE AS N'mds_email_user'  
    );  
*/  
CREATE PROCEDURE mdm.udpNotificationQueueActivate  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE  
         @message_type_name         SYSNAME  
        ,@handle                    UNIQUEIDENTIFIER = NULL  
        ,@interval                  INT  
        ,@need_new                  BIT = NULL  
        ,@status                    NVARCHAR(1000)  
        ,@dialog                    UNIQUEIDENTIFIER;  
  
    --Load interval setting from config, and check the defaults and ranges  
    SET @interval = COALESCE(CONVERT(INT, mdm.udfSystemSettingGet(N'NotificationInterval')), 120);  
    SET @interval =  
    CASE  
        WHEN @interval < 10 THEN 10 --Prevent negative and 'real-time' settings  
        WHEN @interval > 86400  THEN 86400 --Check at least once per day (60 x 60 x 24)  
        ELSE @interval  
    END  
  
    BEGIN TRANSACTION  
  
    WAITFOR (  
        RECEIVE TOP(1)  
            @handle = [conversation_handle],  
            @message_type_name = message_type_name  
        FROM mdm.[microsoft/mdm/queue/notification]  
    ), TIMEOUT 5000; --Always wait a constant time for any new messages  
  
    --Got a TIMER message  
    IF (@message_type_name = CAST(N'http://schemas.microsoft.com/SQL/ServiceBroker/DialogTimer' AS SYSNAME))  
    BEGIN  
  
        --Start a new TIMER and COMMIT the transaction before we do the real work, to avoid poisoning  
        BEGIN CONVERSATION TIMER (@handle) TIMEOUT = @interval;  
        COMMIT TRANSACTION;  
  
        EXEC mdm.udpNotificationQueueProcess  
  
    --Got an END DIALOG message  
    END  
    ELSE IF (@message_type_name = CAST(N'http://schemas.microsoft.com/SQL/ServiceBroker/EndDialog' AS NVARCHAR(128)))  
    BEGIN  
        PRINT N'Error in udpNotificationQueueActivate end dialog';  
        SET @need_new = 1;  
  
    --Got ERROR message  
    END  
    ELSE IF (@message_type_name = CAST(N'http://schemas.microsoft.com/SQL/ServiceBroker/Error' AS NVARCHAR(128)))  
    BEGIN  
        PRINT N'Error in udpNotificationQueueActivate error';  
        SET @need_new = 1;  
  
    --Timeout or unexpected message  
    END  
    ELSE  
    BEGIN  
  
        COMMIT TRANSACTION;  
  
    END; --if  
  
    IF (@need_new = 1)  
    BEGIN  
  
        END CONVERSATION @handle;  
  
        --DECLARE @handle UNIQUEIDENTIFIER; DECLARE @interval INT; SET @interval = 10;  
        BEGIN DIALOG CONVERSATION @handle  
            FROM SERVICE [microsoft/mdm/service/notification]  
            TO SERVICE N'microsoft/mdm/service/system'  
            WITH ENCRYPTION = OFF;  
        BEGIN CONVERSATION TIMER (@handle) TIMEOUT = @interval;  
  
        COMMIT TRANSACTION;  
  
    END; --if  
  
    SET NOCOUNT OFF;  
END; --proc
go

