/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Rank    Permission  
----    ---------------------  
1       Model Admin - ALL  
2       MemberType Deny - Deny  
3       No explicit permission, MemberType not inferred permission - MemberType permission  
4       No explicit permission on name/code, MemberType inferred permission - ReadOnly, some attribute has some permission, membertype is inferred read.  
5       Attribute permission, could be explicit attribute permission or null.  
  
SELECT * FROM mdm.viw_SYSTEM_SECURITY_USER_ATTRIBUTE WHERE User_ID = 118  
*/  
CREATE VIEW mdm.viw_SYSTEM_SECURITY_USER_ATTRIBUTE  
/*WITH SCHEMABINDING*/  
AS  
WITH allPermissions AS (  
    SELECT  
        User_ID,  
        MAX(IsAdmin) IsAdmin,  
        ID,  
        MIN(Privilege_ID) Privilege_ID,  
        SUM(Distinct(AccessPermission & 0x1)) +  
        SUM(Distinct(AccessPermission & 0x2)) +  
        SUM(Distinct(AccessPermission & 0x4)) AS AccessPermission  
    FROM  
        (  
        SELECT  
            tTypSec.User_ID,  
            tTypSec.IsAdmin,  
            tAtt.ID,  
            Privilege_ID =  
                CASE  
                    WHEN tTypSec.IsAdmin = 1 THEN 4 /*Access*/  
                    WHEN tTypSec.Privilege_ID = 1 /*Deny*/ THEN 1 /*Deny*/  
                    -- No explicit permission on attribute and non-inferred permission on memberType, use memberType permission  
                    WHEN ISNULL(tHasExplicit.HasExplicit, 0) != 1 AND tTypSec.Privilege_ID <> 99  
                        THEN tTypSec.Privilege_ID  
                    -- No explicit permission on Name/Code and inferred permission on memberType, then give ReadOnly permission to Name/Code.  
                    WHEN ISNULL(tHasExplicit.HasExplicit, 0) != 1 AND tTypSec.Privilege_ID = 99 AND (tAtt.IsCode = 1 OR tAtt.IsName = 1)  
                        THEN 4 /*Access*/  
                    ELSE tExp.Attribute_PrivilegeID  
                END,  
            AccessPermission =  
                CASE  
                    WHEN tTypSec.IsSyncTarget = 1 THEN 0 -- An entity that is the target of a sync relationship is read-only  
                    WHEN tTypSec.IsAdmin = 1 THEN 7 /*All*/  
                    WHEN tTypSec.Privilege_ID = 1  /*Deny*/ THEN 0 /*None*/  
                    WHEN ISNULL(tHasExplicit.HasExplicit, 0) != 1 AND tTypSec.Privilege_ID <> 99  
                        THEN tTypSec.AccessPermission  
                    WHEN ISNULL(tHasExplicit.HasExplicit, 0) != 1 AND tTypSec.Privilege_ID = 99 AND (tAtt.IsCode = 1 OR tAtt.IsName = 1)  
                        THEN 0 /*Read*/  
                    ELSE tExp.Attribute_AccessPermission  
                END  
            FROM mdm.tblAttribute tAtt  
            -- Check entity security  
            INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_MEMBERTYPE tTypSec  
            ON      tAtt.Entity_ID = tTypSec.Entity_ID  
                AND tAtt.MemberType_ID = tTypSec.ID  
                AND (tAtt.AttributeType_ID <> 3) -- Exclude system attribute  
  
            LEFT JOIN mdm.viw_SYSTEM_SECURITY_USER tExp  
             ON     tAtt.ID = tExp.Attribute_ID  
                AND tTypSec.User_ID = tExp.User_ID  
  
             -- Check if attribute has explicit permission  
            LEFT JOIN (  
                SELECT Attribute_ID, Role_ID, User_ID, MAX(Attribute_IsExplicit) as HasExplicit  
                FROM mdm.viw_SYSTEM_SECURITY_USER  
                GROUP BY Attribute_ID, Role_ID, User_ID  
            ) AS tHasExplicit  
            ON tAtt.ID = tHasExplicit.Attribute_ID AND tExp.User_ID = tHasExplicit.User_ID AND tExp.Role_ID = tHasExplicit.Role_ID  
        ) tSec  
    WHERE  
        Privilege_ID IS NOT NULL  
    GROUP BY  
        User_ID,  
        ID  
)  
SELECT  
    [User_ID],  
    IsAdmin,  
    ID,  
    Privilege_ID,  
    CASE Privilege_ID WHEN 4 /*Access*/ THEN AccessPermission ELSE NULL END AccessPermission  
FROM allPermissions  
WHERE Privilege_ID > 1 /*Deny*/
go

