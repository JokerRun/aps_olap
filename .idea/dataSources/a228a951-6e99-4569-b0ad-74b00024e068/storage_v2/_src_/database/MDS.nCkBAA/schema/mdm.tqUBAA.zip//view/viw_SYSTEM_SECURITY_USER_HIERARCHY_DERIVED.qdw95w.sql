/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    SELECT * FROM mdm.viw_SYSTEM_SECURITY_USER_HIERARCHY_DERIVED ORDER BY User_ID  
*/  
CREATE VIEW mdm.viw_SYSTEM_SECURITY_USER_HIERARCHY_DERIVED  
/*WITH SCHEMABINDING*/  
AS  
WITH allPermissions AS (  
    SELECT  
        User_ID,  
        ID,  
        MIN(Privilege_ID) Privilege_ID,  
        Avg(AccessPermission & 0x1) / 0x1 * 0x1 +  
        Avg(AccessPermission & 0x2) / 0x2 * 0x2 +  
        Avg(AccessPermission & 0x4) / 0x4 * 0x4 AS AccessPermission  
    FROM  
        (  
        SELECT  
            usr.User_ID,  
            dh.ID,  
            Privilege_ID =  
                CASE  
                    WHEN dhd.ForeignType_ID IS NULL THEN 4 /*Access*/  
                    WHEN dhd.ForeignType_ID = 0/*Entity*/ THEN ISNULL(mtSec.Privilege_ID, 1 /*Deny*/)  
                    WHEN dhd.ForeignType_ID = 1/*DBA*/ OR dhd.ForeignType_ID = 5/*Many To Many*/ THEN ISNULL(attSec.Privilege_ID, 1 /*Deny*/)  
                    WHEN dhd.ForeignType_ID = 2/*Explicit Hierarchy*/ THEN ISNULL(ehSec.Privilege_ID, 1 /*Deny*/)  
                END,  
            AccessPermission =  
                CASE  
                    WHEN dhd.ForeignType_ID IS NULL THEN 7 /*All*/  
                    WHEN dhd.ForeignType_ID = 0/*Entity*/ THEN ISNULL(mtSec.AccessPermission, 0 /*None*/)  
                    WHEN dhd.ForeignType_ID = 1/*DBA*/ OR dhd.ForeignType_ID = 5/*Many To Many*/ THEN ISNULL(attSec.AccessPermission, 0 /*None*/)  
                    WHEN dhd.ForeignType_ID = 2 /*Explicit Hierarchy*/THEN ISNULL(ehSec.AccessPermission, 0 /*None*/)  
                END  
        FROM mdm.tblDerivedHierarchy dh  
        CROSS JOIN(  
            SELECT DISTINCT [User_ID] AS [User_ID] -- All users that have at least one functional permission  
            FROM mdm.viw_SYSTEM_SECURITY_USER_FUNCTION  
        ) AS usr  
        LEFT JOIN mdm.tblDerivedHierarchyDetail dhd  
        ON dhd.DerivedHierarchy_ID = dh.ID  
        LEFT JOIN mdm.viw_SYSTEM_SECURITY_USER_MEMBERTYPE mtSec  
        ON      dhd.ForeignType_ID = 0/*Entity*/   
            AND mtSec.ID = 1   
            AND dhd.Foreign_ID = mtSec.Entity_ID   
            AND usr.User_ID = mtSec.User_ID  
        LEFT JOIN mdm.viw_SYSTEM_SECURITY_USER_ATTRIBUTE attSec  
        ON      dhd.ForeignType_ID IN (1/*DBA*/, 5/*Many To Many*/)   
            AND (dhd.Foreign_ID = attSec.ID OR dhd.ManyToManyChildAttribute_ID = attSec.ID)  
            AND usr.User_ID = attSec.User_ID  
        LEFT JOIN mdm.viw_SYSTEM_SECURITY_USER_HIERARCHY ehSec  
        ON      dhd.ForeignType_ID = 2/*Explicit Hierarchy*/   
            AND dhd.Foreign_ID = ehSec.ID   
            AND usr.User_ID = ehSec.User_ID  
        ) dhdSec  
    GROUP BY  
        User_ID,  
        ID  
)  
SELECT  
    [User_ID],  
    ID,  
    Privilege_ID,  
    CASE Privilege_ID WHEN 4 /*Access*/ THEN AccessPermission ELSE NULL END AccessPermission  
FROM allPermissions  
WHERE Privilege_ID > 1 /*Deny*/
go

