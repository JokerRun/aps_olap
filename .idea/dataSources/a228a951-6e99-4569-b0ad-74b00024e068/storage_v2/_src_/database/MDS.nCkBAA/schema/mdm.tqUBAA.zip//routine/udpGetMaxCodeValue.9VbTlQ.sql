/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
/*  
    Call the udpGetMaxCodeValue SPROC to determine the largest numeric Code value for an entity.  
  
    Example: EXEC	[mdm].[udpGetMaxCodeValue]  @Entity_ID = 31  
*/  
CREATE PROCEDURE [mdm].[udpGetMaxCodeValue]  
(  
    @Entity_ID      INT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
AS  
BEGIN  
      
    DECLARE  
        @IsCollectionEnabled    BIT,  
        @IsHierarchyEnabled     BIT,  
        @EntityTable            NVARCHAR(258),  
        @HierarchyParentTable   NVARCHAR(258) = NULL,  
        @CollectionTable        NVARCHAR(258) = NULL,  
        @MemberStatus_Active    TINYINT = 1;  
  
    DECLARE @maxvalue BIGINT = NULL;  
    DECLARE @SQL NVARCHAR(MAX);  
    DECLARE @WhereClause NVARCHAR(MAX) = N'  
        WHERE Status_ID = ' + CONVERT(NVARCHAR, @MemberStatus_Active); -- Do not replace this hardcoded value with a var. It would be bad for perf.  
    DECLARE @SqlAzureEngineEdition INT = 5;  
    DECLARE @IsAzure BIT =  CASE SERVERPROPERTY(N'EngineEdition') WHEN @SqlAzureEngineEdition THEN 1 ELSE 0 END;  
    IF (@IsAzure = 0)  
    BEGIN  
        -- Since SQL CLR is enabled, use the mdq.IsNumber function to filter out non numeric Codes. Otherwise, the filtering will be   
        -- done after all unique Codes are loaded into the temp table.  
        SET @WhereClause += N'  
            AND COALESCE(mdq.IsNumber(Code), 0) = 1';  
    END;  
  
    SELECT   
        @EntityTable = EntityTable,  
        @HierarchyParentTable = HierarchyParentTable,  
        @CollectionTable = CollectionTable,  
        @IsCollectionEnabled = CASE WHEN CollectionTable IS NULL THEN 0 ELSE 1 END,  
        @IsHierarchyEnabled  = CASE WHEN HierarchyTable  IS NULL THEN 0 ELSE 1 END  
    FROM mdm.tblEntity  
    WHERE ID = @Entity_ID;  
  
    CREATE TABLE #NumericCodes   
    (  
         ID INT IDENTITY(1,1) PRIMARY KEY CLUSTERED  
        ,Code NVARCHAR(250) COLLATE DATABASE_DEFAULT  
    );  
  
    -- Get leaf member codes.  
    SET @SQL = N'  
        INSERT INTO #NumericCodes  
        SELECT Code  
        FROM mdm.' + QUOTENAME(@EntityTable) +   
        @WhereClause;  
  
    --If the entity supports collecitons, then also get collection member codes.  
    IF @IsCollectionEnabled = 1  
    BEGIN   
        SET @SQL += N'  
        UNION ALL  
        SELECT Code  
        FROM mdm.' + QUOTENAME(@CollectionTable) +  
        @WhereClause;  
    END  
  
    --If the entity supports hierachies, then also get consolidated member codes.  
    IF @IsHierarchyEnabled = 1  
    BEGIN     
        SET @SQL += N'  
        UNION ALL  
        SELECT Code  
        FROM mdm.' + QUOTENAME(@HierarchyParentTable) +  
        @WhereClause;  
    END  
      
    --PRINT @SQL;  
    EXEC sp_executesql @SQL;  
  
    IF (@IsAzure = 1)  
    BEGIN  
        -- SQL CLR is not supported, so loop through the #NumericCodes rows and remove non-numeric codes.  
        -- TODO: Consider removing this IF block when SQL Azure adds support for SQL CLR  
        DECLARE   
             @Code NVARCHAR(250)  
            ,@Row_ID INT = 0  
            ,@MaxRow_ID INT = COALESCE((SELECT MAX(ID) FROM #NumericCodes), 0)  
            ,@IsNumeric BIT;  
        WHILE @Row_ID < @MaxRow_ID  
        BEGIN  
            -- Get the next row  
            SELECT TOP 1  
                 @Row_ID = ID  
                ,@Code = Code  
            FROM #NumericCodes  
            WHERE ID > @Row_ID  
  
            SET @IsNumeric = 0;  
            EXEC mdq.udpIsNumber @Code, @IsNumeric OUTPUT  
            IF COALESCE(@IsNumeric, 0) = 0  
            BEGIN  
                -- The Code isn't numeric, so delete it from the temp table.  
                DELETE FROM #NumericCodes WHERE ID = @Row_ID  
            END;  
        END;-- WHILE  
    END;   
  
    -- Find the biggest numeric Code value  
    SELECT  
        @maxvalue = MAX(CAST(Code AS BIGINT))  
    FROM #NumericCodes  
  
    -- Return the result of the SPROC  
    RETURN @maxvalue  
END; --[udpGetMaxCodeValue]
go

