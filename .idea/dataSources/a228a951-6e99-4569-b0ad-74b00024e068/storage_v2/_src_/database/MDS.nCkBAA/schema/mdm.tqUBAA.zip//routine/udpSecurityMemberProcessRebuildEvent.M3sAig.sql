/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpSecurityMemberProcessRebuildEvent  
(  
    @SecurityMemberProcessEvent mdm.SecurityMemberProcessEvent READONLY,  
    @ProcessNow                 BIT = 0,  
    @CorrelationID              UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE @handle     UNIQUEIDENTIFIER,  
            @User_ID    INT,  
            @Version_ID INT,  
            @Entity_ID  INT;  
  
    IF NOT EXISTS (SELECT 1 FROM @SecurityMemberProcessEvent)  
    BEGIN  
        RETURN;  
    END  
  
    DECLARE event_cursor CURSOR  
    FOR SELECT [User_ID],[Entity_ID],Version_ID  
        FROM @SecurityMemberProcessEvent  
    OPEN event_cursor  
        FETCH NEXT FROM event_cursor INTO @User_ID, @Entity_ID, @Version_ID;  
        WHILE @@FETCH_STATUS = 0  
        BEGIN  
            --Put a message onto the SB queue to process member security  
            EXEC mdm.udpSecurityMemberQueueSave   
                @User_ID    = @User_ID, -- update member security for the user(s) that pertain(s) to the specified role.  
                @Version_ID = @Version_ID,   
                @Entity_ID  = @Entity_ID;  
            FETCH NEXT FROM event_cursor INTO @User_ID, @Entity_ID, @Version_ID;  
        END  
    CLOSE event_cursor;  
    DEALLOCATE event_cursor;  
  
    --Insert a msg into the Securitymember timer queue to "kick it off"      
    IF @ProcessNow=1  
    BEGIN  
        --get the existing conversation handle if possible  
        SET @handle = mdm.udfServiceGetConversationHandle(  
            N'microsoft/mdm/service/securitymembertimer',  
            N'microsoft/mdm/service/system');  
  
        IF @handle IS NULL   
            BEGIN DIALOG CONVERSATION @handle    
                FROM SERVICE [microsoft/mdm/service/securitymembertimer]    
                TO SERVICE N'microsoft/mdm/service/system'    
                WITH ENCRYPTION=OFF;  
              
        --set a timer on the handle  
        BEGIN CONVERSATION TIMER (@handle) TIMEOUT = 1;        
    END; --if  
      
    SET NOCOUNT OFF;  
END; --proc
go

