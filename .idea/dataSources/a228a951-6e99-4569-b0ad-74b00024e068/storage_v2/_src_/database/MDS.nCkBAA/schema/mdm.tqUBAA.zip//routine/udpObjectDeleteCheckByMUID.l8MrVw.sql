/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    Raises an error if the metadata object with the given MUID and of the given type cannot  
    be deleted. Looks up the object's ID.  
*/  
CREATE PROCEDURE mdm.udpObjectDeleteCheckByMUID  
(  
    @Object_MUID    UNIQUEIDENTIFIER,  
    @ObjectType_ID  TINYINT,  
    @Object_ID      INT = NULL OUTPUT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON  
  
    SET @Object_ID = NULL;  
  
    DECLARE  
         @ErrorMessage  NVARCHAR(MAX)  
        ,@Ret           INT  
  
        ,@MemberType_Leaf           TINYINT = 1  
        ,@MemberType_Consolidated   TINYINT = 2  
              
        ,@ObjectType_Model                  TINYINT = 1  
        ,@ObjectType_DerivedHierarchy       TINYINT = 2  
        ,@ObjectType_DerivedHierarchyLevel  TINYINT = 3  
        ,@ObjectType_Version                TINYINT = 4  
        ,@ObjectType_Entity                 TINYINT = 5  
        ,@ObjectType_Hierarchy              TINYINT = 6  
        ,@ObjectType_Attribute              TINYINT = 7  
        ,@ObjectType_AttributeGroup         TINYINT = 8  
        ,@ObjectType_VersionFlag            TINYINT = 10  
        ,@ObjectType_Index                  TINYINT = 23  
;  
  
    --Default the Value  
    SET @ErrorMessage = NULL;  
  
    IF @ObjectType_ID = @ObjectType_Model  
    BEGIN  
        SELECT @Object_ID = ID FROM mdm.tblModel WHERE MUID = @Object_MUID;  
    END   
      
    ELSE IF @ObjectType_ID IN (@ObjectType_DerivedHierarchy, @ObjectType_DerivedHierarchyLevel)  
    BEGIN  
        DECLARE @DerivedHierarchy_ID INT;  
        IF @ObjectType_ID = @ObjectType_DerivedHierarchy  
        BEGIN  
            SELECT @Object_ID = ID FROM mdm.tblDerivedHierarchy WHERE MUID = @Object_MUID;  
            SET @DerivedHierarchy_ID = @Object_ID  
        END ELSE  
        BEGIN  
            SELECT  
                 @Object_ID = ID  
                ,@DerivedHierarchy_ID = DerivedHierarchy_ID  
            FROM mdm.tblDerivedHierarchyDetail  
            WHERE MUID = @Object_MUID  
        END  
  
        EXEC mdm.udpSubscriptionViewCheck @DerivedHierarchy_ID = @DerivedHierarchy_ID, @ViewFormat_ID = 8 /*Levels*/, @Return_ID = @Ret output  
        IF @Ret > 0  
        BEGIN  
            -- No reason to differentiate between Subscription with Levels vs. with ParentChild.  See TFS 360606  
            SET @ErrorMessage = N'MDSERR200049|The derived hierarchy was not deleted because a subscription view exists.  To delete the hierarchy, you must first delete all subscription views associated with this derived hierarchy.';  
        END ELSE  
        BEGIN  
            EXEC mdm.udpSubscriptionViewCheck @DerivedHierarchy_ID = @DerivedHierarchy_ID, @ViewFormat_ID = 7 /*ParentChild*/, @Return_ID = @Ret output  
            IF @Ret > 0  
            BEGIN  
                SET @ErrorMessage = N'MDSERR200049|The derived hierarchy was not deleted because a subscription view exists.  To delete the hierarchy, you must first delete all subscription views associated with this derived hierarchy.';  
            END  
        END  
    END   
      
    ELSE IF @ObjectType_ID = @ObjectType_Version   
    BEGIN  
        SELECT @Object_ID = ID FROM mdm.tblModelVersion WHERE MUID = @Object_MUID;  
    END   
      
    ELSE IF @ObjectType_ID = @ObjectType_Entity   
    BEGIN  
        SELECT @Object_ID = ID FROM mdm.tblEntity WHERE MUID = @Object_MUID  
  
        IF EXISTS(SELECT 1 FROM mdm.tblAttribute WHERE DomainEntity_ID = @Object_ID AND DomainEntity_ID <> Entity_ID)   
        BEGIN  
            SET @ErrorMessage = N'MDSERR200023|The entity cannot be deleted because it is referenced by a domain-based attribute.';  
        END ELSE IF EXISTS(SELECT 1 FROM mdm.tblBRBusinessRule WHERE Entity_ID = @Object_ID)   
        BEGIN  
            SET @ErrorMessage = N'MDSERR200024|The entity cannot be deleted because it is referenced by a business rule.';  
        END ELSE IF EXISTS(SELECT 1 FROM mdm.viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED_LEVELS WHERE @Object_ID IN (ForeignEntity_ID, Entity_ID))   
        BEGIN  
            SET @ErrorMessage = N'MDSERR200025|The entity cannot be deleted because it is referenced by a derived hierarchy.';  
        END ELSE   
        BEGIN  
            EXEC mdm.udpSubscriptionViewCheck @Entity_ID = @Object_ID, @Return_ID = @Ret output  
            IF @Ret > 0  
                SET @ErrorMessage = N'MDSERR200052|The change cannot be made because there are subscription views for this entity and model.';  
        END; --if  
    END   
      
    ELSE IF @ObjectType_ID = @ObjectType_Hierarchy   
    BEGIN  
        SELECT @Object_ID = ID FROM mdm.tblHierarchy WHERE MUID = @Object_MUID  
  
        IF EXISTS(SELECT 1 FROM mdm.tblDerivedHierarchyDetail WHERE Foreign_ID = @Object_ID AND ForeignType_ID = 2/*Hierarchy*/)   
        BEGIN  
            SET @ErrorMessage = N'MDSERR200030|The explicit hierarchy cannot be deleted because it is referenced by a derived hierarchy.';  
        END ELSE IF EXISTS(  
            -- Check if there are any consolidation rules.  If this is the last hierarchy (current count = 1)  
            -- then prevent the deletion until the BR has been deleted.  
            SELECT	1  
            FROM	mdm.tblBRBusinessRule br INNER JOIN   
                    mdm.tblHierarchy h ON   
                        br.Entity_ID = h.Entity_ID AND  
                        br.MemberType_ID = @MemberType_Consolidated AND  
                        h.ID = @Object_ID  
            WHERE  
                 (SELECT COUNT(ID) FROM mdm.tblHierarchy hr WHERE h.Entity_ID = hr.Entity_ID) = 1   
            UNION ALL  
            -- Check if there are any leaf rules that refer to consolidation attributes  
            SELECT 1 FROM mdm.tblBRItemProperties WHERE PropertyType_ID = 3 AND [Value] = CONVERT(NVARCHAR(999),@Object_ID)  
        )   
        BEGIN  
            SET @ErrorMessage = N'MDSERR200031|The explicit hierarchy cannot be deleted because it is referenced by a business rule.';  
        END; --if  
    END   
      
    ELSE IF @ObjectType_ID = @ObjectType_Attribute   
    BEGIN  
        SELECT @Object_ID = ID FROM mdm.tblAttribute WHERE MUID = @Object_MUID  
  
        IF EXISTS(SELECT 1 FROM mdm.tblDerivedHierarchyDetail   
                  WHERE (   Foreign_ID = @Object_ID   
                        AND ForeignType_ID IN (1/*DBA*/, 5/*ManyToMany*/)  
                        )  
                    OR ManyToManyChildAttribute_ID = @Object_ID  
                  )   
        BEGIN  
            SET @ErrorMessage = N'MDSERR200028|The attribute cannot be deleted because it is referenced by a derived hierarchy.';  
        END ELSE IF EXISTS(SELECT 1 FROM mdm.tblBRItemProperties WHERE   
            (PropertyType_ID = 2 OR PropertyType_ID = 4) AND [Value] = CONVERT(NVARCHAR(999),@Object_ID))   
        BEGIN  
            SET @ErrorMessage = N'MDSERR200027|The attribute cannot be deleted because it is referenced by a business rule.';  
        END;  
        -- Note: if a subscription view exists that uses the attribute, then the subscription view will be updated when the attribute is deleted  
    END   
      
    ELSE IF @ObjectType_ID = @ObjectType_AttributeGroup   
    BEGIN  
        SELECT @Object_ID = ID FROM mdm.tblAttributeGroup WHERE MUID = @Object_MUID  
    END   
      
    ELSE IF @ObjectType_ID = @ObjectType_VersionFlag   
    BEGIN --Version Flag  
        SELECT @Object_ID = ID FROM mdm.tblModelVersionFlag WHERE MUID = @Object_MUID  
  
        IF EXISTS(SELECT 1 FROM mdm.tblModelVersion WHERE VersionFlag_ID = @Object_ID) BEGIN  
            SET @ErrorMessage = N'MDSERR200035|The version flag cannot be deleted because it is referenced by a version.'  
        END; --if  
    END   
      
    ELSE IF @ObjectType_ID = @ObjectType_Index   
    BEGIN  
        SELECT @Object_ID = ID FROM mdm.tblIndex WHERE MUID = @Object_MUID  
    END   
      
    ELSE  
    BEGIN  
        -- Bad object type  
        SET @ErrorMessage = N'MDSERR100010|The Parameters are not valid.';  
    END  
  
    IF @ErrorMessage IS NOT NULL  
    BEGIN  
        SET @ErrorMessage = REPLACE(@ErrorMessage, '%', '%%')-- escape out format specifier  
        RAISERROR(@ErrorMessage, 16, 1)  
    END  
  
    SET NOCOUNT OFF;  
END; --proc
go

