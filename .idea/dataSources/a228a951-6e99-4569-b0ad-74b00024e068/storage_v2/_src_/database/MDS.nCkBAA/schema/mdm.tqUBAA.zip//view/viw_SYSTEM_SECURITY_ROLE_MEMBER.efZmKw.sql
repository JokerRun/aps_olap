/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE VIEW mdm.viw_SYSTEM_SECURITY_ROLE_MEMBER  
/*WITH SCHEMABINDING*/  
AS  
SELECT  
    sra.Role_ID,  
    hsec.[Entity_ID],  
    hsec.LeafOnly,  
    sra.Version_ID,  
    hsec.ID [Hierarchy_ID],  
    hsec.HierarchyType_ID,  
    sra.IsInitialized  
FROM (  
    SELECT  
        dh.ID AS ID,  
        1 /*HierarchyType_Derived*/ AS HierarchyType_ID,  
        CASE ForeignType_ID  
            WHEN 2 /*HierarchyItemType_ExplicitHierarchy*/ THEN 0  
            ELSE 1  
        END AS LeafOnly,  
        CASE ForeignType_ID  
            WHEN 0 /*HierarchyItemType_Entity*/ THEN dhd.Foreign_ID  
            WHEN 1 /*HierarchyItemType_DBA*/ THEN dba.DomainEntity_ID  
            WHEN 2 /*HierarchyItemType_ExplicitHierarchy*/ THEN eh.[Entity_ID]  
            WHEN 5 /*HierarchyItemType_ManyToMany*/ THEN dba.DomainEntity_ID  
        END AS [Entity_ID]  
    FROM mdm.tblDerivedHierarchy dh    
    INNER JOIN mdm.tblDerivedHierarchyDetail dhd  
    ON dhd.DerivedHierarchy_ID = dh.ID  
    LEFT JOIN mdm.tblAttribute dba  
    ON (ForeignType_ID = 1 /*HierarchyItemType_DBA*/ OR ForeignType_ID = 5 /*HierarchyItemType_ManyToMany*/)  
        AND dba.ID = dhd.Foreign_ID  
    LEFT JOIN mdm.tblHierarchy eh  
    ON ForeignType_ID = 2 /*HierarchyItemType_ExplicitHierarchy*/ AND eh.ID = dhd.Foreign_ID  
    UNION ALL  
    SELECT  
        eh.ID,  
        0 /*HierarchyType_Explicit*/ AS HierarchyType_ID,  
        0 AS LeafOnly,  
        eh.[Entity_ID]  
    FROM mdm.tblHierarchy eh) hsec  
    INNER JOIN mdm.tblSecurityRoleAccessMember sra  
    ON (hsec.HierarchyType_ID = sra.HierarchyType_ID)  
        AND (hsec.ID = sra.DerivedHierarchy_ID AND sra.HierarchyType_ID = 1 /*HierarchyType_Derived*/)  
            OR (hsec.ID = sra.ExplicitHierarchy_ID AND sra.HierarchyType_ID = 0 /*HierarchyType_Explicit*/ )
go

