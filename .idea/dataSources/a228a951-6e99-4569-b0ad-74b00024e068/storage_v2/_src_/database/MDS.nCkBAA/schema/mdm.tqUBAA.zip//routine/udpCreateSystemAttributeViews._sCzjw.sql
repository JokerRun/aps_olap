/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    EXEC mdm.udpCreateSystemAttributeViews 1,1,0;  
*/  
CREATE PROCEDURE mdm.udpCreateSystemAttributeViews  
(  
    @Entity_ID      INT,  
    @MemberType_ID  TINYINT,  
    @ViewType       TINYINT = 0, -- 0 EN, 1 PD, 2 HS  
    @CorrelationID  UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    --Defer view generation if we are in the middle of an upgrade or demo-rebuild  
    IF APPLOCK_MODE(N'public', N'DeferViewGeneration', N'Session') = N'NoLock' BEGIN  
  
        DECLARE @ViewName                   SYSNAME,  
                @EntityTable                SYSNAME,  
                @CollectionTable            SYSNAME,  
                @HierarchyParentTable       SYSNAME,  
                @DomainTable                SYSNAME,  
                @Select                     NVARCHAR(MAX),  
                @From                       NVARCHAR(MAX) = N'',  
                @TableColumn                SYSNAME,  
                @ViewColumn                 NVARCHAR(120), --specifically made to be less than 128 for truncation reasons  
                @ViewColumnQuoted           NVARCHAR(300),  
                @DomainEntity_ID            INT,  
                @AttributeType_ID           TINYINT,  
  
                @AttributeDataType_ID       TINYINT,  
                @AttributeDataType_Text     TINYINT = 1,  
                @AttributeDataType_Number   TINYINT = 2,  
                @AttributeDataType_DateTime TINYINT = 3,  
                @AttributeDataType_Link     TINYINT = 6,  
  
                --Member Types  
                @MemberType_Leaf            TINYINT = 1,  
                @MemberType_Consolidated    TINYINT = 2,  
                @MemberType_Collection      TINYINT = 3,  
  
                @ViewType_EN                TINYINT = 0,  
                @ViewType_PD                TINYINT = 1,  
                @ViewType_HS                TINYINT = 2;  
  
        --Initialize the variables  
        SELECT  
            @EntityTable = EntityTable,  
            @CollectionTable = CollectionTable,  
            @HierarchyParentTable = HierarchyParentTable,  
            @ViewName = mdm.udfViewNameGetByID(ID, @MemberType_ID, 0, @ViewType)  
        FROM mdm.tblEntity  
        WHERE ID = @Entity_ID;  
  
        IF @ViewName IS NOT NULL  
        BEGIN --Ensure row actually exists  
  
            --Get the Attributes for the Entity and then find the corresponding lookup table  
            DECLARE @TempTable TABLE(  
                 ViewColumn         NVARCHAR(120) COLLATE database_default  
                ,TableColumn        SYSNAME COLLATE database_default  
                ,AttributeType_ID   TINYINT  
                ,DataType_ID        TINYINT  
                ,DomainEntity_ID    INT  
                ,DomainTable        SYSNAME COLLATE database_default NULL  
                ,SortOrder          INT);  
            INSERT INTO @TempTable  
            SELECT  
                 A.Name AS ViewColumn,  
                TableColumn,  
                AttributeType_ID,  
                DataType_ID,  
                DomainEntity_ID,  
                E.EntityTable AS DomainTable,  
                SortOrder  
            FROM mdm.tblAttribute A  
            LEFT JOIN mdm.tblEntity E  
                ON A.DomainEntity_ID = E.ID  
            WHERE A.Entity_ID = @Entity_ID  
                AND A.MemberType_ID = @MemberType_ID  
                AND A.IsSystem = 0  
            ORDER BY  
                SortOrder ASC;  
  
            SET @Select =  
                CASE @MemberType_ID  
                    WHEN @MemberType_Leaf THEN   
                        CASE @ViewType  
                            WHEN @ViewType_EN THEN N'  
     T.ID  
    ,T.MUID  
    ,T.Version_ID  
    ,T.Name AS Name  
    ,T.Code AS Code  
    ,T.ValidationStatus_ID  
    ,T.ChangeTrackingMask  
    ,T.LastChgTS'  
                            WHEN @ViewType_PD THEN N'  
     T.CS_ID  
    ,T.ID AS PD_ID  
    ,T.Status_ID  
    ,T.EN_ID AS ID  
    ,T.MUID  
    ,T.Version_ID  
    ,NULLIF(T.Code, NCHAR(0) /* @SysNull_Text */) AS [Code]  
    ,CASE WHEN T.Code IS NULL THEN 0 ELSE 1 END AS [Code.IsChanged]  
    ,NULLIF(T.Name, NCHAR(0) /* @SysNull_Text */) AS [Name]  
    ,CASE WHEN T.Name IS NULL THEN 0 ELSE 1 END AS [Name.IsChanged]  
    ,T.Revision_ID AS LastChgTS'  
                            WHEN @ViewType_HS THEN N'  
     T.ID AS HS_ID  
    ,T.Status_ID  
    ,T.EN_ID AS ID  
    ,T.MUID  
    ,T.Version_ID  
    ,T.Name AS Name  
    ,T.Code AS Code  
    ,T.ID AS LastChgTS'  
                    END  
                    WHEN @MemberType_Consolidated THEN  
                        CASE @ViewType  
                            WHEN @ViewType_EN THEN N'  
     T.ID  
    ,T.MUID  
    ,T.Version_ID  
    ,T.Name AS Name  
    ,T.Code AS Code  
    ,T.ValidationStatus_ID  
    ,T.Hierarchy_ID AS Hierarchy_ID  
    ,T.ChangeTrackingMask  
    ,T.LastChgTS'  
                            WHEN @ViewType_HS THEN N'  
     T.ID AS HS_ID  
    ,T.Status_ID  
    ,T.HP_ID AS ID  
    ,T.MUID  
    ,T.Version_ID  
    ,T.Name AS Name  
    ,T.Code AS Code  
    ,T.Hierarchy_ID AS Hierarchy_ID  
    ,T.ID AS LastChgTS'  
                    END  
                    WHEN @MemberType_Collection THEN  
                        CASE @ViewType  
                            WHEN @ViewType_EN THEN N'  
     T.ID  
    ,T.MUID  
    ,T.Version_ID  
    ,T.Name AS Name  
    ,T.Code AS Code  
    ,T.ValidationStatus_ID  
    ,T.Description  
    ,COALESCE([Owner_ID].UserName, N'''') AS Owner_ID  
    ,T.LastChgTS'  
                            WHEN @ViewType_HS THEN N'  
     T.ID AS HS_ID  
    ,T.Status_ID  
    ,T.CN_ID AS ID  
    ,T.MUID  
    ,T.Version_ID  
    ,T.Name AS Name  
    ,T.Code AS Code  
    ,T.Description  
    ,COALESCE([Owner_ID].UserName, N'''') AS Owner_ID  
    ,T.ID AS LastChgTS'  
                        END  
                END;  
  
            SET @Select = @Select + N'  
    --Auditing columns (Creation)  
    ,T.EnterDTM  
    ,T.EnterUserID  
    ,eu.[UserName] AS EnterUserName  
    ,eu.MUID AS EnterUserMuid  
  
    --Auditing columns (Updates)  
    ,T.LastChgDTM  
    ,T.LastChgUserID  
    ,lcu.[UserName] AS LastChgUserName  
    ,lcu.MUID AS LastChgUserMuid  
  
    --Custom attributes';  
  
            SET @From += N'  
LEFT JOIN mdm.tblUser eu  
    ON T.EnterUserID = eu.ID  
LEFT JOIN mdm.tblUser lcu  
    ON T.LastChgUserID = lcu.ID';  
  
            IF @MemberType_ID = @MemberType_Collection  
            BEGIN  
                SET @From += N'  
LEFT JOIN mdm.tblUser AS Owner_ID   
    ON Owner_ID.ID = T.Owner_ID';  
            END  
  
            IF @MemberType_ID = @MemberType_Leaf AND @ViewType = @ViewType_PD  
            BEGIN  
                SET @From += N'  
LEFT JOIN mdm.' + @EntityTable + N' AS EN  
    ON T.EN_ID = EN.ID AND T.Version_ID = EN.Version_ID';  
            END  
  
            WHILE EXISTS(SELECT 1 FROM @TempTable)  
            BEGIN  
                SELECT TOP 1  
                    @ViewColumn = ViewColumn,  
                    @TableColumn = TableColumn,  
                    @AttributeType_ID = AttributeType_ID,  
                    @AttributeDataType_ID = DataType_ID,  
                    @DomainEntity_ID = DomainEntity_ID,  
                    @DomainTable = DomainTable  
                FROM @TempTable  
                ORDER BY SortOrder;  
  
                SET @ViewColumnQuoted = QUOTENAME(@ViewColumn);  
  
                IF @AttributeType_ID = 1  
                BEGIN --FFA  
                    IF @ViewType <> @ViewType_PD  
                    BEGIN  
                        SET @Select = @Select + N'  
    ,T.' + QUOTENAME(@TableColumn) + N' AS ' + @ViewColumnQuoted;  
                    END  
                    ELSE  
                    BEGIN  
                        SET @Select = @Select + CONCAT(N'  
            ,NULLIF(T.', QUOTENAME(@TableColumn), N', ',  
                            CASE  
                                WHEN @AttributeDataType_ID = @AttributeDataType_Text OR @AttributeDataType_ID = @AttributeDataType_Link THEN N'NCHAR(0) /* @SysNull_Text */'  
                                WHEN @AttributeDataType_ID = @AttributeDataType_Number THEN N'-98765432101234567890/* @SysNull_Number */'  
                                WHEN @AttributeDataType_ID = @AttributeDataType_DateTime THEN N'N''5555-11-22T12:34:56'' /* @SysNull_DateTime */'  
                            END, N') AS ', @ViewColumnQuoted, N'  
            ,CASE WHEN T.', QUOTENAME(@TableColumn), N' IS NULL THEN 0 ELSE 1 END AS ', QUOTENAME(@ViewColumn + '.IsChanged'))  
                    END  
                END  
                ELSE IF @AttributeType_ID = 2  
                BEGIN --DBA  
                    SET @Select += N'  
    ,' + @ViewColumnQuoted + N'.Code AS ' + @ViewColumnQuoted + N'  
    , T.' + QUOTENAME(@TableColumn) + N' AS ' + QUOTENAME(@ViewColumn + N'.ID') + N'  
    ,' + @ViewColumnQuoted + N'.MUID AS ' + QUOTENAME(@ViewColumn + N'.MUID') + N'  
    ,' + @ViewColumnQuoted + N'.Name AS ' + QUOTENAME(@ViewColumn + N'.Name');  
  
                    IF @ViewType = @ViewType_PD  
                    BEGIN  
                        SET @Select += N'  
    ,CASE WHEN T.' + QUOTENAME(@TableColumn) + N'IS NULL THEN 0 ELSE 1 END AS ' + QUOTENAME(@ViewColumn + N'.IsChanged');  
                    END  
  
                    SET @From += N'  
LEFT JOIN mdm.' + QUOTENAME(@DomainTable) + N' AS ' + @ViewColumnQuoted + N'  
    ON ' + @ViewColumnQuoted + N'.ID = T.' + QUOTENAME(@TableColumn) + N' AND ' + @ViewColumnQuoted + N'.Version_ID = T.Version_ID';  
                END  
                ELSE IF @AttributeType_ID = 4  
                BEGIN --File  
                    SET @Select += N'  
    ,' + @ViewColumnQuoted + N'.FileName AS ' + @ViewColumnQuoted + N'  
    ,T.' + QUOTENAME(@TableColumn) + N' AS ' + QUOTENAME(@ViewColumn + N'.ID');  
                    IF @ViewType = @ViewType_PD  
                    BEGIN  
                        SET @Select += N'  
    ,CASE WHEN T.' + QUOTENAME(@TableColumn) + N'IS NULL THEN 0 ELSE 1 END AS ' + QUOTENAME(@ViewColumn + N'.IsChanged');  
                    END  
  
                    SET @From += N'  
LEFT JOIN mdm.tblFile AS ' + @ViewColumnQuoted + N'  
    ON ' + @ViewColumnQuoted + N'.ID = T.' + QUOTENAME(@TableColumn);  
                END; --if  
  
                DELETE FROM @TempTable WHERE ViewColumn = @ViewColumn;  
            END; --while  
  
            SET @Select = CASE  
                WHEN EXISTS(SELECT 1 FROM sys.views WHERE [name] = @ViewName AND [schema_id] = SCHEMA_ID('mdm')) THEN N'ALTER '  
                ELSE N'  
CREATE ' END + N'VIEW mdm.' + QUOTENAME(@ViewName) + N'  
/*WITH ENCRYPTION*/ AS  
SELECT ' + @Select;  
  
            IF @MemberType_ID = @MemberType_Leaf BEGIN  
                SET @Select = @Select + N'  
FROM mdm.' +  
                CASE @ViewType  
                    WHEN @ViewType_EN THEN QUOTENAME(@EntityTable)  
                    WHEN @ViewType_PD THEN QUOTENAME(@EntityTable + N'_PD')  
                    WHEN @ViewType_HS THEN QUOTENAME(@EntityTable + N'_HS')  
                END + N' AS T';  
            END ELSE IF @MemberType_ID = @MemberType_Consolidated BEGIN  
                SET @Select = @Select + N'  
FROM mdm.' +  
                CASE @ViewType  
                    WHEN @ViewType_EN THEN QUOTENAME(@HierarchyParentTable)  
                    WHEN @ViewType_HS THEN QUOTENAME(@HierarchyParentTable + N'_HS')  
                END + N' AS T';  
  
            END ELSE IF @MemberType_ID = @MemberType_Collection BEGIN  
                SET @Select = @Select + N'  
FROM mdm.' +  
                CASE @ViewType  
                    WHEN @ViewType_EN THEN QUOTENAME(@CollectionTable)  
                    WHEN @ViewType_HS THEN QUOTENAME(@CollectionTable + N'_HS')  
                END + N' AS T';  
            END; --if  
  
            SET @Select += @From  
  
            IF @ViewType = @ViewType_EN  
            BEGIN  
                SET @Select += N'  
WHERE T.Status_ID = 1;';  
            END  
  
            --PRINT(@Select);  
            EXEC sp_executesql @Select;  
  
        END; --if  
  
    END; --if  
  
    SET NOCOUNT OFF;  
END; --proc
go

