/*  
    SELECT mdm.udfGetTransactionViewName(7)  
*/  
/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE FUNCTION mdm.udfGetTransactionViewName  
(  
    @Model_ID   INT  
)   
RETURNS sysname  
/*WITH SCHEMABINDING*/  
AS BEGIN  
  
    RETURN CONCAT(N'viw_SYSTEM_', @Model_ID, N'_TRANSACTIONS');  
  
END; --fn
go

