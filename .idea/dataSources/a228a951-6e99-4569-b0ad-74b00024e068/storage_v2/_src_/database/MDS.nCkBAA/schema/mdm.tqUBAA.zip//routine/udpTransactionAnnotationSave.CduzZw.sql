/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpTransactionAnnotationSave  
(  
    @User_ID            INT,  
    @Model_ID           INT,  
    @Version_ID         INT,  
    @Transaction_ID     INT,  
    @Comment            NVARCHAR(500),  
    @Return_ID          INT = NULL OUTPUT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE @ID AS INT,  
            @CurrentDTM AS DATETIME2(3),  
            @AnnotationTableName sysname = NULL,  
            @SQL NVARCHAR(MAX);  
  
    --Initialize local variables  
    SELECT  
        @CurrentDTM = GETUTCDATE();  
  
    --Start transaction, being careful to check if we are nested  
    DECLARE @TranCounter INT;  
    SET @TranCounter = @@TRANCOUNT;  
    IF @TranCounter > 0 SAVE TRANSACTION TX;  
    ELSE BEGIN TRANSACTION AnnotationSave;  
  
    BEGIN TRY  
  
    --Test for invalid parameters  
        IF NOT EXISTS(SELECT ID FROM mdm.tblUser WHERE ID = @User_ID) --Invalid @User_ID  
        BEGIN  
            RAISERROR('MDSERR100010|The Parameters are not valid.', 16, 1);  
            RETURN(1);  
        END; --if  
  
        --Validate model  
        IF NOT EXISTS(SELECT ID FROM mdm.tblModel WHERE ID = @Model_ID)  
        BEGIN  
            RAISERROR('MDSERR100010|The Parameters are not valid.', 16, 1);  
            RETURN(1);  
        END  
  
        SET @AnnotationTableName = mdm.udfGetTransactionAnnotationTableName(@Model_ID);  
  
        BEGIN  
            --Insert the Annotation comment  
            SET @SQL = N'  
            INSERT INTO [mdm].' + QUOTENAME(@AnnotationTableName) + N'  
            (  
                 [Version_ID]  
                ,[Transaction_ID]  
                ,[EnterDTM]  
                ,[EnterUserID]  
                ,[LastChgDTM]  
                ,[LastChgUserID]  
                ,[Comment]  
            ) SELECT  
                @Version_ID,  
                @Transaction_ID,  
                @CurrentDTM,  
                @User_ID,  
                @CurrentDTM,  
                @User_ID,  
                @Comment  
            ';  
            EXEC sp_executesql @SQL, N'@Version_ID INT, @Transaction_ID INT, @CurrentDTM DATETIME2(3), @User_ID INT, @Comment NVARCHAR(500)',  
                                       @Version_ID,     @Transaction_ID,     @CurrentDTM,              @User_ID,     @Comment;  
  
            --Save the identity value  
            SET @ID = SCOPE_IDENTITY();  
  
            --Return values  
            SET @Return_ID = @ID;  
  
            --Commit only if we are not nested  
            IF @TranCounter = 0 COMMIT TRANSACTION AnnotationSave;  
            RETURN(0);  
        END;  
  
    END TRY  
    --Handle exceptions  
    BEGIN CATCH  
  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        --Rollback appropriate transaction  
        IF @TranCounter = 0 ROLLBACK TRANSACTION AnnotationSave;  
        ELSE IF XACT_STATE() <> -1 ROLLBACK TRANSACTION TX;  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
  
        --On error, return NULL results  
        SELECT @Return_ID = NULL;  
        RETURN(1);  
  
    END CATCH;  
  
    SET NOCOUNT OFF;  
END; --proc
go

