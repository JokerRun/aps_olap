/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
SELECT CONVERT(XML, mdm.udfNotificationGetValidationIssueHeader());  
*/  
CREATE FUNCTION mdm.udfNotificationGetValidationIssueHeader()  
RETURNS NVARCHAR(MAX)  
/*WITH SCHEMABINDING*/  
AS BEGIN  
  
    DECLARE  
         @HeaderElement NVARCHAR(MAX)  
        ,@LocalizedNotificationTypeName NVARCHAR(MAX) = N'Validation Issue'  
        ,@LocalizedModelHeader NVARCHAR(MAX) = N'Model'  
        ,@LocalizedVersionHeader NVARCHAR(MAX) = N'Version'  
        ,@LocalizedEntityHeader NVARCHAR(MAX) = N'Entity'  
        ,@LocalizedLink NVARCHAR(MAX) = N'Link'  
        ,@LocalizedIDHeader NVARCHAR(MAX) = N'ID'  
        ,@LocalizedMemberCodeHeader NVARCHAR(MAX) = N'Member Code'  
        ,@LocalizedMessageHeader NVARCHAR(MAX) = N'Message'  
        ,@LocalizedIssuedHeader NVARCHAR(MAX) = N'Issued'  
        ,@LocalizedProductName NVARCHAR(MAX) = N'SQL Server Master Data Services'  
        ,@CurrentLanguageCode INT = 1033 -- Default language code is English (US).  
        ,@StringLanguageCode NVARCHAR(MAX) = N''  
        ,@RootUrl NVARCHAR(MAX)  
  
    -- Use default language code to get the notification language code.  
    SELECT @StringLanguageCode = mdm.udfLocalizedStringGet(N'NotificationLCID', @CurrentLanguageCode, 1033);  
  
    IF @StringLanguageCode <> N'' BEGIN  
        SELECT @CurrentLanguageCode = CONVERT(INT, @StringLanguageCode)  
    END; -- if  
  
    -- Get the localized message texts based on the notification language code in tblLocalizedStrings.  
    SELECT @LocalizedIDHeader = mdm.udfLocalizedStringGet(N'NotificationHeaderID', @CurrentLanguageCode, @LocalizedIDHeader);  
    SELECT @LocalizedModelHeader = mdm.udfLocalizedStringGet(N'NotificationHeaderModel', @CurrentLanguageCode, @LocalizedModelHeader);  
    SELECT @LocalizedVersionHeader = mdm.udfLocalizedStringGet(N'NotificationHeaderVersion', @CurrentLanguageCode, @LocalizedVersionHeader);  
    SELECT @LocalizedEntityHeader = mdm.udfLocalizedStringGet(N'NotificationHeaderEntity', @CurrentLanguageCode, @LocalizedEntityHeader);  
    SELECT @LocalizedMemberCodeHeader = mdm.udfLocalizedStringGet(N'NotificationHeaderMemberCode', @CurrentLanguageCode, @LocalizedMemberCodeHeader);  
    SELECT @LocalizedMessageHeader = mdm.udfLocalizedStringGet(N'NotificationHeaderMessage', @CurrentLanguageCode, @LocalizedMessageHeader);  
    SELECT @LocalizedIssuedHeader = mdm.udfLocalizedStringGet(N'NotificationHeaderIssued', @CurrentLanguageCode, @LocalizedIssuedHeader);  
    SELECT @LocalizedLink = mdm.udfLocalizedStringGet(N'NotificationLinkText', @CurrentLanguageCode, @LocalizedLink);  
    SELECT @LocalizedProductName = mdm.udfLocalizedStringGet(N'NotificationProductName', @CurrentLanguageCode, @LocalizedProductName);  
    SELECT @LocalizedNotificationTypeName = mdm.udfLocalizedStringGet(N'NotificationValidationIssue', @CurrentLanguageCode, @LocalizedNotificationTypeName);  
  
    -- Get the MDS web application root URL  
    SELECT @RootUrl = mdm.udfSystemSettingGet(N'MDMRootURL');  
  
    IF RIGHT(@RootUrl, 1) != N'/'  
    BEGIN  
        SET @RootUrl = CONCAT(@RootUrl, N'/');  
    END  
  
    SET @HeaderElement = CONCAT(N'  
        <header>  
          <ProductName>', (SELECT @LocalizedProductName FOR XML PATH('')), N'</ProductName>  
          <Notification_type>', (SELECT @LocalizedNotificationTypeName FOR XML PATH('')), N'</Notification_type>  
          <id>', (SELECT @LocalizedIDHeader FOR XML PATH('')), N'</id>  
          <Model>', (SELECT @LocalizedModelHeader FOR XML PATH('')), N'</Model>  
          <Version>', (SELECT @LocalizedVersionHeader FOR XML PATH('')), N'</Version>  
          <Entity>', (SELECT @LocalizedEntityHeader FOR XML PATH('')), N'</Entity>  
          <MemberCode>', (SELECT @LocalizedMemberCodeHeader FOR XML PATH('')), N'</MemberCode>  
          <Message>', (SELECT @LocalizedMessageHeader FOR XML PATH('')), N'</Message>  
          <Issued>', (SELECT @LocalizedIssuedHeader FOR XML PATH('')), N'</Issued>  
          <root_url>', (SELECT @RootUrl FOR XML PATH('')), N'</root_url>  
        </header>');  
  
    RETURN @HeaderElement  
  
END --fn
go

