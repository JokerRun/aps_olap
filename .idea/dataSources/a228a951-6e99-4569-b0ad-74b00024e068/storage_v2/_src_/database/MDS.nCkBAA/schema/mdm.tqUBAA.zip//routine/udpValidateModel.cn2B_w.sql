/*  
EXEC mdm.udpValidateModel 1, 9, 5, 0  
select * from mdm.tbl_7_VL  
truncate table mdm.tbl_7_VL  
select * from mdm.tblModelVersion  
*/  
/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpValidateModel  
(  
    @User_ID		INT,  
    @Model_ID		INT,  
    @Version_ID		INT,  
    @Status_ID		INT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON  
  
  
    EXEC mdm.udpSystemEventSave @User_ID=@User_ID,@Version_ID=@Version_ID,@EventName='ValidateModel',@EventStatus_ID=1 -- EventStatus = 1 means NotRunning  
  
    DECLARE @MetaID		INT;  
    DECLARE @EntityID	INT;  
    DECLARE	@Entities   TABLE (EntityID int,ProcessSeq int);  
    DECLARE @ValidationLogViewName  sysname;  
    DECLARE @SQL NVARCHAR(MAX);  
    DECLARE @ValidationIssuesExist BIT;  
    DECLARE @EventStatus_NotRunning TINYINT = 2;  
  
    --Determine processing sequence of entities based on entity dependency or derived hierarchy processing priority.  
    INSERT INTO @Entities  
        SELECT   
              Entity_ID  
             ,[Level]  
        FROM mdm.udfEntityGetProcessingSequence(@Model_ID)  
        ORDER BY [Level]  
          
    DECLARE @CurrentStatus_ID TINYINT  
    DECLARE @Counter INT = 1;  
    DECLARE @MaxCounter INT = (SELECT MAX(ProcessSeq) FROM @Entities);  
  
    WHILE @Counter <= @MaxCounter  
    BEGIN  
        SELECT @EntityID = EntityID FROM @Entities WHERE ProcessSeq = @Counter;  
        EXEC mdm.udpValidateEntity @User_ID, @Version_ID, @EntityID  
          
        SELECT @CurrentStatus_ID = EventStatus_ID FROM mdm.tblEvent E WHERE E.LastChgUserID = @User_ID AND EventName = CAST(N'ValidateModel' AS NVARCHAR(100)) AND Version_ID = @Version_ID  
          
        IF @CurrentStatus_ID = 2 --Canceled  
            SET @Counter = @MaxCounter + 1;  
        ELSE  
            SET @Counter += 1;  
    END -- WHILE  
  
	EXEC mdm.udpSystemEventSave @User_ID=@User_ID,@Version_ID=@Version_ID,@EventName='ValidateModel',@EventStatus_ID=@EventStatus_NotRunning  
  
    IF @Status_ID = 3 --Commit  
       BEGIN  
          SET @ValidationLogViewName = mdm.udfGetValidationLogViewName(@Model_ID);  
          SET @SQL = N'  
          IF EXISTS(SELECT 1 FROM [mdm].' + QUOTENAME(@ValidationLogViewName) + N' WHERE Version_ID = @Version_ID)  
          BEGIN  
            SET @ValidationIssuesExist = 1;  
          END  
          ELSE  
          BEGIN  
            SET @ValidationIssuesExist = 0;  
          END  
          ';  
          EXEC sp_executesql @SQL, N'@Version_ID INT, @ValidationIssuesExist BIT OUTPUT',   
                                     @Version_ID,     @ValidationIssuesExist OUTPUT;  
  
          IF @ValidationIssuesExist = 0  
          BEGIN  
                -- Get current values (to prevent them from being overwritten with null)  
                DECLARE   
                     @VersionFlag_ID INT  
                SELECT   
                     @VersionFlag_ID = VersionFlag_ID  
                FROM mdm.tblModelVersion  
                WHERE ID = @Version_ID;  
  
                EXEC mdm.udpVersionSave   
                    @User_ID = @User_ID,   
                    @Model_ID = @Model_ID,  
                    @Version_ID = @Version_ID,  
                    @CurrentVersion_ID = NULL,   
                    @Status_ID = 3/*Committed*/,   
                    @VersionFlag_ID = @VersionFlag_ID,  
                    @AllowVersionCommit = 1;  
          END  
       END  
  
    SET NOCOUNT OFF  
END --proc
go

