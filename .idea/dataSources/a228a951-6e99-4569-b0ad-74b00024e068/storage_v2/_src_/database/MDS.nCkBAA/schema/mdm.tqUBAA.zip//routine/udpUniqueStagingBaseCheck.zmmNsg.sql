/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpUniqueStagingBaseCheck  
(  
	@StagingBase			NVARCHAR(60),  
	@IsUnique				BIT OUTPUT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
	SET NOCOUNT ON  
	  
	-- If the StagingBase is unique return 1. Otherwise return 0.   
	Set @StagingBase = LTRIM(RTRIM(@StagingBase));  
		  
	IF EXISTS (SELECT 1 FROM mdm.tblEntity WHERE StagingBase = @StagingBase) BEGIN  
		SET @IsUnique = 0;  
	END;   
	ELSE BEGIN  
		SET @IsUnique = 1;  
	END; -- IF  
  
	SET NOCOUNT OFF  
END --proc
go

