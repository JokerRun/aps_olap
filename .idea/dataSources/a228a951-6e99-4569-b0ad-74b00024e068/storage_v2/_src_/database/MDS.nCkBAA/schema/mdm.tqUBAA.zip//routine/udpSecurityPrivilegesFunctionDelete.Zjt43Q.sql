/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
*/  
CREATE PROCEDURE mdm.udpSecurityPrivilegesFunctionDelete  
(  
    @SystemUser_ID  INT,  
    @Function_MUID  UNIQUEIDENTIFIER,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    -- There must be at least one principal that has Super User functional permission, so  
    -- return an error when trying to delete the last one.  
  
    --Start transaction, being careful to check if we are nested.  
    DECLARE @TranCounter INT = @@TRANCOUNT;  
    IF @TranCounter > 0  
    BEGIN  
        SAVE TRANSACTION TX;  
    END ELSE  
    BEGIN  
        BEGIN TRANSACTION;  
    END;  
  
    BEGIN TRY  
  
        DECLARE   
             @FunctionalPrivilege_SuperUser TINYINT = 6  
            ,@DeletedFunctional_ID          TINYINT;  
          
        SELECT @DeletedFunctional_ID = FunctionalPrivilege_ID   
        FROM mdm.tblSecurityRoleAccessFunctional   
        WHERE MUID = @Function_MUID;  
              
        IF (@DeletedFunctional_ID = @FunctionalPrivilege_SuperUser)  
        BEGIN  
            -- Only SuperUsers can delete a SuperUser permission. Note: That the user performing the operation has at least Security functional privilege should have been verified before calling this sproc.  
            IF NOT EXISTS (  
                SELECT 1   
                FROM mdm.udfSecurityUserFunctionList(@SystemUser_ID)   
                WHERE Function_ID = @FunctionalPrivilege_SuperUser)   
            BEGIN  
                RAISERROR('MDSERR500067|The Super User function can only be granted or revoked by a user that already has that function.', 16, 1);  
                RETURN;  
            END;              
        END;  
  
        -- Delete the specified permission assignment.  
        DELETE  
        FROM mdm.tblSecurityRoleAccessFunctional  
        WHERE MUID = @Function_MUID  
  
        IF (@DeletedFunctional_ID = @FunctionalPrivilege_SuperUser)  
        BEGIN  
            -- A Super User permission was deleted. Ensure it wasn't the last one.  
            IF NOT EXISTS (SELECT 1 FROM mdm.tblSecurityRoleAccessFunctional WHERE FunctionalPrivilege_ID = @FunctionalPrivilege_SuperUser)  
            BEGIN  
                 -- Raise an error.  
                RAISERROR(N'MDSERR500053|The function privilege cannot be deleted. At least one principal must have the Super User function.', 16, 1);  
                RETURN;  
            END;  
        END;  
  
        -- Commit the transaction  
        IF @TranCounter = 0  
        BEGIN  
            COMMIT TRANSACTION;  
        END;  
  
    END TRY  
    --Compensate as necessary  
    BEGIN CATCH  
  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        IF @TranCounter = 0 ROLLBACK TRANSACTION;  
        ELSE IF XACT_STATE() <> -1 ROLLBACK TRANSACTION TX;  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
  
        RETURN;  
  
    END CATCH;  
  
    SET NOCOUNT OFF;  
END --proc
go

