/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Returns whether the given user is allowed to execute operations pertaining to the given functional permission.  
Always true for users with super user functional permission.  
  
*/  
CREATE FUNCTION mdm.udfSecurityUserFunctionIsAllowed  
(  
     @User_ID  INT  
    ,@Function TINYINT  
)  
RETURNS BIT  
/*WITH SCHEMABINDING*/    
AS  
BEGIN  
    DECLARE   
         @Function_SuperUser TINYINT = 6  
        ,@Function_Explorer  TINYINT = 1  
        ,@IsAllowed BIT = 0;  
  
    IF EXISTS (  
        SELECT 1   
        FROM mdm.udfSecurityUserFunctionList(@User_ID)   
        WHERE  Function_ID IN (@Function_SuperUser, @Function)  
            OR @Function = @Function_Explorer) -- The existence of any functional privilege infers Explorer privilege.  
    BEGIN  
        SET @IsAllowed = 1;  
    END;  
  
    RETURN @IsAllowed;  
END
go

