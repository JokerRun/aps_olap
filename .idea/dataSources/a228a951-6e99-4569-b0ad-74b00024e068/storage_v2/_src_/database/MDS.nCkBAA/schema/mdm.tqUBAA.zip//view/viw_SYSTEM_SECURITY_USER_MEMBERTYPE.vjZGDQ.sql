/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    SELECT * FROM mdm.viw_SYSTEM_SECURITY_USER_MEMBERTYPE ORDER BY User_ID, Entity_ID, ID  
  
    Rank    Permission  
----    ---------------------  
1       Model Admin - ALL  
2       Entity Deny - Deny  
3       No explicit permission, Entity not inferred permission - Entity permission  
4       MemberType permission, could be explicit permission or null.  
  
*/  
CREATE VIEW mdm.viw_SYSTEM_SECURITY_USER_MEMBERTYPE  
/*WITH SCHEMABINDING*/  
AS  
WITH allPermissions AS (  
    SELECT  
        User_ID,  
        MAX(IsAdmin) IsAdmin,  
        MAX(IsSyncTarget) IsSyncTarget,  
        Entity_ID,  
        ID,  
        MIN(Privilege_ID) Privilege_ID,  
        SUM(Distinct(AccessPermission & 0x1)) +  
        SUM(Distinct(AccessPermission & 0x2)) +  
        SUM(Distinct(AccessPermission & 0x4)) AS AccessPermission  
    FROM  
        (  
        SELECT  
            tEntSec.User_ID,  
            tEntSec.ID AS Entity_ID,  
            CASE tEntSec.Privilege_ID WHEN 5 /*Admin*/ THEN 1 ELSE 0 END IsAdmin,  
            tEntSec.IsSyncTarget,  
            tMbrTyp.MemberType_ID AS ID,  
            Privilege_ID =  
                CASE  
                    WHEN tEntSec.Privilege_ID = 1 /*Deny*/ THEN 1 /*Deny*/  
                    WHEN tEntSec.Privilege_ID = 5 /*Admin*/ THEN 4 /*Access*/  
                    -- No explicit permission on membertype and non-inferred permission on entity, use entity permission  
                    WHEN ISNULL(tHasExplicit.HasExplicit, 0) != 1 AND tEntSec.Privilege_ID <> 99  
                        THEN tEntSec.Privilege_ID  
                    ELSE tExp.MemberType_PrivilegeID -- use Member Type permission  
                END,  
            AccessPermission =  
                CASE  
                    WHEN tEntSec.Privilege_ID = 1  /*Deny*/ THEN NULL /*None*/  
                    WHEN tEntSec.IsSyncTarget = 1 THEN 0 -- An entity that is the target of a sync relationship is read-only  
                    WHEN tEntSec.Privilege_ID = 5 /*Admin*/ THEN 7 /*All*/  
                    WHEN ISNULL(tHasExplicit.HasExplicit, 0) != 1 AND tEntSec.Privilege_ID <> 99  
                        THEN tEntSec.AccessPermission  
                    ELSE tExp.MemberType_AccessPermission -- use Member Type permission  
                END  
        FROM  
            mdm.viw_SYSTEM_SCHEMA_ENTITY_MEMBERTYPE tMbrTyp  
            -- Check entity security  
            INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ENTITY tEntSec  
            ON tMbrTyp.Entity_ID = tEntSec.ID  
  
            LEFT JOIN mdm.viw_SYSTEM_SECURITY_USER tExp  
             ON tMbrTyp.Entity_ID = tExp.Entity_ID  
                 AND tMbrTyp.MemberType_ID = tExp.MemberType_ID  
                 AND tEntSec.User_ID = tExp.User_ID  
  
             -- Check if memberType has explicit permission  
            LEFT JOIN (  
                SELECT Entity_ID, MemberType_ID, Role_ID, User_ID, MAX(MemberType_IsExplicit) as HasExplicit  
                FROM mdm.viw_SYSTEM_SECURITY_USER  
                GROUP BY Entity_ID, MemberType_ID, Role_ID, User_ID  
            ) AS tHasExplicit  
            ON tMbrTyp.Entity_ID = tHasExplicit.Entity_ID AND tMbrTyp.MemberType_ID = tHasExplicit.MemberType_ID AND tExp.User_ID = tHasExplicit.User_ID AND tExp.Role_ID = tHasExplicit.Role_ID  
        ) tSec  
    WHERE  
        Privilege_ID IS NOT NULL  
    GROUP BY  
        User_ID,  
        Entity_ID,  
        ID  
)  
SELECT  
    [User_ID],  
    IsAdmin,  
    IsSyncTarget,  
    Entity_ID,  
    ID,  
    Privilege_ID,  
    CASE Privilege_ID WHEN 4 /*Access*/ THEN AccessPermission ELSE NULL END AccessPermission  
FROM allPermissions
go

