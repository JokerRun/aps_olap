/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Returns all users that have the given functional permission.  
  
*/  
CREATE FUNCTION mdm.udfSecurityGetUsersByFunction   
(  
    @FunctionalPrivilege_ID TINYINT = NULL  
)  
RETURNS @UserId TABLE (ID INT PRIMARY KEY)  
/*WITH SCHEMABINDING*/  
AS  
BEGIN  
    INSERT INTO @UserId  
    SELECT DISTINCT [User_ID]  
    FROM viw_SYSTEM_SECURITY_USER_FUNCTION  
    WHERE   Function_ID = @FunctionalPrivilege_ID  
    RETURN;  
END
go

