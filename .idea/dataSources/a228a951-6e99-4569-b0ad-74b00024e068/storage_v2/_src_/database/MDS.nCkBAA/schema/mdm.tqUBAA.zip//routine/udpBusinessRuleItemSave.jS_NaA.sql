/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpBusinessRuleItemSave  
(  
    @User_ID                        INT = NULL,    
    @SaveMode                       TINYINT = 0, -- 0 = Create, 1 = Clone, 2 = Update    
    @BRLogicalOperatorGroup_MUID    UNIQUEIDENTIFIER = NULL OUTPUT,    -- required for Conditions, optional for Actions (will be found/created if not provided)    
    @Rule_MUID                      UNIQUEIDENTIFIER = NULL,    
    @MemberType_ID                  TINYINT = NULL,    
    @ItemType_ID                    INT = NULL,    
    @ItemCategory                   TINYINT  = NULL, -- 1 Condition 2 ThenAction 3 ElseActioin    
    @AnchorName                     NVARCHAR(250),    
    @AnchorAttribute_MUID           UNIQUEIDENTIFIER = NULL,    -- required    
    @Sequence                       INT = NULL,    
    @ItemText                       NVARCHAR(MAX) = NULL,    
    @ArgumentMuids                  XML = NULL, -- must contain Muids of all tblBRItemProperties rows belonging to the BRItem    
    @MUID                           UNIQUEIDENTIFIER = NULL OUTPUT, -- Input (Clone or Update) and output    
    @ID                             INT = NULL OUTPUT, -- Output only    
    @BypassUdsValidation            BIT = 0,  
    @CorrelationID                  UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability    
)    
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN    
    SET NOCOUNT ON    
    
    DECLARE    
        @Rule_ID                        INT,    
        @BRLogicalOperatorGroup_ID      INT,    
        @BRItemAppliesTo_ID             INT,    
        @AnchorDataTypeID               INT,    
        @AnchorID                       INT,    
        @AnchorAttributeType            INT,    
        @Entity_ID                      INT,    
    
        @ItemType_Workflow              INT = 32, -- From tblBRItemType.ID    
    
        @Model_Permission               INT,    
    
        @Permission_Admin               INT = 5,    
    
        @SaveMode_Create                TINYINT = 0,    
        @SaveMode_Clone                 TINYINT = 1,    
        @SaveMode_Update                TINYINT = 2,    
    
        @MemberType_Leaf                TINYINT = 1,    
        @MemberType_Consolidated        TINYINT = 2,    
    
        @GuidEmpty                      UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER);    
    
    SELECT    
        @BRLogicalOperatorGroup_MUID = NULLIF(@BRLogicalOperatorGroup_MUID, @GuidEmpty),    
        @Rule_MUID = NULLIF(@Rule_MUID, @GuidEmpty),    
        @AnchorName = NULLIF(LTRIM(RTRIM(@AnchorName)), N''),    
        @AnchorAttribute_MUID = NULLIF(@AnchorAttribute_MUID, @GuidEmpty),    
        @ItemText = NULLIF(LTRIM(RTRIM(@ItemText)), N''),    
        @MUID = NULLIF(@MUID, @GuidEmpty),    
        @ID = NULL;    
    
    IF @SaveMode = @SaveMode_Clone    
    BEGIN    
        IF @MUID IS NOT NULL AND EXISTS (SELECT 1 FROM mdm.tblBRItem WHERE MUID = @MUID)    
        BEGIN    
            SET @SaveMode = @SaveMode_Update;    
        END    
        ELSE    
        BEGIN    
            SET @SaveMode = @SaveMode_Create;    
        END    
    END    
    
    IF @SaveMode = @SaveMode_Create    
    BEGIN    
        SET @MUID = COALESCE(@MUID, NEWID());    
    END    
    
    IF @SaveMode = @SaveMode_Update    
    BEGIN    
        -- made sure a MUID of an existing row was given    
        IF @MUID IS NULL OR NOT EXISTS (SELECT 1 FROM mdm.tblBRItem WHERE MUID = @MUID)    
        BEGIN    
            RAISERROR('MDSERR400001|The Update operation failed. The MUID was not found.', 16, 1);    
            RETURN;    
        END    
    END    
    
    SELECT    
        @Rule_ID = ID,    
        @Entity_ID = [Entity_ID]    
    FROM mdm.tblBRBusinessRule    
    WHERE MUID = @Rule_MUID    
    
    IF @Rule_ID IS NULL    
    BEGIN    
        RAISERROR('MDSERR400005|The business rule MUID is not valid.', 16, 1);    
        RETURN    
    END    
    
    SELECT @Model_Permission = m.Privilege_ID    
    FROM mdm.viw_SYSTEM_SECURITY_USER_MODEL m    
    INNER JOIN mdm.tblEntity en ON m.ID = en.Model_ID    
    WHERE [User_ID] = @User_ID AND en.ID = @Entity_ID;    
    
    IF @Model_Permission <> @Permission_Admin    
    BEGIN    
        RAISERROR('MDSERR120003|The user does not have permission or the object ID is not valid.', 16, 1);    
        RETURN;    
    END    
    
    -- Getanchorattribute    
    IF @ItemType_ID = 34 -- User defined script    
    BEGIN    
        IF @BypassUdsValidation = 0 And mdm.udfScriptExists(@AnchorName, (CASE WHEN @ItemCategory = 1 THEN 1 ELSE 2 END) , 'usr') = 0    
        BEGIN    
            IF @ItemCategory = 1    
            RAISERROR('MDSERR400060|Could not find SQL Function |%s| with return type BIT in usr schema.', 16, 1, @AnchorName);    
            ELSE    
            RAISERROR('MDSERR400061|Could not find SQL Stored Procedure |%s| with the first parameter type as mdm.MemberId and the second parameter type as string in usr schema.', 16, 1, @AnchorName);    
        END    
    END    
    ELSE    
    BEGIN    
        -- get AnchorAttribute properties    
        SELECT    
            @AnchorID = Attribute_ID,    
            @AnchorDataTypeID = Attribute_DataType_ID,    
            @AnchorAttributeType = Attribute_Type_ID    
        FROM mdm.viw_SYSTEM_SCHEMA_ATTRIBUTES vAtt    
        WHERE vAtt.Attribute_MUID = @AnchorAttribute_MUID    
            OR (vAtt.Attribute_Name = @AnchorName AND  vAtt.[Entity_ID] = @Entity_ID)    
    
        IF (@AnchorID IS NULL)    
        BEGIN    
            RAISERROR('MDSERR400003|The attribute reference is not valid. The attribute was not found.', 16, 1);    
            RETURN    
        END    
    
        -- check compatibility between operation and anchor    
        IF mdm.udfBusinessRuleIsItemTypeCompatible(@AnchorAttributeType, @AnchorDataTypeID, @ItemType_ID) <> 1    
        BEGIN    
            RAISERROR('MDSERR400004|The operation is not supported for the attribute type.', 16, 1);    
            RETURN    
        END    
    END    
    
    -- get @BRLogicalOperatorGroup_ID    
    IF (@BRLogicalOperatorGroup_MUID IS NOT NULL)    
    BEGIN    
        SELECT @BRLogicalOperatorGroup_ID = ID FROM mdm.tblBRLogicalOperatorGroup WHERE MUID = @BRLogicalOperatorGroup_MUID;    
    END    
    IF (@BRLogicalOperatorGroup_ID IS NULL AND @ItemCategory <> 1)    
    BEGIN    
        -- search for existing Action operator group row    
        SELECT    
            @BRLogicalOperatorGroup_ID = logp.ID,    
            @BRLogicalOperatorGroup_MUID = logp.MUID    
        FROM mdm.tblBRLogicalOperatorGroup logp    
        INNER JOIN mdm.tblBRItem it ON logp.ID = it.BRLogicalOperatorGroup_ID    
            AND logp.BusinessRule_ID = @Rule_ID    
            AND logp.Parent_ID IS NULL -- no parent    
            AND logp.LogicalOperator_ID = 1 --AND operator    
        INNER JOIN mdm.tblBRItemTypeAppliesTo itat ON it.BRItemAppliesTo_ID = itat.ID    
        INNER JOIN mdm.tblListRelationship lr ON itat.ApplyTo_ID = lr.ID    
            AND lr.Parent_ID = 2 -- Action    
        ORDER BY logp.ID    
    
        IF (@BRLogicalOperatorGroup_ID IS NULL)    
        BEGIN    
        SET @BRLogicalOperatorGroup_MUID = NEWID()    
            -- couldn't find existing row, so add one    
            INSERT INTO mdm.tblBRLogicalOperatorGroup (    
                LogicalOperator_ID,    
                BusinessRule_ID,    
                [Sequence],    
                MUID    
            )    
            VALUES (    
                1,-- 1 = AND Operator    
                @Rule_ID,    
                1,    
                @BRLogicalOperatorGroup_MUID    
            )    
            SET @BRLogicalOperatorGroup_ID = SCOPE_IDENTITY();    
        END    
    END    
    
    IF @BRLogicalOperatorGroup_ID IS NULL    
    BEGIN    
        RAISERROR('MDSERR400006|The logical operator group MUID is not valid.', 16, 1);    
        RETURN    
    END    
    
    SET @BRItemAppliesTo_ID = mdm.udfBusinessRuleGetBRItemAppliesToID(@ItemType_ID, @ItemCategory, @MemberType_ID)    
    IF (@BRItemAppliesTo_ID IS NULL) BEGIN    
        RAISERROR('MDSERR400007|The operation is not valid for the condition or action.', 16, 1);    
        RETURN    
    END    
    
    -- If the rule item is Workflow, ensure that no other items within the same rule are Workflow.    
    
    IF @ItemType_ID = @ItemType_Workflow    
        AND EXISTS(    
            SELECT 1    
            FROM mdm.tblBRItem i    
            LEFT JOIN mdm.tblBRItemTypeAppliesTo itat ON i.BRItemAppliesTo_ID = itat.ID    
            WHERE  i.BRLogicalOperatorGroup_ID = @BRLogicalOperatorGroup_ID -- All actions within the same rule will share the same logical operator group.    
                AND itat.BRItemType_ID = @ItemType_Workflow    
                AND (@MUID IS NULL OR i.MUID <> @MUID))    
    BEGIN    
        RAISERROR('MDSERR400041|A rule cannot contain more than one Workflow action.', 16, 1);    
        RETURN;    
    END;    
    
    IF @SaveMode = @SaveMode_Create    
    BEGIN    
        -- add row    
        INSERT INTO mdm.tblBRItem (    
            MUID,    
            BRLogicalOperatorGroup_ID,    
            BRItemAppliesTo_ID,    
            [Sequence],    
            ItemText,    
            AnchorName,    
            AnchorAttributeType    
        )    
        VALUES (    
            @MUID,    
            @BRLogicalOperatorGroup_ID,    
            @BRItemAppliesTo_ID,    
            @Sequence,    
            @ItemText,    
            @AnchorName,    
            @AnchorAttributeType    
        );    
    
        -- set output params    
        IF @@ERROR = 0    
        BEGIN    
            SET @ID = SCOPE_IDENTITY();    
        END    
    END    
    ELSE    
        BEGIN    
        -- delete unused arguments    
        DELETE FROM mdm.tblBRItemProperties    
        WHERE BRItem_ID = @ID    
            AND MUID NOT IN (    
                SELECT    
                DISTINCT am.MUID.value(N'.',N'UNIQUEIDENTIFIER') MUID    
                FROM @ArgumentMuids.nodes(N'//guid') am(MUID))    
    
        -- update row    
        UPDATE mdm.tblBRItem    
        SET BRLogicalOperatorGroup_ID = @BRLogicalOperatorGroup_ID,    
            BRItemAppliesTo_ID = @BRItemAppliesTo_ID,    
            [Sequence] = @Sequence,    
            ItemText = @ItemText,    
            AnchorName = @AnchorName,    
            AnchorAttributeType = @AnchorAttributeType    
        WHERE MUID = @MUID    
    
        -- set output params    
        IF @@ERROR = 0    
        BEGIN    
            SELECT @ID = ID FROM mdm.tblBRItem WHERE MUID = @MUID;    
        END    
    END    
    SET NOCOUNT OFF    
END --proc
go

