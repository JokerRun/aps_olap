/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    The procedure assumes 1 and only 1 record should exists in the table.  
  
    exec mdm.udpSystemSave @SchemaVersion = '10.50.166.1234'  
*/  
CREATE PROCEDURE mdm.udpSystemSave  
    @SchemaVersion NVARCHAR(250)=NULL,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
AS  
/*WITH*/  
BEGIN  
    SET NOCOUNT ON;  
  
    --Initialize output parameters and local variables  
    SELECT  
        @SchemaVersion = NULLIF(LTRIM(RTRIM(@SchemaVersion)), N'')  
  
    IF EXISTS(SELECT 1 FROM mdm.tblSystem)  
    BEGIN  
        BEGIN TRY  
  
                UPDATE mdm.tblSystem  
                 SET [SchemaVersion] = ISNULL(@SchemaVersion,[SchemaVersion])  
                  ,[LastChgUserID] = SYSTEM_USER  
                  ,[LastChgDTM] = GETUTCDATE()  
                 WHERE [ID] = (SELECT MAX([ID]) FROM mdm.tblSystem)  
  
            RETURN(0);  
  
        END TRY  
        --Compensate as necessary  
        BEGIN CATCH  
  
            -- Get error info.  
            DECLARE  
                @ErrorMessage NVARCHAR(4000),  
                @ErrorSeverity INT,  
                @ErrorState INT,  
                @ErrorNumber INT,  
                @ErrorLine INT,  
                @ErrorProcedure NVARCHAR(126);  
            EXEC mdm.udpGetErrorInfo  
                @ErrorMessage = @ErrorMessage OUTPUT,  
                @ErrorSeverity = @ErrorSeverity OUTPUT,  
                @ErrorState = @ErrorState OUTPUT,  
                @ErrorNumber = @ErrorNumber OUTPUT,  
                @ErrorLine = @ErrorLine OUTPUT,  
                @ErrorProcedure = @ErrorProcedure OUTPUT  
  
            SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
            RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
  
            RETURN(1);  
  
        END CATCH;  
    END  
    SET NOCOUNT OFF;  
END;
go

