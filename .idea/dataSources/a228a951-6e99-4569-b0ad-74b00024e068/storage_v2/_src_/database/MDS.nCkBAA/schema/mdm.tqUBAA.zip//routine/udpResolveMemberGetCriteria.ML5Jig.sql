/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Convert MemberGetCriteria into SearchTerm that is injection safe.  
  
*/  
CREATE PROCEDURE [mdm].[udpResolveMemberGetCriteria]  
(  
    @SearchTable    mdm.MemberGetCriteria READONLY,  
    @SearchTerm     NVARCHAR(MAX) OUTPUT,  
    @SortTerm       NVARCHAR(MAX) OUTPUT  
)  
AS  
BEGIN  
    IF EXISTS (SELECT 1 FROM @SearchTable)  
    BEGIN  
        DECLARE @maxFilterCount     INT,  
                @groupID            INT,  
                @schemaName         SYSNAME,  
                @objectName         SYSNAME,  
                @fullObjectName     NVARCHAR(MAX),  
                @operator           NVARCHAR(15),  
                @operatorParameters NVARCHAR(MAX),  
                @filterValue        NVARCHAR(MAX),  
                @filterClause       NVARCHAR(MAX),  
                @currentGroup       INT,  
                @CurrentFilterId    INT,  
                @regexMask          INT = mdq.RegexMask(1, 1, 1, 0, 0, 0, 1); --CultureInvariant, ExplicitCapture, IgnoreCase, SingleLine (71)  
  
        --This table variable is used to keep track of unique filters in the search table. A set of records  
        --in the search table that belong to the same group (by way of having the same group ID) are considered  
        --one unique filter and are processed as such. However, records having a group ID of 0 are each considered  
        --their own separate unique filter. For example a search table like:  
        --INSERT INTO @SearchTable(ID,  SchemaName, ObjectName,     Operator,   OperatorParameters, GroupId,    [Value])  
        --                  values(1,   N'',        N'Name',        N'=',       N'',                0,          N'NewMember'),  
        --                        (2,   N'',        N'ModelName',   N'LIKE',    N'',                0,          N'%Premium'),  
        --                        (3,   N'',        N'SubCategory', N'IN',      N'',                1,          N'12'),  
        --                        (4,   N'',        N'SubCategory', N'IN',      N'',                1,          N'14'),  
        --                        (5,   N'',        N'SubCategory', N'IN',      N'',                1,          N'31'),  
        --                        (6,   N'',        N'SubCategory', N'IN',      N'',                1,          N'2'),  
        --                        (7,   N'',        N'Color',       N'IN',      N'',                2,          N'Silver'),  
        --                        (8,   N'',        N'Color',       N'IN',      N'',                2,          N'Yellow')  
        --  
        --would amount to 4 unique filters  
        DECLARE @UniqueFilters TABLE(FilterId INT PRIMARY KEY, Processed BIT DEFAULT 0);  
  
        SET @currentGroup = 0;  
        SET @SearchTerm = N'';  
  
        --Get filters with no GroupId in as unique filter  
        INSERT INTO @UniqueFilters(FilterId)  
        SELECT ID FROM @SearchTable WHERE GroupId = 0;  
  
        --Pick out the lowest ID for a group and stuff it into UniqueFilters  
        INSERT INTO @UniqueFilters(FilterId)  
        SELECT MIN(ID) FROM @SearchTable  
        WHERE GroupId <> 0  
        GROUP BY GroupId;  
  
        --Count out the total number of unique filters  
        SELECT @maxFilterCount = COUNT(1) from @UniqueFilters;  
  
        --Restrict the number of filters supported to a maximum of 100  
        IF @maxFilterCount > 100  
        BEGIN  
            RAISERROR('MDSERR100046|A maximum of 100 filter criteria are supported.', 16, 1);  
            RETURN;  
        END  
  
        --Build filter clause using table param for joins  
        WHILE EXISTS(SELECT 1 FROM @UniqueFilters WHERE Processed = 0)  
        BEGIN  
            SET @filterClause = NULL;  
            SELECT TOP 1  
                 @CurrentFilterId = UF.FilterId  
                ,@operator = UPPER(LTRIM(RTRIM(COALESCE(ST.Operator, N''))))  
                ,@filterValue = ST.[Value]  
                ,@groupID = ST.GroupId  
                ,@schemaName = LTRIM(RTRIM(COALESCE(ST.SchemaName, N'')))  
                ,@objectName = LTRIM(RTRIM(COALESCE(ST.ObjectName, N'')))  
                ,@operatorParameters = UPPER(LTRIM(RTRIM(COALESCE(ST.OperatorParameters, N''))))  
            FROM @UniqueFilters UF  
            INNER JOIN @SearchTable ST ON ST.ID = UF.FilterId  
            WHERE UF.Processed = 0;  
  
            --Validate the filter value if it is non-null  
            IF @filterValue IS NOT NULL  
            BEGIN  
                --Filter values larger than 255 chars are not allowed  
                IF (LEN(@filterValue) > 255)  
                    BEGIN  
                        RAISERROR('MDSERR100045|Filter criteria values can not be larger than 255 characters.', 16, 1);  
                        RETURN;  
                    END  
  
                --Replace any single quotes with double quotes to avoid SQL injection  
                SET @filterValue = REPLACE(@filterValue, '''', '''''');  
            END  
  
            SET @fullObjectName = CASE WHEN LEN(@schemaName) > 0 THEN QUOTENAME(@schemaName) + N'.' ELSE N'T.' END + QUOTENAME(@objectName);  
  
            DECLARE @isOperatorNegated  BIT = CASE WHEN @operator LIKE N'NOT %' THEN 1 ELSE 0 END,  
                    @isOperatorFuzzy    BIT = CASE WHEN @operator IN  
                        (N'NOT MATCH' COLLATE Latin1_General_CI_AS,  
                         N'MATCH'     COLLATE Latin1_General_CI_AS  
                        )  THEN 1 ELSE 0 END,  
                    @isOperatorRegex    BIT = CASE WHEN @operator IN  
                        (N'NOT REGEX' COLLATE Latin1_General_CI_AS,  
                         N'REGEX'     COLLATE Latin1_General_CI_AS  
                        )  THEN 1 ELSE 0 END,  
                    @isOperatorIsNull   BIT = CASE WHEN @operator IN  
                        (N'IS NOT NULL' COLLATE Latin1_General_CI_AS,  
                         N'IS NULL'     COLLATE Latin1_General_CI_AS  
                        )  THEN 1 ELSE 0 END,  
                    @isOperatorIn       BIT = CASE WHEN @operator IN  
                        (N'NOT IN' COLLATE Latin1_General_CI_AS,  
                         N'IN'     COLLATE Latin1_General_CI_AS  
                        )  THEN 1 ELSE 0 END  
            DECLARE @isOperatorValid    BIT = CASE WHEN @operator IN (  
                             N'='  
                            ,N'<>'  
                            ,N'LIKE'  
                            ,N'NOT LIKE'  
                            ,N'>'  
                            ,N'<'  
                            ,N'>='  
                            ,N'<=')  
                            OR @isOperatorFuzzy = 1  
                            OR @isOperatorRegex = 1  
                            OR @isOperatorIsNull = 1  
                            OR @isOperatorIn = 1  
                            THEN 1 ELSE 0 END;  
  
            IF (@isOperatorValid = 1  
                AND LEN(@fullObjectName) > 0  
                AND (@currentGroup <> @groupID OR @groupID = 0))  
            BEGIN  
                SET @currentGroup = @groupID;  
  
                IF (@isOperatorFuzzy = 1)  
                BEGIN  
  
                    -- do fuzzy match  
                    /*  
                     * Fuzzy matching requires operator parameters in this format: 'minSimilarity[ algorithm][ containmentBias]'  
                     *  
                     * minSimilarity: 0 <= value <= 1. Used by all algorithms.  
                     * algorithm:  
                     *      - 0 = Levenstein (default)  
                     *      - 1 = Jaccard  
                     *      - 2 = JaroWinkler  
                     *      - 3 = Longest Common Subsequence  
                     * lengthThreshold 0 <= value <= 1. Default = 0.62. Used only by Jaccard and Longest Common Subsequence algorithms.  
                     *  
                     * Example: '0.5 1 0.32' means use Jaccard algorithm with minSimilarity = 0.5 and containmentBias = 0.32  
                     */  
                    DECLARE @Levenstein  NVARCHAR(1)              = N'0',  
                            @Jaccard     NVARCHAR(1)              = N'1',  
                            @JaroWinkler NVARCHAR(1)              = N'2',  
                            @LongestCommonSubsequence NVARCHAR(1) = N'3';  
                    DECLARE @defaultAlgorithm NVARCHAR(1) = @Levenstein,  
                            @defaultLengthThreshold NVARCHAR(10) = N'0.62';  
  
                    DECLARE @minSimilarity NVARCHAR(100),  
                            @algorithm NVARCHAR(1),  
                            @lengthThreshold NVARCHAR(100)  
  
                    DECLARE @charIndex INT = CHARINDEX(N' ', @operatorParameters);  
                    IF @charIndex = 0  
                    BEGIN  
                        SET @minSimilarity = CONVERT(NVARCHAR(100), @operatorParameters)  
                    END ELSE  
                    BEGIN  
                        SET @minSimilarity = SUBSTRING(@operatorParameters, 1, @charIndex - 1);  
                        SET @operatorParameters = LTRIM(SUBSTRING(@operatorParameters, @charIndex, LEN(@operatorParameters)));  
                        SET @charIndex = CHARINDEX(N' ', @operatorParameters);  
                        IF @charIndex = 0  
                        BEGIN  
                            SET @algorithm = CONVERT(NVARCHAR(1), @operatorParameters);  
                        END ELSE  
                        BEGIN  
                            SET @algorithm = SUBSTRING(@operatorParameters, 1, @charIndex - 1);  
                            SET @lengthThreshold = LTRIM(SUBSTRING(@operatorParameters, @charIndex, LEN(@operatorParameters)));  
                        END;  
                    END;  
  
                    SET @algorithm = COALESCE(@algorithm, @defaultAlgorithm);  
                    SET @lengthThreshold = COALESCE(@lengthThreshold, @defaultLengthThreshold);  
  
                    -- validate parameters  
                    IF (ISNUMERIC(@minSimilarity) = 0)  
                    BEGIN  
                        RAISERROR('MDSERR100032|You must provide a valid similarity value for the fuzzy match operation.', 16, 1);  
                        RETURN;  
                    END  
                    IF (@algorithm NOT IN (@Levenstein, @Jaccard, @JaroWinkler, @LongestCommonSubsequence))  
                    BEGIN  
                        RAISERROR('MDSERR100033|You must provide a valid fuzzy match algorithm code.', 16, 1);  
                        RETURN;  
                    END  
                    IF (ISNUMERIC(@lengthThreshold) = 0)  
                    BEGIN  
                        RAISERROR('MDSERR100034|You must provide a valid containment bias value.', 16, 1);  
                        RETURN;  
                    END  
  
                    SET @filterClause = N'mdq.Similarity(' + @fullObjectName  
                        + N', N''' + @filterValue  
                        + N''', ' + @algorithm  
                        + N', ' + @lengthThreshold  
                        + N', '  
                        + CASE @isOperatorNegated  
                                WHEN 0 THEN @minSimilarity  
                                ELSE N'0.0'  
                        END --case  
                        + N')';  
  
                    --Add the match expression to the custom ORDER BY clause  
                    SET @SortTerm =  
                        CASE  
                            WHEN @SortTerm IS NULL THEN N''  
                            ELSE @SortTerm + N' + '  
                        END  
                        + N'  
                        '  
                        + CASE @isOperatorNegated  
                            WHEN 0 THEN @filterClause  
                            WHEN 1 THEN N'(1.0 - ' + @filterClause + N')'  
                        END; --case  
  
                    --Complete the rest of the predicate  
                    SET @filterClause =  
                        N'('  
                        + @filterClause  
                        + CASE @isOperatorNegated  
                            WHEN 0 THEN N' >= '  
                            WHEN 1 THEN N' < '  
                        END --case  
                        + @minSimilarity  
                        + N')';  
  
                END  
                ELSE IF (@isOperatorRegex = 1)  
                BEGIN  
  
                    -- do regular expression match  
  
                    -- This if statement is commented out because, for now, the desired behavior for an invalid  
                    -- regular expression is to allow an exception to be thrown when it is parsed.  
                    --IF (mdq.RegexIsValid(@filterValue) = 1)  
                    --BEGIN  
                    SET @filterClause = N'(mdq.RegexIsMatch(' + @fullObjectName + N', N''' + @filterValue + N''', ' + CONVERT(NVARCHAR(MAX), @regexMask) + N') '  
                    + CASE @isOperatorNegated  
                        WHEN 0 THEN N'='  
                        WHEN 1 THEN N'<>'  
                        END  
                    + N' 1)';  
                    --END  
                END  
                ELSE IF (@isOperatorIsNull = 1)  
                    BEGIN  
                        SET @filterClause = @fullObjectName + N' ' + @operator;  
                    END  
                ELSE IF (@isOperatorIn = 1)  
                    BEGIN  
                        SET @filterClause = @fullObjectName + N' ' + @operator + N' (SELECT [Value] FROM @SearchTable WHERE GroupId = ' + CONVERT(NVARCHAR(100), @groupID) + N')';  
                    END  
                ELSE  
                    BEGIN  
                        SET @filterClause = @fullObjectName + N' ' + @operator + N' N''' + @filterValue + N'''';  
                    END  
  
                IF @filterClause IS NOT NULL  
                BEGIN  
                    IF LEN(@SearchTerm) <> 0  
                    BEGIN  
                        SET @SearchTerm = @SearchTerm + N'  
                            AND ';  
                    END; --if  
                    SET @SearchTerm = @SearchTerm + @filterClause;  
                END; --if filterclause is not null  
            END; --if  
  
            UPDATE @UniqueFilters  
            SET Processed = 1  
            WHERE FilterId = @CurrentFilterId;  
        END;    --WHILE EXISTS(SELECT * FROM @UniqueFilters WHERE Processed = 0)  
    END; --EXISTS in @SearchTerm  
      
    SET @SearchTerm = NULLIF(@SearchTerm, N'');  
  
    IF (@SortTerm IS NOT NULL)  
    BEGIN  
        SET @SortTerm = N'(' + @SortTerm + N') DESC'  
    END  
    ELSE BEGIN  
        SET @SortTerm = N'';  
    END;  
  
END
go

