/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    EXEC mdm.udpViewNamesGetByID 2,1  
*/  
CREATE PROCEDURE mdm.udpViewNamesGetByID  
(  
    @Model_ID               INT,  
    @Entity_ID              INT,  
    @DerivedHierarchy_ID    INT,  
    @ItemType_ID            TINYINT = 1, --1=ALL; 2=Collection views; 3=Hierarchy views  
    @CorrelationID          UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON  
  
    DECLARE  
         @SQL                   NVARCHAR(MAX)  
        ,@ItemType_All          TINYINT = 1  
        ,@ItemType_Collections  TINYINT = 2  
        ,@ItemType_Hierarchies  TINYINT = 3;  
  
    WITH allviews AS (  
        SELECT [Model_ID], [Entity_ID], [DerivedHierarchy_ID], ViewName  
        FROM  
        (  
            SELECT  
                tMod.ID [Model_ID],  
                tEnt.ID [Entity_ID],  
                NULL [DerivedHierarchy_ID],  
  
                --System views  
                CAST(CONCAT(N'viw_SYSTEM_', tMod.ID, N'_', tEnt.ID, N'_CHILDATTRIBUTES') AS SYSNAME)                                                                [ViewSystem_ChildAttributes],  
                CAST(CONCAT(N'viw_SYSTEM_', tMod.ID, N'_', tEnt.ID, N'_CHILDATTRIBUTES_EXP') AS SYSNAME)                                                            [ViewSystem_ChildAttributes_EXP],  
                CAST(CONCAT(N'viw_SYSTEM_', tMod.ID, N'_', tEnt.ID, N'_CHILDATTRIBUTES_HISTORY') AS SYSNAME)                                                        [ViewSystem_ChildAttributes_History],  
                CAST(CONCAT(N'viw_SYSTEM_', tMod.ID, N'_', tEnt.ID, N'_CHILDATTRIBUTES_PENDING') AS SYSNAME)                                                        [ViewSystem_ChildAttributes_Pending],  
                CAST(CASE WHEN tEnt.CollectionTable IS NOT NULL THEN CONCAT(N'viw_SYSTEM_', tMod.ID, N'_', tEnt.ID, N'_COLLECTIONATTRIBUTES') END AS SYSNAME)       [ViewSystem_CollectionAttributes],  
                CAST(CASE WHEN tEnt.CollectionTable IS NOT NULL THEN CONCAT(N'viw_SYSTEM_', tMod.ID, N'_', tEnt.ID, N'_COLLECTIONATTRIBUTES_EXP') END AS SYSNAME)   [ViewSystem_CollectionAttributes_EXP],  
                CAST(CASE WHEN tHir.ID IS NOT NULL THEN CONCAT(N'viw_SYSTEM_', tMod.ID, N'_', tEnt.ID, N'_LEVELS') END AS SYSNAME)                                  [ViewSystem_Levels],  
                CAST(CASE WHEN tHir.ID IS NOT NULL THEN CONCAT(N'viw_SYSTEM_', tMod.ID, N'_', tEnt.ID, N'_PARENTATTRIBUTES') END AS SYSNAME)                        [ViewSystem_ParentAttributes],  
                CAST(CASE WHEN tHir.ID IS NOT NULL THEN CONCAT(N'viw_SYSTEM_', tMod.ID, N'_', tEnt.ID, N'_PARENTATTRIBUTES_EXP') END AS SYSNAME)                    [ViewSystem_ParentAttributes_EXP],  
                CAST(CASE WHEN tHir.ID IS NOT NULL THEN CONCAT(N'viw_SYSTEM_', tMod.ID, N'_', tEnt.ID, N'_PARENTCHILD') END AS SYSNAME)                             [ViewSystem_ParentChild],  
                CAST(CASE WHEN tEnt.CollectionTable IS NOT NULL THEN CONCAT(N'viw_SYSTEM_', tMod.ID, N'_', tEnt.ID, N'_COLLECTIONPARENTCHILD') END AS SYSNAME)      [ViewSystem_CollectionParentChild]  
            FROM mdm.tblModel tMod  
            INNER JOIN mdm.tblEntity tEnt  
            ON tMod.ID = tEnt.Model_ID  
            LEFT JOIN mdm.tblHierarchy tHir  
            ON tEnt.ID = tHir.Entity_ID  
            LEFT JOIN mdm.tblDerivedHierarchy tDHir  
            ON tMod.ID = tDHir.Model_ID  
         ) AS p  
         UNPIVOT (  
                ViewName FOR ViewType IN ([ViewSystem_ChildAttributes], [ViewSystem_ChildAttributes_EXP], [ViewSystem_ChildAttributes_History], [ViewSystem_ChildAttributes_Pending],  
                [ViewSystem_CollectionAttributes], [ViewSystem_CollectionAttributes_EXP], [ViewSystem_Levels], [ViewSystem_ParentAttributes], [ViewSystem_ParentAttributes_EXP],  
                [ViewSystem_ParentChild], [ViewSystem_CollectionParentChild])  
        ) AS unpvt  
        UNION ALL  
        SELECT [Model_ID], [Entity_ID], [DerivedHierarchy_ID], ViewName  
        FROM  
        (  
            SELECT  
                tMod.ID [Model_ID],  
                NULL [Entity_ID],  
                tDHir.ID [DerivedHierarchy_ID],  
  
                --System views  
                CAST(CASE WHEN tDHir.ID IS NOT NULL THEN CONCAT(N'viw_SYSTEM_', tMod.ID, N'_', tDHir.ID, N'_PARENTCHILD_DERIVED') END AS SYSNAME)                   [ViewSystem_DerivedParentChild]  
            FROM mdm.tblModel tMod  
            INNER JOIN mdm.tblDerivedHierarchy tDHir  
            ON tMod.ID = tDHir.Model_ID  
         ) AS p  
         UNPIVOT (  
                ViewName FOR ViewType IN ([ViewSystem_DerivedParentChild])  
        ) AS unpvt  
        UNION ALL  
        SELECT [Model_ID], [Entity_ID], [DerivedHierarchy_ID], ViewName  
        FROM  
        (  
            SELECT  
                ID [Model_ID] ,  
                NULL [Entity_ID],  
                NULL [DerivedHierarchy_ID],  
                CAST(CONCAT(N'viw_SYSTEM_', ID, N'_ISSUE_VALIDATION') AS SYSNAME) [ISSUE_VALIDATION],  
                CAST(CONCAT(N'viw_SYSTEM_', ID, N'_TRANSACTIONS') AS SYSNAME) [TRANSACTIONS],  
                CAST(CONCAT(N'viw_SYSTEM_', ID, N'_TRANSACTIONS_ANNOTATIONS') AS SYSNAME) [TRANSACTIONS_ANNOTATIONS],  
                CAST(CONCAT(N'viw_SYSTEM_', ID, N'_USER_VALIDATION') AS SYSNAME) [USER_VALIDATION]  
            FROM mdm.tblModel  
        ) AS p  
        UNPIVOT (  
                ViewName FOR ViewType IN ([ISSUE_VALIDATION], [TRANSACTIONS], [TRANSACTIONS_ANNOTATIONS], [USER_VALIDATION])  
        ) AS unpvt  
    )  
    SELECT DISTINCT ViewName  
    FROM allviews  
    WHERE ((Model_ID IS NULL AND @Model_ID IS NULL) OR Model_ID = @Model_ID)  
        AND (([Entity_ID] IS NULL AND @Entity_ID IS NULL) OR [Entity_ID] = @Entity_ID)  
        AND (([DerivedHierarchy_ID] IS NULL AND @DerivedHierarchy_ID IS NULL) OR [DerivedHierarchy_ID] = @DerivedHierarchy_ID)  
        AND ((@ItemType_ID = @ItemType_All)  
            OR (@ItemType_ID = @ItemType_Hierarchies AND ViewName NOT LIKE N'%CHILDATTRIBUTES%')  
            OR (@ItemType_ID = @ItemType_Collections AND ViewName LIKE N'%COLLECTION%'))  
  
    SET NOCOUNT OFF  
END --proc
go

