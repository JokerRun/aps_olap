/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpEntityMemberChangesetsGet  
(  
    @User_ID                INT,  
    @Model_Name             NVARCHAR(50) = NULL,  
    @Model_MUID             UNIQUEIDENTIFIER = NULL,  
    @Entity_Name            NVARCHAR(50) = NULL,  
    @Entity_MUID            UNIQUEIDENTIFIER= NULL,  
    @Version_Name           NVARCHAR(50) = NULL,  
    @Version_MUID           UNIQUEIDENTIFIER = NULL,  
    @Changeset_Name         NVARCHAR(50) = NULL,  
    @Changeset_MUID         UNIQUEIDENTIFIER = NULL,  
    @SortColumn_Name        NVARCHAR(128) = NULL,  
    @SortDirection          NVARCHAR(4) = NULL,  
    @ChangesetStatus        TINYINT = NULL,  
    @CorrelationID          UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
  
    DECLARE @GuidEmpty                  UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER),  
            @Model_ID                   INT,  
            @Entity_ID                  INT,  
            @Version_ID                 INT,  
  
            @ChangesetStatus_Open       TINYINT = 1,  
            @ChangesetStatus_Pending    TINYINT = 2,  
            @ChangesetStatus_Committed  TINYINT = 3,  
  
            @EntityPermission           TINYINT,  
            @Permission_Deny            TINYINT = 1,  
            @Permission_Admin           TINYINT = 5,  
  
            @ChangesetTableName         SYSNAME,  
            @TruncationGuard            NVARCHAR(MAX) = N'',  
            @SortTerm                   NVARCHAR(MAX) = NULL,  
            @SQL                        NVARCHAR(MAX);  
  
    SELECT  
        @User_ID = NULLIF(@User_ID, 0),  
        @Model_MUID = NULLIF(@Model_MUID, @GuidEmpty),  
        @Model_Name = NULLIF(LTRIM(RTRIM(@Model_Name)), N''),  
        @Entity_MUID = NULLIF(@Entity_MUID, @GuidEmpty),  
        @Entity_Name = NULLIF(LTRIM(RTRIM(@Entity_Name)), N''),  
        @Version_MUID = NULLIF(@Version_MUID, @GuidEmpty),  
        @Version_Name = NULLIF(LTRIM(RTRIM(@Version_Name)), N''),  
        @Changeset_MUID = NULLIF(@Changeset_MUID, @GuidEmpty),  
        @Changeset_Name = NULLIF(LTRIM(RTRIM(@Changeset_Name)), N''),  
        @SortColumn_Name = NULLIF(LTRIM(RTRIM(@SortColumn_Name)), N''),  
        @SortDirection = NULLIF(LTRIM(RTRIM(@SortDirection)), N''),  
        @ChangesetStatus = NULLIF(@ChangesetStatus, 0);  
  
    IF @User_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR100009|The User ID is not valid.', 16, 1);  
        RETURN;  
    END  
  
    SELECT  
         @Model_ID = m.ID  
    FROM mdm.tblModel m  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_MODEL s  
    ON m.ID = s.ID  
        AND s.User_ID = @User_ID  
    WHERE (@Model_MUID IS NOT NULL OR @Model_Name IS NOT NULL)  
        AND (@Model_MUID IS NULL OR @Model_MUID = m.MUID)  
        AND (@Model_Name IS NULL OR @Model_Name = m.Name)  
        AND s.Privilege_ID <> @Permission_Deny  
  
    IF @Model_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300005|The supplied model is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    SELECT @Version_ID = ID  
    FROM mdm.tblModelVersion  
    WHERE (@Version_MUID IS NOT NULL OR @Version_Name IS NOT NULL)  
        AND (@Version_MUID IS NULL OR MUID = @Version_MUID)  
        AND (@Version_Name IS NULL OR Name = @Version_Name)  
        AND Model_ID = @Model_ID;  
  
    IF @Version_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300006|The supplied version is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    SELECT  
         @Entity_ID = e.ID,  
         @EntityPermission = s.Privilege_ID  
    FROM mdm.tblEntity e  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ENTITY s  
    ON e.ID = s.ID  
        AND s.User_ID = @User_ID  
    WHERE (@Entity_MUID IS NOT NULL OR @Entity_Name IS NOT NULL)  
        AND (@Entity_MUID IS NULL OR @Entity_MUID = e.MUID)  
        AND (@Entity_Name IS NULL OR @Entity_Name = e.Name)  
        AND e.Model_ID = @Model_ID  
        AND s.Privilege_ID <> @Permission_Deny  
  
    IF @SortColumn_Name IS NOT NULL  
    BEGIN  
        SET @SortTerm = CONCAT(QUOTENAME(@SortColumn_Name), CASE WHEN UPPER(@SortDirection) = N'ASC' THEN N' ASC' ELSE N' DESC' END);  
    END  
    ELSE  
    BEGIN  
        SET @SortTerm = N'LastChgDTM DESC'  
    END  
  
    SET @ChangesetTableName = CONCAT(N'tbl_', @Model_ID, N'_CS');  
  
    SET @SQL = CONCAT(@TruncationGuard + N'  
        SELECT  
            cs.MUID,  
            cs.Name,  
            e.MUID AS EntityMUID,  
            e.Name AS EntityName,  
            cs.Description,  
            cs.Status,  
            cs.EnterDTM,  
            eu.UserName AS EnterUserName,  
            eu.MUID AS EnterUserMUID,  
            cs.LastChgDTM,  
            lu.UserName AS LastChgUserName,  
            lu.MUID AS LastChgUserMUID  
        FROM mdm.', QUOTENAME(@ChangesetTableName), N' cs  
        INNER JOIN mdm.tblEntity e ON e.ID = cs.Entity_ID  
        LEFT JOIN [mdm].[tblUser] eu ON eu.ID = cs.EnterUserID  
        LEFT JOIN [mdm].[tblUser] lu ON lu.ID = cs.LastChgUserID  
        WHERE cs.Version_ID = @Version_ID  
            AND (cs.Entity_ID = @Entity_ID OR @Entity_ID IS NULL)  
            AND (cs.Status = @ChangesetStatus OR @ChangesetStatus IS NULL)  
            AND (cs.Name = @Changeset_Name OR @Changeset_Name IS NULL)  
            AND (cs.MUID = @Changeset_MUID OR @Changeset_MUID IS NULL)  
    ');  
  
    IF @EntityPermission = @Permission_Admin  
    BEGIN  
        SET @SQL += CONCAT(N'  
            AND (cs.EnterUserID = @User_ID OR cs.Status = ', @ChangesetStatus_Pending, N')');  
    END  
    ELSE  
    BEGIN  
        SET @SQL += N'  
            AND cs.EnterUserID = @User_ID';  
    END  
  
    SET @SQL += N'  
        ORDER BY ' + @SortTerm;  
  
    EXEC sp_executesql @SQL,  
        N'@Version_ID INT,  @User_ID INT, @Entity_ID INT, @ChangesetStatus TINYINT, @Changeset_Name NVARCHAR(50), @Changeset_MUID UNIQUEIDENTIFIER',  
          @Version_ID,      @User_ID,     @Entity_ID,     @ChangesetStatus,         @Changeset_Name,              @Changeset_MUID;  
END
go

