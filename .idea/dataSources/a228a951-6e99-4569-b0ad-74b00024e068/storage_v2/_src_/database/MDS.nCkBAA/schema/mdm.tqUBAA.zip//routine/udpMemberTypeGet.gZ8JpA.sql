/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpMemberTypeGet  
(  
     @User_ID       INT  
  
    ,@Model_MUID    UNIQUEIDENTIFIER = NULL  
    ,@Model_Name    NVARCHAR(50) = NULL  
    ,@Model_ID      INT = NULL -- set internally only  
  
    ,@Entity_MUID   UNIQUEIDENTIFIER = NULL  
    ,@Entity_Name   NVARCHAR(50) = NULL  
    ,@Entity_ID     INT = NULL -- set internally only  
  
    ,@MemberType_ID TINYINT = NULL  
  
    -- Only used when getting details  
    ,@AttributeGroup_MUID   UNIQUEIDENTIFIER = NULL  
    ,@AttributeGroup_Name   NVARCHAR(50) = NULL  
  
    ,@Attribute_MUID   UNIQUEIDENTIFIER = NULL  
    ,@Attribute_Name   NVARCHAR(100) = NULL  
  
    ,@ResultOption TINYINT -- None = 0, Identifiers = 1, Details = 2.   
   
    ,@IncludeParentIdentifiers  BIT = 1 -- Return results sets for parent Model and Entity identifiers. Set to 0 when getting attributes as part of a parent object (because the parent identifiers will already have been looked up).  
    ,@OmitAttributes            BIT = 0 -- When 1, a result set is not returned for attributes. This should be set to 1 when the caller will return Attributes. Ignored when @ResultOption is not Details.  
    ,@Debug                     BIT = 0  
    ,@CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
  
    SET NOCOUNT ON  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': begin udpMemberTypeGet, @Model_ID = ', @Model_ID, N', @Entity_ID = ', @Entity_ID, N', @MemberType_ID = ', @MemberType_ID)  
  
    DECLARE   
         @ResultOption_Identifiers  TINYINT = 1  
        ,@ResultOption_Details      TINYINT = 2  
  
    -- Get model ID  
    IF @Model_ID IS NULL -- If the ID was already provided, don't bother looking it up again  
        AND (@Model_Name IS NOT NULL OR @Model_MUID IS NOT NULL)  
    BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': lookup @Model_ID')  
        SELECT   
             @Model_ID = ID  
            ,@Model_MUID = MUID  
            ,@Model_Name = Name  
        FROM mdm.tblModel  
        WHERE   MUID = ISNULL(@Model_MUID, MUID)  
            AND Name = ISNULL(@Model_Name, Name)  
  
        SET @Model_ID = COALESCE(@Model_ID, 0)  
    END  
  
    -- Get entity ID  
    IF @Entity_ID IS NULL -- If the ID was already provided, don't bother looking it up again  
        AND (@Entity_Name IS NOT NULL OR @Entity_MUID IS NOT NULL)  
    BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': lookup @Entity_ID')  
        SELECT  
             @Model_ID = Model_ID  
            ,@Entity_ID = ID  
            ,@Entity_MUID = MUID  
            ,@Entity_Name = Name  
        FROM mdm.tblEntity  
        WHERE   MUID = ISNULL(@Entity_MUID, MUID)  
            AND Name = ISNULL(@Entity_Name, Name)  
            AND Model_ID = ISNULL(@Model_ID, Model_ID) -- If a model filter is specified, use it  
  
        SET @Entity_ID = COALESCE(@Entity_ID, 0)  
    END  
  
    DECLARE @SelectedMemberType TABLE  
    (  
         ID                 TINYINT  
        ,Entity_ID          INT  
        ,Model_ID           INT  
        ,Privilege_ID       TINYINT  
        ,AccessPermission   TINYINT  
        PRIMARY KEY (ID, Entity_ID)  
    )  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': selecting into #SelectedMemberType')  
    INSERT INTO @SelectedMemberType  
    SELECT  
         mt.ID  
        ,mt.Entity_ID  
        ,e.Model_ID  
        ,mt.Privilege_ID  
        ,mt.AccessPermission  
    FROM mdm.viw_SYSTEM_SECURITY_USER_MEMBERTYPE mt  
    INNER JOIN mdm.tblEntity e  
    ON mt.Entity_ID = e.ID  
    WHERE   mt.User_ID = @User_ID  
        AND e.Model_ID = ISNULL(@Model_ID, e.Model_ID)  
        AND mt.Entity_ID = ISNULL(@Entity_ID, mt.Entity_ID)  
        AND mt.ID = ISNULL(@MemberType_ID, mt.ID)  
        AND mt.Privilege_ID > 1/*Deny*/  
  
    IF @IncludeParentIdentifiers = 1  
    BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': returning parent identifiers')  
        -- Return model Identifier(s)  
        IF @Model_ID IS NOT NULL  
        BEGIN  
            IF @Model_Name IS NULL OR @Model_MUID IS NULL  
            BEGIN  
                SELECT   
                     @Model_MUID = MUID  
                    ,@Model_Name = Name  
                FROM mdm.tblModel  
                WHERE ID = @Model_ID  
            END  
  
            -- A single model was specified, and its info has already been looked up, so simply return it  
            SELECT   
                 @Model_MUID    AS Model_MUID  
                ,@Model_Name    AS Model_Name  
                ,@Model_ID      AS Model_ID  
        END ELSE  
        BEGIN  
            SELECT DISTINCT  
                 m.MUID AS Model_MUID  
                ,m.Name AS Model_Name  
                ,m.ID   AS Model_ID  
            FROM @SelectedMemberType mt  
            INNER JOIN mdm.tblEntity e  
            ON mt.Entity_ID = e.ID  
            INNER JOIN mdm.tblModel m  
            ON e.Model_ID = m.ID  
        END  
  
        -- Return entity Identifier(s)  
        IF @Entity_ID IS NOT NULL  
        BEGIN  
            -- A single entity was specified, and its info has already been looked up, so simply return it  
            SELECT   
                 @Model_ID      AS Model_ID  
                ,@Entity_MUID   AS Entity_MUID  
                ,@Entity_Name   AS Entity_Name  
                ,@Entity_ID     AS Entity_ID  
        END ELSE  
        BEGIN  
            SELECT DISTINCT  
                 e.Model_ID AS Model_ID  
                ,e.MUID AS Entity_MUID  
                ,e.Name AS Entity_Name  
                ,e.ID   AS Entity_ID  
            FROM @SelectedMemberType mt  
            INNER JOIN mdm.tblEntity e  
            ON mt.Entity_ID = e.ID  
        END  
    END  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': returning member type info')  
    SELECT  
         ID AS MemberType_ID  
        ,Entity_ID  
        ,Privilege_ID  
        ,AccessPermission  
    FROM @SelectedMemberType  
    ORDER BY Model_ID, Entity_ID, ID  
  
    IF @ResultOption = @ResultOption_Details  
    BEGIN  
        EXEC mdm.udpAttributeGroupGet  
             @User_ID = @User_ID  
            ,@Model_ID = @Model_ID  
            ,@Entity_ID = @Entity_ID  
            ,@MemberType_ID = @MemberType_ID  
            ,@AttributeGroup_MUID = @AttributeGroup_MUID  
            ,@AttributeGroup_Name = @AttributeGroup_Name  
            ,@Attribute_MUID = @Attribute_MUID  
            ,@Attribute_Name = @Attribute_Name  
            ,@ResultOption = @ResultOption_Details  
            ,@IncludeParentIdentifiers = 0 -- parent Ids already returned  
            ,@OmitAttributes = 1 -- Attributes will be returned by the next call  
            ,@Debug = @Debug  
            ,@CorrelationID = @CorrelationID  
  
        IF COALESCE(@OmitAttributes, 1) = 0  
        BEGIN  
            EXEC mdm.udpAttributeGet  
                 @User_ID = @User_ID  
                ,@Model_ID = @Model_ID  
                ,@Entity_ID = @Entity_ID  
                ,@MemberType_ID = @MemberType_ID  
                ,@AttributeGroup_MUID = @AttributeGroup_MUID  
                ,@AttributeGroup_Name = @AttributeGroup_Name  
                ,@Attribute_MUID = @Attribute_MUID  
                ,@Attribute_Name = @Attribute_Name  
                ,@IncludeParentIdentifiers = 0 -- parent Ids already returned  
                ,@Debug = @Debug  
                ,@CorrelationID = @CorrelationID  
        END  
    END   
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': end udpMemberTypeGet')  
  
    SET NOCOUNT OFF  
END --proc
go

