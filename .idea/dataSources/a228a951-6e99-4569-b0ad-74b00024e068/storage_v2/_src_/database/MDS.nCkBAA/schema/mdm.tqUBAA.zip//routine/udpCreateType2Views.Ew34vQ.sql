/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
EXEC mdm.[udpCreateType2Views] 27, 1, 19, NULL, 'TEST1';  
EXEC mdm.[udpCreateType2Views] 27, 2, 19, NULL, 'TEST2';  
EXEC mdm.[udpCreateType2Views] 27, 3, 19, NULL, 'TEST3';  
  
SELECT * FROM mdm.TEST1  
SELECT * FROM mdm.TEST2  
SELECT * FROM mdm.TEST3  
  
*/  
CREATE PROCEDURE [mdm].[udpCreateType2Views]  
(  
    @Entity_ID                 INT,  
    @MemberType_ID             TINYINT,  
    @Version_ID                INT,  
    @VersionFlag_ID            INT,  
    @SubscriptionViewName      SYSNAME,  
    @CorrelationID             UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE  
        @MemberType_Leaf                TINYINT = 1,  
        @MemberType_Consolidated        TINYINT = 2,  
        @MemberType_Collection          TINYINT = 3;  
  
    --Defer view generation if we are in the middle of an upgrade or demo-rebuild  
    IF APPLOCK_MODE(N'public', N'DeferViewGeneration', N'Session') = N'NoLock' BEGIN  
  
        DECLARE  
            @SQL                    NVARCHAR(MAX) = N'',  
            @SelectMain             NVARCHAR(MAX) = N'',  
            @SelectHistory          NVARCHAR(MAX) = N'',  
            @FromMain               NVARCHAR(MAX) = N'',  
            @FromHistory            NVARCHAR(MAX) = N'',  
            @ViewColumn             NVARCHAR(120), --specifically made to be less than 128 for truncation reasons  
            @TableColumn            SYSNAME,  
            @DomainTable            SYSNAME,  
            @DomainEntity_ID        INT,  
            @AttributeType_ID       INT,  
            @MainTable              SYSNAME,  
            @HistoryTable           SYSNAME,  
            @MemberIDColumn         SYSNAME;  
  
        SELECT  
            @MainTable =  
                CASE @MemberType_ID  
                    WHEN @MemberType_Leaf THEN EntityTable  
                    WHEN @MemberType_Collection THEN CollectionTable  
                    WHEN @MemberType_Consolidated THEN HierarchyParentTable  
                    ELSE NULL  
                END,  
            @MemberIDColumn =  
                CASE @MemberType_ID  
                    WHEN @MemberType_Leaf THEN 'EN_ID'  
                    WHEN @MemberType_Collection THEN 'CN_ID'  
                    WHEN @MemberType_Consolidated THEN 'HP_ID'  
                    ELSE NULL  
                END  
        FROM mdm.tblEntity  
        WHERE   ID = @Entity_ID  
  
        IF @MainTable IS NULL  
        BEGIN  
            RAISERROR('MDSERR100010|The Parameters are not valid.', 16, 1);  
            RETURN;  
        END;  
  
        SET @HistoryTable = CONVERT(SYSNAME, CONCAT(@MainTable, N'_HS'));  
  
        SET @SelectMain +=  
            CASE @MemberType_ID  
                WHEN @MemberType_Leaf THEN N''  
                WHEN @MemberType_Collection THEN N''  
                ELSE N',H.Name as Hierarchy'  
            END;  
  
        SET @SelectHistory +=  
            CASE @MemberType_ID  
                WHEN @MemberType_Leaf THEN N''  
                WHEN @MemberType_Collection THEN N''  
                ELSE N',H.Name as Hierarchy'  
            END;  
  
        DECLARE @ConflictingColumnName NVARCHAR(100);  
        --Get the Attributes for the Entity and then find the corresponding lookup table  
        DECLARE @TempTable TABLE(  
                ViewColumn          NVARCHAR(100) COLLATE DATABASE_DEFAULT  
                ,TableColumn        SYSNAME COLLATE DATABASE_DEFAULT  
                ,AttributeType_ID   INT  
                ,DomainEntity_ID    INT NULL  
                ,DomainTable        SYSNAME COLLATE DATABASE_DEFAULT NULL  
                ,SortOrder          INT);  
        INSERT INTO @TempTable  
        SELECT  
            ViewColumn,  
            TableColumn,  
            AttributeType_ID,  
            DomainEntity_ID,  
            DomainTable,  
            SortOrder  
        FROM  
            mdm.udfEntityAttributesGetList(@Entity_ID, @MemberType_ID)  
        WHERE ViewColumn != N'ChangeTrackingMask'  
        ORDER BY  
            SortOrder ASC;  
  
        WHILE EXISTS(SELECT 1 FROM @TempTable) BEGIN  
  
            SELECT TOP 1  
                @ViewColumn = ViewColumn,  
                @TableColumn = TableColumn,  
                @AttributeType_ID = AttributeType_ID,  
                @DomainEntity_ID = DomainEntity_ID,  
                @DomainTable = DomainTable  
            FROM @TempTable  
            ORDER BY  
                SortOrder ASC;  
  
            IF @DomainEntity_ID IS NULL  
            BEGIN  
                --Check for name validation, if there are some DBA which their _Code/_Name/_ID columns have conflicts with some FFA attribute names.  
                DECLARE @ViewColumnPrefix NVARCHAR(120) = CASE  
                    WHEN @ViewColumn LIKE N'%\_Code' ESCAPE N'\' THEN LEFT(@ViewColumn, LEN(@ViewColumn) - LEN(N'_Code'))  
                    WHEN @ViewColumn LIKE N'%\_Name' ESCAPE N'\' THEN LEFT(@ViewColumn, LEN(@ViewColumn) - LEN(N'_Name'))  
                    WHEN @ViewColumn LIKE N'%\_ID' ESCAPE N'\' THEN LEFT(@ViewColumn, LEN(@ViewColumn) - LEN(N'_ID'))  
                    ELSE NULL  
                    END;  
                IF (@ViewColumnPrefix IS NOT NULL)  
                BEGIN  
                    SELECT TOP 1 @ConflictingColumnName = Name  
                    FROM mdm.tblAttribute  
                    WHERE Entity_ID = @Entity_ID  
                        AND MemberType_ID = @MemberType_ID  
                        AND AttributeType_ID = 2 -- DBA  
                        AND Name = @ViewColumnPrefix;  
                    IF (@ConflictingColumnName IS NOT NULL)  
                    BEGIN  
                        RAISERROR('MDSERR100059|There are at least two attribute names in conflict in the existing or new subscription view. Free-form attribute names cannot start with an existing domain-based attribute name and end with "_Code", "_Name" or "_ID". Attribute names are: |%s|%s|', 16, 1, @ConflictingColumnName, @ViewColumn);  
                        RETURN;  
                    END  
                END  
                IF @ViewColumn = N'Owner_ID' AND @MemberType_ID = @MemberType_Collection BEGIN --Collection  
                    SET @SelectMain = @SelectMain + N'  
    ,' + QUOTENAME(@ViewColumn) + N'.UserName AS [Owner_ID]';  
                    SET @SelectHistory = @SelectHistory + N'  
    ,' + QUOTENAME(@ViewColumn) + N'.UserName AS [Owner_ID]';  
                    SET @FromMain = @FromMain + N'  
LEFT JOIN mdm.tblUser AS Owner_ID  
    ON Owner_ID.ID = T.Owner_ID';  
                    SET @FromHistory = @FromHistory + N'  
LEFT JOIN mdm.tblUser AS Owner_ID  
    ON Owner_ID.ID = T.Owner_ID';  
                END ELSE BEGIN  
                    SET @SelectMain = @SelectMain + N'  
    ,T.' + QUOTENAME(@TableColumn) + N' AS ' + QUOTENAME(@ViewColumn);  
                    SET @SelectHistory = @SelectHistory + N'  
    ,T.' + QUOTENAME(@TableColumn) + N' AS ' + QUOTENAME(@ViewColumn);  
                END; --if  
  
            END ELSE BEGIN  
                --Check for name validation, if there are some DBA which their _Code/_Name/_ID columns have conflicts with some FFA attribute names.  
                SELECT TOP 1 @ConflictingColumnName = Name   
                    FROM mdm.tblAttribute   
                    WHERE Entity_ID = @Entity_ID   
                        AND MemberType_ID = @MemberType_ID  
                        AND AttributeType_ID = 1 -- Freeform  
                        AND (  Name = @ViewColumn + N'_Code'   
                            OR Name = @ViewColumn + N'_Name'   
                            OR Name = @ViewColumn + N'_ID' );  
                IF (@ConflictingColumnName IS NOT NULL)  
                BEGIN  
                    RAISERROR('MDSERR100059|There are at least two attribute names in conflict in the existing or new subscription view. Free-form attribute names cannot start with an existing domain-based attribute name and end with "_Code", "_Name" or "_ID". Attribute names are: |%s|%s|', 16, 1, @ConflictingColumnName, @ViewColumn);  
                    RETURN;  
                END  
                SET @SelectHistory = @SelectHistory + N'  
    ,COALESCE(' + QUOTENAME(@ViewColumn) + N'.Code, ' + QUOTENAME(@ViewColumn + N'_HS') + N'.Code) AS ' + QUOTENAME(@ViewColumn + N'_Code') + N'  
    ,COALESCE(' + QUOTENAME(@ViewColumn) + N'.Name, ' + QUOTENAME(@ViewColumn + N'_HS') + N'.Code) AS ' + QUOTENAME(@ViewColumn + N'_Name') + N'  
    ,T.' + QUOTENAME(@TableColumn) + ' AS ' + QUOTENAME(@ViewColumn + N'_ID');  
                SET @SelectMain = @SelectMain + N'  
    ,' + QUOTENAME(@ViewColumn) + N'.Code AS ' + QUOTENAME(@ViewColumn + N'_Code') + N'  
    ,' + QUOTENAME(@ViewColumn) + N'.Name AS ' + QUOTENAME(@ViewColumn + N'_Name') + N'  
    ,T.' + QUOTENAME(@TableColumn) + ' AS ' + QUOTENAME(@ViewColumn + N'_ID');  
  
                SET @FromHistory = @FromHistory + N'  
LEFT JOIN mdm.' + QUOTENAME(@DomainTable) + N' AS ' + QUOTENAME(@ViewColumn) + N'  
    ON ' + QUOTENAME(@ViewColumn) + N'.ID = T.' + QUOTENAME(@TableColumn) + N' AND ' + QUOTENAME(@ViewColumn) + N'.Version_ID = T.Version_ID  
LEFT JOIN mdm.' + QUOTENAME(@DomainTable + N'_HS') + N' AS ' + QUOTENAME(@ViewColumn + N'_HS') + N'  
    ON ' + QUOTENAME(@ViewColumn + N'_HS') + N'.EN_ID = T.' + QUOTENAME(@TableColumn) + N' AND ' + QUOTENAME(@ViewColumn + N'_HS') + N'.Version_ID = T.Version_ID  AND (T.EnterDTM BETWEEN ' + QUOTENAME(@ViewColumn + N'_HS') + N'.EnterDTM  AND ' + QUOTENAME(@ViewColumn + N'_HS') + N'.LastChgDTM)';  
                SET @FromMain = @FromMain + N'  
LEFT JOIN mdm.' + QUOTENAME(@DomainTable) + N' AS ' + QUOTENAME(@ViewColumn) + N'  
    ON ' + QUOTENAME(@ViewColumn) + N'.ID = T.' + QUOTENAME(@TableColumn) + N' AND ' + QUOTENAME(@ViewColumn) + N'.Version_ID = T.Version_ID';  
            END; --if  
  
            DELETE FROM @TempTable WHERE ViewColumn = @ViewColumn;  
  
        END; --while  
  
        SET @SQL = CASE  
            WHEN EXISTS(SELECT 1 FROM sys.views WHERE [name] = @SubscriptionViewName AND [schema_id] = SCHEMA_ID('mdm')) THEN N'ALTER'  
            ELSE N'CREATE' END + N' VIEW mdm.' + QUOTENAME(@SubscriptionViewName) + N'  
/*WITH ENCRYPTION*/  
AS  
SELECT  
    T.ID AS RevisionID  
    ,LS.ListOption AS State  
    ,T.' + @MemberIDColumn + ' AS ID  
    ,T.MUID AS MUID' + @SelectHistory + N'  
    ,T.EnterDTM AS EnterDateTime  
    ,UE.UserName AS EnterUserName  
    ,T.LastChgDTM AS LastChgDateTime  
    ,UC.UserName AS LastChgUserName';  
        SET @SQL += N'  
FROM mdm.' + QUOTENAME(@HistoryTable) + N' AS T'  
  
        IF @MemberType_ID = @MemberType_Consolidated  
        BEGIN  
            SET @SQL += N'  
INNER JOIN mdm.tblHierarchy H  
    ON H.ID = T.Hierarchy_ID'  
        END  
  
        SET @SQL +=  @FromHistory;  
  
        SET @SQL +=  N'  
LEFT JOIN mdm.tblList LS  
    ON LS.OptionID = T.Status_ID AND LS.ListCode = ''lstStatus''';  
  
        SET @SQL +=  N'  
LEFT JOIN mdm.tblUser UE  
    ON T.EnterUserID = UE.ID  
LEFT JOIN mdm.tblUser UC  
    ON T.LastChgUserID = UC.ID'  
            + CASE  
                    WHEN (@Version_ID IS NOT NULL)     THEN CONCAT(N'  
WHERE T.Version_ID = ', @Version_ID)  
                    WHEN (@VersionFlag_ID IS NOT NULL) THEN CONCAT(N'  
INNER JOIN mdm.tblModelVersion AS V  
    ON V.ID =  T.Version_ID  
WHERE V.VersionFlag_ID = ', @VersionFlag_ID)  
            END  
  
        SET @SQL +=  N'  
UNION ALL  
SELECT  
    T.LastChgTS AS RevisionID  
    ,LS.ListOption AS State  
    ,T.ID AS ID  
    ,T.MUID AS MUID' + @SelectMain + N'  
    ,T.LastChgDTM AS EnterDateTime  
    ,UC.UserName AS EnterUserName  
    ,N''9999-12-31 23:59:59.998'' AS LastChgDateTime  
    ,NULL AS LastChgUserName';  
        SET @SQL += N'  
FROM mdm.' + QUOTENAME(@MainTable) + N' AS T'  
  
        IF @MemberType_ID = @MemberType_Consolidated  
        BEGIN  
            SET @SQL += N'  
INNER JOIN mdm.tblHierarchy H  
    ON H.ID = T.Hierarchy_ID'  
        END  
  
        SET @SQL +=  @FromMain;  
  
        SET @SQL +=  N'  
LEFT JOIN mdm.tblList LS  
    ON LS.OptionID = T.Status_ID AND LS.ListCode = ''lstStatus''';  
  
        SET @SQL +=  N'  
LEFT JOIN mdm.tblUser UC  
    ON T.LastChgUserID = UC.ID'  
            + CASE  
                    WHEN (@Version_ID IS NOT NULL)     THEN CONCAT(N'  
WHERE T.Version_ID = ', @Version_ID)  
                    WHEN (@VersionFlag_ID IS NOT NULL) THEN CONCAT(N'  
INNER JOIN mdm.tblModelVersion AS V  
    ON V.ID =  T.Version_ID  
WHERE V.VersionFlag_ID = ', @VersionFlag_ID)  
            END  
  
            SET @SQL += N';';  
  
            SELECT (@SQL);  
            EXEC sp_executesql @SQL;  
    END; --if  
  
    SET NOCOUNT OFF;  
END; --proc
go

