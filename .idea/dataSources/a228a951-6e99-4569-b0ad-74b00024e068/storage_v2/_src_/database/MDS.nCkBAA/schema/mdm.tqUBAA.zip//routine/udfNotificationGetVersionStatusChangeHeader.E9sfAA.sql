/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
SELECT CONVERT(XML, mdm.udfNotificationGetVersionStatusChangeHeader());  
*/  
CREATE FUNCTION mdm.udfNotificationGetVersionStatusChangeHeader()  
RETURNS NVARCHAR(MAX)  
/*WITH SCHEMABINDING*/  
AS BEGIN  
  
    DECLARE  
         @HeaderElement NVARCHAR(MAX)  
        ,@LocalizedNotificationTypeName NVARCHAR(MAX) = N'Version Status Change'  
        ,@LocalizedModelHeader NVARCHAR(MAX) = N'Model'  
        ,@LocalizedVersionHeader NVARCHAR(MAX) = N'Version'  
        ,@LocalizedPriorStatusHeader NVARCHAR(MAX) = N'Prior status'  
        ,@LocalizedNewStatusHeader NVARCHAR(MAX) = N'New status'  
        ,@LocalizedLink NVARCHAR(MAX) = N'Click to view'  
        ,@LocalizedIssuedHeader NVARCHAR(MAX) = N'Issued'  
        ,@LocalizedProductName NVARCHAR(MAX) = N'SQL Server Master Data Services'  
        ,@CurrentLanguageCode INT = 1033 -- Default language code is English (US).  
        ,@StringLanguageCode NVARCHAR(MAX) = N''  
        ,@RootUrl NVARCHAR(MAX)  
  
    -- Use default language code to get the notification language code.  
    SELECT @StringLanguageCode = mdm.udfLocalizedStringGet(N'NotificationLCID', @CurrentLanguageCode, 1033);  
  
    IF @StringLanguageCode <> N'' BEGIN  
        SELECT @CurrentLanguageCode = CONVERT(INT, @StringLanguageCode)  
    END; -- if  
  
    -- Get the localized message texts based on the notification language code in tblLocalizedStrings.  
    SELECT @LocalizedModelHeader = mdm.udfLocalizedStringGet(N'NotificationHeaderModel', @CurrentLanguageCode, @LocalizedModelHeader);  
    SELECT @LocalizedVersionHeader = mdm.udfLocalizedStringGet(N'NotificationHeaderVersion', @CurrentLanguageCode, @LocalizedVersionHeader);  
    SELECT @LocalizedPriorStatusHeader = mdm.udfLocalizedStringGet(N'NotificationHeaderPriorStatus', @CurrentLanguageCode, @LocalizedPriorStatusHeader);  
    SELECT @LocalizedNewStatusHeader = mdm.udfLocalizedStringGet(N'NotificationHeaderNewStatus', @CurrentLanguageCode, @LocalizedNewStatusHeader);  
    SELECT @LocalizedIssuedHeader = mdm.udfLocalizedStringGet(N'NotificationHeaderIssued', @CurrentLanguageCode, @LocalizedIssuedHeader);  
    SELECT @LocalizedLink = mdm.udfLocalizedStringGet(N'NotificationLinkTextVerbose', @CurrentLanguageCode, @LocalizedLink);  
    SELECT @LocalizedProductName = mdm.udfLocalizedStringGet(N'NotificationProductName', @CurrentLanguageCode, @LocalizedProductName);  
    SELECT @LocalizedNotificationTypeName = mdm.udfLocalizedStringGet(N'NotificationVersionStatusChange', @CurrentLanguageCode, @LocalizedNotificationTypeName);  
  
    -- Get the MDS web application root URL  
    SELECT @RootUrl = mdm.udfSystemSettingGet(N'MDMRootURL');  
  
    IF RIGHT(@RootUrl, 1) != N'/'  
    BEGIN  
        SET @RootUrl = CONCAT(@RootUrl, N'/');  
    END  
  
    SET @HeaderElement = CONCAT(N'  
        <header>  
          <ProductName>', (SELECT @LocalizedProductName FOR XML PATH('')), N'</ProductName>  
          <Notification_type>', (SELECT @LocalizedNotificationTypeName FOR XML PATH('')), N'</Notification_type>  
          <Model>', (SELECT @LocalizedModelHeader FOR XML PATH('')), N'</Model>  
          <Version>', (SELECT @LocalizedVersionHeader FOR XML PATH('')), N'</Version>  
          <PriorStatus>', (SELECT @LocalizedPriorStatusHeader FOR XML PATH('')), N'</PriorStatus>  
          <NewStatus>', (SELECT @LocalizedNewStatusHeader FOR XML PATH('')), N'</NewStatus>  
          <link_text>', (SELECT @LocalizedLink FOR XML PATH('')), N'</link_text>  
          <Issued>', (SELECT @LocalizedIssuedHeader FOR XML PATH('')), N'</Issued>  
          <root_url>', (SELECT @RootUrl FOR XML PATH('')), N'</root_url>  
        </header>')  
  
    RETURN @HeaderElement  
  
END --fn
go

