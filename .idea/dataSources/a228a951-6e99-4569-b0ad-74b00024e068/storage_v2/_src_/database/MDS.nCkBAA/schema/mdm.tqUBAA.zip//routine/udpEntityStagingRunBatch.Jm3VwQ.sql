/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
This SPROC runs a staging batch synchronously and optionally clears the batch after it is run.  
  
EXEC mdm.udpEntityStagingRunBatch 31, 20, 4, 1  
*/  
CREATE PROCEDURE mdm.udpEntityStagingRunBatch  
(  
   @User_ID             INT,  
   @Version_ID          INT,  
   @Entity_ID           INT,  
   @MemberType_ID       INT,     
   @Batch_ID            INT,  
   @ClearBatchAfterRun  BIT = 0,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    DECLARE @EntityStagingTableName     SYSNAME,  
            @LogFlag                    INT = NULL,  
            @VersionName                NVARCHAR(50),  
            @RunStagingSql              NVARCHAR(MAX),  
            @SecurityLevel              TINYINT = 0,  
            @PermissionType_Admin       TINYINT = 5,  
            @MemberType_Leaf            TINYINT = 1,  
            @MemberType_Consolidated    TINYINT = 2,  
            @Entity_Permission          TINYINT;  
  
  
    SELECT @Entity_Permission = Privilege_ID  
    FROM mdm.viw_SYSTEM_SECURITY_USER_ENTITY  
    WHERE [User_ID] = @User_ID  
        AND ID = @Entity_ID;  
  
    IF @Entity_Permission = @PermissionType_Admin  
    BEGIN  
        RAISERROR('MDSERR120002|The user does not have permission to perform this operation.', 16, 1);  
        RETURN;  
    END  
  
    SELECT @EntityStagingTableName = (CASE @MemberType_ID   
                                        WHEN @MemberType_Leaf THEN StagingLeafName  
                                        WHEN @MemberType_Consolidated THEN StagingConsolidatedName  
                                        ELSE NULL  
                                      END)  
    FROM mdm.tblEntity  
    WHERE ID = @Entity_ID;  
  
    -- @LogFlag is OnOff list box which value is On 1, Off 2.  
    SELECT @LogFlag = CONVERT(INT, SettingValue) FROM mdm.tblSystemSetting WHERE SettingName = 'StagingTransactionLogging';      
    SELECT @LogFlag = CASE @LogFlag WHEN 1 THEN 1 ELSE 0 END;  
  
    SELECT @VersionName = Name FROM mdm.tblModelVersion WHERE ID = @Version_ID;  
  
    SET @RunStagingSql = N'  
    EXECUTE stg.udp_' + @EntityStagingTableName + N'@VersionName=@VersionName, @LogFlag=@LogFlag, @Batch_ID=@Batch_ID, @User_ID=@User_ID;  
    ';  
  
    IF @ClearBatchAfterRun = 1  
    BEGIN  
        SET @RunStagingSql += N'  
        EXECUTE mdm.udpEntityStagingFlagForClearing @Batch_ID, @User_ID;  
        EXECUTE mdm.udpStagingProcessAllReadyToRun;  
        ';  
    END  
  
    EXEC sp_executesql   
                        @RunStagingSql,   
                        N'@Batch_ID INT, @VersionName NVARCHAR(50), @LogFlag INT, @User_ID INT',  
                          @Batch_ID,     @VersionName,              @LogFlag,     @User_ID;  
  
    SET NOCOUNT OFF;  
END; --proc
go

