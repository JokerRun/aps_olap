/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    SELECT mdm.udfModelGetIDByName(NULL, 'Product')  
    SELECT mdm.udfModelGetIDByName(NULL, 'Account')  
    SELECT mdm.udfModelGetIDByName(NULL, NULL)  
*/  
CREATE FUNCTION mdm.udfModelGetIDByName  
(  
    @Model_MUID UNIQUEIDENTIFIER,  
    @Model_Name NVARCHAR(50)  
)   
RETURNS INT  
/*WITH SCHEMABINDING*/  
AS BEGIN  
  
    DECLARE @Model_ID INT;  
  
    -- Clean input  
    SELECT  
         @Model_MUID = NULLIF(@Model_MUID, 0x0)  
        ,@Model_Name = NULLIF(LTRIM(RTRIM(@Model_Name)), N'' COLLATE Latin1_General_BIN -- collation prevents some special chars (like Chinese) from being considered equal to N''  
            )  
  
    IF @Model_MUID IS NOT NULL OR @Model_Name IS NOT NULL  
    BEGIN  
        SELECT @Model_ID = ID   
        FROM mdm.tblModel   
        WHERE   (@Model_MUID IS NULL OR MUID = @Model_MUID)   
            AND (@Model_Name IS NULL OR [Name] = @Model_Name)   
    END  
  
    RETURN @Model_ID;  
END; --fn
go

