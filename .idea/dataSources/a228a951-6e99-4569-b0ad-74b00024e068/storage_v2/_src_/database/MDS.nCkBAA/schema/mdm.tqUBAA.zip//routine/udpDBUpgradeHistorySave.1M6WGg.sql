/*  
	Inserts a record into the tblDBUpgradeHistory  
*/  
/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpDBUpgradeHistorySave  
(  
	@DBVersion			INT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
	SET NOCOUNT ON  
  
	--Insert the Data  
	INSERT INTO [mdm].[tblDBUpgradeHistory]  
	(  
		[DBVersion]  
	)  
	VALUES  
	(  
		@DBVersion  
	)  
  
	RETURN (SCOPE_IDENTITY())  
  
	SET NOCOUNT OFF  
END --proc
go

