/*  
exec mdm.udpUserPreferencesGet 1  
*/  
/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpUserPreferencesGet  
(  
	@User_ID INT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
	SET NOCOUNT ON  
  
	SELECT  
		PreferenceName,  
		PreferenceValue  
	FROM  
		mdm.tblUserPreference  
	WHERE   
		[User_ID] = @User_ID  
  
	SET NOCOUNT OFF  
END --proc
go

