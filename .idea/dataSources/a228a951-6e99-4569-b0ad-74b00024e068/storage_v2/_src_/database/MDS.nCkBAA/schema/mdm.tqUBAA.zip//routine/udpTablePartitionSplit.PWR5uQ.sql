/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpTablePartitionSplit  
(  
    @Model_ID       INT,  
    @Version_ID     INT  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    IF mdm.udfIsEnterpriseEdition() = 1  
    BEGIN  
        DECLARE @SQL NVARCHAR(MAX),  
                @PartitionSchema SYSNAME,  
                @PartitionFunction SYSNAME,  
                @PartitionId INT,  
                @TotalFileGroup INT,  
                @FileGroupName SYSNAME;  
        SET @PartitionSchema = CONCAT(N'udpsModel_', @Model_ID);  
        SET @PartitionFunction= CONCAT(N'udpfModel_', @Model_ID);  
  
        IF NOT EXISTS (  
            SELECT TOP 1 * FROM sys.partition_functions f  
            INNER JOIN sys.partition_range_values r ON f.function_id = r.function_id  
            WHERE f.name = @PartitionFunction AND r.value = @Version_ID  
        )  
        BEGIN  
  
            SET DEADLOCK_PRIORITY 10;  
  
            SELECT @PartitionId = MAX(boundary_id) FROM sys.partition_functions f  
            INNER JOIN sys.partition_range_values r ON f.function_id = r.function_id  
            WHERE f.name = @PartitionFunction  
            SET @PartitionId = ISNULL(@PartitionId, 0)  
  
            SELECT @TotalFileGroup = COUNT(name)  
            FROM sys.filegroups  
            WHERE is_read_only = 0  
  
            SELECT @FileGroupName = fgs.Name  
            FROM (  
                SELECT ROW_NUMBER() OVER (ORDER BY name ASC) AS ID,  
                       name as Name  
                FROM sys.filegroups  
                WHERE is_read_only = 0  
                ) fgs  
            WHERE fgs.ID = (@PartitionId % @TotalFileGroup) + 1  
  
            SET @SQL = CONCAT(N'ALTER PARTITION SCHEME ' , @PartitionSchema, N' NEXT USED ' , QUOTENAME(@FileGroupName));  
            EXEC sp_executesql @SQL;  
  
            SET @SQL = CONCAT(N'ALTER PARTITION FUNCTION ', @PartitionFunction, N'() SPLIT RANGE(', @Version_ID, N');');  
            EXEC sp_executesql @SQL;  
        END  
    END  
END --proc
go

