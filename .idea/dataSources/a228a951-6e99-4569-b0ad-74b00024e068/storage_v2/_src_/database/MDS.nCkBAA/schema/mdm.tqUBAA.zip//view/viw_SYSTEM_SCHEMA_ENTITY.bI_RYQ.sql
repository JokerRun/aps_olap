/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    SELECT * FROM mdm.viw_SYSTEM_SCHEMA_ENTITY  
    SELECT * FROM mdm.viw_SYSTEM_SCHEMA_ENTITY WHERE ID = 31  
*/  
CREATE VIEW mdm.viw_SYSTEM_SCHEMA_ENTITY  
/*WITH SCHEMABINDING*/  
AS  
SELECT  
     ent.ID  
    ,ent.ID Entity_ID  
    ,ent.MUID  
    ,ent.Name  
    ,ent.[Description]  
    ,ent.IsBase  
    ,ent.EntityTable  
    ,ent.HierarchyTable  
    ,ent.HierarchyParentTable  
    ,ent.CollectionTable  
    ,ent.CollectionMemberTable  
    ,ent.StagingBase  
    ,CASE WHEN ent.StagingBase IS NOT NULL THEN ent.StagingBase + N'_Leaf' ELSE NULL END AS StagingLeafTable  
    ,CASE WHEN ent.HierarchyTable IS NOT NULL AND ent.StagingBase IS NOT NULL THEN ent.StagingBase + N'_Consolidated' ELSE NULL END AS StagingConsolidatedTable  
    ,CASE WHEN ent.HierarchyTable IS NOT NULL AND ent.StagingBase IS NOT NULL THEN ent.StagingBase + N'_Relationship' ELSE NULL END AS StagingRelationshipTable  
    ,ent.Model_ID  
    ,mdl.MUID AS Model_MUID  
    ,mdl.Name AS Model_Name  
    ,COALESCE(ent.EnterUserID, 0) AS EnteredUser_ID  
    ,COALESCE(usrE.MUID, CAST(0x0 AS UNIQUEIDENTIFIER)) AS EnteredUser_MUID  
    ,usrE.UserName AS EnteredUser_UserName  
    ,ent.EnterDTM AS EnteredUser_DTM  
    ,COALESCE(ent.LastChgUserID, 0) AS LastChgUser_ID  
    ,COALESCE(usrL.MUID, CAST(0x0 AS UNIQUEIDENTIFIER)) AS LastChgUser_MUID  
    ,usrL.UserName AS LastChgUser_UserName  
    ,ent.LastChgDTM AS LastChgUser_DTM  
    ,CASE WHEN codegen.Seed IS NULL THEN 0 ELSE 1 END AS IsCodeGenerationEnabled  
    ,CASE WHEN codegen.Seed IS NULL THEN 0 ELSE codegen.Seed END as CodeGenerationSeed  
    ,ent.DataCompression  
    ,ent.TransactionLogType  
    ,ent.RequireApproval  
FROM  
    mdm.tblEntity AS ent   
    INNER JOIN mdm.tblModel AS mdl  
        ON mdl.ID = ent.Model_ID   
    LEFT JOIN mdm.tblUser AS usrE  
        ON ent.EnterUserID = usrE.ID  
    LEFT JOIN mdm.tblUser AS usrL  
        ON ent.LastChgUserID = usrL.ID  
    LEFT JOIN mdm.tblCodeGenInfo AS codegen  
        ON codegen.EntityId = ent.ID;
go

