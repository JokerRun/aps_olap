/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
mdm.udpUserGroupAssignmentSave 1,1,1  
select * from mdm.tblUserGroupAssignment  
*/  
CREATE PROCEDURE mdm.udpUserGroupAssignmentSave  
(  
    @SystemUser_ID      INT, --Person performing save  
    @User_ID            INT,  
    @UserGroup_MUID     UNIQUEIDENTIFIER,  
    @CorrelationID      UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
    DECLARE @GuidEmpty              UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER),  
            @UserGroup_ID           INT,  
            @securityMemberEvent    mdm.SecurityMemberProcessEvent;  
  
    INSERT @securityMemberEvent ([User_ID], [Entity_ID], Version_ID)  
    SELECT DISTINCT [User_ID], [Entity_ID], Version_ID  
    FROM [mdm].[viw_SYSTEM_SECURITY_ROLE_MEMBER] rm  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ROLE ur  
    ON rm.Role_ID = ur.Role_ID  
    WHERE ur.[User_ID] = @User_ID;  
  
    SET @UserGroup_MUID = NULLIF(@UserGroup_MUID, @GuidEmpty);  
  
    SELECT @UserGroup_ID  = (SELECT ID FROM mdm.tblUserGroup WHERE MUID = @UserGroup_MUID)  
    IF @UserGroup_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR500022|The group assignment cannot be updated. The group ID is not valid.', 16, 1);  
        RETURN;  
    END  
  
    IF NOT EXISTS(  
        SELECT 1 FROM mdm.tblUserGroupAssignment  
        WHERE UserGroup_ID = @UserGroup_ID  
            AND User_ID = @User_ID)  
    BEGIN  
        INSERT INTO mdm.tblUserGroupAssignment(UserGroup_ID, User_ID, EnterUserID, LastChgUserID)  
        SELECT @UserGroup_ID, @User_ID, @SystemUser_ID, @SystemUser_ID;  
    END  
  
    -- Queue a async event to recompute affected user  
    EXEC mdm.udpSecurityMemberProcessRebuildEvent @securityMemberEvent, 0;  
  
    SET NOCOUNT OFF;  
END --proc
go

