/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
Deletes all validation issues for the specified set of member ids.  
  
DECLARE @MemberIdList       mdm.IdList;  
INSERT INTO @MemberIdList  
VALUES (1), (2), (3)  
  
EXEC mdm.udpValidationLogClearByMemberIDs 7, 5, 1, @MemberIdList  
SELECT * FROM mdm.tbl_7_VL  
*/  
CREATE PROCEDURE mdm.udpValidationLogClearByMemberIDs  
(  
     @Version_ID     INT  
    ,@Entity_ID      INT  
    ,@MemberType_ID  TINYINT  
    ,@MemberIdList   mdm.IdList READONLY  
    ,@CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON  
  
    DECLARE @Model_ID               INT,  
            @SQL                    NVARCHAR(MAX),  
            @ValidationLogTableName sysname;  
  
    SELECT @Model_ID = Model_ID  
    FROM mdm.tblModelVersion  
    WHERE ID = @Version_ID;  
  
    SET @ValidationLogTableName = mdm.udfGetValidationLogTableName(@Model_ID);  
  
    SET @SQL = N'  
    DELETE lg  
    FROM [mdm].' + QUOTENAME(@ValidationLogTableName) + N' lg  
    INNER JOIN @MemberIdList m  
        ON  
            lg.Member_ID = m.ID  
    WHERE  
        lg.Version_ID = @Version_ID  
        AND lg.Entity_ID = @Entity_ID  
        AND lg.MemberType_ID = @MemberType_ID;  
    ';  
    EXEC sp_executesql @SQL, N'@MemberIdList mdm.IdList READONLY, @Version_ID INT, @Entity_ID INT, @MemberType_ID TINYINT',  
                               @MemberIdList,                     @Version_ID,     @Entity_ID,     @MemberType_ID;  
  
    SET NOCOUNT OFF  
END --proc
go

