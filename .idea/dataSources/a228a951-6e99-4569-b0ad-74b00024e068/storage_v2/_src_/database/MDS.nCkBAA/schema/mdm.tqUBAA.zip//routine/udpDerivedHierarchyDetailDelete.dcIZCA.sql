/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
mdm.udpDerivedHierarchyDetailDelete 'edmAdmin', NULL, 1  
SELECT * FROM mdm.tblDerivedHierarchy  
*/  
CREATE PROCEDURE mdm.udpDerivedHierarchyDetailDelete  
(  
    @ID             INT = NULL,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON  
  
    DECLARE @DerivedHierarchy_ID INT,  
            @Level_ID INT,  
            @LevelDiff INT,  
            @Ret INT;  
  
    BEGIN TRY  
        SELECT   
            @DerivedHierarchy_ID = dt.DerivedHierarchy_ID,  
            @Level_ID = dt.Level_ID,  
            @LevelDiff = (SELECT MAX(Level_ID) FROM mdm.tblDerivedHierarchyDetail WHERE DerivedHierarchy_ID = dt.DerivedHierarchy_ID) - dt.Level_ID  
        FROM mdm.tblDerivedHierarchyDetail dt  
        INNER JOIN [mdm].tblDerivedHierarchy dh ON dh.ID = dt.DerivedHierarchy_ID  
        WHERE dt.ID = @ID  
  
        --Verify that the Derived Hierarchy ID is retrieved, meaning we also have a valid Level ID  
        IF @DerivedHierarchy_ID IS NULL  
        BEGIN  
            RAISERROR('MDSERR200058|The derived hierarchy level cannot be deleted. The derived hierarchy level ID is not valid.', 16, 1);  
        END;  
  
        --Verify deleting the topmost level.  
        IF @LevelDiff > 0  
        BEGIN  
            RAISERROR('MDSERR200059|The derived hierarchy level cannot be deleted. Only the top level can be deleted.', 16, 1);  
        END;  
          
        --Verify there is no security set on any levels of the derived hierarchy.  
        IF EXISTS (SELECT ID FROM mdm.tblSecurityRoleAccessMember WHERE DerivedHierarchy_ID = @DerivedHierarchy_ID)    
        BEGIN    
            RAISERROR('MDSERR200078|Derived Hierarchy level cannot be deleted. The derived hierarchy has secured members.', 16, 1);  
        END  
  
        --Verify no subscription views exists.  
        EXEC mdm.udpSubscriptionViewCheck @DerivedHierarchy_ID = @DerivedHierarchy_ID, @ViewFormat_ID = 8 /*Levels*/, @Return_ID = @Ret output  
        IF @Ret > 0  
            BEGIN  
                RAISERROR('MDSERR200049|The derived hierarchy was not deleted because a subscription view exists.  To delete the hierarchy, you must first delete all subscription views associated with this derived hierarchy.', 16, 1);  
            END;  
        ELSE  
        BEGIN  
            EXEC mdm.udpSubscriptionViewCheck @DerivedHierarchy_ID = @DerivedHierarchy_ID, @ViewFormat_ID = 7 /*ParentChild*/, @Return_ID = @Ret output  
            IF @Ret > 0  
            BEGIN  
                RAISERROR('MDSERR200049|The derived hierarchy was not deleted because a subscription view exists.  To delete the hierarchy, you must first delete all subscription views associated with this derived hierarchy.', 16, 1);  
            END;  
        END  
  
        -- Remove any attribute filters that are referencing the level.  
        UPDATE mdm.tblAttribute  
        SET  FilterParentAttribute_ID = NULL  
            ,FilterHierarchyDetail_ID = NULL  
        WHERE FilterHierarchyDetail_ID = @ID  
  
        -- Ensure the level beneath the level being deleted (which will become the new topmost level) is visible.  
        UPDATE mdm.tblDerivedHierarchyDetail  
        SET  IsVisible = 1  
            ,LastChgDTM = GETUTCDATE()  
        WHERE   DerivedHierarchy_ID = @DerivedHierarchy_ID  
            AND Level_ID = @Level_ID - 1  
            AND IsVisible = 0;  
  
        --Delete the detail record  
        DELETE FROM mdm.tblDerivedHierarchyDetail WHERE ID = @ID  
  
        -- Recreate the system viw_SYSTEM_[MID]_[HID]_PARENTCHILD_DERIVED view  
        EXEC mdm.udpCreateSystemDerivedHierarchyParentChildView @DerivedHierarchy_ID = @DerivedHierarchy_ID  
  
        -- Note that it is not necessary to call udpSecurityMemberProcessRebuildModel to re-compute member security because the hierarchy being modified is not used for member security (as verified above).  
    END TRY  
  
    BEGIN CATCH  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
        RETURN;      
    END CATCH;  
  
    SET NOCOUNT OFF  
END --proc
go

