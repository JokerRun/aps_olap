/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE VIEW mdm.viw_SYSTEM_SCHEMA_BUSINESSRULES  
/*WITH SCHEMABINDING*/  
AS  
  
WITH brStatusCte AS  
(  
    SELECT   
         OptionID ID  
        ,ListOption Name   
    FROM mdm.tblList   
    WHERE ListCode = CAST(N'lstBRStatus' AS NVARCHAR(50))  
)  
SELECT   
    tMod.ID                 Model_ID  
   ,tMod.MUID               Model_MUID  
   ,tMod.Name               Model_Name  
   ,tBR.Entity_ID           Entity_ID  
   ,tEnt.MUID               Entity_MUID  
   ,tEnt.Name               Entity_Name  
   ,tBR.MemberType_ID       MemberType_ID  
   ,tBR.ID                  BusinessRule_ID  
   ,tBR.MUID                BusinessRule_MUID  
   ,tBR.Name                BusinessRule_Name  
   ,tBR.Description         BusinessRule_Description  
   ,tBR.RuleConditionText   BusinessRule_RuleConditionText  
   ,tBR.RuleActionText      BusinessRule_RuleActionText  
   ,tBR.RuleElseActionText  BusinessRule_RuleElseActionText  
   ,tBR.Status_ID           BusinessRule_StatusID  
   ,tStatus.Name            BusinessRule_StatusName  
   ,tBR.Priority            BusinessRule_Priority  
   ,tBR.NotificationGroupID BusinessRule_NotificationGroupID  
   ,ng.MUID                 BusinessRule_NotificationGroupMUID  
   ,ng.Name                 BusinessRule_NotificationGroupName  
   ,tBR.NotificationUserID  BusinessRule_NotificationUserID  
   ,nu.MUID                 BusinessRule_NotificationUserMUID  
   ,nu.UserName             BusinessRule_NotificationUserName  
   ,tBR.LastChgTS           BusinessRule_LastChgTS  
   ,tBR.EnterUserID         BusinessRule_CreatedUserID  
   ,cu.MUID                 BusinessRule_CreatedUserMUID  
   ,cu.UserName             BusinessRule_CreatedUserName  
   ,tBR.EnterDTM            BusinessRule_DateCreated  
   ,tBR.LastChgUserID       BusinessRule_UpdatedUserID  
   ,uu.MUID                 BusinessRule_UpdatedUserMUID  
   ,uu.UserName             BusinessRule_UpdatedUserName  
   ,tBR.LastChgDTM          BusinessRule_DateUpdated  
FROM mdm.tblBRBusinessRule tBR  
INNER JOIN mdm.tblEntity tEnt  
ON tBR.Entity_ID = tEnt.ID  
INNER JOIN mdm.tblModel tMod   
ON tEnt.Model_ID = tMod.ID  
INNER JOIN brStatusCte tStatus  
ON tBR.Status_ID = tStatus.ID  
LEFT JOIN mdm.tblUserGroup ng  
ON tBR.NotificationGroupID = ng.ID  
LEFT JOIN mdm.tblUser nu  
ON tBR.NotificationUserID = nu.ID  
LEFT JOIN mdm.tblUser cu  
ON tBR.EnterUserID = cu.ID  
LEFT JOIN mdm.tblUser uu  
ON tBR.LastChgUserID = uu.ID
go

