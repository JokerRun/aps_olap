/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
 exec mdm.udpValidationStatusEntitySummaryGet @User_ID=1, @Version_Name=N'Product'  
 exec mdm.udpValidationStatusEntitySummaryGet @User_ID=1, @Version_Name=N'Product', @Entity_Name=N'Product'  
*/  
CREATE PROCEDURE mdm.udpValidationStatusEntitySummaryGet  
(  
     @User_ID                   INT  
    ,@Entity_ID                 INT = NULL  
    ,@Entity_MUID               UNIQUEIDENTIFIER = NULL  
    ,@Entity_Name               NVARCHAR(200) = NULL  
    ,@Version_ID                INT = NULL  
    ,@Version_MUID              UNIQUEIDENTIFIER = NULL  
    ,@Version_Name              NVARCHAR(50) = NULL  
    ,@Model_ID                  INT = NULL OUTPUT  
    ,@Model_MUID                UNIQUEIDENTIFIER = NULL OUTPUT  
    ,@Model_Name                NVARCHAR(50) = NULL OUTPUT  
    ,@CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    DECLARE @SQL                       NVARCHAR(MAX);  
    DECLARE @Table                     sysname;  
    DECLARE @MemberTypeID              INT;  
    DECLARE @MemberType_Leaf           INT = 1;  
    DECLARE @MemberType_Consolidated   INT = 2;  
    DECLARE @MemberType_Hierarchy      INT = 4;  
    DECLARE @EventStatus_NotRunning    TINYINT = 2;  
    DECLARE @Counter                   INT;  
    DECLARE @MaxCounter                INT;  
    DECLARE @CurrentEntity_ID          INT;  
    DECLARE @Permission_Deny		   INT = 1;  
    DECLARE @GuidEmpty                 UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER);  
  
    DECLARE @tblList TABLE   
    (  
        RowNumber       INT IDENTITY (1, 1) PRIMARY KEY CLUSTERED NOT NULL,   
        Entity_ID       INT,   
        MemberTypeID    INT,   
        ValidationTable sysname COLLATE database_default  
    )  
  
    CREATE TABLE #tblEntityValidationCounts   
    (  
       Entity_ID              INT,  
       ValidationStatus_ID    INT,   
       ValidationStatus_Count INT  
    )  
  
    -- Validate version and entity ids  
    SET @Version_Name  = NULLIF(@Version_Name, N'');  
    SET @Entity_Name = NULLIF(@Entity_Name, N'');  
    SET @Version_MUID = NULLIF(@Version_MUID, @GuidEmpty);  
    SET @Entity_MUID = NULLIF(@Entity_MUID, @GuidEmpty);  
    SET @Version_ID = NULLIF(@Version_ID, 0);  
    SET @Entity_ID = NULLIF(@Entity_ID, 0);  
  
    -- Validate version  
    DECLARE @Version_ID_Lookup INT = NULL;   
  
    SELECT   
         @Version_ID = v.ID  
        ,@Version_Name = v.Name  
        ,@Version_MUID = v.MUID  
        ,@Version_ID_Lookup = v.ID -- This column is used to determine in the version exists (or the user has permission to it) because it is not nullable.  
        ,@Model_ID = v.Model_ID  
        ,@Model_MUID = m.MUID  
        ,@Model_Name = m.Name  
    FROM mdm.tblModelVersion v  
    INNER JOIN mdm.tblModel m  
    ON v.Model_ID = m.ID  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_MODEL s  
    ON      v.Model_ID = s.ID  
        AND COALESCE(s.Privilege_ID, @Permission_Deny) <> @Permission_Deny  
        AND s.User_ID = @User_ID  
    WHERE   
            (@Version_MUID IS NOT NULL OR @Version_Name IS NOT NULL OR @Version_ID IS NOT NULL) -- At least one Identifier param must be provided.  
        AND (@Version_MUID IS NULL OR @Version_MUID = v.MUID)  
        AND (@Version_Name IS NULL OR @Version_Name = v.Name)  
        AND (@Version_ID   IS NULL OR @Version_ID  = v.ID)  
  
    IF @Version_ID_Lookup IS NULL  
    BEGIN  
        RAISERROR('MDSERR300006|The supplied version is not valid.', 16, 1);   
        RETURN;  
    END;  
  
    -- If entity ids are provided then validate entity  
    IF @Entity_Name IS NOT NULL OR @Entity_ID IS NOT NULL OR @Entity_MUID IS NOT NULL  
    BEGIN  
        DECLARE @Entity_ID_Lookup INT = NULL;  
  
        SELECT   
             @Entity_ID = e.ID  
            ,@Entity_Name = e.Name  
            ,@Entity_MUID = e.MUID  
            ,@Entity_ID_Lookup = e.ID -- This column is used to determine in the model exists (or the user has permission to it) because it is not nullable.  
        FROM mdm.tblEntity e  
        INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ENTITY s  
        ON      e.ID = s.ID  
            AND COALESCE(s.Privilege_ID, @Permission_Deny) <> @Permission_Deny  
            AND s.User_ID = @User_ID  
        WHERE  
            e.Model_ID = @Model_ID  
            AND (@Entity_MUID IS NULL OR @Entity_MUID = e.MUID)  
            AND (@Entity_Name IS NULL OR @Entity_Name = e.Name)  
            AND (@Entity_ID   IS NULL OR @Entity_ID  = e.ID)  
  
        IF @Entity_ID_Lookup IS NULL  
        BEGIN  
            RAISERROR('MDSERR300008|The supplied entity is not valid.', 16, 1);  
            RETURN;  
        END;  
  
    END  
  
    --Seed table with entities, each with validation statuses and counts of zero  
    INSERT INTO #tblEntityValidationCounts   
    SELECT   
        e.ID  
        ,CAST(list.OptionID AS INT)  
        ,0  -- initial count of zero  
    FROM mdm.tblEntity e  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ENTITY s   
    ON e.ID = s.ID  
    CROSS JOIN mdm.tblList list  
    WHERE   
            e.Model_ID = @Model_ID  
        AND (@Entity_ID IS NULL OR @Entity_ID = e.ID)  
        AND COALESCE(s.Privilege_ID, @Permission_Deny) <> @Permission_Deny   
        AND s.User_ID = @User_ID  
        AND list.ListCode = N'lstValidationStatus'  
        AND list.IsVisible = 1  
    ORDER BY   
        e.ID  
        ,list.Seq;  
  
    --Get the list of member tables  
    INSERT INTO @tblList  
        SELECT   
            e.ID AS Entity_ID  
            ,@MemberType_Leaf AS MemberTypeID  
            ,EntityTable AS ValidationTable  
        FROM   
            [mdm].tblEntity e  
        INNER JOIN [mdm].viw_SYSTEM_SECURITY_USER_ENTITY s ON e.ID = s.ID  
            AND COALESCE(s.Privilege_ID, @Permission_Deny) <> @Permission_Deny   
            AND s.User_ID = @User_ID  
        WHERE   
            e.Model_ID = @Model_ID   
            AND (@Entity_ID IS NULL OR e.ID = @Entity_ID)  
      UNION ALL  
        SELECT   
            e.ID AS Entity_ID  
            ,@MemberType_Consolidated  
            ,HierarchyParentTable   
        FROM   
            [mdm].tblEntity e  
        INNER JOIN [mdm].viw_SYSTEM_SECURITY_USER_ENTITY s ON e.ID = s.ID  
            AND COALESCE(s.Privilege_ID, @Permission_Deny) <> @Permission_Deny   
            AND s.User_ID = @User_ID  
        WHERE   
            e.Model_ID = @Model_ID   
            AND HierarchyParentTable IS NOT NULL   
            AND (@Entity_ID IS NULL OR e.ID = @Entity_ID)  
      UNION ALL  
        SELECT   
            e.ID AS Entity_ID  
            ,@MemberType_Hierarchy  
            ,HierarchyTable   
        FROM   
            [mdm].tblEntity e  
        INNER JOIN [mdm].viw_SYSTEM_SECURITY_USER_ENTITY s ON e.ID = s.ID  
            AND COALESCE(s.Privilege_ID, @Permission_Deny) <> @Permission_Deny   
            AND s.User_ID = @User_ID  
        WHERE   
            e.Model_ID = @Model_ID   
            AND HierarchyTable IS NOT NULL   
            AND @Entity_ID IS NULL  
  
  
    ----Loop through each member table getting the validation status counts  
    SET @Counter = 1;  
    SET @MaxCounter = (SELECT MAX(RowNumber) FROM @tblList);  
  
    WHILE @Counter <= @MaxCounter  
    BEGIN  
       SELECT   
            @MemberTypeID = MemberTypeID  
            ,@Table = ValidationTable  
            ,@CurrentEntity_ID = Entity_ID  
       FROM @tblList WHERE [RowNumber] = @Counter  
  
       IF (@MemberTypeID <> @MemberType_Hierarchy)  
       BEGIN  
           SET @SQL =   
           N'  
           WITH cteCounts AS  
           (  
               SELECT ValidationStatus_ID, COUNT(*) AS ValCnt  
               FROM  [mdm].' + QUOTENAME(@Table) + N'    
               WHERE Status_ID = 1   
               GROUP BY ValidationStatus_ID  
           )  
           UPDATE #tblEntityValidationCounts  
           SET   
               ValidationStatus_Count = ValidationStatus_Count + ValCnt  
           FROM #tblEntityValidationCounts vc  
           INNER JOIN cteCounts ON cteCounts.ValidationStatus_ID = vc.ValidationStatus_ID  
           WHERE Entity_ID = @CurrentEntity_ID  
           '  
       END  
       ELSE  
       BEGIN  
           --We are only concerned about LevelNumber = -1 from the HR table.  These records need their LevelNumber recalculated.  
           SET @SQL =   
           N'  
           WITH cteCounts AS  
           (  
               SELECT 4 ValidationStatus_ID, COUNT(*) AS ValCnt  
                  FROM  [mdm].' + QUOTENAME(@Table) + N'  
                  WHERE Status_ID = 1 AND LevelNumber = -1  
           )  
           UPDATE #tblEntityValidationCounts  
           SET   
              ValidationStatus_Count = ValidationStatus_Count + ValCnt  
           FROM #tblEntityValidationCounts vc  
           INNER JOIN cteCounts ON cteCounts.ValidationStatus_ID = vc.ValidationStatus_ID  
           WHERE Entity_ID = @CurrentEntity_ID  
           '  
       END			  
       EXEC sp_executesql @SQL, N'@CurrentEntity_ID INT', @CurrentEntity_ID;  
        SET @Counter += 1;  
    END  
  
    --Return validation results per entity  
    SELECT     
       ent.ID AS [Entity_ID],  
       ent.Name AS [Entity_Name],  
       ent.MUID AS [Entity_MUID],  
       ValidationStatus_ID  AS [ValidationID],  
       ValidationStatus_Count AS [Count]  
    FROM    
       #tblEntityValidationCounts vc  
    INNER JOIN [mdm].tblEntity ent ON vc.Entity_ID = ent.ID;  
  
    --Return last validated dtm for model  
    SELECT LastChgDTM AS [VersionLastValidated], Version_ID  
    FROM [mdm].tblEvent   
    WHERE  
        Version_ID = @Version_ID AND  
        EventName = N'ValidateVersion' AND  
        EventStatus_ID = @EventStatus_NotRunning;  
  
    --Return last validated dtm for entity  
    SELECT LastChgDTM AS [EntityLastValidated], Version_ID, Entity_ID  
    FROM [mdm].tblEvent   
    WHERE   
        Version_ID = @Version_ID AND  
        (@Entity_ID IS NULL OR Entity_ID = @Entity_ID) AND  
        EventName = N'ValidateEntity' AND  
        EventStatus_ID = @EventStatus_NotRunning;  
              
    SET NOCOUNT OFF  
END --proc
go

