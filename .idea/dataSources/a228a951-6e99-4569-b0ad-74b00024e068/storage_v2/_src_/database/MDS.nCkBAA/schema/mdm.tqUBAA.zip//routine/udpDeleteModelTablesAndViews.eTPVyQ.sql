/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================      
  
EXEC mdm.udpDeleteModelTablesAndViews @Model_ID = 2;  
  
*/  
CREATE PROCEDURE mdm.udpDeleteModelTablesAndViews  
(  
    @Model_ID	INT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON;  
  
    --Start transaction, being careful to check if we are nested  
    DECLARE @TranCounter                INT,  
            @SQL                        NVARCHAR(MAX),  
            @ChangesetTable             SYSNAME,  
            @TransactionTableName       SYSNAME,  
            @AnnotationTableName        SYSNAME,  
            @TransactionViewName        SYSNAME,  
            @AnnotationViewName         SYSNAME,  
            @ValidationLogTableName     SYSNAME,  
            @ValidationLogViewName      SYSNAME,  
            @UserValidationViewName     SYSNAME;  
  
    --Set up table and view names  
    SET @ChangesetTable = CONCAT(N'tbl_', @Model_ID, N'_CS');  
    SET @TransactionTableName = mdm.udfGetTransactionTableName(@Model_ID);  
    SET @AnnotationTableName = mdm.udfGetTransactionAnnotationTableName(@Model_ID);  
    SET @TransactionViewName = mdm.udfGetTransactionViewName(@Model_ID);  
    SET @AnnotationViewName = mdm.udfGetTransactionAnnotationViewName(@Model_ID);  
    SET @ValidationLogTableName = mdm.udfGetValidationLogTableName(@Model_ID);  
    SET @ValidationLogViewName = mdm.udfGetValidationLogViewName(@Model_ID);  
    SET @UserValidationViewName = mdm.udfGetUserValidationViewName(@Model_ID);  
  
    --Create the transaction table  
    SET @SQL = CONCAT(N'  
    DROP TABLE [mdm].', QUOTENAME(@ChangesetTable), N';  
    DROP VIEW [mdm].', QUOTENAME(@AnnotationViewName), N';  
    DROP VIEW [mdm].', QUOTENAME(@TransactionViewName), N';  
    DROP TABLE [mdm].', QUOTENAME(@AnnotationTableName), N';  
    DROP TABLE [mdm].', QUOTENAME(@TransactionTableName), N';  
    DROP VIEW [mdm].', QUOTENAME(@UserValidationViewName), N'  
    DROP VIEW [mdm].', QUOTENAME(@ValidationLogViewName), N';  
    DROP TABLE [mdm].', QUOTENAME(@ValidationLogTableName), N';');  
    EXEC sp_executesql @SQL;  
  
    SET NOCOUNT OFF;  
END; --proc
go

