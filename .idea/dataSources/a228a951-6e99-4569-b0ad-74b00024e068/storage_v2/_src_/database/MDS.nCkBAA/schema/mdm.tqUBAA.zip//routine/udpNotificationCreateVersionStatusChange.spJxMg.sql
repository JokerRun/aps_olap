/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    select * from mdm.viw_SYSTEM_SCHEMA_VERSION where ID = 20;  
  
    EXEC mdm.udpNotificationCreateVersionStatusChange 1, 20, 1;  
  
    SELECT * FROM mdm.tblNotificationQueue;  
*/  
CREATE PROCEDURE mdm.udpNotificationCreateVersionStatusChange  
(  
     @User_ID INT  
    ,@Version_ID INT  
    ,@PriorStatus_ID INT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE   
        @NotificationType INT = 2,  
        @LocalizedPriorStatus NVARCHAR(MAX) = N'',  
        @LocalizedNewStatus NVARCHAR(MAX) = N'',  
        @CurrentLanguageCode INT = 1033, -- Default language code is English (US).  
        @StringLanguageCode NVARCHAR(MAX) = N'';  
  
    IF (@NotificationType IS NULL) BEGIN  
        RAISERROR('MDSERR100028|Notification Type ''Validation Issue'' not found.', 16, 1);  
        RETURN;    
    END; --if  
  
    -- Use default language code to get the notification language code.  
    SELECT @StringLanguageCode = mdm.udfLocalizedStringGet(N'NotificationLCID', @CurrentLanguageCode, 1033);  
      
    IF @StringLanguageCode <> N'' BEGIN  
        SELECT @CurrentLanguageCode = CONVERT(INT, @StringLanguageCode)  
    END; -- if  
  
    SELECT @LocalizedPriorStatus = L.[ListOption] FROM mdm.tblList L WHERE L.ListCode = N'lstVersionStatus' AND L.OptionID = @PriorStatus_ID;  
    SELECT @LocalizedNewStatus = v.[Status] FROM mdm.viw_SYSTEM_SCHEMA_VERSION v WHERE v.ID = @Version_ID;  
  
    -- Get the localized message texts based on the notification language code in tblLocalizedStrings.  
    SELECT @LocalizedPriorStatus = mdm.udfLocalizedStringGet(CONCAT(N'NotificationVersionStatus', @LocalizedPriorStatus), @CurrentLanguageCode, @LocalizedPriorStatus);  
    SELECT @LocalizedNewStatus = mdm.udfLocalizedStringGet(CONCAT(N'NotificationVersionStatus', @LocalizedNewStatus), @CurrentLanguageCode, @LocalizedNewStatus);  
              
    SELECT @LocalizedPriorStatus = IsNULL(@LocalizedPriorStatus, N'');  
    SELECT @LocalizedNewStatus = IsNULL(@LocalizedNewStatus, N'');  
      
    BEGIN TRAN  
        DECLARE @newQueueRecord AS TABLE (ID INT, Model_ID INT);  
          
        INSERT INTO mdm.tblNotificationQueue (  
             NotificationType_ID  
            ,Version_ID  
            ,Model_ID  
            ,[Message]  
            ,EnterDTM  
            ,EnterUserID  
        )  
        OUTPUT inserted.ID, inserted.Model_ID INTO @newQueueRecord  
        SELECT    
            @NotificationType  
            ,v.ID  
            ,v.Model_ID  
            ,CONCAT(N'  
                <notification>  
                  <model>', (SELECT v.[Model_Name] FOR XML PATH('')), N'</model>  
                  <model_muid>', v.[MUID], N'</model_muid>  
                  <version>', (SELECT v.[Name] FOR XML PATH('')), N'</version>  
                  <version_description>', (SELECT v.[Description] FOR XML PATH('')), N'</version_description>  
                  <version_muid>', v.[MUID], N'</version_muid>  
                  <prior_status>', (SELECT @LocalizedPriorStatus FOR XML PATH('')), N'</prior_status>  
                  <new_status>', (SELECT @LocalizedNewStatus FOR XML PATH('')), N'</new_status>  
                  <issued>', (SELECT CONVERT(NVARCHAR,GETDATE()) FOR XML PATH('')), N'</issued>  
                </notification>')  
            ,GETUTCDATE()  
            ,@User_ID  
        FROM mdm.viw_SYSTEM_SCHEMA_VERSION v   
        WHERE v.ID = @Version_ID  
  
        IF (@@ERROR <> 0) BEGIN  
            RAISERROR('MDSERR100029|Cannot insert into notification queue because of general insert error.', 16, 1);  
            ROLLBACK TRAN;  
            RETURN;    
        END; --if  
  
        DECLARE @ModelUserList TABLE (  
             RowNumber INT IDENTITY(1,1) NOT NULL  
            ,ID INT  
            ,UserName NVARCHAR(MAX) COLLATE database_default  
            ,Name NVARCHAR(MAX) COLLATE database_default  
            ,Description NVARCHAR(MAX) COLLATE database_default  
            ,EmailAddress NVARCHAR(MAX) COLLATE database_default  
            ,Privilege_ID INT  
            ,AccessPermission TINYINT  
            );  
  
        DECLARE   
             @newQueueID INT  
            ,@Model_ID INT  
            ,@ModelObject_ID INT = 1  
            ,@DenyPriviledge INT = 1;  
  
        SELECT  
             @newQueueID = q.ID  
            ,@Model_ID = q.Model_ID  
        FROM @newQueueRecord q;  
                              
        INSERT INTO @ModelUserList EXECUTE mdm.udpUserListGetByItem @ModelObject_ID, @Model_ID   
          
        -- Insert into mdm.tblNotificationUsers  
        INSERT INTO mdm.tblNotificationUsers (  
            Notification_ID,  
            [User_ID]  
        )  
        SELECT @newQueueID, u.[ID]  
        FROM @ModelUserList u  
        WHERE u.Privilege_ID <> @DenyPriviledge;  
          
        IF (@@ERROR <> 0) BEGIN  
            RAISERROR('MDSERR100030|Cannot insert into notification users because of general insert error.', 16, 1);  
            ROLLBACK TRAN;  
            RETURN;    
        END; --if  
  
    COMMIT TRAN;  
  
    SET NOCOUNT OFF;  
END; --proc
go

