/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Saves (creates or updates) an AttributeGroup  
  
*/  
CREATE PROCEDURE mdm.udpAttributeGroupSave  
(  
    @User_ID            INT,  
    @Version_ID         INT, -- Caller should validate. Used for audit info.  
    @Model_ID           INT, -- Caller should validate  
    @Entity_ID          INT, -- Caller should validate  
    @IsHierarchyEnabled     BIT,  
    @IsCollectionEnabled    BIT,  
    @DataCompression        TINYINT,  
    @MemberType_ID      TINYINT = NULL,  
    @MUID               UNIQUEIDENTIFIER = NULL,  
    @Name               NVARCHAR(50),  
    @SortOrder          INT = NULL,  
    @FreezeNameCode     BIT = 0,  
    @IsSystem           BIT = 0,  
    @EditMode           TINYINT = 0, --0: Create, 1: Update, 4: Clone, defaults to Create  
    @Return_ID          INT = NULL OUTPUT,  
    @Return_MUID        UNIQUEIDENTIFIER = NULL OUTPUT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON;  
  
    SET @Return_ID = NULL;  
    SET @Return_MUID = NULL;  
  
  
    DECLARE @CurrentDTM             AS DATETIME2(3),  
            @GuidEmpty              UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER),  
            @EditMode_Create        TINYINT = 0,  
            @EditMode_Update        TINYINT = 1,  
            @EditMode_Clone         TINYINT = 4,  
            @ExistingAttributeGroup_MUID UNIQUEIDENTIFIER = NULL,  
            @ExistingAttributeGroup_ID   INT = NULL,  
            @ExistingAttributeGroupName  NVARCHAR(MAX),  
  
            @MemberType_Leaf           TINYINT = 1,  
            @MemberType_Consolidated   TINYINT = 2,  
            @MemberType_Collection     TINYINT = 3,  
  
            @TableOptions           NVARCHAR(MAX) = N'',  
            @IndexOptions           NVARCHAR(MAX) = N'';  
  
    --Initialize output parameters and local variables  
    SELECT  
        @Name = NULLIF(LTRIM(RTRIM(@Name)), N''), --Convert empty @Name to NULL  
        @FreezeNameCode = ISNULL(@FreezeNameCode, 0), --Convert NULL @FreezeNameCode to 0  
        @IsSystem = ISNULL(@IsSystem, 0), --Convert NULL @IsSystem to 0  
        @Return_ID = NULL,  
        @CurrentDTM = GETUTCDATE(),  
        @Entity_ID = NULLIF(@Entity_ID, 0),  
        @MUID = NULLIF(@MUID, @GuidEmpty),  
        @Name = NULLIF(LTRIM(RTRIM(@Name)), N'');  
  
    BEGIN TRY  
  
        -- When creating collection member attributes, ensure the collection tables have been created.  
        IF @MemberType_ID = @MemberType_Collection AND @IsCollectionEnabled = 0  
        BEGIN  
            DECLARE @TableName SYSNAME;  
            SET @TableOptions = mdm.udfGetTableOptions(@DataCompression, @Model_ID);  
            SET @IndexOptions = mdm.udfGetIndexOptions(@DataCompression, @Model_ID);  
  
            EXEC mdm.udpCollectionTablesCreate @User_ID, @Model_ID, @Version_ID, @Entity_ID, @IsHierarchyEnabled, @TableOptions, @IndexOptions, @TableName OUTPUT;  
            SET @IsCollectionEnabled = 1;  
        END; --if  
  
        --If we are in the Update or Clone mode get the missing pieces of the identifier  
        IF @EditMode IN (@EditMode_Update, @EditMode_Clone)  
        BEGIN  
            --Only use the name if the MUID is not available. This is important because we don't want  
            --to look up by name if the name is what the user is trying to update.  
            IF @MUID IS NULL  
            BEGIN  
                SELECT TOP 1  
                    @ExistingAttributeGroup_ID =  ID,  
                    @ExistingAttributeGroup_MUID = MUID,  
                    @ExistingAttributeGroupName = Name  
                FROM mdm.tblAttributeGroup  
                WHERE  
                    --Filter by member type too  
                    MemberType_ID = @MemberType_ID AND  
                    [Name] = @Name AND  
                    Entity_ID = @Entity_ID;  
            END  
            --Use the Attribute group MUID to look up the full identifier  
            ELSE  
            BEGIN  
                SELECT  
                    @ExistingAttributeGroup_ID =  ID,  
                    @ExistingAttributeGroup_MUID = MUID,  
                    @ExistingAttributeGroupName = Name  
                FROM mdm.tblAttributeGroup  
                WHERE  
                    MemberType_ID = @MemberType_ID AND  
                    MUID = @MUID AND  
                    Entity_ID = @Entity_ID;  
            END  
  
            --If we are in the Clone mode we need to figure out whether we are creating or updating an attribute group  
            IF @EditMode = @EditMode_Clone  
            BEGIN  
                --If there is no existing attribute group then set the edit mode to Create  
                IF @ExistingAttributeGroup_MUID IS NULL AND @ExistingAttributeGroup_ID IS NULL  
                BEGIN  
                    SET @EditMode = @EditMode_Create;  
                END  
                --If there is an existing attribute group then set the edit mode to Update  
                ELSE  
                BEGIN  
                    SET @EditMode = @EditMode_Update;  
                    SET @MUID = @ExistingAttributeGroup_MUID;  
                END  
            END  
            --If we are in Update mode and could not find a matching existing attribute group we need to raise an error and quit now  
            ELSE IF @EditMode = @EditMode_Update  
            BEGIN  
                IF @ExistingAttributeGroup_ID IS NULL OR @ExistingAttributeGroup_MUID IS NULL  
                BEGIN  
                    --On error, return NULL results  
                    SELECT @Return_ID = NULL, @Return_MUID = NULL;  
                    RAISERROR('MDSERR110007|The ID is not valid.', 16, 1);  
                    RETURN;  
                END  
                ELSE  
                BEGIN  
                    SET @MUID = @ExistingAttributeGroup_MUID;  
                END  
            END  
        END  
  
        --If the edit mode is Create. This code also needs to execute if the user sent in EditMode clone which ended up becoming Create (hence the IF instead of ELSE IF)  
        IF @EditMode = @EditMode_Create  
        BEGIN  
  
            --If @MUID is not null then we need to ensure it does not already exist (since this is a create)  
            IF @MUID IS NOT NULL AND EXISTS(SELECT * FROM mdm.tblAttributeGroup WHERE MUID = @MUID)  
            BEGIN  
                --On error, return NULL results  
                SELECT @Return_ID = NULL, @Return_MUID = NULL;  
                RAISERROR('MDSERR110007|The ID is not valid.', 16, 1);  
                RETURN;  
            END  
        END  
  
        --Test for invalid parameters  
        IF (@Entity_ID IS NULL OR @User_ID IS NULL)  
            OR (@ExistingAttributeGroup_ID IS NULL AND (@MemberType_ID IS NULL OR @Name IS NULL OR @MemberType_ID NOT IN (@MemberType_Leaf, @MemberType_Consolidated, @MemberType_Collection))) --INSERT: Requires these params to be populated  
            OR (@ExistingAttributeGroup_ID IS NOT NULL AND @MemberType_ID IS NOT NULL AND @MemberType_ID NOT IN (@MemberType_Leaf, @MemberType_Consolidated, @MemberType_Collection)) --UPDATE: Invalid @MemberType_ID  
            OR (@SortOrder IS NOT NULL AND @SortOrder < 0) --Invalid @SortOrder  
        BEGIN  
            RAISERROR('MDSERR100010|The Parameters are not valid.', 16, 1);  
            RETURN;  
        END; --if  
  
        --Check the name of the attribute group for duplicates  
        IF EXISTS  
        (  
            SELECT 1 FROM  
            mdm.tblAttributeGroup  
            WHERE  
                @Name = Name AND  
                (@MUID IS NULL OR MUID <> @MUID) AND  
                Entity_ID = @Entity_ID AND  
                MemberType_ID = @MemberType_ID  
        )  
        BEGIN  
            --On error, return NULL resultsudpSecurityPrivilegesSave  
            SELECT @Return_ID = NULL, @Return_MUID = NULL;  
            RAISERROR('MDSERR110003|The name already exists. Type a different name.', 16, 1);  
            RETURN;  
        END  
  
        --Update/Insert Attribute Group details  
        IF @EditMode = @EditMode_Update  
        --Update Attribute Group  
        BEGIN  
            UPDATE mdm.tblAttributeGroup   
            SET  
                [Name] = ISNULL(@Name, [Name]),  
                SortOrder = ISNULL(@SortOrder, SortOrder),  
                FreezeNameCode = ISNULL(@FreezeNameCode, FreezeNameCode),  
                LastChgDTM = @CurrentDTM,  
                LastChgUserID = @User_ID  
            WHERE  
                ID = @ExistingAttributeGroup_ID;  
  
            --Populate output parameters  
            SELECT @Return_MUID = @ExistingAttributeGroup_MUID  
  
        END  
        ELSE  
        --New Attribute Group  
        BEGIN  
            --Accept an explicit MUID (for clone operations) or generate a new one  
            SET @Return_MUID = ISNULL(@MUID, NEWID());  
  
            INSERT INTO mdm.tblAttributeGroup  
            (  
                 [Entity_ID]  
                ,[MemberType_ID]  
                ,[Name]  
                ,[SortOrder]  
                ,FreezeNameCode  
                ,[IsSystem]  
                ,[MUID]  
                ,[EnterDTM]  
                ,[EnterUserID]  
                ,[EnterVersionID]  
                ,[LastChgDTM]  
                ,[LastChgUserID]  
                ,[LastChgVersionID]  
            )  
            SELECT  
                @Entity_ID,  
                @MemberType_ID,  
                @Name,  
                ISNULL(MAX(SortOrder), 0) + 1,  
                @FreezeNameCode,  
                @IsSystem,  
                @Return_MUID,  
                @CurrentDTM,  
                @User_ID,  
                @Version_ID,  
                @CurrentDTM,  
                @User_ID,  
                @Version_ID  
            FROM  
                mdm.tblAttributeGroup  
            WHERE  
                    Entity_ID = @Entity_ID  
                AND MemberType_ID = @MemberType_ID;  
  
            --Save the identity value  
            SET @ExistingAttributeGroup_ID = SCOPE_IDENTITY();  
  
            -- Allow the creating user to see the new Attribute Group  
            EXEC mdm.udpSecurityPrivilegesSave  
                @SystemUser_ID = @User_ID,  
                @Principal_ID = @User_ID,  
                @PrincipalType_ID = 1, -- User  
                @RoleAccess_ID = NULL,  
                @Object_ID = 5, --AttributeGroup,  
                @Privilege_ID = 4, -- Access  
                @AccessPermission = 7, -- all  
                @Model_ID = @Model_ID,  
                @Securable_ID = @ExistingAttributeGroup_ID,  
                @Securable_Name = @Name;  
  
        END; --if  
  
        --Return values  
        SET @Return_ID = @ExistingAttributeGroup_ID;  
        RETURN;  
  
    END TRY  
    --Compensate as necessary  
    BEGIN CATCH  
  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
  
        --On error, return NULL results  
        SELECT @Return_ID = NULL, @Return_MUID = NULL;  
        RETURN;  
  
    END CATCH;  
  
    SET NOCOUNT OFF;  
END; --proc
go

