/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
      
    SELECT mdm.udfViewNameGetByID(42,NULL,0)  
*/  
CREATE FUNCTION mdm.udfViewNameGetByID  
(  
    @Entity_ID      INT,  
    @MemberType_ID  TINYINT = NULL,  
    @IsExplodedView BIT = 0, -- When 1, adds a 'EXP' suffix to the view name, which is exploded by hierarchy parent  
    @ViewType       TINYINT = 0 -- 0 EN, 1 PD, 2 HS  
)   
RETURNS sysname  
/*WITH SCHEMABINDING*/  
AS BEGIN  
    DECLARE @ViewName       SYSNAME,  
            @MemberType_Leaf                    TINYINT = 1,  
            @MemberType_Consolidated            TINYINT = 2,  
            @MemberType_Collection              TINYINT = 3,  
            @MemberType_ParentChild             TINYINT = 4,  
            @MemberType_CollectionParentChild   TINYINT = 5;  
  
    SELECT @ViewName = mdm.udfViewNameGet(Model_ID, @Entity_ID, @MemberType_ID, @IsExplodedView, @ViewType)  
    FROM mdm.tblEntity   
    WHERE ID = @Entity_ID  
        -- Ensure that the requested member type is supported  
        AND (@MemberType_ID = @MemberType_Leaf -- Leaf is always supported  
            OR (@MemberType_ID IN (@MemberType_Collection, @MemberType_CollectionParentChild) AND CollectionTable IS NOT NULL)  
            OR (@MemberType_ID IN (@MemberType_Consolidated, @MemberType_ParentChild) AND HierarchyTable IS NOT NULL)  
            )  
      
    RETURN @ViewName;  
END; --fn
go

