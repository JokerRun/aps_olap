/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE VIEW mdm.viw_SYSTEM_SECURITY_ROLE  
/*WITH SCHEMABINDING*/  
AS  
--Model permissions  
SELECT  
    tModSec.Role_ID,  
    tModSec.Model_ID,  
    tModSec.Privilege_ID Model_PrivilegeID,  
    tModSec.AccessPermission Model_AccessPermission,  
    1 Model_IsExplicit,  
    0 Entity_ID,  
    0 Entity_PrivilegeID,  
    0 Entity_AccessPermission,  
    0 Entity_IsExplicit,  
    0 MemberType_ID,  
    0 MemberType_PrivilegeID,  
    0 MemberType_AccessPermission,  
    0 MemberType_IsExplicit,  
    0 Attribute_ID,  
    0 Attribute_PrivilegeID,  
    0 Attribute_AccessPermission,  
    0 Attribute_IsExplicit  
FROM  
   mdm.tblSecurityRoleAccess  tModSec  
WHERE Object_ID = 1  
  
--Entity permissions (leaf member, consolidation, and collection member type security is defined at the entity level; i.e., the Securable_ID represents the entity)  
UNION ALL  
SELECT  
    tEntSec.Role_ID,  
    tEnt.Model_ID,  
    CASE tEntSec.Privilege_ID WHEN 1 THEN NULL ELSE 99 END Model_PrivilegeID,  
    0 Model_AccessPermission,  
    0 Model_IsExplicit,  
    tEnt.ID Entity_ID,  
    tEntSec.Privilege_ID Entity_PrivilegeID,  
    tEntSec.AccessPermission Entity_AccessPermission,  
    1 Entity_IsExplicit,  
    0 MemberType_ID,  
    0 MemberType_PrivilegeID,  
    0 MemberType_AccessPermission,  
    0 MemberType_IsExplicit,  
    0 Attribute_ID,  
    0 Attribute_PrivilegeID,  
    0 Attribute_AccessPermission,  
    0 Attribute_IsExplicit  
FROM mdm.tblEntity tEnt  
JOIN mdm.tblSecurityRoleAccess tEntSec  
     ON Object_ID = 3  
     AND tEnt.ID = tEntSec.Securable_ID  
  
--Member type permissions (leaf member, consolidation, and collection member type security is defined at the entity level; i.e., the Securable_ID represents the entity)  
UNION ALL  
SELECT  
    tTypSec.Role_ID,  
    tEnt.Model_ID,  
    CASE tTypSec.Privilege_ID WHEN 1 THEN NULL ELSE 99 END Model_PrivilegeID,  
    0 Model_AccessPermission,  
    0 Model_IsExplicit,  
    tEnt.ID Entity_ID,  
    CASE tTypSec.Privilege_ID WHEN 1 THEN NULL ELSE 99 END Entity_PrivilegeID,  
    0 Entity_AccessPermission,  
    0 Entity_IsExplicit,  
    Object_ID-7 MemberType_ID,  
    tTypSec.Privilege_ID MemberType_PrivilegeID,  
    tTypSec.AccessPermission MemberType_AccessPermission,  
    1 MemberType_IsExplicit,  
    0 Attribute_ID,  
    0 Attribute_PrivilegeID,  
    0 Attribute_AccessPermission,  
    0 Attribute_IsExplicit  
FROM mdm.tblEntity tEnt  
JOIN mdm.tblSecurityRoleAccess tTypSec  
  ON Object_ID BETWEEN 8 AND 10  
  AND tEnt.ID = tTypSec.Securable_ID  
  
UNION ALL  
--Attribute permissions  
SELECT  
    tAttSec.Role_ID,  
    tEnt.Model_ID,  
    CASE tAttSec.Privilege_ID WHEN 1 THEN NULL ELSE 99 END Model_PrivilegeID,  
    0 Model_AccessPermission,  
    0 Model_IsExplicit,  
    tAtt.Entity_ID,  
    CASE tAttSec.Privilege_ID WHEN 1 THEN NULL ELSE 99 END Entity_PrivilegeID,  
    0 Entity_AccessPermission,  
    0 Entity_IsExplicit,  
    tAtt.MemberType_ID,  
    CASE tAttSec.Privilege_ID WHEN 1 THEN NULL ELSE 99 END MemberType_PrivilegeID,  
    0 MemberType_AccessPermission,  
    0 MemberType_IsExplicit,  
    tAtt.ID Attribute_ID,  
    tAttSec.Privilege_ID Attribute_PrivilegeID,  
    tAttSec.AccessPermission Attribute_AccessPermission,  
    1 Attribute_IsExplicit  
FROM mdm.tblAttribute tAtt  
JOIN mdm.tblSecurityRoleAccess tAttSec  
  ON Object_ID = 4  
  AND tAtt.ID = tAttSec.Securable_ID  
JOIN mdm.tblEntity tEnt ON tAtt.Entity_ID = tEnt.ID  
  
UNION ALL  
  
--DBA: If entity is referred by DBA, and DBA permission is Access, then referred entity leaf name and code are inferred read.  
--     The permission could come from entity, membertype and attribute permission of dest entity.  
SELECT  
    referredEntity.Role_ID,  
    tEnt.Model_ID,  
    99 Model_PrivilegeID,  
    0 Model_AccessPermission,  
    0 Model_IsExplicit,  
    refa.Entity_ID,  
    99,  
    0 Entity_AccessPermission,  
    0 Entity_IsExplicit,  
    refa.MemberType_ID,  
    99,  
    0 MemberType_AccessPermission,  
    0 MemberType_IsExplicit,  
    refa.ID Attribute_ID,  
    4 Attribute_PrivilegeID,  
    0 Attribute_AccessPermission,  
    0 Attribute_IsExplicit -- Can be overwritten by MemberType  
FROM  
mdm.tblAttribute refa  
INNER JOIN (  
    SELECT Role_ID AS Role_ID, SourceEntityID AS Entity_ID  
    FROM(  
        SELECT sec.Role_ID AS Role_ID, dba.Entity_ID AS DestEntityId, DomainEntity_ID AS SourceEntityID, MIN(sec.Privilege_ID) AS Privilege_ID  
        FROM mdm.tblAttribute dba  
        INNER JOIN mdm.tblSecurityRoleAccess sec  
            ON ((Object_ID = 3 AND sec.Securable_ID = dba.Entity_ID) -- Any dba attribute on this entity  
               -- Do not use between which leading to bad excution plan  
               OR (Object_ID = 8 AND sec.Securable_ID = dba.Entity_ID AND dba.MemberType_ID = 1) --Any dba attribute on this leaf type  
               OR (Object_ID = 9 AND sec.Securable_ID = dba.Entity_ID AND dba.MemberType_ID = 2) --Any dba attribute on this consolidate type  
               OR (Object_ID = 10 AND sec.Securable_ID = dba.Entity_ID AND dba.MemberType_ID = 3) --Any dba attribute on this collection type  
               OR (Object_ID = 4 AND sec.Securable_ID = dba.ID)) --Any dba attribute  
        WHERE dba.DomainEntity_ID IS NOT NULL  
                AND dba.DomainEntity_ID != dba.Entity_ID -- Exclude self reference  
        GROUP BY sec.Role_ID, dba.Entity_ID, dba.DomainEntity_ID  
        ) AS referredEntityPerDest  
    GROUP BY Role_ID, SourceEntityID  
    HAVING MAX(Privilege_ID) = 4  
    ) AS referredEntity  
    ON ((refa.IsCode = 1 OR refa.IsName = 1) /*Name And Code*/  
        AND refa.Entity_ID = referredEntity.Entity_ID  
        AND refa.MemberType_ID = 1) -- Always refer leaf member  
INNER JOIN mdm.tblEntity tEnt ON refa.Entity_ID = tEnt.ID  
  
UNION ALL  
--DBA: If referred entity is permission deny, the DBA should be deny regardless.  
--     The permission could come from entity and membertype of referred entity.  
SELECT  
    sec.Role_ID,  
    tEnt.Model_ID,  
    99 Model_PrivilegeID,  
    0 Model_AccessPermission,  
    0 Model_IsExplicit,  
    dba.Entity_ID,  
    99,  
    0 Entity_AccessPermission,  
    0 Entity_IsExplicit,  
    dba.MemberType_ID,  
    99,  
    0 MemberType_AccessPermission,  
    0 MemberType_IsExplicit,  
    dba.ID Attribute_ID,  
    1 Attribute_PrivilegeID,  
    0 Attribute_AccessPermission,  
    1 Attribute_IsExplicit -- Cannot be overwritten by MemberType  
FROM  
mdm.tblAttribute dba  
INNER JOIN mdm.tblSecurityRoleAccess sec  
    ON dba.DomainEntity_ID IS NOT NULL  
       AND ((Object_ID = 3 AND sec.Securable_ID = dba.DomainEntity_ID) -- Entity is deny  
           OR (Object_ID = 8 AND sec.Securable_ID = dba.DomainEntity_ID AND dba.MemberType_ID = 1)) --Leaf is deny  
INNER JOIN mdm.tblEntity tEnt ON dba.Entity_ID = tEnt.ID  
WHERE sec.Privilege_ID = 1 /*Deny*/
go

