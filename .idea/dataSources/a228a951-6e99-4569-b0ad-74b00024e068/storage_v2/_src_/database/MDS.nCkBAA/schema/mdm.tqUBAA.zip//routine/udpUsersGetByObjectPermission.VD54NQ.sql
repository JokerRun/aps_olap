/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
-- Get all user with effective permissions of all models  
EXEC mdm.udpUsersGetByObjectPermission @User_ID = 1, @ObjectType = 1  
  
-- Get all user with effective permissions of entities under model product  
EXEC mdm.udpUsersGetByObjectPermission @User_ID = 1, @ObjectType = 5, @Model_Name = N'Product'  
  
-- Get all user with effective permissions of leaf membertpye of entity product/product  
EXEC mdm.udpUsersGetByObjectPermission @User_ID = 1, @ObjectType = 8, @Model_Name = N'Product', @Entity_Name = N'Product'  
  
-- Get all user with effective permissions of consolidated membertype of entity product/product  
EXEC mdm.udpUsersGetByObjectPermission @User_ID = 1, @ObjectType = 9, @Model_Name = N'Product', @Entity_Name = N'Product'  
  
-- Get all user with effective permissions of collection membertype of entity product/product  
EXEC mdm.udpUsersGetByObjectPermission @User_ID = 1, @ObjectType = 10, @Model_Name = N'Product', @Entity_Name = N'Product'  
  
-- Get all user with effective permissions of attributes of entity product/product/leaf  
EXEC mdm.udpUsersGetByObjectPermission @User_ID = 1, @ObjectType = 7, @Model_Name = N'Product', @Entity_Name = N'Product', @MemberType_ID = 1  
  
*/  
CREATE PROCEDURE mdm.udpUsersGetByObjectPermission  
(  
    @User_ID                INT, -- Who is doing the look up  
    @ObjectType             TINYINT,  
    @Model_MUID             UNIQUEIDENTIFIER = NULL,  
    @Model_Name             NVARCHAR(50) = NULL,  
    @Entity_MUID            UNIQUEIDENTIFIER = NULL,  
    @Entity_Name            NVARCHAR(50) = NULL,  
    @MemberType_ID          TINYINT = NULL,  
    @Attribute_MUID         UNIQUEIDENTIFIER = NULL,  
    @Attribute_Name         NVARCHAR(100) = NULL,  
    @SecurityPermission     TINYINT = NULL,  
    @AccessPermission       TINYINT = NULL,  
    @CorrelationID          UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    DECLARE @GuidEmpty                      UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER),  
              
            @Model_ID                       INT = NULL,  
            @Entity_ID                      INT = NULL,  
            @Model_Permission               TINYINT = NULL,  
  
            @Permission_Admin               INT = 5,  
  
            @MemberType_NotSpecified        TINYINT = 0,  
            @MemberType_Leaf                TINYINT = 1,  
            @MemberType_Consolidated        TINYINT = 2,  
            @MemberType_Collection          TINYINT = 3,  
  
            -- Check [mdm].[tblSecurityObject]  
            @ObjectType_Model               TINYINT = 1,  
            @ObjectType_Entity              TINYINT = 3,  
            @ObjectType_Attribute           TINYINT = 4,  
            @ObjectType_LeafType            TINYINT = 8,  
            @ObjectType_ConsolidatedType    TINYINT = 9,  
            @ObjectType_CollectionType      TINYINT = 10;  
  
    SELECT  
        @User_ID = NULLIF(@User_ID, 0),  
        @Model_MUID = NULLIF(@Model_MUID, @GuidEmpty),  
        @Model_Name = NULLIF(LTRIM(RTRIM(@Model_Name)), N''),  
        @Entity_MUID = NULLIF(@Entity_MUID, @GuidEmpty),  
        @Entity_Name = NULLIF(LTRIM(RTRIM(@Entity_Name)), N''),  
        @MemberType_ID = NULLIF(@MemberType_ID, 0),  
        @Attribute_MUID = NULLIF(@Attribute_MUID, @GuidEmpty),  
        @Attribute_Name = NULLIF(LTRIM(RTRIM(@Attribute_Name)), N''),  
        @ObjectType = NULLIF(@ObjectType, 0),  
        @SecurityPermission = NULLIF(@SecurityPermission, 0),  
        @AccessPermission = NULLIF(@AccessPermission, 0);  
  
    IF @ObjectType IS NULL OR @ObjectType NOT IN (@ObjectType_Model, @ObjectType_Entity, @ObjectType_Attribute, @ObjectType_LeafType, @ObjectType_ConsolidatedType, @ObjectType_CollectionType)  
    BEGIN  
        RAISERROR('MDSERR300005|The supplied object type is not valid.', 16, 1);  
        RETURN;  
    END  
  
    DECLARE @Permission TABLE  
    (  
        [User_ID]           INT,  
        ObjectType          TINYINT,  
        SecurityPermission  TINYINT NULL,  
        AccessPermission    TINYINT NULL,  
        Model_MUID          UNIQUEIDENTIFIER,  
        Model_Name          NVARCHAR(50),  
        Entity_MUID         UNIQUEIDENTIFIER NULL,  
        [Entity_Name]       NVARCHAR(50) NULL,  
        MemberType          TINYINT NULL,  
        Attribute_MUID      UNIQUEIDENTIFIER NULL,  
        Attribute_Name      NVARCHAR(100) NULL  
    );  
  
    IF @ObjectType = @ObjectType_Model  
    BEGIN  
        INSERT @Permission (  
            [User_ID],  
            ObjectType,  
            SecurityPermission,  
            AccessPermission,  
            Model_MUID,  
            Model_Name,  
            Entity_MUID,  
            [Entity_Name],  
            MemberType,  
            Attribute_MUID,  
            Attribute_Name  
        )  
        SELECT  
            ssum.[User_ID],  
            @ObjectType_Model,  
            ssum.Privilege_ID,  
            ssum.AccessPermission,  
            m.MUID,  
            m.Name,  
            NULL,  
            NULL,  
            NULL,  
            NULL,  
            NULL  
        FROM mdm.viw_SYSTEM_SECURITY_USER_MODEL ssum  
        INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_MODEL ownedssum  
        ON ssum.ID = ownedssum.ID AND ownedssum.[User_ID] = @User_ID AND ownedssum.Privilege_ID = @Permission_Admin  
        INNER JOIN mdm.tblModel m  
        ON ssum.ID = m.ID  
        WHERE (@Model_MUID IS NULL OR m.MUID = @Model_MUID)  
            AND (@Model_Name IS NULL OR m.Name = @Model_Name)  
            AND (@SecurityPermission IS NULL OR ssum.Privilege_ID = @SecurityPermission)  
            AND (@AccessPermission IS NULL OR ssum.AccessPermission = @AccessPermission)  
    END  
    ELSE  
    BEGIN  
        IF @Model_MUID IS NOT NULL OR @Model_Name IS NOT NULL  
        BEGIN  
            EXEC mdm.udpInformationLookupModel  
                @User_ID = @User_ID,  
                @Model_MUID = @Model_MUID,  
                @Model_Name = @Model_Name,  
                @ID = @Model_ID OUTPUT,  
                @Name = @Model_Name OUTPUT,  
                @MUID = @Model_MUID OUTPUT,  
                @Privilege_ID = @Model_Permission OUTPUT;  
        END  
  
        IF @Model_ID IS NULL OR @Model_Permission != @Permission_Admin  
        BEGIN  
            RAISERROR('MDSERR120003|The user does not have permission or the object ID is not valid.', 16, 1);  
            RETURN;  
        END  
  
        IF @ObjectType = @ObjectType_Entity  
        BEGIN  
            INSERT @Permission (  
                [User_ID],  
                ObjectType,  
                SecurityPermission,  
                AccessPermission,  
                Model_MUID,  
                Model_Name,  
                Entity_MUID,  
                [Entity_Name],  
                MemberType,  
                Attribute_MUID,  
                Attribute_Name  
            )  
            SELECT  
                ssue.[User_ID],  
                @ObjectType_Entity,  
                ssue.Privilege_ID,  
                ssue.AccessPermission,  
                @Model_MUID,  
                @Model_Name,  
                e.MUID,  
                e.Name,  
                NULL,  
                NULL,  
                NULL  
            FROM mdm.viw_SYSTEM_SECURITY_USER_ENTITY ssue  
            INNER JOIN mdm.tblEntity e  
            ON ssue.ID = e.ID AND e.Model_ID = @Model_ID  
            WHERE (@Entity_MUID IS NULL OR e.MUID = @Entity_MUID)  
                AND (@Entity_Name IS NULL OR e.Name = @Entity_Name)  
                AND (@SecurityPermission IS NULL OR ssue.Privilege_ID = @SecurityPermission)  
                AND (@AccessPermission IS NULL OR ssue.AccessPermission = @AccessPermission)  
        END  
        ELSE  
        BEGIN  
            IF @Entity_MUID IS NOT NULL OR @Entity_Name IS NOT NULL  
            BEGIN  
                EXEC mdm.udpInformationLookupEntity  
                    @User_ID = @User_ID,  
                    @Entity_MUID = @Entity_MUID,  
                    @Entity_Name = @Entity_Name,  
                    @ID = @Entity_ID OUTPUT,  
                    @Name = @Entity_Name OUTPUT,  
                    @MUID = @Entity_MUID OUTPUT;  
            END  
  
            IF @Entity_ID IS NULL  
            BEGIN  
                RAISERROR('MDSERR120003|The user does not have permission or the object ID is not valid.', 16, 1);  
                RETURN;  
            END;  
  
            IF @ObjectType IN (@ObjectType_LeafType, @ObjectType_ConsolidatedType, @ObjectType_CollectionType)  
            BEGIN  
                SET @MemberType_ID = @ObjectType - @ObjectType_LeafType + 1;  
                IF @MemberType_ID IS NULL OR @MemberType_ID NOT IN (@MemberType_Leaf, @MemberType_Consolidated, @MemberType_Collection)  
                BEGIN  
                    RAISERROR('MDSERR120003|The user does not have permission or the object ID is not valid.', 16, 1);  
                    RETURN;  
                END  
  
                INSERT @Permission (  
                    [User_ID],  
                    ObjectType,  
                    SecurityPermission,  
                    AccessPermission,  
                    Model_MUID,  
                    Model_Name,  
                    Entity_MUID,  
                    [Entity_Name],  
                    MemberType,  
                    Attribute_MUID,  
                    Attribute_Name  
                )  
                SELECT  
                    ssumt.[User_ID],  
                    @ObjectType,  
                    ssumt.Privilege_ID,  
                    ssumt.AccessPermission,  
                    @Model_MUID,  
                    @Model_Name,  
                    @Entity_MUID,  
                    @Entity_Name,  
                    @MemberType_ID,  
                    NULL,  
                    NULL  
                FROM mdm.viw_SYSTEM_SECURITY_USER_MEMBERTYPE ssumt  
                WHERE ssumt.[Entity_ID] = @Entity_ID  
                    AND ssumt.ID = @MemberType_ID  
                    AND (@SecurityPermission IS NULL OR ssumt.Privilege_ID = @SecurityPermission)  
                    AND (@AccessPermission IS NULL OR ssumt.AccessPermission = @AccessPermission)  
                END  
            ELSE IF @ObjectType = @ObjectType_Attribute  
            BEGIN  
                IF @MemberType_ID IS NULL OR @MemberType_ID NOT IN (@MemberType_Leaf, @MemberType_Consolidated, @MemberType_Collection)  
                BEGIN  
                    RAISERROR('MDSERR120003|The user does not have permission or the object ID is not valid.', 16, 1);  
                    RETURN;  
                END;  
  
                INSERT @Permission (  
                    [User_ID],  
                    ObjectType,  
                    SecurityPermission,  
                    AccessPermission,  
                    Model_MUID,  
                    Model_Name,  
                    Entity_MUID,  
                    [Entity_Name],  
                    MemberType,  
                    Attribute_MUID,  
                    Attribute_Name  
                )  
                SELECT  
                    ssua.[User_ID],  
                    @ObjectType_Attribute,  
                    ssua.Privilege_ID,  
                    ssua.AccessPermission,  
                    @Model_MUID,  
                    @Model_Name,  
                    @Entity_MUID,  
                    @Entity_Name,  
                    @MemberType_ID,  
                    a.MUID,  
                    a.Name  
                FROM mdm.viw_SYSTEM_SECURITY_USER_ATTRIBUTE ssua  
                INNER JOIN mdm.tblAttribute a  
                ON ssua.ID = a.ID AND a.[Entity_ID] = @Entity_ID AND a.MemberType_ID = @MemberType_ID  
                WHERE (@Attribute_MUID IS NULL OR a.MUID = @Attribute_MUID)  
                    AND (@Attribute_Name IS NULL OR a.Name = @Attribute_Name)  
                    AND (@SecurityPermission IS NULL OR ssua.Privilege_ID = @SecurityPermission)  
                    AND (@AccessPermission IS NULL OR ssua.AccessPermission = @AccessPermission)  
            END  
        END  
    END  
  
    SELECT  
        ID,  
        UserName,  
        MUID,  
        [SID]  
    FROM mdm.tblUser u  
    WHERE u.ID IN (SELECT [User_ID] FROM @Permission)  
  
    SELECT  
        [User_ID],  
        ObjectType,  
        SecurityPermission,  
        AccessPermission,  
        Model_Name,  
        Model_MUID,  
        [Entity_Name],  
        Entity_MUID,  
        MemberType,  
        Attribute_Name,  
        Attribute_MUID  
    FROM @Permission  
  
    SET NOCOUNT OFF  
END --proc
go

