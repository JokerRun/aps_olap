/*  
SELECT mdm.udfUniqueStagingBaseGet('Product')  
*/  
/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE FUNCTION mdm.udfUniqueStagingBaseGet  
(  
    @StagingBaseName	NVARCHAR(50) -- An entity name or the first 50 characters of StagingBase.  
)   
RETURNS NVARCHAR(60)  
/*WITH SCHEMABINDING*/  
AS BEGIN  
    DECLARE @NewStagingBase NVARCHAR(60),  
            @Count			INT = 0,  
            @MaxNameLen		INT = 111;  
          
    SET	@NewStagingBase = @StagingBaseName  
      
    -- If @NewStagingBase is not unique append the sequence number to make it unique.  
    WHILE EXISTS (SELECT 1 FROM mdm.tblEntity WHERE StagingBase = @NewStagingBase)  
    BEGIN  
        SET @Count = @Count + 1;  
        SET @NewStagingBase = LEFT(@StagingBaseName, @MaxNameLen - 6) + N'_' + CONVERT(NVARCHAR(5), @Count)   
    END; -- WHILE	  
          
    RETURN @NewStagingBase;	     
  
END --fn
go

