/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
--This can be called to save or create a new Annotations  
--Create or Update annotation Transaction  
EXEC mdm.udpEntityMemberAnnotationSave @User_ID = 1, @Model_Name = N'Product', @Entity_Name = N'Product', @Version_Name = N'Version 1', @MemberType_ID= 1, @Revision_ID = 0, @Member_Code = N'BB-8107', @Comment = N'haha';  
  
EXEC mdm.udpEntityMemberAnnotationSave @User_ID = 1, @Model_Name = N'Product', @Entity_Name = N'Product', @Version_Name = N'Version 1', @MemberType_ID= 1, @Comment = N'haha2', @Annotation_ID = 1;  
*/  
CREATE PROCEDURE mdm.udpEntityMemberAnnotationSave  
(  
    @User_ID        INT,  
    @Model_Name     NVARCHAR(50) = NULL,  
    @Model_MUID     UNIQUEIDENTIFIER = NULL,  
    @Entity_Name    NVARCHAR(50) = NULL,  
    @Entity_MUID    UNIQUEIDENTIFIER= NULL,  
    @Version_Name   NVARCHAR(50) = NULL,  
    @Version_MUID   UNIQUEIDENTIFIER = NULL,  
    @MemberType_ID  TINYINT,  
    @Revision_ID    BIGINT = NULL,  
    @Annotation_ID  INT = NULL OUTPUT,  
    @Comment        NVARCHAR(500),  
    @CorrelationID  UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
  
    DECLARE @GuidEmpty                      UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER),  
            @Owner_ID                       INT,  
            @Model_ID                       INT,  
            @Entity_ID                      INT,  
            @Version_ID                     INT,  
            @Member_ID                      INT,  
  
            @MemberIDColumn                 SYSNAME,  
            @EntityMemberTableName          SYSNAME,  
            @EntityMemberHistoryTableName   SYSNAME,  
            @AnnotationTableName            SYSNAME,  
  
            @Privilege_ID                   TINYINT,  
            @AccessPermission               TINYINT,  
            @Permission_Access              TINYINT = 4,  
            @Permission_Inferred            TINYINT = 99,  
            @AccessPermission_Update        TINYINT = 2,  
  
            @MemberType_Leaf                TINYINT = 1,  
            @MemberType_Consolidated        TINYINT = 2,  
            @MemberType_Collection          TINYINT = 3,  
            @MemberType_Hierarchy           TINYINT = 4,  
            @MemberType_CollectionMember    TINYINT = 5,  
  
            @SQL                            NVARCHAR(MAX);  
  
    SELECT  
        @User_ID = NULLIF(@User_ID, 0),  
        @Model_MUID = NULLIF(@Model_MUID, @GuidEmpty),  
        @Model_Name = NULLIF(LTRIM(RTRIM(@Model_Name)), N''),  
        @Entity_MUID = NULLIF(@Entity_MUID, @GuidEmpty),  
        @Entity_Name = NULLIF(LTRIM(RTRIM(@Entity_Name)), N''),  
        @Version_MUID = NULLIF(@Version_MUID, @GuidEmpty),  
        @Version_Name = NULLIF(LTRIM(RTRIM(@Version_Name)), N''),  
        @MemberType_ID = NULLIF(@MemberType_ID, 0),  
        @Revision_ID = NULLIF(@Revision_ID, 0),  
        @Annotation_ID = NULLIF(@Annotation_ID, 0),  
        @Comment = NULLIF(LTRIM(RTRIM(@Comment)), N'');  
  
    IF @User_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR100009|The User ID is not valid.', 16, 1);  
        RETURN;  
    END  
  
    IF @Comment IS NULL  
    BEGIN  
        RAISERROR('MDSERR310031|Comment is not valid.', 16, 1);  
        RETURN;  
    END  
  
    IF @MemberType_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR210021|MemberType ID is not valid.', 16, 1);  
        RETURN;  
    END  
  
    EXEC mdm.udpInformationLookupModel @User_ID = @User_ID, @Model_MUID = @Model_MUID, @Model_Name = @Model_Name, @ID = @Model_ID OUTPUT;  
    IF @Model_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300005|The supplied model is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    SELECT @Version_ID = ID  
    FROM mdm.tblModelVersion  
    WHERE  
            (@Version_MUID IS NOT NULL OR @Version_Name IS NOT NULL)  
        AND (@Version_MUID IS NULL OR MUID = @Version_MUID)  
        AND (@Version_Name IS NULL OR Name = @Version_Name)  
        AND Model_ID = @Model_ID;  
    IF @Version_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300006|The supplied version is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    EXEC mdm.udpInformationLookupEntity @User_ID = @User_ID, @Model_ID = @Model_ID, @Entity_MUID = @Entity_MUID, @Entity_Name = @Entity_Name, @ID = @Entity_ID OUTPUT;  
    IF @Entity_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300008|The supplied entity is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    SET @EntityMemberTableName = mdm.udfTableNameGetByID(@Entity_ID, @MemberType_ID);  
    SET @EntityMemberHistoryTableName = CONCAT(@EntityMemberTableName, N'_HS');  
    SET @AnnotationTableName = CONCAT(@EntityMemberTableName, N'_AN');  
    SET @MemberIDColumn =  
        CASE @MemberType_ID  
            WHEN @MemberType_Leaf THEN N'EN_ID'  
            WHEN @MemberType_Consolidated THEN N'HP_ID'  
            WHEN @MemberType_Collection THEN N'CN_ID'  
            WHEN @MemberType_Hierarchy THEN N'HR_ID'  
            WHEN @MemberType_CollectionMember THEN N'CM_ID'  
        END;  
  
    IF @Annotation_ID IS NULL  
    BEGIN  
        IF @Revision_ID IS NULL  
        BEGIN  
            RAISERROR('MDSERR200223|Revision ID is not valid.', 16, 1);  
            RETURN;  
        END  
  
        SET @SQL = CONCAT(N'  
            SELECT @Member_ID = ID  
            FROM [mdm].', QUOTENAME(@EntityMemberTableName), N'  
            WHERE Version_ID = @Version_ID AND LastChgTS = @Revision_ID;  
              
            IF @Member_ID IS NULL  
            BEGIN  
                SELECT @Member_ID = ', QUOTENAME(@MemberIDColumn), N'  
                FROM [mdm].', QUOTENAME(@EntityMemberHistoryTableName), N'  
                WHERE Version_ID = @Version_ID AND ID = @Revision_ID;  
            END');  
  
        EXEC sp_executesql @SQL, N'@Version_ID INT, @Revision_ID BIGINT, @Member_ID INT OUTPUT',  
                                   @Version_ID,     @Revision_ID,        @Member_ID OUTPUT;  
  
        IF @Member_ID IS NULL  
        BEGIN  
            RAISERROR('MDSERR200223|Revision ID is not valid.', 16, 1);  
            RETURN;  
        END  
  
        EXEC mdm.udpSecurityMemberResolverGet @User_ID, @Version_ID, NULL,NULL, @Entity_ID, @Member_ID, @MemberType_ID, @Privilege_ID OUTPUT, @AccessPermission OUTPUT;  
  
        -- User need have aleast one attribute update permission to add annotation  
        IF NOT ((@Privilege_ID = @Permission_Access OR @Privilege_ID = @Permission_Inferred) AND EXISTS (  
            SELECT 1  
            FROM mdm.viw_SYSTEM_SECURITY_USER_ATTRIBUTE sec  
            INNER JOIN mdm.tblAttribute att  
            ON sec.ID = att.ID  
            WHERE sec.User_ID = @User_ID  
                AND att.Entity_ID = @Entity_ID  
                AND att.MemberType_ID = @MemberType_ID  
                AND (AccessPermission & @AccessPermission_Update) = @AccessPermission_Update  
        ))  
        BEGIN  
            RAISERROR('MDSERR120002|The user does not have permission to perform this operation.', 16, 1);  
            RETURN;  
        END  
  
        SET @SQL = CONCAT(N'  
            INSERT INTO [mdm].', QUOTENAME(@AnnotationTableName), N'  
            (  
                Version_ID,  
                Revision_ID,  
                Comment,  
                EnterUserID,  
                LastChgUserID  
            )  
            VALUES  
            (  
                @Version_ID,  
                @Revision_ID,  
                @Comment,  
                @User_ID,  
                @User_ID  
            );')  
  
        EXEC sp_executesql @SQL, N'@Version_ID INT, @Revision_ID INT, @Comment NVARCHAR(500), @User_ID INT',  
                                   @Version_ID,     @Revision_ID,     @Comment,               @User_ID;  
  
        SET @Annotation_ID = SCOPE_IDENTITY();  
    END  
    ELSE  
    BEGIN  
        SET @SQL = CONCAT(N'  
            SELECT @Owner_ID = [EnterUserID]  
            FROM [mdm].', QUOTENAME(@AnnotationTableName), N'  
            WHERE Version_ID = @VersionID AND ID = @Annotation_ID');  
        EXEC sp_executesql @SQL, N'@VersionID INT, @Annotation_ID INT, @Owner_ID INT OUTPUT', @Version_ID, @Annotation_ID, @Owner_ID OUTPUT;  
        IF @Owner_ID IS NULL  
        BEGIN  
            RAISERROR('MDSERR310032|The annotation ID is not valid.', 16, 1);  
            RETURN;  
        END  
  
        IF @User_ID != @Owner_ID AND NOT EXISTS(  
            SELECT 1 FROM [mdm].[viw_SYSTEM_SECURITY_USER_MODEL] WHERE [User_ID] = @User_ID AND Privilege_ID = 5 /*Admin*/  
        )  
        BEGIN  
            RAISERROR('MDSERR120002|The user does not have permission to perform this operation.', 16, 1);  
            RETURN;  
        END  
  
        SET @SQL = CONCAT(N'  
            UPDATE [mdm].', QUOTENAME(@AnnotationTableName) + N'  
            SET Comment = @Comment,  
                LastChgDTM = GETUTCDATE(),  
                LastChgUserID = @User_ID  
            WHERE ID = @Annotation_ID AND Version_ID = @Version_ID;');  
  
        EXEC sp_executesql @SQL, N'@Version_ID INT, @Annotation_ID INT, @Comment NVARCHAR(500), @User_ID INT',  
                                   @Version_ID,     @Annotation_ID,     @Comment,               @User_ID;  
  
        SET @Annotation_ID = @Annotation_ID;  
    END  
  
END --proc
go

