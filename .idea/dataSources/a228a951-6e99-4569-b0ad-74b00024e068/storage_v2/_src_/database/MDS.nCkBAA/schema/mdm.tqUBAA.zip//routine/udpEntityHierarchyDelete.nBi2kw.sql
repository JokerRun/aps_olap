/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    EXEC mdm.udpEntityHierarchyDelete 1, 4, 15;  
    SELECT * FROM mdm.tblAttribute;  
*/  
CREATE PROCEDURE mdm.udpEntityHierarchyDelete  
(  
    @User_ID      INT,  
    @Hierarchy_ID INT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE @Entity_ID INT = (SELECT Entity_ID from mdm.tblHierarchy WHERE ID = @Hierarchy_ID);  
  
    IF @Entity_ID IS NULL  
    BEGIN  
        RETURN  
    END  
    --Start transaction, being careful to check if we are nested  
    DECLARE @TranCounter INT;  
    SET @TranCounter = @@TRANCOUNT;  
    IF @TranCounter > 0 SAVE TRANSACTION TX;  
    ELSE BEGIN TRANSACTION;  
  
    BEGIN TRY  
  
        DECLARE @HierarchyParentTable       SYSNAME,  
                @HierarchyParentSecurityTable   SYSNAME,  
                @HierarchyParentHistoryTable    SYSNAME,  
                @HierarchyParentAnnotationTable SYSNAME,  
                @HierarchyTable             SYSNAME,  
                @HierarchyHistoryTable      SYSNAME,  
                @HierarchyAnnotationTable   SYSNAME,  
                @CollectionMemberTable      SYSNAME,  
                @CollectionMemberHistoryTable   SYSNAME,  
                @StagingConsolidatedTable   SYSNAME,  
                @StagingRelationshipTable   SYSNAME,  
                @StagingBase                NVARCHAR(MAX),  
                @SQL                        NVARCHAR(MAX),  
                @Version_ID                 INT,  
                @ConstraintName             SYSNAME,  
                @TempID                     INT,  
                @TempTableName              SYSNAME,  
                @HierarchyMUID              UNIQUEIDENTIFIER,  
                @Model_ID                   INT,  
                @ConsolidatedAndRelationship    INT = 3,  
                @TransactionTableName       SYSNAME,  
  
                @MemberType_Leaf                    TINYINT = 1,  
                @MemberType_Consolidated            TINYINT = 2,  
                @MemberType_Collection              TINYINT = 3,  
                @MemberType_ParentChild             TINYINT = 4,  
                @MemberType_CollectionParentChild   TINYINT = 5,  
  
                @HierarchyType_Explicit    TINYINT = 0;  
  
        DECLARE    @TableFKConstraints      TABLE  
                (   [ID] [INT] IDENTITY (1, 1) Primary KEY CLUSTERED NOT NULL,  
                    TableName               SYSNAME,  
                    ConstraintName          SYSNAME);  
  
        --Get the latest version  
        SELECT @Version_ID = MAX(mv.ID)  
        FROM mdm.tblModelVersion AS mv  
        INNER JOIN mdm.tblEntity AS e ON (e.Model_ID = mv.Model_ID)  
        WHERE e.ID = @Entity_ID;  
  
        --Get the table name  
        SELECT  
            @HierarchyParentTable = HierarchyParentTable,  
            @HierarchyTable = HierarchyTable,  
            @CollectionMemberTable = CollectionMemberTable,  
            @StagingConsolidatedTable = StagingConsolidatedName,  
            @StagingRelationshipTable = StagingRelationshipName,  
            @StagingBase = StagingBase,  
            @Model_ID = Model_ID  
        FROM mdm.tblEntity  
        WHERE ID = @Entity_ID;  
  
        SELECT @HierarchyParentSecurityTable = CONCAT(@HierarchyParentTable, N'_MS'),  
            @HierarchyParentHistoryTable = CONCAT(@HierarchyParentTable, N'_HS'),  
            @HierarchyParentAnnotationTable = CONCAT(@HierarchyParentTable, N'_AN'),  
            @HierarchyHistoryTable = CONCAT(@HierarchyTable, N'_HS'),  
            @HierarchyAnnotationTable = CONCAT(@HierarchyTable, N'_AN'),  
            @CollectionMemberHistoryTable = CONCAT(@CollectionMemberTable, N'_HS');  
  
        --Get the transaction and annotation table names  
        SET @TransactionTableName = mdm.udfGetTransactionTableName(@Model_ID);  
  
        --delete any transactions and annotations  
        SET @SQL = CONCAT(N'  
            DELETE [mdm].', QUOTENAME(@TransactionTableName), N'  
            WHERE Hierarchy_ID = @Hierarchy_ID;');  
        EXEC sp_executesql @SQL, N'@Hierarchy_ID INT',  @Hierarchy_ID;  
  
        --Get the MUID  
        SELECT @HierarchyMUID = MUID from mdm.tblHierarchy WHERE ID = @Hierarchy_ID;  
  
        --Delete any member security assignments (object security assignments not allowed on explicit hierarchies)  
        DELETE FROM mdm.tblSecurityRoleAccessMember WHERE HierarchyType_ID = @HierarchyType_Explicit AND Hierarchy_ID = @Hierarchy_ID;  
  
  
        --If the entity has collections, then delete the consolidated members from any collections that contain them.  
        IF @CollectionMemberTable IS NOT NULL  
        BEGIN  
            SET @SQL = CONCAT(N'  
  
               DELETE FROM mdm.', QUOTENAME(@CollectionMemberTable), N'  
                WHERE ID IN (  
                    SELECT CMT.ID FROM mdm.', QUOTENAME(@CollectionMemberTable), N' AS CMT  
                    WHERE EXISTS (  
                        SELECT 1 FROM mdm.', QUOTENAME(@HierarchyTable), N' AS HRT  
                        WHERE HRT.Hierarchy_ID = @Hierarchy_ID  
                            AND CMT.ChildType_ID = HRT.ChildType_ID  
                            AND (CMT.ChildType_ID = 2 AND CMT.Child_HP_ID = HRT.Child_HP_ID))  
                    );')  
  
            EXEC sp_executesql @SQL, N'@Hierarchy_ID INT', @Hierarchy_ID;  
  
        END;  
  
        --Check to see if this is the last hierarchy for entity if so delete tables, views, and update mdm.tblEntity and CM table  
        --Per check above we know the hierarchy belongs to the entity.  
        IF (SELECT COUNT(*) FROM mdm.tblHierarchy WHERE Entity_ID = @Entity_ID) = 1  
        BEGIN  
  
                --Drop the FK from the HP - Really only need the one to the MS table but going to drop them all  
                INSERT INTO @TableFKConstraints  
                            SELECT  SCHEMA_NAME(schema_id) + '.[' + OBJECT_NAME(parent_object_id)+ ']',  
                                    s.[name]  
                            FROM sys.foreign_keys s  
                            WHERE referenced_object_id = OBJECT_ID('mdm.' + '[' + @HierarchyParentTable + ']');  
                -- Delete all the constraints first  
                DECLARE @Counter INT = 1 ;  
                DECLARE @MaxCounter INT = (SELECT MAX(ID) FROM @TableFKConstraints);  
                SET @Counter =1;  
                SET @SQL = '';  
                WHILE @Counter <= @MaxCounter  
                BEGIN  
                    SELECT @TempID = ID, @TempTableName = TableName, @ConstraintName = ConstraintName  
                        FROM @TableFKConstraints WHERE ID = @Counter;  
  
                    SET @SQL = CONCAT(@SQL, N'ALTER TABLE ', @TempTableName,  
                                N' DROP CONSTRAINT ', @ConstraintName, N';')  
  
                    SET @Counter = @Counter +1;  
                END  
                EXEC sp_executesql @SQL;  
  
                --Drop tables  
                SET @SQL = CONCAT(N'  
                    DROP TABLE mdm.', QUOTENAME(@HierarchyAnnotationTable), N';  
                    DROP TABLE mdm.', QUOTENAME(@HierarchyHistoryTable), N';  
                    DROP TABLE mdm.', QUOTENAME(@HierarchyTable), N';  
                    DROP TABLE mdm.', QUOTENAME(@HierarchyParentSecurityTable), N';  
                    DROP TABLE mdm.', QUOTENAME(@HierarchyParentAnnotationTable), N';  
                    DROP TABLE mdm.', QUOTENAME(@HierarchyParentHistoryTable), N';  
                    DROP TABLE mdm.', QUOTENAME(@HierarchyParentTable), N';');  
                EXEC sp_executesql @SQL;  
  
                --Update CM table  
                IF @CollectionMemberTable IS NOT NULL  
                BEGIN  
                   SET @SQL = CONCAT(N'  
                    DROP INDEX mdm.', QUOTENAME(@CollectionMemberTable), '.[ix_', @CollectionMemberTable, N'_Version_ID_Child_HP_ID];  
                    ALTER TABLE mdm.', QUOTENAME(@CollectionMemberTable), ' DROP CONSTRAINT [ck_', @CollectionMemberTable, N'_ChildType_ID];  
                    ALTER TABLE mdm.', QUOTENAME(@CollectionMemberTable), ' DROP COLUMN Child_HP_ID;  
                    ALTER TABLE mdm.', QUOTENAME(@CollectionMemberTable), ' ADD CONSTRAINT [ck_', @CollectionMemberTable, N'_ChildType_ID] CHECK ([ChildType_ID]=(1) AND [Child_EN_ID] IS NOT NULL AND [Child_CN_ID] IS NULL OR [ChildType_ID]=(3) AND [Child_CN_ID] IS NOT NULL AND [Child_EN_ID] IS NULL) ;  
                    ALTER TABLE mdm.', QUOTENAME(@CollectionMemberHistoryTable), ' DROP COLUMN Child_HP_ID;');  
  
                    EXEC sp_executesql @SQL;  
                END  
  
                --If @StagingBase is specified, drop entity based staging tables and delete staging Sprocs.  
                IF COALESCE(@StagingBase, N'') <> N'' BEGIN  
  
                    SET @SQL = CONCAT(N'  
                        DROP TABLE stg.', QUOTENAME(@StagingConsolidatedTable), N';  
                        DROP TABLE stg.', QUOTENAME(@StagingRelationshipTable), N';');  
  
                    EXEC sp_executesql @SQL;  
  
                    --Delete Staging Sprocs  
                    Exec mdm.udpEntityStagingDeleteStoredProcedures @Entity_ID, @ConsolidatedAndRelationship -- Drop consolidated and relationship Sprocs.  
  
                END; --IF  
  
                --Delete views  
                EXEC mdm.udpDeleteViews @Model_ID, @Entity_ID, NULL, 3;  
  
                --Delete attributes  
                DELETE FROM mdm.tblAttribute WHERE Entity_ID = @Entity_ID AND MemberType_ID IN (@MemberType_Consolidated, @MemberType_ParentChild);  
  
                --Update entity  
                UPDATE  
                    mdm.tblEntity  
                SET  
                    --Unassign table names  
                    HierarchyTable = NULL,  
                    HierarchyParentTable = NULL,  
                    --Audit changes  
                    LastChgDTM = GETUTCDATE(),  
                    LastChgUserID = @User_ID,  
                    LastChgVersionID = @Version_ID  
                WHERE  
                    ID = @Entity_ID;  
  
                --Recreate leaf staging SProc when HP table is deleted.  
                Exec mdm.udpEntityStagingCreateLeafStoredProcedure @Entity_ID = @Entity_ID;  
  
                --Recreate views for the hierarchy-free entity  
                EXEC mdm.udpCreateViews @Model_ID = @Model_ID, @NewEntity_ID = @Entity_ID;  
                EXEC mdm.udpEntityStagingCreateErrorDetailViews @Entity_ID = @Entity_ID;  
  
                --Put a msg onto the SB queue to process member security  
                EXEC mdm.udpSecurityMemberQueueSave  
                    @User_ID    = NULL,-- update member security for all users  
                    @Version_ID = @Version_ID,  
                    @Entity_ID  = @Entity_ID;  
  
        END ELSE BEGIN  
  
            -- Delete the consolidated members from the HP and HR tables.  
            SET @SQL = CONCAT(N'  
            DELETE FROM mdm.', QUOTENAME(@HierarchyTable), N'  
                WHERE Hierarchy_ID = @Hierarchy_ID;  
            DELETE FROM mdm.', QUOTENAME(@HierarchyParentTable), N'  
                WHERE Hierarchy_ID = @Hierarchy_ID;');  
  
            EXEC sp_executesql @SQL, N'@Hierarchy_ID INT', @Hierarchy_ID;  
        END; --if  
  
        --Delete the hierarchy record  
        DELETE FROM mdm.tblHierarchy WHERE ID = @Hierarchy_ID;  
  
        --Commit only if we are not nested  
        IF @TranCounter = 0 COMMIT TRANSACTION;  
        RETURN(0);  
  
    END TRY  
    --Compensate as necessary  
    BEGIN CATCH  
  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        IF @TranCounter = 0 ROLLBACK TRANSACTION;  
        ELSE IF XACT_STATE() <> -1 ROLLBACK TRANSACTION TX;  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
  
        --On error, return NULL results  
        SELECT NULL AS HierarchyCount;  
        RETURN(1);  
  
    END CATCH;  
  
  
    SET NOCOUNT OFF;  
END; --proc
go

