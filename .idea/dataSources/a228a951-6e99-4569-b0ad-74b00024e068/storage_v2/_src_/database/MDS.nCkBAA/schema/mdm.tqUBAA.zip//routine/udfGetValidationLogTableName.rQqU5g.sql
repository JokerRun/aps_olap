/*  
    SELECT mdm.udfGetValidationLogTableName(7)  
*/  
/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE FUNCTION mdm.udfGetValidationLogTableName  
(  
    @Model_ID   INT  
)   
RETURNS sysname  
/*WITH SCHEMABINDING*/  
AS BEGIN  
  
    RETURN CONCAT(N'tbl_', @Model_ID, N'_VL');  
  
END; --fn
go

