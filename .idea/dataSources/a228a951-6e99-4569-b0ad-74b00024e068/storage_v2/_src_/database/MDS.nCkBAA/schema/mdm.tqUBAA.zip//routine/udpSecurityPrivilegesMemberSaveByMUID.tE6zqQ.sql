/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpSecurityPrivilegesMemberSaveByMUID  
(  
    @SystemUser_ID			INT,  
    @Principal_MUID			UNIQUEIDENTIFIER=NULL,  
    @PrincipalType_ID		TINYINT,  
    @Principal_Name			NVARCHAR(355) = NULL,-- max group name length  
    @RoleAccess_MUID		UNIQUEIDENTIFIER = NULL,  
    @Privilege_ID			TINYINT,  
    @AccessPermission       TINYINT = NULL,  
    @Model_MUID			    UNIQUEIDENTIFIER = NULL,  
    @Model_Name			    NVARCHAR(50) = NULL,  
    @Version_MUID			UNIQUEIDENTIFIER = NULL,  
    @Version_Name			NVARCHAR(50) = NULL,  
    @Entity_MUID			UNIQUEIDENTIFIER=NULL,  
    @Entity_Name			NVARCHAR(MAX) = NULL,  
    @Hierarchy_MUID			UNIQUEIDENTIFIER = NULL,  
    @Hierarchy_Name			NVARCHAR(50) = NULL,  
    @HierarchyType_ID		TINYINT,  
    @Member_ID				INT,  
    @MemberType_ID			TINYINT,  
    @Member_Code            NVARCHAR(250) = NULL,  
    @Status_ID				TINYINT = 0,  
    @Securable_Name			NVARCHAR(100) = NULL,  
    @Return_ID				INT = NULL OUTPUT,  
    @Return_MUID			UNIQUEIDENTIFIER = NULL OUTPUT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    -- Set AccessPermission as 0 if AccessPermission is null  
    SET @AccessPermission = ISNULL(@AccessPermission, 0);  
  
    DECLARE @Role_ID			INT  
    DECLARE @Description		NVARCHAR(250),  
        @Principal_ID			INT,  
        @Principal_NameUpper    NVARCHAR(355) = UPPER(@Principal_Name),  
        @Model_ID               INT,  
        @Version_ID				INT,  
        @Entity_ID				INT,  
        @Hierarchy_ID			INT,  
        @Securable_ID			INT,   
        @RoleAccess_ID			INT,  
        @TempRoleAccess_ID		INT,  
        @NewUser_ID	INT,  
        @GuidEmpty          UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER)  
        ;  
    SELECT  
         @Model_MUID = NULLIF(@Model_MUID, @GuidEmpty)  
        ,@Model_Name = NULLIF(@Model_Name, N'')  
        ,@Version_MUID = NULLIF(@Version_MUID, @GuidEmpty)  
        ,@Version_Name = NULLIF(@Version_Name, N'')  
        ,@RoleAccess_MUID = NULLIF(@RoleAccess_MUID, @GuidEmpty)  
        ,@Entity_MUID = NULLIF(@Entity_MUID, @GuidEmpty)  
        ,@Entity_Name = NULLIF(@Entity_Name, N'')  
        ,@Hierarchy_MUID = NULLIF(@Hierarchy_MUID, @GuidEmpty)  
        ,@Hierarchy_Name = NULLIF(@Hierarchy_Name, N'');  
  
  
    -- Disallow Admin permission for members (only valid for models).  
    DECLARE @PermissionType_Admin TINYINT = 5;  
    IF @Privilege_ID = @PermissionType_Admin  
    BEGIN  
        RAISERROR('MDSERR500054|The permission cannot be saved. Admin permission can only be set on a model.', 16, 1);  
        RETURN;  
    END;  
  
    SET  @Principal_ID = 0   
    --Lookup the integerIDs for the MUIDs  
    IF(@PrincipalType_ID =1)  
    BEGIN  
        IF( @Principal_MUID IS NOT NULL AND CAST(@Principal_MUID  AS BINARY) <> 0x0  
                    AND EXISTS(SELECT ID from mdm.tblUser WHERE MUID=@Principal_MUID))  
        BEGIN  
            SELECT @Principal_ID = (SELECT ID FROM mdm.tblUser WHERE MUID=@Principal_MUID)  
        END  
        ELSE   
        IF( @Principal_Name IS NOT NULL AND EXISTS(SELECT ID from mdm.tblUser WHERE UPPER(UserName) = @Principal_NameUpper))  
        BEGIN  
            SELECT @Principal_ID = (SELECT ID FROM mdm.tblUser WHERE UPPER(UserName) = @Principal_NameUpper)  
        END  
    END  
    ELSE  
    BEGIN  
        IF(@PrincipalType_ID =2 )  
        BEGIN  
            IF( @Principal_MUID IS NOT NULL AND CAST(@Principal_MUID  AS BINARY) <> 0x0  
                    AND EXISTS(SELECT ID from mdm.tblUserGroup WHERE MUID=@Principal_MUID))  
            BEGIN  
                SELECT @Principal_ID = (SELECT ID FROM mdm.tblUserGroup WHERE MUID=@Principal_MUID)  
            END  
            ELSE   
            IF( @Principal_Name IS NOT NULL AND EXISTS(SELECT ID from mdm.tblUserGroup WHERE UPPER(Name) = @Principal_NameUpper))  
            BEGIN  
            SELECT @Principal_ID = (SELECT ID FROM mdm.tblUserGroup WHERE UPPER(Name) = @Principal_NameUpper)  
            END  
        END  
    END  
  
    If @Principal_ID IS NULL OR @Principal_ID = 0   
    BEGIN  
        RAISERROR('MDSERR500025|The principal ID for the user or group is not valid.', 16, 1);  
        RETURN     
    END  
      
    IF (@RoleAccess_MUID IS NOT NULL)    
    BEGIN    
        IF((EXISTS (SELECT ID FROM mdm.tblSecurityRoleAccessMember WHERE MUID = @RoleAccess_MUID)))    
        BEGIN    
            SELECT @RoleAccess_ID = RoleAccess_ID,  
                    @Model_ID = Model_ID,      
                    @Version_ID = Version_ID,  
                    @Entity_ID = Entity_ID,      
                    @Hierarchy_ID = Hierarchy_ID,  
                    @Member_ID = Member_ID,  
                    @HierarchyType_ID = HierarchyType_ID  
            FROM mdm.viw_SYSTEM_SECURITY_ROLE_ACCESSCONTROL_MEMBER   
            WHERE RoleAccess_MUID = @RoleAccess_MUID      
        END     
    END     
  
    --Validate other supplied parameters     
    IF (@Version_ID IS NULL   
        AND (@Version_MUID IS NOT NULL  
               OR (@Version_Name IS NOT NULL  
                 AND (@Model_MUID IS NOT NULL OR @Model_Name IS NOT NULL))))  
    BEGIN  
        SELECT  
             @Version_ID = mv.ID  
            ,@Model_ID = mv.Model_ID  
        FROM mdm.tblModelVersion mv  
        INNER JOIN mdm.tblModel m  
        ON mv.Model_ID = m.ID  
        WHERE  
                (@Model_MUID IS NULL OR @Model_MUID = m.MUID)  
            AND (@Model_Name IS NULL OR @Model_Name = m.Name)  
            AND (@Version_MUID IS NULL OR @Version_MUID = mv.MUID)  
            AND (@Version_Name IS NULL OR @Version_Name = mv.Name);  
    END          
    IF (@Version_ID IS NULL)  
    BEGIN    
        RAISERROR('MDSERR500029|The hierarchy permission cannot be saved. The version ID is not valid.', 16, 1);  
        RETURN       
    END  
      
    IF (@Entity_ID IS NULL   
        AND (@Entity_MUID IS NOT NULL OR @Entity_Name IS NOT NULL))  
    BEGIN  
        SELECT  
            @Entity_ID = ID  
        FROM mdm.tblEntity  
        WHERE  
            Model_ID = @Model_ID  
            AND (@Entity_MUID IS NULL OR @Entity_MUID = MUID)  
            AND (@Entity_Name IS NULL OR @Entity_Name = Name);  
    END          
    IF (@Entity_ID IS NULL)  
    BEGIN    
        RAISERROR('MDSERR500030|The hierarchy permission cannot be saved. The entity ID is not valid.', 16, 1);  
        RETURN       
    END    
        
    -- Check for member Id.   
    IF(@Member_ID = 0 AND @Member_Code IS NOT NULL AND @Member_Code <> '' AND @Member_Code <> 'ROOT')  
    BEGIN  
        EXEC mdm.udpMemberIDGetByCode @Version_ID,@Entity_ID, @Member_Code,@MemberType_ID,@Member_ID OUTPUT  
  
        -- Verify that the member code exists.  
        IF (@Member_ID = 0)   
        BEGIN   
            RAISERROR('MDSERR300002|Error - The member code is not valid.', 16, 1);  
            RETURN;         
        END  
    END  
  
    IF (@Hierarchy_ID IS NULL  
        AND (@Hierarchy_MUID IS NOT NULL OR @Hierarchy_Name IS NOT NULL))  
    BEGIN  
        IF (@HierarchyType_ID = 0)  
        BEGIN  
            SELECT @Hierarchy_ID = ID   
            FROM mdm.tblHierarchy   
            WHERE   
                Entity_ID = @Entity_ID  
                AND (@Hierarchy_MUID IS NULL OR @Hierarchy_MUID = MUID)  
                AND (@Hierarchy_Name IS NULL OR @Hierarchy_Name = Name)  
        END ELSE IF (@HierarchyType_ID = 1)  
        BEGIN  
           SELECT @Hierarchy_ID = ID   
            FROM mdm.tblDerivedHierarchy   
            WHERE   
                Model_ID = @Model_ID  
                AND (@Hierarchy_MUID IS NULL OR @Hierarchy_MUID = MUID)  
                AND (@Hierarchy_Name IS NULL OR @Hierarchy_Name = Name)  
        END  
    END  
    IF (@Hierarchy_ID is NULL)  
    BEGIN    
        RAISERROR('MDSERR500031|The hierarchy permission cannot be saved. The hierarchy ID is not valid.', 16, 1);  
        RETURN       
    END    
          
    SELECT	@TempRoleAccess_ID = RoleAccess_ID  FROM	mdm.viw_SYSTEM_SECURITY_ROLE_ACCESSCONTROL_MEMBER rac     
                    WHERE	rac.Version_ID       = @Version_ID    
                    AND		rac.Entity_ID      = @Entity_ID    
                    AND		rac.Hierarchy_ID   = @Hierarchy_ID    
                    AND		rac.HierarchyType_ID = @HierarchyType_ID    
                    AND		rac.Member_ID        = @Member_ID    
                    AND		rac.MemberType_ID    = @MemberType_ID    
                    AND		rac.Principal_MUID      = @Principal_MUID    
                    AND		rac.PrincipalType_ID  = @PrincipalType_ID    
    
    If ( @TempRoleAccess_ID IS NOT NULL AND @TempRoleAccess_ID <>0)    
    BEGIN     
    --Role exists update the role.    
        UPDATE mdm.tblSecurityRoleAccessMember SET Privilege_ID = @Privilege_ID, AccessPermission = @AccessPermission WHERE ID = @TempRoleAccess_ID     
        SELECT @Hierarchy_ID = Hierarchy_ID ,@HierarchyType_ID = HierarchyType_ID from mdm.tblSecurityRoleAccessMember      
        WHERE ID = @TempRoleAccess_ID     
        Return(1)    
    END    
            
    
    IF(@HierarchyType_ID =0)    
    BEGIN    
        -- Verify that the member is a part of the hierarchy.  
        IF (COALESCE(@Hierarchy_ID, 0) > 0 AND COALESCE(@Member_ID, 0) > 0)  
        BEGIN  
            DECLARE @IsMemberInHierarchy BIT = 0;  
            DECLARE @SQL NVARCHAR(MAX) =  
            N'SET @IsMemberInHierarchy =   
                CASE WHEN EXISTS(  
                            SELECT *  
                            FROM mdm.' + QUOTENAME(mdm.udfTableNameGetByID(@Entity_ID, 4 /*HierarchyTable*/)) + N'  
                            WHERE   
                            Version_ID =    @Version_ID AND  
                            Hierarchy_ID =  @Hierarchy_ID AND  
                            ChildType_ID =  @MemberType_ID AND   
                            @Member_ID =    CASE ChildType_ID   
                                                WHEN 1 /*Leaf*/         THEN Child_EN_ID   
                                                WHEN 2 /*Consolidated*/ THEN Child_HP_ID  
                                                END)  
                    THEN 1 ELSE 0 END;                                          
            ';  
            EXEC sp_executesql @SQL, N'@Version_ID INT, @Hierarchy_ID INT, @MemberType_ID TINYINT, @Member_ID INT, @IsMemberInHierarchy BIT OUTPUT', @Version_ID, @Hierarchy_ID, @MemberType_ID, @Member_ID, @IsMemberInHierarchy OUTPUT;  
            IF (@IsMemberInHierarchy <> 1)  
            BEGIN  
                RAISERROR('MDSERR300002|Error - The member code is not valid.', 16, 1);  
                RETURN;         
            END  
        END  
    END    
  
    
    IF (@RoleAccess_MUID IS NOT NULL)    
        BEGIN    
            IF((EXISTS (SELECT ID FROM mdm.tblSecurityRoleAccessMember WHERE MUID=@RoleAccess_MUID)))    
                BEGIN    
                    SELECT @RoleAccess_ID = (SELECT ID FROM mdm.tblSecurityRoleAccessMember WHERE MUID=@RoleAccess_MUID)    
                    
                    --Print 'update'     
                    IF (@Status_ID = 3)    
                    BEGIN    
                        SET @Status_ID = 1     
    
                    END    
                    IF(@Status_ID = 0)    
                    BEGIN    
                        SET @RoleAccess_ID = 0  -- ignore the role access id     
                    END     
                END    
            ELSE     
            BEGIN    
                IF (@Status_ID = 3)    
                BEGIN    
                    --Print 'Clone' --Clone operation.    
                    print @RoleAccess_ID    
                    SELECT	@Role_ID = Role_ID    
                    FROM	mdm.tblSecurityAccessControl    
                    WHERE	Principal_ID = @Principal_ID    
                    AND		PrincipalType_ID = @PrincipalType_ID    
    
    
                    IF @Principal_Name IS NULL     
                    BEGIN    
                        IF @PrincipalType_ID = 1 BEGIN    
                            SELECT @Principal_Name = mdm.udfUserNameGetByUserID(@Principal_ID)    
                        END ELSE BEGIN    
                            SELECT @Principal_Name = Name FROM mdm.tblUserGroup WHERE ID = @Principal_ID    
                        END     
                    END    
      
                    DECLARE @PrincipalType_Name NVARCHAR(20);  
                    IF @PrincipalType_ID = 1  
                    BEGIN  
                        SELECT @PrincipalType_Name = CAST(N'UserAccount' AS NVARCHAR(20))  
                    END ELSE  
                    BEGIN    
                        SELECT @PrincipalType_Name = CAST(N'Group' AS NVARCHAR(20))  
                    END  
    
                    IF @Role_ID IS NULL BEGIN    
                        --Create a new user account role for this user.    
                        INSERT INTO mdm.tblSecurityRole (Name, EnterUserID, LastChgUserID) VALUES (CAST(N'Role for ' + @PrincipalType_Name + N' ' + @Principal_Name AS NVARCHAR(115)), @SystemUser_ID, @SystemUser_ID)    
                        SET @Role_ID = SCOPE_IDENTITY()    
    
                        INSERT INTO mdm.tblSecurityAccessControl (PrincipalType_ID, Principal_ID, Role_ID, Description, EnterUserID, LastChgUserID)     
                        VALUES (@PrincipalType_ID, @Principal_ID, @Role_ID, CAST(@Principal_Name + N' ' + @PrincipalType_Name AS NVARCHAR(110)), @SystemUser_ID, @SystemUser_ID)    
                    END     
    
                    SELECT	@Description = CONCAT(@Securable_Name, N' ', o.Name, N' (', p.Name, N')')  
                    FROM	mdm.tblSecurityObject o     
                            INNER JOIN mdm.tblSecurityPrivilege p     
                                ON p.ID = @Privilege_ID    
                    --print 'insert'    
                    INSERT INTO mdm.tblSecurityRoleAccessMember (MUID,Role_ID, Privilege_ID, AccessPermission, Version_ID, Entity_ID, ExplicitHierarchy_ID,DerivedHierarchy_ID, HierarchyType_ID, Member_ID, MemberType_ID, Description, EnterUserID, LastChgUserID)    
                    VALUES(@RoleAccess_MUID,@Role_ID, @Privilege_ID, @AccessPermission, @Version_ID, @Entity_ID, CASE @HierarchyType_ID WHEN 0 THEN @Hierarchy_ID ELSE NULL END,CASE @HierarchyType_ID WHEN 1 THEN @Hierarchy_ID ELSE NULL END, @HierarchyType_ID, @Member_ID, @MemberType_ID, @Description, @SystemUser_ID, @SystemUser_ID)    
                    SELECT @NewUser_ID=SCOPE_IDENTITY()		    
                      
                    SELECT @Return_ID = @NewUser_ID    
                    SELECT @Return_MUID = (SELECT MUID FROM mdm.tblSecurityRoleAccessMember WHERE ID = @NewUser_ID)    
                    RETURN(1)     
                END -- Clone    
            END -- ELSE    
        END -- muid Check     
    ELSE    
        BEGIN    
            IF (@Status_ID = 1)    
            BEGIN    
                RAISERROR('MDSERR500037|The hierarchy permission cannot be updated. The ID is not valid.', 16, 1);  
                RETURN      
            END    
            ELSE IF (@Status_ID = 3)    
            BEGIN    
                RAISERROR('MDSERR500038|The hierarchy permission cannot be copied. The ID is not valid.', 16, 1);  
                RETURN      
            END    
        END    
    
        IF (@Status_ID = 0 AND (@RoleAccess_ID IS NOT null AND @RoleAccess_ID > 0) )    
        BEGIN    
            RAISERROR('MDSERR500036|The hierarchy permission cannot be created. The ID is not valid.', 16, 1);  
            RETURN      
        END    
        ELSE IF(@Status_ID = 1 AND (@RoleAccess_ID IS  null OR @RoleAccess_ID = 0 ))    
        BEGIN    
                RAISERROR('MDSERR500037|The hierarchy permission cannot be updated. The ID is not valid.', 16, 1);  
                RETURN      
        END     
        ELSE IF(@Status_ID = 0)    
        BEGIN    
            If(EXISTS (SELECT ID FROM mdm.tblSecurityRoleAccessMember where Role_ID = @Role_ID AND     
                 Privilege_ID = @Privilege_ID AND Hierarchy_ID = @Hierarchy_ID AND Entity_ID=@Entity_ID AND     
                Version_ID = @Version_ID AND Member_ID = @Member_ID))    
            BEGIN    
                RAISERROR('MDSERR500026|The hierarchy permission cannot be created. A hierarchy permission already exists.', 16, 1);  
                RETURN      
            END    
            set @RoleAccess_ID = 0     
        END     
    
    --print @RoleAccess_ID    
    --Execute the save stored procedure.    
    DECLARE	@return_value int    
    
    EXEC    @return_value = [mdm].[udpSecurityPrivilegesMemberSave]    
        @SystemUser_ID,    
        @Principal_ID,    
        @PrincipalType_ID,    
        @Principal_Name,    
        @RoleAccess_ID,    
        @Privilege_ID,  
        @AccessPermission,  
        @Version_ID,    
        @Entity_ID,   
        @Hierarchy_ID,    
        @HierarchyType_ID,    
        @Member_ID,    
        @MemberType_ID,    
        @Securable_Name,    
        @Return_ID = @Return_ID OUTPUT,    
        @Return_MUID = @Return_MUID OUTPUT    
    
        --RETURN(@return_value)    
    
    SET NOCOUNT OFF    
END --proc
go

