/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpVersionGet  
(  
     @User_ID       INT  
  
    ,@Model_MUID    UNIQUEIDENTIFIER = NULL  
    ,@Model_Name    NVARCHAR(50) = NULL  
    ,@Model_ID      INT = NULL -- set internally only  
  
    ,@Version_MUID    UNIQUEIDENTIFIER = NULL  
    ,@Version_Name    NVARCHAR(50) = NULL  
  
    ,@IncludeParentIdentifiers  BIT = 1 -- Return results sets for parent Model identifiers. Set to 0 when getting versions as part of a parent object (because the parent identifiers will already have been looked up).  
    ,@Debug                     BIT = 0  
    ,@CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
  
    SET NOCOUNT ON  
  
    DECLARE   
         @ValidationStatus_NotSpecified TINYINT = 0  
        ,@ValidationStatus_NotValidated TINYINT = 1  
        ,@ValidationStatus_Validated    TINYINT = 2  
  
        ,@VersionStatus_Open        TINYINT = 1  
        ,@VersionStatus_Locked      TINYINT = 2  
        ,@VersionStatus_Committed   TINYINT = 3  
        ;  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': start udpVersionGet')  
  
    -- Get model ID  
    IF @Model_ID IS NULL -- If the ID was already provided, don't bother looking it up again  
        AND (@Model_Name IS NOT NULL OR @Model_MUID IS NOT NULL)  
    BEGIN  
        SELECT   
             @Model_ID = ID  
            ,@Model_MUID = MUID  
            ,@Model_Name = Name  
        FROM mdm.tblModel  
        WHERE   MUID = ISNULL(@Model_MUID, MUID)  
            AND Name = ISNULL(@Model_Name, Name)  
  
        SET @Model_ID = COALESCE(@Model_ID, 0)  
    END  
  
    -- Get version ID  
    DECLARE @Version_ID INT = NULL;  
    IF @Version_Name IS NOT NULL OR @Version_MUID IS NOT NULL  
    BEGIN  
        SELECT   
             @Version_ID = ID  
            ,@Version_MUID = MUID  
            ,@Version_Name = Name  
        FROM mdm.tblModelVersion  
        WHERE   MUID = ISNULL(@Version_MUID, MUID)  
            AND Name = ISNULL(@Version_Name, Name)  
            AND Model_ID = ISNULL(@Model_ID, Model_ID) -- If a model filter is specified, use it  
  
        SET @Version_ID = COALESCE(@Version_ID, 0)  
    END  
  
    DECLARE @SelectedVersion TABLE   
    (  
         ID                     INT PRIMARY KEY  
        ,Model_ID               INT  
        ,ValidationStatus_ID    TINYINT  
        ,Privilege_ID           TINYINT  
        ,AccessPermission       TINYINT  
    )  
  
    INSERT INTO @SelectedVersion  
    SELECT  
         v.ID  
        ,v.Model_ID  
        ,CASE v.Status_ID   
            WHEN @VersionStatus_Committed THEN @ValidationStatus_Validated -- Committed versions are always validated  
            ELSE @ValidationStatus_NotSpecified END  
        ,4/*Access*/  
        ,CASE  
            -- If the status is Committed (3) then the version has been approved and cannot be updated by anyone  
            WHEN v.Status_ID = 3 THEN 0 -- ReadOnly  
            -- If the status is Locked (2) then the version is locked for review and can only be updated by a Model administrator  
            WHEN v.Status_ID = 2 THEN  
                CASE  
                    WHEN acl.Privilege_ID = 5 /*Admin*/ THEN 7 -- All  
                    ELSE 0 -- ReadOnly  
                END  
            -- If the status is Open (1) then return update.  
            ELSE 7 -- All  
        END AS AccessPermission  
    FROM mdm.tblModelVersion v  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_MODEL acl  
    ON v.Model_ID = acl.ID  
    WHERE   acl.User_ID = @User_ID  
        AND v.Model_ID = ISNULL(@Model_ID, v.Model_ID)  
        AND v.ID = ISNULL(@Version_ID, v.ID)  
        AND acl.Privilege_ID <> 1 /*Deny*/  
  
    IF @IncludeParentIdentifiers = 1  
    BEGIN  
        -- Return model Identifier(s)  
        IF @Model_ID IS NOT NULL  
        BEGIN  
            IF @Model_Name IS NULL OR @Model_MUID IS NULL  
            BEGIN  
                SELECT   
                     @Model_MUID = MUID  
                    ,@Model_Name = Name  
                FROM mdm.tblModel  
                WHERE ID = @Model_ID  
            END  
  
            -- A single model was specified, and its info has already been looked up, so simply return it  
            SELECT   
                 @Model_MUID    AS Model_MUID  
                ,@Model_Name    AS Model_Name  
                ,@Model_ID      AS Model_ID  
        END ELSE  
        BEGIN  
            SELECT DISTINCT  
                 m.MUID AS Model_MUID  
                ,m.Name AS Model_Name  
                ,m.ID   AS Model_ID  
            FROM @SelectedVersion v  
            INNER JOIN mdm.tblModel m  
            ON v.Model_ID = m.ID  
        END  
    END  
  
    -- Get version validation status  
    DECLARE   
         @IsValidated           BIT  
        ,@ValidationStatus_ID   TINYINT;  
    SET @Version_ID = -1  
  
    WHILE (1 = 1)  
    BEGIN  
        SET @Model_ID = NULL  
  
        SELECT TOP 1   
             @Model_ID = Model_ID  
            ,@Version_ID = ID   
            ,@ValidationStatus_ID = ValidationStatus_ID  
        FROM @SelectedVersion   
        WHERE ID > @Version_ID  
        ORDER BY ID ASC  
  
        IF @Model_ID IS NULL  
        BEGIN  
            BREAK;  
        END  
        ELSE IF @ValidationStatus_ID = @ValidationStatus_NotSpecified -- Skip versions whose validation status has already been determined   
        BEGIN  
  
            EXEC mdm.udpVersionValidationStatusGet @Model_ID = @Model_ID, @Version_ID = @Version_ID, @IsValidated = @IsValidated OUTPUT  
  
            UPDATE @SelectedVersion   
            SET ValidationStatus_ID = CASE @IsValidated WHEN 0 THEN @ValidationStatus_NotValidated ELSE @ValidationStatus_Validated END  
            WHERE ID = @Version_ID  
        END   
    END  
  
    SELECT  
         v.MUID AS Version_MUID  
        ,v.Name AS Version_Name  
        ,v.ID   AS Version_ID  
        ,sv.Privilege_ID  
        ,sv.AccessPermission  
  
        ,sv.Model_ID  
  
        ,v.Description  
        ,v.Status_ID  
        ,sv.ValidationStatus_ID  
        ,v.VersionNbr AS VersionNumber  
  
        ,NULLIF(v.Flag_MUID, 0x0)       AS VersionFlag_MUID  
        ,NULLIF(v.Flag, N'')            AS VersionFlag_Name  
        ,NULLIF(v.VersionFlag_ID, 0)    AS VersionFlag_ID  
  
        ,NULLIF(v.CopiedFrom_MUID, 0x0) AS CopiedFrom_MUID  
        ,NULLIF(v.CopiedFrom, N'')      AS CopiedFrom_Name  
        ,NULLIF(v.CopiedFrom_ID, 0)     AS CopiedFrom_ID  
  
        ,v.EnteredUser_DTM  
        ,v.EnteredUser_MUID  
        ,v.EnteredUser_UserName  
        ,v.EnteredUser_ID  
        ,v.LastChgUser_DTM  
        ,v.LastChgUser_MUID  
        ,v.LastChgUser_UserName  
        ,v.LastChgUser_ID  
    FROM @SelectedVersion sv  
    INNER JOIN mdm.viw_SYSTEM_SCHEMA_VERSION v  
    ON sv.ID = v.ID  
    ORDER BY   
         v.Model_MUID  
        ,v.VersionNbr  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': end udpVersionGet')  
  
    SET NOCOUNT OFF  
END --proc
go

