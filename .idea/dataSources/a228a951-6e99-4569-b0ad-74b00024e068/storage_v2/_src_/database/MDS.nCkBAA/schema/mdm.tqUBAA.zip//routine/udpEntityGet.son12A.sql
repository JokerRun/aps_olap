/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpEntityGet  
(  
     @User_ID       INT  
  
    ,@Model_MUID    UNIQUEIDENTIFIER = NULL  
    ,@Model_Name    NVARCHAR(50) = NULL  
    ,@Model_ID      INT = NULL -- set internally only  
  
    ,@Entity_MUID   UNIQUEIDENTIFIER = NULL  
    ,@Entity_Name   NVARCHAR(50) = NULL  
  
    -- Only used when getting details  
    ,@Index_MUID    UNIQUEIDENTIFIER = NULL  
    ,@Index_Name    NVARCHAR(50) = NULL  
  
    ,@HierarchyTable mdm.Identifier READONLY  
  
    ,@MemberType_ID TINYINT = NULL  
  
    ,@AttributeGroup_MUID   UNIQUEIDENTIFIER = NULL  
    ,@AttributeGroup_Name   NVARCHAR(50) = NULL  
  
    ,@Attribute_MUID   UNIQUEIDENTIFIER = NULL  
    ,@Attribute_Name   NVARCHAR(100) = NULL  
  
    ,@ResultOption TINYINT -- None = 0, Identifiers = 1, Details = 2.   
   
    ,@IncludeParentIdentifiers  BIT = 1 -- Return results sets for parent Model and Entity identifiers. Set to 0 when getting attributes as part of a parent object (because the parent identifiers will already have been looked up).  
    ,@Debug                     BIT = 0  
    ,@CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
  
    SET NOCOUNT ON  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': begin udpEntityGet')  
    DECLARE   
         @ResultOption_Identifiers  TINYINT = 1  
        ,@ResultOption_Details      TINYINT = 2  
  
    -- Get model ID  
    IF @Model_ID IS NULL -- If the ID was already provided, don't bother looking it up again  
        AND (@Model_Name IS NOT NULL OR @Model_MUID IS NOT NULL)  
    BEGIN  
        SELECT   
             @Model_ID = ID  
            ,@Model_MUID = MUID  
            ,@Model_Name = Name  
        FROM mdm.tblModel  
        WHERE   MUID = ISNULL(@Model_MUID, MUID)  
            AND Name = ISNULL(@Model_Name, Name)  
  
        SET @Model_ID = COALESCE(@Model_ID, 0)  
    END  
  
    -- Get entity ID  
    DECLARE @Entity_ID INT;  
    IF @Entity_Name IS NOT NULL OR @Entity_MUID IS NOT NULL  
    BEGIN  
        SELECT  
             @Model_ID = Model_ID  
            ,@Entity_ID = ID  
            ,@Entity_MUID = MUID  
            ,@Entity_Name = Name  
        FROM mdm.tblEntity  
        WHERE   MUID = ISNULL(@Entity_MUID, MUID)  
            AND Name = ISNULL(@Entity_Name, Name)  
            AND Model_ID = ISNULL(@Model_ID, Model_ID) -- If a model filter is specified, use it  
  
        SET @Entity_ID = COALESCE(@Entity_ID, 0)  
    END  
  
    DECLARE @SelectedEntity TABLE   
    (  
         ID                 INT PRIMARY KEY  
        ,Model_ID           INT  
        ,Privilege_ID       TINYINT  
        ,AccessPermission   TINYINT  
        ,IsSyncTarget       BIT  
    )  
  
    INSERT INTO @SelectedEntity  
    SELECT  
         e.ID  
        ,e.Model_ID  
        ,acl.Privilege_ID  
        ,acl.AccessPermission  
        ,acl.IsSyncTarget  
    FROM mdm.tblEntity e  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ENTITY acl  
    ON e.ID = acl.ID  
    WHERE   acl.User_ID = @User_ID  
        AND e.Model_ID = ISNULL(@Model_ID, e.Model_ID)  
        AND e.ID = ISNULL(@Entity_ID, e.ID)  
        AND acl.Privilege_ID <> 1 -- Deny  
  
    IF @IncludeParentIdentifiers = 1  
    BEGIN  
        -- Return model Identifier(s)  
        IF @Model_ID IS NOT NULL  
        BEGIN  
            IF @Model_Name IS NULL OR @Model_MUID IS NULL  
            BEGIN  
                SELECT   
                     @Model_MUID = MUID  
                    ,@Model_Name = Name  
                FROM mdm.tblModel  
                WHERE ID = @Model_ID  
            END  
  
            -- A single model was specified, and its info has already been looked up, so simply return it  
            SELECT   
                 @Model_MUID    AS Model_MUID  
                ,@Model_Name    AS Model_Name  
                ,@Model_ID      AS Model_ID  
        END ELSE  
        BEGIN  
            SELECT DISTINCT  
                 m.MUID AS Model_MUID  
                ,m.Name AS Model_Name  
                ,m.ID   AS Model_ID  
            FROM @SelectedEntity e  
            INNER JOIN mdm.tblModel m  
            ON e.Model_ID = m.ID  
        END  
    END  
  
    SELECT  
         e.MUID AS Entity_MUID  
        ,e.Name AS Entity_Name  
        ,e.ID   AS Entity_ID  
        ,se.Privilege_ID  
        ,se.AccessPermission  
  
        ,se.Model_ID  
        ,e.CodeGenerationSeed  
        ,e.DataCompression  
        ,e.Description  
        ,e.IsBase  
        ,CONVERT(BIT, e.IsCodeGenerationEnabled) AS IsCodeGenerationEnabled  
        ,CONVERT(BIT, CASE WHEN e.CollectionTable IS NULL THEN 0 ELSE 1 END) AS IsCollectionEnabled  
        ,CONVERT(BIT, CASE WHEN e.HierarchyTable IS NULL THEN 0 ELSE 1 END) AS IsHierarchyEnabled  
        ,se.IsSyncTarget  
        ,e.RequireApproval  
        ,e.StagingBase  
        ,e.TransactionLogType  
  
        ,e.EnteredUser_DTM  
        ,e.EnteredUser_MUID  
        ,e.EnteredUser_UserName  
        ,e.EnteredUser_ID  
        ,e.LastChgUser_DTM  
        ,e.LastChgUser_MUID  
        ,e.LastChgUser_UserName  
        ,e.LastChgUser_ID  
    FROM @SelectedEntity se  
    INNER JOIN mdm.viw_SYSTEM_SCHEMA_ENTITY e  
    ON se.ID = e.Entity_ID  
    ORDER BY e.Model_ID, e.Name   
  
    IF @ResultOption = @ResultOption_Details  
    BEGIN  
        EXEC mdm.udpExplicitHierarchyGet  
             @User_ID = @User_ID  
            ,@Model_ID = @Model_ID  
            ,@Model_MUID = @Model_MUID  
            ,@Model_Name = @Model_Name  
            ,@Entity_ID = @Entity_ID  
            ,@Entity_MUID = @Entity_MUID  
            ,@Entity_Name = @Entity_Name  
            ,@HierarchyTable = @HierarchyTable  
            ,@IncludeParentIdentifiers = 0 -- parent Ids already returned  
            ,@Debug = @Debug  
            ,@CorrelationID = @CorrelationID  
  
        EXEC mdm.udpMemberTypeGet  
             @User_ID = @User_ID  
            ,@Model_MUID = @Model_MUID  
            ,@Model_Name = @Model_Name  
            ,@Model_ID = @Model_ID  
            ,@Entity_ID = @Entity_ID  
            ,@Entity_MUID = @Entity_MUID  
            ,@Entity_Name = @Entity_Name  
            ,@MemberType_ID = @MemberType_ID  
            ,@AttributeGroup_MUID = @AttributeGroup_MUID  
            ,@AttributeGroup_Name = @AttributeGroup_Name  
            ,@Attribute_MUID = @Attribute_MUID  
            ,@Attribute_Name = @Attribute_Name  
            ,@ResultOption = @ResultOption_Details  
            ,@IncludeParentIdentifiers = 0 -- parent Ids already returned  
            ,@OmitAttributes = 1 -- Attributes will be returned by a subsequent call  
            ,@Debug = @Debug  
            ,@CorrelationID = @CorrelationID  
  
        EXEC mdm.udpIndexGet  
             @User_ID = @User_ID  
            ,@Model_ID = @Model_ID  
            ,@Model_MUID = @Model_MUID  
            ,@Model_Name = @Model_Name  
            ,@Entity_ID = @Entity_ID  
            ,@Entity_MUID = @Entity_MUID  
            ,@Entity_Name = @Entity_Name  
            ,@Index_MUID = @Index_MUID  
            ,@Index_Name = @Index_Name  
            ,@ResultOption = @ResultOption_Details  
            ,@IncludeParentIdentifiers = 0 -- parent Ids already returned  
            ,@OmitAttributes = 1 -- Attributes will be returned by a subsequent call  
            ,@Debug = @Debug  
            ,@CorrelationID = @CorrelationID  
  
        EXEC mdm.udpAttributeGet  
             @User_ID = @User_ID  
            ,@Model_ID = @Model_ID  
            ,@Model_MUID = @Model_MUID  
            ,@Model_Name = @Model_Name  
            ,@Entity_ID = @Entity_ID  
            ,@Entity_MUID = @Entity_MUID  
            ,@Entity_Name = @Entity_Name  
            ,@MemberType_ID = @MemberType_ID  
            ,@AttributeGroup_MUID = @AttributeGroup_MUID  
            ,@AttributeGroup_Name = @AttributeGroup_Name  
            ,@Attribute_MUID = @Attribute_MUID  
            ,@Attribute_Name = @Attribute_Name  
            ,@IncludeParentIdentifiers = 0 -- parent Ids already returned  
            ,@Debug = @Debug  
            ,@CorrelationID = @CorrelationID  
    END   
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': end udpEntityGet')  
    SET NOCOUNT OFF  
END --proc
go

