/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
udpFileSave 1,'test.zip','application/x-zip-compressed','<Binary data>'  
  
select * from mdm.tblFile  
*/  
CREATE PROCEDURE mdm.udpFileSave  
(  
    @User_ID            INT,  
    @FileName           NVARCHAR(250),  
    @FileContentType    NVARCHAR(200),  
    @FileContent        VARBINARY(max),  
    @Return_ID          INT = NULL OUTPUT,  
    @CorrelationID      UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    --Insert the Data  
    INSERT INTO [mdm].[tblFile]  
    (  
        [FileName],  
        [FileContentType],  
        [FileContent],  
        [EnterDTM],  
        [EnterUserID],  
        [LastChgDTM],  
        [LastChgUserID]  
    )  
    VALUES  
    (  
        @FileName,  
        @FileContentType,  
        @FileContent,  
        GETUTCDATE(),  
        @User_ID,  
        GETUTCDATE(),  
        @User_ID  
    )  
  
    SELECT @Return_ID = SCOPE_IDENTITY()  
  
    SET NOCOUNT OFF  
END --proc
go

