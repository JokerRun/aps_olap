/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE VIEW mdm.viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED_LEVELS  
/*WITH SCHEMABINDING*/  
AS  
SELECT  
    dh.Model_ID     Model_ID,  
    m.MUID          Model_MUID,  
    m.Name          Model_Name,  
    dhd.DerivedHierarchy_ID Hierarchy_ID,   
    dh.MUID         Hierarchy_MUID,   
    dh.Name         Hierarchy_Name,   
    --  
    dhd.ID,  
    dhd.MUID,  
    dhd.Name,   
    dhd.DisplayName,   
    COALESCE(dhd.ForeignType_ID, 0) ForeignType_ID,  
    CASE dhd.ForeignType_ID  
        WHEN 0 THEN N'Entity'  
        WHEN 1 THEN N'Dba'  
        WHEN 2 THEN N'Hierarchy'  
        WHEN 5 THEN N'ManyToMany'  
        END ForeignType_Name,  
    COALESCE(e.ID, a.ID, h.ID, mapParentDBA.ID)          Foreign_ID,  
    COALESCE(e.MUID, a.MUID, h.MUID, mapParentDBA.MUID)  Foreign_MUID,  
    COALESCE(e.Name, a.Name, h.Name, mapParentDBA.Name)  Foreign_Name,  
      
    COALESCE(fe.ID, 0)                                  ForeignEntity_ID,  
    COALESCE(fe.MUID, CAST(0x0 AS UNIQUEIDENTIFIER))    ForeignEntity_MUID,  
    COALESCE(fe.Name, N'')                              ForeignEntity_Name,  
  
    -- When displaying members for a level, they will be members of this entity  
    COALESCE(e.ID, de.ID, he.ID, mapParentEntity.ID)          [Entity_ID],  
    COALESCE(e.MUID, de.MUID, he.MUID, mapParentEntity.MUID)  [Entity_MUID],  
    COALESCE(e.Name, de.Name, he.Name, mapParentEntity.Name)  [Entity_Name],  
  
    COALESCE(mapChildDBA.ID, 0)                                ManyToManyChildAttribute_ID,  
    COALESCE(mapChildDBA.MUID, CAST(0x0 AS UNIQUEIDENTIFIER))  ManyToManyChildAttribute_MUID,  
    COALESCE(mapChildDBA.Name, N'')                            ManyToManyChildAttribute_Name,  
  
    (tLevels.LevelCount - dhd.Level_ID )    LevelNumber, -- Ordered top-to-bottom, zero-based: 0 = top, N - 1 = bottom  
    dhd.Level_ID,                                        -- Ordered bottom-to-top, one-based: N = top, 1 = bottom  
      
    dhd.IsVisible IsLevelVisible,  
    CASE WHEN dhd.ForeignType_ID = 2 -- Hierarchy  
        THEN 2 -- Consolidated  
        ELSE 1 -- Leaf  
        END MemberType_ID,  
    CASE WHEN dhd.ForeignType_ID = 2 -- Hierarchy  
        THEN N'Consolidated'  
        ELSE N'Leaf'  
        END MemberType_Name,  
    CASE WHEN a.Entity_ID = a.DomainEntity_ID THEN 1 ELSE 0 END IsRecursive,  
      
    -- Audit info  
    COALESCE(dhd.EnterUserID, 0)                            Detail_EnteredUser_ID,  
    COALESCE(usrDetE.MUID, CAST(0x0 AS UNIQUEIDENTIFIER))   Detail_EnteredUser_MUID,  
    usrDetE.UserName                                        Detail_EnteredUser_UserName,  
    dhd.EnterDTM                                            Detail_EnteredUser_DTM,  
    COALESCE(dhd.LastChgUserID, 0)                          Detail_LastChgUser_ID,  
    COALESCE(usrDetL.MUID, CAST(0x0 AS UNIQUEIDENTIFIER))   Detail_LastChgUser_MUID,  
    usrDetL.UserName                                        Detail_LastChgUser_UserName,  
    dhd.LastChgDTM                                          Detail_LastChgUser_DTM  
FROM mdm.tblModel m  
INNER JOIN mdm.tblDerivedHierarchy dh   
ON m.ID = dh.Model_ID  
INNER JOIN -- Get the number of levels for each hierarchy. Used to invert the ordering (levels are ordered bottom-to-top in the db but top-to-bottom in the DataContracts)  
(  
    SELECT   
         DerivedHierarchy_ID  
        ,COUNT(Level_ID) LevelCount   
    FROM mdm.tblDerivedHierarchyDetail   
    GROUP BY DerivedHierarchy_ID  
) tLevels   
ON dh.ID = tLevels.DerivedHierarchy_ID  
INNER JOIN mdm.tblDerivedHierarchyDetail dhd  
ON dh.ID = dhd.DerivedHierarchy_ID  
  
LEFT JOIN mdm.tblEntity e  
ON      dhd.Foreign_ID = e.ID  
    AND dhd.ForeignType_ID = 0 -- Entity  
  
LEFT JOIN mdm.tblAttribute a  
ON      dhd.Foreign_ID = a.ID  
    AND dhd.ForeignType_ID = 1 -- DBA  
LEFT JOIN mdm.tblEntity de  
ON a.DomainEntity_ID = de.ID  
  
LEFT JOIN mdm.tblHierarchy h  
ON      dhd.Foreign_ID = h.ID  
    AND dhd.ForeignType_ID = 2 -- Explicit Hierarchy  
LEFT JOIN mdm.tblEntity he  
ON h.Entity_ID = he.ID  
  
LEFT JOIN mdm.tblAttribute mapParentDBA  
ON      dhd.Foreign_ID = mapParentDBA.ID  
    AND dhd.ForeignType_ID = 5 -- ManyToMany  
LEFT JOIN mdm.tblAttribute mapChildDBA  
ON      dhd.ManyToManyChildAttribute_ID = mapChildDBA.ID  
    AND dhd.ForeignType_ID = 5 -- ManyToMany  
LEFT JOIN mdm.tblEntity mapParentEntity -- The parent Entity referenced by the mapping Entity  
ON mapParentDBA.DomainEntity_ID = mapParentEntity.ID  
  
LEFT JOIN mdm.tblEntity fe  
ON ISNULL(ISNULL(a.Entity_ID, h.Entity_ID), mapParentDBA.Entity_ID) = fe.ID  
  
LEFT JOIN mdm.tblUser usrDetE   
ON dhd.EnterUserID = usrDetE.ID  
LEFT JOIN mdm.tblUser usrDetL   
ON dhd.LastChgUserID = usrDetL.ID
go

