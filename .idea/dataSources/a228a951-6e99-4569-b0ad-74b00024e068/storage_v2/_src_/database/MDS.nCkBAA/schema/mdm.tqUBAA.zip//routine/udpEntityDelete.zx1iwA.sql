/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    EXEC mdm.udpEntityDelete 1;  
    select * from mdm.tblEntity;  
*/  
CREATE PROCEDURE mdm.udpEntityDelete  
(  
    @Entity_ID      INT,  
    @CreateViewsInd BIT = NULL, --1=Create,0=DoNot Create. Typically only set to 0 when deleting the parent model.  
    @CorrelationID  UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON;  
  
    --Start transaction, being careful to check if we are nested  
    DECLARE @TranCounter INT;  
    SET @TranCounter = @@TRANCOUNT;  
    IF @TranCounter > 0 SAVE TRANSACTION TX;  
    ELSE BEGIN TRANSACTION;  
  
    BEGIN TRY  
  
        DECLARE  
             @SQL                       NVARCHAR(MAX)  
            ,@Model_ID                  INT  
            ,@Entity_MUID               UNIQUEIDENTIFIER  
            ,@TransactionTableName      SYSNAME  
            ,@ValidationLogTableName    SYSNAME  
            ,@ChangesetTableName        SYSNAME  
  
            ,@MemberType_Leaf           TINYINT = 1  
            ,@MemberType_Consolidated   TINYINT = 2  
            ,@MemberType_Collection     TINYINT = 3  
  
            ,@AttributeType_File        TINYINT = 4;  
  
        SET @CreateViewsInd = ISNULL(@CreateViewsInd, 1);  
  
        -- Remove any sync relationships for which the deleted entity is source.  
        DECLARE  
             @TargetVersion_ID  INT  
            ,@TargetEntity_ID   INT  
        CREATE TABLE #SyncRelationshipsToDelete  
        (  
             TargetVersion_ID   INT  
            ,TargetEntity_ID    INT  
        );  
        CREATE UNIQUE CLUSTERED INDEX #pk_SyncRelationshipsToDelete ON #SyncRelationshipsToDelete(TargetVersion_ID, TargetEntity_ID);  
        INSERT INTO #SyncRelationshipsToDelete  
        (  
             TargetVersion_ID  
            ,TargetEntity_ID  
        )  
        SELECT  
             sr.TargetVersion_ID  
            ,sr.TargetEntity_ID  
        FROM mdm.tblSyncRelationship sr  
        WHERE SourceEntity_ID = @Entity_ID;  
  
        WHILE EXISTS(SELECT 1 FROM #SyncRelationshipsToDelete)  
        BEGIN  
            SELECT TOP 1  
                 @TargetVersion_ID  = TargetVersion_ID  
                ,@TargetEntity_ID   = TargetEntity_ID  
            FROM #SyncRelationshipsToDelete  
  
            EXEC mdm.udpSyncRelationshipDelete  
                 @User_ID = 0 -- Unused when @IsVersionOrEntityDelete = 1  
                ,@TargetVersion_ID = @TargetVersion_ID  
                ,@TargetEntity_ID = @TargetEntity_ID  
                ,@IsVersionOrEntityDelete = 1  
                ,@CorrelationID = @CorrelationID  
  
            DELETE FROM #SyncRelationshipsToDelete  
            WHERE   TargetVersion_ID  = @TargetVersion_ID  
                AND TargetEntity_ID = @TargetEntity_ID  
        END;  
  
        -- Remove any sync relationships for which deleted entity is target.  
        -- Can directly delete from tblSyncRelationship. No need to call udpSyncRelationshipDelete since the applicable EN table and tblAttribute rows are being deleted.  
        DELETE mdm.tblSyncRelationship  
        WHERE TargetEntity_ID = @Entity_ID  
  
        -- Get list of Files that are referenced by File attributes values in the entity. These will be deleted after the entity tables are deleted.  
        CREATE TABLE #FileIDsToDelete  
        (  
            ID INT NOT NULL  
        )  
        -- Get the IDs of the Files referenced by the members being purged  
        SET @SQL = mdm.udfFileIDReferencesGetSQL(@Entity_ID, NULL, NULL, 0);  
        IF LEN(@SQL) > 0  
        BEGIN  
            SET @SQL = CONCAT(N'INSERT INTO #FileIDsToDelete(ID)  
', @SQL)  
            --PRINT @SQL  
            EXEC sp_executesql @SQL;  
        END  
  
        SELECT  
            @Model_ID = Model_ID,  
            @Entity_MUID = MUID  
        FROM mdm.tblEntity  
        WHERE ID = @Entity_ID;  
  
        --Get the transaction and annotation table names  
        SET @TransactionTableName = mdm.udfGetTransactionTableName(@Model_ID);  
        SET @ValidationLogTableName = mdm.udfGetValidationLogTableName(@Model_ID);  
        SET @ChangesetTableName = CONCAT(N'tbl_', @Model_ID, N'_CS');  
  
  
        --Delete the views  
        EXEC mdm.udpEntityStagingDeleteErrorDetailViews @Entity_ID;  
        EXEC mdm.udpDeleteViews @Model_ID, @Entity_ID, NULL;  
  
        --Delete all the entity related data  
        DECLARE    @Object_ID    INT;  
        SET @Object_ID = mdm.udfSecurityObjectIDGetByCode(N'DIMENT');  
  
  
        --Delete the subscription views associated with the entity  
        EXEC mdm.udpSubscriptionViewsDelete  
            @Model_ID               = NULL,  
            @Version_ID             = NULL,  
            @Entity_ID                = @Entity_ID,  
            @DerivedHierarchy_ID    = NULL;  
  
        --Delete the security maps  
        --EXEC mdm.udpHierarchyMapDelete @Entity_ID = @Entity_ID;  
        --DELETE hmq  
        --FROM mdm.tblHierarchyMapQueue hmq  
        --INNER JOIN mdm.tblHierarchy h  
        --    ON h.ID = hmq.Hierarchy_ID  
        --    AND hmq.HierarchyType_ID = 0 -- explicit hierarchies only  
        --    AND h.Entity_ID =@Entity_ID  
  
        DELETE FROM mdm.tblSecurityRoleAccessMember WHERE Entity_ID =@Entity_ID;  
  
        DECLARE @TempTable TABLE (  
             RowNumber      INT IDENTITY (1, 1) PRIMARY KEY CLUSTERED NOT NULL  
            ,Attribute_ID   INT NOT NULL);  
  
        --Delete the transaction table. The transaction annotation table will be cascade deleted.  
        SET @SQL = CONCAT(N'  
            DELETE [mdm].', QUOTENAME(@TransactionTableName), N'  
            WHERE Entity_ID = @Entity_ID;');  
        EXEC sp_executesql @SQL, N'@Entity_ID INT', @Entity_ID;  
  
        --Delete the related validation log  
        SET @SQL = CONCAT(N'  
            DELETE [mdm].', QUOTENAME(@ValidationLogTableName), N'  
            WHERE Entity_ID = @Entity_ID;');  
        EXEC sp_executesql @SQL, N'@Entity_ID INT', @Entity_ID;  
  
        --Delete the related changesets  
        SET @SQL = CONCAT(N'  
            DELETE [mdm].', QUOTENAME(@ChangesetTableName), N'  
            WHERE Entity_ID = @Entity_ID;');  
        EXEC sp_executesql @SQL, N'@Entity_ID INT', @Entity_ID;  
  
        --Get all related Domain Entity into temp table  
        INSERT INTO @TempTable  
        SELECT ID  
        FROM mdm.tblAttribute  
        WHERE   DomainEntity_ID = @Entity_ID  
            AND Entity_ID <> @Entity_ID -- ignore self-referencing attribute;  
  
        DECLARE  
             @TempAttribute_ID  INT  
            ,@Counter           INT = 1  
            ,@MaxCounter        INT = (SELECT MAX(RowNumber) FROM @TempTable);  
  
        --Delete all related data for the Entity being referenced by the Domain Entity records  
        -- and delete the domain Entity attribute record  
        WHILE @Counter <= @MaxCounter  
        BEGIN  
            SELECT  
                 @TempAttribute_ID = Attribute_ID  
            FROM @TempTable  
            WHERE [RowNumber] = @Counter ;  
  
            EXEC mdm.udpAttributeDelete @Attribute_ID = @TempAttribute_ID, @CreateViewsInd = @CreateViewsInd  
  
            SET @Counter += 1  
  
        END; --while  
  
        --Delete related meta data tables referencing the Entity including staging tables.  
        EXEC mdm.udpEntityMetaTablesDelete @Entity_ID;  
  
        DECLARE @DeletedChildObjects TABLE  
        (  
             MUID       UNIQUEIDENTIFIER PRIMARY KEY  
            ,Object_Type NVARCHAR(50)  
        );  
  
        --Delete indexes on the Entity  
        DELETE FROM mdm.tblIndex  
        OUTPUT deleted.MUID, N'Index'  
        INTO @DeletedChildObjects  
        WHERE Entity_ID = @Entity_ID;  
  
        --Delete the hierarchy referencing the Entity  
        DELETE FROM mdm.tblHierarchy  
        OUTPUT deleted.MUID, N'Hierarchy'  
        INTO @DeletedChildObjects  
        WHERE Entity_ID = @Entity_ID;  
  
        --Delete the tblAttributeGroupDetail records before we can delete  
        --the tblAttributeGroup records  
        DELETE FROM mdm.tblAttributeGroupDetail  
        FROM mdm.tblAttributeGroupDetail gt  
                INNER JOIN mdm.tblAttributeGroup g  
                 ON gt.AttributeGroup_ID = g.ID  
                WHERE g.Entity_ID = @Entity_ID;  
  
        --Delete the tblAttributeGroup records that reference the Entity  
        DELETE FROM mdm.tblAttributeGroup  
        OUTPUT deleted.MUID, N'AttributeGroup'  
        INTO @DeletedChildObjects  
        WHERE Entity_ID = @Entity_ID;  
  
        --Delete the security around all the attributes in this entity  
        DECLARE @Att_Object_ID INT = mdm.udfSecurityObjectIDGetByCode(N'DIMATT');  
        DELETE sra  
        FROM mdm.tblSecurityRoleAccess sra  
        INNER JOIN mdm.tblAttribute att  
        ON sra.Object_ID = @Att_Object_ID AND  
           sra.Securable_ID = att.ID AND  
           att.Entity_ID = @Entity_ID;  
  
        --Delete the attribute for the entity  
        DELETE FROM mdm.tblAttribute  
        OUTPUT deleted.MUID, N'Attribute'  
        INTO @DeletedChildObjects  
        WHERE Entity_ID = @Entity_ID;  
  
        --Delete Entity Based Staging Stored Procedures.  
        --Delete all types (0). Delete Leaf staging SProc. Then, if the entity supports hierarchies then delete Parent and Relation staging SProcs.  
        Exec mdm.udpEntityStagingDeleteStoredProcedures @Entity_ID, 0  
  
        --Delete the record(s) for the entity from staging batch table.  
        DELETE FROM mdm.tblStgBatch WHERE Entity_ID = @Entity_ID;  
  
        --Delete code generation information  
        DELETE FROM mdm.tblCodeGenInfo WHERE EntityId = @Entity_ID;  
  
        DELETE FROM mdm.tblEntity WHERE ID = @Entity_ID;  
        EXEC mdm.udpSecurityPrivilegesDelete NULL, NULL, @Object_ID, @Entity_ID;  
  
        --Delete associated user-defined metadata if the entity doesn't belong to a system model (metadata).  
        IF EXISTS(SELECT 1 FROM mdm.tblModel WHERE ID = @Model_ID) BEGIN  
            DECLARE  
                 @DeletedMuid UNIQUEIDENTIFIER  
                ,@Object_Type NVARCHAR(50);  
  
            -- Delete the child object metadata.  
            WHILE EXISTS (SELECT 1 FROM @DeletedChildObjects)  
            BEGIN  
                SELECT TOP 1  
                     @DeletedMuid = MUID  
                    ,@Object_Type = Object_Type  
                FROM @DeletedChildObjects;  
  
                DELETE FROM @DeletedChildObjects WHERE MUID = @DeletedMuid;  
            END;  
        END; -- if  
  
        -- Delete orphaned Files that were referenced by the entity  
        IF EXISTS (SELECT 1 FROM #FileIDsToDelete)  
        BEGIN  
  
            DECLARE @File_ID mdm.IdList;  
            INSERT INTO @File_ID  
            SELECT ID  
            FROM #FileIDsToDelete  
  
            EXEC mdm.udpFilesDelete @File_ID = @File_ID, @CorrelationID = @CorrelationID  
        END  
  
        --Commit only if we are not nested  
        IF @TranCounter = 0 COMMIT TRANSACTION;  
        RETURN(0);  
  
    END TRY  
    --Compensate as necessary  
    BEGIN CATCH  
  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        IF @TranCounter = 0 ROLLBACK TRANSACTION;  
        ELSE IF XACT_STATE() <> -1 ROLLBACK TRANSACTION TX;  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
  
        --On error, return NULL results  
        --SELECT @Return_ID = NULL;  
        RETURN(1);  
  
    END CATCH;  
  
    SET NOCOUNT OFF;  
END; --proc
go

