/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    SELECT * FROM mdm.viw_SYSTEM_SCHEMA_BUSINESSRULE_ITEMTYPES  
    SELECT * FROM mdm.viw_SYSTEM_SCHEMA_BUSINESSRULE_ITEMTYPES WHERE ApplyToCategoryID = 2 AND BRSubTypeIsVisible = 1 order by DisplaySequence, DisplaySubSequence  
    SELECT * FROM mdm.viw_SYSTEM_SCHEMA_BUSINESSRULE_ITEMTYPES WHERE BRItemType_ID = 28  
*/  
CREATE VIEW mdm.viw_SYSTEM_SCHEMA_BUSINESSRULE_ITEMTYPES  
/*WITH SCHEMABINDING*/  
AS  
SELECT  
        apl.ID AS AppliesTo_ID,  
        apl.ApplyTo_ID,  
        lrt.ID AS ApplyToCategoryID,  
        lrt.Name AS ApplyToCategory,  
        1 AS BRTypeID,  
        lr.Child_ID  AS BRSubTypeID,  
        1 AS BRSubTypeIsVisible,  
        apl.BRItemType_ID,  
        lr.Child_ID AS DisplaySequence,  
        ISNULL(apl.Sequence,-1) AS DisplaySubSequence  
FROM    mdm.tblBRItemTypeAppliesTo apl INNER JOIN  
        mdm.tblListRelationship lr ON lr.ID = apl.ApplyTo_ID INNER JOIN  
        mdm.tblListRelationshipType lrt ON lrt.ID = lr.ListRelationshipType_ID and lrt.ID = 1  
UNION ALL  
SELECT  
        apl.ID AS AppliesTo_ID,  
        apl.ApplyTo_ID,  
        lrt.ID AS ApplyToCategoryID,  
        lrt.Name AS ApplyToCategory,  
        p.OptionID AS BRTypeID,  
        c.OptionID AS BRSubTypeID,  
        c.IsVisible AS BRSubTypeIsVisible,  
        apl.BRItemType_ID,  
        c.Seq AS DisplaySequence,  
        ISNULL(apl.Sequence,-1) AS DisplaySubSequence  
FROM    mdm.tblBRItemTypeAppliesTo apl INNER JOIN  
        mdm.tblListRelationship lr ON lr.ID = apl.ApplyTo_ID INNER JOIN  
        mdm.tblListRelationshipType lrt ON lrt.ID = lr.ListRelationshipType_ID and lrt.ID = 2 INNER JOIN  
        mdm.tblList p ON p.OptionID = lr.Parent_ID AND p.ListCode = N'lstBRItemTypeCategory' INNER JOIN  
        mdm.tblList c ON c.OptionID = lr.Child_ID AND c.ListCode = N'lstBRItemTypeSubCategory'
go

