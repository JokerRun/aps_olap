/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE FUNCTION mdm.udfGetTableOptions  
(  
    @dataCompression    TINYINT,  
    @modelId            INT = NULL  
)  
RETURNS NVARCHAR(MAX)  
/*WITH SCHEMABINDING*/  
AS BEGIN  
    DECLARE @dataCompressionOption    NVARCHAR(MAX) = N'NONE',  
            @tableOptions             NVARCHAR(MAX) = N'';  
  
    IF mdm.udfIsEnterpriseEdition() = 1 AND @modelId IS NOT NULL  
    BEGIN  
        SET @tableOptions = CONCAT(N' ON udpsModel_', @modelId, N'([Version_ID])');  
    END  
  
    IF mdm.udfIsEnterpriseEdition() = 1  
    BEGIN  
        SET @dataCompressionOption = CASE @dataCompression WHEN 1 THEN N'ROW' WHEN 2 THEN N'PAGE' ELSE N'NONE' END;  
    END  
    SET @tableOptions = CONCAT(@tableOptions, N' WITH (DATA_COMPRESSION = ', @dataCompressionOption, N')');  
  
    RETURN @tableOptions;  
END; --fn
go

