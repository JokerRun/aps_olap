/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Returns a list of functions available for an active user  
  
Example 1  : SELECT * FROM mdm.udfSecurityUserFunctionList(NULL)  
Example 2  : SELECT * FROM mdm.udfSecurityUserFunctionList(2)  
*/  
CREATE FUNCTION mdm.udfSecurityUserFunctionList   
(  
    @User_ID INT = NULL  
)  
RETURNS TABLE   
/*WITH SCHEMABINDING*/  
AS RETURN  
    WITH permission AS (  
        SELECT RoleAccess_ID  
            ,RoleAccess_MUID  
  
            ,Principal_ID  
            ,Principal_MUID  
            ,PrincipalType_ID  
            ,Principal_Name  
  
            ,Function_ID  
            ,Function_Name  
  
            --Auditing  
            ,EnterDTM  
            ,EnterUserID  
            ,EnterUserMUID  
            ,EnterUserName  
            ,LastChgDTM  
            ,LastChgUserID  
            ,LastChgUserMUID  
            ,LastChgUserName  
            ,ROW_NUMBER() OVER (PARTITION BY Function_ID ORDER BY PrincipalType_ID, RoleAccess_ID DESC) AS rk  
        FROM mdm.viw_SYSTEM_SECURITY_USER_FUNCTION  
        WHERE @User_ID IS NULL OR @User_ID = [User_ID]  
    )  
    SELECT  
         RoleAccess_ID  
        ,RoleAccess_MUID  
  
        ,Principal_ID  
        ,Principal_MUID  
        ,PrincipalType_ID  
        ,Principal_Name  
  
        ,Function_ID  
        ,Function_Name  
  
        --Auditing  
        ,EnterDTM  
        ,EnterUserID  
        ,EnterUserMUID  
        ,EnterUserName  
        ,LastChgDTM  
        ,LastChgUserID  
        ,LastChgUserMUID  
        ,LastChgUserName  
    FROM permission  
    WHERE rk = 1
go

