/*  
declare @ret as NVARCHAR(500)  
exec mdm.udpSystemSettingGet 'BuiltInAdministrator',@ret OUTPUT  
select @ret  
*/  
/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpSystemSettingGet  
(  
	@SettingName 	NVARCHAR(100),  
	@SettingValue 	NVARCHAR(max) = NULL OUTPUT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
	SET NOCOUNT ON  
  
	SELECT	@SettingValue = SettingValue  
	FROM	mdm.tblSystemSetting  
	WHERE	SettingName = @SettingName  
  
	SET @SettingValue = ISNULL(@SettingValue, CAST(N'' AS NVARCHAR(max)) )  
  
	SET NOCOUNT OFF  
END --proc
go

