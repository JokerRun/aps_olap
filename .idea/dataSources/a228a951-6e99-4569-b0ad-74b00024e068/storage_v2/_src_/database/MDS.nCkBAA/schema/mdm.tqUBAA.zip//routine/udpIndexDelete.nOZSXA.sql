/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    EXEC mdm.udpIndexDelete null,1;  
    SELECT * FROM mdm.tblIndex;  
*/  
CREATE PROCEDURE mdm.udpIndexDelete  
(  
    @ID		    INT = NULL,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON;  
  
    --Start transaction, being careful to check if we are nested  
    DECLARE @TranCounter INT;   
    DECLARE	@Object_ID	INT;  
    DECLARE @IndexMUID UNIQUEIDENTIFIER;  
    DECLARE @TempModel_ID        INT,  
        @TempEntity_ID        INT;  
  
      
      
    IF @ID IS NULL RETURN;  
    --Get Entity  
    SELECT   
        @TempEntity_ID = Entity_ID,  
        @IndexMUID = MUID   
        FROM mdm.tblIndex WHERE ID = @ID;  
    IF @IndexMUID IS NULL RETURN;  
      
  
    --Get Model  
    SELECT   
        @TempModel_ID = e.Model_ID  
    FROM mdm.tblModelVersion AS mv  
    INNER JOIN mdm.tblEntity AS e ON (mv.Model_ID = e.Model_ID)  
    WHERE e.ID = @TempEntity_ID  
    GROUP BY e.Model_ID;  
      
      
  
    SET @TranCounter = @@TRANCOUNT;  
    IF @TranCounter > 0 SAVE TRANSACTION TX;  
    ELSE BEGIN TRANSACTION;  
  
    BEGIN TRY  
  
        DECLARE @SQL                    NVARCHAR(MAX);  
        DECLARE @TableName              sysname;  
        SET @TableName = CONCAT(N'tbl_', @TempModel_ID, N'_', @TempEntity_ID, N'_', N'EN');  
        DECLARE @SystemIndexName sysname;  
        DECLARE @EntityObjectID INT = OBJECT_ID(N'[mdm].' + QUOTENAME(@TableName));  
        SELECT @SystemIndexName = name from sys.indexes WHERE object_id = @EntityObjectID AND index_id = (SELECT SysIndex_ID from mdm.tblIndex where ID = @ID);  
  
          
        IF @SystemIndexName IS NOT NULL BEGIN  
            SET @SQL =  CONCAT(N'DROP INDEX', QUOTENAME(@SystemIndexName), N'ON mdm.', quotename(@TableName));  
            EXEC sp_executesql @SQL;  
        END  
  
        DELETE FROM mdm.tblIndex WHERE ID = @ID;  
  
        --Commit only if we are not nested  
        IF @TranCounter = 0 COMMIT TRANSACTION;  
        RETURN(0);  
  
    END TRY  
    --Compensate as necessary  
    BEGIN CATCH  
  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        IF @TranCounter = 0 ROLLBACK TRANSACTION;  
        ELSE IF XACT_STATE() <> -1 ROLLBACK TRANSACTION TX;  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);		  
  
        --On error, return NULL results  
        --SELECT @Return_ID = NULL;  
        RETURN(1);  
  
    END CATCH;  
  
    SET NOCOUNT OFF;  
END; --proc
go

