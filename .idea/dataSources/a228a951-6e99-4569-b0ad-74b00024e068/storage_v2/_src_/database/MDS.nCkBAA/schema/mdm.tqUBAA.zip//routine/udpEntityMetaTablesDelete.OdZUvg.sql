/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    EXEC mdm.udpEntityMetaTablesDelete 1;  
    select * from mdm.tblEntity;  
  
/******************************************************************************  
*  
** Desc:  The stored procedure will delete the following associated meta data tables  
          for an Entity:  
  
          _EN  
          _MS  
          _HP  
          _HR  
          _CM  
          _CN  
  
** Processing Steps:  
        1.  The existence of each table will be check first  
        2.  If the table exists, the drop statement will be executed.  
**  
** Parameters: @Entity_ID    INT  
**  
** Restart:  
        Restart at the beginning. No code modifications required.  
**  
** Tables Used:  
**        tbl_Modelxx_Entityzz_EN  (where xx is the model Id and zz is the Entity Id)  
**        tbl_Modelxx_Entityzz_HP  
**        tbl_Modelxx_Entityzz_HR  
**        tbl_Modelxx_Entityzz_CM  
**        tbl_Modelxx_Entityzz_CN  
**  
** Return values:  
        = 0 Success  
        = 1 Failure  
**  
** Called By:  
        udpEntityDelete  
**  
** Calls:  
        None  
**  
*******************************************************************************/  
*/  
  
CREATE PROCEDURE [mdm].[udpEntityMetaTablesDelete]  
(  
    @Entity_ID        INT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    --Start transaction, being careful to check if we are nested  
    DECLARE @TranCounter INT;  
    SET @TranCounter = @@TRANCOUNT;  
    IF @TranCounter > 0 SAVE TRANSACTION TX;  
    ELSE BEGIN TRANSACTION;  
  
    BEGIN TRY  
  
        DECLARE @SQL                        NVARCHAR(MAX),  
                @IsCollectionEnabled        BIT,  
                @IsHierarchyEnabled         BIT,  
                @EntityTable                SYSNAME,  
                @EntityHistoryTable         SYSNAME,  
                @EntityAnnotationTable      SYSNAME,  
                @EntityPendingTable         SYSNAME,  
                @EntitySecurityTable        SYSNAME,  
                @HierarchyTable             SYSNAME,  
                @HierarchyHistoryTable      SYSNAME,  
                @HierarchyAnnotationTable   SYSNAME,  
                @HierarchyParentTable       SYSNAME,  
                @HierarchyParentHistoryTable        SYSNAME,  
                @HierarchyParentAnnotationTable     SYSNAME,  
                @HierarchyParentSecurityTable       SYSNAME,  
                @CollectionTable            SYSNAME,  
                @CollectionHistoryTable     SYSNAME,  
                @CollectionAnnotationTable  SYSNAME,  
                @CollectionMemberTable      SYSNAME,  
                @CollectionMemberHistoryTable       SYSNAME,  
                @CollectionMemberAnnotationTable    SYSNAME,  
                @LeafStagingTable           SYSNAME,  
                @ConsolidatedStagingTable   SYSNAME,  
                @RelationshipStagingTable   SYSNAME,  
                @ConstraintName             SYSNAME,  
                @TempID                     INT,  
                @TempTableName              SYSNAME;  
  
        DECLARE @TableFKConstraints         TABLE  
                    ([ID] [INT]             IDENTITY (1, 1) Primary KEY CLUSTERED NOT NULL,  
                    TableName               SYSNAME,  
                    ConstraintName          SYSNAME);  
  
        --Set variables.  
        SET @SQL = N'';  
  
        SELECT  
            @EntityTable = EntityTable,  
            @EntityHistoryTable = CONCAT(EntityTable, N'_HS'),  
            @EntityAnnotationTable = CONCAT(EntityTable, N'_AN'),  
            @EntityPendingTable = CONCAT(EntityTable, N'_PD'),  
            @EntitySecurityTable = CAST(EntityTable + '_MS' AS SYSNAME),  
            @HierarchyTable = HierarchyTable,  
            @HierarchyHistoryTable = CONCAT(HierarchyTable, N'_HS'),  
            @HierarchyAnnotationTable = CONCAT(HierarchyTable, N'_AN'),  
            @HierarchyParentTable = HierarchyParentTable,  
            @HierarchyParentHistoryTable = CONCAT(HierarchyParentTable, N'_HS'),  
            @HierarchyParentAnnotationTable = CONCAT(HierarchyParentTable, N'_AN'),  
            @HierarchyParentSecurityTable = CAST(HierarchyParentTable + '_MS' AS SYSNAME),  
            @CollectionTable = CollectionTable,  
            @CollectionHistoryTable = CONCAT(CollectionTable, N'_HS'),  
            @CollectionAnnotationTable = CONCAT(CollectionTable, N'_AN'),  
            @CollectionMemberTable = CollectionMemberTable,  
            @CollectionMemberHistoryTable = CONCAT(CollectionMemberTable, N'_HS'),  
            @CollectionMemberAnnotationTable = CONCAT(CollectionMemberTable, N'_AN'),  
            @IsCollectionEnabled = CASE WHEN CollectionTable IS NULL THEN 0 ELSE 1 END,  
            @IsHierarchyEnabled  = CASE WHEN HierarchyTable  IS NULL THEN 0 ELSE 1 END  
        FROM  
            mdm.tblEntity  
        WHERE  
            ID = @Entity_ID;  
  
        --Get staging table names.  
        SELECT  
            @LeafStagingTable = COALESCE(StagingLeafTable, N''),  
            @ConsolidatedStagingTable = COALESCE(StagingConsolidatedTable, N''),  
            @RelationshipStagingTable = COALESCE(StagingRelationshipTable, N'')  
        FROM  
            mdm.viw_SYSTEM_SCHEMA_ENTITY WHERE ID = @Entity_ID;  
  
        -- Get all the foreign key constraints for the entity table - EN  
        DECLARE @EntityTableObjectID INT = object_id(N'mdm.' + QUOTENAME(@EntityTable));  
        INSERT INTO @TableFKConstraints  
                        SELECT  schema_name(schema_id) + '.' + QUOTENAME(object_name(parent_object_id)),  
                                s.[name]  
                        FROM sys.foreign_keys s  
                        WHERE referenced_object_id = @EntityTableObjectID;  
  
        -- Get all the foreign key constraints for the secutity table - MS  
        DECLARE @EntitySecurityTableObjectID INT = object_id(N'mdm.' + QUOTENAME(@EntitySecurityTable));  
        INSERT INTO @TableFKConstraints  
                        SELECT  schema_name(schema_id) + '.' + QUOTENAME(object_name(parent_object_id)),  
                                s.[name]  
                        FROM sys.foreign_keys s  
                        WHERE referenced_object_id = @EntitySecurityTableObjectID;  
  
                -- Get all the foreign key constraints for the secutity table - MS  
        DECLARE @HierarchyParentSecurityTableObjectID INT = object_id(N'mdm.' + QUOTENAME(@HierarchyParentSecurityTable));  
        INSERT INTO @TableFKConstraints  
                        SELECT  schema_name(schema_id) + '.' + QUOTENAME(object_name(parent_object_id)),  
                                s.[name]  
                        FROM sys.foreign_keys s  
                        WHERE referenced_object_id = @HierarchyParentSecurityTableObjectID;  
  
        -- Get all the foreign key constraints for the hierarchy table - HR  
        DECLARE @HierarchyTableObjectID INT = object_id(N'mdm.' + QUOTENAME(@HierarchyTable));  
        INSERT INTO @TableFKConstraints  
                        SELECT  schema_name(schema_id) + '.' + QUOTENAME(object_name(parent_object_id)),  
                                s.[name]  
                        FROM sys.foreign_keys s  
                        WHERE referenced_object_id = @HierarchyTableObjectID;  
  
        -- Get all the foreign key constraints for the hierarchy parent table - HP  
        DECLARE @HierarchyParentTableObjectID INT = object_id(N'mdm.' + QUOTENAME(@HierarchyParentTable));  
        INSERT INTO @TableFKConstraints  
                        SELECT  schema_name(schema_id) + '.' + QUOTENAME(object_name(parent_object_id)),  
                                s.[name]  
                        FROM sys.foreign_keys s  
                        WHERE referenced_object_id = @HierarchyParentTableObjectID;  
  
        -- Get all the foreign key constraints for the collection table - CN  
        DECLARE @CollectionTableObjectID INT = object_id(N'mdm.' + QUOTENAME(@CollectionTable));  
        INSERT INTO @TableFKConstraints  
                        SELECT  schema_name(schema_id) + '.' + QUOTENAME(object_name(parent_object_id)),  
                                s.[name]  
                        FROM sys.foreign_keys s  
                        WHERE referenced_object_id = @CollectionTableObjectID;  
  
        -- Get all the foreign key constraints for the collection member table - CM  
        DECLARE @CollectionMemberTableObjectID INT = object_id(N'mdm.' + QUOTENAME(@CollectionMemberTable));  
        INSERT INTO @TableFKConstraints  
                        SELECT  schema_name(schema_id) + '.' + QUOTENAME(object_name(parent_object_id)),  
                                s.[name]  
                        FROM sys.foreign_keys s  
                        WHERE referenced_object_id = @CollectionMemberTableObjectID;  
  
        -- Delete all the constraints first  
        DECLARE @Counter INT = 1 ;  
        DECLARE @MaxCounter INT = (SELECT MAX(ID) FROM @TableFKConstraints);  
        SET @Counter =1;  
        WHILE @Counter <= @MaxCounter  
        BEGIN  
            SELECT @TempID = ID, @TempTableName = TableName, @ConstraintName = ConstraintName  
                FROM @TableFKConstraints WHERE ID = @Counter;  
  
            SET @SQL = @SQL + N'ALTER TABLE ' + @TempTableName +  
                        ' DROP CONSTRAINT ' + @ConstraintName + N';'  
  
            SET @Counter = @Counter +1;  
        END  
  
        --Drop the related entity table  
        IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t WHERE t.TABLE_SCHEMA = N'mdm' AND t.TABLE_NAME = @EntityPendingTable)  
        BEGIN  
        SET @SQL += N'  
            DROP TABLE mdm.' + QUOTENAME(@EntityPendingTable) + ';';  
        END  
        IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t WHERE t.TABLE_SCHEMA = N'mdm' AND t.TABLE_NAME = @EntityAnnotationTable)  
        BEGIN  
        SET @SQL += N'  
            DROP TABLE mdm.' + QUOTENAME(@EntityAnnotationTable) + ';';  
        END  
        IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t WHERE t.TABLE_SCHEMA = N'mdm' AND t.TABLE_NAME = @EntityHistoryTable)  
        BEGIN  
        SET @SQL += N'  
            DROP TABLE mdm.' + QUOTENAME(@EntityHistoryTable) + ';';  
        END  
        IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t WHERE t.TABLE_SCHEMA = N'mdm' AND t.TABLE_NAME = @EntityTable)  
        BEGIN  
        SET @SQL += N'  
            DROP TABLE mdm.' + QUOTENAME(@EntityTable) + ';';  
        END  
        IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t WHERE t.TABLE_SCHEMA = N'mdm' AND t.TABLE_NAME = @EntitySecurityTable)  
        BEGIN  
        SET @SQL += N'  
            DROP TABLE mdm.' + QUOTENAME(@EntitySecurityTable) + ';';  
        END  
        IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t WHERE t.TABLE_SCHEMA = N'stg' AND t.TABLE_NAME = @LeafStagingTable)  
        BEGIN  
        SET @SQL += N'  
            DROP TABLE stg.' + QUOTENAME(@LeafStagingTable) + ';';  
        END  
  
        -- Drop the related hierarchy, hierarchy parent, collection and collection member tables if the Entity has them  
        -- Drop the related HierarchyParent table for Entity Based Staging  
  
        IF @IsCollectionEnabled = 1  
        BEGIN  
            IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t WHERE t.TABLE_SCHEMA = N'mdm' AND t.TABLE_NAME = @CollectionAnnotationTable)  
            BEGIN  
            SET @SQL += N'  
                DROP TABLE mdm.' + QUOTENAME(@CollectionAnnotationTable) + ';';  
            END  
            IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t WHERE t.TABLE_SCHEMA = N'mdm' AND t.TABLE_NAME = @CollectionHistoryTable)  
            BEGIN  
            SET @SQL += N'  
                DROP TABLE mdm.' + QUOTENAME(@CollectionHistoryTable) + ';';  
            END  
            IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t WHERE t.TABLE_SCHEMA = N'mdm' AND t.TABLE_NAME = @CollectionTable)  
            BEGIN  
            SET @SQL += N'  
                DROP TABLE mdm.' + QUOTENAME(@CollectionTable) + ';';  
            END  
            IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t WHERE t.TABLE_SCHEMA = N'mdm' AND t.TABLE_NAME = @CollectionMemberAnnotationTable)  
            BEGIN  
            SET @SQL += N'  
                DROP TABLE mdm.' + QUOTENAME(@CollectionMemberAnnotationTable) + ';';  
            END  
            IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t WHERE t.TABLE_SCHEMA = N'mdm' AND t.TABLE_NAME = @CollectionMemberHistoryTable)  
            BEGIN  
            SET @SQL += N'  
                DROP TABLE mdm.' + QUOTENAME(@CollectionMemberHistoryTable) + ';';  
            END  
            IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t WHERE t.TABLE_SCHEMA = N'mdm' AND t.TABLE_NAME = @CollectionMemberTable)  
            BEGIN  
            SET @SQL += N'  
                DROP TABLE mdm.' + QUOTENAME(@CollectionMemberTable) + ';';  
            END  
        END;  
  
        IF @IsHierarchyEnabled = 1  
        BEGIN  
            IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t WHERE t.TABLE_SCHEMA = N'stg' AND t.TABLE_NAME = @ConsolidatedStagingTable)  
            BEGIN  
            SET @SQL += N'  
                DROP TABLE stg.' + QUOTENAME(@ConsolidatedStagingTable) + ';';  
            END  
            IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t WHERE t.TABLE_SCHEMA = N'stg' AND t.TABLE_NAME = @RelationshipStagingTable)  
            BEGIN  
            SET @SQL += N'  
                DROP TABLE stg.' + QUOTENAME(@RelationshipStagingTable) + ';';  
            END  
            IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t WHERE t.TABLE_SCHEMA = N'mdm' AND t.TABLE_NAME = @HierarchyAnnotationTable)  
            BEGIN  
            SET @SQL += N'  
                DROP TABLE mdm.' + QUOTENAME(@HierarchyAnnotationTable) + ';';  
            END  
            IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t WHERE t.TABLE_SCHEMA = N'mdm' AND t.TABLE_NAME = @HierarchyHistoryTable)  
            BEGIN  
            SET @SQL += N'  
                DROP TABLE mdm.' + QUOTENAME(@HierarchyHistoryTable) + ';';  
            END  
            IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t WHERE t.TABLE_SCHEMA = N'mdm' AND t.TABLE_NAME = @HierarchyParentSecurityTable)  
            BEGIN  
            SET @SQL += N'  
                DROP TABLE mdm.' + QUOTENAME(@HierarchyParentSecurityTable) + ';';  
            END  
            IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t WHERE t.TABLE_SCHEMA = N'mdm' AND t.TABLE_NAME = @HierarchyTable)  
            BEGIN  
            SET @SQL += N'  
                DROP TABLE mdm.' + QUOTENAME(@HierarchyTable) + ';';  
            END  
                        IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t WHERE t.TABLE_SCHEMA = N'mdm' AND t.TABLE_NAME = @HierarchyParentAnnotationTable)  
            BEGIN  
            SET @SQL += N'  
                DROP TABLE mdm.' + QUOTENAME(@HierarchyParentAnnotationTable) + ';';  
            END  
            IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t WHERE t.TABLE_SCHEMA = N'mdm' AND t.TABLE_NAME = @HierarchyParentHistoryTable)  
            BEGIN  
            SET @SQL += N'  
                DROP TABLE mdm.' + QUOTENAME(@HierarchyParentHistoryTable) + ';';  
            END  
            IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t WHERE t.TABLE_SCHEMA = N'mdm' AND t.TABLE_NAME = @HierarchyParentTable)  
            BEGIN  
            SET @SQL += N'  
                DROP TABLE mdm.' + QUOTENAME(@HierarchyParentTable) + ';';  
            END  
        END;  
  
        EXEC sp_executesql @SQL;  
  
        --Commit only if we are not nested  
        IF @TranCounter = 0 COMMIT TRANSACTION;  
        RETURN(0);  
  
    END TRY  
    --Compensate as necessary  
    BEGIN CATCH  
  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
  
        IF @TranCounter = 0 ROLLBACK TRANSACTION;  
        ELSE IF XACT_STATE() <> -1 ROLLBACK TRANSACTION TX;  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
  
        RETURN(1);  
  
    END CATCH;  
  
    SET NOCOUNT OFF;  
END; --proc
go

