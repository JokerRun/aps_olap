/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    Returns the specified model privileges.  
  
    DECLARE @RoleAccessTable mdm.Identifier  
    EXEC udpSecurityPrivilegesModelGet  
        @Permission_ID          = NULL,  
        @Model_MUID             = NULL,  
        @Model_Name             = NULL,  
        @Securable_MUID         = NULL,  
        @Securable_Name         = NULL,  
        @Principal_MUID         = NULL,  
        @Principal_Name         = NULL,  
        @PrincipalType_ID       = NULL,  
        @RoleAccessTable        = @RoleAccessTable  
*/  
CREATE PROCEDURE mdm.udpSecurityPrivilegesModelGet  
(  
    @SystemUser_ID          INT, -- The user requesting the permissions  
    @Permission_ID          INT = NULL,  
    @AccessPermission_ID    TINYINT = NULL,  
    @Model_MUID             UNIQUEIDENTIFIER = NULL,  
    @Model_Name             NVARCHAR(100) = NULL,  
    @Securable_MUID         UNIQUEIDENTIFIER = NULL,  
    @Securable_Name         NVARCHAR(355) = NULL, -- Max group name length  
    @Principal_MUID         UNIQUEIDENTIFIER = NULL,  
    @Principal_Name         NVARCHAR(100) = NULL,  
    @PrincipalType_ID       INT = NULL,  
    @RoleAccessTable        mdm.Identifier READONLY,-- caller should ensure table does not include rows where both MUID and Name are blank  
    @CorrelationID          UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE  
         @EmptyMuid             UNIQUEIDENTIFIER = CONVERT(UNIQUEIDENTIFIER, 0x0)  
        ,@PrincipalType_User    TINYINT = 1  
        ,@Permission_Deny       TINYINT = 1;  
  
    SET @Permission_ID      = NULLIF(@Permission_ID, 0);  
    SET @Model_MUID         = NULLIF(@Model_MUID, @EmptyMuid);  
    SET @Model_Name         = NULLIF(@Model_Name, N'');  
    SET @Securable_MUID     = NULLIF(@Securable_MUID, @EmptyMuid);  
    SET @Securable_Name     = NULLIF(@Securable_Name, N'');  
    SET @Principal_MUID     = NULLIF(@Principal_MUID, @EmptyMuid);  
    SET @Principal_Name     = NULLIF(@Principal_Name, N'');  
    DECLARE @Principal_NameUpper NVARCHAR(355) = UPPER(@Principal_Name);  
    SET @PrincipalType_ID   = NULLIF(@PrincipalType_ID, 0);  
  
    IF EXISTS(SELECT 1 FROM @RoleAccessTable)  
    BEGIN  
        SELECT   
             rac.RoleAccess_ID  
            ,rac.RoleAccess_MUID  
            ,rac.Privilege_ID  
            ,rac.AccessPermission  
            ,rac.Object_ID  
            ,rac.Securable_ID  
            ,rac.Securable_MUID  
            ,rac.Securable_Name  
            ,rac.Model_ID  
            ,rac.Model_MUID  
            ,rac.Model_Name  
            ,rac.Principal_ID  
            ,rac.Principal_MUID  
            ,rac.PrincipalType_ID  
            ,rac.Principal_Name  
            ,rac.EnterUserID  
            ,rac.EnterUserMUID  
            ,rac.EnterUserName  
            ,rac.EnterDTM  
            ,rac.LastChgUserID  
            ,rac.LastChgUserMUID  
            ,rac.LastChgUserName  
            ,rac.LastChgDTM  
            ,rac.LastChgDTM  
            ,rac.IsModelAdministrator  
        FROM mdm.viw_SYSTEM_SECURITY_ROLE_ACCESSCONTROL rac  
        INNER JOIN @RoleAccessTable crit  
        ON      (crit.MUID IS NULL OR crit.MUID = rac.RoleAccess_MUID)  
            AND (crit.ID IS NULL OR crit.ID = rac.RoleAccess_ID)  
        INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_MODEL sysUserModel -- The requesting user's model permissions.  
        ON      rac.Model_ID = sysUserModel.ID  
            AND sysUserModel.User_ID = @SystemUser_ID  
        WHERE   (sysUserModel.Privilege_ID = 5 /*Admin*/                -- Requesting user can only see permissions if he is a model admin ...  
                    OR (    rac.Principal_ID = @SystemUser_ID           -- ... or is requesting his own permissions (except for Deny permissions)  
                        AND rac.PrincipalType_ID = @PrincipalType_User  
                        AND rac.Privilege_ID > @Permission_Deny))  
            AND (@Permission_ID IS NULL OR rac.Privilege_ID = @Permission_ID)  
            AND (@AccessPermission_ID IS NULL OR rac.AccessPermission = @AccessPermission_ID)  
            AND (@Model_MUID IS NULL OR rac.Model_MUID = @Model_MUID)  
            AND (@Model_Name IS NULL OR rac.Model_Name = @Model_Name)  
            AND (@Securable_MUID IS NULL OR rac.Securable_MUID = @Securable_MUID)  
            AND (@Securable_Name IS NULL OR rac.Securable_Name = @Securable_Name)  
            AND (@Principal_MUID IS NULL OR rac.Principal_MUID = @Principal_MUID)  
            AND (@Principal_Name IS NULL OR UPPER(rac.Principal_Name) = @Principal_NameUpper)  
            AND (@PrincipalType_ID IS NULL OR rac.PrincipalType_ID = @PrincipalType_ID)  
    END ELSE  
    BEGIN  
        SELECT   
             rac.RoleAccess_ID  
            ,rac.RoleAccess_MUID  
            ,rac.Privilege_ID  
            ,rac.AccessPermission  
            ,rac.Object_ID  
            ,rac.Securable_ID  
            ,rac.Securable_MUID  
            ,rac.Securable_Name  
            ,rac.Model_ID  
            ,rac.Model_MUID  
            ,rac.Model_Name  
            ,rac.Principal_ID  
            ,rac.Principal_MUID  
            ,rac.PrincipalType_ID  
            ,rac.Principal_Name  
            ,rac.EnterUserID  
            ,rac.EnterUserMUID  
            ,rac.EnterUserName  
            ,rac.EnterDTM  
            ,rac.LastChgUserID  
            ,rac.LastChgUserMUID  
            ,rac.LastChgUserName  
            ,rac.LastChgDTM  
            ,rac.LastChgDTM  
            ,rac.IsModelAdministrator  
        FROM mdm.viw_SYSTEM_SECURITY_ROLE_ACCESSCONTROL rac  
        INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_MODEL sysUserModel -- The requesting user's model permissions.  
        ON      rac.Model_ID = sysUserModel.ID  
            AND sysUserModel.User_ID = @SystemUser_ID  
        WHERE   (sysUserModel.Privilege_ID = 5 /*Admin*/                -- Requesting user can only see permissions if he is a model admin ...  
                    OR (    rac.Principal_ID = @SystemUser_ID           -- ... or is requesting his own permissions (except for Deny permissions)  
                        AND rac.PrincipalType_ID = @PrincipalType_User  
                        AND rac.Privilege_ID > @Permission_Deny))  
            AND (@Permission_ID IS NULL OR rac.Privilege_ID = @Permission_ID)  
            AND (@AccessPermission_ID IS NULL OR rac.AccessPermission = @AccessPermission_ID)  
            AND (@Model_MUID IS NULL OR rac.Model_MUID = @Model_MUID)  
            AND (@Model_Name IS NULL OR rac.Model_Name = @Model_Name)  
            AND (@Securable_MUID IS NULL OR rac.Securable_MUID = @Securable_MUID)  
            AND (@Securable_Name IS NULL OR rac.Securable_Name = @Securable_Name)  
            AND (@Principal_MUID IS NULL OR rac.Principal_MUID = @Principal_MUID)  
            AND (@Principal_Name IS NULL OR UPPER(rac.Principal_Name) = @Principal_NameUpper)  
            AND (@PrincipalType_ID IS NULL OR rac.PrincipalType_ID = @PrincipalType_ID)  
    END  
  
    SET NOCOUNT OFF;  
END; --proc
go

