/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    Removes all collection-related tables from the given entities.  
*/  
CREATE PROCEDURE mdm.udpCollectionTablesDrop  
(  
    @Entities       mdm.IdList READONLY,  
    @CorrelationID  UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE   
         @SQL                               NVARCHAR(MAX) = ''  
        ,@SQLDeleteViews                    NVARCHAR(MAX) = ''  
        ,@MemberType_Collection             TINYINT = 3  
        ,@MemberType_CollectionParentChild  TINYINT = 5  
  
    -- This pseudo-constant is for use in string concatenation operations to prevent string truncation. When concatenating two or more strings,  
    -- if none of the strings is an NVARCHAR(MAX) or an NVARCHAR constant that is longer than 4,000 characters, then the resulting string   
    -- will be silently truncated to 4,000 characters. Concatenating with this empty NVARCHAR(MAX), is sufficient to prevent truncation.  
    -- See http://connect.microsoft.com/SQLServer/feedback/details/283368/nvarchar-max-concatenation-yields-silent-truncation.  
        ,@TruncationGuard NVARCHAR(MAX) = N'';  
  
    DECLARE @EntityInfo TABLE  
    (  
         ID                     INT PRIMARY KEY  
        ,Model_ID               INT  
        ,IsHierarchyEnabled     BIT  
        ,CollectionMemberTable  SYSNAME  
        ,CollectionTable        SYSNAME  
    );  
    --Start transaction, being careful to check if we are nested  
    DECLARE @TranCounter INT;   
  
    SET @TranCounter = @@TRANCOUNT;  
    IF @TranCounter > 0 SAVE TRANSACTION TX;  
    ELSE BEGIN TRANSACTION;  
  
    BEGIN TRY  
  
        INSERT INTO @EntityInfo  
        SELECT DISTINCT   
             ei.ID  
            ,e.Model_ID  
            ,CASE WHEN e.HierarchyTable IS NULL THEN 0 ELSE 1 END IsHierarchyEnabled  
            ,e.CollectionMemberTable  
            ,e.CollectionTable  
        FROM @Entities ei  
        INNER JOIN mdm.tblEntity e  
        ON ei.ID = e.ID  
        WHERE e.CollectionTable IS NOT NULL;  
  
        IF EXISTS (SELECT 1 FROM @EntityInfo)  
        BEGIN  
            SELECT   
                @SQLDeleteViews += CONCAT(@TruncationGuard, N'  
EXEC mdm.udpDeleteViews ', Model_ID, N',', ID, N', NULL, 2 -- Collection views  
                '),  
  
                @SQL += CONCAT(@TruncationGuard, N'  
DROP TABLE mdm.', QUOTENAME(CollectionMemberTable + N'_AN'), N'  
DROP TABLE mdm.', QUOTENAME(CollectionMemberTable + N'_HS'), N'  
DROP TABLE mdm.', QUOTENAME(CollectionMemberTable), N'  
DROP TABLE mdm.', QUOTENAME(CollectionTable + N'_AN'), N'  
DROP TABLE mdm.', QUOTENAME(CollectionTable + N'_HS'), N'  
DROP TABLE mdm.', QUOTENAME(CollectionTable), N'  
  
-- Recreate the staging sprocs, because they reference the collection table to check for code uniqueness.  
EXEC mdm.udpEntityStagingCreateLeafStoredProcedure ', ID, N';',   
            CASE WHEN IsHierarchyEnabled = 1 THEN CONCAT(N'  
EXEC mdm.udpEntityStagingCreateConsolidatedStoredProcedure ', ID, N';') END)  
            FROM @EntityInfo;  
  
PRINT CONCAT(SYSDATETIME(), N': Deleting collection system views'); -- Note that this must be done before clearing the tlbEntity columns  
            --PRINT @@SQLDeleteViews;  
            EXEC sp_executesql @SQLDeleteViews;  
  
PRINT CONCAT(SYSDATETIME(), N': Clearing collection member table info from tblEntity');  
            UPDATE e  
            SET   
                 CollectionTable = NULL  
                ,CollectionMemberTable = NULL  
            FROM @EntityInfo ei  
            INNER JOIN mdm.tblEntity e  
            ON ei.ID = e.ID;  
  
PRINT CONCAT(SYSDATETIME(), N': Removing collection-related attributes from tblAttribute');  
            DELETE a  
            FROM mdm.tblAttribute a  
            INNER JOIN @EntityInfo ei  
            ON a.Entity_ID = ei.ID  
            WHERE a.MemberType_ID IN (@MemberType_Collection, @MemberType_CollectionParentChild)  
  
PRINT CONCAT(SYSDATETIME(), N': Deleting collection tables');  
            --PRINT @SQL;  
            EXEC sp_executesql @SQL;  
        END  
  
        --Commit only if we are not nested  
        IF @TranCounter = 0 COMMIT TRANSACTION;  
        RETURN(0);  
  
    END TRY  
    --Compensate as necessary  
    BEGIN CATCH  
  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        IF @TranCounter = 0 ROLLBACK TRANSACTION;  
        ELSE IF XACT_STATE() <> -1 ROLLBACK TRANSACTION TX;  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);		  
  
        --On error, return NULL results  
        --SELECT @Return_ID = NULL;  
        RETURN(1);  
  
    END CATCH;  
  
    SET NOCOUNT OFF;  
END; --proc
go

