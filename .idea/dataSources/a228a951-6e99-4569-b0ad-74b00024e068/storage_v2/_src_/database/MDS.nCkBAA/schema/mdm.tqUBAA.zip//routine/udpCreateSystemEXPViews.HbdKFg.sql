/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    --Create for All Entities  
    DECLARE @Entities TABLE(ID INT)  
    DECLARE @EntityID INT  
    INSERT INTO @Entities SELECT ID FROM mdm.tblEntity ORDER BY ID  
    WHILE(SELECT COUNT(*) FROM @Entities) <> 0  
    BEGIN  
        SELECT TOP 1 @EntityID = ID FROM @Entities  
        EXEC mdm.udpCreateSystemEXPViews @EntityID,1  
        EXEC mdm.udpCreateSystemEXPViews @EntityID,2  
        EXEC mdm.udpCreateSystemEXPViews @EntityID,3  
        DELETE FROM @Entities WHERE ID=@EntityID  
    END  
  
    --account  
    EXEC mdm.udpCreateSystemEXPViews 41,1;  
    EXEC mdm.udpCreateSystemEXPViews 7,2;  
    EXEC mdm.udpCreateSystemEXPViews 7,3;  
  
    exec mdm.udpcreateallviews  
  
    --vld Branch  
    SELECT top 100 * FROM mdm.viw_SYSTEM_8_41_CHILDATTRIBUTES_EXP WHERE Version_ID = 21 ORDER BY Code  
  
    -_Account  
    SELECT * FROM mdm.viw_SYSTEM_2_7_CHILDATTRIBUTES_EXP WHERE Version_ID=4 order by Code;  
    SELECT * FROM mdm.viw_SYSTEM_2_9_CHILDATTRIBUTES_EXP WHERE Version_ID=4 order by Code;  
      
    SELECT * FROM mdm.viw_SYSTEM_2_7_PARENTATTRIBUTES_EXP;  
    SELECT * FROM mdm.viw_SYSTEM_2_7_COLLECTIONATTRIBUTES_EXP;  
*/  
CREATE PROCEDURE mdm.udpCreateSystemEXPViews   
(  
    @EntityID       INT,  
    @MemberTypeID   TINYINT,  
    @ViewType       TINYINT = 0, -- 0 EN, 2 HS  
    @CorrelationID  UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)   
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    --Defer view generation if we are in the middle of an upgrade or demo-rebuild  
    IF APPLOCK_MODE(N'public', N'DeferViewGeneration', N'Session') = N'NoLock' BEGIN  
  
        DECLARE @EntityViewName                 SYSNAME,  
                @ParentChildViewName            SYSNAME,  
                @CollectionParentChildViewName  SYSNAME,  
                @ViewName                       SYSNAME,  
                @SQL                            NVARCHAR(MAX),  
                @TruncateGuard                  NVARCHAR(MAX) = N'',  
                @MemberType_Leaf                TINYINT = 1,  
                @MemberType_Consolidated        TINYINT = 2,  
                @MemberType_Collection          TINYINT = 3,  
                @MemberType_ParentChild             TINYINT = 4,  
                @MemberType_CollectionParentChild   TINYINT = 5,  
                @ViewType_EN                    TINYINT = 0,  
                @ViewType_HS                    TINYINT = 2,  
                @IsHierarchyEnabled             BIT = 0,  
                @IsCollectionEnabled            BIT = 0;  
  
        SELECT  
             @IsHierarchyEnabled  = CASE WHEN HierarchyParentTable IS NULL THEN 0 ELSE 1 END  
            ,@IsCollectionEnabled = CASE WHEN CollectionTable      IS NULL THEN 0 ELSE 1 END  
        FROM tblEntity  
        WHERE ID = @EntityID;  
  
        --Check to see if you are trying to create Parent/Collection Attributes view on an entity that does not support it. If so exit.  
        IF     (@IsHierarchyEnabled  = 0 AND @MemberTypeID = @MemberType_Consolidated)  
            OR (@IsCollectionEnabled = 0 AND @MemberTypeID = @MemberType_Collection)  
        BEGIN  
            RETURN(0);  
        END;  
  
        --Get the view names  
        SELECT   
            @EntityViewName = mdm.udfViewNameGetByID(@EntityID, @MemberTypeID, 0, 0), -- ends with "_[CHILD|PARENT|COLLECTION]ATTRIBUTES"  
            @ParentChildViewName = mdm.udfViewNameGetByID(@EntityID, @MemberType_ParentChild,0, @ViewType), -- ends with "_PARENTCHILD"  
            @CollectionParentChildViewName = mdm.udfViewNameGetByID(@EntityID, @MemberType_CollectionParentChild,0, @ViewType), -- ends with "_COLLECTIONPARENTCHILD"  
            @ViewName = mdm.udfViewNameGetByID(@EntityID, @MemberTypeID, 1, @ViewType); -- ends with "_[CHILD|PARENT|COLLECTION]ATTRIBUTES_EXP"  
  
        SET @SQL = @TruncateGuard + N'  
            SELECT   
                 T.*';  
        IF @IsHierarchyEnabled = 1 AND @MemberTypeID IN (@MemberType_Leaf, @MemberType_Consolidated)  
        BEGIN  
            SET @SQL += N'  
                ,PDL.Status_ID AS [Parent_Status_ID]  
                ,PDL.Parent_Code AS [Parent_Code]  
                ,PDL.Parent_Name AS [Parent_Name]  
                ,PDL.Hierarchy_MUID AS [Parent_HierarchyMuid]  
                ,PDL.Hierarchy_Name AS [Parent_HierarchyName]  
                ,PDL.Hierarchy_ID AS [Parent_HierarchyId]  
                ,PDL.Child_SortOrder AS [Child_SortOrder]  
                ,PDL.[LastChgTS] AS [Parent_LastChgTS]  
  
                --Auditing columns (Creation)  
                ,PDL.[EnterDTM] AS [Parent_EnterDTM]  
                ,PDL.[EnterUserID] AS [Parent_EnterUserID]  
                ,PDL.[EnterUserName] AS [Parent_EnterUserName]  
                ,PDL.[EnterUserMuid] AS [Parent_EnterUserMuid]  
  
                --Auditing columns (Updates)  
                ,PDL.[LastChgDTM] AS [Parent_LastChgDTM]  
                ,PDL.[LastChgUserID] AS [Parent_LastChgUserID]  
                ,PDL.[LastChgUserName] AS [Parent_LastChgUserName]  
                ,PDL.[LastChgUserMuid] AS [Parent_LastChgUserMuid]'  
        END  
        ELSE  
        BEGIN  
            SET @SQL += N'  
                ,NULL AS [Parent_Status_ID]  
                ,NULL AS [Parent_Code]  
                ,NULL AS [Parent_Name]  
                ,NULL AS [Parent_HierarchyMuid]  
                ,NULL AS [Parent_HierarchyName]  
                ,NULL AS [Parent_HierarchyId]  
                ,NULL AS [Child_SortOrder]  
                ,NULL AS [Parent_LastChgTS]  
  
                --Auditing columns (Creation)  
                ,NULL AS [Parent_EnterDTM]  
                ,NULL AS [Parent_EnterUserID]  
                ,NULL AS [Parent_EnterUserName]  
                ,NULL AS [Parent_EnterUserMuid]  
  
                --Auditing columns (Updates)  
                ,NULL AS [Parent_LastChgDTM]  
                ,NULL AS [Parent_LastChgUserID]  
                ,NULL AS [Parent_LastChgUserName]  
                ,NULL AS [Parent_LastChgUserMuid]'  
        END  
  
        IF @IsCollectionEnabled = 1  
        BEGIN  
            SET @SQL += N'  
                ,CDL.Status_ID AS [Collection_Status_ID]  
                ,CDL.Parent_Code as Collection_Code  
                ,CDL.Parent_Name as Collection_Name  
                ,CDL.SortOrder AS Collection_SortOrder  
                ,CDL.[Weight] AS Collection_Weight  
                ,CDL.[LastChgTS] AS [Collection_LastChgTS]  
  
                --Auditing columns (Creation)  
                ,CDL.[EnterDTM] AS [Collection_EnterDTM]  
                ,CDL.[EnterUserID] AS [Collection_EnterUserID]  
                ,CDL.[EnterUserName] AS [Collection_EnterUserName]  
                ,CDL.[EnterUserMuid] AS [Collection_EnterUserMuid]  
  
                --Auditing columns (Updates)  
                ,CDL.[LastChgDTM] AS [Collection_LastChgDTM]  
                ,CDL.[LastChgUserID] AS [Collection_LastChgUserID]  
                ,CDL.[LastChgUserName] AS [Collection_LastChgUserName]  
                ,CDL.[LastChgUserMuid] AS [Collection_LastChgUserMuid]'  
        END  
        ELSE  
        BEGIN  
            SET @SQL += N'  
                ,NULL AS [Collection_Status_ID]  
                ,NULL AS Collection_Code  
                ,NULL AS Collection_Name  
                ,NULL AS Collection_SortOrder  
                ,NULL AS Collection_Weight  
                ,NULL AS [Collection_LastChgTS]  
  
                --Auditing columns (Creation)  
                ,NULL AS [Collection_EnterDTM]  
                ,NULL AS [Collection_EnterUserID]  
                ,NULL AS [Collection_EnterUserName]  
                ,NULL AS [Collection_EnterUserMuid]  
  
                --Auditing columns (Updates)  
                ,NULL AS [Collection_LastChgDTM]  
                ,NULL AS [Collection_LastChgUserID]  
                ,NULL AS [Collection_LastChgUserName]  
                ,NULL AS [Collection_LastChgUserMuid]'  
        END  
  
        SET @SQL += N'  
            FROM   
                mdm.' + QUOTENAME(@EntityViewName) + ' AS T';  
          
        IF @IsHierarchyEnabled = 1 AND @MemberTypeID IN (@MemberType_Leaf, @MemberType_Consolidated) BEGIN  
            SET @SQL += N'  
            OUTER APPLY (  
                SELECT *  
                FROM mdm.' + QUOTENAME(@ParentChildViewName) + N'  
                WHERE   
                    Version_ID = T.Version_ID AND   
                    T.ID = ' + CASE @MemberTypeID WHEN @MemberType_Leaf THEN + ' Child_EN_ID ' WHEN @MemberType_Consolidated THEN + ' Child_HP_ID ' WHEN @MemberType_Collection THEN + ' Child_EN_ID ' END + N' AND   
                    ChildType_ID = ' + CONVERT(NVARCHAR(30), @MemberTypeID) + N'  
                --FOR XML PATH (N''Parent''), ELEMENTS, TYPE  
            ) AS PDL --PDL(XmlColumn);'  
        END;  
  
        IF @IsCollectionEnabled = 1  
        BEGIN  
            SET @SQL += N'  
            LEFT JOIN mdm.' + QUOTENAME(@CollectionParentChildViewName) + N' CDL  
            ON   
                CDL.Version_ID = T.Version_ID AND   
                T.ID = ' + CASE @MemberTypeID WHEN @MemberType_Leaf THEN + ' CDL.Child_EN_ID ' WHEN @MemberType_Consolidated THEN + ' CDL.Child_HP_ID ' WHEN @MemberType_Collection THEN + ' CDL.Child_CN_ID ' END + N' AND   
                CDL.ChildType_ID = ' + CONVERT(NVARCHAR(30), @MemberTypeID) + N'  
                ';  
        END; --if  
  
        --Alter or create the view	  
        SET @SQL = CASE  
            WHEN EXISTS(SELECT 1 FROM sys.views WHERE [name] = @ViewName AND [schema_id] = SCHEMA_ID(N'mdm')) THEN N'ALTER'  
            ELSE N'CREATE'  
        END + N' VIEW mdm.' + QUOTENAME(@ViewName) + N'  
            /*WITH ENCRYPTION*/ AS'  
            + @SQL;  
  
        --PRINT @SQL;  
        EXEC sp_executesql @SQL;  
  
    END; --if  
  
    SET NOCOUNT OFF;  
END --proc
go

