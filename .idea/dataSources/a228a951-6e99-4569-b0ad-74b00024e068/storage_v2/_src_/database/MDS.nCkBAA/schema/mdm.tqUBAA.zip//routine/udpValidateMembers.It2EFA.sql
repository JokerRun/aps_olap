/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpValidateMembers  
(  
    @User_ID INT,   
    @Version_ID INT,  
    @Entity_ID INT,  
    @MemberIdList mdm.IdList READONLY,   
    @MemberType_ID TINYINT,  
    @ProcessUIRulesOnly BIT = 0,  
    @ReturnChangedIds BIT = 0,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    /*  
    Business Rule Process options.  Any combination can be present.  
    Bits              876543210  
    ===================================  
    Default          = 000000001 =  1  
    ChangeValue      = 000000010 =  2  
    Assignment       = 000000011 =  3  
    Validation       = 000000100 =  4  
    UI               = 000001000 =  8  
    ExternalAction   = 000010000 =  16  
    Logging          = 010000000 =  128  
    ReturnChangedIds = 100000000 =  256  
    */  
    DECLARE @ProcessOptions	               INT;  
    DECLARE @ProcessOptionDefault          INT = 1;  
    DECLARE @ProcessOptionChangeValue      INT = 2;  
    DECLARE @ProcessOptionAssignments      INT = @ProcessOptionDefault | @ProcessOptionChangeValue;  
    DECLARE @ProcessOptionValidation       INT = 4;  
    DECLARE @ProcessOptionUI               INT = 8;  
    DECLARE @ProcessOptionExternalAction   INT = 16;  
    DECLARE @ProcessOptionLogging          INT = 128;  
    DECLARE @ProcessOptionReturnChangedIds INT = 256;  
  
    IF @ProcessUIRulesOnly = 1  
    BEGIN  
        SET @ProcessOptions = @ProcessOptionUI;  
    END  
    ELSE  
    BEGIN  
        SET @ProcessOptions = @ProcessOptionAssignments | @ProcessOptionValidation | @ProcessOptionLogging | @ProcessOptionExternalAction;  
          
        IF @ReturnChangedIds = 1  
        BEGIN  
            SET @ProcessOptions |= @ProcessOptionReturnChangedIds;  
        END  
    END  
  
    --Call the Business Rules Controller to process rules for the member(s)  
    EXEC mdm.udpBusinessRule_AttributeMemberController @User_ID, @Version_ID, @Entity_ID, @MemberIdList, @MemberType_ID, @ProcessOptions  
  
    SET NOCOUNT OFF  
END --proc
go

