/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Looks up the IDs and MemberTypes of the given list of member codes for the given entity and version. If the code  
cannot be found, it is omitted from the result set. This is the set-based version of the udpMemberTypeIDAndIDGetByCode  
sproc that only operates on a single member.  
  
DECLARE    @MemberIds      mdm.MemberId;  
INSERT INTO @MemberIds (Code) VALUES (N'MyMemberCode')  
EXEC mdm.udpMembersTypeIDAndIDGetByCode  
     @Version_ID =    3  
    ,@Entity_ID =     6  
    ,@ActiveMembersOnly = 1  
    ,@MemberIds = @MemberIds;  
*/  
CREATE PROCEDURE mdm.udpMembersTypeIDAndIDGetByCode  
(  
     @Version_ID        INT  
    ,@Entity_ID         INT  
    ,@ActiveMembersOnly BIT = 1 -- When 1, inactive (soft-deleted) members are ignored.  
    ,@MemberIds         mdm.MemberId READONLY,  
    @CorrelationID      UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
    DECLARE  
         @SQL                       NVARCHAR(MAX)  
        ,@TableName                 SYSNAME  
  
        -- Member types  
        ,@MemberType_NotSpecified   TINYINT = 0  
        ,@MemberType_Leaf           TINYINT = 1  
        ,@MemberType_Consolidated   TINYINT = 2  
        ,@MemberType_Collection     TINYINT = 3  
  
        -- IDs of special hierarchy parent node members  
        ,@MemberId_RootNode         INT = 0  
        ,@MemberCode_RootNode       NVARCHAR(250) = N'ROOT'  
        ,@MemberId_UnusedNode       INT = -1  
        ,@MemberCode_UnusedNode     NVARCHAR(250) = N'MDMUNUSED'  
          
        ,@GuidEmpty                 UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER);  
  
    -- Create a table to store member info. Use a temp table rather than a table var so that it can be used by dynamic SQL (can't pass a table var as a parameter)  
    CREATE TABLE #MemberIdsWorkingSet  
    (  
         Code           NVARCHAR(250) COLLATE DATABASE_DEFAULT  
        ,ID             INT  
        ,MemberType_ID  TINYINT  
        ,MUID           UNIQUEIDENTIFIER  
    );  
    CREATE INDEX #ix_MemberIdsWorkingSet_ID ON #MemberIdsWorkingSet(ID);  
    CREATE INDEX #ix_MemberIdsWorkingSet_Code ON #MemberIdsWorkingSet(Code);  
    CREATE INDEX #ix_MemberIdsWorkingSet_MUID ON #MemberIdsWorkingSet(MUID);  
  
    ;WITH memberIdsCte AS  
    (  
        SELECT --DISTINCT  
            NULLIF(LTRIM(RTRIM(Code)), N'') Code, -- Trim member code,  
            NULLIF(MUID, @GuidEmpty) MUID  
        FROM @MemberIds  
    )  
    INSERT INTO #MemberIdsWorkingSet (Code, MUID, MemberType_ID, ID)  
    SELECT  
         Code  
        ,MUID  
        ,CASE UPPER(Code)  
            WHEN @MemberCode_RootNode THEN @MemberType_NotSpecified  
            WHEN @MemberCode_UnusedNode THEN @MemberType_Consolidated  
            END  
        ,CASE UPPER(Code)  
            WHEN @MemberCode_RootNode THEN @MemberId_RootNode  
            WHEN @MemberCode_UnusedNode THEN @MemberId_UnusedNode  
            END  
    FROM memberIdsCte  
    WHERE Code IS NOT NULL OR MUID IS NOT NULL  
  
    DECLARE @QueryTemplate NVARCHAR(MAX) = CONCAT(N'  
UPDATE ws  
SET  
     ws.ID              = mem.ID  
    ,ws.Code            = mem.Code  
    ,ws.MUID            = mem.MUID  
    ,ws.MemberType_ID   = {MemberTypePlaceholder}  
FROM #MemberIdsWorkingSet ws  
INNER JOIN mdm.{TableNamePlaceholder} mem  
ON      mem.Version_ID = @Version_ID  
    AND ws.{ColumnNamePlaceholder} = mem.{ColumnNamePlaceholder}  
WHERE ws.ID IS NULL  -- Skip rows that have already been looked up.',   
    CASE WHEN @ActiveMembersOnly = 1 THEN N'  
    AND mem.Status_ID = 1 -- Skip rows that have been soft-deleted.'   
    END, N'  
');  
  
    --Type 1 (EntityTable)  
    SET @TableName = mdm.udfTableNameGetByID(@Entity_ID, 1 /*EntityTable*/);  
  
    DECLARE @LeafQueryTemplate NVARCHAR(MAX) =   
        REPLACE(  
            REPLACE(@QueryTemplate,   
                N'{MemberTypePlaceholder}', @MemberType_Leaf),  
            N'{TableNamePlaceholder}', @TableName);  
      
    -- !!!Matching on MUID and Code is done in two separate queries on purpose. Combining the two results in significantly worse performance!!!  
    SET @SQL = CONCAT(  
        REPLACE(@LeafQueryTemplate, N'{ColumnNamePlaceholder}', N'MUID'),  
        REPLACE(@LeafQueryTemplate, N'{ColumnNamePlaceholder}', N'Code'))  
  
    EXEC sp_executesql @SQL, N'@Version_ID INT', @Version_ID;  
  
    --Type 2 (HierarchyParentTable)  
    SET @TableName = mdm.udfTableNameGetByID(@Entity_ID, 2 /*HierarchyParentTable*/);  
    IF EXISTS(SELECT 1 FROM #MemberIdsWorkingSet WHERE ID IS NULL) AND  
       @TableName IS NOT NULL  
    BEGIN  
        DECLARE @ConsolidatedQueryTemplate NVARCHAR(MAX) =   
            REPLACE(  
                REPLACE(@QueryTemplate,   
                    N'{MemberTypePlaceholder}', @MemberType_Consolidated),  
                N'{TableNamePlaceholder}', @TableName);  
      
        SET @SQL = CONCAT(  
            REPLACE(@ConsolidatedQueryTemplate, N'{ColumnNamePlaceholder}', N'MUID'),  
            REPLACE(@ConsolidatedQueryTemplate, N'{ColumnNamePlaceholder}', N'Code'))  
  
        EXEC sp_executesql @SQL, N'@Version_ID INT', @Version_ID;  
    END  
  
  
    --Type 3 (CollectionTable)  
    SELECT @TableName = mdm.udfTableNameGetByID(@Entity_ID, 3 /*CollectionTable*/);  
    IF EXISTS(SELECT 1 FROM #MemberIdsWorkingSet WHERE ID IS NULL) AND  
       @TableName IS NOT NULL  
    BEGIN  
        DECLARE @CollectionQueryTemplate NVARCHAR(MAX) =   
            REPLACE(  
                REPLACE(@QueryTemplate,   
                    N'{MemberTypePlaceholder}', @MemberType_Collection),  
                N'{TableNamePlaceholder}', @TableName);  
  
        SET @SQL = CONCAT(  
            REPLACE(@CollectionQueryTemplate, N'{ColumnNamePlaceholder}', N'MUID'),  
            REPLACE(@CollectionQueryTemplate, N'{ColumnNamePlaceholder}', N'Code'))  
  
        EXEC sp_executesql @SQL, N'@Version_ID INT', @Version_ID;  
    END; --if  
  
    -- Return member info  
    SELECT  
        ID,  
        MemberType_ID,  
        Code,  
        MUID  
    FROM #MemberIdsWorkingSet  
    WHERE ID IS NOT NULL; -- Do not include invalid member codes in the result set  
  
    SET NOCOUNT OFF;  
END; --proc
go

