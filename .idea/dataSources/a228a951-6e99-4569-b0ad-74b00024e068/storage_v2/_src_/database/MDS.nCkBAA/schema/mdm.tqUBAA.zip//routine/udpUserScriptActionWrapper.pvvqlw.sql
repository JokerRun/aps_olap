/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpUserScriptActionWrapper  
(     
    @ScriptName SYSNAME,      
    @MemberIdList mdm.[MemberId] READONLY,  
    @ModelName NVARCHAR(50),  
    @VersionName NVARCHAR(50),  
    @EntityName NVARCHAR(50),  
    @BusinessRuleName NVARCHAR(50)  
)     
WITH EXECUTE AS 'mds_br_user'  
AS BEGIN      
    IF EXISTS (SELECT 1 FROM @MemberIdList)  
    BEGIN  
        DECLARE @Sql NVARCHAR(500) = 'EXEC usr.'+ @ScriptName +N' @MemberIdList, @BRP_ModelName ,@BRP_EntityName ,@BRP_VersionName, @BRP_BRName'  
           
        EXEC sp_executesql @Sql,N'@MemberIdList mdm.[MemberId] READONLY, @BRP_ModelName NVARCHAR(50), @BRP_EntityName NVARCHAR(50), @BRP_VersionName NVARCHAR(50),@BRP_BRName NVARCHAR(50)',     
                                   @MemberIdList,        @ModelName,        @EntityName,     @VersionName, @BusinessRuleName;    
    END  
END
go

