/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpVersionFlagGet  
(  
     @User_ID       INT  
  
    ,@Model_MUID    UNIQUEIDENTIFIER = NULL  
    ,@Model_Name    NVARCHAR(50) = NULL  
    ,@Model_ID      INT = NULL -- set internally only  
  
    ,@VersionFlag_MUID  UNIQUEIDENTIFIER = NULL  
    ,@VersionFlag_Name  NVARCHAR(50) = NULL  
  
    ,@IncludeParentIdentifiers  BIT = 1 -- Return results sets for parent Model and Entity identifiers. Set to 0 when getting attributes as part of a parent object (because the parent identifiers will already have been looked up).  
    ,@Debug                     BIT = 0  
    ,@CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
  
    SET NOCOUNT ON  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': begin udpVersionFlagGet')  
  
    -- Get model ID  
    IF @Model_ID IS NULL -- If the ID was already provided, don't bother looking it up again  
        AND (@Model_Name IS NOT NULL OR @Model_MUID IS NOT NULL)  
    BEGIN  
        SELECT   
             @Model_ID = ID  
            ,@Model_MUID = MUID  
            ,@Model_Name = Name  
        FROM mdm.tblModel  
        WHERE   MUID = ISNULL(@Model_MUID, MUID)  
            AND Name = ISNULL(@Model_Name, Name)  
  
        SET @Model_ID = COALESCE(@Model_ID, 0)  
    END  
  
    -- Get version flag ID  
    DECLARE @VersionFlag_ID INT = NULL;  
    IF @VersionFlag_Name IS NOT NULL OR @VersionFlag_MUID IS NOT NULL  
    BEGIN  
        SELECT   
             @VersionFlag_ID = ID  
            ,@VersionFlag_MUID = MUID  
            ,@VersionFlag_Name = Name  
        FROM mdm.tblModelVersionFlag  
        WHERE   MUID = ISNULL(@VersionFlag_MUID, MUID)  
            AND Name = ISNULL(@VersionFlag_Name, Name)  
            AND Model_ID = ISNULL(@Model_ID, Model_ID) -- If a model filter is specified, use it  
  
        SET @VersionFlag_ID = COALESCE(@VersionFlag_ID, 0)  
    END  
  
    DECLARE @SelectedVersionFlag TABLE   
    (  
         ID                 INT PRIMARY KEY  
        ,Model_ID           INT  
        ,Privilege_ID       TINYINT  
        ,AccessPermission   TINYINT  
    )  
  
    INSERT INTO @SelectedVersionFlag  
    SELECT  
         vf.ID  
        ,vf.Model_ID  
        ,acl.Privilege_ID  
        ,acl.AccessPermission  
    FROM mdm.tblModelVersionFlag vf  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_MODEL acl  
    ON vf.Model_ID = acl.ID  
    WHERE   acl.User_ID = @User_ID  
        AND vf.Model_ID = ISNULL(@Model_ID, vf.Model_ID)  
        AND vf.ID = ISNULL(@VersionFlag_ID, vf.ID)  
        AND vf.Status_ID = 1  
        AND acl.Privilege_ID <> 1 /*Deny*/  
  
    IF @IncludeParentIdentifiers = 1  
    BEGIN  
        -- Return model Identifier(s)  
        IF @Model_ID IS NOT NULL  
        BEGIN  
            IF @Model_Name IS NULL OR @Model_MUID IS NULL  
            BEGIN  
                SELECT   
                     @Model_MUID = MUID  
                    ,@Model_Name = Name  
                FROM mdm.tblModel  
                WHERE ID = @Model_ID  
            END  
  
            -- A single model was specified, and its info has already been looked up, so simply return it  
            SELECT   
                 @Model_MUID    AS Model_MUID  
                ,@Model_Name    AS Model_Name  
                ,@Model_ID      AS Model_ID  
        END ELSE  
        BEGIN  
            SELECT DISTINCT  
                 m.MUID AS Model_MUID  
                ,m.Name AS Model_Name  
                ,m.ID   AS Model_ID  
            FROM @SelectedVersionFlag vf  
            INNER JOIN mdm.tblModel m  
            ON vf.Model_ID = m.ID  
        END  
    END  
  
    SELECT  
         vf.MUID    AS VersionFlag_MUID  
        ,vf.Name    AS VersionFlag_Name  
        ,vf.ID      AS VersionFlag_ID  
        ,svf.Privilege_ID  
        ,svf.AccessPermission  
  
        ,svf.Model_ID  
  
        ,vf.Description  
        ,vf.IsCommittedOnly  
  
        ,NULLIF(vf.AssignedVersion_MUID, 0x0)   AS AssignedVersion_MUID  
        ,NULLIF(vf.AssignedVersion_Name, N'')   AS AssignedVersion_Name  
        ,NULLIF(vf.AssignedVersion_ID, 0)       AS AssignedVersion_ID  
  
        ,vf.EnteredUser_DTM  
        ,vf.EnteredUser_MUID  
        ,vf.EnteredUser_UserName  
        ,vf.EnteredUser_ID  
        ,vf.LastChgUser_DTM  
        ,vf.LastChgUser_MUID  
        ,vf.LastChgUser_UserName  
        ,vf.LastChgUser_ID  
    FROM @SelectedVersionFlag svf  
    INNER JOIN mdm.viw_SYSTEM_SCHEMA_VERSION_FLAGS vf  
    ON svf.ID = vf.ID  
    ORDER BY   
         vf.Model_MUID  
        ,vf.Name  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': end udpVersionFlagGet')  
  
    SET NOCOUNT OFF  
END --proc
go

