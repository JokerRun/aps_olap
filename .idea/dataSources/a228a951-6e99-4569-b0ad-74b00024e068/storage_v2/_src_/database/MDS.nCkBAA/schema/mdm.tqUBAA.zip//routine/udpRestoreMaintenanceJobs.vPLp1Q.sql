/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
  
CREATE PROCEDURE mdm.udpRestoreMaintenanceJobs  
(  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
AS BEGIN  
    DECLARE @databaseName SYSNAME = DB_NAME(),  
            @jobName SYSNAME,  
            @jobId UNIQUEIDENTIFIER,  
            @stepName SYSNAME,  
  
            @scheduleName SYSNAME,  
            @scheduleId INT;  
  
    SET @jobId = NULL;  
    SET @scheduleId = NULL;  
    SET @jobName = CONCAT(N'MDS_', @databaseName, N'_Index_Maintenance');  
    SELECT @jobId = job_id FROM [msdb].[dbo].[sysjobs_view] WHERE [name] = @jobName;  
    IF @jobId IS NULL  
    BEGIN  
        EXEC [msdb].[dbo].sp_add_job  
            @job_name = @jobName,  
            @job_id = @jobId OUTPUT;  
    END  
  
    SET @stepName = CONCAT(N'MDS_', @databaseName, N'_Index_Maintenance_TablePartition');  
    IF NOT EXISTS (  
        SELECT 1 FROM [msdb].[dbo].[sysjobsteps]  
        WHERE job_id = @jobId AND step_name = @stepName  
    )  
    BEGIN  
        EXEC [msdb].[dbo].sp_add_jobstep  
            @step_id = 1,  
            @job_id = @jobId,  
            @step_name = @stepName,  
            @subsystem = N'TSQL',  
            @command = N'EXEC [mdm].[udpTablePartitionCheck];',  
            @database_name = @databaseName,  
            @retry_attempts = 3,  
            @retry_interval = 60, -- 1 hour  
            @on_success_action = 3, -- Go to next step  
            @on_fail_action = 3; -- Go to next step  
    END  
  
    SET @stepName = CONCAT(N'MDS_', @databaseName, N'_Index_Maintenance_Defragmentation');  
    IF NOT EXISTS (  
        SELECT 1 FROM [msdb].[dbo].[sysjobsteps]  
        WHERE job_id = @jobId AND step_name = @stepName  
    )  
    BEGIN  
        EXEC [msdb].[dbo].sp_add_jobstep  
            @step_id = 2,  
            @job_id = @jobId,  
            @step_name = @stepName,  
            @subsystem = N'TSQL',  
            @command = N'EXEC [mdm].[udpDefragmentation];',  
            @database_name = @databaseName,  
            @retry_attempts = 3,  
            @retry_interval = 60, -- 1 hour  
            @on_success_action = 1, -- Quit with success  
            @on_fail_action = 1; -- Quit with success  
    END  
  
    SET @scheduleName = CONCAT(N'MDS_', @databaseName, N'_Index_Maintenance_Schedule');  
    SELECT @scheduleId = schedule_id FROM [msdb].[dbo].sysschedules WHERE name = @scheduleName;  
    IF @scheduleId IS NULL  
    BEGIN  
        EXEC [msdb].[dbo].sp_add_schedule  
            @schedule_name = @scheduleName,  
            @freq_type = 8, -- Weekly  
            @freq_interval = 64, -- Saturday  
            @freq_subday_type = 1, -- At the specified time  
            @freq_recurrence_factor = 1, -- Every 1 week  
            @active_start_time = 20000, -- 2AM  
            @schedule_id = @scheduleId OUTPUT;  
    END  
  
    IF NOT EXISTS(  
        SELECT 1 FROM [msdb].[dbo].[sysjobschedules]  
        WHERE job_id = @jobId AND schedule_id = @scheduleId  
    )  
    BEGIN  
        EXEC [msdb].[dbo].sp_attach_schedule  
            @job_id = @jobId,  
            @schedule_id = @scheduleId;  
    END  
  
    IF NOT EXISTS(  
        SELECT 1 FROM [msdb].[dbo].[sysjobservers]  
        WHERE job_id = @jobId  
    )  
    BEGIN  
        EXEC [msdb].[dbo].sp_add_jobserver  
            @job_id = @jobId;  
    END  
  
    SET @jobId = NULL;  
    SET @scheduleId = NULL;  
    SET @jobName = CONCAT(N'MDS_', @databaseName, N'_Log_Maintenance');  
    SELECT @jobId = job_id FROM [msdb].[dbo].[sysjobs_view] WHERE [name] = @jobName  
    IF @jobId IS NULL  
    BEGIN  
        EXEC [msdb].[dbo].sp_add_job  
            @job_name = @jobName,  
            @job_id = @jobId OUTPUT;  
    END  
  
    SET @stepName = CONCAT(N'MDS_', @databaseName, N'_Log_Maintenance_CleanUp');  
    IF NOT EXISTS (  
        SELECT 1 FROM [msdb].[dbo].[sysjobsteps]  
        WHERE job_id = @jobId AND step_name = @stepName  
    )  
    BEGIN  
        EXEC [msdb].[dbo].sp_add_jobstep  
            @job_id = @jobId,  
            @step_name = @stepName,  
            @subsystem = N'TSQL',  
            @command = N'EXEC [mdm].[udpLogCleanup];',  
            @database_name = @databaseName,  
            @retry_attempts = 3,  
            @retry_interval = 10; -- 10 minute  
    END  
  
    SET @scheduleName = CONCAT(N'MDS_', @databaseName, N'_Log_Maintenance_Schedule');  
    SELECT @scheduleId = schedule_id FROM [msdb].[dbo].sysschedules WHERE name = @scheduleName  
    IF @scheduleId IS NULL  
    BEGIN  
        EXEC [msdb].[dbo].sp_add_schedule  
            @schedule_name = @scheduleName,  
            @freq_type = 4, -- Daily  
            @freq_interval = 1, -- Every Day  
            @freq_subday_type = 1, -- At the specified time  
            @active_start_time = 20000 , -- 2AM  
            @schedule_id = @scheduleId OUTPUT;  
   END  
  
    IF NOT EXISTS(  
        SELECT 1 FROM [msdb].[dbo].[sysjobschedules]  
        WHERE job_id = @jobId AND schedule_id = @scheduleId  
    )  
    BEGIN  
        EXEC [msdb].[dbo].sp_attach_schedule  
            @job_id = @jobId,  
            @schedule_id = @scheduleId;  
    END  
  
    IF NOT EXISTS(  
        SELECT 1 FROM [msdb].[dbo].[sysjobservers]  
        WHERE job_id = @jobId  
    )  
    BEGIN  
        EXEC [msdb].[dbo].sp_add_jobserver  
            @job_id = @jobId;  
    END  
  
  
    -- Sync  
  
    SET @jobId = NULL;  
    SET @scheduleId = NULL;  
    SET @jobName = CONCAT(N'MDS_', @databaseName, N'_Sync');  
    SELECT @jobId = job_id FROM [msdb].[dbo].[sysjobs_view] WHERE [name] = @jobName;  
    IF @jobId IS NULL  
    BEGIN  
        EXEC [msdb].[dbo].sp_add_job  
            @job_name = @jobName,  
            @job_id = @jobId OUTPUT;  
    END  
  
    SET @stepName = CONCAT(N'MDS_', @databaseName, N'_Sync_Refresh');  
    IF NOT EXISTS (  
        SELECT 1 FROM [msdb].[dbo].[sysjobsteps]  
        WHERE job_id = @jobId AND step_name = @stepName  
    )  
    BEGIN  
        EXEC [msdb].[dbo].sp_add_jobstep  
            @job_id = @jobId,  
            @step_name = @stepName,  
            @subsystem = N'TSQL',  
            @command = N'EXEC [mdm].[udpSyncRefreshJob];',  
            @database_name = @databaseName,  
            @retry_attempts = 3,  
            @retry_interval = 5; -- minutes  
    END  
  
    SET @scheduleName = CONCAT(N'MDS_', @databaseName, N'_Sync_Refresh_Schedule');  
    SELECT @scheduleId = schedule_id FROM [msdb].[dbo].sysschedules WHERE name = @scheduleName;  
    IF @scheduleId IS NULL  
    BEGIN  
        EXEC [msdb].[dbo].sp_add_schedule  
            @schedule_name = @scheduleName,  
            @freq_type = 4, -- Daily  
            @freq_interval = 1, -- every 1 day  
            @freq_subday_type = 0x8, -- Hours  
            @freq_subday_interval  = 1, -- every 1 hour  
            @freq_relative_interval = 0,  
            @freq_recurrence_factor = 1, -- Every 1 hour  
            @schedule_id = @scheduleId OUTPUT;  
    END  
  
    IF NOT EXISTS(  
        SELECT 1 FROM [msdb].[dbo].[sysjobschedules]  
        WHERE job_id = @jobId AND schedule_id = @scheduleId  
    )  
    BEGIN  
        EXEC [msdb].[dbo].sp_attach_schedule  
            @job_id = @jobId,  
            @schedule_id = @scheduleId;  
    END  
  
    IF NOT EXISTS(  
        SELECT 1 FROM [msdb].[dbo].[sysjobservers]  
        WHERE job_id = @jobId  
    )  
    BEGIN  
        EXEC [msdb].[dbo].sp_add_jobserver  
            @job_id = @jobId  
    END  
END
go

