/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
/*  
--Returns the index name and ID based on the SystemName of the index.  
*/  
CREATE PROCEDURE [mdm].[udpGetIndexNameBySystemName]    
(    
    @SystemName             sysname,        
    @CorrelationID          UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability    
)    
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
  
    SELECT TOP 1 idx.Name as UserDefinedName, idx.MUID as IndexMUID  
        FROM mdm.tblIndex AS idx  
        INNER JOIN sys.indexes as sysIdx ON sysIdx.name = @SystemName   
        AND idx.SysIndex_ID = sysIdx.index_id  
  
END --proc
go

