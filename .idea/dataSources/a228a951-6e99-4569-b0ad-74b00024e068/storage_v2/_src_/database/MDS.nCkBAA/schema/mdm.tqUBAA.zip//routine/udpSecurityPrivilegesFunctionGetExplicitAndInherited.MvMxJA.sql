/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Gets all functional permissions, both explicit and inherited from group,  
of the given user. Overlapping user and group permissions are not combined  
and are listed separately.  
  
EXEC mdm.udpSecurityPrivilegesFunctionGetExplicitAndInherited  @User_ID = 1  
*/  
CREATE PROCEDURE mdm.udpSecurityPrivilegesFunctionGetExplicitAndInherited  
(  
    @User_ID INT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    SELECT  
         RoleAccess_ID  
        ,RoleAccess_MUID  
  
        ,Principal_ID  
        ,Principal_MUID  
        ,PrincipalType_ID  
        ,Principal_Name  
  
        ,Function_ID  
        ,Function_Name  
  
        -- Audit info  
        ,EnterDTM  
        ,EnterUserID  
        ,EnterUserMUID  
        ,EnterUserName  
        ,LastChgDTM  
        ,LastChgUserID  
        ,LastChgUserMUID  
        ,LastChgUserName  
    FROM mdm.viw_SYSTEM_SECURITY_USER_FUNCTION  
    WHERE [User_ID] = @User_ID  
  
    SET NOCOUNT OFF;  
END
go

