/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
/*  
  Rebuild or Reorganize the index with more than 5% fragment  
  http://msdn.microsoft.com/en-us/library/ms189858.aspx  
*/  
CREATE PROCEDURE [mdm].[udpDefragmentation]  
(  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
AS BEGIN  
    DECLARE @schema SYSNAME,  
            @table SYSNAME,  
            @index SYSNAME,  
            @onlineOption SYSNAME = N'OFF',  
            @fragPrecent DECIMAL,  
            @sql NVARCHAR(MAX);  
    IF mdm.udfIsEnterpriseEdition() = 1  
    BEGIN  
        SET @onlineOption = N'ON';  
    END  
    DECLARE fragmentIndexes CURSOR FOR  
    SELECT OBJECT_SCHEMA_NAME(a.[object_id]), OBJECT_NAME(a.[object_id]), name, avg_fragmentation_in_percent  
    FROM sys.dm_db_index_physical_stats (DB_ID(), null, NULL, NULL, NULL) AS a  
        JOIN sys.indexes AS b ON a.[object_id] = b.[object_id] AND a.index_id = b.index_id  
    WHERE avg_fragmentation_in_percent >= 5  
    ORDER BY avg_fragmentation_in_percent DESC;  
  
    OPEN fragmentIndexes;  
    FETCH NEXT FROM fragmentIndexes INTO @schema, @table, @index, @fragPrecent;  
  
    WHILE @@FETCH_STATUS = 0  
    BEGIN  
        IF @fragPrecent<= 30.0  
        BEGIN  
            SET @sql = N'ALTER INDEX ' + QUOTENAME(@index) + N' ON ' + QUOTENAME(@schema) + '.' + QUOTENAME(@table) + N' REORGANIZE';  
            -- PRINT @sql  
            EXEC (@sql);  
        END  
        ELSE  
        BEGIN  
            SET @sql = N'ALTER INDEX ' + QUOTENAME(@index) + N' ON ' + QUOTENAME(@schema) + '.' + QUOTENAME(@table) + N' REBUILD WITH (ONLINE = '+ @onlineOption + N')';  
            -- PRINT @sql  
            EXEC (@sql);  
        END  
        FETCH NEXT FROM fragmentIndexes INTO @schema, @table, @index, @fragPrecent;  
    END  
    CLOSE fragmentIndexes;  
    DEALLOCATE fragmentIndexes;  
END
go

