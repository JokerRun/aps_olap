/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpBusinessRuleLogicalOperatorGroupSave  
(  
    @User_ID                INT = NULL,  
    @SaveMode               TINYINT = 0, -- 0 = Create, 1 = Clone, 2 = Update  
    @Rule_MUID              UNIQUEIDENTIFIER = NULL,  
    @LogicalOperator_ID     INT = NULL, /* 1= AND, 2 = OR */  
    @Parent_MUID            UNIQUEIDENTIFIER = NULL,  
    @Sequence               INT = NULL,  
    @MUID                   UNIQUEIDENTIFIER = NULL OUTPUT, /*Input (Clone only) and output*/  
    @ID                     INT = NULL OUTPUT, /*Output only*/  
    @CorrelationID          UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    DECLARE @Rule_ID                        INT,  
            @Parent_ID                      INT,  
            @Entity_ID                      INT,  
  
            @Model_Permission               INT,  
  
            @Permission_Deny                INT = 1,  
            @Permission_Admin               INT = 5,  
  
            @GuidEmpty                      UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER),  
  
            @SaveMode_Create                TINYINT = 0,  
            @SaveMode_Clone                 TINYINT = 1,  
            @SaveMode_Update                TINYINT = 2;  
  
    SELECT  
        @Rule_MUID = NULLIF(@Rule_MUID, @GuidEmpty),  
        @Parent_MUID = NULLIF(@Parent_MUID, @GuidEmpty),  
        @MUID = NULLIF(@MUID, @GuidEmpty),  
        @ID = NULL;  
  
    IF @SaveMode = @SaveMode_Clone  
    BEGIN  
        IF @MUID IS NOT NULL AND EXISTS (SELECT 1 FROM mdm.tblBRLogicalOperatorGroup WHERE MUID = @MUID)  
        BEGIN  
            SET @SaveMode = @SaveMode_Update;  
        END  
        ELSE  
        BEGIN  
            SET @SaveMode = @SaveMode_Create;  
        END  
    END  
  
    IF @SaveMode = @SaveMode_Create  
    BEGIN  
        SET @MUID = COALESCE(@MUID, NEWID());  
    END  
  
    IF @SaveMode = @SaveMode_Update  
    BEGIN  
        -- made sure a MUID of an existing row was given  
        IF @MUID IS NULL OR NOT EXISTS (SELECT 1 FROM mdm.tblBRLogicalOperatorGroup WHERE MUID = @MUID)  
        BEGIN  
            RAISERROR('MDSERR400001|The Update operation failed. The MUID was not found.', 16, 1);  
            RETURN;  
        END  
    END  
  
    SELECT  
        @Rule_ID = ID,  
        @Entity_ID = [Entity_ID]  
    FROM mdm.tblBRBusinessRule  
    WHERE MUID = @Rule_MUID;  
  
    IF @Rule_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR400005|The business rule MUID is not valid.', 16, 1);  
        RETURN  
    END  
  
    SELECT @Model_Permission = m.Privilege_ID  
    FROM mdm.viw_SYSTEM_SECURITY_USER_MODEL m  
    INNER JOIN mdm.tblEntity en ON m.ID = en.Model_ID  
    WHERE [User_ID] = @User_ID AND en.ID = @Entity_ID;  
  
    IF @Model_Permission <> @Permission_Admin  
    BEGIN  
        RAISERROR('MDSERR120003|The user does not have permission or the object ID is not valid.', 16, 1);  
        RETURN;  
    END  
  
    -- get parent ID  
    IF @Parent_MUID IS NOT NULL  
    BEGIN  
        SELECT @Parent_ID = ID FROM mdm.tblBRLogicalOperatorGroup WHERE MUID = @Parent_MUID;  
  
        IF @Parent_ID IS NULL  
        BEGIN  
            RAISERROR('MDSERR400020|The MUID for the parent tree node is not valid.', 16, 1);  
            RETURN;  
        END  
    END  
  
    IF @SaveMode = @SaveMode_Create  
    BEGIN  
     -- add row  
        INSERT INTO mdm.tblBRLogicalOperatorGroup (  
            MUID,  
            LogicalOperator_ID,  
            Parent_ID,  
            BusinessRule_ID,  
            [Sequence]  
        )  
        VALUES (  
            @MUID,  
            @LogicalOperator_ID,  
            @Parent_ID,  
            @Rule_ID,  
            @Sequence  
        );  
  
        IF @@ERROR = 0  
        BEGIN  
            SET @ID = SCOPE_IDENTITY();  
        END  
    END  
    ELSE  
    BEGIN  
        -- update row  
        UPDATE mdm.tblBRLogicalOperatorGroup  
        SET LogicalOperator_ID = @LogicalOperator_ID,  
            Parent_ID = @Parent_ID,  
            BusinessRule_ID = @Rule_ID,  
            [Sequence] = @Sequence  
        WHERE MUID = @MUID  
  
        IF @@ERROR = 0  
        BEGIN  
            SELECT @ID = ID FROM mdm.tblBRLogicalOperatorGroup WHERE MUID = @MUID;  
        END  
    END  
  
    SET NOCOUNT OFF  
END
go

