/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Gets all user groups.  
  
EXEC mdm.udpUserGroupListGet  
*/  
CREATE PROCEDURE mdm.udpUserGroupListGet  
(  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
    SELECT  
        g.ID,  
        g.MUID,  
        g.UserGroupType_ID,  
        g.SID,  
        g.Name,  
        g.Description,  
        COALESCE(g.EnterUserID, 0) AS EnterUserID,  
        eu.MUID AS EnterUserMUID,  
        COALESCE(eu.UserName, N'') AS EnterUserName,  
        COALESCE(eu.DisplayName, N'') AS EnterUserDisplayName,  
        g.EnterDTM,  
        COALESCE(g.LastChgUserID, 0) AS LastChgUserID,  
        lcu.MUID AS LastChgUserMUID,  
        COALESCE(lcu.UserName, N'') AS LastChgUserName,  
        COALESCE(lcu.DisplayName, N'') AS LastChgUserDisplayName,  
        g.LastChgDTM  
    FROM mdm.tblUserGroup g  
    LEFT JOIN mdm.tblUser eu   
    ON g.EnterUserID = eu.ID   
    LEFT JOIN mdm.tblUser lcu   
    ON g.LastChgUserID = lcu.ID  
    WHERE g.Status_ID = 1--Active  
    ORDER BY Name  
  
    SET NOCOUNT OFF  
END --proc
go

