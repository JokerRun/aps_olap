/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    mdm.udpCreateSystemViews 1  
*/  
CREATE PROCEDURE mdm.udpCreateSystemViews  
(  
    @Model_ID       INT,  
    @NewEntity_ID   INT = 0, --any non zero value results in only that entity being generated  
    @CorrelationID  UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON;  
  
    --Defer view generation if we are in the middle of an upgrade or demo-rebuild  
    IF APPLOCK_MODE(N'public', N'DeferViewGeneration', N'Session') = N'NoLock' BEGIN  
  
        DECLARE @Entity_ID              INT,  
                @Type_ID                INT,  
                @EntityName             sysname,  
                @IsCollectionEnabled    BIT,  
                @IsHierarchyEnabled     BIT,  
                @SQL                    NVARCHAR(MAX),  
  
                @MemberType_Leaf                TINYINT = 1,  
                @MemberType_Consolidated        TINYINT = 2,  
                @MemberType_Collection          TINYINT = 3;  
          
        DECLARE @TempTable TABLE   
        (  
             RowNumber              INT IDENTITY (1, 1) PRIMARY KEY CLUSTERED NOT NULL   
            ,ID                     INT NOT NULL  
            ,IsCollectionEnabled    BIT NOT NULL  
            ,IsHierarchyEnabled     BIT NOT NULL  
        );  
  
        SET @NewEntity_ID = COALESCE(@NewEntity_ID, 0);  
                      
        --Start transaction, being careful to check if we are nested	  
        DECLARE @TranCounter INT;   
        SET @TranCounter = @@TRANCOUNT;  
        IF @TranCounter > 0 SAVE TRANSACTION TX;  
        ELSE BEGIN TRANSACTION;  
          
        BEGIN TRY  
            INSERT INTO @TempTable   
            SELECT   
                 ID  
                ,CASE WHEN CollectionTable IS NULL THEN 0 ELSE 1 END IsCollectionEnabled  
                ,CASE WHEN HierarchyTable IS NULL THEN 0 ELSE 1 END IsHierarchyEnabled  
            FROM mdm.tblEntity   
            WHERE Model_ID = @Model_ID AND (@NewEntity_ID = 0 OR ID = @NewEntity_ID);  
  
            DECLARE @Counter INT = 1 ;  
            DECLARE @MaxCounter INT = (SELECT MAX(RowNumber) FROM @TempTable);  
  
            WHILE @Counter <= @MaxCounter  
                BEGIN  
  
                SELECT @Entity_ID = ID  
                    ,@IsCollectionEnabled = IsCollectionEnabled  
                    ,@IsHierarchyEnabled = IsHierarchyEnabled  
                FROM @TempTable   
                WHERE [RowNumber] = @Counter;  
  
                --Delete Entity Views.  
                EXEC mdm.udpDeleteViews @Model_ID, @Entity_ID, NULL;  
  
                --Leaf Views  
                EXEC mdm.udpCreateSystemAttributeViews @Entity_ID, @MemberType_Leaf, 0;  
                EXEC mdm.udpCreateSystemAttributeViews @Entity_ID, @MemberType_Leaf, 1;  
                EXEC mdm.udpCreateSystemAttributeViews @Entity_ID, @MemberType_Leaf, 2;  
  
                IF @IsHierarchyEnabled = 1   
                BEGIN  
                    --Consolidated Views  
                    EXEC mdm.udpCreateSystemAttributeViews @Entity_ID, @MemberType_Consolidated, 0;  
                    EXEC mdm.udpCreateSystemAttributeViews @Entity_ID, @MemberType_Consolidated, 2;  
                    EXEC mdm.udpCreateSystemLevelViews @Entity_ID; -- Consolidated  
                END  
  
                IF @IsCollectionEnabled = 1   
                BEGIN  
                    --Collection Views  
                    EXEC mdm.udpCreateSystemAttributeViews @Entity_ID, @MemberType_Collection, 0;  
                    EXEC mdm.udpCreateSystemAttributeViews @Entity_ID, @MemberType_Collection, 2;  
                END; --if  
  
                IF @IsHierarchyEnabled = 1 OR @IsCollectionEnabled = 1  
                BEGIN  
                    EXEC mdm.udpCreateSystemParentChildViews @Entity_ID, 0; -- Consolidated and Collection  
                    EXEC mdm.udpCreateSystemParentChildViews @Entity_ID, 2; -- Consolidated and Collection  
  
                    IF @IsHierarchyEnabled = 1   
                    BEGIN  
                        EXEC mdm.udpCreateSystemEXPViews @Entity_ID, @MemberType_Consolidated, 0;  
                        EXEC mdm.udpCreateSystemEXPViews @Entity_ID, @MemberType_Consolidated, 2;  
                    END;  
  
                    IF @IsCollectionEnabled = 1  
                    BEGIN  
                        EXEC mdm.udpCreateSystemEXPViews @Entity_ID, @MemberType_Collection, 0;  
                        EXEC mdm.udpCreateSystemEXPViews @Entity_ID, @MemberType_Collection, 2;  
                    END;  
                END;  
  
                --Leaf XML - must be after the consolidated views as it consumes them  
                EXEC mdm.udpCreateSystemEXPViews @Entity_ID, @MemberType_Leaf, 0;  
                EXEC mdm.udpCreateSystemEXPViews @Entity_ID, @MemberType_Leaf, 2;  
  
                SET @Counter = @Counter+1;  
  
            END; --while  
              
  
            --Commit only if we are not nested  
            IF @TranCounter = 0 COMMIT TRANSACTION;  
  
        END TRY  
        --Compensate as necessary  
        BEGIN CATCH  
  
            -- Get error info.  
            DECLARE  
                @ErrorMessage NVARCHAR(4000),  
                @ErrorSeverity INT,  
                @ErrorState INT,  
                @ErrorNumber INT,  
                @ErrorLine INT,  
                @ErrorProcedure NVARCHAR(126);  
            EXEC mdm.udpGetErrorInfo  
                @ErrorMessage = @ErrorMessage OUTPUT,  
                @ErrorSeverity = @ErrorSeverity OUTPUT,  
                @ErrorState = @ErrorState OUTPUT,  
                @ErrorNumber = @ErrorNumber OUTPUT,  
                @ErrorLine = @ErrorLine OUTPUT,  
                @ErrorProcedure = @ErrorProcedure OUTPUT  
  
            SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
            IF @TranCounter = 0 ROLLBACK TRANSACTION;  
            ELSE IF XACT_STATE() <> -1 ROLLBACK TRANSACTION TX;  
  
            RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
  
        END CATCH;  
  
    END; --if  
  
    SET NOCOUNT OFF;  
END; --proc
go

