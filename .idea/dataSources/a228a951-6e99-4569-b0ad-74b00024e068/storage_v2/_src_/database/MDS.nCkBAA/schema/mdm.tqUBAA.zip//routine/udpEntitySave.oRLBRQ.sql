/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    --Create new Entity  
    DECLARE @Return_ID INT, @Return_MUID UNIQUEIDENTIFIER;  
    EXEC mdm.udpEntitySave @User_ID = 1, @Model_ID = 5, @EntityName = N'Test11', @EditMode = 0, @Return_ID = @Return_ID OUTPUT, @Return_MUID = @Return_MUID OUTPUT;  
    SELECT @Return_ID, @Return_MUID;  
    SELECT * FROM mdm.tblEntity WHERE ID = @Return_ID;  
  
    --Create new Entity with code gen turned ON  
    DECLARE @Return_ID INT, @Return_MUID UNIQUEIDENTIFIER;  
    EXEC mdm.udpEntitySave @User_ID = 1, @Model_ID = 5, @EntityName = N'Test11', @CodeGenSeed = 1, @EditMode = 0, @Return_ID = @Return_ID OUTPUT, @Return_MUID = @Return_MUID OUTPUT;  
    SELECT @Return_ID, @Return_MUID;  
    SELECT * FROM mdm.tblEntity WHERE ID = @Return_ID;  
  
    --Update existing Entity  
    DECLARE @Return_ID INT, @Return_MUID UNIQUEIDENTIFIER;  
    EXEC mdm.udpEntitySave @User_ID = 1, @Model_ID = 5, @Entity_ID = 1, @EntityName = N'Test11 New', @EditMode = 1, @Return_ID = @Return_ID OUTPUT, @Return_MUID = @Return_MUID OUTPUT;  
    SELECT @Return_ID, @Return_MUID;  
    SELECT * FROM mdm.tblEntity WHERE ID = @Return_ID;  
*/  
CREATE PROCEDURE mdm.udpEntitySave  
(  
    @User_ID                INT,  
    @Model_ID               INT, -- caller should validate  
    @Version_ID             INT = NULL, -- used for audit info. When NULL, the highest value for the model will be used  
    @Entity_ID              INT = NULL,  
    @Entity_MUID            UNIQUEIDENTIFIER = NULL,  
    @EntityName             NVARCHAR(50),  
    @Description            NVARCHAR(500) = NULL,  
    @IsBase                 BIT = NULL,  
    @StagingBase            NVARCHAR(60) = N'',  
    @CodeGenSeed            INT = NULL,  
    @EditMode               TINYINT = 0, --0: Create, 1: Update, 4: Clone, defaults to Create  
    @DataCompression        TINYINT = NULL,  
    @TransactionLogType     TINYINT = 0, -- 0: NotSpecified, 1: Column, 2: Row, 3: None  
    @RequireApproval        BIT = NULL,-- caller should validate, NULL: NotSpecified, 0: does not require approval, 1: requires entity admin approval  
    @IsSync                 BIT = 0,  
    @RecreateStagingProc    BIT = 1, -- In can be useful, for efficiency, to turn this off for batch metadata changes   
    @Return_DidNameChange   BIT = NULL OUTPUT,  
    @Return_ID              INT = NULL OUTPUT,  
    @Return_MUID            UNIQUEIDENTIFIER = NULL OUTPUT, --Also an input parameter for clone operations  
    @CorrelationID          UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE @SQL                        NVARCHAR(MAX),  
            @CurrentDTM                 DATETIME2(3),  
            @EntityTable                SYSNAME,  
            @SecurityTable              SYSNAME,  
            @StagingTable               SYSNAME,  
            @HistoryTable               SYSNAME,  
            @AnnotationTable            SYSNAME,  
            @PendingTable               SYSNAME,  
            @TableOptions               NVARCHAR(MAX) = N'',  
            @IndexOptions               NVARCHAR(MAX) = N'',  
            @StagingTableOptions        NVARCHAR(MAX) = N'',  
            @StagingIndexOptions        NVARCHAR(MAX) = N'',  
            @TranCommitted              INT = 0, -- 0: Not committed, 1: Committed.  
            @IsHierarchyEnabled         BIT,  
  
            -- This pseudo-constant is for use in string concatenation operations to prevent string truncation. When concatenating two or more strings,  
            -- if none of the strings is an NVARCHAR(MAX) or an NVARCHAR constant that is longer than 4,000 characters, then the resulting string  
            -- will be silently truncated to 4,000 characters. Concatenating with this empty NVARCHAR(MAX), is sufficient to prevent truncation.  
            -- See http://connect.microsoft.com/SQLServer/feedback/details/283368/nvarchar-max-concatenation-yields-silent-truncation.  
            @TruncationGuard            NVARCHAR(MAX) = N'',  
  
            @Status_Active              TINYINT = 1,  
  
            @TransactionLogType_NotSpecified    TINYINT = 0,  
            @TransactionLogType_Attribute       TINYINT = 1,  
  
            @LeafSproc                          SYSNAME,  
            @ConsolidatedSproc                  SYSNAME,  
            @RelationshipSproc                  SYSNAME,  
            @RelationshipStagingTable           SYSNAME,  
            @LeafStagingTable                   SYSNAME,  
            @ConsolidatedStagingTable           SYSNAME,  
            @MemberErrorViewName                SYSNAME,  
            @RelationErrorViewName              SYSNAME,  
            @CurrentStagingBase                 NVARCHAR(MAX) = N'',  
            @CurrentDataCompression             TINYINT = 0,  
            @CurrentEntityName                  NVARCHAR(MAX),  
            @CurrentEntityStagingBaseName       NVARCHAR(MAX),  
            @CurrentEntityTable                 SYSNAME,  
            @CurrentHierarchyTable              SYSNAME,  
            @CurrentHierarchyParentTable        SYSNAME,  
            @CurrentCollectionTable             SYSNAME,  
            @CurrentCollectionMemberTable       SYSNAME,  
            @CurrentTransactionLogType          TINYINT,  
            @TableName                          SYSNAME,  
            @UsedBy                             NVARCHAR(MAX),  
            @CurrentDescription                 NVARCHAR(MAX),  
            @CurrentCodeGenSeed                 INT = NULL,  
            @GuidEmpty                          UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER),  
            @EditMode_Create                    TINYINT = 0,  
            @EditMode_Update                    TINYINT = 1,  
            @EditMode_Clone                     TINYINT = 4,  
            @ExistingEntity_MUID                UNIQUEIDENTIFIER = NULL,  
            @ExistingEntity_ID                  INT = NULL,  
            @ObjectType_Model                   INT = 1,  
            @IsModelAdmin                       INT = NULL;  
  
    --Initialize output parameters and local variables  
  
    SELECT  
        @Description = NULLIF(LTRIM(RTRIM(@Description)), N''),  
        @Return_ID = NULL,  
        @CurrentDTM = GETUTCDATE(),  
        @Model_ID = NULLIF(@Model_ID, 0),  
        @Entity_MUID = NULLIF(@Entity_MUID, @GuidEmpty),  
        @Entity_ID = NULLIF(@Entity_ID, 0),  
        @EntityName = NULLIF(LTRIM(RTRIM(@EntityName)), N''),  
        @IsBase = COALESCE(@IsBase, 0);  
  
    -- If TransactionLogType is not specified, use default type @TransactionLogType_Attribute  
    IF @TransactionLogType = @TransactionLogType_NotSpecified  
    BEGIN  
        SET @TransactionLogType = @TransactionLogType_Attribute;  
    END;  
  
    --On error, return NULL results  
    SELECT @Return_ID = NULL, @Return_MUID = NULL;  
  
    --Test for invalid EditMode  
    IF @EditMode IS NULL OR @EditMode NOT IN (@EditMode_Create, @EditMode_Update, @EditMode_Clone)  
    BEGIN  
        RAISERROR('MDSERR100010|The Parameters are not valid.', 16, 1);  
        RETURN;  
    END; --if  
  
    --The user is not a model admin  
    IF @Model_ID = 0  
    BEGIN  
        RAISERROR('MDSERR120003|The user does not have permission or the object ID is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    --Get the latest Model Version  
    IF @Version_ID IS NULL  
    BEGIN  
        SELECT @Version_ID = MAX(ID)  
        FROM mdm.tblModelVersion  
        WHERE Model_ID = @Model_ID;  
    END  
  
    --If we are in the Update or Clone mode get the missing pieces of the identifier  
    IF @EditMode IN (@EditMode_Update, @EditMode_Clone)  
    BEGIN  
        --Only use the name if neither MUID nor ID are available. This is important because we don't want  
        --to look up by name if the name is what the user is trying to update.  
        IF @Entity_ID IS NULL AND @Entity_MUID IS NULL  
        BEGIN  
            SELECT TOP 1  
                @ExistingEntity_ID =  ID,  
                @ExistingEntity_MUID = MUID  
            FROM mdm.tblEntity  
            WHERE  
                [Name] = @EntityName AND  
                Model_ID = @Model_ID;  
        END  
        --Use the Entity ID and MUID to look up the full identifier  
        ELSE  
        BEGIN  
            SELECT  
                @ExistingEntity_ID =  ID,  
                @ExistingEntity_MUID = MUID  
            FROM mdm.tblEntity  
            WHERE  
                (@Entity_ID IS NULL OR ID = @Entity_ID) AND  
                (@Entity_MUID IS NULL OR MUID = @Entity_MUID) AND  
                Model_ID = @Model_ID;  
        END  
  
        --If we are in the Clone mode we need to figure out whether we are creating or updating  
        IF @EditMode = @EditMode_Clone  
        BEGIN  
            --If there is no existing model then set the edit mode to Create  
            IF @ExistingEntity_MUID IS NULL AND @ExistingEntity_ID IS NULL  
            BEGIN  
                SET @EditMode = @EditMode_Create;  
                SET @Entity_ID = NULL;  
            END  
            --If there is an existing entity then set the edit mode to Update  
            ELSE  
            BEGIN  
                SET @EditMode = @EditMode_Update;  
                SET @Entity_ID = @ExistingEntity_ID;  
                SET @Entity_MUID = @ExistingEntity_MUID;  
            END  
        END  
        --If we are in Update mode and could not find a matching existing model we need to raise an error and quit now  
        ELSE IF @EditMode = @EditMode_Update  
        BEGIN  
            IF @ExistingEntity_ID IS NULL OR @ExistingEntity_MUID IS NULL  
            BEGIN  
                RAISERROR('MDSERR110007|The ID is not valid.', 16, 1);  
                RETURN;  
            END  
            ELSE  
            BEGIN  
                SET @Entity_ID = @ExistingEntity_ID;  
                SET @Entity_MUID = @ExistingEntity_MUID;  
            END  
        END  
  
        IF      @EditMode = @EditMode_Update  
            AND @IsSync = 0  
        BEGIN  
            IF EXISTS(SELECT 1 FROM mdm.tblSyncRelationship WHERE TargetEntity_ID = @Entity_ID)-- This query is in a nested IF statement, rather than in the parent IF statement, for efficiency because SQL does not guarantee Boolean short circuiting.  
            BEGIN  
                RAISERROR('MDSERR200213|The entity cannot be saved. It is the target of a sync relationship.', 16, 1);  
                RETURN;  
            END  
        END  
    END  
  
    --If the edit mode is Create. This code also needs to execute if the user sent in EditMode clone which ended up becoming Create (hence the IF instead of ELSE IF)  
    IF @EditMode = @EditMode_Create  
    BEGIN  
        --Set Entity ID to null. We don't care what came in.  
        SET @Entity_ID = NULL;  
  
        --If Entity_MUID is not null then we need to ensure it does not already exist (since this is a create)  
        IF @Entity_MUID IS NOT NULL AND EXISTS(SELECT 1 FROM mdm.tblEntity WHERE MUID = @Entity_MUID)  
        BEGIN  
            RAISERROR('MDSERR110007|The ID is not valid.', 16, 1);  
            RETURN;  
        END  
    END  
  
  
    --Test for invalid parameters  
    IF (@Version_ID IS NULL) --Invalid @Version_ID (via invalid @Model_ID)  
        OR (@Entity_ID IS NULL AND @EntityName IS NULL) --@EntityName cannot be NULL for inserts  
        OR (@Entity_ID IS NOT NULL AND NOT EXISTS(SELECT ID FROM mdm.tblEntity WHERE Model_ID = @Model_ID AND ID = @Entity_ID)) --Invalid @Entity_ID (or wrong @Model_ID)  
    BEGIN  
        SELECT @Entity_ID = NULL, @Return_MUID = NULL, @EntityName = NULL;  
        RAISERROR('MDSERR100010|The Parameters are not valid.', 16, 1);  
        RETURN;  
    END; --if  
  
    --Check the name of the entity for duplicates  
    IF EXISTS  
    (  
        SELECT 1   
        FROM mdm.tblEntity  
        WHERE  
            @EntityName = Name AND  
            (@Entity_MUID IS NULL OR MUID <> @Entity_MUID) AND  
            Model_ID = @Model_ID  
    )  
    BEGIN  
        RAISERROR('MDSERR110003|The name already exists. Type a different name.', 16, 1);  
        RETURN;  
    END  
  
  
    --Start transaction, being careful to check if we are nested  
    DECLARE @TranCounter INT;  
    SET @TranCounter = @@TRANCOUNT;  
    IF @TranCounter > 0 SAVE TRANSACTION TX;  
    ELSE BEGIN TRANSACTION;  
  
    BEGIN TRY  
  
        SET @StagingBase = LTRIM(RTRIM(@StagingBase));  
  
        --Update/Insert Entity details  
        IF @EditMode = @EditMode_Update  
        BEGIN --Update Entity  
  
           ---------------------------------------------------------  
            ---------            Update Entity             ----------  
            ---------------------------------------------------------  
  
            --Don't bother doing anything if the @EntityName is NULL  
            IF @EntityName IS NOT NULL  
            BEGIN  
                SELECT  @CurrentEntityName = Name,  
                        @CurrentEntityStagingBaseName = StagingBase,  
                        @CurrentDescription = [Description],  
                        @CurrentStagingBase = StagingBase  
                FROM mdm.tblEntity  
                WHERE ID = @Entity_ID;  
  
                --Check if code gen is enabled  
                DECLARE @result INT;  
                EXEC @result = mdm.udpIsCodeGenEnabled @Entity_ID;  
                DECLARE @CodeGenEnabled BIT =  CONVERT(BIT, @result);  
  
                --Check the current code gen seed  
                IF @CodeGenEnabled = 1  
                BEGIN  
                    SELECT @CurrentCodeGenSeed = Seed  
                    FROM mdm.tblCodeGenInfo  
                    WHERE EntityId = @Entity_ID;  
                END  
  
                --Update details in Entity table  
                UPDATE mdm.tblEntity   
                SET  
                    [Name] = @EntityName,  
                    [Description] = @Description,  
                    IsBase = @IsBase,  
                    LastChgDTM = @CurrentDTM,  
                    LastChgUserID = @User_ID,  
                    LastChgVersionID = @Version_ID  
                WHERE  
                    ID = @Entity_ID;  
  
                --If the user did not send in a code gen seed we might need to turn code gen off  
                IF @CodeGenSeed IS NULL  
                BEGIN  
                    --If code gen is enabled on this entity turn it off  
                    IF @CodeGenEnabled = 1  
                    BEGIN  
                        DELETE FROM mdm.tblCodeGenInfo  
                        WHERE EntityId = @Entity_ID;  
                    END  
                END ELSE  
                BEGIN  
                    --If code gen is already enabled on this entity just update the seed  
                    IF @CodeGenEnabled = 1  
                    BEGIN  
                        UPDATE mdm.tblCodeGenInfo  
                        SET Seed = @CodeGenSeed  
                        WHERE EntityId = @Entity_ID;  
                    END ELSE  
                    --If code gen needs to be enabled  
                    BEGIN  
                        --Turn it on  
                        DECLARE @ExistingMaxValue BIGINT = NULL;  
                        EXEC @ExistingMaxValue = mdm.udpGetMaxCodeValue @Entity_ID = @Entity_ID;  
                        INSERT INTO mdm.tblCodeGenInfo (EntityId, Seed, LargestCodeValue)  
                        VALUES (@Entity_ID, @CodeGenSeed, @ExistingMaxValue);  
                    END  
                END  
  
                --If StagingBase is specified, check if it is changed.  
                IF COALESCE(@StagingBase, N'') <> N''  
                BEGIN  
                    SELECT  
                        @IsHierarchyEnabled  = CASE WHEN HierarchyTable  IS NULL THEN 0 ELSE 1 END,  
                        @LeafSproc = N'[stg].' + QUOTENAME(N'udp_' + StagingBase + N'_Leaf'),  
                        @ConsolidatedSproc = N'[stg].' + QUOTENAME(N'udp_' + StagingBase + N'_Consolidated'),  
                        @RelationshipSproc = N'[stg].' + QUOTENAME(N'udp_' + StagingBase + N'_Relationship'),  
                        @LeafStagingTable = N'[stg].' + QUOTENAME(StagingBase + N'_Leaf'),  
                        @ConsolidatedStagingTable = N'[stg].' + QUOTENAME(StagingBase + N'_Consolidated'),  
                        @RelationshipStagingTable = N'[stg].' + QUOTENAME(StagingBase + N'_Relationship'),  
                        @MemberErrorViewName = N'[stg].' + QUOTENAME(N'viw_' + StagingBase + N'_MemberErrorDetails'),  
                        @RelationErrorViewName = N'[stg].' + QUOTENAME(N'viw_' + StagingBase + N'_RelationshipErrorDetails')  
                    FROM  
                        mdm.tblEntity WHERE ID = @Entity_ID;  
  
                    -- When the entity is a system entity @CurrentStagingBase is NULL.  
                    -- In this case the user cannot change the StagingBase.  
                    IF COALESCE(@CurrentStagingBase, N'') <> N'' AND @CurrentStagingBase <> @StagingBase  
                    BEGIN  
                        --If the specified StagingBase is not unique, get the unique name from the first 50 characters of @StagingBase.  
                        IF EXISTS (SELECT 1 FROM mdm.tblEntity WHERE StagingBase = @StagingBase) BEGIN  
                            SELECT @StagingBase = mdm.udfUniqueStagingBaseGet(LEFT(@StagingBase, 50))  
                        END; --IF  
  
                        -- Update StagingBase  
                        UPDATE mdm.tblEntity   
                        SET StagingBase = @StagingBase  
                        WHERE ID = @Entity_ID;  
  
                        -- Update staging table names and staging stored procedure names.  
                          
                        SET @SQL = CONCAT(@TruncationGuard, @SQL, N'    
                        -- Change leaf staging table name.    
                        IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N', QUOTENAME(@LeafStagingTable, N'''') , N') AND type = (N''U''))  
                        EXEC sp_rename N' , QUOTENAME(@LeafStagingTable, N'''') , N', N' , QUOTENAME((CONCAT(@StagingBase , N'_Leaf')), N'''') , N'  
  
                        -- Change leaf staging stored procedure name.    
                        IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N', QUOTENAME(@LeafSproc, N'''') , N') AND type in (N''P'', N''PC''))    
                        EXEC sp_rename N' , QUOTENAME(@LeafSproc, N'''') , N', N' , QUOTENAME(CONCAT(N'[stg].' , QUOTENAME(CONCAT(N'udp_' , @StagingBase , N'_Leaf'))), N'''')  , N'  
  
                        -- Change staging view name    
                        IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N' , QUOTENAME(@MemberErrorViewName, N'''') , N') AND type in (N''V''))  
                        EXEC sp_rename N' , QUOTENAME(@MemberErrorViewName, N'''') , N', N' , QUOTENAME(CONCAT(N'[stg].' , QUOTENAME(CONCAT(N'viw_' , @StagingBase , N'_MemberErrorDetails'))), N'''') ,  
  
                        CASE WHEN @IsHierarchyEnabled = 1 THEN CONCAT(N'    
                        -- Change consolidated staging table name.    
                        IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N' , QUOTENAME(@ConsolidatedStagingTable, N'''') , N') AND type = (N''U''))    
                        EXEC sp_rename N' , QUOTENAME(@ConsolidatedStagingTable, N'''') , N', N' , QUOTENAME((CONCAT(@StagingBase , N'_Consolidated')), N'''') , N'    
    
                        IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N' , QUOTENAME(@RelationshipStagingTable, N'''') , N') AND type = (N''U''))   
                        EXEC sp_rename N' , QUOTENAME(@RelationshipStagingTable, N'''') , N', N' , QUOTENAME((CONCAT(@StagingBase , N'_Relationship')), N'''') , N'  
    
                        -- Change consolidated staging stored procedure name.    
                        IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N' , QUOTENAME(@ConsolidatedSproc, N'''') , N') AND type in (N''P'', N''PC''))    
                        EXEC sp_rename N' , QUOTENAME(@ConsolidatedSproc, N'''') , N', N' , QUOTENAME(CONCAT(N'[stg].' , QUOTENAME(CONCAT(N'udp_' , @StagingBase , N'_Consolidated'))), N'''') , N'    
    
                        IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N' , QUOTENAME(@RelationshipSproc, N'''') , N') AND type in (N''P'', N''PC''))    
                        EXEC sp_rename N' , QUOTENAME(@RelationshipSproc, N'''') , N', N' , QUOTENAME(CONCAT(N'[stg].' , QUOTENAME(CONCAT(N'udp_' , @StagingBase , N'_Relationship'))), N'''') , N'    
    
                        IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N' , QUOTENAME(@RelationErrorViewName, N'''') , N') AND type = N''V'')    
                        EXEC sp_rename N' , QUOTENAME(@RelationErrorViewName, N'''') , N', N' , QUOTENAME(CONCAT(N'[stg].' , QUOTENAME(CONCAT(N'viw_' , @StagingBase , N'_RelationshipErrorDetails'))), N''''))  
                            END);  
                        EXEC sp_executesql @SQL;    
                    END; --IF  
                END; --IF  
  
                --If DataCompression is specified, check if it is changed.  
                IF @DataCompression IS NOT NULL BEGIN  
                   SELECT  
                       @CurrentDataCompression = DataCompression,  
                       @CurrentStagingBase = StagingBase,  
                       @CurrentEntityTable = EntityTable,  
                       @CurrentHierarchyTable = HierarchyTable,  
                       @CurrentHierarchyParentTable = HierarchyParentTable,  
                       @CurrentCollectionTable = CollectionTable,  
                       @CurrentCollectionMemberTable = CollectionMemberTable  
                   FROM  
                       mdm.tblEntity WHERE ID = @Entity_ID;  
                   IF @DataCompression <> @CurrentDataCompression  
                   BEGIN  
  
                       -- Update all entity tables  
                       SET @TableName = N'[mdm].' + QUOTENAME(@CurrentEntityTable);  
                       EXEC [mdm].[udpChangeTableDataCompressionType] @TableName, @DataCompression;  
                       SET @TableName = N'[mdm].' + QUOTENAME(@CurrentHierarchyTable);  
                       EXEC [mdm].[udpChangeTableDataCompressionType] @TableName, @DataCompression;  
                       SET @TableName = N'[mdm].' + QUOTENAME(@CurrentHierarchyParentTable);  
                       EXEC [mdm].[udpChangeTableDataCompressionType] @TableName, @DataCompression;  
                       SET @TableName = N'[mdm].' + QUOTENAME(@CurrentCollectionTable);  
                       EXEC [mdm].[udpChangeTableDataCompressionType] @TableName, @DataCompression;  
                       SET @TableName = N'[mdm].' + QUOTENAME(@CurrentCollectionMemberTable);  
                       EXEC [mdm].[udpChangeTableDataCompressionType] @TableName, @DataCompression;  
                       SET @TableName = N'[stg].' + QUOTENAME(@CurrentStagingBase + N'_Leaf');  
                       EXEC [mdm].[udpChangeTableDataCompressionType] @TableName, @DataCompression;  
                       SET @TableName = N'[stg].' + QUOTENAME(@CurrentStagingBase + N'_Consolidated');  
                       EXEC [mdm].[udpChangeTableDataCompressionType] @TableName, @DataCompression;  
                       SET @TableName = N'[stg].' + QUOTENAME(@CurrentStagingBase + N'_Relationship');  
                       EXEC [mdm].[udpChangeTableDataCompressionType] @TableName, @DataCompression;  
                       SET @TableName = N'[stg].' + QUOTENAME(@CurrentEntityTable + N'_HS');  
                       EXEC [mdm].[udpChangeTableDataCompressionType] @TableName, @DataCompression;  
                       SET @TableName = N'[stg].' + QUOTENAME(@CurrentEntityTable + N'_AN');  
                       EXEC [mdm].[udpChangeTableDataCompressionType] @TableName, @DataCompression;  
                       SET @TableName = N'[stg].' + QUOTENAME(@CurrentEntityTable + N'_PD');  
                       EXEC [mdm].[udpChangeTableDataCompressionType] @TableName, @DataCompression;  
                       SET @TableName = N'[stg].' + QUOTENAME(@CurrentEntityTable + N'_WI');  
                       EXEC [mdm].[udpChangeTableDataCompressionType] @TableName, @DataCompression;  
                       SET @TableName = N'[mdm].' + QUOTENAME(@CurrentEntityTable + N'_MS');  
                       EXEC [mdm].[udpChangeTableDataCompressionType] @TableName, @DataCompression;  
  
                       -- Update DataCompression  
                       UPDATE mdm.tblEntity  
                       SET DataCompression = @DataCompression  
                       WHERE ID = @Entity_ID;  
                   END  
                END; --IF  
  
                --If TransactionLogType is specified, check if it is changed.  
                IF @TransactionLogType IS NOT NULL  
                BEGIN  
                    SELECT  
                       @CurrentTransactionLogType = TransactionLogType,  
                       @CurrentEntityTable = EntityTable,  
                       @CurrentHierarchyTable = HierarchyTable  
                    FROM mdm.tblEntity   
                    WHERE ID = @Entity_ID;  
  
                    IF @TransactionLogType <> @CurrentTransactionLogType  
                    BEGIN  
                        -- Update DataCompression  
                        UPDATE mdm.tblEntity  
                        SET TransactionLogType = @TransactionLogType  
                        WHERE ID = @Entity_ID;  
                    END;  
  
                    IF @RecreateStagingProc = 1  
                    BEGIN  
                        IF @CurrentEntityTable IS NOT NULL  
                        BEGIN  
                            EXEC mdm.udpEntityStagingCreateLeafStoredProcedure @Entity_ID;  
                        END;  
  
                        IF @CurrentHierarchyTable IS NOT NULL  
                        BEGIN  
                            EXEC mdm.udpEntityStagingCreateConsolidatedStoredProcedure @Entity_ID;  
                            EXEC mdm.udpEntityStagingCreateRelationshipStoredProcedure @Entity_ID;  
                        END;  
                    END  
                END; --IF  
  
                IF @RequireApproval IS NOT NULL  
                BEGIN  
                    UPDATE mdm.tblEntity  
                    SET RequireApproval = @RequireApproval  
                    WHERE ID = @Entity_ID;  
                END  
            END; --if  
  
            --Populate output parameters  
            SELECT @Return_MUID = MUID FROM mdm.tblEntity WHERE ID = @Entity_ID;  
  
        END  
        ELSE  
        BEGIN  
            --------------------------------------------------  
            ---------        Create New Entity        --------  
            --------------------------------------------------  
  
            --Accept an explicit MUID (for clone operations) or generate a new one  
            SET @Return_MUID = ISNULL(@Entity_MUID, NEWID());  
  
            --If the StagingBase is not specified, get the unique name.  
            IF COALESCE(@StagingBase, N'') = N''   
            BEGIN  
                SET @StagingBase = mdm.udfUniqueStagingBaseGet(@EntityName)  
            END ELSE   
            BEGIN  
                --If the specified StagingBase is not unique, get the unique name from the first 50 characters of @StagingBase.  
                IF EXISTS (SELECT 1 FROM mdm.tblEntity WHERE StagingBase = @StagingBase)   
                BEGIN  
                    SELECT @StagingBase = mdm.udfUniqueStagingBaseGet(LEFT(@StagingBase, 50))  
                END --IF  
            END --IF  
  
            SET @StagingTable = @StagingBase + N'_Leaf';  
  
            SET @TableOptions = mdm.udfGetTableOptions(@DataCompression, @Model_ID);  
            SET @IndexOptions = mdm.udfGetIndexOptions(@DataCompression, @Model_ID);  
            SET @StagingTableOptions = mdm.udfGetTableOptions(@DataCompression, NULL);  
            SET @StagingIndexOptions = mdm.udfGetIndexOptions(@DataCompression, NULL);  
  
            SET @RequireApproval = COALESCE(@RequireApproval, 0);  
  
            PRINT CONCAT(SYSDATETIME(), N', udpEntitySave: Inserting entity ', @EntityName);  
  
            --Insert details into Entity table  
            INSERT INTO mdm.tblEntity  
            (  
                Model_ID,  
                [Name],  
                [Description],  
                EntityTable,  
                IsBase,  
                MUID,  
                EnterDTM,  
                EnterUserID,  
                EnterVersionID,  
                LastChgDTM,  
                LastChgUserID,  
                LastChgVersionID,  
                StagingBase,  
                DataCompression,  
                TransactionLogType,  
                RequireApproval  
            )   
            VALUES   
            (  
                @Model_ID,  
                @EntityName,  
                @Description,  
                N'', --Temporary TableName values which we will update in the next step  
                @IsBase,  
                @Return_MUID,  
                @CurrentDTM,  
                @User_ID,  
                @Version_ID,  
                @CurrentDTM,  
                @User_ID,  
                @Version_ID,  
                @StagingBase,  
                ISNULL(@DataCompression, 0),  
                @TransactionLogType,  
                @RequireApproval  
            );  
  
            --Save the identity value  
            SET @Entity_ID =  SCOPE_IDENTITY();  
  
            --If the user provided a seed value then we need to turn on code gen  
            IF @CodeGenSeed IS NOT NULL  
            BEGIN  
                --Insert a row into the code gen info table to track numeric codes  
                INSERT INTO mdm.tblCodeGenInfo  
                (  
                    EntityId,  
                    Seed  
                )  
                VALUES  
                (  
                    @Entity_ID,  
                    @CodeGenSeed  
                );  
            END;  
  
            --Generate table names  
            WITH cte(prefix) AS (SELECT CONCAT(N'tbl_', @Model_ID, N'_', @Entity_ID))  
            SELECT  
                @EntityTable = prefix + N'_EN',  
                @SecurityTable = prefix + N'_EN_MS',  
                @HistoryTable = prefix + N'_EN_HS',  
                @AnnotationTable = prefix + N'_EN_AN',  
                @PendingTable = prefix + N'_EN_PD'  
            FROM cte;  
  
            --Store table names  
            UPDATE mdm.tblEntity   
            SET  
                EntityTable = @EntityTable  
            WHERE ID = @Entity_ID;  
  
            --Create the Entity (EN) table  
            SET @SQL = CONCAT(@TruncationGuard, N'  
  
            CREATE TABLE mdm.', QUOTENAME(@EntityTable), N'  
            (  
                --Identity  
                Version_ID          INT NOT NULL,  
                ID                  INT IDENTITY (1, 1) NOT NULL,  
  
                --Status  
                Status_ID           TINYINT NOT NULL CONSTRAINT ', QUOTENAME(N'df_' + @EntityTable + N'_Status_ID'), N' DEFAULT ', @Status_Active, N',  
                ValidationStatus_ID TINYINT NOT NULL CONSTRAINT ', QUOTENAME(N'df_' + @EntityTable  + N'_ValidationStatus_ID'), N' DEFAULT 0,  
  
                --Info  
                [Name]              NVARCHAR(250) NULL,  
                Code                NVARCHAR(250) NOT NULL,  
  
                --Change Tracking  
                ChangeTrackingMask  INT NOT NULL CONSTRAINT ', QUOTENAME(N'df_' + @EntityTable  + N'_ChangeTrackingMask'), N' DEFAULT 0,  
  
                --Auditing  
                EnterDTM            DATETIME2(3) NOT NULL CONSTRAINT ', QUOTENAME(N'df_' + @EntityTable  + N'_EnterDTM'), N' DEFAULT GETUTCDATE(),  
                EnterUserID         INT NOT NULL,  
                EnterVersionID      INT NOT NULL,  
                LastChgDTM          DATETIME2(3) NOT NULL CONSTRAINT ', QUOTENAME(N'df_' + @EntityTable  + N'_LastChgDTM'), N' DEFAULT GETUTCDATE(),  
                LastChgUserID       INT NOT NULL,  
                LastChgVersionID    INT NOT NULL,  
                LastChgTS           ROWVERSION NOT NULL,  
                AsOf_ID             INT NULL,  
                MUID                UNIQUEIDENTIFIER NOT NULL CONSTRAINT ', QUOTENAME(N'df_' + @EntityTable + N'_MUID'), N' DEFAULT NEWID(),  
  
                --Create PRIMARY KEY constraint  
                CONSTRAINT ', QUOTENAME(N'pk_' + @EntityTable), N'  
                    PRIMARY KEY CLUSTERED (Version_ID, ID)  
  
                -- Note: the values of the Status_ID column should fall between 1 and 2. The ValidationStatus_ID column should be between 0 and 5. However,  
                -- we do not enforce this via db constraint because it would slow down table writes and only trusted MDS sproc code should be writing to those columns.  
            )  
            ', @TableOptions, N'  
  
            --Ensure uniqueness of [Code] for active members.  
            CREATE UNIQUE NONCLUSTERED INDEX ', QUOTENAME(N'ux_' + @EntityTable + N'_Version_ID_Code_Active'), N'  
                ON mdm.', QUOTENAME(@EntityTable), N'(Version_ID, Code)  
                WHERE Status_ID = ', @Status_Active, N'  
                ', @IndexOptions, N';  
  
            --Index [Code] and [Name] for performance. Indexing [Code] for all members (active or not) improves EBS Purge perf, which matches against all member Code values, not just active members.  
            CREATE NONCLUSTERED INDEX ', QUOTENAME(N'ix_' + @EntityTable + N'_Version_ID_Code_Name'), N'  
                ON mdm.', QUOTENAME(@EntityTable), N'(Version_ID, Code, Name)  
                ', @IndexOptions, N';  
  
            --Index Status_ID and ValidationStatus_ID for performance (queried together in udpVersionValidationStatusGet)  
            CREATE NONCLUSTERED INDEX ', QUOTENAME(N'ix_' + @EntityTable + N'_Version_ID_Status_ID_ValidationStatus_ID'), N'  
                ON mdm.', QUOTENAME(@EntityTable), N'(Version_ID, Status_ID, ValidationStatus_ID)  
                ', @IndexOptions, N';  
  
            --Index [LastChgDTM] for performance  
            CREATE NONCLUSTERED INDEX ', QUOTENAME(N'ix_' + @EntityTable + N'_Version_ID_LastChgDTM'), N'  
                ON mdm.' + QUOTENAME(@EntityTable) + N'(Version_ID, LastChgDTM)  
                ', @IndexOptions, N';  
  
            --Ensure uniqueness of [MUID]  
            CREATE UNIQUE NONCLUSTERED INDEX ', QUOTENAME(N'ux_' + @EntityTable + N'_Version_ID_MUID'), N'  
                ON mdm.', QUOTENAME(@EntityTable), N'(Version_ID, MUID)  
                ', @IndexOptions, N';  
  
            --Required for VersionCopy operations  
            CREATE NONCLUSTERED INDEX ', QUOTENAME(N'ix_' + @EntityTable + N'_Version_ID_AsOf_ID_Status_ID'), N'  
                ON mdm.', QUOTENAME(@EntityTable), N'(Version_ID, AsOf_ID, Status_ID)  
                INCLUDE ([ID])  
                WHERE [AsOf_ID] IS NOT NULL  
                ', @IndexOptions, N';  
  
            --Create the History (_EN_HS) table  
            CREATE TABLE mdm.', QUOTENAME(@HistoryTable), N'  
            (  
                Version_ID          INT NOT NULL,  
                ID                  BIGINT NOT NULL,  
  
                EN_ID               INT NOT NULL,  
  
                --Status  
                Status_ID           TINYINT NOT NULL,  
  
                --Info  
                [Name]              NVARCHAR(250) NULL,  
                Code                NVARCHAR(250) NOT NULL,  
  
                --Auditing  
                EnterDTM            DATETIME2(3) NOT NULL,  
                EnterUserID         INT NOT NULL,  
                LastChgDTM          DATETIME2(3) NOT NULL,  
                LastChgUserID       INT NOT NULL,  
                MUID                UNIQUEIDENTIFIER NOT NULL,  
  
                --Create PRIMARY KEY constraint  
                CONSTRAINT ', QUOTENAME(N'pk_' + @HistoryTable), N'  
                    PRIMARY KEY CLUSTERED (Version_ID, ID)  
  
                --Cannot have foreign key (Version_ID, EN_ID) on EN table, because HS table is used in OUTPUT clause  
            )  
            ', @TableOptions, N'  
  
            -- Required by udpEntityMemberHistoriesGet and type2 view  
            CREATE NONCLUSTERED INDEX ', QUOTENAME(N'ix_' + @HistoryTable + N'_Version_ID_EN_ID_EnterDTM_LastChgDTM'), N'  
                ON mdm.', QUOTENAME(@HistoryTable), N'(Version_ID, EN_ID, EnterDTM, LastChgDTM)  
                INCLUDE(Name, Code) -- Required by type 2 view  
                ', @IndexOptions, N';  
  
            --Create the Annotation (_EN_AN) table  
            CREATE TABLE mdm.', QUOTENAME(@AnnotationTable), N'  
            (  
                Version_ID          INT NOT NULL,  
                ID                  INT IDENTITY(1, 1) NOT NULL,  
  
                Revision_ID         BIGINT NOT NULL,  
  
                [Comment]           [NVARCHAR](500) NULL,  
  
                --Auditing  
                EnterDTM            DATETIME2(3) NOT NULL CONSTRAINT ', QUOTENAME(N'df_' + @AnnotationTable  + N'_EnterDTM'), N' DEFAULT GETUTCDATE(),  
                EnterUserID         INT NOT NULL,  
                LastChgDTM          DATETIME2(3) NOT NULL CONSTRAINT ', QUOTENAME(N'df_' + @AnnotationTable  + N'_LastChgDTM'), N' DEFAULT GETUTCDATE(),  
                LastChgUserID       INT NOT NULL,  
                LastChgTS           ROWVERSION NOT NULL,  
  
                --Create PRIMARY KEY constraint  
                CONSTRAINT ', QUOTENAME(N'pk_' + @AnnotationTable), N'  
                    PRIMARY KEY CLUSTERED (Version_ID, ID)  
            )  
            ', @TableOptions, N'  
  
            -- Required for udpEntityMemberAnnotationsGet operations  
            CREATE NONCLUSTERED INDEX ', QUOTENAME(N'ix_' + @AnnotationTable + N'_Version_ID_Revision_ID'), N'  
                ON mdm.' + QUOTENAME(@AnnotationTable) + N'(Version_ID, Revision_ID)  
                ', @IndexOptions, N';  
  
            --Create the PendingChanges (_EN_PD) table  
            CREATE TABLE mdm.', QUOTENAME(@PendingTable), N'  
            (  
                Version_ID          INT NOT NULL,  
                ID                  INT IDENTITY(1, 1) NOT NULL,  
  
                CS_ID               INT NOT NULL,  
                EN_ID               INT NULL,  
  
                --Status  
                Status_ID           TINYINT NOT NULL,  
  
                --Info  
                [Name]              NVARCHAR(250) NULL,  
                Code                NVARCHAR(250) NULL,  
  
                --Auditing  
                EnterDTM            DATETIME2(3) NOT NULL CONSTRAINT ', QUOTENAME(N'df_' + @PendingTable  + N'_EnterDTM'), N' DEFAULT GETUTCDATE(),  
                EnterUserID         INT NOT NULL,  
                LastChgDTM          DATETIME2(3) NOT NULL CONSTRAINT ', QUOTENAME(N'df_' + @PendingTable  + N'_LastChgDTM'), N' DEFAULT GETUTCDATE(),  
                LastChgUserID       INT NOT NULL,  
                LastChgTS           ROWVERSION NOT NULL,  
                Revision_ID         BIGINT NOT NULL,  
                MUID                UNIQUEIDENTIFIER NOT NULL,  
  
                --Create PRIMARY KEY constraint  
                CONSTRAINT ', QUOTENAME(N'pk_' + @PendingTable), N'  
                    PRIMARY KEY CLUSTERED (Version_ID, ID),  
  
                --Create FOREIGN KEY constraints  
                CONSTRAINT ', QUOTENAME(N'fk_' + @PendingTable + N'_' + @EntityTable + '_Version_ID_EN_ID'), N'  
                    FOREIGN KEY (Version_ID, EN_ID) REFERENCES mdm.' + @EntityTable + '(Version_ID, ID)  
                    ON UPDATE NO ACTION  
                    ON DELETE CASCADE  
            )  
            ', @TableOptions, N'  
  
            CREATE NONCLUSTERED INDEX ', QUOTENAME(N'ix_' + @PendingTable + N'_Version_ID_CS_ID_EN_ID'), N'  
                ON mdm.', QUOTENAME(@PendingTable), N'(Version_ID, CS_ID, EN_ID)  
                ', @IndexOptions, N';  
  
            --Create the Member Security (EN_MS) table  
            --There is no IDENTITY() column since this table gets bulk- deleted & inserted frequently  
            CREATE TABLE mdm.', QUOTENAME(@SecurityTable), N'  
            (  
                Version_ID          INT NOT NULL,  
                User_ID             INT NOT NULL,  
                ID                  INT NOT NULL,  
                AccessPermission    TINYINT NOT NULL,  
  
                --Create PRIMARY KEY constraint  
                CONSTRAINT ', QUOTENAME(N'pk_' + @SecurityTable), N'  
                     PRIMARY KEY CLUSTERED (Version_ID, User_ID, ID), -- User_ID comes before ID (udpSecurityMemberProcess joins on Version_ID and User_ID)  
  
                --Create FOREIGN KEY constraints  
                CONSTRAINT ', QUOTENAME(N'fk_' + @SecurityTable + N'_' + @EntityTable + '_Version_ID_ID'), N'  
                    FOREIGN KEY (Version_ID, ID) REFERENCES mdm.' + @EntityTable + '(Version_ID, ID)  
                    ON UPDATE NO ACTION  
                    ON DELETE CASCADE  
            )  
            ', @TableOptions, N'  
  
            -- Create index for the FK, to improve perf of cascaded deletes from EN table.  
            CREATE NONCLUSTERED INDEX ', QUOTENAME(N'ix_' + @SecurityTable + N'_Version_ID_ID'), N'  
                ON mdm.', QUOTENAME(@SecurityTable), N'(Version_ID, ID)  
                ', @IndexOptions, N';  
            ');  
  
            --Execute the dynamic SQL  
            --PRINT(@SQL);  
            EXEC sp_executesql @SQL;  
  
            --Add default columns to Attribute table  
            INSERT INTO mdm.tblAttribute (Entity_ID,SortOrder,DomainEntity_ID,AttributeType_ID,MemberType_ID,IsSystem,IsReadOnly,IsCode,IsName,[Name],DisplayName,TableColumn,DisplayWidth,DataType_ID,DataTypeInformation,InputMask_ID,EnterUserID,EnterVersionID,LastChgUserID,LastChgVersionID)  
            VALUES  
             (@Entity_ID, 1, NULL, 3, 1, 1, 1, 0, 0, N'ID',N'ID',N'ID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 2, NULL, 3, 1, 1, 1, 0, 0, N'Version_ID',N'Version_ID',N'Version_ID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 4, NULL, 3, 1, 1, 1, 0, 0, N'Status_ID',N'Status_ID',N'Status_ID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 5, NULL, 3, 1, 1, 1, 0, 0, N'ValidationStatus_ID',N'ValidationStatus_ID',N'ValidationStatus_ID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 6, NULL, 3, 1, 1, 1, 0, 0, N'EnterDTM',N'EnterDTM',N'EnterDTM',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 7, NULL, 3, 1, 1, 1, 0, 0, N'EnterUserID',N'EnterUserID',N'EnterUserID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 8, NULL, 3, 1, 1, 1, 0, 0, N'EnterVersionID',N'EnterVersionID',N'EnterVersionID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 9, NULL, 3, 1, 1, 1, 0, 0, N'LastChgDTM',N'LastChgDTM',N'LastChgDTM',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 10, NULL, 3, 1, 1, 1, 0, 0, N'LastChgUserID',N'LastChgUserID',N'LastChgUserID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 11, NULL, 3, 1, 1, 1, 0, 0, N'LastChgVersionID',N'LastChgVersionID',N'LastChgVersionID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 12, NULL, 3, 1, 1, 1, 0, 0, N'LastChgTS',N'LastChgTS',N'LastChgTS',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 13, NULL, 1, 1, 1, 0, 0, 1, N'Name',N'Name',N'Name',250,1,250,1,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 14, NULL, 1, 1, 1, 0, 1, 0, N'Code',N'Code',N'Code',250,1,250,1,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 15, NULL, 3, 1, 1, 1, 0, 0, N'MUID',N'MUID',N'MUID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 16, NULL, 3, 1, 1, 1, 0, 0, N'AsOf_ID',N'AsOf_ID',N'AsOf_ID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 17, NULL, 3, 1, 1, 0, 0, 0, N'ChangeTrackingMask',N'ChangeTrackingMask',N'ChangeTrackingMask',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ;  
  
            EXEC mdm.udpEntityStagingCreateLeafTable  
                 @StagingTableName = @StagingTable  
                ,@TableOptions = @StagingTableOptions  
                ,@IndexOptions = @StagingIndexOptions;  
  
            IF @RecreateStagingProc = 1  
            BEGIN  
                -- Create the leaf member staging stored procedure.  
                EXEC mdm.udpEntityStagingCreateLeafStoredProcedure @Entity_ID  
            END  
        END; --if  
  
        --Recreate the views  
        EXEC mdm.udpCreateViews @Model_ID, @Entity_ID;  
        EXEC mdm.udpEntityStagingCreateErrorDetailViews @Entity_ID;  
  
        --Return values  
        SET @Return_ID = @Entity_ID;  
  
        --Commit only if we are not nested  
        IF @TranCounter = 0  
        BEGIN  
            COMMIT TRANSACTION;  
            --Set @TranCommitted as 1 (committed).  
            SET @TranCommitted = 1;  
        END -- IF  
  
        -- Return indicating whether the entity name was updated.  This is used in the API to determine if business rules should be refreshed.  
        IF  @EditMode = @EditMode_Update AND  
            (@CurrentEntityName <> COALESCE(@EntityName, @CurrentEntityName) OR  
            (@CurrentEntityStagingBaseName <> CASE WHEN LEN(@StagingBase) > 0 THEN @StagingBase ELSE @CurrentEntityStagingBaseName END))  
        BEGIN  
            SET @Return_DidNameChange = 1;  
        END  
        ELSE  
        BEGIN  
            SET @Return_DidNameChange = 0;  
        END  
  
        RETURN(0);  
  
    END TRY  
    --Compensate as necessary  
    BEGIN CATCH  
  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        IF @TranCommitted = 0 -- Don't rollback when the transaction has been committed.  
        BEGIN  
            IF @TranCounter = 0 ROLLBACK TRANSACTION;  
            ELSE IF XACT_STATE() <> -1 ROLLBACK TRANSACTION TX;  
        END; -- IF  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
  
        RETURN;  
  
    END CATCH;  
  
    SET NOCOUNT OFF;  
END; --proc
go

