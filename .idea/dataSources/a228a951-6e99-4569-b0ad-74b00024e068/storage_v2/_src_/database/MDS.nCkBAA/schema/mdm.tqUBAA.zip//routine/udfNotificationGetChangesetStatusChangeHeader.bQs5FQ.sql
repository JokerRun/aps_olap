/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
SELECT CONVERT(XML, mdm.udfNotificationGetChangesetStatusChangeHeader());  
*/  
CREATE FUNCTION mdm.udfNotificationGetChangesetStatusChangeHeader()  
RETURNS NVARCHAR(MAX)  
/*WITH SCHEMABINDING*/  
AS BEGIN  
  
    DECLARE  
         @HeaderElement NVARCHAR(MAX)  
        ,@LocalizedNotificationTypeName NVARCHAR(MAX) = N'Changeset Status Change'  
        ,@LocalizedModelHeader NVARCHAR(MAX) = N'Model'  
        ,@LocalizedVersionHeader NVARCHAR(MAX) = N'Version'  
        ,@LocalizedEntityHeader NVARCHAR(MAX) = N'Entity'  
        ,@LocalizedChangesetHeader NVARCHAR(MAX) = N'Changeset'  
        ,@LocalizedPriorStatusHeader NVARCHAR(MAX) = N'Prior status'  
        ,@LocalizedNewStatusHeader NVARCHAR(MAX) = N'New status'  
        ,@LocalizedLink NVARCHAR(MAX) = N'Click to view'  
        ,@LocalizedProductName NVARCHAR(MAX) = N'SQL Server Master Data Services'  
        ,@CurrentLanguageCode INT = 1033 -- Default language code is English (US).  
        ,@StringLanguageCode NVARCHAR(MAX) = N'1033'  
        ,@RootUrl NVARCHAR(MAX)  
  
    -- Use default language code to get the notification language code.  
    SET @StringLanguageCode = mdm.udfLocalizedStringGet(N'NotificationLCID', @CurrentLanguageCode, @StringLanguageCode);  
  
    IF @StringLanguageCode <> N'' BEGIN  
        SET @CurrentLanguageCode = CONVERT(INT, @StringLanguageCode)  
    END; -- if  
  
    -- Get the localized message texts based on the notification language code in tblLocalizedStrings.  
    SET @LocalizedModelHeader = mdm.udfLocalizedStringGet(N'NotificationHeaderModel', @CurrentLanguageCode, @LocalizedModelHeader);  
    SET @LocalizedVersionHeader = mdm.udfLocalizedStringGet(N'NotificationHeaderVersion', @CurrentLanguageCode, @LocalizedVersionHeader);  
    SET @LocalizedEntityHeader = mdm.udfLocalizedStringGet(N'NotificationHeaderEntity', @CurrentLanguageCode, @LocalizedEntityHeader);  
    SET @LocalizedChangesetHeader = mdm.udfLocalizedStringGet(N'NotificationHeaderChangeset', @CurrentLanguageCode, @LocalizedChangesetHeader);  
    SET @LocalizedPriorStatusHeader = mdm.udfLocalizedStringGet(N'NotificationHeaderPriorStatus', @CurrentLanguageCode, @LocalizedPriorStatusHeader);  
    SET @LocalizedNewStatusHeader = mdm.udfLocalizedStringGet(N'NotificationHeaderNewStatus', @CurrentLanguageCode, @LocalizedNewStatusHeader);  
    SET @LocalizedLink = mdm.udfLocalizedStringGet(N'NotificationLinkTextVerbose', @CurrentLanguageCode, @LocalizedLink);  
    SET @LocalizedProductName = mdm.udfLocalizedStringGet(N'NotificationProductName', @CurrentLanguageCode, @LocalizedProductName);  
    SET @LocalizedNotificationTypeName = mdm.udfLocalizedStringGet(N'NotificationChangesetStatusChange', @CurrentLanguageCode, @LocalizedNotificationTypeName);  
  
    -- Get the MDS web application root URL  
    SET @RootUrl = mdm.udfSystemSettingGet(N'MDMRootURL');  
  
    IF RIGHT(@RootUrl, 1) != N'/'  
    BEGIN  
        SET @RootUrl = CONCAT(@RootUrl, N'/');  
    END  
  
    SET @HeaderElement = CONCAT(N'  
        <header>  
          <ProductName>', (SELECT @LocalizedProductName FOR XML PATH('')), N'</ProductName>  
          <Notification_type>' + (SELECT @LocalizedNotificationTypeName FOR XML PATH('')), N'</Notification_type>  
          <Model>', (SELECT @LocalizedModelHeader FOR XML PATH('')), N'</Model>  
          <Version>', (SELECT @LocalizedVersionHeader FOR XML PATH('')), N'</Version>  
          <Entity>', (SELECT @LocalizedEntityHeader FOR XML PATH('')), N'</Entity>  
          <Changeset>', (SELECT @LocalizedChangesetHeader FOR XML PATH('')), N'</Changeset>  
          <PriorStatus>', (SELECT @LocalizedPriorStatusHeader FOR XML PATH('')), N'</PriorStatus>  
          <NewStatus>', (SELECT @LocalizedNewStatusHeader FOR XML PATH('')), N'</NewStatus>  
          <link_text>', (SELECT @LocalizedLink FOR XML PATH('')), N'</link_text>  
          <root_url>', (SELECT @RootUrl FOR XML PATH('')), N'</root_url>  
        </header>');  
  
    RETURN @HeaderElement  
  
END --fn
go

