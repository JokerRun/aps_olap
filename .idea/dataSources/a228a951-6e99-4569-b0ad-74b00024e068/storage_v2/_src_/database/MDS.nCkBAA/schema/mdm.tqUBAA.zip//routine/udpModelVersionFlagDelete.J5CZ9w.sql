/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    EXEC mdm.udpModelVersionFlagDelete 1, '1565655D-4B03-4F64-B37F-956F75BF396D'  
*/  
CREATE PROCEDURE mdm.udpModelVersionFlagDelete  
(  
    @VersionFlag_ID INT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON;  
  
    --Do a hard delete of the version flag  
    UPDATE mdm.tblModelVersion SET VersionFlag_ID = NULL WHERE VersionFlag_ID = @VersionFlag_ID;  
    DELETE FROM mdm.tblModelVersionFlag	WHERE ID = @VersionFlag_ID;  
  
    SET NOCOUNT OFF;  
END; --proc
go

