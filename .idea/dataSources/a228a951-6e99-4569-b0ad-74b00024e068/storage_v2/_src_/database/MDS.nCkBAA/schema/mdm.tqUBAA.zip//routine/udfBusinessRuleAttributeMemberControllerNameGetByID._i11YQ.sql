/*  
    SELECT mdm.udfBusinessRuleAttributeMemberControllerNameGetByID(32,1)  
*/  
/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE FUNCTION mdm.udfBusinessRuleAttributeMemberControllerNameGetByID  
(  
    @Entity_ID      INT,  
    @EntityType_ID  TINYINT  
)   
RETURNS sysname  
/*WITH SCHEMABINDING*/  
AS BEGIN  
    DECLARE @ControllerName SYSNAME,  
            @ModelID INT,  
  
            @MemberType_Leaf            TINYINT = 1,  
            @MemberType_Consolidated    TINYINT = 2,  
            @MemberType_Collection      TINYINT = 3;  
  
    SELECT @ModelID = Model_ID FROM mdm.tblEntity WHERE ID = @Entity_ID;  
  
    SET @ControllerName = CONCAT(N'udp_SYSTEM_', @ModelID, N'_', @Entity_ID, N'_',  
        CASE @EntityType_ID  
            WHEN @MemberType_Leaf THEN N'CHILDATTRIBUTES'  
            WHEN @MemberType_Consolidated THEN N'PARENTATTRIBUTES'  
            WHEN @MemberType_Collection THEN N'COLLECTIONATTRIBUTES'  
        END, N'_ProcessRules')  
  
    RETURN @ControllerName;  
END --fn
go

