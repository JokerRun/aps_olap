/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Determines whether the the specified model version (or versions) is being validated by the service broker.  
  
DECLARE @IsRunning BIT = 0;  
EXEC mdm.udpValidationIsRunning @Version_ID = 20, @IsRunning = @IsRunning OUTPUT -- checks one version  
SELECT @IsRunning;  
EXEC mdm.udpValidationIsRunning @Entity_ID = 31, @IsRunning = @IsRunning OUTPUT -- checks all versions that pertain to the specified entity's model.  
SELECT @IsRunning;  
EXEC mdm.udpValidationIsRunning @Model_ID = 7, @IsRunning = @IsRunning OUTPUT -- checks all versions that pertain to the specified model.  
SELECT @IsRunning;  
EXEC mdm.udpValidationIsRunning @IsRunning = @IsRunning OUTPUT -- checks all versions  
SELECT @IsRunning;  
  
*/  
CREATE PROCEDURE mdm.udpValidationIsRunning  
(  
     @Model_ID      INT = NULL  
    ,@Version_ID    INT = NULL  
    ,@Entity_ID     INT = NULL  
    ,@IsRunning     BIT OUTPUT  
    ,@CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
-- The caller is the application pool user which should have VIEW SERVER STATE  
WITH EXECUTE AS CALLER  
AS BEGIN  
    SET NOCOUNT ON  
      
    DECLARE @IsTaskActive  BIT = 0;  
    SELECT @IsTaskActive = 1 FROM sys.dm_broker_activated_tasks WHERE procedure_name = N'[mdm].[udpValidationQueueActivate]';  
  
    EXEC mdm.udpValidationIsRunningInternal  
        @Model_ID = @Model_ID,  
        @Version_ID = @Version_ID,  
        @Entity_ID = @Entity_ID,  
        @IsTaskActive = @IsTaskActive,  
        @IsRunning = @IsRunning OUTPUT,  
        @CorrelationID = @CorrelationID;  
  
    SET NOCOUNT OFF  
END --proc
go

