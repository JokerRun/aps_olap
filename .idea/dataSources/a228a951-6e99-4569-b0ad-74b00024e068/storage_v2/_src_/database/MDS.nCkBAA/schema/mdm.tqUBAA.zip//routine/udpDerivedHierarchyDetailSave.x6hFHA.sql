/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
mdm.udpDerivedHierarchyDetailSave 1,.....  
*/  
CREATE PROCEDURE mdm.udpDerivedHierarchyDetailSave  
(  
    @User_ID                INT,  
    @Model_ID               INT, -- caller should validate  
    @Version_ID             INT = NULL, -- used for audit info. When NULL, the highest value for the model will be used  
    @DerivedHierarchy_ID    INT, -- caller should validate  
    @MUID                   UNIQUEIDENTIFIER = NULL,  
    @Name                   NVARCHAR(100),  
    @Foreign_ID             INT, -- caller should validate  
    @ForeignType_ID         TINYINT,      
    @ManyToManyChildAttribute_ID    INT = NULL, -- caller should validate  
    @DisplayName            NVARCHAR(100),  
    @IsVisible              BIT,  
    @EditMode               TINYINT = 0, --0: Create, 1: Update, 4: Clone, defaults to Create  
    @IsMemberSecurityApplied BIT = NULL, -- If NULL, will be looked up.  
    @Return_ID              INT = NULL OUTPUT,  
    @Return_MUID            UNIQUEIDENTIFIER = NULL OUTPUT,  
    @CorrelationID          UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON  
      
    DECLARE   
         @GuidEmpty         UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER)  
  
        ,@HierarchyItemType_Entity              TINYINT = 0  
        ,@HierarchyItemType_DBA                 TINYINT = 1  
        ,@HierarchyItemType_Hierarchy           TINYINT = 2  
        --,@HierarchyItemType_ConsolidatedDBA     TINYINT = 3 -- Not used  
        ,@HierarchyItemType_ManyToMany          TINYINT = 5  
  
        ,@MemberType_Leaf           TINYINT = 1  
        ,@MemberType_Consolidated   TINYINT = 2  
  
        -- This pseudo-constant is for use in string concatenation operations to prevent string truncation. When concatenating two or more strings,  
        -- if none of the strings is an NVARCHAR(MAX) or an NVARCHAR constant that is longer than 4,000 characters, then the resulting string   
        -- will be silently truncated to 4,000 characters. Concatenating with this empty NVARCHAR(MAX), is sufficient to prevent truncation.  
        -- See http://connect.microsoft.com/SQLServer/feedback/details/283368/nvarchar-max-concatenation-yields-silent-truncation.  
        ,@TruncationGuard                NVARCHAR(MAX) = N''  
        ,@ExistingLevel_MUID             UNIQUEIDENTIFIER = NULL  
        ,@ExistingLevel_ID               INT = NULL  
        ,@ExistingLevel_IsRecursive      BIT = 0  
  
        ,@EditMode_Create                TINYINT = 0  
        ,@EditMode_Update                TINYINT = 1  
        ,@EditMode_Clone                 TINYINT = 4  
  
        ,@LevelNumber                    INT = NULL  
  
    SELECT    
        @DerivedHierarchy_ID = NULLIF(@DerivedHierarchy_ID, 0),  
        @Foreign_ID = NULLIF(@Foreign_ID, 0),  
        @ManyToManyChildAttribute_ID = NULLIF(@ManyToManyChildAttribute_ID, 0),  
        @MUID = NULLIF(@MUID, @GuidEmpty),  
        @Name = NULLIF(LTRIM(RTRIM(@Name)), N'');  
  
    --Test for invalid EditMode  
    IF @EditMode IS NULL OR @EditMode NOT IN (@EditMode_Create, @EditMode_Update, @EditMode_Clone)  
    BEGIN  
        --On error, return NULL results  
        RAISERROR('MDSERR100010|The Parameters are not valid.', 16, 1);  
        RETURN;  
    END; --if  
  
    IF @IsMemberSecurityApplied IS NULL  
    BEGIN  
        SET @IsMemberSecurityApplied = CASE WHEN EXISTS (SELECT 1  FROM mdm.tblSecurityRoleAccessMember WHERE DerivedHierarchy_ID = @DerivedHierarchy_ID)   
            THEN 1 ELSE 0 END  
    END  
      
    --If we are in the Update or Clone mode get the missing pieces of the identifier  
    IF @EditMode IN (@EditMode_Update, @EditMode_Clone)  
    BEGIN  
        --Only use the name if neither MUID nor ID are available. This is important because we don't want  
        --to look up by name if the name is what the user is trying to update.  
        IF @MUID IS NULL  
        BEGIN  
            SELECT TOP 1  
                @ExistingLevel_ID = ID,  
                @ExistingLevel_MUID = MUID,  
                @LevelNumber = Level_ID,  
                @ExistingLevel_IsRecursive = IsRecursive  
            FROM mdm.viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED_LEVELS  
            WHERE   Name = @Name  
                AND Hierarchy_ID = @DerivedHierarchy_ID  
        END  
        --Use the derived hierarchy level ID and MUID to look up the full identifier  
        ELSE  
        BEGIN  
            SELECT  
                @ExistingLevel_ID =  ID,   
                @ExistingLevel_MUID = MUID,  
                @LevelNumber = Level_ID,  
                @ExistingLevel_IsRecursive = IsRecursive  
            FROM mdm.viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED_LEVELS  
            WHERE   MUID = @MUID  
                AND Hierarchy_ID = @DerivedHierarchy_ID  
        END  
  
        --If we are in the Clone mode we need to figure out whether we are creating or updating a derived hierarchy level  
        IF @EditMode = @EditMode_Clone  
        BEGIN  
            --If there is no existing derived hierarchy level then set the edit mode to Create  
            IF @ExistingLevel_ID IS NULL  
            BEGIN  
                SET @EditMode = @EditMode_Create;  
            END  
            --If there is an existing derived hierarchy level then set the edit mode to Update  
            ELSE  
            BEGIN  
                SET @EditMode = @EditMode_Update;  
                SET @MUID = @ExistingLevel_MUID;  
            END  
        END  
        --If we are in Update mode and could not find a matching existing derived hierarchy level we need to raise an error and quit now  
        ELSE IF @EditMode = @EditMode_Update  
        BEGIN  
            IF @ExistingLevel_ID IS NULL  
            BEGIN  
                --On error, return NULL results  
                SELECT @Return_ID = NULL, @Return_MUID = NULL;  
                RAISERROR('MDSERR200055|The derived hierarchy level cannot be saved. The derived hierarchy level ID is not valid.', 16, 1);  
                RETURN;  
            END ELSE  
            BEGIN  
                SET @MUID = @ExistingLevel_MUID;  
  
                --Perform validations for a recursive level.   
                --A recursive level must be visible.  
                IF @ExistingLevel_IsRecursive = 1 AND @IsVisible = 0  
                BEGIN  
                    --On error, return NULL results  
                    SELECT @Return_ID = NULL, @Return_MUID = NULL;  
                    RAISERROR('MDSERR200080|The derived hierarchy level cannot be hidden because it defines a recursive relationship.', 16, 1);  
                    RETURN;  
                END  
            END  
        END  
    END      
  
    --If the edit mode is Create. This code also needs to execute if the user sent in EditMode clone which ended up becoming Create (hence the IF instead of ELSE IF)  
    IF @EditMode = @EditMode_Create  
    BEGIN  
        --If MUID is not null then we need to ensure it does not already exist (since this is a create)  
        IF @MUID IS NOT NULL AND EXISTS(SELECT 1 FROM mdm.tblDerivedHierarchy WHERE MUID = @MUID)  
        BEGIN  
            --On error, return NULL results  
            SELECT @Return_ID = NULL, @Return_MUID = NULL;  
            RAISERROR('MDSERR110007|The ID is not valid.', 16, 1);  
            RETURN;  
        END  
  
        --These checks are only applicable for new derived hierarchy levels  
        --Perform validations for the compatibility of this level within a derived hierarchy   
        --that has a recursive relationship at any level.  
        IF EXISTS(  
                    SELECT 1  
                    FROM mdm.viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED_LEVELS  
                    WHERE   Hierarchy_ID = @DerivedHierarchy_ID  
                        AND IsRecursive = 1  
                )  
        BEGIN  
  
            IF (@IsMemberSecurityApplied = 1)  
            BEGIN  
                RAISERROR('MDSERR200113|The derived hierarchy level cannot be saved. A level cannot be added on top of a recursive level when the hierarchy has member permissions assigned.', 16, 1);  
                RETURN;  
            END  
  
            --Cannot add an explicit hierarchy level to a recursive derived hierarchy.  
            IF @ForeignType_ID = @HierarchyItemType_Hierarchy  
            BEGIN  
                --On error, return NULL results  
                SELECT @Return_ID = NULL, @Return_MUID = NULL;  
                RAISERROR('MDSERR200082|The derived hierarchy level cannot be saved.  An explicit hierarchy level is not supported in a recursive derived hierarchy.', 16, 1);  
                RETURN;  
            END  
        END  
    END  
  
    IF COALESCE(@Foreign_ID, -1) <= 0   
    BEGIN  
        --On error, return NULL results  
        SELECT @Return_ID = NULL, @Return_MUID = NULL;  
        RAISERROR('MDSERR200063|The derived hierarchy level cannot be saved. The Foreign ID is not valid.', 16, 1);  
        RETURN;  
    END;  
              
    --Validate ForeignType ID  
    IF (@ForeignType_ID IS NULL)  
    BEGIN  
        RAISERROR('MDSERR100008|The ForeignType_ID is required.', 16, 1);  
        RETURN;    
    END;  
  
    -- Validate ManyToManyChildAttribute  
    IF @ForeignType_ID = @HierarchyItemType_ManyToMany  
    BEGIN  
        IF @ManyToManyChildAttribute_ID = @Foreign_ID  
        BEGIN  
            RAISERROR('MDSERR100062|The ManyToManyChildAttributeId cannot reference the same attribute as ForeignId.', 16, 1);  
            RETURN;    
        END  
    END ELSE   
    BEGIN  
        -- It is not a many-to-many level, so ensure the @ManyToManyChildAttribute_ID is null.  
        SET @ManyToManyChildAttribute_ID = NULL;  
    END  
      
    IF @Version_ID IS NULL  
    BEGIN  
        --Get the Latest Version  
        SELECT @Version_ID = MAX(mv.ID)  
        FROM mdm.tblModelVersion mv   
        INNER JOIN mdm.tblDerivedHierarchy dh  
        ON mv.Model_ID = dh.Model_ID   
            AND dh.ID = @DerivedHierarchy_ID  
    END  
      
    --Check the name of the derived hierarchy level for duplicates  
    IF EXISTS   
    (  
        SELECT 1 FROM   
        mdm.tblDerivedHierarchyDetail  
        WHERE   
            @Name = Name AND   
            (@MUID IS NULL OR MUID <> @MUID) AND  
            DerivedHierarchy_ID = @DerivedHierarchy_ID  
    )  
    BEGIN  
        --On error, return NULL results  
        SELECT @Return_ID = NULL, @Return_MUID = NULL;  
        RAISERROR('MDSERR110003|The name already exists. Type a different name.', 16, 1);  
        RETURN;  
    END  
  
        
    BEGIN TRY    
        IF @EditMode = @EditMode_Update  
        --Update  
        BEGIN    
            -- Update existing level.  
            IF @IsVisible = 0  
            BEGIN  
                -- Cannot hide a level if the hierarchy is used for member security.  
                If @IsMemberSecurityApplied = 1  
                BEGIN  
                    RAISERROR('MDSERR200075|The derived hierarchy level cannot be hidden. The derived hierarchy has secured members.', 16, 1);  
                    RETURN  
                END;  
  
                -- Cannot hide top or bottom level  
                DECLARE @MaxLevel INT = (SELECT MAX(Level_ID) FROM mdm.tblDerivedHierarchyDetail WHERE DerivedHierarchy_ID = @DerivedHierarchy_ID);  
                IF @LevelNumber IN (1, @MaxLevel)  
                BEGIN  
                    RAISERROR('MDSERR200099|The top or bottom level of a derived hierarchy cannot be hidden.', 16, 1);  
                    RETURN  
                END;  
  
                -- Cannot hide a level whose parent level is recursive  
                IF EXISTS(  
                    SELECT 1   
                    FROM mdm.tblDerivedHierarchyDetail child  
                    INNER JOIN mdm.tblAttribute cDba  
                    ON child.Foreign_ID = cDba.ID  
                    INNER JOIN mdm.tblDerivedHierarchyDetail parent  
                    ON      child.Level_ID = parent.Level_ID - 1  
                        AND child.DerivedHierarchy_ID = parent.DerivedHierarchy_ID  
                        AND parent.ForeignType_ID = @HierarchyItemType_DBA  
                    INNER JOIN mdm.tblAttribute pDba  
                    ON parent.Foreign_ID = pDba.ID  
                    WHERE   child.DerivedHierarchy_ID = @DerivedHierarchy_ID  
                        AND child.ID = @ExistingLevel_ID  
                        AND child.ForeignType_ID = @HierarchyItemType_DBA  
                        AND cDba.DomainEntity_ID = pDba.DomainEntity_ID  
                )  
                BEGIN  
                    RAISERROR('MDSERR200077|The derived hierarchy level cannot be hidden. It is part of a recursive relationship.', 16, 1);  
                    RETURN  
                END;  
  
                -- Cannot hide a level that is being used as part of an attribute filter  
                DECLARE   
                     @FilterEntityName NVARCHAR(50) = NULL  
                    ,@FilterAttributeName NVARCHAR(100) = NULL;  
                SELECT TOP 1   
                     @FilterEntityName = e.Name  
                    ,@FilterAttributeName = a.Name  
                FROM mdm.tblAttribute a  
                LEFT JOIN mdm.tblEntity e  
                ON a.Entity_ID = e.ID  
                WHERE a.FilterHierarchyDetail_ID = @ExistingLevel_ID  
                IF @FilterAttributeName IS NOT NULL  
                BEGIN  
                    DECLARE @Message NVARCHAR(MAX) = CONCAT('MDSERR200126|The derived hierarchy level cannot be hidden. It is being used to filter attribute "{0}" in entity "{1}".|', REPLACE(@FilterAttributeName, N'|', N''), N'|', REPLACE(@FilterEntityName, N'|', N''));  
                    SET @Message = REPLACE(@Message, '%', '%%')-- escape out format specifier  
                    RAISERROR(@Message, 16, 1);  
                    RETURN  
                END  
            END  
  
            UPDATE mdm.tblDerivedHierarchyDetail     
            SET  
                 Name = COALESCE(@Name, [Name])    
                ,DisplayName = COALESCE(@DisplayName, [DisplayName])    
                ,IsVisible = COALESCE(@IsVisible,[IsVisible])    
                ,LastChgDTM = GETUTCDATE()    
                ,LastChgUserID = @User_ID    
                ,LastChgVersionID = @Version_ID    
            WHERE    
                ID = @ExistingLevel_ID    
        
            --Populate output parameters    
            SELECT @Return_ID = @ExistingLevel_ID    
            SELECT @Return_MUID = @ExistingLevel_MUID;  
        END    
        ELSE    
        --Create  
        BEGIN    
            --Level Add Check.  We need to make sure the save request is compatible with the current top level of the hierarchy.    
            --The new level can only be added to the top.    
            DECLARE   
                 @NextLevelNumber INT  
                ,@ForeignParent_ID  INT  
  
            EXEC mdm.udpDerivedHierarchyLevelAddCheck @DerivedHierarchy_ID, @Foreign_ID, @ForeignType_ID, @ManyToManyChildAttribute_ID, @NextLevelNumber OUT, @ForeignParent_ID OUT    
                    
            IF @NextLevelNumber = 0    
            BEGIN    
                RAISERROR('MDSERR200056|The derived hierarchy level cannot be saved. The level being saved is not compatible with the current top level.', 16, 1);  
            END;    
                  
            -- If adding an explicit hierarchy and member security has been applied return error.  
            IF (@IsMemberSecurityApplied = 1 AND @ForeignType_ID = @HierarchyItemType_Hierarchy)  
            BEGIN  
                RAISERROR('MDSERR200076|A derived hierarchy level with explicit cap cannot be added. The derived hierarchy has secured members.', 16, 1);  
                RETURN  
            END  
  
-- TODO: If the level is ManyToMany and recursive (both parent and child DBAs reference the same entity), check for circular relationship.  
  
            -- If the level is recursive, check for pre-existing circular relationships.  
            IF @ForeignType_ID = @HierarchyItemType_DBA  
            BEGIN  
                -- Get attribute info  
                DECLARE   
                     @AttributeColumnName   sysname  
                    ,@Entity_ID             INT  
                    ,@DomainEntity_ID       INT;  
                SELECT  
                     @Entity_ID = Entity_ID  
                    ,@DomainEntity_ID = DomainEntity_ID  
                    ,@AttributeColumnName = TableColumn  
                FROM mdm.tblAttribute  
                WHERE ID = @Foreign_ID  
  
                -- If the attribute's entity is the same as its domain entity, then the level would be recursive. Ensure there are no pre-existing circular relationships.  
                IF @Entity_ID = @DomainEntity_ID  
                BEGIN  
                    DECLARE  
                         @MemberTableName   sysname = (SELECT EntityTable FROM mdm.tblEntity WHERE ID = @Entity_ID)  
                        ,@ErrorMsg          NVARCHAR(MAX)  
                        ,@SQL               NVARCHAR(MAX);  
  
                    SET @SQL = @TruncationGuard + N'  
                    SET @ErrorMsg = N'''';  
                    WITH parentAssignmentsCte AS  
                    (  
                        SELECT DISTINCT  
                                Code AS ChildCode  
                            ,ID AS ChildID  
                            ,' + @AttributeColumnName + N' AS ParentID  
                        FROM mdm.' + @MemberTableName + N'  
                        WHERE ' + @AttributeColumnName + N' IS NOT NULL -- Exclude null parents for efficiency. A member with a null parent cannot be part of a circular relationship.  
                    )  
  
                    -- Recursively find all member ancestors, checking for circular relationships.  
                    ,ancestorsCte AS  
                    (  
                        SELECT  
                             ChildCode AS MemberCode  
                            ,ChildID AS MemberID  
                            ,ParentID AS AncestorID  
                            ,0 AS RecursionLevel  
                            ,CASE WHEN ChildID = ParentID THEN 1 ELSE 0 END AS IsCircular -- If a member is its own parent, then it is part of a circular relationship.  
                        FROM parentAssignmentsCte  
  
                        UNION ALL  
  
                        -- Recursively find all ancestors of the members.  
                        SELECT  
                             cte.MemberCode  
                            ,cte.MemberID  
                            ,p.ParentID AS AncestorID  
                            ,cte.RecursionLevel + 1  
                            ,CASE WHEN cte.MemberID = p.ParentID THEN 1 ELSE 0 END AS IsCircular -- If a member is its own ancestor, then it is part of a circular relationship.  
                        FROM ancestorsCte cte  
                        INNER JOIN parentAssignmentsCte p  
                        ON cte.AncestorID = p.ChildID  
                        WHERE   cte.RecursionLevel < 99 -- Protects against "The statement terminated. The maximum recursion 100 has been exhausted before statement completion" error.  
                            AND cte.IsCircular = 0 -- Stop when a circular relationship is found.  
                    )  
                  
                    -- Get the MemberCodes that participate in circular relationships.  
                    ,circularRelationshipsCte AS  
                    (  
                        SELECT DISTINCT MemberCode  
                        FROM ancestorsCte  
                        WHERE IsCircular = 1  
                    )  
                    SELECT   
                        @ErrorMsg += N'', '' + MemberCode  
                    FROM circularRelationshipsCte;  
                    ';  
                    --PRINT @SQL  
                    EXEC sp_executesql @SQL, N'@ErrorMsg NVARCHAR(MAX) OUTPUT', @ErrorMsg OUTPUT;  
                    IF LEN(@ErrorMsg) > 0  
                    BEGIN  
                        SET @ErrorMsg = N'MDSERR100058|A recursive derived hierarchy level cannot be added. Members with the following codes participate in circular relationships: {0}.|'  
                            + REPLACE(SUBSTRING(@ErrorMsg, 2, LEN(@ErrorMsg)), N'|', N'');-- Remove the leading comma, remove separator char  
                        SET @ErrorMsg = REPLACE(@ErrorMsg, '%', '%%')-- escape out format specifier  
                        RAISERROR(@ErrorMsg, 16, 1);  
                        RETURN;  
                    END; -- Error found  
                END; -- Level is recursive  
            END; -- Level is DBA-based (not explicit hierarchy)  
  
            --Accept an explicit MUID (for clone operations) or generate a new one    
            SET @Return_MUID = COALESCE(@MUID, NEWID());    
    
            INSERT INTO mdm.tblDerivedHierarchyDetail    
                ([DerivedHierarchy_ID]    
                ,[ForeignParent_ID]    
                ,[Foreign_ID]    
                ,[ForeignType_ID]    
                ,[ManyToManyChildAttribute_ID]  
                ,[Level_ID]    
                ,[Name]    
                ,[MUID]    
                ,[DisplayName]    
                ,[IsVisible]    
                ,[EnterDTM]    
                ,[EnterUserID]    
                ,[EnterVersionID]    
                ,[LastChgDTM]    
                ,[LastChgUserID]    
                ,[LastChgVersionID])    
                    
            SELECT     
                 @DerivedHierarchy_ID    
                ,@ForeignParent_ID    
                ,@Foreign_ID    
                ,@ForeignType_ID    
                ,@ManyToManyChildAttribute_ID  
                ,@NextLevelNumber    
                ,@Name    
                ,@Return_MUID    
                ,@DisplayName    
                ,@IsVisible    
                ,GETUTCDATE()    
                ,@User_ID    
                ,@Version_ID    
                ,GETUTCDATE()    
                ,@User_ID    
                ,@Version_ID    
    
            SELECT @Return_ID = SCOPE_IDENTITY()    
        END    
  
        -- If the hierarchy is being used for member security, then put a message onto the service broker queue to process member security for the whole model.  
        IF @IsMemberSecurityApplied = 1  
        BEGIN  
            EXEC mdm.udpSecurityMemberProcessRebuildModel @Model_ID = @Model_ID, @ProcessNow=0;  
        END;  
    END TRY    
    BEGIN CATCH    
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
        RETURN;      
    END CATCH;    
    
    SET NOCOUNT OFF    
END --proc
go

