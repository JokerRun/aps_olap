/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Creates the collection member tables  (e.g. tbl_{@Model_ID}_{@Entity_ID}_CN and tbl_{@Model_ID}_{@Entity_ID}_CM  and system views for the given entity.  
  
*/  
CREATE PROCEDURE mdm.udpCollectionTablesCreate  
(  
     @User_ID               INT  
    ,@Model_ID              INT -- Note that this value could be looked up from the provided entity ID, but it is being passed to save an extra lookup  
    ,@Version_ID            INT  
    ,@Entity_ID             INT  
    ,@IsHierarchyEnabled    BIT -- If 1, adds to the collection membership (CM) table a column with a FK reference to the HP table (since collections can contain consolidated members)  
    ,@TableOptions          NVARCHAR(MAX) = N''  
    ,@IndexOptions          NVARCHAR(MAX) = N''  
    ,@CollectionTable       NVARCHAR(128) OUTPUT  
    ,@CorrelationID         UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
AS BEGIN  
  
    DECLARE  
         @SQL                       NVARCHAR(MAX)  
        ,@TableNamePrefix           NVARCHAR(120) = CONCAT(N'tbl_', @Model_ID, N'_', @Entity_ID)  
        ,@Status_Active             TINYINT = 1  
  
        -- This pseudo-constant is for use in string concatenation operations to prevent string truncation. When concatenating two or more strings,  
        -- if none of the strings is an NVARCHAR(MAX) or an NVARCHAR constant that is longer than 4,000 characters, then the resulting string  
        -- will be silently truncated to 4,000 characters. Concatenating with this empty NVARCHAR(MAX) is sufficient to prevent truncation.  
        -- See http://connect.microsoft.com/SQLServer/feedback/details/283368/nvarchar-max-concatenation-yields-silent-truncation.  
        ,@TruncationGuard        NVARCHAR(MAX) = N'';  
  
    SET @CollectionTable = @TableNamePrefix + N'_CN';  
    DECLARE  
         @EntityTable               NVARCHAR(128) = @TableNamePrefix + N'_EN'  
        ,@CollectionMemberTable     NVARCHAR(128) = @TableNamePrefix + N'_CM'  
        ,@HierarchyParentTable      NVARCHAR(128) = @TableNamePrefix + N'_HP'  
        ,@CollectionHistoryTable    NVARCHAR(128) = @TableNamePrefix + N'_CN_HS'  
        ,@CollectionAnnotationTable NVARCHAR(128) = @TableNamePrefix + N'_CN_AN'  
        ,@CollectionMemberHistoryTable      NVARCHAR(128) = @TableNamePrefix + N'_CM_HS'  
        ,@CollectionMemberAnnotationTable   NVARCHAR(128) = @TableNamePrefix + N'_CM_AN';  
    -- Create the Collection table (CN)  
    SET @SQL = @TruncationGuard + N'  
        CREATE TABLE mdm.' + QUOTENAME(@CollectionTable) + N'  
        (  
            --Identity  
             Version_ID          INT NOT NULL  
            ,ID                  INT IDENTITY(1, 1) NOT NULL  
            --Status  
            ,Status_ID           TINYINT NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @CollectionTable  + N'_Status_ID') + N' DEFAULT ' + CONVERT(NVARCHAR, @Status_Active) + N'  
            ,ValidationStatus_ID TINYINT NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @CollectionTable  + N'_ValidationStatus_ID') + N' DEFAULT 0  
  
            --Data  
            ,[Name]              NVARCHAR(250) NULL  
            ,Code                NVARCHAR(250) NOT NULL  
            ,[Description]       NVARCHAR(500) NULL  
            ,[Owner_ID]          INT NOT NULL  
  
            --Auditing  
            ,EnterDTM            DATETIME2(3) NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @CollectionTable  + N'_EnterDTM') + N' DEFAULT GETUTCDATE()  
            ,EnterUserID         INT NOT NULL  
            ,EnterVersionID      INT NOT NULL  
            ,LastChgDTM          DATETIME2(3) NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @CollectionTable  + N'_LastChgDTM') + N' DEFAULT GETUTCDATE()  
            ,LastChgUserID       INT NOT NULL  
            ,LastChgVersionID    INT NOT NULL  
            ,LastChgTS           ROWVERSION NOT NULL  
            ,AsOf_ID             INT NULL  
            ,MUID                UNIQUEIDENTIFIER NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @CollectionTable + N'_MUID') + N' DEFAULT NEWID()  
  
            --Create PRIMARY KEY constraint  
            ,CONSTRAINT ' + QUOTENAME(N'pk_' + @CollectionTable + N'') + N'  
                PRIMARY KEY CLUSTERED (Version_ID, ID)  
  
            --Create FOREIGN KEY constraints  
            ,CONSTRAINT ' + QUOTENAME(N'fk_' + @CollectionTable  + N'_tblUser_Owner_ID') + N'  
                FOREIGN KEY ([Owner_ID]) REFERENCES mdm.tblUser(ID)  
                ON UPDATE NO ACTION  
                ON DELETE NO ACTION  
  
            -- Note: the values of the Status_ID column should fall between 1 and 2. The ValidationStatus_ID column should be between 0 and 5. However,  
            -- we do not enforce this via db constraint because it would slow down table writes and only trusted MDS sproc code should be writing to those columns.  
        )  
        ' + @TableOptions + N';  
  
        --Ensure uniqueness of [Code] for active members.  
        CREATE UNIQUE NONCLUSTERED INDEX ' + QUOTENAME(N'ux_' + @CollectionTable + N'_Version_ID_Code_Active') + N'  
            ON mdm.' + QUOTENAME(@CollectionTable) + N'(Version_ID, Code)  
            WHERE Status_ID = ' + CONVERT(NVARCHAR, @Status_Active) + N'  
        ' + @IndexOptions + N';  
  
        --Index [Name] for performance  
        CREATE NONCLUSTERED INDEX ' + QUOTENAME(N'ix_' + @CollectionTable + N'_Version_ID_Name') + N'  
            ON mdm.' + QUOTENAME(@CollectionTable) + N'(Version_ID, Name)  
        ' + @IndexOptions + N';  
  
        --Ensure uniqueness of [MUID]  
        CREATE UNIQUE NONCLUSTERED INDEX ' + QUOTENAME(N'ux_' + @CollectionTable + N'_Version_ID_MUID') + N'  
            ON mdm.' + QUOTENAME(@CollectionTable) + N'(Version_ID, MUID)  
        ' + @IndexOptions + N';  
  
        CREATE NONCLUSTERED INDEX ' + QUOTENAME(N'ux_' + @CollectionTable + N'_Version_ID_Owner_ID') + N'  
            ON mdm.' + QUOTENAME(@CollectionTable) + N'(Version_ID, Owner_ID)  
        ' + @IndexOptions + N';  
  
        --Required for VersionCopy operations  
        CREATE NONCLUSTERED INDEX ' + QUOTENAME(N'ix_' + @CollectionTable  + N'_Version_ID_AsOf_ID_Status_ID') + N'  
            ON mdm.' + QUOTENAME(@CollectionTable) + N'(Version_ID, AsOf_ID, Status_ID)  
            INCLUDE ([ID])  
            WHERE [AsOf_ID] IS NOT NULL  
        ' + @IndexOptions + N';  
  
        --Create the History (_CN_HS) table  
        CREATE TABLE mdm.' + QUOTENAME(@CollectionHistoryTable) + N'  
        (  
            --Identity  
            Version_ID          INT NOT NULL,  
            ID                  BIGINT NOT NULL,  
  
            CN_ID               INT NOT NULL,  
  
            --Status  
            Status_ID           TINYINT NOT NULL,  
  
            --Data  
            [Name]              NVARCHAR(250) NULL,  
            Code                NVARCHAR(250) NOT NULL,  
            [Description]       NVARCHAR(500) NULL,  
            [Owner_ID]          INT NOT NULL,  
  
            --Auditing  
            EnterDTM            DATETIME2(3) NOT NULL,  
            EnterUserID         INT NOT NULL,  
            LastChgDTM          DATETIME2(3) NOT NULL,  
            LastChgUserID       INT NOT NULL,  
            MUID                UNIQUEIDENTIFIER NOT NULL,  
  
            --Create PRIMARY KEY constraint  
            CONSTRAINT ' + QUOTENAME(N'pk_' + @CollectionHistoryTable + N'') + N'  
                PRIMARY KEY CLUSTERED (Version_ID, ID)  
  
            --Cannot have foreign key (Version_ID, CN_ID) on CN table, because HS table is used in OUTPUT clause  
        )  
        ' + @TableOptions + N';  
  
        -- Required by udpEntityMemberHistoriesGet and type2 view  
        CREATE NONCLUSTERED INDEX ' + QUOTENAME(N'ix_' + @CollectionHistoryTable + N'_Version_ID_CN_ID') + N'  
            ON mdm.' + QUOTENAME(@CollectionHistoryTable) + N'(Version_ID, CN_ID, EnterDTM, LastChgDTM)  
            ' + @IndexOptions + N';  
  
        --Create the Annotation (_CN_AN) table  
        CREATE TABLE mdm.' + QUOTENAME(@CollectionAnnotationTable) + N'  
        (  
            Version_ID          INT NOT NULL,  
            ID                  INT IDENTITY(1, 1) NOT NULL,  
  
            Revision_ID         BIGINT NOT NULL,  
  
            [Comment]           [NVARCHAR](500) NULL,  
  
            --Auditing  
            EnterDTM            DATETIME2(3) NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @CollectionAnnotationTable  + N'_EnterDTM') + N' DEFAULT GETUTCDATE(),  
            EnterUserID         INT NOT NULL,  
            LastChgDTM          DATETIME2(3) NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @CollectionAnnotationTable  + N'_LastChgDTM') + N' DEFAULT GETUTCDATE(),  
            LastChgUserID       INT NOT NULL,  
            LastChgTS           ROWVERSION NOT NULL,  
  
            --Create PRIMARY KEY constraint  
            CONSTRAINT ' + QUOTENAME(N'pk_' + @CollectionAnnotationTable) + N'  
                PRIMARY KEY CLUSTERED (Version_ID, ID)  
        )  
        ' + @TableOptions + N';  
  
        -- Required for udpEntityMemberAnnotationsGet operations  
        CREATE NONCLUSTERED INDEX ' + QUOTENAME(N'ix_' + @CollectionAnnotationTable + N'_Version_ID_Revision_ID') + N'  
            ON mdm.' + QUOTENAME(@CollectionAnnotationTable) + N'(Version_ID, Revision_ID)  
            ' + @IndexOptions + N';  
        ';  
  
    --Execute the dynamic SQL  
    --PRINT(@SQL);  
    EXEC sp_executesql @SQL;  
  
  
    -- Create the Collection Member Table (CM)  
    SET @SQL = @TruncationGuard + N'  
        CREATE TABLE mdm.' + QUOTENAME(@CollectionMemberTable) + N'  
        (  
            --Identity  
             Version_ID          INT NOT NULL  
            ,ID                  INT IDENTITY(1, 1) NOT NULL  
  
            --Status  
            ,Status_ID           TINYINT NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @CollectionMemberTable  + N'_Status_ID') + N' DEFAULT ' + CONVERT(NVARCHAR, @Status_Active) + N'  
  
            --Pointers  
            ,Parent_CN_ID        INT NOT NULL --Always points to CN  
            ,ChildType_ID        TINYINT NOT NULL  
            ,Child_EN_ID         INT NULL --Used when the child is of type EN (ChildType_ID = 1)' +  
            CASE WHEN @IsHierarchyEnabled = 1 THEN N'  
            ,Child_HP_ID         INT NULL --Used when the child is of type HP (ChildType_ID = 2)' ELSE N'' END + N'  
            ,Child_CN_ID         INT NULL --Used when the child is of type CN (ChildType_ID = 3)  
  
            --Data  
            ,SortOrder           INT NOT NULL  
            ,Weight              DECIMAL(10,3) NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @CollectionMemberTable  + N'_Weight') + N' DEFAULT 1.0  
  
            --Auditing  
            ,EnterDTM            DATETIME2(3) NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @CollectionMemberTable  + N'_EnterDTM') + N' DEFAULT GETUTCDATE()  
            ,EnterUserID         INT NOT NULL  
            ,EnterVersionID      INT NOT NULL  
            ,LastChgDTM          DATETIME2(3) NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @CollectionMemberTable  + N'_LastChgDTM') + N' DEFAULT GETUTCDATE()  
            ,LastChgUserID       INT NOT NULL  
            ,LastChgVersionID    INT NOT NULL  
            ,LastChgTS           ROWVERSION NOT NULL  
            ,AsOf_ID             INT NULL  
            ,MUID                UNIQUEIDENTIFIER NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @CollectionMemberTable + N'_MUID') + N' DEFAULT NEWID()  
  
            --Create PRIMARY KEY constraint  
            CONSTRAINT ' + QUOTENAME(N'pk_' + @CollectionMemberTable + N'') + N'  
                PRIMARY KEY (Version_ID, ID)  
  
            --Create FOREIGN KEY constraints  
            ,CONSTRAINT ' + QUOTENAME(N'fk_' + @CollectionMemberTable + N'_' + @CollectionTable + N'_Parent_CN_ID') + N'  
                FOREIGN KEY (Version_ID, Parent_CN_ID) REFERENCES mdm.' + QUOTENAME(@CollectionTable) + N'(Version_ID, ID)  
                ON UPDATE NO ACTION  
                ON DELETE CASCADE  
            ,CONSTRAINT ' + QUOTENAME(N'fk_' + @CollectionMemberTable + N'_' + @EntityTable + N'_Child_EN_ID') + N'  
                FOREIGN KEY (Version_ID, Child_EN_ID) REFERENCES mdm.' + QUOTENAME(@EntityTable) + N'(Version_ID, ID)  
                ON UPDATE NO ACTION  
                ON DELETE CASCADE' +  
            CASE WHEN @IsHierarchyEnabled = 1 THEN N'  
            ,CONSTRAINT ' + QUOTENAME(N'fk_' + @CollectionMemberTable + N'_' + @HierarchyParentTable + N'_Child_HP_ID') + N'  
                FOREIGN KEY (Version_ID, Child_HP_ID) REFERENCES mdm.' + QUOTENAME(@HierarchyParentTable) + N'(Version_ID, ID)  
                ON UPDATE NO ACTION  
                ON DELETE CASCADE' ELSE N'' END + N'  
            ,CONSTRAINT ' + QUOTENAME(N'fk_' + @CollectionMemberTable + N'_' + @CollectionTable + N'_Child_CN_ID') + N'  
                FOREIGN KEY (Version_ID, Child_CN_ID) REFERENCES mdm.' + QUOTENAME(@CollectionTable) + N'(Version_ID, ID)  
                ON UPDATE NO ACTION  
                ON DELETE NO ACTION --Cannot use CASCADE due to chance of cycles  
  
            --Create CHECK constraints  
            ,CONSTRAINT ' + QUOTENAME(N'ck_' + @CollectionMemberTable + N'_ChildType_ID') + N'  
                CHECK (    (ChildType_ID = 1 AND Child_EN_ID IS NOT NULL' +  
            CASE WHEN @IsHierarchyEnabled = 1 THEN N' AND Child_HP_ID IS NULL' ELSE N'' END + N' AND Child_CN_ID IS NULL)' +  
            CASE WHEN @IsHierarchyEnabled = 1 THEN N'  
                        OR (ChildType_ID = 2 AND Child_HP_ID IS NOT NULL AND Child_EN_ID IS NULL AND Child_CN_ID IS NULL)' ELSE N'' END + N'  
                        OR (ChildType_ID = 3 AND Child_CN_ID IS NOT NULL AND Child_EN_ID IS NULL' +  
            CASE WHEN @IsHierarchyEnabled = 1 THEN N' AND Child_HP_ID IS NULL' ELSE N'' END + N'))  
            ,CONSTRAINT ' + QUOTENAME(N'ck_' + @CollectionMemberTable + N'_Parent_CN_ID_Child_CN_ID') + N'  
                CHECK (NOT (ChildType_ID = 3 AND Parent_CN_ID = Child_CN_ID)) --Prevent self-reference  
        )  
        ' + @TableOptions + N';  
  
        --Required for foreign key join performance  
        CREATE NONCLUSTERED INDEX ' + QUOTENAME(N'ix_' + @CollectionMemberTable + N'_Version_ID_Parent_CN_ID') + N'  
            ON mdm.' + QUOTENAME(@CollectionMemberTable) + N'(Version_ID, Parent_CN_ID)  
            ' + @IndexOptions + N';  
            --No filter on this index since Parent_CN_ID is NOT NULL' +  
            CASE WHEN @IsHierarchyEnabled = 1 THEN N'  
        CREATE NONCLUSTERED INDEX ' + QUOTENAME(N'ix_' + @CollectionMemberTable + N'_Version_ID_Child_HP_ID') + N'  
            ON mdm.' + QUOTENAME(@CollectionMemberTable) + N'(Version_ID, Child_HP_ID)  
            WHERE [Child_HP_ID] IS NOT NULL  
            ' + @IndexOptions + N';' ELSE N'' END + N'  
        CREATE NONCLUSTERED INDEX ' + QUOTENAME(N'ix_' + @CollectionMemberTable + N'_Version_ID_Child_CN_ID') + N'  
            ON mdm.' + QUOTENAME(@CollectionMemberTable) + N'(Version_ID, Child_CN_ID)  
            WHERE [Child_CN_ID] IS NOT NULL  
            ' + @IndexOptions + N';  
        CREATE NONCLUSTERED INDEX ' + QUOTENAME(N'ix_' + @CollectionMemberTable + N'_Version_ID_Child_EN_ID') + N'  
            ON mdm.' + QUOTENAME(@CollectionMemberTable) + N'(Version_ID, Child_EN_ID)  
            WHERE [Child_EN_ID] IS NOT NULL  
            ' + @IndexOptions + N';  
  
        --Create the HISTORY (_CM_HS) table  
        CREATE TABLE mdm.' + QUOTENAME(@CollectionMemberHistoryTable) + N'  
        (  
            --Identity  
            Version_ID          INT NOT NULL,  
            ID                  BIGINT NOT NULL,  
  
            CM_ID               INT NOT NULL,  
  
            --Status  
            Status_ID           TINYINT NOT NULL,  
  
            --Pointers  
            Parent_CN_ID        INT NOT NULL, --Always points to CN  
            ChildType_ID        TINYINT NOT NULL,  
            Child_EN_ID         INT NULL, --Used when the child is of type EN (ChildType_ID = 1)' +  
            CASE WHEN @IsHierarchyEnabled = 1 THEN N'  
            Child_HP_ID         INT NULL, --Used when the child is of type HP (ChildType_ID = 2)' ELSE N'' END + N'  
            Child_CN_ID         INT NULL, --Used when the child is of type CN (ChildType_ID = 3)  
  
            --Data  
            SortOrder           INT NOT NULL,  
            Weight              DECIMAL(10,3) NOT NULL,  
  
            --Auditing  
            EnterDTM            DATETIME2(3) NOT NULL,  
            EnterUserID         INT NOT NULL,  
            LastChgDTM          DATETIME2(3) NOT NULL,  
            LastChgUserID       INT NOT NULL,  
            MUID                UNIQUEIDENTIFIER NOT NULL,  
  
            --Create PRIMARY KEY constraint  
            CONSTRAINT ' + QUOTENAME(N'pk_' + @CollectionMemberHistoryTable + N'') + N'  
                PRIMARY KEY CLUSTERED (Version_ID, ID)  
  
            --Cannot have foreign key (Version_ID, CM_ID) on CM table, because HS table is used in OUTPUT clause  
        )  
        ' + @TableOptions + N';  
  
        --Required for udpEntityMemberHistoriesGet operations  
        CREATE NONCLUSTERED INDEX ' + QUOTENAME(N'ix_' + @CollectionMemberHistoryTable + N'_Version_ID_CM_ID') + N'  
            ON mdm.' + QUOTENAME(@CollectionMemberHistoryTable) + N'(Version_ID, CM_ID)  
            ' + @IndexOptions + N';  
  
        --Create the Annotation (_CM_AN) table  
        CREATE TABLE mdm.' + QUOTENAME(@CollectionMemberAnnotationTable) + N'  
        (  
            Version_ID          INT NOT NULL,  
            ID                  INT IDENTITY(1, 1) NOT NULL,  
  
            Revision_ID         BIGINT NOT NULL,  
  
            [Comment]           [NVARCHAR](500) NULL,  
  
            --Auditing  
            EnterDTM            DATETIME2(3) NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @CollectionMemberAnnotationTable  + N'_EnterDTM') + N' DEFAULT GETUTCDATE(),  
            EnterUserID         INT NOT NULL,  
            LastChgDTM          DATETIME2(3) NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @CollectionMemberAnnotationTable  + N'_LastChgDTM') + N' DEFAULT GETUTCDATE(),  
            LastChgUserID       INT NOT NULL,  
            LastChgTS           ROWVERSION NOT NULL,  
  
            --Create PRIMARY KEY constraint  
            CONSTRAINT ' + QUOTENAME(N'pk_' + @CollectionMemberAnnotationTable) + N'  
                PRIMARY KEY CLUSTERED (Version_ID, ID)  
        )  
        ' + @TableOptions + N';  
  
        --Required for udpEntityMemberAnnotationsGet operations  
        CREATE NONCLUSTERED INDEX ' + QUOTENAME(N'ix_' + @CollectionMemberAnnotationTable + N'_Version_ID_Revision_ID') + N'  
            ON mdm.' + QUOTENAME(@CollectionMemberAnnotationTable) + N'(Version_ID, Revision_ID)  
            ' + @IndexOptions + N';  
        ';  
  
    --Execute the dynamic SQL  
    --PRINT(@SQL);  
    EXEC sp_executesql @SQL;  
  
    -- Update the entity table with the new collection table names  
    UPDATE mdm.tblEntity  
    SET  CollectionTable = @CollectionTable  
        ,CollectionMemberTable = @CollectionMemberTable  
        ,LastChgDTM = GETUTCDATE()  
        ,LastChgUserID = @User_ID  
    WHERE ID = @Entity_ID;  
  
    -- Add system attributes for collection tables.  
  
    --Collection (CN)  
    INSERT INTO mdm.tblAttribute (Entity_ID,SortOrder,DomainEntity_ID,AttributeType_ID,MemberType_ID,IsSystem,IsReadOnly,IsCode,IsName,[Name],DisplayName,TableColumn,DisplayWidth,DataType_ID,DataTypeInformation,InputMask_ID,EnterUserID,EnterVersionID,LastChgUserID,LastChgVersionID)  
    VALUES  
     (@Entity_ID,1,NULL,3,3,1,1,0,0,N'ID',N'ID',N'ID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID,2,NULL,3,3,1,1,0,0,N'Version_ID',N'Version_ID',N'Version_ID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID,4,NULL,3,3,1,1,0,0,N'Status_ID',N'Status_ID',N'Status_ID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID,5,NULL,3,3,1,1,0,0,N'ValidationStatus_ID',N'ValidationStatus_ID',N'ValidationStatus_ID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID,6,NULL,3,3,1,1,0,0,N'EnterDTM',N'EnterDTM',N'EnterDTM',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID,7,NULL,3,3,1,1,0,0,N'EnterUserID',N'EnterUserID',N'EnterUserID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID,8,NULL,3,3,1,1,0,0,N'EnterVersionID',N'EnterVersionID',N'EnterVersionID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID,9,NULL,3,3,1,1,0,0,N'LastChgDTM',N'LastChgDTM',N'LastChgDTM',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID,10,NULL,3,3,1,1,0,0,N'LastChgUserID',N'LastChgUserID',N'LastChgUserID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID,11,NULL,3,3,1,1,0,0,N'LastChgVersionID',N'LastChgVersionID',N'LastChgVersionID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID,12,NULL,3,3,1,1,0,0,N'LastChgTS',N'LastChgTS',N'LastChgTS',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID,13,NULL,1,3,1,0,0,1,N'Name',N'Name',N'Name',250,1,250,1,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID,14,NULL,1,3,1,0,1,0,N'Code',N'Code',N'Code',250,1,250,1,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID,15,NULL,1,3,1,0,0,0,N'Description',N'Description',N'Description',225,1,100,1,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID,16,NULL,1,3,1,0,0,0,N'Owner_ID',N'Owner_ID',N'Owner_ID',100,1,100,1,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID,17,NULL,3,3,1,1,0,0,N'MUID',N'MUID',N'MUID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID,18,NULL,3,3,1,1,0,0,N'AsOf_ID',N'AsOf_ID',N'AsOf_ID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ;  
  
    --CollectionMember (CM)  
    INSERT INTO mdm.tblAttribute (Entity_ID,SortOrder,DomainEntity_ID,AttributeType_ID,MemberType_ID,IsSystem,IsReadOnly,[Name],DisplayName,TableColumn,DisplayWidth,DataType_ID,DataTypeInformation,InputMask_ID,EnterUserID,EnterVersionID,LastChgUserID,LastChgVersionID)  
    VALUES  
     (@Entity_ID, 1,NULL,3,5,1,1,N'ID',N'ID',N'ID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID, 2,NULL,3,5,1,1,N'Version_ID',N'Version_ID',N'Version_ID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID, 3,NULL,3,5,1,1,N'Status_ID',N'Status_ID',N'Status_ID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID, 5,NULL,3,5,1,1,N'EnterDTM',N'EnterDTM',N'EnterDTM',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID, 6,NULL,3,5,1,1,N'EnterUserID',N'EnterUserID',N'EnterUserID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID, 7,NULL,3,5,1,1,N'EnterVersionID',N'EnterVersionID',N'EnterVersionID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID, 8,NULL,3,5,1,1,N'LastChgDTM',N'LastChgDTM',N'LastChgDTM',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID, 9,NULL,3,5,1,1,N'LastChgUserID',N'LastChgUserID',N'LastChgUserID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID, 10,NULL,3,5,1,1,N'LastChgVersionID',N'LastChgVersionID',N'LastChgVersionID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID, 11,NULL,3,5,1,1,N'LastChgTS',N'LastChgTS',N'LastChgTS',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID, 13, NULL,3,5,1,1,N'Parent_CN_ID',N'Parent_CN_ID',N'Parent_CN_ID',0,1,100,1,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID, 14, NULL,3,5,1,1,N'Child_EN_ID',N'Child_EN_ID',N'Child_EN_ID',0,1,100,1,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID, 15, NULL,3,5,1,1,N'Child_HP_ID',N'Child_HP_ID',N'Child_HP_ID',0,1,100,1,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID, 16, NULL,3,5,1,1,N'Child_CN_ID',N'Child_CN_ID',N'Child_CN_ID',0,1,100,1,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID, 17, NULL,3,5,1,1,N'ChildType_ID',N'ChildType_ID',N'ChildType_ID',0,1,100,1,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID, 18, NULL,3,5,1,1,N'SortOrder',N'SortOrder',N'SortOrder',0,1,100,1,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID, 19, NULL,1,5,1,0,N'Weight',N'Weight',N'Weight',50,1,100,1,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID, 20,NULL,3,5,1,1,N'MUID',N'MUID',N'MUID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ,(@Entity_ID, 21,NULL,3,5,1,1,N'AsOf_ID',N'AsOf_ID',N'AsOf_ID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
    ;  
  
    EXEC mdm.udpCreateSystemViews @Model_ID, @Entity_ID  
  
    -- Recreate the staging sprocs, because they reference the collection table to check for code uniqueness.  
    EXEC mdm.udpEntityStagingCreateLeafStoredProcedure @Entity_ID;  
    IF @IsHierarchyEnabled = 1  
    BEGIN  
        EXEC mdm.udpEntityStagingCreateConsolidatedStoredProcedure @Entity_ID;  
    END;  
END;
go

