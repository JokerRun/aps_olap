/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    EXEC mdm.udpCreateDerivedHierarchyParentChildView 1,1,1,'TEST';  
    EXEC mdm.udpCreateAllViews;  
*/  
CREATE PROCEDURE mdm.udpCreateDerivedHierarchyParentChildView  
(  
    @DerivedHierarchy_ID    INT,  
    @Version_ID             INT,  
    @VersionFlag_ID         INT = NULL,  
    @SubscriptionViewName   SYSNAME,  
    @CorrelationID          UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability    
)    
WITH EXECUTE AS 'mds_schema_user'    
AS BEGIN    
    SET NOCOUNT ON;  
  
    --Defer view generation if we are in the middle of an upgrade or demo-rebuild    
    IF APPLOCK_MODE(N'public', N'DeferViewGeneration', N'Session') = N'NoLock'  
    BEGIN  
    
        DECLARE   
             @Model_ID       INT  
            ,@ViewLookupName SYSNAME;  
  
        SELECT  
            @Model_ID = Model_ID,  
            @ViewLookupName = CONCAT(N'viw_SYSTEM_', Model_ID, N'_', ID, N'_PARENTCHILD_DERIVED')  
        FROM mdm.tblDerivedHierarchy  
        WHERE ID = @DerivedHierarchy_ID;  
    
        IF     @Model_ID IS NULL --Invalid @DerivedHierarchy_ID    
            OR (@Version_ID IS NOT NULL     AND NOT EXISTS(SELECT ID FROM mdm.tblModelVersion       WHERE ID = @Version_ID)) --Invalid @Version_ID  
            OR (@VersionFlag_ID IS NOT NULL AND NOT EXISTS(SELECT ID FROM mdm.tblModelVersionFlag   WHERE ID = @VersionFlag_ID)) --Invalid @VersionFlag_ID  
            OR NULLIF(@SubscriptionViewName, N'') IS NULL --Must enter @SubscriptionViewName  
        BEGIN    
            RAISERROR('MDSERR100010|The Parameters are not valid.', 16, 1);  
            RETURN;  
        END    
  
        IF NOT EXISTS(SELECT 1 FROM mdm.tblDerivedHierarchyDetail WHERE DerivedHierarchy_ID = @DerivedHierarchy_ID)   
        BEGIN  
            -- Hierarchy has no levels, so nothing to do  
            RETURN;  
        END  
    
        DECLARE @SQL NVARCHAR(MAX) = CONCAT(CASE WHEN EXISTS(SELECT 1 FROM sys.views WHERE [name] = @SubscriptionViewName AND [schema_id] = SCHEMA_ID('mdm'))   
            THEN N'ALTER'  
            ELSE N'CREATE' END,   
            N' VIEW mdm.', QUOTENAME(@SubscriptionViewName), N'  
    /*WITH ENCRYPTION*/  
    AS  
    SELECT  
        V.Name          AS VersionName,  
        V.Display_ID    AS VersionNumber,  
        V.ID            AS Version_ID,  
        DV.Name         AS VersionFlag,  
        (SELECT [Name]  
            FROM mdm.tblDerivedHierarchy  
            WHERE ID = ', @DerivedHierarchy_ID, N') AS [Hierarchy],  
        ChildType_ID,  
        Child_ID,  
        ChildCode,  
        ChildName,  
        E.ID         AS Child_Entity_ID,  
        E.Name       AS Child_EntityName,  
        ParentType_ID,  
        Parent_ID,  
        ParentCode,  
        ParentName,  
        Epar.ID     AS Parent_Entity_ID,  
        Epar.Name   AS Parent_EntityName  
    FROM mdm.', QUOTENAME(@ViewLookupName), N' AS T  
    INNER JOIN mdm.[tblModelVersion] AS V  
    ON      V.ID = T.Version_ID');  
  
        --Restrict by Version or Version Flag    
        IF (@Version_ID IS NOT NULL)  
        BEGIN     
            SET @SQL += CONCAT(N'  
        AND V.ID = ', @Version_ID);  
        END    
        ELSE IF (@VersionFlag_ID IS NOT NULL)   
        BEGIN    
            SET @SQL += CONCAT(N'  
        AND V.VersionFlag_ID = ', @VersionFlag_ID);  
        END  
  
        SET @SQL += N'  
    LEFT JOIN mdm.[tblModelVersionFlag] AS DV  
    ON DV.ID = V.VersionFlag_ID  
    INNER JOIN mdm.[tblEntity] E  
    ON T.Entity_ID = E.ID  
    LEFT JOIN mdm.[tblEntity] Epar  
    ON T.ParentEntity_ID = Epar.ID;';  
  
        --PRINT @SQL;  
        EXEC sp_executesql @SQL;  
  
    END; --if  
  
    SET NOCOUNT OFF;  
END; --proc
go

