/*    
	SELECT * FROM mdm.viw_SYSTEM_SCHEMA_INDEXES    
*/    
/*    
==============================================================================    
 Copyright (c) Microsoft Corporation. All Rights Reserved.    
==============================================================================    
*/    
CREATE VIEW [mdm].[viw_SYSTEM_SCHEMA_INDEXES]    
/*WITH SCHEMABINDING*/    
AS    
SELECT    
    tEnt.Model_ID       Model_ID,     
    tMod.MUID           Model_MUID,     
    tMod.Name           Model_Name,      
    tInd.Entity_ID      Entity_ID,    
    tEnt.MUID           Entity_MUID,    
    tEnt.Name           Entity_Name,    
    tInd.ID             Index_ID,     
    tInd.MUID           Index_MUID,     
    tInd.Name           Index_Name,  
    tInd.SysIndex_ID    SysIndex_ID,    
    tInd.IsUnique       Index_IsUnique,       
    --    
    COALESCE(tInd.EnterUserID, 0) EnteredUser_ID,    
    COALESCE(usrE.MUID, CAST(0x0 AS UNIQUEIDENTIFIER)) EnteredUser_MUID,    
    usrE.UserName EnteredUser_UserName,    
    tInd.EnterDTM EnteredUser_DTM,    
    COALESCE(tInd.LastChgUserID, 0) LastChgUser_ID,    
    COALESCE(usrL.MUID, CAST(0x0 AS UNIQUEIDENTIFIER)) LastChgUser_MUID,    
    usrL.UserName LastChgUser_UserName,    
    tInd.LastChgDTM LastChgUser_DTM    
FROM    
    mdm.tblIndex tInd  
    INNER JOIN mdm.tblEntity tEnt ON tEnt.ID = tInd.Entity_ID    
    INNER JOIN mdm.tblModel tMod ON tMod.ID = tEnt.Model_ID    
    LEFT JOIN mdm.tblUser usrE ON tInd.EnterUserID = usrE.ID    
    LEFT JOIN mdm.tblUser usrL ON tInd.LastChgUserID = usrL.ID
go

