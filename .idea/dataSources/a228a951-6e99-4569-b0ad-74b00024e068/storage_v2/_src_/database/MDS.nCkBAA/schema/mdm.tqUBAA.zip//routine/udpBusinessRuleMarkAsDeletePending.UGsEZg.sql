/*  
exec mdm.udpBusinessRuleMarkAsDeletePending @MUID  
*/  
/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpBusinessRuleMarkAsDeletePending  
(  
    @User_ID       INT,  
    @MUID          UNIQUEIDENTIFIER,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    DECLARE  
        @GuidEmpty              UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER),  
        @ID                     INT,  
  
        @Permission_Admin       TINYINT = 5,  
  
        @Status_DeletePending   INT = 6;  
  
    SET @MUID = NULLIF(@MUID, @GuidEmpty);  
  
    SELECT @ID = br.ID  
    FROM mdm.tblBRBusinessRule br  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ENTITY se  
    ON br.Entity_ID = se.ID AND se.User_ID = @User_ID  
    WHERE @MUID IS NOT NULL  
        AND MUID = @MUID  
        AND se.Privilege_ID = @Permission_Admin  
  
    IF @ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR400005|The business rule MUID is not valid.', 16, 1);  
        RETURN;  
    END  
  
    -- Mark as Delete Pending  
    UPDATE tblBRBusinessRule  
    SET Status_ID = @Status_DeletePending   
    WHERE ID = @ID  
  
    SET NOCOUNT OFF  
END
go

