/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
-- Entity members sample  
-- Account/Account/Leaf  
DECLARE @p27 INT  
DECLARE @p28 mdm.MemberGetCriteria  
DECLARE @p29 mdm.Identifier  
EXEC mdm.udpEntityMembersGet @User_ID=1,@Version_Name=N'Version 4',@Model_Name=N'Product',@Entity_Name=N'Product', @MemberType_ID=1, @PageNumber=1,@PageSize=50,@SortColumn_MUID=NULL,@SortColumn_Name=NULL,@SortDirection=NULL,@MemberReturnOption=3,@MemberCount=@p27 output,@SearchTable=@p28,@AttributeTable=@p29  
SELECT @p27  
  
-- Account/Account/Leaf History  
DECLARE @p27 INT  
DECLARE @p28 mdm.MemberGetCriteria  
DECLARE @p29 mdm.Identifier  
EXEC mdm.udpEntityMembersGet @User_ID=1,@Version_Name=N'Version 4',@Model_Name=N'Product',@Entity_Name=N'Product', @MemberType_ID=1, @PageNumber=1,@PageSize=50,@SortColumn_MUID=NULL,@SortColumn_Name=NULL,@SortDirection=NULL,@MemberReturnOption=18,@MemberCount=@p27 output,@SearchTable=@p28,@AttributeTable=@p29  
SELECT @p27  
  
-- Entity members in Explicit Hierarchy Samples  
-- Product/Bundle/Root (Leaf)  
DECLARE @p27 INT  
DECLARE @p28 mdm.MemberGetCriteria  
DECLARE @p29 mdm.Identifier  
EXEC mdm.udpEntityMembersGet @User_ID=1,@Version_Name=N'Version 4',@Model_Name=N'Product',@Entity_Name=N'Product',@Hierarchy_Name=N'Bundle',@HierarchyType_ID=0,@ParentEntity_Name=N'Product',@MemberType_ID=1,@ParentCode=N'ROOT',@PageNumber=1,@PageSize=50,@SortColumn_MUID=NULL,@SortColumn_Name=NULL,@SortDirection=NULL,@MemberReturnOption=3,@MemberCount=@p27 output,@SearchTable=@p28,@AttributeTable=@p29  
SELECT @p27  
  
-- Product/Bundle/Root (Leaf) History  
DECLARE @p27 INT  
DECLARE @p28 mdm.MemberGetCriteria  
DECLARE @p29 mdm.Identifier  
EXEC mdm.udpEntityMembersGet @User_ID=1,@Version_Name=N'Version 4',@Model_Name=N'Product',@Entity_Name=N'Product',@Hierarchy_Name=N'Bundle',@HierarchyType_ID=0,@ParentEntity_Name=N'Product',@MemberType_ID=1,@ParentCode=N'ROOT',@PageNumber=1,@PageSize=50,@SortColumn_MUID=NULL,@SortColumn_Name=NULL,@SortDirection=NULL,@MemberReturnOption=18,@MemberCount=@p27 output,@SearchTable=@p28,@AttributeTable=@p29  
SELECT @p27  
  
-- Product/Bundle/Root (Consolidated)  
DECLARE @p27 INT  
DECLARE @p28 mdm.MemberGetCriteria  
DECLARE @p29 mdm.Identifier  
EXEC mdm.udpEntityMembersGet @User_ID=1,@Version_Name=N'Version 4',@Model_Name=N'Product',@Entity_Name=N'Product',@Hierarchy_Name=N'Bundle',@HierarchyType_ID=0,@ParentEntity_Name=N'Product',@MemberType_ID=1,@ParentCode=N'ROOT',@PageNumber=1,@PageSize=50,@SortColumn_MUID=NULL,@SortColumn_Name=NULL,@SortDirection=NULL,@MemberReturnOption=3,@MemberCount=@p27 output,@SearchTable=@p28,@AttributeTable=@p29  
SELECT @p27  
  
-- Product/Bundle/Root (Consolidated) History  
DECLARE @p27 INT  
DECLARE @p28 mdm.MemberGetCriteria  
DECLARE @p29 mdm.Identifier  
EXEC mdm.udpEntityMembersGet @User_ID=1,@Version_Name=N'Version 4',@Model_Name=N'Product',@Entity_Name=N'Product',@Hierarchy_Name=N'Bundle',@HierarchyType_ID=0,@ParentEntity_Name=N'Product',@MemberType_ID=1,@ParentCode=N'ROOT',@PageNumber=1,@PageSize=50,@SortColumn_MUID=NULL,@SortColumn_Name=NULL,@SortDirection=NULL,@MemberReturnOption=18,@MemberCount=@p27 output,@SearchTable=@p28,@AttributeTable=@p29  
SELECT @p27  
  
-- Product/Bundle/Root/Bundle10 (Leaf)  
DECLARE @p27 INT  
DECLARE @p28 mdm.MemberGetCriteria  
DECLARE @p29 mdm.Identifier  
EXEC mdm.udpEntityMembersGet @User_ID=1,@Version_Name=N'Version 4',@Model_Name=N'Product',@Entity_Name=N'Product',@Hierarchy_Name=N'Bundle',@HierarchyType_ID=0,@ParentEntity_Name=N'Product',@MemberType_ID=1,@ParentCode=N'BUNDLE10',@PageNumber=1,@PageSize=50,@SortColumn_MUID=NULL,@SortColumn_Name=NULL,@SortDirection=NULL,@MemberReturnOption=3,@MemberCount=@p27 output,@SearchTable=@p28,@AttributeTable=@p29  
SELECT @p27  
  
-- Product/Bundle/Root/Bundle10 (Leaf) History  
DECLARE @p27 INT  
DECLARE @p28 mdm.MemberGetCriteria  
DECLARE @p29 mdm.Identifier  
EXEC mdm.udpEntityMembersGet @User_ID=1,@Version_Name=N'Version 4',@Model_Name=N'Product',@Entity_Name=N'Product',@Hierarchy_Name=N'Bundle',@HierarchyType_ID=0,@ParentEntity_Name=N'Product',@MemberType_ID=1,@ParentCode=N'BUNDLE10',@PageNumber=1,@PageSize=50,@SortColumn_MUID=NULL,@SortColumn_Name=NULL,@SortDirection=NULL,@MemberReturnOption=18,@MemberCount=@p27 output,@SearchTable=@p28,@AttributeTable=@p29  
SELECT @p27  
  
-- Product/Bundle/Root/Bundle10 (Consolidated)  
DECLARE @p27 INT  
DECLARE @p28 mdm.MemberGetCriteria  
DECLARE @p29 mdm.Identifier  
EXEC mdm.udpEntityMembersGet @User_ID=1,@Version_Name=N'Version 4',@Model_Name=N'Product',@Entity_Name=N'Product',@Hierarchy_Name=N'Bundle',@HierarchyType_ID=0,@ParentEntity_Name=N'Product',@MemberType_ID=2,@ParentCode=N'BUNDLE10',@PageNumber=1,@PageSize=50,@SortColumn_MUID=NULL,@SortColumn_Name=NULL,@SortDirection=NULL,@MemberReturnOption=3,@MemberCount=@p27 output,@SearchTable=@p28,@AttributeTable=@p29  
SELECT @p27  
  
-- Product/Bundle/Root/Bundle10 (Consolidated) History  
DECLARE @p27 INT  
DECLARE @p28 mdm.MemberGetCriteria  
DECLARE @p29 mdm.Identifier  
EXEC mdm.udpEntityMembersGet @User_ID=1,@Version_Name=N'Version 4',@Model_Name=N'Product',@Entity_Name=N'Product',@Hierarchy_Name=N'Bundle',@HierarchyType_ID=0,@ParentEntity_Name=N'Product',@MemberType_ID=2,@ParentCode=N'BUNDLE10',@PageNumber=1,@PageSize=50,@SortColumn_MUID=NULL,@SortColumn_Name=NULL,@SortDirection=NULL,@MemberReturnOption=18,@MemberCount=@p27 output,@SearchTable=@p28,@AttributeTable=@p29  
SELECT @p27  
  
-- All Consolidate in Product/Bundle  
DECLARE @p27 INT  
DECLARE @p28 mdm.MemberGetCriteria  
DECLARE @p29 mdm.Identifier  
EXEC mdm.udpEntityMembersGet @User_ID=1,@Version_Name=N'Version 4',@Model_Name=N'Product',@Entity_Name=N'Product',@Hierarchy_Name=N'Bundle',@HierarchyType_ID=0,@ParentEntity_Name=N'Product',@MemberType_ID=2,@ParentCode=NULL,@PageNumber=1,@PageSize=50,@SortColumn_MUID=NULL,@SortColumn_Name=NULL,@SortDirection=NULL,@MemberReturnOption=3,@MemberCount=@p27 output,@SearchTable=@p28,@AttributeTable=@p29  
SELECT @p27  
  
-- All Consolidate in Product/Bundle History  
DECLARE @p27 INT  
DECLARE @p28 mdm.MemberGetCriteria  
DECLARE @p29 mdm.Identifier  
EXEC mdm.udpEntityMembersGet @User_ID=1,@Version_Name=N'Version 4',@Model_Name=N'Product',@Entity_Name=N'Product',@Hierarchy_Name=N'Bundle',@HierarchyType_ID=0,@ParentEntity_Name=N'Product',@MemberType_ID=2,@ParentCode=NULL,@PageNumber=1,@PageSize=50,@SortColumn_MUID=NULL,@SortColumn_Name=NULL,@SortDirection=NULL,@MemberReturnOption=18,@MemberCount=@p27 output,@SearchTable=@p28,@AttributeTable=@p29  
SELECT @p27  
  
-- Entity members in Derived Hierarchy Samples  
-- Product/Color/Unused  
DECLARE @p27 INT  
DECLARE @p28 mdm.MemberGetCriteria  
DECLARE @p29 mdm.Identifier  
EXEC mdm.udpEntityMembersGet @User_ID=1,@Version_Name=N'Version 4',@Model_Name=N'Product',@Entity_Name=N'Product',@Hierarchy_Name=N'Color',@HierarchyType_ID=1,@ParentEntity_Name=N'Color',@MemberType_ID=1,@ParentCode=N'MDMUNUSED',@PageNumber=1,@PageSize=50,@SortColumn_MUID=NULL,@SortColumn_Name=NULL,@SortDirection=NULL,@MemberReturnOption=3,@MemberCount=@p27 output,@SearchTable=@p28,@AttributeTable=@p29  
SELECT @p27  
  
-- Product/Color/Unused History  
DECLARE @p27 INT  
DECLARE @p28 mdm.MemberGetCriteria  
DECLARE @p29 mdm.Identifier  
EXEC mdm.udpEntityMembersGet @User_ID=1,@Version_Name=N'Version 4',@Model_Name=N'Product',@Entity_Name=N'Product',@Hierarchy_Name=N'Color',@HierarchyType_ID=1,@ParentEntity_Name=N'Color',@MemberType_ID=1,@ParentCode=N'MDMUNUSED',@PageNumber=1,@PageSize=50,@SortColumn_MUID=NULL,@SortColumn_Name=NULL,@SortDirection=NULL,@MemberReturnOption=18,@MemberCount=@p27 output,@SearchTable=@p28,@AttributeTable=@p29  
SELECT @p27  
  
-- Product/Color/White  
DECLARE @p27 INT  
DECLARE @p28 mdm.MemberGetCriteria  
DECLARE @p29 mdm.Identifier  
EXEC mdm.udpEntityMembersGet @User_ID=1,@Version_Name=N'Version 4',@Model_Name=N'Product',@Entity_Name=N'Product',@Hierarchy_Name=N'Color',@HierarchyType_ID=1,@ParentEntity_Name=N'Color',@MemberType_ID=1,@ParentCode=N'White',@PageNumber=1,@PageSize=50,@SortColumn_MUID=NULL,@SortColumn_Name=NULL,@SortDirection=NULL,@MemberReturnOption=3,@MemberCount=@p27 output,@SearchTable=@p28,@AttributeTable=@p29  
SELECT @p27  
  
-- Product/Color/White History  
DECLARE @p27 INT  
DECLARE @p28 mdm.MemberGetCriteria  
DECLARE @p29 mdm.Identifier  
EXEC mdm.udpEntityMembersGet @User_ID=1,@Version_Name=N'Version 4',@Model_Name=N'Product',@Entity_Name=N'Product',@Hierarchy_Name=N'Color',@HierarchyType_ID=1,@ParentEntity_Name=N'Color',@MemberType_ID=1,@ParentCode=N'White',@PageNumber=1,@PageSize=50,@SortColumn_MUID=NULL,@SortColumn_Name=NULL,@SortDirection=NULL,@MemberReturnOption=18,@MemberCount=@p27 output,@SearchTable=@p28,@AttributeTable=@p29  
SELECT @p27  
*/  
CREATE PROCEDURE mdm.udpEntityMembersGet  
(  
    @User_ID                INT,  
    @Model_MUID             UNIQUEIDENTIFIER = NULL,  
    @Model_Name             NVARCHAR(MAX) = NULL,  
    @Entity_MUID            UNIQUEIDENTIFIER = NULL,  
    @Entity_Name            NVARCHAR(MAX) = NULL,  
    @Version_MUID           UNIQUEIDENTIFIER = NULL,  
    @Version_Name           NVARCHAR(MAX) = NULL,  
    @MemberType_ID          TINYINT,  
    @Hierarchy_MUID         UNIQUEIDENTIFIER = NULL,  
    @Hierarchy_Name         NVARCHAR(MAX) = NULL,  
    @HierarchyType_ID       TINYINT = NULL,  
    @HierarchyLevelNumber   INT = NULL, -- viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED_LEVELS.LevelNumber (starts with zero at the top level)  
    @ParentEntity_MUID      UNIQUEIDENTIFIER = NULL,  
    @ParentEntity_Name      NVARCHAR(MAX) = NULL,  
    @ParentCode             NVARCHAR(250) = NULL,  
    @AttributeTable         mdm.Identifier READONLY,  
    @AttributeGroup_MUID    UNIQUEIDENTIFIER = NULL,  
    @AttributeGroup_Name    NVARCHAR(MAX) = NULL,  
    @SearchTable            mdm.MemberGetCriteria READONLY,  
    @PageNumber             INT = NULL,  
    @PageSize               INT = NULL OUTPUT,  
    @SortColumn_MUID        UNIQUEIDENTIFIER = NULL,  
    @SortColumn_Name        NVARCHAR(128) = NULL,  
    @SortDirection          NVARCHAR(4) = NULL,  
    @IncludeAuditInfo       BIT = 0,  
    @MemberReturnOption     TINYINT = 7, -- Data, counts & membership information  
    @MemberCount            INT = NULL OUTPUT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
    DECLARE @GuidEmpty                                  UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER),  
            @Model_ID                                   INT,  
            @Entity_ID                                  INT,  
            @Version_ID                                 INT,  
            @AttributeGroup_ID                          INT,  
            @Hierarchy_ID                               INT,  
            @HierarchyLevel_ID                          INT,  
            @ParentEntity_ID                            INT,  
            @ParentAttribute_ID                         INT,  
            @ParentAttribute_Name                       SYSNAME,  
            @Parent_ID                                  INT,  
            @ParentViewAlias                            SYSNAME = NULL,  
  
            @Unused_ID                                  INT = -1,  
            @Root_ID                                    INT = 0,  
  
            @UseMemberSecurity                          BIT = 0,  
            @IsDefaultOrder                             BIT = 0,  
            @IsCollectionEnabled                        BIT = 0,  
            @IsHierarchyEnabled                         BIT = 0,  
            @IsHistoricalData                           BIT = 0,  
            @IsHistoricalMembershipInformation          BIT = 0,  
  
            @SecurityTableName                          SYSNAME,  
            @HierarchyTable                             SYSNAME,  
            @MemberViewName                             SYSNAME,  
  
            @HierarchyType_Explicit                     TINYINT = 0,  
            @HierarchyType_Derived                      TINYINT = 1,  
  
            @MemberReturnOptionData                     TINYINT = 1,  
            @MemberReturnOptionCount                    TINYINT = 2,  
            @MemberReturnOptionMembershipInformation    TINYINT = 4,  
            @MemberReturnOptionDerivedHierarchyParents  TINYINT = 8,-- return the Parents member Id  
            @MemberReturnOptionHistoricalData           TINYINT = 16,  
            @MemberReturnOptionHistoricalMembershipInformation  TINYINT = 32,  
  
            @MemberType_NotSpecified                    TINYINT = 0,  
            @MemberType_Leaf                            TINYINT = 1,  
            @MemberType_Consolidated                    TINYINT = 2,  
            @MemberType_Collection                      TINYINT = 3,  
  
            @AttributeType_Domain                       TINYINT = 2,  
            @AttributeType_System                       TINYINT = 3,  
  
            @ForeignType_Entity                         TINYINT = 0,  
            @ForeignType_DBA                            TINYINT = 1,  
            @ForeignType_ManyToMany                     TINYINT = 5,  
  
            @MemberStatusActive                         TINYINT = 1,  
  
            @Model_Permission                           TINYINT,  
            @Entity_Permission                          TINYINT,  
            @MemberType_Permission                      TINYINT,  
            @Permission_Deny                            TINYINT = 1,  
            @Permission_Access                          TINYINT = 4,  
            @Permission_Admin                           TINYINT = 5,  
            @Permission_Inferred                        TINYINT = 99,  
  
            @MemberType_AccessPermission                TINYINT,  
            @AccessPermission_All                       TINYINT = 7,  
            @AccessPermission_Read                      TINYINT = 0,  
            @AccessPermission_Update                    TINYINT = 2,  
            @AccessPermission_Delete                    TINYINT = 4,  
            @AccessPermission_UpdateDelete              TINYINT = 6, -- 2+4  
  
            @VersionStatus                              TINYINT,  
            @VersionStatus_Locked                       TINYINT = 2,  
            @VersionStatus_Committed                    TINYINT = 3,  
  
            @SortColumn_TableName                       SYSNAME = NULL,  
            @ColumnString                               NVARCHAR(MAX) = NULL,  
            @MemberOrderBy                              NVARCHAR(MAX) = NULL,  
            @PagingTerm                                 NVARCHAR(MAX) = NULL,  
            @MemberFrom                                 NVARCHAR(MAX) = NULL,  
            @DerivedHierarchyParentJoin                 NVARCHAR(MAX) = NULL,  
            @MemberWhere                                NVARCHAR(MAX) = NULL,  
            @TruncateGuard                              NVARCHAR(MAX) = N'',  
            @SQL                                        NVARCHAR(MAX);  
  
    SELECT  
        @User_ID = NULLIF(@User_ID, 0),  
        @Model_MUID = NULLIF(@Model_MUID, @GuidEmpty),  
        @Model_Name = NULLIF(LTRIM(RTRIM(@Model_Name)), N''),  
        @Entity_MUID = NULLIF(@Entity_MUID, @GuidEmpty),  
        @Entity_Name = NULLIF(LTRIM(RTRIM(@Entity_Name)), N''),  
        @Version_MUID = NULLIF(@Version_MUID, @GuidEmpty),  
        @Version_Name = NULLIF(LTRIM(RTRIM(@Version_Name)), N''),  
        @AttributeGroup_MUID = NULLIF(@AttributeGroup_MUID, @GuidEmpty),  
        @AttributeGroup_Name = NULLIF(LTRIM(RTRIM(@AttributeGroup_Name)), N''),  
        @Hierarchy_MUID = NULLIF(@Hierarchy_MUID, @GuidEmpty),  
        @Hierarchy_Name = NULLIF(LTRIM(RTRIM(@Hierarchy_Name)), N''),  
        @ParentEntity_MUID = NULLIF(@ParentEntity_MUID, @GuidEmpty),  
        @ParentEntity_Name = NULLIF(LTRIM(RTRIM(@ParentEntity_Name)), N''),  
        @ParentCode = NULLIF(LTRIM(RTRIM(@ParentCode)), N''),  
        @SortColumn_MUID = NULLIF(@SortColumn_MUID, @GuidEmpty),  
        @SortColumn_Name = NULLIF(LTRIM(RTRIM(@SortColumn_Name)), N''),  
        @SortDirection = NULLIF(LTRIM(RTRIM(@SortDirection)), N''),  
        @IsHistoricalData = CASE WHEN @MemberReturnOption & @MemberReturnOptionHistoricalData <> 0 THEN 1 ELSE -0 END,  
        @IsHistoricalMembershipInformation = CASE WHEN @MemberReturnOption & @MemberReturnOptionHistoricalMembershipInformation <> 0 THEN 1 ELSE -0 END,  
        @MemberCount = NULL;  
  
    -- Validate parameters  
    IF @User_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR100009|The User ID is not valid.', 16, 1);  
        RETURN;  
    END  
  
    EXEC mdm.udpInformationLookupModel  
        @User_ID = @User_ID,  
        @Model_MUID = @Model_MUID,  
        @Model_Name = @Model_Name,  
        @ID = @Model_ID OUTPUT,  
        @Privilege_ID = @Model_Permission OUTPUT;  
    IF @Model_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300005|The supplied model is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    SELECT @Version_ID = ID, @VersionStatus = Status_ID  
    FROM mdm.tblModelVersion  
    WHERE  
            (@Version_MUID IS NOT NULL OR @Version_Name IS NOT NULL)  
        AND (@Version_MUID IS NULL OR MUID = @Version_MUID)  
        AND (@Version_Name IS NULL OR Name = @Version_Name)  
        AND Model_ID = @Model_ID;  
    IF @Version_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300006|The supplied version is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    EXEC mdm.udpInformationLookupEntity  
        @User_ID = @User_ID,  
        @Model_ID = @Model_ID,  
        @Entity_MUID = @Entity_MUID,  
        @Entity_Name = @Entity_Name,  
        @ID = @Entity_ID OUTPUT,  
        @Privilege_ID = @Entity_Permission OUTPUT,  
        @IsCollectionEnabled = @IsCollectionEnabled OUTPUT,  
        @IsHierarchyEnabled = @IsHierarchyEnabled OUTPUT;  
    IF @Entity_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300008|The supplied entity is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    SET @SecurityTableName =  
        CASE @MemberType_ID  
            WHEN @MemberType_Leaf THEN CONCAT(N'tbl_', @Model_ID, N'_', @Entity_ID ,N'_EN_MS')  
            WHEN @MemberType_Consolidated THEN CONCAT(N'tbl_', @Model_ID, N'_', @Entity_ID ,N'_HP_MS')  
        END;  
  
    SET @HierarchyTable = CONCAT(N'tbl_', @Model_ID, N'_', @Entity_ID ,N'_HR');  
  
    IF @IsHierarchyEnabled = 0 AND @MemberType_ID = @MemberType_Consolidated  
    BEGIN  
        RAISERROR('MDSERR300035|The member type is not supported by the entity.', 16, 1);  
        RETURN;  
    END  
  
    IF @IsCollectionEnabled = 0 AND @MemberType_ID =  @MemberType_Collection  
    BEGIN  
        -- No collections have been created yet, so return.  
        RETURN;  
    END;  
  
    SET @MemberType_ID = COALESCE(@MemberType_ID, @MemberType_NotSpecified);  
    IF @MemberType_ID NOT IN (@MemberType_Leaf, @MemberType_Consolidated, @MemberType_Collection)  
    BEGIN  
        RAISERROR('MDSERR100002|The Member Type is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    IF @ParentEntity_MUID IS NOT NULL OR @ParentEntity_Name IS NOT NULL  
    BEGIN  
        EXEC mdm.udpInformationLookupEntity  
            @User_ID = @User_ID,  
            @Model_ID = @Model_ID,  
            @Entity_MUID = @ParentEntity_MUID,  
            @Entity_Name = @ParentEntity_Name,  
            @ID = @ParentEntity_ID OUTPUT  
        IF @ParentEntity_ID IS NULL  
        BEGIN  
            RAISERROR(N'MDSERR300008|The supplied entity is not valid.', 16, 1);  
            RETURN;  
        END;  
    END  
  
    IF @Hierarchy_MUID IS NOT NULL OR @Hierarchy_Name IS NOT NULL  
    BEGIN  
  
        IF @HierarchyType_ID = @HierarchyType_Explicit  
        BEGIN  
            EXEC mdm.udpInformationLookupHierarchy  
                @User_ID = @User_ID,  
                @Entity_ID = @Entity_ID,  
                @Hierarchy_MUID = @Hierarchy_MUID,  
                @Hierarchy_Name = @Hierarchy_Name,  
                @ID = @Hierarchy_ID OUTPUT  
            IF @Hierarchy_ID IS NULL  
            BEGIN  
                RAISERROR(N'MDSERR300009|Explicit Hierarchy is Invalid', 16, 1);  
                RETURN;  
            END;  
        END  
        ELSE IF @HierarchyType_ID = @HierarchyType_Derived  
        BEGIN  
            EXEC mdm.udpInformationLookupDerivedHierarchy  
                @User_ID = @User_ID,  
                @Model_ID = @Model_ID,  
                @DerivedHierarchy_ID = @Hierarchy_ID,  
                @DerivedHierarchy_MUID = @Hierarchy_MUID,  
                @DerivedHierarchy_Name = @Hierarchy_Name,  
                @ID = @Hierarchy_ID OUTPUT  
            IF @Hierarchy_ID IS NULL  
            BEGIN  
                RAISERROR(N'MDSERR300007|DerivedHierarchy is Invalid', 16, 1);  
                RETURN;  
            END;  
        END  
    END  
  
    -- Check paging, sorting and search term.  
    SET @PageNumber = COALESCE(@PageNumber, 0);  
    SET @PageSize = COALESCE(@PageSize, (SELECT SettingValue FROM mdm.tblSystemSetting WHERE SettingName = CAST(N'RowsPerBatch' AS NVARCHAR(100))))  
    IF @PageNumber > 0 AND @PageSize > 0  
    BEGIN  
        SET @PagingTerm = N'  
OFFSET ((@PageNumber - 1) * @PageSize) ROWS  
FETCH NEXT @PageSize ROWS ONLY'  
    END  
  
    IF  @SortColumn_MUID IS NOT NULL OR @SortColumn_Name IS NOT NULL  
    BEGIN  
        EXEC mdm.udpInformationLookupAttribute  
            @User_ID = @User_ID,  
            @Entity_ID = @Entity_ID,  
            @Attribute_MUID = @SortColumn_MUID,  
            @Attribute_Name = @SortColumn_Name,  
            @Name = @SortColumn_TableName OUTPUT  
        IF @SortColumn_TableName IS NULL  
        BEGIN  
            IF  @SortColumn_MUID IS NOT NULL  
            BEGIN  
                RAISERROR(N'MDSERR300010|Attribute is Invalid', 16, 1);  
                RETURN;  
            END  
            ELSE  
            BEGIN  
                SET @SortColumn_TableName = @SortColumn_Name;  
            END  
        END;  
    END  
  
    EXEC mdm.udpResolveMemberGetCriteria @SearchTable, @MemberWhere OUTPUT, @MemberOrderBy OUTPUT;  
  
    IF @SortColumn_TableName IS NOT NULL  
    BEGIN  
        SET @MemberOrderBy = CONCAT(N'T.', QUOTENAME(@SortColumn_TableName), CASE WHEN UPPER(@SortDirection) = N'ASC' THEN N' ASC' ELSE N' DESC' END);  
    END  
  
    IF NULLIF(@MemberOrderBy, N'') IS NULL  
    BEGIN  
        SET @MemberOrderBy = CASE @IsHistoricalData WHEN 0 THEN N'T.ID ASC' ELSE N'T.HS_ID DESC' END;  
        SET @IsDefaultOrder = 1;  
    END  
  
    SET @MemberOrderBy = CONCAT(N'  
ORDER BY ', @MemberOrderBy);  
  
    -- Check member security.  
    IF @Entity_Permission = @Permission_Admin  
    BEGIN  
        SET @MemberType_Permission = @Permission_Access;  
        SET @MemberType_AccessPermission = @AccessPermission_All;  
    END  
    ELSE  
    BEGIN  
        SELECT @MemberType_Permission = Privilege_ID,  
            @MemberType_AccessPermission = AccessPermission  
        FROM mdm.viw_SYSTEM_SECURITY_USER_MEMBERTYPE  
        WHERE [User_ID] = @User_ID  
            AND [Entity_ID] = @Entity_ID  
            AND ID = @MemberType_ID;  
  
        SET @MemberType_Permission = COALESCE(@MemberType_Permission, @Permission_Deny);  
  
        -- In the case of Privilege_ID is inferred, should be INTerpreted as Access and ReadOnly  
        IF  @MemberType_Permission = @Permission_Inferred  
        BEGIN  
            SET @MemberType_Permission = @Permission_Access;  
            SET @MemberType_AccessPermission = @AccessPermission_Read;  
        END;  
  
        IF @MemberType_Permission = @Permission_Deny  
        BEGIN  
            RAISERROR(N'MDSERR120002|The user does not have permission to perform this operation.', 16, 1);  
            RETURN;  
        END;  
  
        -- Only leaf and consolidated has member security  
        IF @MemberType_ID IN (@MemberType_Leaf, @MemberType_Consolidated)  
        BEGIN  
            SET @UseMemberSecurity = mdm.udfUseMemberSecurity (@User_ID, @Entity_ID, @Version_ID, @MemberType_ID);  
        END  
    END;  
  
    -- Process attributes  
    DECLARE @AttributesWorkingSet TABLE  
    (  
        Name NVARCHAR(250) COLLATE DATABASE_DEFAULT PRIMARY KEY,  
        MUID UNIQUEIDENTIFIER,  
        ID INT NULL,  
        AttributeType_ID TINYINT NULL,  
        DataType_ID TINYINT NULL,  
        SortOrder INT,  
        AccessPermission TINYINT  
    );  
  
    IF (@AttributeGroup_MUID IS NOT NULL OR @AttributeGroup_Name IS NOT NULL)  
    BEGIN  
        EXEC mdm.udpInformationLookupAttributeGroup  
            @User_ID = @User_ID,  
            @Entity_ID = @Entity_ID,  
            @MemberType_ID = @MemberType_ID,  
            @AttributeGroup_MUID = @AttributeGroup_MUID,  
            @AttributeGroup_Name = @AttributeGroup_Name,  
            @ID = @AttributeGroup_ID OUTPUT;  
        IF @AttributeGroup_ID IS NULL  
        BEGIN  
            RAISERROR(N'MDSERR300011|Attribute Group is Invalid', 16, 1);  
            RETURN;  
        END;  
  
        INSERT INTO @AttributesWorkingSet  
        (  
            MUID  
            ,Name  
            ,ID  
            ,AttributeType_ID  
            ,DataType_ID  
            ,SortOrder  
            ,AccessPermission  
        )  
        SELECT  
            att.MUID  
            ,att.Name  
            ,att.ID  
            ,att.AttributeType_ID  
            ,att.DataType_ID  
            ,COALESCE(agDetail.SortOrder, att.SortOrder)  
            ,sec.AccessPermission  
        FROM mdm.tblAttribute att  
        INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ATTRIBUTE sec -- Only return AttributeType_ID <> @AttributeType_System  
        ON att.ID = sec.ID AND sec.User_ID = @User_ID AND att.Entity_ID = @Entity_ID AND att.MemberType_ID = @MemberType_ID  
        LEFT JOIN mdm.tblAttributeGroupDetail agDetail  
        ON agDetail.Attribute_ID = sec.ID AND agDetail.AttributeGroup_ID = @AttributeGroup_ID  
        WHERE agDetail.Attribute_ID IS NOT NULL OR att.IsSystem = 1  
    END  
    ELSE IF EXISTS (SELECT 1 FROM @AttributeTable)  
    BEGIN  
        INSERT INTO @AttributesWorkingSet  
        (  
            MUID  
            ,Name  
            ,ID  
            ,AttributeType_ID  
            ,DataType_ID  
            ,SortOrder  
            ,AccessPermission  
        )  
        SELECT  
            att.MUID  
            ,att.Name  
            ,att.ID  
            ,att.AttributeType_ID  
            ,att.DataType_ID  
            ,att.SortOrder  
            ,sec.AccessPermission  
        FROM mdm.tblAttribute att  
        INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ATTRIBUTE sec -- Only return AttributeType_ID <> @AttributeType_System  
        ON att.ID = sec.ID AND sec.User_ID = @User_ID AND att.Entity_ID = @Entity_ID AND att.MemberType_ID = @MemberType_ID  
        LEFT JOIN @AttributeTable at  
        ON (at.MUID IS NULL OR at.MUID = 0x0 OR at.MUID = att.MUID) AND (at.Name IS NULL OR at.Name = N'' OR at.Name = att.Name)  
        WHERE (at.MUID IS NOT NULL AND at.MUID != 0x0) OR (at.Name IS NOT NULL AND at.Name != N'') OR att.IsSystem = 1  
    END  
    ELSE  
    BEGIN  
        INSERT INTO @AttributesWorkingSet  
        (  
            MUID  
            ,Name  
            ,ID  
            ,AttributeType_ID  
            ,DataType_ID  
            ,SortOrder  
            ,AccessPermission  
        )  
        SELECT  
            att.MUID  
            ,att.Name  
            ,att.ID  
            ,att.AttributeType_ID  
            ,att.DataType_ID  
            ,att.SortOrder  
            ,sec.AccessPermission  
        FROM mdm.tblAttribute att  
        INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ATTRIBUTE sec -- Only return AttributeType_ID <> @AttributeType_System  
        ON att.ID = sec.ID AND sec.User_ID = @User_ID AND att.Entity_ID = @Entity_ID AND att.MemberType_ID = @MemberType_ID  
    END  
  
    SET @MemberType_AccessPermission = @MemberType_AccessPermission & @AccessPermission_UpdateDelete;  
  
    IF EXISTS(SELECT ID FROM @AttributesWorkingSet WHERE (AccessPermission & @AccessPermission_Update) = @AccessPermission_Update)  
    BEGIN  
        SET @MemberType_AccessPermission |= @AccessPermission_Update;  
    END  
    ELSE  
    BEGIN  
        SET @MemberType_AccessPermission &= @AccessPermission_Delete;  
    END;  
  
    -- If version status is committed or locked, the member is read-only.  
    IF (@VersionStatus = @VersionStatus_Committed) OR (@VersionStatus = @VersionStatus_Locked AND @Model_Permission != @Permission_Admin)  
    BEGIN  
        SET @MemberType_AccessPermission = @AccessPermission_Read;  
    END  
  
    SET @ColumnString = CONCAT(@TruncateGuard, N'  
     T.ID  
    ,T.Code  
    ,T.Name  
    ,T.MUID  
    ');  
  
    SET @ColumnString = CONCAT(@ColumnString,  
        CASE @IsHistoricalData  
            WHEN 0 THEN N'  
    ,T.ValidationStatus_ID  
    ,CONVERT(BIGINT, T.LastChgTS) AS LastChgTS'  
            ELSE N'  
    ,T.HS_ID  
    ,T.Status_ID  
    ,T.LastChgTS AS LastChgTS'  
            END);  
  
    SET @ColumnString = CONCAT(@ColumnString,  
        CASE @IncludeAuditInfo  
            WHEN 1 THEN N'  
    ,T.EnterDTM  
    ,T.EnterUserName  
    ,T.LastChgDTM  
    ,T.LastChgUserName'  
        END);  
  
    SELECT  
        @ColumnString +=  
            CASE AttributeType_ID  
                WHEN @AttributeType_Domain THEN CONCAT(N'  
    ,', QUOTENAME(Name), N'  
    ,', QUOTENAME(Name + N'.Name'), N'  
    ,', QUOTENAME(Name + N'.MUID'), N'  
    ,', QUOTENAME(Name + N'.ID'))  
                ELSE CONCAT(N'  
    ,', QUOTENAME(Name), N'')  
            END  
        FROM @AttributesWorkingSet  
        WHERE Name <> N'Code'  
            AND Name <> N'Name'  
  
    SET @ColumnString = CONCAT(@ColumnString, N'  
    ,@MemberType_Permission AS Privilege_ID  
    ,', CASE WHEN @UseMemberSecurity = 0 OR @IsHistoricalData = 1  
        THEN N'@MemberType_AccessPermission'   
        ELSE N'CONVERT(TINYINT, id.AccessPermission & @MemberType_AccessPermission)' END,   
        N' AS AccessPermission')  
  
    SET @MemberViewName = mdm.udfViewNameGet(@Model_ID, @Entity_ID, @MemberType_ID, 0, CASE @IsHistoricalData WHEN 0 THEN 0 ELSE 2 END);  
  
    SET @MemberFrom = CONCAT(@TruncateGuard, N'  
FROM mdm.', QUOTENAME(@MemberViewName), N' T', CASE WHEN @UseMemberSecurity = 1 THEN CONCAT(N'  
INNER JOIN mdm.', QUOTENAME(@SecurityTableName), N' ms  
ON      T.Version_ID = ms.Version_ID  
    AND T.ID = ms.ID  
    AND ms.User_ID = @User_ID') END)  
  
    SET @MemberWhere = CONCAT(N'  
WHERE   ', @MemberWhere, CASE WHEN @MemberWhere IS NOT NULL THEN N'  
    AND ' END, N'T.Version_ID = @Version_ID');  
  
    IF @ParentCode IS NULL OR @ParentCode  = N'MDMNULL'  
    BEGIN  
        SET @Parent_ID = NULL;  
    END  
    ELSE IF UPPER(@ParentCode) = N'MDMUNUSED'  
    BEGIN  
        SET @Parent_ID = @Unused_ID;  
    END  
    ELSE IF UPPER(@ParentCode) = N'ROOT'  
    BEGIN  
        SET @Parent_ID = @Root_ID;  
    END   
    ELSE IF @Hierarchy_ID IS NOT NULL  
    BEGIN  
        -- Lookup @Parent_ID from @ParentCode  
        SET @SQL = CONCAT(@TruncateGuard, N'  
            SELECT TOP 1 @Parent_ID = ID  
            FROM mdm.', QUOTENAME(CONCAT(N'tbl_', @Model_ID, N'_',  
                CASE @HierarchyType_ID  
                    WHEN @HierarchyType_Derived THEN CONCAT(@ParentEntity_ID, N'_EN')  
                    ELSE                             CONCAT(@Entity_ID,       N'_HP')  
                    END)), N'   
            WHERE   Version_ID = @Version_ID   
                AND Code = @ParentCode  
                AND Status_ID = ', @MemberStatusActive, N'; -- ignore soft-deleted members');  
        EXEC sp_executesql @SQL, N'@ParentCode NVARCHAR(250), @Version_ID INT, @Parent_ID INT OUTPUT', @ParentCode, @Version_ID, @Parent_ID OUTPUT;  
  
        IF @Parent_ID IS NULL  
        BEGIN  
            RAISERROR('MDSERR100025|Either the parent code or the parent type is not valid.', 16, 1);  
            RETURN;  
        END  
    END  
  
    IF @Hierarchy_ID IS NOT NULL  
    BEGIN  
        --Derived Hierarchy  
        IF @HierarchyType_ID = @HierarchyType_Derived  
        BEGIN  
            -- Determine if it is a recursive hierarchy that anchors null recursions.  
            DECLARE @IsRecursiveAndAnchorsNullRecursions BIT = COALESCE(  
               (SELECT TOP 1 tDH.AnchorNullRecursions  
                FROM mdm.tblDerivedHierarchy tDH  
                LEFT JOIN mdm.viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED_LEVELS tDHL  
                ON tDHL.Hierarchy_ID = tDH.ID  
                WHERE   tDH.ID = @Hierarchy_ID  
                    AND tDHL.IsRecursive = 1  
                    AND tDHL.LevelNumber = 0)-- only look at top recursive level  
                , 0);  
  
            DECLARE @RootEntity_ID INT = 0;  
            IF @IsRecursiveAndAnchorsNullRecursions = 0 AND COALESCE(@Parent_ID, @Root_ID) = @Root_ID -- Find Entity for the root of the Derived Hierarchy  
            BEGIN  
                SELECT TOP 1  
                    @RootEntity_ID = Entity_ID  
                FROM mdm.viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED_LEVELS  
                WHERE   Hierarchy_ID = @Hierarchy_ID  
                    AND LevelNumber = 0 -- topmost level  
            END  
  
            IF @RootEntity_ID != @Entity_ID  
            BEGIN  
                -- We are looking for the foreign ID of the Derived Hierarchy. In the normal case there should be only one returned that match the hierarchy ID  
                -- and is of type DBA. If there is a hidden level, the tblAttribute.Entity_ID will NOT be the same as the given entity. But, as we only get back one result it is correct  
                -- But, in the case of a recursive hierarchy that has level(s) beneath the recursive levels, there will be more than 1 returned result. We only want to filter out the one that has the same entity ID in the attribute  
                -- We solve this by sorting by the equality of attribute.Entity_ID to the given entity ID. if there is only one result, it doesn't matter. For multiple results we will  
                -- always get back first the one that has the ID we are looking for and choose it using a TOP 1.  
                  
                IF (@HierarchyLevelNumber IS NULL)  
                BEGIN  
                    SELECT TOP 1  
                         @ParentAttribute_ID = dhd.Foreign_ID  
                        ,@HierarchyLevel_ID = dhd.Level_ID  
                    FROM mdm.tblDerivedHierarchyDetail dhd  
                    INNER JOIN mdm.tblAttribute a  
                    ON      dhd.Foreign_ID = a.ID  
                        AND dhd.ForeignType_ID IN (@ForeignType_DBA, @ForeignType_ManyToMany)  
                    WHERE   dhd.DerivedHierarchy_ID = @Hierarchy_ID  
                        AND a.DomainEntity_ID = @ParentEntity_ID  
                    ORDER BY (CASE WHEN a.Entity_ID = @Entity_ID THEN 0 ELSE dhd.Level_ID END)  ASC  
                END ELSE  
                BEGIN  
                    IF (@HierarchyLevelNumber = 0)  
                    BEGIN  
                        -- Top-level of hierarchy  
                        SELECT TOP 1  
                             @ParentAttribute_ID = CASE WHEN dhd.IsRecursive = 1 THEN Foreign_ID END  
                            ,@HierarchyLevel_ID = Level_ID  
                        FROM mdm.viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED_LEVELS dhd  
                        WHERE   dhd.Hierarchy_ID = @Hierarchy_ID  
                            AND dhd.ForeignType_ID IN (@ForeignType_DBA, @ForeignType_ManyToMany)  
                            AND dhd.LevelNumber = 0  
                    END ELSE   
                    BEGIN  
                        -- Below the top level of hierarchy  
                        DECLARE @ParentLevel_ID INT;  
                        SELECT TOP 1  
                             @ParentAttribute_ID = Foreign_ID -- The Attribute_ID is the Foreign_ID of the level above the specified level  
                            ,@ParentLevel_ID = Level_ID  
                        FROM mdm.viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED_LEVELS dhd  
                        WHERE   dhd.Hierarchy_ID = @Hierarchy_ID  
                            AND dhd.ForeignType_ID IN (@ForeignType_DBA, @ForeignType_ManyToMany)  
                            AND dhd.LevelNumber < @HierarchyLevelNumber -- Get the nearest matching parent level (may skip levels if the immediate parent is not visible)  
                            AND dhd.IsLevelVisible = 1  
                            AND dhd.Entity_ID = @ParentEntity_ID  
                        ORDER BY dhd.Level_ID  
  
                        SET @HierarchyLevel_ID = @ParentLevel_ID - 1;  
                    END  
                END  
  
                DECLARE  
                    @CurrentLevel_ID                        INT,  
                    @PriorLevel_ID                          INT,  
                    @PriorLevelForeignType_ID               TINYINT,  
                    @PriorLevelManyToManyChildAttribute_ID  INT;  
  
                --Fetch the attribute DBA column name  
                SELECT  
                    @ParentAttribute_Name = [Name]  
                FROM mdm.tblAttribute WHERE ID = @ParentAttribute_ID;  
  
                --Check to see if any levels were skipped; if so, create the proper join string------------  
                --Fetch the prior level  
                SELECT TOP 1  
                     @PriorLevel_ID = Level_ID  
                    ,@PriorLevelForeignType_ID = ForeignType_ID  
                    ,@PriorLevelManyToManyChildAttribute_ID = ManyToManyChildAttribute_ID  
                FROM mdm.tblDerivedHierarchyDetail  
                WHERE   DerivedHierarchy_ID = @Hierarchy_ID  
                    AND Foreign_ID = @ParentAttribute_ID  
                    AND ForeignType_ID IN (@ForeignType_DBA, @ForeignType_ManyToMany)  
                    AND (@HierarchyLevel_ID IS NULL OR Level_ID > @HierarchyLevel_ID)  
                ORDER BY Level_ID DESC;  
  
                --Fetch the current level  
                SELECT TOP 1 @CurrentLevel_ID = Level_ID  
                FROM mdm.tblDerivedHierarchyDetail  
                WHERE   DerivedHierarchy_ID = @Hierarchy_ID  
                    AND Level_ID < @PriorLevel_ID  
                    AND IsVisible = 1  
                ORDER BY Level_ID DESC;  
  
                --Fetch the list of tables to join (if skipping levels)  
                DECLARE @SkippedLevel TABLE  
                (  
                     Level_ID                       INT PRIMARY KEY  
                    ,ForeignType_ID                 TINYINT NOT NULL  
                    ,AttributeName                  SYSNAME NOT NULL -- Name of Foreign_ID  
                    ,EntityViewName                 SYSNAME NOT NULL  
                    ,DomainEntityViewName           SYSNAME NOT NULL  
                    ,ManyToManyChildAttribute_Name  SYSNAME NULL  
                );  
                INSERT INTO @SkippedLevel  
                SELECT  
                     l.Level_ID  
                    ,l.ForeignType_ID  
                    ,l.Foreign_Name AS AttributeName  
                    ,mdm.udfViewNameGetByID(  
                        CASE l.ForeignType_ID  
                        WHEN @ForeignType_ManyToMany THEN a.Entity_ID -- Use the mapping table for M2M levels  
                        ELSE l.Entity_ID END  
                        , @MemberType_Leaf, 0, 0) AS EntityViewName  
                    ,mdm.udfViewNameGetByID(a.DomainEntity_ID, @MemberType_Leaf, 0, 0) AS DomainEntityViewName  
                    ,l.ManyToManyChildAttribute_Name  
                FROM mdm.viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED_LEVELS l  
                LEFT JOIN mdm.tblAttribute a  
                ON      l.Foreign_ID = a.ID  
                    AND l.ForeignType_ID IN (@ForeignType_DBA, @ForeignType_ManyToMany)  
                WHERE   l.Hierarchy_ID = @Hierarchy_ID  
                    AND l.Level_ID > @CurrentLevel_ID  
                    AND l.Level_ID < @PriorLevel_ID ;  
  
                DECLARE  
                    @TempLevel_ID                   INT,  
                    @TempForeignType_ID             TINYINT,  
                    @TempEntityViewName             SYSNAME = NULL,  
                    @TempDomainEntityViewName       SYSNAME = NULL,  
                    @TempViewAlias                  SYSNAME = NULL,  
                    @TempPriorViewAlias             SYSNAME = N'T',  
                    @TempAttributeName              SYSNAME,  
                    @ManyToManyChildAttributeName   SYSNAME  
                     ;  
  
                WHILE EXISTS(SELECT 1 FROM @SkippedLevel)  
                BEGIN  
                    SELECT TOP 1  
                        @TempLevel_ID                   = Level_ID,  
                        @TempForeignType_ID             = ForeignType_ID,  
                        @TempAttributeName              = AttributeName,  
                        @TempEntityViewName             = EntityViewName,  
                        @TempDomainEntityViewName       = DomainEntityViewName,  
                        @ManyToManyChildAttributeName   = ManyToManyChildAttribute_Name  
                    FROM @SkippedLevel  
                    ORDER BY Level_ID ASC;  
  
                    IF (@TempForeignType_ID = @ForeignType_ManyToMany)  
                    BEGIN  
                        -- Join with the mapping table  
                        SET @TempViewAlias = CONCAT('skipMapLvl', @TempLevel_ID);  
                        SET @DerivedHierarchyParentJoin = CONCAT(@DerivedHierarchyParentJoin, N'  
LEFT JOIN mdm.', QUOTENAME(@TempEntityViewName), N' AS ', QUOTENAME(@TempViewAlias), N'  
ON      ', QUOTENAME(@TempPriorViewAlias), N'.ID = ', QUOTENAME(@TempViewAlias), N'.', QUOTENAME(CONCAT(@ManyToManyChildAttributeName, N'.ID')), N'  
    AND ', QUOTENAME(@TempPriorViewAlias), N'.Version_ID = ', QUOTENAME(@TempViewAlias), N'.Version_ID');  
                        SET @TempPriorViewAlias = @TempViewAlias;  
                    END  
  
                    -- Join with the skipped level's entity view  
                    SET @TempViewAlias = CONCAT(N'skipLvl', @TempLevel_ID)  
                    SET @DerivedHierarchyParentJoin = CONCAT(@DerivedHierarchyParentJoin, N'  
LEFT JOIN mdm.', QUOTENAME(@TempDomainEntityViewName), N' AS ', QUOTENAME(@TempViewAlias), N'  
ON      ', QUOTENAME(@TempPriorViewAlias), '.', QUOTENAME(CONCAT(@TempAttributeName, N'.ID')), N' = ' + QUOTENAME(@TempViewAlias), N'.ID  
    AND ', QUOTENAME(@TempPriorViewAlias), '.Version_ID = ', QUOTENAME(@TempViewAlias) + N'.Version_ID');  
  
                    SET @TempPriorViewAlias = @TempViewAlias;  
  
                    DELETE FROM @SkippedLevel  
                    WHERE Level_ID = @TempLevel_ID;  
                END; --while  
  
                DECLARE @MappingTableAlias SYSNAME = NULL;  
                IF @PriorLevelForeignType_ID = @ForeignType_ManyToMany  
                BEGIN  
                    SET @MappingTableAlias = CONCAT(N'mapLvl', @PriorLevel_ID);  
                    -- Join with the mapping entity  
                    DECLARE  
                         @MappingEntityViewName SYSNAME  
                        ,@ParentAttributeName   SYSNAME  
                        ,@ChildAttributeName    SYSNAME;  
  
                    SELECT  
                         @MappingEntityViewName = mdm.udfViewNameGetByID(a.Entity_ID, @MemberType_Leaf, 0, 0)  
                        ,@ParentAttributeName   = Name  
                    FROM mdm.tblAttribute a  
                    WHERE ID = @ParentAttribute_ID;  
  
                    SELECT @ChildAttributeName = Name  
                    FROM mdm.tblAttribute  
                    WHERE ID = @PriorLevelManyToManyChildAttribute_ID  
  
                    -- Note: This is a LEFT rather than INNER JOIN so that it works for MDMUNUSED (i.e. when the attribute value is null and the join condition won't have matches only for unused members)  
                    SET @DerivedHierarchyParentJoin = CONCAT(@DerivedHierarchyParentJoin, N'  
LEFT JOIN mdm.', QUOTENAME(@MappingEntityViewName), N' ', @MappingTableAlias, N'  
ON      ', COALESCE(@TempViewAlias, 'T'), N'.ID = ', @MappingTableAlias, N'.', QUOTENAME(CONCAT(@ChildAttributeName, N'.ID')), N'  
    AND ', COALESCE(@TempViewAlias, 'T'), N'.Version_ID = ', @MappingTableAlias, N'.Version_ID');  
                END  
  
                SET @ParentViewAlias = COALESCE(@MappingTableAlias, @TempViewAlias, 'T');  
                IF (@Parent_ID IS NOT NULL AND @ParentAttribute_Name IS NOT NULL)  
                BEGIN  
                    SET @MemberWhere = CONCAT(@MemberWhere, N'  
    AND ', @ParentViewAlias, '.', QUOTENAME(CONCAT(@ParentAttribute_Name, N'.ID')), CASE  
                        WHEN @Parent_ID <= 0 THEN N' IS NULL '  
                        ELSE N' = @Parent_ID '  
                        END);  
                    SET @MemberFrom = CONCAT(@MemberFrom, @DerivedHierarchyParentJoin);  
                END;  
            END -- @RootEntity_ID != @Entity_ID  
        END -- Derived Hierarchy  
        -- Explicit hierarchy  
        ELSE IF @HierarchyType_ID = @HierarchyType_Explicit  
        BEGIN  
            IF @Parent_ID IS NULL  
            BEGIN  
                IF @MemberType_ID = @MemberType_Consolidated  
                BEGIN  
                    SET @MemberFrom += CONCAT(N'  
                         INNER JOIN [mdm].', @HierarchyTable, N' HR  
                         ON HR.ChildType_ID = ', @MemberType_Consolidated, N'  
                            AND HR.Version_ID = T.Version_ID  
                            AND HR.Hierarchy_ID = @Hierarchy_ID  
                            AND HR.Child_HP_ID = T.ID  
                            AND HR.Status_ID = ', @MemberStatusActive, N'  
                        ');  
                END  
            END  
           -- Display members under a explicit hierarchy  
            ELSE  
            BEGIN  
                -- Unused Leaf members  
                IF @Parent_ID = @Unused_ID AND @MemberType_ID = @MemberType_Leaf  
                BEGIN  
                    SET @MemberFrom += CONCAT(N'  
                         LEFT JOIN [mdm].', @HierarchyTable, N' HR  
                         ON HR.ChildType_ID = ', @MemberType_Leaf, N'  
                            AND HR.Version_ID = @Version_ID  
                            AND HR.Hierarchy_ID = @Hierarchy_ID  
                            AND HR.Child_EN_ID = T.ID  
                            AND HR.Status_ID = ', @MemberStatusActive, N'  
                        ');  
  
                    SET @MemberWhere += N'  
                            AND HR.Child_EN_ID IS NULL'  
                END  
                -- Under consolidate member or root  
                ELSE  
                BEGIN  
                    SET @MemberFrom += CONCAT(N'  
                    INNER JOIN [mdm].', @HierarchyTable, N' AS HR  
                    ON HR.ChildType_ID = ', @MemberType_ID, N'  
                        AND HR.Version_ID = @Version_ID  
                        AND HR.Hierarchy_ID = @Hierarchy_ID  
                        AND HR.' + CASE @MemberType_ID WHEN @MemberType_Leaf THEN N'Child_EN_ID' ELSE N'Child_HP_ID' END, N' = T.ID  
                        AND HR.Status_ID = ', @MemberStatusActive, N'  
                        ');  
  
                    SET @MemberWhere += N'  
                        AND ISNULL(HR.Parent_HP_ID, 0) = @Parent_ID'  
                END  
            END  
        END  
    END -- Get hierarchy members  
  
    DECLARE @MemberIdsCte NVARCHAR(MAX) = CONCAT(@TruncateGuard, N'  
WITH memberIdsCte AS  
(  
    SELECT ', CASE @IsHistoricalData WHEN 0 THEN N'T.ID' ELSE N'T.HS_ID' END, -- get all member IDs from within the selected page  
            CASE WHEN @UseMemberSecurity = 1 AND @IsHistoricalData <> 1 THEN N'  
          ,ms.AccessPermission AS AccessPermission'  
            END,  
            @MemberFrom, @MemberWhere, CASE WHEN LEN(@PagingTerm) > 0 THEN @MemberOrderBy END/*Exclude the ORDER BY clause if there is no paging*/, @PagingTerm, N'  
)'       )  
        ,@PagedMemberFrom NVARCHAR(MAX) = CONCAT(@TruncateGuard, N'  
FROM mdm.', QUOTENAME(@MemberViewName), N' T  
INNER JOIN memberIdsCte id  
ON      T.Version_ID = @Version_ID  
    AND ', CASE @IsHistoricalData WHEN 0 THEN N'T.ID = id.ID' ELSE N'T.HS_ID = id.HS_ID' END);  
  
    IF (@MemberReturnOption & @MemberReturnOptionData <> 0) OR (@MemberReturnOption & @MemberReturnOptionHistoricalData <> 0)  
    BEGIN  
        SELECT  
            MUID  
            ,Name  
            ,ID  
            ,AttributeType_ID  
            ,DataType_ID  
            ,SortOrder  
        FROM @AttributesWorkingSet  
        WHERE Name <> N'Code'  
            AND Name <> N'Name'  
        ORDER BY SortOrder, ID  
  
        SET @SQL = CONCAT(@TruncateGuard, N'  
-- Get member data', @MemberIdsCte, N'  
SELECT ', @ColumnString, @PagedMemberFrom, @MemberOrderBy);  
  
        --SELECT CONVERT(XML, @SQL);  
        EXEC sp_executesql @SQL, N'@Version_ID INT, @User_ID INT, @MemberType_Permission TINYINT, @MemberType_AccessPermission TINYINT, @PageNumber INT, @PageSize INT, @SearchTable mdm.MemberGetCriteria READONLY, @Parent_ID INT, @Hierarchy_ID INT',  
                                   @Version_ID,     @User_ID,     @MemberType_Permission,         @MemberType_AccessPermission,         @PageNumber,     @PageSize,     @SearchTable,                                @Parent_ID,     @Hierarchy_ID;  
    END  
  
    IF @MemberReturnOption & @MemberReturnOptionCount <> 0  
    BEGIN  
        SET @SQL = CONCAT(@TruncateGuard, N'  
-- Get member count  
SELECT @MemberCount = COUNT(DISTINCT T.', CASE @IsHistoricalData WHEN 0 THEN N'ID' ELSE N'HS_ID' END, ')', @MemberFrom, @MemberWhere);  
  
        --SELECT CONVERT(XML, @SQL);  
        EXEC sp_executesql @SQL, N'@Version_ID INT, @User_ID INT, @MemberType_Permission TINYINT, @MemberType_AccessPermission TINYINT, @SearchTable mdm.MemberGetCriteria READONLY, @Parent_ID INT, @Hierarchy_ID INT, @MemberCount INT OUTPUT',  
                                   @Version_ID,     @User_ID,     @MemberType_Permission,         @MemberType_AccessPermission,         @SearchTable,                                @Parent_ID,     @Hierarchy_ID,     @MemberCount OUTPUT;  
    END  
  
    -- Deprecated @MemberReturnOptionMembershipInformation  
    IF (@MemberReturnOption & @MemberReturnOptionMembershipInformation <> 0) OR (@MemberReturnOption & @MemberReturnOptionHistoricalMembershipInformation <> 0)  
    BEGIN  
        -- Use the exploded view to get parent info  
        DECLARE @ExplodedMemberViewName SYSNAME = mdm.udfViewNameGet(@Model_ID, @Entity_ID, @MemberType_ID, 1/*@IsExplodedView*/, CASE @IsHistoricalMembershipInformation WHEN 0 THEN 0 ELSE 2 END);  
  
        -- Have to join back again with the member view (but the exploded one) so that paging will work, since each member could have more than one EH parent  
        SET @SQL = CONCAT(@TruncateGuard, @MemberIdsCte, N'  
-- Get Explicit Hierarchy membership  
SELECT   
     CONVERT(BIGINT, T.LastChgTS) AS LastChgTS',-- The child's revision ID is used to match the child with its parent record(s)  
     CASE WHEN @IsHierarchyEnabled = 1 THEN N'  
    ,T.Parent_Status_ID  
    ,T.Parent_Code  
    ,T.Parent_Name  
    ,T.Parent_HierarchyMuid  
    ,T.Parent_HierarchyName  
    ,T.Parent_HierarchyId  
    ,T.Child_SortOrder  
    ,T.Parent_LastChgTS' END,  
    CASE WHEN @IncludeAuditInfo = 1 AND @IsHierarchyEnabled = 1 THEN N'  
    ,T.Parent_EnterDTM  
    ,T.Parent_EnterUserName  
    ,T.Parent_LastChgDTM  
    ,T.Parent_LastChgUserName'  
    END,  
    CASE WHEN @IsCollectionEnabled = 1 THEN N'  
    ,T.Collection_Status_ID  
    ,T.Collection_Code  
    ,T.Collection_Name  
    ,T.Collection_SortOrder  
    ,T.Collection_Weight  
    ,T.Collection_LastChgTS' END,  
    CASE WHEN @IncludeAuditInfo = 1 AND @IsCollectionEnabled = 1 THEN N'  
    ,T.Collection_EnterDTM  
    ,T.Collection_EnterUserName  
    ,T.Collection_LastChgDTM  
    ,T.Collection_LastChgUserName'  
    END,  
            REPLACE(@PagedMemberFrom, QUOTENAME(@MemberViewName), QUOTENAME(@ExplodedMemberViewName)),   
            CASE WHEN @IsHierarchyEnabled = 0 AND @IsCollectionEnabled = 0 THEN N'  
WHERE 0 = 1' END); -- don't both returning any rows (but still return an empty result set) if neither explicit hierarchies nor collections are enabled.  
  
        --SELECT CONVERT(XML, @SQL);  
        EXEC sp_executesql @SQL, N'@Version_ID INT, @User_ID INT, @MemberType_Permission TINYINT, @MemberType_AccessPermission TINYINT, @PageNumber INT, @PageSize INT, @SearchTable mdm.MemberGetCriteria READONLY, @Parent_ID INT, @Hierarchy_ID INT',  
                                   @Version_ID,     @User_ID,     @MemberType_Permission,         @MemberType_AccessPermission,         @PageNumber,     @PageSize,     @SearchTable,                                @Parent_ID,     @Hierarchy_ID;  
    END;  
  
    IF (@MemberReturnOption & @MemberReturnOptionDerivedHierarchyParents <> 0)   
        AND @HierarchyType_ID = @HierarchyType_Derived   
        AND @ParentAttribute_Name IS NOT NULL  
    BEGIN  
        SET @SQL = CONCAT(@TruncateGuard, @MemberIdsCte, N'  
-- Get Derived Hierarchy parents  
SELECT   
     CONVERT(BIGINT, T.LastChgTS) AS LastChgTS  
    ,', @ParentViewAlias, N'.', QUOTENAME(CONCAT(@ParentAttribute_Name, N'.MUID')), N' Parent_Muid', @MemberFrom,   
            CASE WHEN @Parent_ID IS NULL THEN @DerivedHierarchyParentJoin END -- If a parent wasn't specified, then @MemberFrom does not already include the DH parent join(s), so add it here.  
            , N'  
INNER JOIN memberIdsCte id  
ON      T.Version_ID = @Version_ID  
    AND T.ID = id.ID', @MemberWhere, CONCAT(N'  
    AND ', @ParentViewAlias, N'.', QUOTENAME(@ParentAttribute_Name), N' IS NOT NULL')); -- Ignore rows with null parent info  
  
        --SELECT CONVERT(XML, @SQL);  
        EXEC sp_executesql @SQL, N'@Version_ID INT, @User_ID INT, @MemberType_Permission TINYINT, @MemberType_AccessPermission TINYINT, @PageNumber INT, @PageSize INT, @SearchTable mdm.MemberGetCriteria READONLY, @Parent_ID INT, @Hierarchy_ID INT',  
                                   @Version_ID,     @User_ID,     @MemberType_Permission,         @MemberType_AccessPermission,         @PageNumber,     @PageSize,     @SearchTable,                                @Parent_ID,     @Hierarchy_ID;  
    END  
  
    SET NOCOUNT OFF;  
END; --proc
go

