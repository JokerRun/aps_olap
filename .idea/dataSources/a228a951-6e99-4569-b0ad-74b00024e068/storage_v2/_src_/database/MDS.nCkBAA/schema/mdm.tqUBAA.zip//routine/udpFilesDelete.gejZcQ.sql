/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Deletes the files with the given IDs  
*/  
CREATE PROCEDURE mdm.udpFilesDelete  
(  
    @File_ID        mdm.IdList READONLY,  
    @CorrelationID  UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON  
  
    -- Orphan any sync target files that reference the files being deleted  
    UPDATE f  
    SET   
         Source_ID = NULL  
        ,Source_LastChgTS = NULL  
    FROM mdm.tblFile f  
    INNER JOIN @File_ID d  
    ON f.Source_ID = d.ID;  
PRINT CONCAT(SYSDATETIME(), N': ', @@ROWCOUNT, N' row(s) had Source_ID set to null in tblFile.');  
  
    -- Delete the files  
    DELETE f  
    FROM mdm.tblFile f  
    INNER JOIN @File_ID d  
    ON f.ID = d.ID  
PRINT CONCAT(SYSDATETIME(), N': ', @@ROWCOUNT, N' row(s) deleted from tblFile.');  
  
    SET NOCOUNT OFF  
END --proc
go

