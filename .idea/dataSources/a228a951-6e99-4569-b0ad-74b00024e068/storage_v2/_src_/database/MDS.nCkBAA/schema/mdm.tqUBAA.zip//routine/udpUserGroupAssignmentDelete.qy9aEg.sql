/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
exec mdm.udpUserGroupAssignmentDelete 'jhills', NULL    -- Deletes all group assignments for user_id 'jhills'  
exec mdm.udpUserGroupAssignmentDelete NULL, 8           -- Deletes all group assignments for usergroup_id 8   
exec mdm.udpUserGroupAssignmentDelete 'bbarnett', 9     -- Deletes group assignment for user_id 'bbarnett' and usergroup_id 9  
exec mdm.udpUserGroupAssignmentDelete NULL, NULL        -- Deletes all group assignments  
  
select u.UserName, ga.* from mdm.tblUserGroupAssignment ga inner join mdm.tblUser u on u.id = ga.User_ID order by usergroup_id, user_id  
select u.UserName, ga.* from mdm.tblUserGroupAssignment ga inner join mdm.tblUser u on u.id = ga.User_ID order by user_id, usergroup_id   
  
*/  
CREATE PROCEDURE mdm.udpUserGroupAssignmentDelete  
(  
    @SystemUser_ID  INT, --Person performing save  
    @User_ID        INT = NULL, -- NULL to deactive all user  
    @UserGroup_ID   INT = NULL, -- NULL to deactive all group  
    @ProcessSecurityMember  BIT = 1,  
    @CorrelationID  UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    DECLARE @Status_Deactive        TINYINT = 2,  
            @PrincipalType_Group    TINYINT = 2,  
            @securityMemberEvent    mdm.SecurityMemberProcessEvent  
  
    IF @ProcessSecurityMember = 1  
    BEGIN  
        IF @User_ID IS NOT NULL  
        BEGIN  
            INSERT @securityMemberEvent ([User_ID], [Entity_ID], Version_ID)  
            SELECT DISTINCT [User_ID], [Entity_ID], Version_ID  
            FROM [mdm].[viw_SYSTEM_SECURITY_ROLE_MEMBER] rm  
            INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ROLE ur  
            ON rm.Role_ID = ur.Role_ID  
            WHERE ur.[User_ID] = @User_ID;  
        END  
        ELSE IF @UserGroup_ID IS NOT NULL  
        BEGIN  
            INSERT @securityMemberEvent ([User_ID], [Entity_ID], Version_ID)  
            SELECT DISTINCT [User_ID], [Entity_ID], Version_ID  
            FROM [mdm].[viw_SYSTEM_SECURITY_ROLE_MEMBER] rm  
            INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ROLE ur  
            ON rm.Role_ID = ur.Role_ID  
            INNER JOIN [mdm].[tblSecurityAccessControl] sa  
            ON  rm.Role_ID = sa.Role_ID  
            WHERE PrincipalType_ID = @PrincipalType_Group  
            AND Principal_ID = @UserGroup_ID  
        END  
    END  
  
    DELETE mdm.tblUserGroupAssignment  
    WHERE (@UserGroup_ID IS NOT NULL OR @User_ID IS NOT NULL)  
        AND (@UserGroup_ID IS NULL OR UserGroup_ID = @UserGroup_ID)  
        AND (@User_ID IS NULL OR [User_ID] = @User_ID)  
  
    -- Queue a async event to recompute affected user  
    EXEC mdm.udpSecurityMemberProcessRebuildEvent @securityMemberEvent, 0;  
  
    SET NOCOUNT OFF  
END
go

