/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE [mdm].[udpChangeTableDataCompressionType]  
    @tableName       NVARCHAR(128),  
    @dataCompression TINYINT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
AS  
BEGIN  
    DECLARE @sql NVARCHAR(MAX),  
            @tableId INT = NULL,  
            @index NVARCHAR(128),  
            @options NVARCHAR(MAX);  
    -- Only enterprise version supports data compression  
    -- http://msdn.microsoft.com/en-us/library/ms174396.aspx  
    IF mdm.udfIsEnterpriseEdition() = 1  
    BEGIN  
        SET @tableId = OBJECT_ID(@tableName);  
        IF @tableId IS NOT NULL AND EXISTS (SELECT 1 FROM sys.tables WHERE [object_id] = @tableId)  
        BEGIN  
            -- Rebuild Tabble  
            SET @options = mdm.udfGetTableOptions(@dataCompression, NULL);  
            SET @sql = N'ALTER TABLE ' + @tableName + N' REBUILD ' + @options;  
            -- PRINT @sql  
            EXEC (@sql);  
  
            -- Rebuild Indexes  
            SET @options = mdm.udfGetIndexOptions(@dataCompression, NULL);  
  
            DECLARE tableIndexes CURSOR FOR  
            SELECT name FROM sys.indexes WHERE [object_id] = @tableId  
  
            OPEN tableIndexes;  
            FETCH NEXT FROM tableIndexes INTO @index;  
  
            WHILE @@FETCH_STATUS = 0  
            BEGIN  
                SET @sql = N'ALTER INDEX ' + QUOTENAME(@index) + N' ON ' + @tableName + N' REBUILD ' + @options;  
                -- PRINT @sql  
                EXEC (@sql);  
                FETCH NEXT FROM tableIndexes INTO @index;  
            END  
            CLOSE tableIndexes;  
            DEALLOCATE tableIndexes;  
       END;  
    END;  
END
go

