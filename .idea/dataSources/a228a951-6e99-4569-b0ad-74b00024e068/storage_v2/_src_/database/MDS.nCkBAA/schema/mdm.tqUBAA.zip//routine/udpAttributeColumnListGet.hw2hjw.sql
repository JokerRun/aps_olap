/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
    Procedure  : mdm.udpAttributeColumnListGet  
    Component  : Hierarchy Explorer; Security Administration  
    Description: mdm.udpAttributeColumnListGet returns a string containing column names that are accessible to a user (security is applied)  
    Parameters : User ID (required)             
                 Entity ID (required)            
                 Member Type ID (required)       
                 Display Type ID (required)      
                 Attribute Group ID (required)         
    Return     : String  
    Example    :   
                DECLARE @ColumnString AS NVARCHAR(MAX);  
                EXEC mdm.udpAttributeColumnListGet 1, 6, 1, NULL, @ColumnString OUT;  
                SELECT @ColumnString;  
*/  
CREATE PROCEDURE mdm.udpAttributeColumnListGet  
(  
    @User_ID            INT,  
    @Entity_ID          INT,  
    @MemberType_ID      INT,  
    @AttributeGroup_ID  INT = NULL,  
    @ColumnString       NVARCHAR(MAX) OUTPUT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON;  
  
    --Get static set of columns  
    SET @ColumnString = CAST(N'T.[ID], T.[Version_ID], T.[ValidationStatus_ID]' AS NVARCHAR(MAX));  
  
    --Get variable set of colummns  
    SELECT @ColumnString += N', T.' + QUOTENAME(a.Name)   
    FROM mdm.tblAttribute a  
    INNER JOIN viw_SYSTEM_SECURITY_USER_ATTRIBUTE aSec  
    ON a.ID = aSec.ID  
        AND aSec.User_ID = @User_ID  
        AND (@Entity_ID IS NULL OR a.Entity_ID = @Entity_ID)  
        AND (@MemberType_ID IS NULL OR a.MemberType_ID = @MemberType_ID)  
    LEFT JOIN mdm.tblAttributeGroupDetail aGroup   
    ON      a.ID = aGroup.Attribute_ID  
        AND aGroup.AttributeGroup_ID = @AttributeGroup_ID  
    WHERE  @AttributeGroup_ID IS NULL  
        OR aGroup.AttributeGroup_ID IS NOT NULL  
        OR a.IsCode = 1 -- always include Name and Code (if the user has permission to see them)  
        OR a.IsName = 1  
    ORDER BY -- Ensure Name and Code come before the other attributes  
        CASE WHEN a.IsName = 1 THEN 0  
             WHEN a.IsCode = 1 THEN 1  
             ELSE 2 END;  
  
    SET NOCOUNT OFF;  
END; --proc
go

