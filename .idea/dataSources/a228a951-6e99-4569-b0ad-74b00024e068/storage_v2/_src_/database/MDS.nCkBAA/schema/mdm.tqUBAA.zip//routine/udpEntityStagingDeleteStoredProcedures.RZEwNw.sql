/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE [mdm].[udpEntityStagingDeleteStoredProcedures]  
(    
    @Entity_ID INT,  
    @ProcedureType INT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    --Start transaction, being careful to check if we are nested    
    DECLARE @TranCounter INT;     
    SET @TranCounter = @@TRANCOUNT;    
    IF @TranCounter > 0 SAVE TRANSACTION TX;    
    ELSE BEGIN TRANSACTION;    
    
    BEGIN TRY    
    
        DECLARE @SQL                            NVARCHAR(MAX),  
                @IsHierarchyEnabled             BIT,  
                @LeafSproc                      sysname,  
                @ConsolidatedSproc              sysname,  
                @RelationshipSproc              sysname,  
                -- Types of staging procedures to delete.      
                @AllTypes                       INT = 0,    
                @Leaf                           INT = 1,      
                @Consolidated                   INT = 2,  
                @ConsolidatedAndRelationship    INT = 3,      
                @Relationship                   INT = 4,  
                @StagingBase					NVARCHAR(max) = NULL;  
  
        --Set variables.    
        SET @SQL = N'';  
          
        SELECT  
            @IsHierarchyEnabled  = CASE WHEN HierarchyTable  IS NULL THEN 0 ELSE 1 END,  
            @StagingBase = StagingBase,  
            @LeafSproc = N'udp_' + StagingBase + N'_Leaf',  
            @ConsolidatedSproc = N'udp_' + StagingBase + N'_Consolidated',  
            @RelationshipSproc = N'udp_' + StagingBase + N'_Relationship'  
        FROM  
            mdm.tblEntity WHERE ID = @Entity_ID;  
                      
        IF      (@ProcedureType = @Leaf OR @ProcedureType = @AllTypes)   
            AND EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_TYPE = N'PROCEDURE' AND ROUTINE_SCHEMA = N'stg' AND ROUTINE_NAME = @LeafSproc)  
        BEGIN  
            SET @SQL += N'  
                DROP PROCEDURE stg.' + QUOTENAME(@LeafSproc) + ';';  
        END; -- IF  
          
          
        --Drop Consolidated Entity Based Staging Procedure if the entity supports hierarchies  
        IF @IsHierarchyEnabled = 1   
        BEGIN  
            IF      @ProcedureType IN (@AllTypes, @Consolidated, @ConsolidatedAndRelationship)   
                AND EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_TYPE = N'PROCEDURE' AND ROUTINE_SCHEMA = N'stg' AND ROUTINE_NAME = @ConsolidatedSproc)  
            BEGIN   
                --Drop Consolidated Staging Procedure.  
                SET @SQL += N'  
                    DROP PROCEDURE stg.' + QUOTENAME(@ConsolidatedSproc) + ';';  
            END; --IF  
           
            IF  @ProcedureType IN (@AllTypes, @ConsolidatedAndRelationship, @Relationship)  
                AND EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_TYPE = N'PROCEDURE' AND ROUTINE_SCHEMA = N'stg' AND ROUTINE_NAME = @RelationshipSproc)  
            BEGIN  
                -- Drop Relationship Staging Procedure.  
                SET @SQL += N'  
                    DROP PROCEDURE stg.' + QUOTENAME(@RelationshipSproc) + ';';  
            END; --IF  
        END --IF   
  
        EXEC sp_executesql @SQL;    
    
        --Commit only if we are not nested    
        IF @TranCounter = 0 COMMIT TRANSACTION;    
        RETURN(0);    
            
    END TRY    
    --Compensate as necessary    
    BEGIN CATCH  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
    
        IF @TranCounter = 0 ROLLBACK TRANSACTION;    
        ELSE IF XACT_STATE() <> -1 ROLLBACK TRANSACTION TX;    
    
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);    
    
        RETURN(1);    
    
    END CATCH;      
      
    SET NOCOUNT OFF;    
END; --proc
go

