/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Creates an attribute. For efficiency, this sproc does not verify that the user is a model  
admin. This check should be done before calling the sproc.  
  
    --Create free form attribute  
    DECLARE @Return_ID INT, @Return_MUID UNIQUEIDENTIFIER, @Type INT;  
    SET @Type = 1; --SET NVARCHAR=1, DECIMAL=2, DATETIME=3  
    EXEC mdm.udpAttributeSave  
    @User_ID = 1,  
    @Entity_ID = 15,  
    @MemberType_ID = 1, --Leaf  
    @AttributeName = N'Comments 10',  
    @AttributeType_ID = 1,  
    @Description = N'Comments 10',  
    @DisplayName = N'Comments 10',  
    @DisplayWidth = 100,  
    @DataType_ID = @Type,  
    @DataTypeInformation = 0,  
    @EditMode = 0,  
    @Return_ID = @Return_ID OUTPUT,  
    @Return_MUID = @Return_MUID OUTPUT;  
    SELECT @Return_ID, @Return_MUID;  
    SELECT * FROM mdm.tblAttribute WHERE ID = @Return_ID;  
  
    --Create DBA attribute  
    DECLARE @Return_ID INT, @Return_MUID UNIQUEIDENTIFIER, @DomainEntity_ID INT;  
    SET @DomainEntity_ID = 4;  
    EXEC mdm.udpAttributeSave  
    @User_ID = 1,  
    @Entity_ID = 15,  
    @MemberType_ID = 1, --Leaf  
    @AttributeName = N'Color Attribute',  
    @AttributeType_ID = 2, --Domain  
    @Description = N'Color Attribute',  
    @DisplayName = N'Color Attribute',  
    @DisplayWidth = 100,  
    @DomainEntity_ID = @DomainEntity_ID  
    @DataTypeInformation = 0,  
    @EditMode = 0,  
    @Return_ID = @Return_ID OUTPUT,  
    @Return_MUID = @Return_MUID OUTPUT;  
    SELECT @Return_ID, @Return_MUID;  
    SELECT * FROM mdm.tblAttribute WHERE ID = @Return_ID;  
  
    --Create FILE attribute  
    DECLARE @Return_ID INT, @Return_MUID UNIQUEIDENTIFIER;  
    --SET @Return_MUID = NEWID(); SELECT @Return_MUID; --Uncomment to test clone operation  
    EXEC mdm.udpAttributeSave  
    @User_ID = 1,  
    @Entity_ID = 15,  
    @MemberType_ID = 1, --Leaf  
    @AttributeName = N'Picture',  
    @AttributeType_ID = 4, --File  
    @Description = N'Picture',  
    @DisplayName = N'Picture',  
    @DisplayWidth = 100,  
    @EditMode = 0,  
    @Return_ID = @Return_ID OUTPUT,  
    @Return_MUID = @Return_MUID OUTPUT;  
    SELECT @Return_ID, @Return_MUID;  
    SELECT * FROM mdm.tblAttribute WHERE ID = @Return_ID;  
  
    --Update name of free form attribute  
    DECLARE @Return_ID INT, @Return_MUID UNIQUEIDENTIFIER;  
    EXEC mdm.udpAttributeSave  
    @User_ID = 1,  
    @Entity_ID = 15,  
    @MemberType_ID = 1, --Leaf  
    @Attribute_ID = 10,  
    @AttributeName = N'NewName',  
    @AttributeType_ID = 1,  
    @Description = N'Comments 10',  
    @DisplayName = N'Comments 10',  
    @DisplayWidth = 100,  
    @DataType_ID = 1,  
    @DataTypeInformation = 0,  
    @EditMode = 1, --Update  
    @Return_ID = @Return_ID OUTPUT,  
    @Return_MUID = @Return_MUID OUTPUT;  
    SELECT @Return_ID, @Return_MUID;  
    SELECT * FROM mdm.tblAttribute WHERE ID = @Return_ID;  
*/  
CREATE PROCEDURE mdm.udpAttributeSave  
(  
    @User_ID                INT,  
    @Model_ID               INT,-- Caller should validate  
    @Version_ID             INT = NULL,-- used for audit info. When NULL, the highest value for the model will be used  
  
    -- Entity info  
    @Entity_ID              INT, -- Caller should validate  
    @IsHierarchyEnabled     BIT,  
    @IsCollectionEnabled    BIT,  
    @DataCompression        TINYINT,  
    @TableName              SYSNAME OUTPUT,-- OUTPUT param because creating a collection attribute causes the entity to support collections  
    @StagingTableName       SYSNAME,  
  
    @MemberType_ID          TINYINT,  
    @Attribute_ID           INT = NULL,  
    @Attribute_MUID         UNIQUEIDENTIFIER = NULL,  
    @AttributeName          NVARCHAR(100),  
    @AttributeType_ID       TINYINT, --1: Freeform, 2: Domain, 3: System, 4: File  
    @Description	        NVARCHAR(500) = NULL,  
    @DisplayName            NVARCHAR(250) = NULL,  
    @DisplayWidth           INT,  
    @DomainEntity_ID        INT = NULL,  
    @FilterParentAttribute_ID INT = NULL,-- Caller should validate  
    @FilterHierarchyDetail_ID INT = NULL,-- Caller should validate  
    @DataType_ID            TINYINT = NULL,  
    @DataTypeInformation    INT = NULL,  
    @InputMask_ID           INT = NULL,-- Caller should validate  
    @ChangeTrackingGroup    INT = 0,  
    @SortOrder              INT = NULL OUTPUT,  
    @EditMode               TINYINT = 0, --0: Create, 1: Update, 4: Clone, defaults to Create  
    @IsSync                 BIT = 0,  
    @RecreateStagingProc    BIT = 1, -- In can be useful, for efficiency, to turn this off for batch metadata changes   
    @Return_DidNameChange   BIT = NULL OUTPUT,  
    @Return_ID              INT = NULL OUTPUT,  
    @Return_MUID            UNIQUEIDENTIFIER = NULL OUTPUT, --Also an input parameter for clone operations  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE   
            @SQL                    NVARCHAR(MAX),  
            @AddColumnSQL           NVARCHAR(MAX),  
            @CurrentDTM             DATETIME2(3),  
            @TableColumn            SYSNAME,  
            @IsCloneMode            BIT,  
            @ExistingSysAttr_MUID   UNIQUEIDENTIFIER,  
            @CurrentDataType_ID     INT,  
            @CurrentDataTypeInfo    INT,  
            @CurrentSortOrder       INT,  
            @HistoryTableName       SYSNAME,  
            @VersionColumnName      SYSNAME,  
            @PendingTableName       SYSNAME,  
  
            -- MemberType constants  
            @MemberTypeLeaf         TINYINT = 1,  
            @MemberTypeConsolidated TINYINT = 2,  
            @MemberTypeCollection   TINYINT = 3,  
  
            -- AttributeType constants  
            @AttributeTypeFreeform  TINYINT = 1,  
            @AttributeTypeDomain    TINYINT = 2,  
            @AttributeTypeSystem    TINYINT = 3,  
            @AttributeTypeFile      TINYINT = 4,  
  
            -- AttributeDataType constants  
            @DataTypeText           TINYINT = 1,  
            @DataTypeNumber         TINYINT = 2,  
            @DataTypeDateTime       TINYINT = 3,  
            @DataTypeLink           TINYINT = 6,  
  
            @TranCommitted          INT = 0, -- 0: Not committed, 1: Committed.  
            @PreviousAttributeName  NVARCHAR(100),  
            @IsSystem               BIT = 0,  
            @TableOptions           NVARCHAR(MAX) = N'',  
            @IndexOptions           NVARCHAR(MAX) = N'',  
  
            @GuidEmpty              UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER),  
            @EditMode_Create        TINYINT = 0,  
            @EditMode_Update        TINYINT = 1,  
            @EditMode_Clone         TINYINT = 4,  
            @ExistingAttribute_MUID UNIQUEIDENTIFIER = NULL,  
            @ExistingAttribute_ID   INT = NULL,  
            @ExistingAttributeType  TINYINT = NULL,  
            @ExistingAttributeName  NVARCHAR(MAX),  
            @ExistingFilterParentAttribute_ID INT,  
            @ExistingFilterHierarchyDetail_ID INT,  
            @Found_DomainEntity_ID  INT = NULL;  
  
    --Initialize output parameters and local variables  
    SELECT  
        @Description = NULLIF(LTRIM(RTRIM(@Description)), N''),  
        @DisplayName = NULLIF(LTRIM(RTRIM(@DisplayName)), N''),  
        @Return_ID = NULL,  
        @CurrentDTM = GETUTCDATE(),  
        @IsCloneMode = CASE WHEN @Return_MUID IS NULL THEN 0 ELSE 1 END,  
        @Entity_ID = NULLIF(@Entity_ID, 0),  
        @Attribute_ID = NULLIF(@Attribute_ID, 0),  
        @Attribute_MUID = NULLIF(@Attribute_MUID, @GuidEmpty),  
        @AttributeName = NULLIF(LTRIM(RTRIM(@AttributeName)), N''),  
        @DomainEntity_ID = NULLIF(@DomainEntity_ID, 0),  
        @FilterParentAttribute_ID = NULLIF(@FilterParentAttribute_ID, 0),  
        @FilterHierarchyDetail_ID = NULLIF(@FilterHierarchyDetail_ID, 0),  
        @AttributeType_ID = NULLIF(@AttributeType_ID, 0),  
        @Return_DidNameChange = 0,  
        @MemberType_ID = COALESCE(@MemberType_ID, 0),  
        @TableName = @TableName,  
        @SortOrder = @SortOrder  
        ;  
  
  
  
    --Invalid @MemberType_ID  
    IF @MemberType_ID NOT IN (@MemberTypeLeaf, @MemberTypeConsolidated, @MemberTypeCollection) --Invalid MemberType  
    BEGIN  
        RAISERROR('MDSERR200015|The attribute cannot be saved. The member type is not valid.', 16, 1);  
        RETURN;  
    END; --if  
  
    --Test for invalid AttributeType  
    IF @AttributeType_ID NOT IN (@AttributeTypeFreeform, @AttributeTypeDomain, @AttributeTypeSystem, @AttributeTypeFile)  
    BEGIN  
        --On error, return NULL results  
        SELECT @Return_ID = NULL, @Return_MUID = NULL;  
        RAISERROR('MDSERR100010|The Parameters are not valid.', 16, 1);  
        RETURN;  
    END; --if  
  
    --Raise an error if we are missing the entity ID  
    IF @Model_ID IS NULL OR @Entity_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR200014|The attribute cannot be saved. The entity ID is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    --Get the latest Model version  
    IF @Version_ID IS NULL  
    BEGIN  
        SELECT @Version_ID = MAX(ID)  
        FROM mdm.tblModelVersion  
        WHERE Model_ID = @Model_ID  
    END  
  
    IF @AttributeType_ID = @AttributeTypeDomain  
    BEGIN  
        SET @DataType_ID = @DataTypeText;  
        IF COALESCE(@DomainEntity_ID, 0) <= 0  
        BEGIN  
            RAISERROR('MDSERR200068|The attribute cannot be saved. The DomainEntity ID is not valid.', 16, 1);  
            RETURN;  
        END  
    END ELSE  
    BEGIN  
        IF @FilterParentAttribute_ID IS NOT NULL OR @FilterHierarchyDetail_ID IS NOT NULL  
        BEGIN  
            RAISERROR(N'MDSERR200115|The attribute cannot be saved. An attribute filter can only be added to a domain-based attribute.', 16, 1);  
            RETURN;  
        END  
    END  
  
    -- Either both or neither filter params must be specified  
    IF @FilterParentAttribute_ID > 0 AND COALESCE(@FilterHierarchyDetail_ID, 0) <= 0   
    BEGIN  
        RAISERROR(N'MDSERR200119|The attribute cannot be saved. The attribute filter hierarchy is not valid.', 16, 1);  
        RETURN;  
    END  
    IF @FilterHierarchyDetail_ID > 0 AND COALESCE(@FilterParentAttribute_ID, 0) <= 0   
    BEGIN  
        RAISERROR(N'MDSERR200116|The attribute cannot be saved. The attribute filter parent is not valid.', 16, 1);  
        RETURN;  
    END  
  
  
    IF @MemberType_ID <> @MemberTypeLeaf AND @FilterParentAttribute_ID IS NOT NULL  
    BEGIN  
        RAISERROR(N'MDSERR200114|The attribute cannot be saved. An attribute filter can only be added to a leaf attribute.', 16, 1);  
        RETURN;  
    END  
  
    --Test for invalid parameters:  
    --Invalid @ChangeTrackingGroup  
    IF @ChangeTrackingGroup NOT BETWEEN 0 AND 31  
    BEGIN  
        RAISERROR('MDSERR100108|Change Tracking Group must be an INT between 0 and 31.', 16, 1);  
        RETURN;  
    END --IF  
  
    --Invalid @MemberType_ID for THIS entity  
    IF @MemberType_ID = @MemberTypeConsolidated AND @IsHierarchyEnabled = 0  
    BEGIN  
        RAISERROR('MDSERR200072|The attribute cannot be saved. The member type is not valid for this entity.', 16, 1);  
        RETURN;  
    END; --if  EXE  
  
    SET @TableOptions = mdm.udfGetTableOptions(@DataCompression, @Model_ID);  
    SET @IndexOptions = mdm.udfGetIndexOptions(@DataCompression, @Model_ID);  
  
    -- When creating collection member attributes, ensure the collection tables have been created.  
    IF @MemberType_ID = @MemberTypeCollection AND @IsCollectionEnabled = 0  
    BEGIN  
        EXEC mdm.udpCollectionTablesCreate @User_ID, @Model_ID, @Version_ID, @Entity_ID, @IsHierarchyEnabled, @TableOptions, @IndexOptions, @TableName OUTPUT;  
        SET @IsCollectionEnabled = 1;  
    END; --if  
  
    --Figure out whether the attribute is a system attribute  
    IF @EditMode IN (@EditMode_Update, @EditMode_Clone)  
        AND EXISTS(  
                SELECT 1  
                FROM mdm.tblAttribute  
                WHERE Entity_ID = @Entity_ID  
                AND MemberType_ID = @MemberType_ID  
                AND IsSystem = 1  
                AND [Name] = @AttributeName  
             )  
    BEGIN  
        SET @IsSystem = 1;  
    END  
  
    --Invalid @DataType_ID  
    IF @DataType_ID NOT IN (@DataTypeText, @DataTypeNumber, @DataTypeDateTime, @DataTypeLink) --Invalid @DataType_ID  
    BEGIN  
        RAISERROR('MDSERR200073|The attribute cannot be saved. The data type is not valid.', 16, 1);  
        RETURN;  
    END; --if  
  
    --Invalid @DisplayWidth  
    IF @DisplayWidth NOT BETWEEN 0 AND 500 --Invalid @DisplayWidth  
    BEGIN  
        RAISERROR('MDSERR200067|The attribute cannot be saved. The display width is not valid.', 16, 1);  
        RETURN;  
    END; --if  
  
    -- Validate @AttributeName  
    IF ISNULL(@AttributeName, '') = ''  
    BEGIN  
        RAISERROR('MDSERR100003|The Name is not valid.', 16, 1);  
        RETURN;  
    END; --if  
  
    --If we are in the Update or Clone mode get the missing pieces of the identifier  
    IF @EditMode IN (@EditMode_Update, @EditMode_Clone)  
    BEGIN  
        --Use the name to look up the attribute identifier if:  
        --  * the attribute is a system attribute. In this case name updates are not allowed  
        --    and we don't care what IDs the user sent in  
        -- OR  
        --  * use the name if neither MUID nor ID are available. This is important because we don't  
        --    want to look up by name if the name is what the user is trying to update.  
        IF @IsSystem = 1 OR (@Attribute_ID IS NULL AND @Attribute_MUID IS NULL)  
        BEGIN  
            SELECT TOP 1  
                @ExistingAttribute_ID =  ID,  
                @ExistingAttribute_MUID = MUID,  
                @ExistingAttributeType = AttributeType_ID,  
                @ExistingAttributeName = Name,  
                @ExistingFilterParentAttribute_ID = FilterParentAttribute_ID,  
                @ExistingFilterHierarchyDetail_ID = FilterHierarchyDetail_ID,  
                @TableColumn = TableColumn,  
                @CurrentDataType_ID = DataType_ID,  
                @CurrentDataTypeInfo = DataTypeInformation,  
                @PreviousAttributeName = [Name],  
                @CurrentSortOrder = SortOrder  
            FROM mdm.tblAttribute  
            WHERE  
                --Filter by member type too  
                MemberType_ID = @MemberType_ID AND  
                [Name] = @AttributeName AND  
                Entity_ID = @Entity_ID;  
        END  
        --Use the Attribute ID and MUID to look up the full identifier  
        ELSE  
        BEGIN  
            SELECT  
                @ExistingAttribute_ID =  ID,  
                @ExistingAttribute_MUID = MUID,  
                @ExistingAttributeType = AttributeType_ID,  
                @ExistingAttributeName = Name,  
                @ExistingFilterParentAttribute_ID = FilterParentAttribute_ID,  
                @ExistingFilterHierarchyDetail_ID = FilterHierarchyDetail_ID,  
                @TableColumn = TableColumn,  
                @CurrentDataType_ID = DataType_ID,  
                @CurrentDataTypeInfo = DataTypeInformation,  
                @PreviousAttributeName = [Name],  
                @CurrentSortOrder = SortOrder  
            FROM mdm.tblAttribute  
            WHERE  
                MemberType_ID = @MemberType_ID AND  
                (@Attribute_ID IS NOT NULL OR @Attribute_MUID IS NOT NULL) AND  
                (@Attribute_ID IS NULL OR ID = @Attribute_ID) AND  
                (@Attribute_MUID IS NULL OR MUID = @Attribute_MUID) AND  
                Entity_ID = @Entity_ID;  
        END  
  
        --If we are in the Clone mode we need to figure out whether we are creating or updating an attribute  
        IF @EditMode = @EditMode_Clone  
        BEGIN  
            --If there is no existing attribute then set the edit mode to Create  
            IF @ExistingAttribute_MUID IS NULL AND @ExistingAttribute_ID IS NULL  
            BEGIN  
                SET @EditMode = @EditMode_Create;  
                SET @Attribute_ID = NULL;  
            END  
            --If there is an existing attribute then set the edit mode to Update  
            ELSE  
            BEGIN  
                SET @EditMode = @EditMode_Update;  
                SET @Attribute_ID = @ExistingAttribute_ID;  
            END  
        END  
        --If we are in Update mode and could not find a matching existing attribute we need to raise an error and quit now  
        ELSE IF @EditMode = @EditMode_Update  
        BEGIN  
            IF @ExistingAttribute_ID IS NULL OR @ExistingAttribute_MUID IS NULL  
            BEGIN  
                --On error, return NULL results  
                SELECT @Return_ID = NULL, @Return_MUID = NULL;  
                RAISERROR('MDSERR110007|The ID is not valid.', 16, 1);  
                RETURN;  
            END  
            ELSE  
            BEGIN  
                SET @Attribute_ID = @ExistingAttribute_ID;  
                SET @Attribute_MUID = @ExistingAttribute_MUID;  
            END  
        END  
  
        --Can not update attribute type of an existing attribute  
        IF @EditMode = @EditMode_Update AND @AttributeType_ID <> @ExistingAttributeType  
        BEGIN  
            SELECT @Return_ID = NULL, @Return_MUID = NULL;  
            RAISERROR('MDSERR100010|The Parameters are not valid.', 16, 1);  
            RETURN;  
        END  
    END  
  
    --If the edit mode is Create. This code also needs to execute if the user sent in EditMode clone which ended up becoming Create (hence the IF instead of ELSE IF)  
    IF @EditMode = @EditMode_Create  
    BEGIN  
        --Set Entity ID to null. We don't care what came in.  
        SET @Attribute_ID = NULL;  
  
        --If @Attribute_MUID is not null then we need to ensure it does not already exist (since this is a create)  
        IF @Attribute_MUID IS NOT NULL AND EXISTS(SELECT 1 FROM mdm.tblAttribute WHERE MUID = @Attribute_MUID)  
        BEGIN  
            --On error, return NULL results  
            SELECT @Return_ID = NULL, @Return_MUID = NULL;  
            RAISERROR('MDSERR110007|The ID is not valid.', 16, 1);  
        RETURN;  
        END  
    END  
  
    --Invalid @Attribute_ID (or not in same Entity)  
    IF @Attribute_ID IS NOT NULL AND NOT EXISTS(SELECT 1 FROM mdm.tblAttribute WHERE ID = @Attribute_ID AND Entity_ID = @Entity_ID AND MemberType_ID = @MemberType_ID)  
    BEGIN  
        RAISERROR('MDSERR200016|The attribute cannot be saved. The attribute ID is not valid.', 16, 1);  
        RETURN;  
    END; --if  
  
    --Do not allow the creation of system attributes  
    IF @EditMode = @EditMode_Create AND @IsSystem = 1 --System attribute  
    BEGIN  
        RAISERROR('MDSERR200074|Creating system attributes is not supported.', 16, 1);  
        RETURN;  
    END  
  
    --Check the name of the attribute for duplicates  
    IF @IsSystem = 0  
    BEGIN  
        IF EXISTS  
        (  
            SELECT 1   
            FROM mdm.tblAttribute  
            WHERE  
                @AttributeName = Name AND  
                (@Attribute_MUID IS NULL OR MUID <> @Attribute_MUID) AND  
                Entity_ID = @Entity_ID AND  
                MemberType_ID = @MemberType_ID  
        )  
        BEGIN  
            --On error, return NULL results  
            SELECT @Return_ID = NULL, @Return_MUID = NULL;  
            RAISERROR('MDSERR110003|The name already exists. Type a different name.', 16, 1);  
            RETURN;  
        END  
    END  
  
    -- If an Attribute filter is specified ensure it is valid  
   -- If an existing attribute is being updated with a new filter, do additional validity checks  
    IF      @EditMode = @EditMode_Update   
        AND @FilterParentAttribute_ID IS NOT NULL   
    BEGIN  
  
        -- If the parent attribute is new, verify that it does not cause a circular dependency. Note: this does not need to be checked in Create mode, because no existing attribute can reference an attribute that hasn't yet been created.  
        IF (@FilterParentAttribute_ID <> COALESCE(@ExistingFilterParentAttribute_ID, 0))  
        BEGIN  
            DECLARE @IsCircularReference BIT = 0;  
  
            ;WITH attributesCte AS  
            (  
                SELECT  
                     ID Child_ID  
                    ,CASE WHEN ID = @Attribute_ID   
                        THEN @FilterParentAttribute_ID -- Use the new value for the attribute being updated  
                        ELSE FilterParentAttribute_ID -- Use the current value  
                        END Parent_ID  
                FROM mdm.tblAttribute  
                WHERE   Entity_ID = @Entity_ID  
                    AND MemberType_ID = @MemberType_ID  
            )  
            ,parentChildCte AS  
            (  
                -- The recursive base case is the attribute being updated.  
                SELECT  
                     @Attribute_ID Child_ID  
                    ,@FilterParentAttribute_ID Parent_ID  
                    ,0 RecursionLevel  
  
                UNION ALL  
  
                SELECT  
                     child.Child_ID  
                    ,CASE WHEN child.Child_ID = ancestor.Parent_ID THEN NULL ELSE ancestor.Parent_ID END Parent_ID  
                    ,child.RecursionLevel + 1  
                FROM parentChildCte child  
                INNER JOIN attributesCte ancestor  
                ON      child.Parent_ID = ancestor.Child_ID  
                    AND child.RecursionLevel < 99 -- Protects against "The statement terminated. The maximum recursion 100 has been exhausted before statement completion" error.  
                WHERE ancestor.Parent_ID IS NOT NULL-- ignore rows without a parent, they cannot be part of a circular relationship  
            )  
            SELECT TOP 1  
                @IsCircularReference = 1  
            FROM parentChildCte  
            WHERE Parent_ID IS NULL  
  
            If @IsCircularReference = 0  
            BEGIN  
                -- Check for circular references across entities (it would cause problems for Model Deployment)  
                ;WITH filteredAttributesCte AS  
                (  
                    SELECT  
                         a.ID               Child_ID  
                        ,a.Entity_ID        ChildEntity_ID  
                        ,a.DomainEntity_ID  ChildDomainEntity_ID  
                    FROM mdm.tblAttribute a  
                    WHERE (a.ID = @Attribute_ID OR FilterParentAttribute_ID IS NOT NULL)  
                        AND a.DomainEntity_ID <> a.Entity_ID -- ignore recursive filtered attributes  
                )  
                ,parentChildCte AS  
                (  
                    -- The recursive base case is the attribute being updated.  
                    SELECT   
                         Child_ID  
                        ,ChildEntity_ID  
                        ,ChildDomainEntity_ID  
                        ,0 RecursionLevel  
                    FROM filteredAttributesCte  
                    WHERE Child_ID = @Attribute_ID  
  
                    UNION ALL  
  
                    SELECT  
                         child.Child_ID  
                        ,child.ChildEntity_ID  
                        ,CASE WHEN child.ChildEntity_ID = ancestor.ChildEntity_ID THEN NULL ELSE ancestor.ChildDomainEntity_ID END ChildDomainEntity_ID  
                        ,child.RecursionLevel + 1  
                    FROM parentChildCte child  
                    INNER JOIN filteredAttributesCte ancestor  
                    ON      child.ChildDomainEntity_ID = ancestor.ChildEntity_ID  
                        AND child.RecursionLevel < 99 -- Protects against "The statement terminated. The maximum recursion 100 has been exhausted before statement completion" error.  
                )  
                SELECT TOP 1  
                    @IsCircularReference = 1  
                FROM parentChildCte  
                WHERE ChildDomainEntity_ID IS NULL  
            END  
  
            IF @IsCircularReference = 1  
            BEGIN  
                RAISERROR('MDSERR200124|The attribute cannot be saved. The attribute filter forms a circular dependency, which is not allowed.', 16, 1);  
                RETURN;  
            END  
        END  
  
        -- If an existing attribute is being updated with a new filter, check for conflicts with existing attribute values. Note: this does not need to be checked in Create mode, because a new attribute's values are null.  
        IF    (@FilterParentAttribute_ID <> COALESCE(@ExistingFilterParentAttribute_ID, 0)   
            OR @FilterHierarchyDetail_ID <> COALESCE(@ExistingFilterHierarchyDetail_ID, 0))  
        BEGIN  
            DECLARE   
                 @MemberCodeWithInconpatibleValue   NVARCHAR(250)  
                ,@MemberVersionName                 NVARCHAR(50)  
                ,@FilterParentColumnName            SYSNAME = (SELECT TableColumn FROM mdm.tblAttribute WHERE ID = @FilterParentAttribute_ID)  
                ,@FilterHierarchyEntityTableName    SYSNAME  
                ,@FilterHierarchyParentColumnName   SYSNAME  
                ,@FilterHierarchyM2MChildColumnName SYSNAME  
  
            SELECT   
                 @FilterHierarchyEntityTableName = parentEntity.EntityTable  
                ,@FilterHierarchyParentColumnName = parentAttribute.TableColumn   
                ,@FilterHierarchyM2MChildColumnName = m2mChildAttribute.TableColumn  
            FROM mdm.tblDerivedHierarchyDetail dhd  
            INNER JOIN mdm.tblAttribute parentAttribute  
            ON dhd.Foreign_ID = parentAttribute.ID   
            INNER JOIN mdm.tblEntity parentEntity  
            ON parentAttribute.Entity_ID = parentEntity.ID  
            LEFT JOIN mdm.tblAttribute m2mChildAttribute  
            ON dhd.ManyToManyChildAttribute_ID = m2mChildAttribute.ID  
            WHERE dhd.ID = @FilterHierarchyDetail_ID;  
  
            SET @SQL = CONCAT(N'  
        SELECT TOP 1   
             @MemberCodeWithInconpatibleValue = en.Code  
            ,@MemberVersionName = v.Name  
        FROM mdm.', QUOTENAME(@TableName), N' en  
        INNER JOIN mdm.tblModelVersion v  
        ON en.Version_ID = v.ID  
        LEFT JOIN mdm.', QUOTENAME(@FilterHierarchyEntityTableName), N' fen  
        ON      en.Version_ID = fen.Version_ID  
            AND en.', QUOTENAME(@TableColumn), N' = fen.', QUOTENAME(COALESCE(@FilterHierarchyM2MChildColumnName, N'ID')), N' -- If DBA level, this should always have exactly one match. If M2M level, it could have zero to many matches.  
            AND ISNULL(en.', QUOTENAME(@FilterParentColumnName), N', 0) = ISNULL(fen.', QUOTENAME(@FilterHierarchyParentColumnName), N', 0)  
        WHERE   en.', QUOTENAME(@TableColumn), N' IS NOT NULL -- a null child value is always valid  
            AND fen.ID IS NULL -- could not find a matching row in the domain/mapping entity  
        ORDER BY en.Version_ID DESC');  
  
            --Execute the dynamic SQL  
            EXEC sp_executesql @SQL, N'@MemberCodeWithInconpatibleValue NVARCHAR(250) OUTPUT, @MemberVersionName NVARCHAR(50) OUTPUT', @MemberCodeWithInconpatibleValue OUTPUT, @MemberVersionName OUTPUT;  
  
            IF @MemberCodeWithInconpatibleValue IS NOT NULL  
            BEGIN  
                DECLARE @Message NVARCHAR(MAX) = CONCAT('MDSERR200117|The attribute cannot be updated. The attribute filter is not compatible with one or more current attribute values. First member code: {0}, version: {1}.|', REPLACE(@MemberCodeWithInconpatibleValue, N'|', N''), N'|', REPLACE(@MemberVersionName, N'|', N''))  
                RAISERROR(@Message, 16, 1);  
                RETURN;  
            END  
        END  
    END -- If updating with a filter  
  
  
    --Start transaction, being careful to check if we are nested  
    DECLARE @TranCounter INT;  
    SET @TranCounter = @@TRANCOUNT;  
    IF @TranCounter > 0 SAVE TRANSACTION TX;  
    ELSE BEGIN TRANSACTION;  
  
    BEGIN TRY  
  
        DECLARE @SortOrderProvided BIT = 1;  
  
        IF (@SortOrder IS NULL OR @SortOrder = 0)  
        BEGIN  
            SET @SortOrderProvided = 0;  
            SELECT @SortOrder = MAX(SortOrder) + 1  
            FROM mdm.tblAttribute  
            WHERE   Entity_ID = @Entity_ID  
                AND MemberType_ID = @MemberType_ID  
  
            -- If we still couldn't find  a sort order, default to 1  
            IF (@SortOrder IS NULL)  
            BEGIN  
                SET @SortOrder = 1  
            END  
        END  
  
        --Update/Insert Attribute details  
        IF @EditMode = @EditMode_Update  
        --Update Attribute  
        BEGIN  
  
            IF @IsSystem = 1  
            --System Attribute  
            BEGIN  
  
                --The only change we allow on system attributes is the DisplayWidth, DisplayName, Description and MUID (clone scenario).  
                UPDATE mdm.tblAttribute   
                SET  
                    MUID = ISNULL(@Attribute_MUID, MUID),  
                    DisplayWidth = ISNULL(@DisplayWidth, DisplayWidth),  
                    DisplayName = COALESCE(@DisplayName,DisplayName,Name),  
                    [Description] = COALESCE(@Description, [Description]),  
                    LastChgDTM = @CurrentDTM,  
                    LastChgUserID = @User_ID,  
                    LastChgVersionID = @Version_ID,  
                    ChangeTrackingGroup  = @ChangeTrackingGroup  
                WHERE ID = @Attribute_ID;  
  
                SELECT @AttributeName = @PreviousAttributeName;  
  
            END ELSE  
            --Non-system Attribute  
            BEGIN  
                IF (@SortOrderProvided = 1)  
                BEGIN  
                    DECLARE @NextExistingOrder int;  
                    DECLARE @NextExistingID int;  
                    IF @CurrentSortOrder > @SortOrder  
                    BEGIN  
                        SELECT TOP 1  
                           @NextExistingID = ID,  
                           @NextExistingOrder = SortOrder  
                        FROM tblAttribute  
                        WHERE  
                            Entity_ID = @Entity_ID AND  
                            MemberType_ID = @MemberType_ID AND -- Only take into accounts attributes on the same entity of the same member type  
                            SortOrder < @CurrentSortOrder  
                        ORDER BY SortOrder DESC;  
  
                        UPDATE tblAttribute SET SortOrder = @NextExistingOrder WHERE ID = @Attribute_ID;  
                        UPDATE tblAttribute SET SortOrder = @CurrentSortOrder WHERE ID = @NextExistingID;  
                    END  
  
                    ELSE IF @CurrentSortOrder < @SortOrder  
                    BEGIN  
                        SELECT TOP 1  
                            @NextExistingID = ID,  
                            @NextExistingOrder = SortOrder  
                        FROM tblAttribute  
                        WHERE  
                            Entity_ID = @Entity_ID AND  
                            MemberType_ID = @MemberType_ID AND -- Only take into accounts attributes on the same entity of the same member type  
                            SortOrder > @CurrentSortOrder  
                        ORDER BY SortOrder ASC;  
  
                        IF (@NextExistingOrder IS NULL)  
                        BEGIN  
                            UPDATE tblAttribute SET SortOrder = @SortOrder WHERE ID = @Attribute_ID;  
                        END ELSE  
                        BEGIN  
                            UPDATE tblAttribute SET SortOrder = @NextExistingOrder WHERE ID = @Attribute_ID;  
                            UPDATE tblAttribute SET SortOrder = @CurrentSortOrder WHERE ID = @NextExistingID;  
                       END  
                    END  
                END  
                ELSE  
                --if SortOrderProvided = 0. This is for the case when we are updating an attribute type and therefor the old attribute is created and we don't want to swap it with anything else  
                BEGIN  
                    UPDATE tblAttribute SET SortOrder = @SortOrder WHERE ID = @Attribute_ID;  
                END  
  
                --Update details in the Attribute table  
                UPDATE mdm.tblAttribute   
                SET  
                    [Name] = ISNULL(@AttributeName, [Name]),  
                    [Description] =  COALESCE(@Description, [Description]),  
                    DisplayName = ISNULL(@DisplayName, DisplayName),  
                    DisplayWidth = @DisplayWidth,  
                    InputMask_ID = ISNULL(@InputMask_ID, InputMask_ID),  
                    FilterParentAttribute_ID = @FilterParentAttribute_ID,  
                    FilterHierarchyDetail_ID = @FilterHierarchyDetail_ID,  
                    LastChgDTM = @CurrentDTM,  
                    LastChgUserID = @User_ID,  
                    LastChgVersionID = @Version_ID,  
                    ChangeTrackingGroup = @ChangeTrackingGroup  
                WHERE   
                    ID = @Attribute_ID;  
  
                --Update column name of the staging table when @StagingTableName is specified.  
                IF @AttributeName IS NOT NULL AND @PreviousAttributeName <> @AttributeName AND COALESCE(@StagingTableName, N'') <> N''   
                BEGIN  
                    SET @SQL = N'EXEC sp_rename N' + QUOTENAME(N'stg.' + QUOTENAME(@StagingTableName) + N'.' + QUOTENAME(@PreviousAttributeName), N'''') + N', N' + QUOTENAME(@AttributeName, N'''') + N', ''COLUMN'';';  
                    --Execute the dynamic SQL  
                    EXEC sp_executesql @SQL;  
                END; --IF  
            END; --if  
  
            --Populate output parameters  
            SELECT @Return_MUID = MUID FROM mdm.tblAttribute WHERE ID = @Attribute_ID;  
  
        END  
        ELSE  
        --New Attribute  
        BEGIN  
            --Coalesce defaults for specific parameters  
            SELECT  
                --Accept an explicit MUID (for clone operations) or generate a new one  
                @Return_MUID = ISNULL(@Attribute_MUID, NEWID()),  
                @DataType_ID = ISNULL(@DataType_ID, @DataTypeText),  
                @DataTypeInformation = ISNULL(@DataTypeInformation, 0),  
                @InputMask_ID = ISNULL(@InputMask_ID, 1),  
                @DisplayName = ISNULL(@DisplayName,@AttributeName);  
  
            -- Always use Link data type for file attributes.  
            IF (@AttributeType_ID = @AttributeTypeFile)   
            BEGIN  
                SET @DataType_ID = @DataTypeLink;  
            END;  
  
            --Insert details into Attribute table  
            INSERT INTO mdm.tblAttribute  
            (  
                Entity_ID,  
                SortOrder,  
                DomainEntity_ID,  
                FilterParentAttribute_ID,  
                FilterHierarchyDetail_ID,  
                AttributeType_ID,  
                MemberType_ID,  
                IsSystem,  
                IsReadOnly,  
                [Name],  
                [Description],  
                DisplayName,  
                TableColumn,  
                DisplayWidth,  
                DataType_ID,  
                DataTypeInformation,  
                InputMask_ID,  
                MUID,  
                EnterUserID,  
                EnterVersionID,  
                LastChgUserID,  
                LastChgVersionID,  
                ChangeTrackingGroup  
            )  
            SELECT  
                @Entity_ID,  
                @SortOrder,  
                CASE  
                    WHEN @DomainEntity_ID > 0 THEN @DomainEntity_ID  
                    ELSE NULL --Distinguish between FILE and F/F using AttributeType_ID  
                END, --case  
                @FilterParentAttribute_ID,  
                @FilterHierarchyDetail_ID,  
                @AttributeType_ID,  
                @MemberType_ID,  
                0, --IsSystem = False  
                0, --IsReadOnly = False  
                @AttributeName,  
                @Description,  
                @DisplayName,  
                N'', --Temporary value since this is a required column  
                @DisplayWidth,  
                @DataType_ID,  
                @DataTypeInformation,  
                @InputMask_ID,  
                @Return_MUID,  
                @User_ID,  
                @Version_ID,  
                @User_ID,  
                @Version_ID,  
                @ChangeTrackingGroup  
  
            --Save the identity value  
            SET @Attribute_ID = SCOPE_IDENTITY();  
  
            --Generate the physical column name and replace the default generated value.  
            --Note that a random value would work fine, but a reproducible value makes debugging simpler.  
            --Note that @Attribute_ID required to maintain uniqueness. For example user creates attribute 'Color'  
            --which instantiates as column [A]. They rename 'Color' to 'Size' but the column stays as [A].  
            --They then create a new attribute called 'Color' which - if @Attribute_ID was not used to uniqify  
            --the generated name it would try to instantiate the column as [A] again --> Error.  
            SET @TableColumn = CONCAT(N'uda_', @Entity_ID, N'_', @Attribute_ID);  
            SET @VersionColumnName = N'Version_ID'  
  
            UPDATE mdm.tblAttribute SET TableColumn = @TableColumn WHERE ID = @Attribute_ID;  
  
            --Add the column to the Entity table.  
            SET @AddColumnSQL = N' ADD ' + QUOTENAME(@TableColumn) + N' ';  
            IF @AttributeType_ID = @AttributeTypeFreeform   
            BEGIN  
                IF @DataType_ID = @DataTypeText OR @DataType_ID = @DataTypeLink   
                BEGIN  
                    IF @DataTypeInformation < 1  
                    BEGIN  
                        SET @AddColumnSQL += N'NVARCHAR(MAX) NULL;';  
                    END  
                    ELSE  
                    BEGIN  
                    SET @AddColumnSQL += N'NVARCHAR(' + CONVERT(NVARCHAR(30), @DataTypeInformation) + N') NULL;';  
                    END  
                END ELSE IF @DataType_ID = @DataTypeNumber   
                BEGIN  
                    IF @DataTypeInformation < 0   
                    BEGIN  
                        SET @DataTypeInformation = 0; --DECIMAL(38, 0) is minimum precision allowed by SQL  
                    END ELSE   
                    IF @DataTypeInformation > 38   
                    BEGIN  
                        SET @DataTypeInformation = 38; --DECIMAL(38, 38) is maximum precision allowed by SQL  
                    END  
                    SET @AddColumnSQL += N'DECIMAL(38, ' + CONVERT(NVARCHAR(2), @DataTypeInformation) + N') NULL;';  
                END ELSE IF @DataType_ID = @DataTypeDateTime   
                BEGIN  
                    SET @AddColumnSQL += N'DATETIME2(3) NULL;';  
                END; --if  
            END ELSE   
            BEGIN --DBA/FILE  
                SET @AddColumnSQL += N'INT NULL;';  
            END --if  
  
            SET @SQL = N'ALTER TABLE mdm.' + QUOTENAME(@TableName) + @AddColumnSQL;  
            --Execute the dynamic SQL  
            EXEC sp_executesql @SQL;  
  
            SET @HistoryTableName = CONCAT(@TableName, N'_HS');  
            SET @SQL = N'ALTER TABLE mdm.' + QUOTENAME(@HistoryTableName) + @AddColumnSQL;  
            --Execute the dynamic SQL  
            EXEC sp_executesql @SQL;  
  
            IF @MemberType_ID = @MemberTypeLeaf  
            BEGIN  
                SET @PendingTableName = CONCAT(@TableName, N'_PD');  
                SET @SQL = N'ALTER TABLE mdm.' + QUOTENAME(@PendingTableName) + @AddColumnSQL;  
                --Execute the dynamic SQL  
                EXEC sp_executesql @SQL;  
            END  
  
            --Create the FK & FK index for DBA & FIL attributes.  
            IF @AttributeType_ID = @AttributeTypeDomain   
            BEGIN  
  
                --Foreign key constraint definition  
                SELECT @SQL = CONCAT(N'  
                    ALTER TABLE mdm.', QUOTENAME(@TableName), N' ADD CONSTRAINT  
                        ', QUOTENAME(CONCAT(N'fk_', @TableName, N'_', EntityTable, N'_Version_ID_', @TableColumn)), N'  
                        FOREIGN KEY (', QUOTENAME(@VersionColumnName), N', ', QUOTENAME(@TableColumn), N')  
                        REFERENCES mdm.', QUOTENAME(EntityTable), N'(Version_ID, ID);')  
                FROM mdm.tblEntity   
                WHERE ID = @DomainEntity_ID;  
  
                --Foreign key index definition  
                SET @SQL += CONCAT(N'  
                    -- For udpVersionCopy  
                    CREATE NONCLUSTERED INDEX ', QUOTENAME(CONCAT(N'ix_', @TableName, N'_Version_ID_', @TableColumn)), N'  
                        ON mdm.', QUOTENAME(@TableName), N'(', QUOTENAME(@VersionColumnName), N', ', QUOTENAME(@TableColumn), N')  
                        INCLUDE(ID)  
                        ', @IndexOptions, N';');  
  
                IF @MemberType_ID = @MemberTypeLeaf  
                BEGIN  
                    --Foreign key index definition  
                    SET @SQL += CONCAT(N'  
                        -- For udpVersionCopy  
                        CREATE NONCLUSTERED INDEX ', QUOTENAME(CONCAT(N'ix_', @PendingTableName, N'_Version_ID_', @TableColumn)), N'  
                            ON mdm.', QUOTENAME(@PendingTableName), N'(', QUOTENAME(@VersionColumnName), N', ', QUOTENAME(@TableColumn), N')  
                            INCLUDE(ID)  
                            ', @IndexOptions, N';');  
                END  
  
                EXEC sp_executesql @SQL;  
  
            END ELSE IF @AttributeType_ID = @AttributeTypeFile   
            BEGIN  
  
                --Foreign key constraint definition  
                SET @SQL = N'  
                    ALTER TABLE mdm.' + QUOTENAME(@TableName) + N' ADD CONSTRAINT  
                        ' + QUOTENAME(N'fk_' + @TableName + N'_tblFile_' + @TableColumn) + N'  
                        FOREIGN KEY (' + QUOTENAME(@TableColumn) + N')  
                        REFERENCES mdm.tblFile(ID);';  
  
                --Foreign key index definition  
                SET @SQL += N'  
                    CREATE NONCLUSTERED INDEX ' + QUOTENAME(N'ix_' + @TableName + N'_Version_ID_' + @TableColumn ) + N'  
                        ON mdm.' + QUOTENAME(@TableName) + N'(' + QUOTENAME(@VersionColumnName) + N', ' + QUOTENAME(@TableColumn) + N')  
                        INCLUDE(ID)  
                        ' + @IndexOptions + N';';  
  
                IF @MemberType_ID = @MemberTypeLeaf  
                BEGIN  
                    --Foreign key index definition  
                    SET @SQL += N'  
                        CREATE NONCLUSTERED INDEX ' + QUOTENAME(N'ix_' + @PendingTableName + N'_Version_ID_' + @TableColumn ) + N'  
                            ON mdm.' + QUOTENAME(@PendingTableName) + N'(' + QUOTENAME(@VersionColumnName) + N', ' + QUOTENAME(@TableColumn) + N')  
                            INCLUDE(ID)  
                            ' + @IndexOptions + N';';  
                END  
  
                EXEC sp_executesql @SQL;  
  
            END; --if  
  
            --Add the column to the Staging table.  
            IF LEN(COALESCE(@StagingTableName, N'')) > 0  
            BEGIN  
                SET @SQL = N'ALTER TABLE stg.' + QUOTENAME(@StagingTableName) + N' ADD ' + QUOTENAME(@AttributeName) + N' ';  
                IF @AttributeType_ID = @AttributeTypeFreeform   
                BEGIN  
                    IF @DataType_ID = @DataTypeText OR @DataType_ID = @DataTypeLink   
                    BEGIN  
                        IF @DataTypeInformation < 1  
                        BEGIN  
                            SET @SQL += N'NVARCHAR(MAX) NULL;';  
                        END  
                        ELSE  
                        BEGIN  
                            SET @SQL += CONCAT(N'NVARCHAR(', @DataTypeInformation, N') NULL;');  
                        END  
                    END ELSE   
                    IF @DataType_ID = @DataTypeNumber   
                    BEGIN  
                        IF @DataTypeInformation < 0   
                        BEGIN  
                            SET @DataTypeInformation = 0; --DECIMAL(38, 0) is minimum precision allowed by SQL  
                        END ELSE   
                        IF @DataTypeInformation > 38  
                        BEGIN  
                            SET @DataTypeInformation = 38; --DECIMAL(38, 38) is maximum precision allowed by SQL  
                        END  
                        SET @SQL += CONCAT(N'DECIMAL(38, ', @DataTypeInformation, N') NULL;');  
                    END ELSE   
                    IF @DataType_ID = @DataTypeDateTime   
                    BEGIN  
                        SET @SQL += N'DATETIME2(3) NULL;';  
                    END; --if  
                END ELSE   
                BEGIN --DBA/FILE  
                    SET @SQL += N'NVARCHAR(250) NULL;';  
                END --if  
  
                --Execute the dynamic SQL  
                EXEC sp_executesql @SQL;  
  
            END; --IF  
  
            --Populate output parameters  
            SELECT @CurrentDataType_ID = @DataType_ID;  
  
        END; --if new attribute  
  
        --Recreate the views  
        EXEC mdm.udpCreateViews @Model_ID, @Entity_ID;  
  
        --Recreate the subscription views of entity  
        EXEC mdm.udpCreateAllSubscriptionViews NULL, @Entity_ID;  
  
        --Return values  
        SET @Return_ID = @Attribute_ID;  
  
        IF @RecreateStagingProc = 1  
        BEGIN  
            -- Recreate the staging stored procedure.  
            IF @MemberType_ID = @MemberTypeLeaf  
            BEGIN  
                EXEC mdm.udpEntityStagingCreateLeafStoredProcedure @Entity_ID  
            END -- IF  
            ELSE IF @MemberType_ID = @MemberTypeConsolidated  
            BEGIN  
                EXEC mdm.udpEntityStagingCreateConsolidatedStoredProcedure @Entity_ID  
            END -- IF  
        END  
  
        --Commit only if we are not nested  
        IF @TranCounter = 0  
        BEGIN  
            COMMIT TRANSACTION;  
            SET @TranCommitted = 1;  
        END; -- IF  
  
        IF @EditMode = @EditMode_Update AND @AttributeName <> @ExistingAttributeName  
        BEGIN  
            SET @Return_DidNameChange = 1;  
        END  
  
        RETURN;  
  
    END TRY  
    --Compensate as necessary  
    BEGIN CATCH  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        IF @TranCommitted = 0 -- Don't rollback when the transaction has been committed.  
        BEGIN  
            IF @TranCounter = 0 ROLLBACK TRANSACTION;  
            ELSE IF XACT_STATE() <> -1 ROLLBACK TRANSACTION TX;  
        END; -- IF  
  
        --On error, return NULL results  
        SELECT @Attribute_ID = NULL, @Return_MUID = NULL, @TableColumn = NULL, @AttributeName = NULL, @CurrentDataType_ID = NULL, @CurrentDataTypeInfo = NULL, @Model_ID = NULL;  
  
        --Throw the error again so the calling procedure can use it  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
  
        RETURN;  
  
    END CATCH;  
  
    SET NOCOUNT OFF;  
END; --proc
go

