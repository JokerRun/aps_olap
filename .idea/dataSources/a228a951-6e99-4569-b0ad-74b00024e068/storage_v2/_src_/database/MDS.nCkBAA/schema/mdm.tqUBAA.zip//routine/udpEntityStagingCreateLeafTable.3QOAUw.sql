/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Helper sproc that creates the Leaf staging table of the given name.   
*/  
CREATE PROCEDURE mdm.udpEntityStagingCreateLeafTable  
(  
    @StagingTableName   sysname, -- The name of the leaf staging table to create  
    @TableOptions           NVARCHAR(MAX) = N'', -- Optional compress string used in creating the table.  
    @IndexOptions           NVARCHAR(MAX) = N'', -- Optional compress string used in creating the table indexes.  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
AS BEGIN  
    SET NOCOUNT ON;  
  
    SET @TableOptions = COALESCE(@TableOptions, N'');  
    SET @IndexOptions = COALESCE(@IndexOptions, N'');  
  
    -- This pseudo-constant is for use in string concatenation operations to prevent string truncation. When concatenating two or more strings,  
    -- if none of the strings is an NVARCHAR(MAX) or an NVARCHAR constant that is longer than 4,000 characters, then the resulting string   
    -- will be silently truncated to 4,000 characters. Concatenating with this empty NVARCHAR(MAX), is sufficient to prevent truncation.  
    -- See http://connect.microsoft.com/SQLServer/feedback/details/283368/nvarchar-max-concatenation-yields-silent-truncation.  
    DECLARE @TruncationGuard NVARCHAR(MAX) = N'';  
  
    DECLARE @SQL NVARCHAR(MAX) = @TruncationGuard + N'  
        CREATE TABLE [stg].' + QUOTENAME(@StagingTableName) + N'    
        (    
            --Identity    
            ID                  INT IDENTITY (1, 1) NOT NULL,  
                          
            --Import Specific  
            ImportType          TINYINT NOT NULL,  
  
            --Status    
            ImportStatus_ID     TINYINT NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @StagingTableName  + N'_ImportStatus_ID') + N' DEFAULT 0,   
        
            --Info  
            Batch_ID            INT NULL,  
            BatchTag            NVARCHAR(50) NOT NULL,  
  
            --Error Code  
            ErrorCode           INT NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @StagingTableName  + N'_ErrorCode') + N' DEFAULT 0,   
            Code                NVARCHAR(250) NULL,  
            [Name]              NVARCHAR(250) NULL,    
            NewCode             NVARCHAR(250) NULL,      
                                                                                                            
            --Create PRIMARY KEY constraint    
            CONSTRAINT ' + QUOTENAME(N'pk_' + @StagingTableName) + N'     
                PRIMARY KEY CLUSTERED (ID),    
                        
            --Create CHECK constraints    
            CONSTRAINT ' + QUOTENAME(N'ck_' + @StagingTableName + N'_ImportType') + N'     
                CHECK (ImportType BETWEEN 0 AND 6),    
                              
            CONSTRAINT ' + QUOTENAME(N'ck_' + @StagingTableName + N'_ImportStatus_ID') + N'     
                CHECK (ImportStatus_ID BETWEEN 0 and 3)     
        )    
        ' + @TableOptions + N';  
                      
        --Index [Batch_ID] for performance  
        CREATE NONCLUSTERED INDEX ' + QUOTENAME(N'ix_' + @StagingTableName + N'_Batch_ID') + N'   
            ON [stg].' + QUOTENAME(@StagingTableName) + N'(Batch_ID)  
            ' + @IndexOptions + N';  
                      
        --Index [BatchTag], [ImportStatus_ID] for performance  
        CREATE NONCLUSTERED INDEX ' + QUOTENAME(N'ix_' + @StagingTableName + N'_BatchTag_ImportStatus_ID') + N'   
            ON [stg].' + QUOTENAME(@StagingTableName) + N'(BatchTag, ImportStatus_ID)  
            ' + @IndexOptions + N';  
  
        --Index [Code] for performance  
        CREATE NONCLUSTERED INDEX ' + QUOTENAME(N'ix_' + @StagingTableName + N'_Code') + N'   
            ON [stg].' + QUOTENAME(@StagingTableName) + N'(Code)  
            ' + @IndexOptions + N';  
        ';    
       
    --Execute the dynamic SQL    
    --PRINT(@SQL);    
    EXEC sp_executesql @SQL;    
  
    SET NOCOUNT OFF;  
END;
go

