/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
This can be called to get Annotations for a revision.  
EXEC mdm.udpEntityMemberAnnotationsGet @User_ID = 1, @Model_Name = N'Product', @Entity_Name = N'Product', @Version_Name = N'Version 1', @MemberType_ID= 1, @Revision_ID = 0  
*/  
CREATE PROCEDURE mdm.udpEntityMemberAnnotationsGet  
(  
    @User_ID        INT,  
    @Model_Name     NVARCHAR(50) = NULL,  
    @Model_MUID     UNIQUEIDENTIFIER = NULL,  
    @Entity_Name    NVARCHAR(50) = NULL,  
    @Entity_MUID    UNIQUEIDENTIFIER= NULL,  
    @Version_Name   NVARCHAR(50) = NULL,  
    @Version_MUID   UNIQUEIDENTIFIER = NULL,  
    @MemberType_ID  TINYINT,  
    @Revision_ID    BIGINT,  
    @CorrelationID  UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
  
    DECLARE @GuidEmpty                      UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER),  
            @Model_ID                       INT,  
            @Entity_ID                      INT,  
            @Version_ID                     INT,  
            @Member_ID                      INT,  
  
            @MemberIDColumn                 SYSNAME,  
            @EntityMemberTableName          SYSNAME,  
            @EntityMemberHistoryTableName   SYSNAME,  
            @AnnotationTableName            SYSNAME,  
  
            @ModelPrivilege_ID              TINYINT,  
            @Privilege_ID                   TINYINT,  
            @AccessPermission               TINYINT,  
            @Permission_Access              TINYINT = 4,  
            @Permission_Inferred            TINYINT = 99,  
            @Permission_Admin               TINYINT = 5,  
            @AccessPermission_Read          TINYINT = 0,  
            @AccessPermission_ReadUpdateDelete  TINYINT = 6,  
  
            @MemberType_Leaf                TINYINT = 1,  
            @MemberType_Consolidated        TINYINT = 2,  
            @MemberType_Collection          TINYINT = 3,  
            @MemberType_Hierarchy           TINYINT = 4,  
            @MemberType_CollectionMember    TINYINT = 5,  
  
            @IsModelAdmin                   BIT = 0,  
  
            @SQL                            NVARCHAR(MAX);  
  
    SELECT  
        @User_ID = NULLIF(@User_ID, 0),  
        @Model_MUID = NULLIF(@Model_MUID, @GuidEmpty),  
        @Model_Name = NULLIF(LTRIM(RTRIM(@Model_Name)), N''),  
        @Entity_MUID = NULLIF(@Entity_MUID, @GuidEmpty),  
        @Entity_Name = NULLIF(LTRIM(RTRIM(@Entity_Name)), N''),  
        @Version_MUID = NULLIF(@Version_MUID, @GuidEmpty),  
        @Version_Name = NULLIF(LTRIM(RTRIM(@Version_Name)), N''),  
        @MemberType_ID = NULLIF(@MemberType_ID, 0),  
        @Revision_ID = NULLIF(@Revision_ID, 0);  
  
    IF @User_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR100009|The User ID is not valid.', 16, 1);  
        RETURN;  
    END  
  
    IF @Revision_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR200223|Revision ID is not valid.', 16, 1);  
        RETURN;  
    END  
  
    IF @MemberType_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR210021|MemberType ID is not valid.', 16, 1);  
        RETURN;  
    END  
  
    EXEC mdm.udpInformationLookupModel @User_ID = @User_ID, @Model_MUID = @Model_MUID, @Model_Name = @Model_Name, @ID = @Model_ID OUTPUT, @Privilege_ID = @ModelPrivilege_ID OUTPUT;  
    IF @Model_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300005|The supplied model is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    IF @ModelPrivilege_ID = @Permission_Admin  
    BEGIN  
        SET @IsModelAdmin = 1;  
    END  
  
    SELECT @Version_ID = ID  
    FROM mdm.tblModelVersion   
    WHERE  
            (@Version_MUID IS NOT NULL OR @Version_Name IS NOT NULL)   
        AND (@Version_MUID IS NULL OR MUID = @Version_MUID)   
        AND (@Version_Name IS NULL OR Name = @Version_Name)  
        AND Model_ID = @Model_ID;  
    IF @Version_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300006|The supplied version is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    EXEC mdm.udpInformationLookupEntity @User_ID = @User_ID, @Model_ID = @Model_ID, @Entity_MUID = @Entity_MUID, @Entity_Name = @Entity_Name, @ID = @Entity_ID OUTPUT;  
    IF @Entity_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300008|The supplied entity is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    SET @EntityMemberTableName = mdm.udfTableNameGetByID(@Entity_ID, @MemberType_ID);  
    SET @EntityMemberHistoryTableName = CONCAT(@EntityMemberTableName, N'_HS');  
    SET @AnnotationTableName = CONCAT(@EntityMemberTableName, N'_AN');  
    SET @MemberIDColumn =  
        CASE @MemberType_ID  
            WHEN @MemberType_Leaf THEN N'EN_ID'  
            WHEN @MemberType_Consolidated THEN N'HP_ID'  
            WHEN @MemberType_Collection THEN N'CN_ID'  
            WHEN @MemberType_Hierarchy THEN N'HR_ID'  
            WHEN @MemberType_CollectionMember THEN N'CM_ID'  
        END;  
  
    SET @SQL = CONCAT(N'  
        SELECT @Member_ID = ID  
        FROM [mdm].', QUOTENAME(@EntityMemberTableName), N'  
        WHERE Version_ID = @Version_ID AND LastChgTS = @Revision_ID;  
              
        IF @Member_ID IS NULL  
        BEGIN  
            SELECT @Member_ID = ', QUOTENAME(@MemberIDColumn), N'  
            FROM [mdm].', QUOTENAME(@EntityMemberHistoryTableName), N'  
            WHERE Version_ID = @Version_ID AND ID = @Revision_ID;  
        END');  
  
    EXEC sp_executesql @SQL, N'@Version_ID INT, @Revision_ID BIGINT, @Member_ID INT OUTPUT',  
                               @Version_ID,     @Revision_ID,        @Member_ID OUTPUT;  
  
    IF @Member_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR200223|Revision ID is not valid.', 16, 1);  
        RETURN;  
    END  
  
    EXEC mdm.udpSecurityMemberResolverGet @User_ID, @Version_ID, NULL,NULL, @Entity_ID, @Member_ID, @MemberType_ID, @Privilege_ID OUTPUT, @AccessPermission OUTPUT;  
  
    IF NOT (@Privilege_ID = @Permission_Access OR @Privilege_ID = @Permission_Inferred)  
    BEGIN  
        RAISERROR('MDSERR120002|The user does not have permission to perform this operation.', 16, 1);  
        RETURN;  
    END  
  
    SET @SQL = CONCAT(N'  
        SELECT  
            a.ID,  
            a.Comment,  
            a.Revision_ID,  
            a.EnterDTM,  
            eu.UserName AS EnterUserName,  
            eu.ID AS EnterUserID,  
            eu.MUID AS EnterUserMUID,  
            a.LastChgDTM,  
            lu.UserName AS LastChgUserName,  
            lu.ID AS LastChgUserID,  
            lu.MUID AS LastChgUserMUID,  
            CONVERT(BIGINT, a.LastChgTS) AS LastChgTS,  
            @Permission_Access AS SecurityPermission,  
            CASE  
                WHEN @IsModelAdmin = 1 OR a.EnterUserID = @User_ID THEN @AccessPermission_ReadUpdateDelete  
                ELSE @AccessPermission_Read  
            END AS AccessPermission  
        FROM [mdm].', QUOTENAME(@AnnotationTableName), ' a  
        INNER JOIN [mdm].[tblUser] eu on eu.ID = a.EnterUserID  
        INNER JOIN [mdm].[tblUser] lu on lu.ID = a.LastChgUserID  
        WHERE  
            Version_ID = @Version_ID  
            AND Revision_ID = @Revision_ID  
        ');  
        EXEC sp_executesql @SQL, N'@User_ID INT, @Version_ID INT, @Revision_ID BIGINT, @IsModelAdmin BIT, @Permission_Access TINYINT, @AccessPermission_Read TINYINT, @AccessPermission_ReadUpdateDelete TINYINT',  
                                   @User_ID,     @Version_ID,     @Revision_ID,        @IsModelAdmin,     @Permission_Access,         @AccessPermission_Read,         @AccessPermission_ReadUpdateDelete;  
END --proc
go

