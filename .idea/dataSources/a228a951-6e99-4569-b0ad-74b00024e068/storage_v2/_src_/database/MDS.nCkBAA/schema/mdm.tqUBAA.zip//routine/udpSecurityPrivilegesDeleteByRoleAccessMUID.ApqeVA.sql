/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
Create PROCEDURE [mdm].[udpSecurityPrivilegesDeleteByRoleAccessMUID]  
(  
	@RoleAccess_MUID		UNIQUEIDENTIFIER,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
	SET NOCOUNT ON  
	  
	DELETE FROM mdm.tblSecurityRoleAccess WHERE MUID = @RoleAccess_MUID  
  
	SET NOCOUNT OFF  
END --proc
go

