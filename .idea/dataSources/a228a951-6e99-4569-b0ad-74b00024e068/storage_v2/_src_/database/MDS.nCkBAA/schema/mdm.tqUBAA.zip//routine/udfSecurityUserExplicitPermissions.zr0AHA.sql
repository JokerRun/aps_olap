/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Returns the object (model) permissions that apply to the given principal, optionally  
including permissions inherited from groups.  
  
SELECT * FROM mdm.udfSecurityUserExplicitPermissions(11,1,0,NULL)  
SELECT * FROM mdm.udfSecurityUserExplicitPermissions(27,1,1,NULL)  
SELECT * FROM mdm.udfSecurityUserExplicitPermissions(2,1,1,NULL)  
*/  
CREATE FUNCTION mdm.udfSecurityUserExplicitPermissions  
(  
     @SystemUser_ID              INT -- The ID of the user requesting the permission info  
    ,@Principal_ID               INT  
    ,@PrincipalType_ID           INT  
    ,@IncludeGroupAssignments    BIT  
)  
RETURNS @UserPermissions TABLE  
(  
     RoleAccess_ID          INT  
    ,RoleAccess_MUID        UNIQUEIDENTIFIER  
    ,Privilege_ID           INT  
    ,AccessPermission       TINYINT  
    ,Object_ID              INT  
    ,Securable_ID           INT  
    ,Securable_MUID         UNIQUEIDENTIFIER  
    ,Securable_Name         NVARCHAR(MAX) COLLATE DATABASE_DEFAULT  
    ,Model_ID               INT  
    ,Model_MUID             UNIQUEIDENTIFIER  
    ,Model_Name             NVARCHAR(50) COLLATE DATABASE_DEFAULT  
    ,IsModelAdministrator   BIT  
    ,PrincipalType_ID       INT  
    ,Principal_ID           INT  
    ,Principal_MUID         UNIQUEIDENTIFIER  
    ,Principal_Name         NVARCHAR(MAX) COLLATE DATABASE_DEFAULT  
    ,EnterUserID            INT  
    ,EnterUserMUID          UNIQUEIDENTIFIER  
    ,EnterUserName          NVARCHAR(MAX) COLLATE DATABASE_DEFAULT  
    ,EnterDTM               DATETIME2(3)  
    ,LastChgUserID          INT  
    ,LastChgUserMUID        UNIQUEIDENTIFIER  
    ,LastChgUserName        NVARCHAR(MAX) COLLATE DATABASE_DEFAULT  
    ,LastChgDTM             DATETIME2(3)  
)  
/*WITH SCHEMABINDING*/  
AS BEGIN  
  
    DECLARE  
         @PrincipalType_User    TINYINT = 1  
        ,@PrincipalType_Group   TINYINT = 2  
        ,@Privilege_Deny        TINYINT = 1;  
  
    INSERT INTO @UserPermissions  
    SELECT  
         rac.RoleAccess_ID  
        ,rac.RoleAccess_MUID  
        ,rac.Privilege_ID  
        ,rac.AccessPermission  
        ,rac.Object_ID  
        ,rac.Securable_ID  
        ,rac.Securable_MUID  
        ,rac.Securable_Name  
        ,rac.Model_ID  
        ,rac.Model_MUID  
        ,rac.Model_Name  
        ,rac.IsModelAdministrator  
        ,rac.PrincipalType_ID  
        ,rac.Principal_ID  
        ,rac.Principal_MUID  
        ,rac.Principal_Name  
        ,rac.EnterUserID  
        ,rac.EnterUserMUID  
        ,rac.EnterUserName  
        ,rac.EnterDTM  
        ,rac.LastChgUserID  
        ,rac.LastChgUserMUID  
        ,rac.LastChgUserName  
        ,rac.LastChgDTM  
    FROM mdm.viw_SYSTEM_SECURITY_ROLE_ACCESSCONTROL rac  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_MODEL modSec  
    ON      rac.Model_ID = modSec.ID  
    WHERE   modSec.User_ID = @SystemUser_ID  
        AND (modSec.Privilege_ID = 5 /*Admin*/                              -- User must be a model admin to see another user's permission on the model.  
             OR (   @SystemUser_ID = @Principal_ID                          -- User can see his own permissions (except Deny)  
                AND @PrincipalType_ID = @PrincipalType_User  
                AND COALESCE(rac.Privilege_ID, @Privilege_Deny) <> @Privilege_Deny))  
        AND rac.PrincipalType_ID = @PrincipalType_ID  
        AND rac.Principal_ID = @Principal_ID  
  
    IF (@PrincipalType_ID = @PrincipalType_User) AND (COALESCE(@IncludeGroupAssignments, 0) = 1)  
    BEGIN  
        -- Explicit permissions inherited from group assignments  
        INSERT INTO @UserPermissions  
        SELECT  
             rac.RoleAccess_ID  
            ,rac.RoleAccess_MUID  
            ,rac.Privilege_ID  
            ,rac.AccessPermission  
            ,rac.Object_ID  
            ,rac.Securable_ID  
            ,rac.Securable_MUID  
            ,rac.Securable_Name  
            ,rac.Model_ID  
            ,rac.Model_MUID  
            ,rac.Model_Name  
            ,rac.IsModelAdministrator  
            ,rac.PrincipalType_ID  
            ,rac.Principal_ID  
            ,rac.Principal_MUID  
            ,rac.Principal_Name  
            ,rac.EnterUserID  
            ,rac.EnterUserMUID  
            ,rac.EnterUserName  
            ,rac.EnterDTM  
            ,rac.LastChgUserID  
            ,rac.LastChgUserMUID  
            ,rac.LastChgUserName  
            ,rac.LastChgDTM  
        FROM mdm.viw_SYSTEM_SECURITY_ROLE_ACCESSCONTROL rac  
        INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ROLE sur  
        ON      rac.Role_ID = sur.Role_ID  
            AND sur.User_ID = @Principal_ID  
        INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_MODEL modSec  
        ON      rac.Model_ID = modSec.ID  
        WHERE   modSec.User_ID = @SystemUser_ID  
            AND (modSec.Privilege_ID = 5 /*Admin*/                              -- User must be a model admin to see another user's permission on the model.  
                 OR (   @SystemUser_ID = @Principal_ID                          -- User can see his own permissions (except Deny)  
                    AND @PrincipalType_ID = @PrincipalType_User  
                    AND COALESCE(rac.Privilege_ID, @Privilege_Deny) <> @Privilege_Deny))  
            AND rac.PrincipalType_ID = @PrincipalType_Group  
    END  
  
    RETURN  
END
go

