/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
  
CREATE PROCEDURE mdm.udpTablePartitionQueueSave  
(  
    @Model_ID       INT,  
    @Version_ID     INT  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON  
    --Insert a Message into the Service Broker Queue  
    DECLARE @xml AS XML;  
    SET @xml = (  
        SELECT  
            @Model_ID AS [Model_ID],  
            @Version_ID AS [Version_ID]  
        FOR XML PATH('TablePartition'), ELEMENTS  
    );  
  
    --try to get an existing conversation handle  
    DECLARE @conversationHandle UNIQUEIDENTIFIER = mdm.udfServiceGetConversationHandle(  
        N'microsoft/mdm/service/system',  
        N'microsoft/mdm/service/tablepartition');  
  
    --Start a new conversation if necessary  
    IF @conversationHandle IS NULL  
        BEGIN DIALOG @conversationHandle  
            FROM SERVICE [microsoft/mdm/service/system]   
            TO SERVICE N'microsoft/mdm/service/tablepartition'  
            ON CONTRACT [microsoft/mdm/contract/tablepartition]   
            WITH ENCRYPTION = OFF;  
  
    --Send a sample message  
    SEND ON CONVERSATION @conversationHandle MESSAGE TYPE [microsoft/mdm/message/tablepartition](@xml);  
  
    SET NOCOUNT OFF  
END --proc
go

