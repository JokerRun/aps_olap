/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    EXEC mdm.udpDeleteViews 1;  
    EXEC mdm.udpDeleteViews 2;  
    EXEC mdm.udpDeleteViews 3;  
    EXEC mdm.udpDeleteViews 4;  
    EXEC mdm.udpDeleteViews 5;  
  
    EXEC mdm.udpCreateAllViews;  
*/  
CREATE PROCEDURE mdm.udpDeleteViews  
(  
    @Model_ID               INT,  
    @Entity_ID              INT,  
    @DerivedHierarchy_ID    INT,  
    @ItemType_ID            TINYINT = 1, --1=ALL; 2=Collection views; 3=Hierarchy views  
    @CorrelationID          UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE @SQL        NVARCHAR(MAX),  
            @ViewName   SYSNAME;  
  
    SET @ItemType_ID = ISNULL(@ItemType_ID, 1);  
  
    DECLARE @ViewTable TABLE(RowNumber INT IDENTITY (1, 1) PRIMARY KEY CLUSTERED NOT NULL , ViewName SYSNAME COLLATE database_default);  
    INSERT INTO @ViewTable EXEC mdm.udpViewNamesGetByID @Model_ID, @Entity_ID, @DerivedHierarchy_ID, @ItemType_ID;  
  
    SET @SQL = CAST(N'' AS NVARCHAR(MAX));  
    DECLARE @Counter INT = 1;   
    DECLARE @MaxCounter INT = (SELECT MAX(RowNumber) FROM @ViewTable);  
          
    WHILE @Counter <= @MaxCounter  
    BEGIN  
        SELECT @ViewName = ViewName FROM @ViewTable WHERE [RowNumber] = @Counter;  
        SET @SQL = @SQL + N'  
            IF (SELECT OBJECT_ID(N''mdm.' + QUOTENAME(@ViewName) +''',''V'' )) IS NOT NULL  
                DROP VIEW mdm.' + QUOTENAME(@ViewName) + N';'  
        SET @Counter = @Counter +1;  
    END; --while  
  
    --PRINT(@SQL);  
    EXEC sp_executesql @SQL;  
  
    SET NOCOUNT OFF;  
END; --proc
go

