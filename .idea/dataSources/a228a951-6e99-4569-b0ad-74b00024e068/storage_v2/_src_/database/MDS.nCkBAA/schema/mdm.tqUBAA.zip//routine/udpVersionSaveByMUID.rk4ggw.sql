/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
 Wrapper for udpVersionSave sproc.  
*/  
CREATE PROCEDURE mdm.udpVersionSaveByMUID  
(  
    @User_ID                INT,  
    @Model_MUID             UNIQUEIDENTIFIER,  
    @Version_MUID           UNIQUEIDENTIFIER = NULL,  
    @Status_ID              TINYINT = NULL,  
    @Name                   NVARCHAR(50) = NULL,  
    @Description            NVARCHAR(250) = NULL,  
    @VersionFlag_MUID       UNIQUEIDENTIFIER = NULL,  
    @Return_ID              INT = NULL OUTPUT,  
    @Return_MUID            UNIQUEIDENTIFIER = NULL OUTPUT, --Also an input parameter for clone operations  
    @CorrelationID          UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE @FunctionalPrivilege_Versions  TINYINT = 2  
    IF mdm.udfSecurityUserFunctionIsAllowed(@User_ID, @FunctionalPrivilege_Versions) = 0  
    BEGIN  
        RAISERROR('MDSERR120002|The user does not have permission to perform this operation.', 16, 1);  
        RETURN;  
    END  
  
    DECLARE  
        @Model_ID           INT,  
        @Model_Privilege    INT,  
        @Version_ID         INT,  
        @VersionFlag_ID     INT;  
  
    DECLARE @EmptyMuid UNIQUEIDENTIFIER SET @EmptyMuid = CONVERT(UNIQUEIDENTIFIER, 0x0);  
  
    SELECT   
         @Model_ID = m.ID   
        ,@Model_Privilege = um.Privilege_ID  
    FROM mdm.viw_SYSTEM_SECURITY_USER_MODEL um  
    INNER JOIN mdm.tblModel m  
    ON um.ID = m.ID  
    WHERE   m.MUID = @Model_MUID  
        AND um.User_ID = @User_ID;  
  
    --Test for invalid parameters  
    IF (@Model_ID IS NULL) --Invalid Model_MUID  
    BEGIN  
        --On error, return NULL results  
        SELECT @Return_ID = NULL, @Return_MUID = NULL;  
        RAISERROR('MDSERR200004|The version cannot be saved. The model ID is not valid.', 16, 1);  
        RETURN;  
    END; --if        
  
    IF @Model_Privilege != 5 /*Admin*/  
    BEGIN  
        --On error, return NULL results  
        SELECT @Return_ID = NULL, @Return_MUID = NULL;  
        RAISERROR(N'MDSERR120003|The user does not have permission or the object ID is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    SELECT @Version_ID = ID  
    FROM mdm.tblModelVersion  
    WHERE   Model_ID = @Model_ID  
        AND MUID = @Version_MUID;  
  
    IF (@Version_MUID IS NOT NULL AND @Version_MUID <> @EmptyMuid AND @Version_ID IS NULL) --Invalid Version_MUID  
    BEGIN  
        --On error, return NULL results  
        SELECT @Return_ID = NULL, @Return_MUID = NULL;  
        RAISERROR('MDSERR200005|The version cannot be saved. The version ID is not valid.', 16, 1);  
        RETURN;  
    END; --if        
  
    IF @VersionFlag_MUID IS NOT NULL AND @VersionFlag_MUID <> @EmptyMuid  
    BEGIN  
        SELECT @VersionFlag_ID = ID FROM mdm.tblModelVersionFlag WHERE MUID = @VersionFlag_MUID;  
        IF (@VersionFlag_ID IS NULL) --Invalid Version_MUID  
        BEGIN  
            --On error, return NULL results  
            SELECT @Return_ID = NULL, @Return_MUID = NULL;  
            RAISERROR('MDSERR200070|The version cannot be saved. The version flag ID is not valid.', 16, 1);  
            RETURN;  
        END  
    END; --if        
      
    EXEC mdm.udpVersionSave  
            @User_ID = @User_ID,   
            @Model_ID = @Model_ID,  
            @Version_ID = @Version_ID,  
            @CurrentVersion_ID = NULL,   
            @Status_ID = @Status_ID,   
            @Name = @Name,   
            @Description = @Description,   
            @VersionFlag_ID = @VersionFlag_ID,  
            @Return_ID = @Return_ID OUTPUT,   
            @Return_MUID = @Return_MUID OUTPUT;  
  
    SET NOCOUNT OFF;  
END; --proc
go

