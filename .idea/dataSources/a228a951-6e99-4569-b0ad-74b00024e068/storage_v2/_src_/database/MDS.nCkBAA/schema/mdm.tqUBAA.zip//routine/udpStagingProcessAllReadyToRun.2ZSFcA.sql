/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
  
-- =============================================  
-- Author:        <John M. Hall (johnhall)>  
-- Create date: <10-21-09>  
-- Description:    <Process All Ready To Run Batches>  
-- =============================================  
CREATE PROCEDURE mdm.udpStagingProcessAllReadyToRun  
(  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
AS  
BEGIN  
    SET NOCOUNT ON;  
    /* WARNING --- YOU CANNOT INTRODUCE A TRY .. CATCH HERE WITHOUT   
     * SIGNIFICANTLY CHANGING THE BEHAVIOR OF UNDERLYING SPROCS. Contact [johnhall] with questions. */  
       
    DECLARE                
     @User_ID               INT    
    ,@Batch_ID              INT    
    ,@LogFlag               INT = NULL  
    ,@Version_ID            INT  
    ,@BatchTag              NVARCHAR(50)  
    ,@MemberType_ID         TINYINT  
    ,@Entity_ID             INT  
    ,@LeafSproc             SYSNAME  
    ,@ConsolidatedSproc     SYSNAME  
    ,@RelationshipSproc     SYSNAME  
    ,@LeafTable             SYSNAME  
    ,@ConsolidatedTable     SYSNAME  
    ,@RelationshipTable     SYSNAME  
    ,@SQL                   NVARCHAR(MAX)  
    ,@VersionName           NVARCHAR(50)  
  
  
    DECLARE  
        @QueuedToRun                TINYINT = 1,  
        @NotRunning                 TINYINT = 2,             
        @Running                    TINYINT = 3,  
        @QueueToClear               TINYINT = 4,  
        @Cleared                    TINYINT = 5,  
        @AllExceptCleared           TINYINT = 6,  
        @Completed                  TINYINT = 7  
  
    IF EXISTS(SELECT 1 FROM mdm.tblStgBatch WHERE Status_ID = 1)   
    BEGIN    
        -- @LogFlag is OnOff list box which value is On 1, Off 2.  
        SELECT  @LogFlag = CONVERT(INT, SettingValue) FROM mdm.tblSystemSetting WHERE SettingName = 'StagingTransactionLogging';  
        SELECT @LogFlag = CASE @LogFlag WHEN 1 THEN 1 ELSE 0 END;  
          
        WHILE EXISTS(SELECT 1 FROM mdm.tblStgBatch WHERE Status_ID = @QueuedToRun)   
        BEGIN    
   
            SELECT TOP 1    
                @User_ID = EnterUserID,    
                @Batch_ID = ID,    
                @Version_ID = Version_ID,  
                @BatchTag = BatchTag,  
                @MemberType_ID = MemberType_ID,  
                @Entity_ID = Entity_ID     
            FROM mdm.tblStgBatch WHERE Status_ID = @QueuedToRun;  
                
            SELECT            
                @LeafSproc = N'[stg].' + QUOTENAME(N'udp_' + StagingBase + N'_Leaf'),  
                @ConsolidatedSproc = N'[stg].' + QUOTENAME(N'udp_' + StagingBase + N'_Consolidated'),  
                @RelationshipSproc = N'[stg].' + QUOTENAME(N'udp_' + StagingBase + N'_Relationship'),    
                @LeafTable = N'[stg].' + QUOTENAME(StagingBase + N'_Leaf'),     
                @ConsolidatedTable = N'[stg].' + QUOTENAME(StagingBase + N'_Consolidated'),                        
                @RelationshipTable = N'[stg].' + QUOTENAME(StagingBase + N'_Relationship')     
            FROM mdm.tblEntity WHERE ID = @Entity_ID;  
                    
            SELECT   
                @VersionName = [Name]  
            FROM mdm.tblModelVersion WHERE ID = @Version_ID  
                                                          
            --Process EBS  
  
            --Update last run DTM and last run start user ID for the batch      
            UPDATE mdm.tblStgBatch SET LastRunStartDTM=GETUTCDATE(),LastRunStartUserID=@User_ID WHERE ID = @Batch_ID;      
  
            IF @MemberType_ID = 1 -- Leaf  
            BEGIN   
                EXEC @LeafSproc @VersionName = @VersionName, @LogFlag = @LogFlag, @BatchTag = @BatchTag, @User_ID = @User_ID  
            END; --IF  
                
            IF @MemberType_ID = 2 -- Consolidated  
            BEGIN   
                EXEC @ConsolidatedSproc @VersionName = @VersionName, @LogFlag = @LogFlag, @BatchTag = @BatchTag, @User_ID = @User_ID  
            END; --IF  
                
            IF @MemberType_ID = 4 -- Relationship  
            BEGIN   
                EXEC @RelationshipSproc @VersionName = @VersionName, @LogFlag = @LogFlag, @BatchTag = @BatchTag, @User_ID = @User_ID  
            END; --IF                  
                              
            --Update the Status for the batch    
            UPDATE mdm.tblStgBatch   
            SET     
                Status_ID = @Completed,    
                LastRunEndDTM=GETUTCDATE(),    
                LastRunEndUserID=@User_ID  
            WHERE     
                ID = @Batch_ID;    
        END; --while           
    END; --if    
        
    --Checked for Batches that need to be cleared            
    IF EXISTS(SELECT 1 FROM mdm.tblStgBatch WHERE Status_ID = @QueueToClear)   
    BEGIN                      
        WHILE EXISTS(SELECT 1 FROM mdm.tblStgBatch WHERE Status_ID = @QueueToClear)   
        BEGIN    
            SELECT TOP 1    
                @User_ID = EnterUserID,    
                @Batch_ID = ID,  
                @BatchTag = BatchTag,  
                @MemberType_ID = MemberType_ID,  
                @Entity_ID = Entity_ID     
            FROM mdm.tblStgBatch WHERE Status_ID = @QueueToClear;  
                  
            SELECT            
                @LeafTable = N'[stg].' + QUOTENAME(StagingBase + N'_Leaf'),     
                @ConsolidatedTable = N'[stg].' + QUOTENAME(StagingBase + N'_Consolidated'),                        
                @RelationshipTable = N'[stg].' + QUOTENAME(StagingBase + N'_Relationship')     
            FROM       
                mdm.tblEntity WHERE ID = @Entity_ID;    
                                                                        
            --Clear the batch records from the EBS staging tables.    
                  
            IF @MemberType_ID = 1 -- Leaf  
            BEGIN   
                -- Delete records for the batch ID from leaf staging table.  
                SET @SQL = N'DELETE FROM ' + @LeafTable + N' WHERE Batch_ID = @Batch_ID';  
                EXEC sp_executesql @SQL, N'@Batch_ID int', @Batch_ID;                                                                        
            END; --IF  
                
            IF @MemberType_ID = 2 -- Consolidated  
            BEGIN   
                -- Delete records for the batch ID from Consolidated staging table.  
                SET @SQL = N'DELETE FROM ' + @ConsolidatedTable + N' WHERE Batch_ID = @Batch_ID';  
                EXEC sp_executesql @SQL, N'@Batch_ID int', @Batch_ID;                                    
            END; --IF  
                
            IF @MemberType_ID = 4 -- Relationship  
            BEGIN   
                -- Delete records for the batch ID from Relationship staging table.  
                SET @SQL = N'DELETE FROM ' + @RelationshipTable + N' WHERE Batch_ID = @Batch_ID';  
                EXEC sp_executesql @SQL, N'@Batch_ID int', @Batch_ID;  
            END; --IF        
              
            --Update the Status for the batch    
            UPDATE mdm.tblStgBatch   
            SET     
                Status_ID = @Cleared,    
                LastClearedDTM=GETUTCDATE(),    
                LastClearedUserID=@User_ID    
            WHERE     
                ID = @Batch_ID;          
        END; --while          
    END; --if    
  
END -- Proc
go

