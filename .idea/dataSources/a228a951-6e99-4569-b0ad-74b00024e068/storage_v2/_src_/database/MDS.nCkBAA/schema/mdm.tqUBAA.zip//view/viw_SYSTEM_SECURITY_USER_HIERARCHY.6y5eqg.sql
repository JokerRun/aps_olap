/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
Explicit hierarchy requires both permission on leaf and consolidated member  
*/  
CREATE VIEW mdm.viw_SYSTEM_SECURITY_USER_HIERARCHY  
/*WITH SCHEMABINDING*/  
AS  
WITH allPermissions AS (  
    SELECT   
        usr.User_ID,  
        tHir.ID,  
        Privilege_ID =  
            CASE  
                WHEN tMTLeafSec.Privilege_ID = 1 OR tMTConSec.Privilege_ID = 1 THEN 1 /*Deny*/  
                WHEN tMTLeafSec.Privilege_ID = 4 OR tMTConSec.Privilege_ID = 4 THEN 4 /*Access*/  
                ELSE 99 /*Inferred*/  
            END,  
        tMTLeafSec.AccessPermission & tMTConSec.AccessPermission AS AccessPermission  
    FROM mdm.tblHierarchy tHir  
    CROSS JOIN(  
            SELECT DISTINCT [User_ID] AS [User_ID]  
            FROM mdm.viw_SYSTEM_SECURITY_USER_FUNCTION  
        ) AS usr  
    LEFT JOIN mdm.viw_SYSTEM_SECURITY_USER_MEMBERTYPE tMTLeafSec  
    ON      tMTLeafSec.Entity_ID = tHir.Entity_ID   
        AND tMTLeafSec.ID = 1   
        AND tMTLeafSec.User_ID = usr.User_ID  
    LEFT JOIN  mdm.viw_SYSTEM_SECURITY_USER_MEMBERTYPE tMTConSec  
    ON      tMTConSec.Entity_ID = tHir.Entity_ID   
        AND tMTConSec.ID = 2   
        AND tMTConSec.User_ID = usr.User_ID  
    WHERE   tMTLeafSec.Privilege_ID IS NOT NULL  
        AND tMTConSec.Privilege_ID IS NOT NULL  
)  
SELECT  
    [User_ID],  
    ID,  
    Privilege_ID,  
    CASE Privilege_ID WHEN 4 /*Access*/ THEN AccessPermission ELSE NULL END AccessPermission  
FROM allPermissions  
WHERE Privilege_ID > 1 /*Deny*/
go

