/*  
    EXEC mdm.udpCreateSystemParentChildViews 8;  
    EXEC mdm.udpCreateSystemParentChildViews 31;  
    EXEC mdm.udpCreateSystemParentChildViews 11111; --invalid  
*/  
/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpCreateSystemParentChildViews  
(  
    @Entity_ID      INT,  
    @ViewType       TINYINT = 0, -- 0 EN, 2 HS  
    @CorrelationID  UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    --Defer view generation if we are in the middle of an upgrade or demo-rebuild  
    IF APPLOCK_MODE(N'public', N'DeferViewGeneration', N'Session') = N'NoLock'  
    BEGIN  
        DECLARE @EntityTable            SYSNAME,  
                @HierarchyParentTable   SYSNAME,  
                @HierarchyTable         SYSNAME,  
                @CollectionTable        SYSNAME,  
                @CollectionMemberTable  SYSNAME,  
                @SQL                    NVARCHAR(MAX),  
                @TruncateGuard          NVARCHAR(MAX) = N'',  
                @CollectionViewName     SYSNAME,  
                @ViewName               SYSNAME,  
                @ViewType_EN            TINYINT = 0,  
                @ViewType_HS            TINYINT = 2,  
                @MemberType_ParentChild            TINYINT = 4,  
                @MemberType_CollectionParentChild  TINYINT = 5;  
  
        --Initialize the variables  
        SELECT  
                @EntityTable = QUOTENAME(EntityTable),  
                @HierarchyParentTable = QUOTENAME(HierarchyParentTable),  
                @HierarchyTable =  
                    CASE @ViewType  
                        WHEN @ViewType_EN THEN QUOTENAME(HierarchyTable)  
                        WHEN @ViewType_HS THEN QUOTENAME(HierarchyTable + N'_HS')  
                    END,  
                @CollectionTable = QUOTENAME(CollectionTable),  
                @CollectionMemberTable =  
                    CASE @ViewType  
                        WHEN @ViewType_EN THEN QUOTENAME(CollectionMemberTable)  
                        WHEN @ViewType_HS THEN QUOTENAME(CollectionMemberTable + N'_HS')  
                    END,  
                @ViewName = mdm.udfViewNameGetByID(ID, @MemberType_ParentChild, 0, @ViewType),  
                @CollectionViewName = mdm.udfViewNameGetByID(ID, @MemberType_CollectionParentChild, 0, @ViewType)  
        FROM mdm.tblEntity  
        WHERE ID = @Entity_ID;  
  
        -- Do not create parent child view if entity does not exist  
        IF @@ROWCOUNT = 0  
        BEGIN  
            RETURN;  
        END;  
  
        -- Create PARENTCHILD view  
        IF @ViewName IS NOT NULL  
        BEGIN  
            SET @SQL = CONCAT(@TruncateGuard, CASE  
                WHEN EXISTS(SELECT 1 FROM sys.views WHERE [name] = @ViewName AND [schema_id] = SCHEMA_ID('mdm')) THEN N'ALTER'  
                ELSE N'CREATE' END  
            , N' VIEW mdm.', @ViewName, N'  
                AS  
                SELECT  
                    HR.Version_ID,  
                    HR.Status_ID,  
                    ISNULL(HR.Parent_HP_ID,0) AS Parent_ID,  
                    HR.ChildType_ID,  
                    HR.Child_EN_ID,  
                    HR.Child_HP_ID,  
                    CASE HR.ChildType_ID WHEN 1 THEN HR.Child_EN_ID WHEN 2 THEN HR.Child_HP_ID END AS Child_ID,  
                    CASE  
                        WHEN HR.ChildType_ID = 1 THEN EN.ValidationStatus_ID  
                        ELSE HPC.ValidationStatus_ID  
                    END AS Child_ValidationStatus_ID,  
                    HR.Hierarchy_ID,  
                    H.MUID as Hierarchy_MUID,  
                    H.Name as Hierarchy_Name,  
                    ISNULL(HPP.Code,''ROOT'') AS Parent_Code,  
                    HPP.MUID AS Parent_MUID,  
                    ISNULL(HPP.Name,'''') AS Parent_Name,  
                    CASE  
                        WHEN HR.ChildType_ID = 1 THEN EN.Code  
                        ELSE HPC.Code  
                    END AS Child_Code,  
                    CASE  
                        WHEN HR.ChildType_ID = 1 THEN EN.MUID  
                        ELSE HPC.MUID  
                    END AS Child_MUID,  
                    CASE  
                        WHEN HR.ChildType_ID = 1 THEN EN.Name  
                        ELSE HPC.Name  
                    END AS Child_Name,  
                    HR.SortOrder AS Child_SortOrder,  
                    HR.LevelNumber AS Child_LevelNumber,  
  
                    ', CASE @ViewType WHEN 0 THEN N'CONVERT(BIGINT, HR.LastChgTS)' ELSE N'HR.ID' END, N' AS LastChgTS,  
                    --Auditing columns (Creation)  
                    HR.EnterDTM,  
                    HR.EnterUserID,  
                    eu.[UserName] AS EnterUserName,  
                    eu.MUID AS EnterUserMuid,  
  
                    --Auditing columns (Updates)  
                    HR.LastChgDTM,  
                    HR.LastChgUserID,  
                    lcu.[UserName] AS LastChgUserName,  
                    lcu.MUID AS LastChgUserMuid  
                FROM  
                    mdm.', @HierarchyTable, N' AS HR  
                    -- Changed from INNER JOIN for better performance  
                    LEFT JOIN mdm.tblUser eu ON HR.EnterUserID = eu.ID  
                    LEFT JOIN mdm.tblUser lcu ON HR.LastChgUserID = lcu.ID  
                    LEFT JOIN mdm.tblHierarchy H ON H.ID = HR.Hierarchy_ID  
                    LEFT JOIN mdm.', @HierarchyParentTable, N' AS HPP  
                        ON HPP.ID = HR.Parent_HP_ID  
                        AND HPP.Version_ID = HR.Version_ID  
                        AND HPP.Hierarchy_ID = HR.Hierarchy_ID  
                        AND HPP.Status_ID = HR.Status_ID  
                    LEFT JOIN mdm.', @EntityTable, N' AS EN  
                        ON HR.ChildType_ID = 1  
                        AND HR.Child_EN_ID = EN.ID  
                        AND HR.Version_ID = EN.Version_ID  
                        AND EN.Status_ID = 1  
                    LEFT JOIN mdm.', @HierarchyParentTable, N' AS HPC  
                        ON HR.ChildType_ID = 2  
                        AND HR.Child_HP_ID = HPC.ID  
                        AND HR.Version_ID = HPC.Version_ID  
                        AND HR.Hierarchy_ID = HPC.Hierarchy_ID  
                        AND HPC.Status_ID = 1  
                    WHERE  
                        (EN.ID IS NOT NULL OR HPC.ID IS NOT NULL)  
                        ', CASE @ViewType WHEN 0 THEN N'AND HR.Status_ID = 1' END);  
  
            --PRINT(@SQL);  
            EXEC sp_executesql @SQL  
        END;  
  
        --Create the CollectionParentChild view  
        IF @CollectionViewName IS NOT NULL  
        BEGIN  
            SET @SQL = CONCAT(@TruncateGuard, CASE  
                WHEN EXISTS(SELECT 1 FROM sys.views WHERE [name] = @CollectionViewName AND [schema_id] = SCHEMA_ID('mdm')) THEN N'ALTER'  
                ELSE N'CREATE' END,  
            N' VIEW mdm.', @CollectionViewName, N'  
            AS  
            SELECT  
                tCM.Version_ID,  
                tCM.Status_ID,  
                tCNN.Code Parent_Code,  
                tCNN.Name Parent_Name,  
                3 as ParentType_ID,  
                tCNN.ID as Parent_ID,  
                CASE tCM.ChildType_ID  
                    WHEN 1 THEN tEN.ID ',  
                CASE WHEN @HierarchyParentTable IS NOT NULL THEN N'  
                    WHEN 2 THEN tHP.ID' END, N'  
                    WHEN 3 THEN tCN.ID  
                END Member_ID,  
                tCM.ChildType_ID MemberType_ID,  
                CASE tCM.ChildType_ID  
                    WHEN 1 THEN 0 ',  
                CASE WHEN @HierarchyParentTable IS NOT NULL THEN N'  
                    WHEN 2 THEN tHP.Hierarchy_ID' END, N'  
                    WHEN 3 THEN tCN.ID  
                END Hierarchy_ID,  
                NULL as Hierarchy_MUID,  
                N'''' as Hierarchy_Name,  
                tCM.SortOrder,  
                CASE tCM.ChildType_ID  
                    WHEN 1 THEN tEN.Code',  
                CASE WHEN @HierarchyParentTable IS NOT NULL THEN N'  
                    WHEN 2 THEN tHP.Code' END, N'  
                    WHEN 3 THEN tCN.Code  
                END Code,  
                CASE tCM.ChildType_ID  
                    WHEN 1 THEN tEN.Name',  
                CASE WHEN @HierarchyParentTable IS NOT NULL THEN N'  
                    WHEN 2 THEN tHP.Name' END, N'  
                    WHEN 3 THEN tCN.Name  
                END Name,  
                CONVERT(DECIMAL(18, 2), tCM.Weight) AS Weight,  
                tCM.ChildType_ID,  
                tCM.Child_EN_ID,',  
                CASE WHEN @HierarchyParentTable IS NOT NULL THEN N'  
                tCM.Child_HP_ID,' END, N'  
                tCM.Child_CN_ID,  
                CASE tCM.ChildType_ID  
                    WHEN 1 THEN tCM.Child_EN_ID',  
                CASE WHEN @HierarchyParentTable IS NOT NULL THEN N'  
                    WHEN 2 THEN tCM.Child_HP_ID' END, N'  
                    WHEN 3 THEN tCM.Child_CN_ID  
                    END AS Child_ID,  
                CASE tCM.ChildType_ID  
                    WHEN 1 THEN 0',  
                CASE WHEN @HierarchyParentTable IS NOT NULL THEN N'  
                    WHEN 2 THEN tHP.Hierarchy_ID' END, N'  
                    WHEN 3 THEN tCN.ID  
                END NextHierarchy_ID,  
                CASE  
                    WHEN tCM.ChildType_ID = 3 THEN 2  
                    ELSE 0  
                END NextHierarchyType_ID,  
                ', CASE @ViewType WHEN 0 THEN N'CONVERT(BIGINT, tCM.LastChgTS)' ELSE N'tCM.ID' END, N' AS LastChgTS,  
                --Auditing columns (Creation)  
                tCM.EnterDTM,  
                tCM.EnterUserID,  
                eu.[UserName] AS EnterUserName,  
                eu.MUID AS EnterUserMuid,  
  
                --Auditing columns (Updates)  
                tCM.LastChgDTM,  
                tCM.LastChgUserID,  
                lcu.[UserName] AS LastChgUserName,  
                lcu.MUID AS LastChgUserMuid  
            FROM  
                mdm.', @CollectionMemberTable, N' AS tCM  
                -- Changed from INNER JOIN for better performance  
                LEFT JOIN mdm.tblUser eu ON tCM.EnterUserID = eu.ID  
                LEFT JOIN mdm.tblUser lcu ON tCM.LastChgUserID = lcu.ID  
                LEFT JOIN  mdm.', @CollectionTable, N' AS tCNN  
                    ON tCNN.ID = tCM.Parent_CN_ID  
                    AND tCNN.Version_ID = tCM.Version_ID  
                LEFT JOIN mdm.', @EntityTable, N' AS tEN  
                    ON tCM.ChildType_ID = 1  
                    AND tCM.Child_EN_ID = tEN.ID  
                    AND tCM.Version_ID = tEN.Version_ID  
                    AND tEN.Status_ID = 1',  
                    CASE WHEN @HierarchyParentTable IS NOT NULL THEN CONCAT(N'  
                LEFT JOIN mdm.', @HierarchyParentTable, N' AS tHP  
                    ON tCM.ChildType_ID = 2  
                    AND tCM.Child_HP_ID = tHP.ID  
                    AND tCM.Version_ID = tHP.Version_ID  
                    AND tHP.Status_ID = 1') END, N'  
                LEFT JOIN mdm.', @CollectionTable, N' AS tCN  
                    ON tCM.ChildType_ID = 3  
                    AND tCM.Child_CN_ID = tCN.ID  
                    AND tCM.Version_ID = tCN.Version_ID  
                    AND tCN.Status_ID = 1  
                WHERE  
                    tCNN.Status_ID = 1 AND -- Collection must be active  
                    (      tEN.ID IS NOT NULL',  
                    CASE WHEN @HierarchyParentTable IS NOT NULL THEN N'  
                        OR tHP.ID IS NOT NULL' END, N'  
                        OR tCN.ID IS NOT NULL)  
                    ', CASE @ViewType WHEN 0 THEN N'AND tCM.Status_ID = 1' END);  
  
            --PRINT(@SQL);  
            EXEC sp_executesql @SQL  
        END;  
  
    END; --if  
  
    SET NOCOUNT OFF;  
END; --proc
go

