/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
EXEC mdm.udpSystemSettingGroupGet   
EXEC mdm.udpSystemSettingGroupGet @Group_Name = 'Email'  
exec mdm.udpSystemSettingGroupGet @Group_ID=NULL,@Group_MUID=0x0,@Group_Name=N'Email'  
  
*/  
CREATE PROCEDURE mdm.udpSystemSettingGroupGet   
(  
     @Group_MUID UNIQUEIDENTIFIER = NULL  
    ,@Group_Name NVARCHAR(50) = NULL  
    ,@CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS N'mds_schema_user'   
AS BEGIN  
  
    SET NOCOUNT ON  
  
    SET @Group_MUID = NULLIF(@Group_MUID, 0x0);  
    SET @Group_Name = NULLIF(@Group_Name, N'');   
  
    DECLARE @SelectedGroup TABLE   
    (  
        ID  INT PRIMARY KEY  
    )  
    INSERT INTO @SelectedGroup  
    SELECT ID  
    FROM mdm.tblSystemSettingGroup g  
    WHERE   MUID = ISNULL(@Group_MUID, MUID)  
        AND GroupName = ISNULL(@Group_Name, GroupName)  
  
    SELECT  
         g.MUID         AS Group_MUID  
        ,g.GroupName    AS Group_Name  
        ,sg.ID          AS Group_ID  
          
        ,g.Description  
        ,g.DisplayName  
        ,g.DisplaySequence  
    FROM @SelectedGroup sg  
    INNER JOIN mdm.tblSystemSettingGroup g  
    ON sg.ID = g.ID  
    ORDER BY g.DisplaySequence  
  
  
    SELECT  
         s.MUID           AS Setting_MUID  
        ,s.SettingName    AS Setting_Name  
        ,s.ID             AS Setting_ID  
  
        ,s.SystemSettingGroup_ID  AS Group_ID  
              
        ,s.DataType_ID   
        ,s.Description  
        ,s.DisplayName  
        ,s.DisplaySequence  
        ,s.IsVisible  
        ,s.MaxValue  
        ,s.MinValue  
        ,s.SettingType_ID  
        ,s.SettingValue  
        ,s.SettingValueDomainName  
    FROM @SelectedGroup sg  
    INNER JOIN mdm.viw_SYSTEM_SCHEMA_SYSTEMSETTINGS s  
    ON sg.ID = s.SystemSettingGroup_ID  
    ORDER BY s.SystemSettingGroup_ID, s.DisplaySequence  
  
  
    -- load a temp table with the list codes to get  
    DECLARE @ListItem mdm.MemberCodes;  
  
    INSERT INTO @ListItem (MemberCode, MemberName)  
    SELECT DISTINCT  
         s.SettingValueDomainName   AS MemberCode  
        ,l.ListName                 AS MemberName  
    FROM @SelectedGroup sg  
    INNER JOIN mdm.viw_SYSTEM_SCHEMA_SYSTEMSETTINGS s  
    ON sg.ID = s.SystemSettingGroup_ID  
    INNER JOIN mdm.tblList l  
    ON s.SettingValueDomainName = l.ListCode  
    WHERE s.SettingValueDomainName IS NOT NULL  
  
  
    EXEC mdm.udpSystemDomainListGet @ListItem = @ListItem, @CorrelationID = @CorrelationID  
  
    SET NOCOUNT OFF  
END --proc
go

