/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Gets the privilege for the given member  
  
Procedure  : mdm.udpSecurityMemberResolverGet  
Component  : Security  
Description: mdm.udpSecurityMemberResolverGet returns a list of members and privileges available for a user.  
Parameters : User ID, Version ID, Entity ID, Hierarchy_ID (Optional), HIerarchyType_ID )Optional),Member ID (optional), Member type ID (optional)  
  
Example    : EXEC mdm.udpSecurityMemberResolverGet @User_ID = 1, @Version_ID = 4, @Entity_ID = 7, @Member_ID = 0, @MemberType_ID = 2  
Dependency : NA  
  
  
EXEC mdm.udpSecurityMemberResolverGet @User_ID = 1, @Version_ID = 20, @Entity_ID = 31, @Member_ID = null, @MemberType_ID = null  
*/  
CREATE PROCEDURE mdm.udpSecurityMemberResolverGet  
(  
    @User_ID            INT,  
    @Version_ID         INT,  
    @Hierarchy_ID       INT = NULL,  
    @HierarchyType_ID   TINYINT = NULL,  
    @Entity_ID          INT,  
    @Member_ID          INT,  
    @MemberType_ID      TINYINT,  
    @Privilege_ID       TINYINT = NULL OUTPUT,  
    @AccessPermission   TINYINT = NULL OUTPUT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    -- Why?  
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED  
  
    DECLARE  
        @ExplicitHierarchyTypeId    TINYINT = 0,  
        @DerivedHierarchyTypeId     TINYINT = 1,  
  
        @Root_ID                    INT = 0,  
        @Unused_ID                  INT = -1,  
  
        @Permission_Deny            TINYINT = 1,  
        @Permission_Access          TINYINT = 4;  
  
    DECLARE @TempCount INT  
    DECLARE @Item_ID INT  
  
    SET @Privilege_ID = @Permission_Deny;  
    SET @AccessPermission = 0;  
        -- Root and used node use hierarchy permission  
    IF COALESCE(NULLIF(@Member_ID, @Unused_ID), @Root_ID) = @Root_ID  
    BEGIN   
        IF @HierarchyType_ID = @ExplicitHierarchyTypeId  
        BEGIN  
            SELECT @Privilege_ID=Privilege_ID, @AccessPermission=AccessPermission FROM mdm.viw_SYSTEM_SECURITY_USER_HIERARCHY WHERE User_ID = @User_ID AND ID = @Hierarchy_ID  
        END  
        ELSE IF @HierarchyType_ID = @DerivedHierarchyTypeId  
        BEGIN  
            SELECT @Privilege_ID=Privilege_ID, @AccessPermission=AccessPermission FROM mdm.viw_SYSTEM_SECURITY_USER_HIERARCHY_DERIVED WHERE User_ID = @User_ID AND ID = @Hierarchy_ID  
        END  
    END  
    -- other nodes use membertype effective permission  
    ELSE  
    BEGIN  
        SELECT @Privilege_ID = Privilege_ID, @AccessPermission = AccessPermission  
        FROM mdm.viw_SYSTEM_SECURITY_USER_MEMBERTYPE  
        WHERE User_ID = @User_ID AND Entity_ID = @Entity_ID AND ID = @MemberType_ID  
    END  
  
    IF COALESCE(NULLIF(@Member_ID, @Unused_ID), @Root_ID) = @Root_ID  
    BEGIN  
        IF EXISTS(  
            SELECT 1  
            FROM mdm.viw_SYSTEM_SECURITY_USER_MEMBER  
            WHERE User_ID=@User_ID  
            AND IsMapped=1  
            AND Hierarchy_ID=@Hierarchy_ID  
            AND HierarchyType_ID=@HierarchyType_ID  
            AND Member_ID=@Member_ID  
        )  
            SELECT @Privilege_ID = Privilege_ID, @Permission_Access = AccessPermission  
            FROM mdm.viw_SYSTEM_SECURITY_USER_MEMBER  
            WHERE User_ID=@User_ID  
                AND IsMapped=1  
                AND Hierarchy_ID=@Hierarchy_ID  
                AND HierarchyType_ID=@HierarchyType_ID  
                AND Member_ID=@Member_ID  
    END ELSE  
    BEGIN  
        -- Overwrite the effective membertype permission with member permission  
        IF mdm.udfUseMemberSecurity(@User_ID, @Entity_ID, @Version_ID, @MemberType_ID) <> 0  
        BEGIN  
            DECLARE @MemberIds mdm.MemberId;  
            INSERT INTO @MemberIds (ID, MemberType_ID) SELECT @Member_ID, @MemberType_ID  
  
            DECLARE @MemberPermissions AS TABLE (ID INT, MemberType_ID TINYINT, Privilege_ID TINYINT, AccessPermission TINYINT);  
            INSERT INTO @MemberPermissions  
            EXEC mdm.udpSecurityMembersResolverGet @User_ID=@User_ID, @Version_ID=@Version_ID, @Entity_ID=@Entity_ID, @MemberIds=@MemberIds;  
  
            SELECT  
                @Privilege_ID = Privilege_ID, @AccessPermission = AccessPermission  
            FROM @MemberPermissions  
        END  
    END  
  
    SET NOCOUNT OFF  
  
END --proc
go

