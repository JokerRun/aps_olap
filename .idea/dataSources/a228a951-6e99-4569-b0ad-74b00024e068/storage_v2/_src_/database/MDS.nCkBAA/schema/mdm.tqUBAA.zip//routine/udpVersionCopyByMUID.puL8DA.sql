/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    DECLARE @Return_ID              int,  
            @Return_MUID            uniqueidentifier,  
            @VersionName            NVARCHAR(50),  
            @VersionDescription     NVARCHAR(250);  
  
    SELECT  
            @VersionName            = 'New Product Version',  
            @VersionDescription     = 'Product Model - Proposed next quarter model';  
  
    EXEC mdm.udpVersionCopyByMUID 1, 'DC011B93-5599-4278-8101-B3D254A09B81', @VersionName, @VersionDescription, @Return_ID OUTPUT, @Return_MUID OUTPUT;  
    SELECT @Return_ID, @Return_MUID;  
  
    SELECT * FROM mdm.tblModelVersion;  
*/  
CREATE PROCEDURE mdm.udpVersionCopyByMUID  
(  
    @User_ID                INT,  
    @Version_MUID           UNIQUEIDENTIFIER,  
    @VersionName            NVARCHAR(50),  
    @VersionDescription     NVARCHAR(250),  
    @Return_ID              INT = NULL OUTPUT,  
    @Return_MUID            UNIQUEIDENTIFIER = NULL OUTPUT,  
    @CorrelationID          UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE @FunctionalPrivilege_Versions  TINYINT = 2  
    IF mdm.udfSecurityUserFunctionIsAllowed(@User_ID, @FunctionalPrivilege_Versions) = 0  
    BEGIN  
        RAISERROR('MDSERR120002|The user does not have permission to perform this operation.', 16, 1);  
        RETURN;  
    END  
  
    DECLARE   
         @Version_ID        INT  
        ,@ModelPrivilege    INT;  
  
    SELECT   
         @Version_ID = mv.ID   
        ,@ModelPrivilege = m.Privilege_ID  
    FROM mdm.tblModelVersion mv  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_MODEL m  
    ON mv.Model_ID = m.ID  
    WHERE   mv.MUID = @Version_MUID  
        AND m.User_ID = @User_ID  
        AND m.Privilege_ID > 1/*Deny*/;  
  
    --Test for invalid parameters  
    IF (@Version_ID IS NULL) --Invalid @Version_MUID  
    BEGIN  
        --On error, return NULL results  
        SELECT @Return_ID = NULL, @Return_MUID = NULL;  
        RAISERROR('MDSERR200036|The version cannot be copied. The version MUID is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    IF @ModelPrivilege != 5 /*Admin*/  
    BEGIN  
        --On error, return NULL results  
        SELECT @Return_ID = NULL, @Return_MUID = NULL;  
        RAISERROR(N'MDSERR120003|The user does not have permission or the object ID is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    EXEC mdm.udpVersionCopy @User_ID, @Version_ID, @VersionName, @VersionDescription, @Return_ID OUTPUT, @Return_MUID OUTPUT;  
  
    SET NOCOUNT OFF;  
END; --proc
go

