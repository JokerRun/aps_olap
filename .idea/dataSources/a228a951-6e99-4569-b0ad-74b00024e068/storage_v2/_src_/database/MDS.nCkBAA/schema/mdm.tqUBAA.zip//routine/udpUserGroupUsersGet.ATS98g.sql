/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Gets the users that are assigned to the given group.  
  
exec mdm.udpUserGroupUsersGet 8  
  
select * from mdm.tblUserGroupAssignment  
*/  
CREATE PROCEDURE mdm.udpUserGroupUsersGet  
(  
    @UserGroup_ID   INT,  
    @CorrelationID  UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    SELECT  
        U.ID,  
        U.MUID,  
        U.UserName + N' (' + U.DisplayName + N')' as Name,  
        U.UserName  
    FROM mdm.tblUser U  
    INNER JOIN mdm.tblUserGroupAssignment SGA   
    ON U.ID = SGA.User_ID  
    WHERE   SGA.UserGroup_ID = @UserGroup_ID  
        AND U.Status_ID = 1 -- Active  
    ORDER BY  
        U.UserName  
  
    SET NOCOUNT OFF  
END
go

