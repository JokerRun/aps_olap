/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE VIEW mdm.viw_SYSTEM_SECURITY_USER_ATTRIBUTEGROUP  
/*WITH SCHEMABINDING*/  
AS  
WITH allPermissions AS (  
    SELECT  
        User_ID,  
        ID,  
        MIN(Privilege_ID) Privilege_ID,  
        SUM(Distinct(AccessPermission & 0x1)) +  
        SUM(Distinct(AccessPermission & 0x2)) +  
        SUM(Distinct(AccessPermission & 0x4)) AS AccessPermission  
    FROM  
        (  
        SELECT   
            mtSec.User_ID,  
            tAtt.ID,  
            Privilege_ID =  
                CASE  
                    WHEN mtSec.IsAdmin = 1 THEN 4 /*Access*/  
                    WHEN mtSec.Privilege_ID = 1 /*Deny*/ THEN 1 /*Deny*/  
                    -- No explicit permission on attribute group and non-inferred permission on memberType, use memberType permision  
                    ELSE tExp.Privilege_ID  
                END,  
            AccessPermission =  
                CASE  
                    WHEN mtSec.IsAdmin = 1 THEN 7 /*All*/  
                    WHEN mtSec.Privilege_ID = 1 /*Deny*/ THEN 0 /*None*/  
                    -- No explicit permission on attribute group and non-inferred permission on memberType, use memberType permision  
                    ELSE tExp.AccessPermission  
                END  
        FROM mdm.tblAttributeGroup tAtt  
            INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_MEMBERTYPE mtSec  
            ON tAtt.Entity_ID = mtSec.Entity_ID  
               AND tAtt.MemberType_ID = mtSec.ID  
            LEFT JOIN (  
               SELECT User_ID, Securable_ID AS ID, Privilege_ID, AccessPermission  
               FROM mdm.tblSecurityRoleAccess tAcc  
                   INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ROLE tRol  
                   ON tRol.Role_ID = tAcc.Role_ID  
               WHERE tAcc.Privilege_ID IS NOT NULL AND  
                  tAcc.Object_ID = 5 /*AttriubteGroup*/  
            ) tExp  
            ON tExp.ID = tAtt.ID AND tExp.[User_ID] = mtSec.[User_ID]  
        ) tSec  
    WHERE  
        Privilege_ID IS NOT NULL  
    GROUP BY  
        User_ID,  
        ID  
)  
SELECT  
    [User_ID],  
    ID,  
    Privilege_ID,  
    CASE Privilege_ID WHEN 4 /*Access*/ THEN AccessPermission ELSE NULL END AccessPermission  
FROM allPermissions  
WHERE Privilege_ID > 1 /*Deny*/
go

