/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
udpFileGet 1  
  
select * from mdm.tblFile  
*/  
CREATE PROCEDURE mdm.udpFileGet  
(  
    @ID             INT,  
    @CorrelationID  UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
  
    SELECT  
         ID  
        ,FileName  
        ,FileContentType  
        ,FileContent  
        ,EnterDTM  
        ,EnterUserID  
        ,LastChgDTM  
        ,LastChgUserID  
    FROM  
        mdm.tblFile  
    WHERE  
        ID = @ID  
  
    SET NOCOUNT OFF  
END --proc
go

