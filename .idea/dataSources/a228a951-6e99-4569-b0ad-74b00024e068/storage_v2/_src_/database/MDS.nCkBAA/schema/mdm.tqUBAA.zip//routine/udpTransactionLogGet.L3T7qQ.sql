/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
EXEC  
    mdm.udpTransactionLogGet  
        @Model_MUID             = NULL,  
        @Model_Name             = NULL,  
        @Version_MUID            = NULL,  
        @Version_Name            = NULL,  
        @Entity_MUID            = NULL,  
        @Entity_Name            = NULL,  
        @MemberType_ID                = NULL,  
        @Attribute_MUID            = NULL,  
        @Attribute_Name            = NULL,  
        @ExplicitHierarchy_MUID = NULL,  
        @ExplicitHierarchy_Name = NULL,  
        @User_MUID                = NULL,  
        @User_Name                = NULL,  
        @MemberCode                = NULL,  
        @MemberMuid                = NULL,  
        @Transaction_ID            = NULL,  
        @TransactionType_ID        = NULL,  
        @NewValue                = NULL,  
        @PriorValue                = NULL,  
        @DateTimeBeginRange        = '2008-07-28 12:51:55.999',  
        @DateTimeEndRange        = NULL,  
        @PageNumber                = NULL,  
        @PageSize                = NULL,  
        @SortColumn                = NULL,  
        @SortDirection            = NULL,  
        @CountOnly                = 0,  
  
*/  
CREATE PROCEDURE mdm.udpTransactionLogGet  
(  
     @SystemUser_ID          INT  
    ,@Model_MUID             UNIQUEIDENTIFIER = NULL  
    ,@Model_Name             NVARCHAR(MAX) = NULL  
    ,@Version_MUID           UNIQUEIDENTIFIER = NULL  
    ,@Version_Name           NVARCHAR(MAX) = NULL  
    ,@Entity_MUID            UNIQUEIDENTIFIER = NULL  
    ,@Entity_Name            NVARCHAR(MAX) = NULL  
    ,@MemberType_ID          TINYINT = NULL  
    ,@Attribute_MUID         UNIQUEIDENTIFIER = NULL  
    ,@Attribute_Name         NVARCHAR(MAX) = NULL  
    ,@ExplicitHierarchy_MUID UNIQUEIDENTIFIER = NULL  
    ,@ExplicitHierarchy_Name NVARCHAR(MAX) = NULL  
    ,@User_MUID              UNIQUEIDENTIFIER = NULL  
    ,@User_Name              NVARCHAR(MAX) = NULL  
    ,@MemberCode             NVARCHAR(MAX) = NULL  
    ,@Member_MUID            UNIQUEIDENTIFIER = NULL  
    ,@Transaction_ID         INT = NULL  
    ,@TransactionType_ID     INT = NULL  
    ,@NewValue               NVARCHAR(MAX) = NULL  
    ,@PriorValue             NVARCHAR(MAX) = NULL  
    ,@DateTimeBeginRange     DATETIME2(3) = NULL  
    ,@DateTimeEndRange       DATETIME2(3) = NULL  
    ,@PageNumber             INT = NULL  
    ,@PageSize               INT = NULL  
    ,@SortColumn             NVARCHAR(500) = NULL  
    ,@SortDirection          NVARCHAR(5) = NULL  
    ,@CountOnly              BIT = 0  
    ,@CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
    DECLARE  
         @SQL                   NVARCHAR(MAX)  
        ,@NoMatches             BIT = 0 -- This flag is used to skip doing additional filtering once a filter has been found that results in no matches.  
        ,@FilterByVersion       BIT = 0  
        ,@FilterByEntity        BIT = 0  
        ,@FilterByMemberType    BIT = 0  
        ,@FilterByAttribute     BIT = 0  
        ,@FilterByHierarchy     BIT = 0  
        ,@FilterByUser          BIT = 0  
        ,@FilterByMemberCode    BIT = 0  
        ,@FilterByMemberId      BIT = 0  
        ,@FilterByMemberMuid    BIT = 0  
  
        --Member Types  
        ,@MemberType_Unknown            TINYINT = 0  
        ,@MemberType_Leaf               TINYINT = 1  
        ,@MemberType_Consolidated       TINYINT = 2  
        ,@MemberType_Collection         TINYINT = 3  
  
        ,@StartRow    INT  
        ,@EndRow      INT  
  
        ,@CurrentRow_ID              INT  
        ,@CurrentEntity_ID           INT  
        ,@CurrentMemberTableName     NVARCHAR(258)  
        ,@CurrentSecurityTableName   SYSNAME  
        ,@CurrentMemberSecurity      BIT  
        ,@CurrentMemberType_ID       TINYINT  
        ,@AttributeExplorerMode      INT = 1  
        ,@IsFirstCTE                 BIT = 1  
        ,@IsModelAdmin               BIT  
        ,@CurrentCTE                 NVARCHAR(MAX)  
        ,@CurrentAcl                 NVARCHAR(MAX)  
  
        ,@Permission_Deny            TINYINT = 4  
  
        ,@WhereCriteria NVARCHAR(MAX) = N''  
        ,@From          NVARCHAR(MAX) = N''  
        ,@Join          NVARCHAR(MAX) = N''  
  
        --Transaction view name  
        ,@TransactionViewName NVARCHAR(258)  
  
        ,@Model_ID               INT = NULL  
        ,@Version_ID             INT = NULL  
        ,@Entity_ID              INT = NULL  
        ,@Attribute_ID           INT = NULL  
        ,@User_ID                INT = NULL  
  
        -- This pseudo-constant is for use in string concatenation operations to prevent string truncation. When concatenating two or more strings,  
        -- if none of the strings is an NVARCHAR(MAX) or an NVARCHAR constant that is longer than 4,000 characters, then the resulting string  
        -- will be silently truncated to 4,000 characters. Concatenating with this empty NVARCHAR(MAX), is sufficient to prevent truncation.  
        -- See http://connect.microsoft.com/SQLServer/feedback/details/283368/nvarchar-max-concatenation-yields-silent-truncation.  
        ,@TruncationGuard        NVARCHAR(MAX) = N''  
        ;  
  
    IF (@SortDirection IS NOT NULL AND UPPER(@SortDirection) <> N'ASC' AND UPPER(@SortDirection) <> N'DESC')  
    BEGIN  
        RAISERROR('MDSERR200086|Invalid Sort Direction.  Supported Values are ''ASC'' and ''DESC''.', 16, 1);  
        RETURN;  
    END;  
  
    SET @SortDirection = COALESCE(@SortDirection, N'ASC');  
    SET @PageNumber = COALESCE(@PageNumber, 1);  
    SET @Model_Name = NULLIF(@Model_Name, N'');  
    SET @Model_MUID = NULLIF(@Model_MUID, 0x0);  
    SET @Version_Name = NULLIF(@Version_Name, N'');  
    SET @Version_MUID = NULLIF(@Version_MUID, 0x0);  
    SET @Entity_Name = NULLIF(@Entity_Name, N'');  
    SET @Entity_MUID = NULLIF(@Entity_MUID, 0x0);  
    SET @Attribute_Name = NULLIF(@Attribute_Name, N'');  
    SET @Attribute_MUID = NULLIF(@Attribute_MUID, 0x0);  
    SET @ExplicitHierarchy_Name = NULLIF(@ExplicitHierarchy_Name, N'');  
    SET @ExplicitHierarchy_MUID = NULLIF(@ExplicitHierarchy_MUID, 0x0);  
    SET @User_Name = NULLIF(@User_Name, N'');  
    DECLARE @User_NameUpper NVARCHAR(MAX) = UPPER(@User_Name);  
    SET @User_MUID = NULLIF(@User_MUID, 0x0);  
    SET @MemberCode = NULLIF(@MemberCode, N'');  
    SET @Member_MUID = NULLIF(@Member_MUID, 0x0);  
  
    -- Replace null page size with default.  
    IF @PageSize IS NULL  
    BEGIN  
        SELECT @PageSize = CAST(SettingValue AS INT)  
        FROM mdm.tblSystemSetting  
        WHERE SettingName = N'RowsPerBatch';  
    END  
    SET @PageSize = COALESCE(@PageSize, 50);  
  
    -- Get start row.  
    IF @PageNumber <= 1  
    BEGIN  
        SET @PageNumber = 1;  
    END  
    SET @StartRow = ((@PageNumber - 1) * @PageSize) + 1;  
  
    -- Get the end row.  
    SET @EndRow = @PageNumber * @PageSize;  
  
    -- Prefilter various items (Models, Versions, Entities, Users, etc) on the table in which they are defined to get  
    -- a list of matching ID values. This is much less expensive that doing the same search directly against the transaction  
    -- view, which is typically much larger. For example, doing a LIKE comparison on tblModel.Name is much cheaper than doing it on system_transaction_viw.Model_Name  
    -- because tblModel typically won't have more than dozens (or even hundreds, in an extreme case) of rows, while the transaction  
    -- view could easily have millions of rows.  
  
    -- Find all models that match the provided criteria.  
    CREATE TABLE #ModelIds (ID INT PRIMARY KEY, IsAdministrator BIT);  
    INSERT INTO #ModelIds(ID, IsAdministrator)  
    SELECT DISTINCT m.ID, CASE acl.Privilege_ID WHEN 5 /*Admin*/ THEN 1 ELSE 0 END  
    FROM mdm.tblModel m  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_MODEL acl  
    ON m.ID = acl.ID  
        AND acl.User_ID = @SystemUser_ID  
        AND acl.Privilege_ID <> 1 /*Deny*/  
    WHERE   (@Model_MUID IS NULL OR m.MUID    = @Model_MUID)  
        AND (@Model_Name IS NULL OR m.Name    = @Model_Name);  
  
    IF NOT EXISTS(SELECT 1 FROM #ModelIds)  
    BEGIN  
        --A valid model must be supplied  
        RAISERROR('MDSERR300005|The supplied model is not valid.', 16, 1);  
        RETURN;  
    END;  
  
        --Load the model ID we found  
    SELECT TOP 1  
        @Model_ID = ID,  
        @IsModelAdmin = IsAdministrator  
    FROM #ModelIds;  
  
        SET @TransactionViewName = mdm.udfGetTransactionViewName(@Model_ID);  
  
    IF @SortColumn IS NOT NULL  
    BEGIN  
        IF NOT EXISTS(  
            SELECT 1  
            FROM sys.columns c  
            INNER JOIN sys.views v  
            ON c.object_id = v.object_id  
            INNER JOIN sys.schemas s  
            ON v.schema_id = s.schema_id  
            WHERE   v.name =  @TransactionViewName  
                AND s.name = N'mdm'  
                AND c.name = @SortColumn)  
        BEGIN  
            RAISERROR('MDSERR200087|Sort Column not found in target table.', 16, 1);  
            RETURN;  
        END  
    END  
    ELSE  
    BEGIN  
        -- Sort by ID by default.  
        SET @SortColumn = CAST(N'ID' AS NVARCHAR(500))  
        -- Sort by Date Time by default.  
    END  
  
    -- Find all versions that match the provided criteria.  
    IF  @NoMatches = 0  
        AND(   @Version_MUID IS NOT NULL  
            OR @Version_Name IS NOT NULL)  
    BEGIN  
        SET @FilterByVersion = 1;  
  
        CREATE TABLE #VersionIds (ID INT PRIMARY KEY);  
        INSERT INTO #VersionIds(ID)  
        SELECT DISTINCT v.ID  
        FROM mdm.tblModelVersion v  
        INNER JOIN #ModelIds m  
        ON v.Model_ID = m.ID  
        WHERE   (@Version_MUID IS NULL OR v.MUID    = @Version_MUID)  
            AND (@Version_Name IS NULL OR v.Name LIKE @Version_Name);  
  
        IF NOT EXISTS(SELECT 1 FROM #VersionIds)  
        BEGIN  
            SET @NoMatches = 1;  
        END;  
    END;  
  
    -- Find all entities that match the provided criteria.  
    IF  @NoMatches = 0  
        AND(   @Entity_MUID IS NOT NULL  
            OR @Entity_Name IS NOT NULL)  
    BEGIN  
        SET @FilterByEntity = 1;  
  
        CREATE TABLE #EntityIds  
        (  
             Row_ID                         INT IDENTITY(1,1)  
            ,ID                             INT PRIMARY KEY  
            ,LeafMemberTableName            NVARCHAR(258) NULL  
            ,ConsolidatedMemberTableName    NVARCHAR(258) NULL  
            ,CollectionMemberTableName      NVARCHAR(258) NULL  
        );  
        INSERT INTO #EntityIds  
        (  
             ID  
            ,LeafMemberTableName  
            ,ConsolidatedMemberTableName  
            ,CollectionMemberTableName  
        )  
        SELECT DISTINCT  
             e.ID  
            ,e.EntityTable  
            ,e.HierarchyParentTable  
            ,e.CollectionTable  
        FROM mdm.tblEntity e  
        INNER JOIN #ModelIds m  
        ON e.Model_ID = m.ID  
  
        WHERE   (@Entity_MUID IS NULL OR e.MUID    = @Entity_MUID)  
            AND (@Entity_Name IS NULL OR e.Name    = @Entity_Name);  
  
        IF NOT EXISTS(SELECT 1 FROM #EntityIds)  
        BEGIN  
            SET @NoMatches = 1;  
        END ELSE  
        BEGIN  
            -- select the entity ID we just found  
            SELECT TOP 1  
                @Entity_ID = ID  
            FROM #EntityIds;  
        END;  
    END;  
  
    -- Set a flag indicating whether filtering should be done on member type. This is necessary so that the flag can be switched off, even  
    -- when a member type is specified, if a subsequent filter makes this one redundant.  
    IF @NoMatches = 0 AND @MemberType_ID IS NOT NULL  
    BEGIN  
        SET @FilterByMemberType = 1;  
    END;  
  
    -- Find all attributes that match the provided criteria.  
    IF  @NoMatches = 0  
        AND(   @Attribute_MUID IS NOT NULL  
            OR @Attribute_Name IS NOT NULL)  
    BEGIN  
        SET @FilterByAttribute = 1;  
  
        CREATE TABLE #AttributeIds (ID INT PRIMARY KEY);  
        SET @SQL = @TruncationGuard + N'  
        INSERT INTO #AttributeIds(ID)  
        SELECT DISTINCT a.ID  
        FROM mdm.tblAttribute a' +  
  
        -- If an entity filter also exists, then use it to further constrain the results.  
        CASE WHEN @FilterByEntity = 1 THEN N'  
        INNER JOIN #EntityIds e  
        ON a.Entity_ID = e.ID'  
  
        -- Or if there is no entity filter  
        ELSE N'  
        INNER JOIN mdm.tblEntity e  
        ON a.Entity_ID = e.ID  
        INNER JOIN mdm.tblModel m  
        ON e.Model_ID = m.ID'  
  
        END + N'  
        WHERE   (@Attribute_MUID IS NULL OR a.MUID             = @Attribute_MUID)  
            AND (@Attribute_Name IS NULL OR a.Name             = @Attribute_Name)  
            AND (@MemberType_ID  IS NULL OR a.MemberType_ID    = @MemberType_ID);';  
        -- PRINT @SQL  
        EXEC sp_executesql @SQL, N'@Attribute_MUID UNIQUEIDENTIFIER, @Attribute_Name NVARCHAR(100), @MemberType_ID TINYINT', @Attribute_MUID, @Attribute_Name, @MemberType_ID;  
  
        IF NOT EXISTS(SELECT 1 FROM #AttributeIds)  
        BEGIN  
            SET @NoMatches = 1;  
        END;  
    END;  
  
    -- Find all explicit hierarchies that match the provided criteria.  
    IF  @NoMatches = 0  
        AND(   @ExplicitHierarchy_MUID IS NOT NULL  
            OR @ExplicitHierarchy_Name IS NOT NULL)  
    BEGIN  
        SET @FilterByHierarchy = 1;  
  
        CREATE TABLE #HierarchyIds (ID INT PRIMARY KEY);  
        SET @SQL = @TruncationGuard + N'  
        INSERT INTO #HierarchyIds(ID)  
        SELECT DISTINCT h.ID  
        FROM mdm.tblHierarchy h' +  
  
        -- If an entity filter also exists, then use it to further constrain the results.  
        CASE WHEN @FilterByEntity = 1 THEN N'  
        INNER JOIN #EntityIds e  
        ON h.Entity_ID = e.ID'  
  
        -- Or if there is no entity filter  
        ELSE N'  
        INNER JOIN mdm.tblEntity e  
        ON h.Entity_ID = e.ID  
        INNER JOIN mdm.tblModel m  
        ON e.Model_ID = m.ID'  
  
        END + N'  
        WHERE   (@ExplicitHierarchy_MUID IS NULL OR h.MUID    = @ExplicitHierarchy_MUID)  
            AND (@ExplicitHierarchy_Name IS NULL OR h.Name    = @ExplicitHierarchy_Name);';  
        -- PRINT @SQL  
        EXEC sp_executesql @SQL, N'@ExplicitHierarchy_MUID UNIQUEIDENTIFIER, @ExplicitHierarchy_Name NVARCHAR(50)', @ExplicitHierarchy_MUID, @ExplicitHierarchy_Name;  
  
        IF NOT EXISTS(SELECT 1 FROM #HierarchyIds)  
        BEGIN  
            SET @NoMatches = 1;  
        END;  
    END;  
  
    -- Find all users that match the provided criteria.  
    IF  @NoMatches = 0  
        AND(   @User_MUID IS NOT NULL  
            OR @User_Name IS NOT NULL)  
    BEGIN  
        SET @FilterByUser = 1;  
  
        CREATE TABLE #UserIds (ID INT PRIMARY KEY);  
        INSERT INTO #UserIds(ID)  
        SELECT DISTINCT ID  
        FROM mdm.tblUser  
        WHERE   (@User_MUID IS NULL OR MUID        = @User_MUID)  
            AND (@User_Name IS NULL OR UPPER(UserName) LIKE @User_NameUpper);  
  
        IF NOT EXISTS(SELECT 1 FROM #UserIds)  
        BEGIN  
            SET @NoMatches = 1;  
        END;  
    END;  
  
    -- If a member MUID is provided, set FilterByMemberMuid flag  
    IF @Member_MUID IS NOT NULL  
    BEGIN  
        SET @FilterByMemberMuid = 1;  
    END  
  
    -- Find all members that match the provided criteria. We can skip this step if member muid is already provided.  
    IF @NoMatches = 0 AND @FilterByMemberMuid = 0 AND @MemberCode IS NOT NULL  
    BEGIN  
        -- See if we can take the shortcut of filtering on MemberID rather than MemberCode (comparing INTs is cheaper than doing a LIKE on NVARCHARs)  
        IF      @FilterByEntity = 1  
            AND COALESCE(@MemberType_ID, @MemberType_Unknown) IN (@MemberType_Leaf, @MemberType_Consolidated, @MemberType_Collection)  
        BEGIN  
            -- Lookup member id(s) from the provided member code. This will be faster than scanning through the view, doing a LIKE on member code.  
            SET @FilterByMemberId = 1;  
  
            CREATE TABLE #MemberIds  
            (  
                 Entity_ID      INT  
                ,MemberType_ID  TINYINT  
                ,Member_ID             INT  
            );  
            CREATE CLUSTERED INDEX #ix_MemberIds_Entity_ID ON #MemberIds(Entity_ID);  
            CREATE NONCLUSTERED INDEX #ix_MemberIds_MemberType_ID ON #MemberIds(MemberType_ID);  
            CREATE NONCLUSTERED INDEX #ix_MemberIds_Member_ID ON #MemberIds(Member_ID);  
  
            SET @CurrentRow_ID = 1;  
            WHILE EXISTS(SELECT 1 FROM #EntityIds WHERE Row_ID = @CurrentRow_ID)  
            BEGIN  
                SELECT  
                     @CurrentEntity_ID = ID  
                    ,@CurrentMemberTableName = CASE @MemberType_ID  
                        WHEN @MemberType_Leaf THEN LeafMemberTableName  
                        WHEN @MemberType_Consolidated THEN ConsolidatedMemberTableName  
                        WHEN @MemberType_Collection THEN CollectionMemberTableName  
                        END  
                FROM #EntityIds  
                WHERE Row_ID = @CurrentRow_ID;  
                SET @SQL = @TruncationGuard + N'  
                INSERT INTO #MemberIds  
                (  
                     Entity_ID  
                    ,MemberType_ID  
                    ,Member_ID  
                )  
                SELECT  
                     @CurrentEntity_ID  
                    ,@MemberType_ID  
                    ,m.ID  
                FROM mdm.' + @CurrentMemberTableName + N' m' +  
  
                -- If a verion filter also exists, then use it to further constrain the results.  
                CASE WHEN @FilterByVersion = 1 THEN N'  
                INNER JOIN #VersionIds v  
                ON m.Version_ID = v.ID'  
  
                ELSE N'' END + N'  
                WHERE m.Code LIKE @MemberCode  
                ';  
                -- PRINT @SQL  
                EXEC sp_executesql @SQL, N'@MemberCode NVARCHAR(250), @CurrentEntity_ID INT, @MemberType_ID TINYINT', @MemberCode, @CurrentEntity_ID, @MemberType_ID;  
  
                SET @CurrentRow_ID += 1;  
            END; -- WHILE  
  
            IF NOT EXISTS(SELECT 1 FROM #MemberIds)  
            BEGIN  
                SET @NoMatches = 1;  
            END;  
        END ELSE  
        BEGIN  
            -- Not enough info was provided to filter by member ID, so just filter by member code (this will be slower).  
            SET @FilterByMemberCode = 1;  
        END;  
    END;  
  
    -- See if the filters can be simplified.  
    IF @FilterByMemberMuid = 1  
    BEGIN  
            -- We do not need to filter by member code if a member muid is supplied  
        SET @FilterByMemberCode = 0;  
    END  
  
    IF @FilterByMemberId = 1 OR @FilterByMemberMuid = 1  
    BEGIN  
        -- Filtering by MemberId or MemberMuid includes model, version, entity, and member type, so no need to explicitly filter on those.  
        SET @FilterByVersion = 0;  
        SET @FilterByEntity = 0;  
        SET @FilterByMemberType = 0;  
    END  
    ELSE IF @FilterByAttribute = 1  
    BEGIN  
        -- Filtering by attribute includes model, entity, and member type, so no need to explicitly filter on those.  
        SET @FilterByEntity = 0;  
        SET @FilterByMemberType = 0;  
    END  
  
    -- reset the var to build query  
    SET @SQL = N'';  
  
    DECLARE @UseEntitiesToCheckSecurity BIT = 0;  
    IF @IsModelAdmin = 0  
    BEGIN  
        -- Find entity member types that need security check  
        -- and store only the entities that need it  
        CREATE TABLE #EntitiesToCheckSecurity  
        (  
             Row_ID INT PRIMARY KEY IDENTITY  
            ,Entity_ID INT NOT NULL  
            ,MemberType_ID TINYINT NOT NULL  
            ,UseMemberSecurity BIT NOT NULL  
            ,SecurityTableName SYSNAME NULL  
  
        );  
        CREATE NONCLUSTERED INDEX #ix_EntitiesToCheckSecurity_Entity_ID ON #EntitiesToCheckSecurity(Entity_ID);  
  
        -- Find entities that need security check  
        -- and store only the ones that need it  
        WITH cteEntityMemberTypesToCheckSecurity AS  
        (  
            SELECT  
                 memberType.Entity_ID  
                ,memberType.ID AS MemberType_ID  
                ,mdm.udfUseMemberSecurity(@SystemUser_ID, memberType.Entity_ID, @Version_ID, memberType.ID) AS UseMemberSecurity  
                ,CASE memberType.ID  
                    WHEN @MemberType_Leaf THEN CAST(entity.EntityTable + '_MS' AS SYSNAME)  
                    WHEN @MemberType_Consolidated THEN CASE WHEN HierarchyParentTable IS NOT NULL THEN CAST(entity.HierarchyParentTable + '_MS' AS SYSNAME) ELSE NULL END  
                 END AS SecurityTable  
            FROM mdm.viw_SYSTEM_SECURITY_USER_MEMBERTYPE memberType  
            INNER JOIN mdm.tblEntity entity  
            ON entity.ID = memberType.Entity_ID  
            INNER JOIN mdm.tblModel model  
            ON model.ID = entity.Model_ID  
            WHERE model.ID = @Model_ID  
                AND (@Entity_ID IS NULL OR entity.ID = @Entity_ID)  
                AND (@MemberType_ID IS NULL OR memberType.ID = @MemberType_ID)  
                AND (Privilege_ID <> @Permission_Deny)  
        )  
        INSERT INTO #EntitiesToCheckSecurity  
        SELECT DISTINCT  
             Entity_ID  
            ,MemberType_ID  
            ,UseMemberSecurity  
            ,SecurityTable  
        FROM cteEntityMemberTypesToCheckSecurity  
        WHERE UseMemberSecurity <> 0;  
  
        -- begin building the where clause for CTEs  
        IF EXISTS(SELECT 1 FROM #EntitiesToCheckSecurity)  
        BEGIN  
            SET @UseEntitiesToCheckSecurity = 1;  
            SET @WhereCriteria += @TruncationGuard + N'    AND (t.Member_ID IS NULL OR sec.UseMemberSecurity = 0)';  
        END  
  
        -- begin a loop that generates CTEs to look up member level security  
        -- the CTEs will be named based on their member security tables, e.g. cte_tbl_1_1_MS  
        SET @CurrentRow_ID = 1;  
        WHILE EXISTS(SELECT 1 FROM #EntitiesToCheckSecurity WHERE Row_ID = @CurrentRow_ID)  
        BEGIN  
            SELECT  
                 @CurrentEntity_ID = Entity_ID  
                ,@CurrentSecurityTableName = SecurityTableName  
                ,@CurrentMemberSecurity = UseMemberSecurity  
                ,@CurrentMemberType_ID = MemberType_ID  
            FROM #EntitiesToCheckSecurity  
            WHERE Row_ID = @CurrentRow_ID  
  
            IF @CurrentMemberSecurity = 1  
            BEGIN  
                -- begin generating CTEs  
                IF @IsFirstCTE = 1  
                BEGIN  
                    SET @SQL += @TruncationGuard + N'  
        ;WITH'  
                    SET @IsFirstCTE = 0;  
                END  
                ELSE  
                BEGIN  
                    SET @SQL += @TruncationGuard + N'  
        ,';  
                END  
  
                SET @CurrentCTE = N' cte_' + @CurrentSecurityTableName;  
  
                -- the CTE will contain Member_ID column that is either EN_ID or HP_ID depending on the member type  
                SET @SQL += CONCAT(@TruncationGuard + @CurrentCTE + N' AS  
        (  
            SELECT  
                ID AS Member_ID,  
                ', @CurrentMemberType_ID, N' AS MemberType_ID,  
                ', @CurrentEntity_ID,'AS Entity_ID  
            FROM  
                mdm.', QUOTENAME(@CurrentSecurityTableName), N' X  
            WHERE X.User_ID = @SystemUser_ID  
                AND X.Version_ID = @Version_ID  
        )');  
  
                -- build the join clause to join on entity, entity member type, and member id  
                SET @Join += @TruncationGuard + N'  
        LEFT JOIN ' + @CurrentCTE + N' ' + @CurrentCTE + N'  
        ON t.Entity_ID = ' + @CurrentCTE + N'.Entity_ID AND t.MemberType_ID = ' + @CurrentCTE + N'.MemberType_ID AND t.Member_ID = ' + @CurrentCTE + N'.Member_ID';  
  
                -- build the where clause to exclude members that need to evaluate member security  
                SET @WhereCriteria += @TruncationGuard + N' OR ' + @CurrentCTE + N'.Member_ID IS NOT NULL';  
            END  
            SET @CurrentRow_ID += 1;  
        END -- while  
  
        -- wrap up building the where clause for CTEs  
        IF EXISTS(SELECT 1 FROM #EntitiesToCheckSecurity)  
        BEGIN  
            SET @WhereCriteria += @TruncationGuard + N')';  
        END  
  
    END -- if  
  
    -- Create the FROM clause, using INNER JOINs to filter on various ID columns (most of which have FK relationships, so they are indexed).  
    SET @From = @TruncationGuard + N'  
        FROM [mdm].' + QUOTENAME(@TransactionViewName) + N' AS t ' +  
    CASE WHEN @FilterByVersion = 1 THEN N'  
        INNER JOIN #VersionIds v  
        ON t.Version_ID = v.ID' ELSE N'' END +  
    CASE WHEN @FilterByEntity = 1 THEN N'  
        INNER JOIN #EntityIds e  
        ON t.Entity_ID = e.ID' ELSE N'' END +  
    CASE WHEN @FilterByHierarchy = 1 THEN N'  
        INNER JOIN #HierarchyIds h  
        ON t.ExplicitHierarchy_ID = h.ID' ELSE N'' END +  
    CASE WHEN @FilterByAttribute = 1 THEN N'  
        INNER JOIN #AttributeIds a  
        ON t.Attribute_ID = a.ID' ELSE N'' END +  
    CASE WHEN @FilterByUser = 1 THEN N'  
        INNER JOIN #UserIds u  
        ON t.[User ID] = u.ID' ELSE N'' END +  
    CASE WHEN @FilterByMemberId = 1 THEN N'  
        INNER JOIN #MemberIds mem  
        ON      t.Entity_ID = mem.Entity_ID  
            AND t.MemberType_ID = mem.MemberType_ID  
            AND t.Member_ID = mem.Member_ID' ELSE N'' END +  
    CASE WHEN @IsModelAdmin = 0 THEN N'  
        LEFT JOIN mdm.viw_SYSTEM_SECURITY_USER_ENTITY eAcl  
        ON t.Entity_ID = eAcl.ID AND eAcl.User_ID = @SystemUser_ID AND eAcl.Privilege_ID <> 1  
        LEFT JOIN mdm.viw_SYSTEM_SECURITY_USER_ATTRIBUTE aAcl  
        ON  t.Attribute_ID = aAcl.ID AND aAcl.User_ID = @SystemUser_ID'  
        + CASE @UseEntitiesToCheckSecurity WHEN 1 THEN N'  
        LEFT JOIN #EntitiesToCheckSecurity sec  
        ON t.Entity_ID = sec.Entity_ID AND t.MemberType_ID = sec.MemberType_ID' ELSE N'' END  
        ELSE N'' END;  
  
    -- Create the WHERE clause to filter on additional values.  
  
    IF @IsModelAdmin = 0  
    BEGIN  
        -- build the where clause to ensure user has privileges on attribute and entity  
        SET @WhereCriteria += @TruncationGuard + N'  
            AND (t.Entity_ID IS NULL OR t.Entity_ID = eAcl.ID)  
            AND (t.Attribute_ID IS NULL OR t.Attribute_ID = aAcl.ID)'  
    END  
  
    IF @FilterByMemberType = 1  
    BEGIN  
        SET @WhereCriteria += @TruncationGuard + N'  
            AND t.MemberType_ID = @MemberType_ID';  
    END;  
  
    IF @Transaction_ID IS NOT NULL  
    BEGIN  
        SET @WhereCriteria += @TruncationGuard + N'  
            AND t.ID = @Transaction_ID';  
    END  
  
    IF @TransactionType_ID IS NOT NULL  
    BEGIN  
        SET @WhereCriteria += @TruncationGuard + N'  
            AND t.TransactionType_ID = @TransactionType_ID';  
    END  
  
    IF @FilterByMemberMuid = 1  
    BEGIN  
        SET @WhereCriteria += @TruncationGuard + N'  
                AND t.[Member_MUID] = @Member_MUID';  
    END  
  
    IF @NewValue IS NOT NULL  
    BEGIN  
        SET @WhereCriteria += @TruncationGuard + N'  
            AND t.[New Value] LIKE @NewValue';  
    END  
  
    IF @PriorValue IS NOT NULL  
    BEGIN  
        SET @WhereCriteria += @TruncationGuard + N'  
            AND t.[Prior Value] LIKE @PriorValue';  
    END  
  
    IF @FilterByMemberCode = 1  
    BEGIN  
        SET @WhereCriteria += @TruncationGuard + N'  
            AND t.[Member Code] LIKE @MemberCode';  
    END  
  
    IF @DateTimeBeginRange IS NOT NULL  
    BEGIN  
        SET @WhereCriteria += @TruncationGuard + N'  
            AND t.[Date Time] >= @DateTimeBeginRange';  
    END  
  
    IF @DateTimeEndRange IS NOT NULL  
    BEGIN  
        SET @WhereCriteria += @TruncationGuard + N'  
            AND t.[Date Time] <= @DateTimeEndRange';  
    END  
  
    -- Remove the leading 'AND' and prepend 'WHERE'.  
    IF LEN(@WhereCriteria) > 0  
    BEGIN  
        SET @WhereCriteria = SUBSTRING(@WhereCriteria, CHARINDEX(N'AND ', @WhereCriteria) + 4, LEN(@WhereCriteria));-- Remove leading AND  
        SET @WhereCriteria = @TruncationGuard + N'  
        WHERE   ' + @WhereCriteria;  
    END  
  
    IF @CountOnly = 1  
    BEGIN  
        SET @SQL += @TruncationGuard + N'  
        SELECT COUNT(t.ID) AS MemberRowCount'  
        + @From  
        + @Join  
        + @WhereCriteria;  
    END ELSE  
    BEGIN  
        -- The returned columns must be in the correct order (see http://msdn.microsoft.com/en-us/library/ms729813.aspx) or DataContractSerializer  
         -- may fail (sometimes silently) to deserialize out-of-order columns.  
         -- Core.BusinessEntities.Transaction members  
  
        IF @IsFirstCTE = 1  
        BEGIN  
            SET @SQL += @TruncationGuard + N'  
    ;WITH'  
            SET @IsFirstCTE = 0;  
        END  
        ELSE  
        BEGIN  
            SET @SQL += @TruncationGuard + N'  
    ,';  
        END  
        SET @SQL += @TruncationGuard + N' ctePaging AS  
    (  
        SELECT  
            t.*,  
            ROW_NUMBER() OVER(ORDER BY t.' + QUOTENAME(@SortColumn) + N' ' + CASE @SortDirection WHEN N'ASC' THEN N'ASC' ELSE N'DESC' END + N') AS Row'  
        + @From  
        + @Join  
        + @WhereCriteria + N'  
    )  
    SELECT  
         [Attribute_ID]  
        ,[Attribute_MUID]  
        ,[Attribute] AS [Attribute_Name]  
        ,[Date Time] AS [Date]  
        ,[Entity_ID]  
        ,[Entity_MUID]  
        ,[Entity] AS [Entity_Name]  
        ,[ExplicitHierarchy_ID]  
        ,[ExplicitHierarchy_MUID]  
        ,[Explicit Hierarchy] AS [ExplicitHierarchy_Name]  
        ,[ID]  
        ,[Member_ID]  
        ,[Member_MUID]  
        ,[Member Code] AS [Member_Code]  
        ,[MemberType_ID] AS [Member_Type]  
        ,[Model_ID]  
        ,[Model_MUID]  
        ,[Model_Name]  
        ,[New Value] AS [New_Value]  
        ,[Prior Value] AS [Prior_Value]  
        ,[TransactionType_ID] AS [TransactionType]  
        ,[User ID] AS [User_ID]  
        ,[User_MUID]  
        ,[User Name] AS [User_Name]  
        ,[Version_ID]  
        ,[Version_MUID]  
        ,[Version_Name]  
    FROM ctePaging AS t  
    WHERE t.Row BETWEEN @StartRow AND @EndRow  
    ;';  
    END;  
  
    -- PRINT @SQL  
  
    EXEC sp_executesql @SQL,  
            N' @SystemUser_ID                 INT  
              ,@Model_ID                INT  
              ,@MemberType_ID           TINYINT  
              ,@NewValue                NVARCHAR(MAX)  
              ,@PriorValue              NVARCHAR(MAX)  
              ,@MemberCode              NVARCHAR(250)  
              ,@Member_MUID             UNIQUEIDENTIFIER  
              ,@Transaction_ID          INT  
              ,@TransactionType_ID      INT  
              ,@DateTimeBeginRange      DATETIME2(3)  
              ,@DateTimeEndRange        DATETIME2(3)  
              ,@StartRow                INT  
              ,@EndRow                  INT  
              ,@MemberType_Leaf         TINYINT  
              ,@MemberType_Consolidated TINYINT',  
  
               @SystemUser_ID  
              ,@Model_ID  
              ,@MemberType_ID  
              ,@NewValue  
              ,@PriorValue  
              ,@MemberCode  
              ,@Member_MUID  
              ,@Transaction_ID  
              ,@TransactionType_ID  
              ,@DateTimeBeginRange  
              ,@DateTimeEndRange  
              ,@StartRow  
              ,@EndRow  
              ,@MemberType_Leaf  
              ,@MemberType_Consolidated;  
  
    SET NOCOUNT OFF  
  
END --proc
go

