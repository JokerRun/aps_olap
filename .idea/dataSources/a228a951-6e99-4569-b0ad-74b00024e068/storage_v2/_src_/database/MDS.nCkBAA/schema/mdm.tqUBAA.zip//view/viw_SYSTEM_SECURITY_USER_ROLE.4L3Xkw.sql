/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE VIEW mdm.viw_SYSTEM_SECURITY_USER_ROLE  
/*WITH SCHEMABINDING*/  
AS  
SELECT  
   COALESCE(uga.User_ID, sac.Principal_ID) User_ID,   
   sac.Role_ID,  
   CASE WHEN uga.User_ID IS NULL THEN 0 ELSE 1 END IsUserGroupAssignment  
FROM mdm.tblSecurityAccessControl sac  
LEFT JOIN mdm.tblUserGroupAssignment uga  
ON      sac.PrincipalType_ID = 2-- Group  
    AND sac.Principal_ID = uga.UserGroup_ID  
WHERE   sac.PrincipalType_ID = 1--User  
    OR  uga.User_ID IS NOT NULL -- exclude groups that have no users
go

