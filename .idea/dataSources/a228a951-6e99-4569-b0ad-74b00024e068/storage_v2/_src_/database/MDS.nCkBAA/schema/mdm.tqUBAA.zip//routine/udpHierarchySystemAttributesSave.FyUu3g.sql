/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
recalculates the level number, sort order, and index code for each member relationship in a hierarchy within a version  
*/  
CREATE PROCEDURE mdm.udpHierarchySystemAttributesSave   
(  
    @Version_ID INT,   
    @Hierarchy_ID INT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON;  
    --Calculate level numbers for the hierarchy  
    EXEC mdm.udpHierarchyMemberLevelSave @Version_ID, @Hierarchy_ID, 0, 2  
  
    --Recalibrate sort orders for the hierarchy   
    EXEC mdm.udpHierarchySortOrderSave @Version_ID, @Hierarchy_ID  
  
    --Recalculate index codes for the hierarchy   
    --EXEC mdm.udpHierarchyIndexCodeSave @Version_ID, @Hierarchy_ID  
  
    SET NOCOUNT OFF;  
END --proc
go

