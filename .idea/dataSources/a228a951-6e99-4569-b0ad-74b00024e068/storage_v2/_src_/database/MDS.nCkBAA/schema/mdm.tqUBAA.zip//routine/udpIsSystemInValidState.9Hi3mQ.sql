/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
    A simple stored procedure that the API can call to determine  
      1) Is the connection to the database still alive  
      2) If so (this sproc will get called) are the system tables populated.  
  
    DECLARE @RET AS INT;  
    EXEC mdm.udpIsSystemInValidState @RET OUTPUT;  
    SELECT @RET;  
*/  
CREATE PROCEDURE mdm.udpIsSystemInValidState  
(  
    @Return_ID BIT OUTPUT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    --Check core system tables for the existence of records  
    IF  EXISTS (SELECT 1 FROM mdm.tblSystemSetting)   
        AND EXISTS (SELECT 1 FROM mdm.tblUser)  
        AND EXISTS (SELECT 1 FROM mdm.tblList)  
        AND EXISTS (SELECT 1 FROM mdm.tblSecurityPrivilegeFunctional)  
        AND EXISTS (SELECT 1 FROM mdm.tblSecurityObject)  
        AND EXISTS (SELECT 1 FROM mdm.tblSecurityPrivilege)  
        AND EXISTS (SELECT 1 FROM mdm.tblBRItemTypeAppliesTo)  
        SET @Return_ID = 1;  
    ELSE  
        SET @Return_ID = 0;  
  
    SET NOCOUNT OFF;  
END; --proc
go

