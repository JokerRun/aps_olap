/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
--Puts a msg on the qureue for the user  
Then inserts a timer msg onto the queue to effectively "kick it off"  
  
--Account  
EXEC mdm.udpSecurityMemberProcessRebuildUser @User_ID=3  
*/  
CREATE PROCEDURE mdm.udpSecurityMemberProcessRebuildUser  
(  
    @User_ID        INT, --Required  
    @ProcessNow     BIT = 0,  
    @CorrelationID              UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE @SecurityMemberProcessEvent mdm.SecurityMemberProcessEvent  
  
    INSERT @SecurityMemberProcessEvent ([User_ID], [Entity_ID], Version_ID)  
    SELECT DISTINCT [User_ID], [Entity_ID], Version_ID  
    FROM [mdm].[viw_SYSTEM_SECURITY_ROLE_MEMBER] rm  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ROLE ur  
    ON rm.Role_ID = ur.Role_ID  
    WHERE ur.[User_ID] = @User_ID;  
  
    EXEC mdm.udpSecurityMemberProcessRebuildEvent @SecurityMemberProcessEvent, @ProcessNow  
  
    SET NOCOUNT OFF;  
END; --proc
go

