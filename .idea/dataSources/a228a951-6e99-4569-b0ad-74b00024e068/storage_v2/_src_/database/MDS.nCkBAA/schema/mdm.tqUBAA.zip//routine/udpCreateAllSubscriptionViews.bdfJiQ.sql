/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    DECLARE @Entity_ID INT;  
    SET @Entity_ID = 72;  
    EXEC mdm.udpCreateAllSubscriptionViews NULL, @Entity_ID;  
      
  
    EXEC mdm.udpCreateAllSubscriptionViews;  
  
*/  
CREATE PROCEDURE mdm.udpCreateAllSubscriptionViews  
(  
    @Model_ID   INT = NULL,  
    @Entity_ID  INT = NULL,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON;  
  
        --    IF EXISTS(SELECT * FROM [mdm].[tblSubscriptionView] WHERE @Entity_ID IS NULL OR Entity_ID = @Entity_ID)  
        --BEGIN  
        DECLARE @SubscriptionViewID       INT,   
                @ViewEntity_ID            INT,  
                @DerivedHierarchy_ID      INT,  
                @ViewFormat_ID            INT,  
                @ModelVersion_ID          INT,  
                @ModelVersionFlag_ID      INT,  
                @SubscriptionViewName     SYSNAME,  
                @Levels                   SMALLINT,  
                @IncludeSoftDeletedMembers BIT;  
  
        --Table variable we use to iterate through subscription views  
        DECLARE @subscriptionViews TABLE     
        (    
            ID                  INT PRIMARY KEY NOT NULL,      
            Entity_ID           INT NULL,  
            DerivedHierarchy_ID INT NULL,  
            ViewFormat_ID       INT NOT NULL,  
            ModelVersion_ID     INT NULL,  
            ModelVersionFlag_ID INT NULL,  
            Name                SYSNAME NOT NULL,  
            Levels              SMALLINT NULL,  
            IncludeSoftDeletedMembers BIT NOT NULL  
        );            
              
        --Fill out the temp table with the subscription view definitions  
        INSERT INTO @subscriptionViews  
        (  
             ID  
            ,Entity_ID  
            ,DerivedHierarchy_ID  
            ,ViewFormat_ID  
            ,ModelVersion_ID  
            ,ModelVersionFlag_ID  
            ,Name  
            ,Levels  
            ,IncludeSoftDeletedMembers  
        )  
        SELECT   
             sv.ID  
            ,sv.Entity_ID  
            ,sv.DerivedHierarchy_ID  
            ,sv.ViewFormat_ID  
            ,sv.ModelVersion_ID  
            ,sv.ModelVersionFlag_ID  
            ,sv.Name  
            ,CONVERT(SMALLINT, sv.Levels)  
            ,sv.IncludeSoftDeletedMembers  
        FROM mdm.tblSubscriptionView sv  
        INNER JOIN mdm.tblEntity e   
        ON sv.Entity_ID = e.ID  
        WHERE   (@Entity_ID IS NULL OR sv.Entity_ID = @Entity_ID)  
            AND (@Model_ID IS NULL OR e.Model_ID = e.Model_ID);  
  
        --Iterate through the subscription view definitions  
        WHILE EXISTS(SELECT 1 FROM @subscriptionViews)   
        BEGIN  
  
            SELECT TOP 1  
                @SubscriptionViewID = ID,  
                @ViewEntity_ID = Entity_ID,  
                @DerivedHierarchy_ID = DerivedHierarchy_ID,  
                @ViewFormat_ID = ViewFormat_ID,  
                @ModelVersion_ID = ModelVersion_ID,  
                @ModelVersionFlag_ID = ModelVersionFlag_ID,  
                @SubscriptionViewName = Name,  
                @Levels = Levels,  
                @IncludeSoftDeletedMembers = IncludeSoftDeletedMembers  
            FROM @subscriptionViews  
            ORDER BY ID;    
  
            --Call udpCreateSubscriptionViews to create each view  
            --The SPROCS udpCreateSubscriptionViews calls are smart enough to ALTER (instead of CREATE) if the view already exists  
            -- so there is no risk of us trying to recreate an existing view  
            EXEC mdm.udpCreateSubscriptionViews @SubscriptionViewID, @ViewEntity_ID, @DerivedHierarchy_ID, @ModelVersion_ID, @ModelVersionFlag_ID, @ViewFormat_ID, @Levels, @SubscriptionViewName, @IncludeSoftDeletedMembers;  
  
            DELETE FROM @subscriptionViews WHERE ID = @SubscriptionViewID  
  
        END; -- WHILE  
  
    SET NOCOUNT OFF;  
END; --proc
go

