/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Gets information about the given user.  
  
EXEC mdm.udpUserGet 5  
EXEC mdm.udpUserGet 11  
*/  
CREATE PROCEDURE mdm.udpUserGet  
(  
    @User_ID INT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    SELECT  
        u.ID,  
        u.MUID,  
        u.SID,  
        u.UserName,  
        u.DisplayName,  
        u.Description,  
        u.EmailAddress,  
        u.LastLoginDTM,  
-       u.EnterUserID,  
        eu.MUID AS EnterUserMUID,  
        COALESCE(eu.UserName,N'') AS EnterUserName,  
        COALESCE(eu.DisplayName,N'') AS EnterUserDisplayName,  
        u.EnterDTM,  
        u.LastChgUserID,  
        eu.MUID AS LastChgUserMUID,  
        COALESCE(lcu.UserName,N'') AS LastChgUserName,  
        COALESCE(lcu.DisplayName,N'') AS LastChgUserDisplayName,  
        u.LastChgDTM,  
        pref.PreferenceValue AS EmailType    
    FROM  
        mdm.tblUser u  
        LEFT OUTER JOIN mdm.tblUser eu ON u.EnterUserID = eu.ID   
        LEFT OUTER JOIN mdm.tblUser lcu ON u.LastChgUserID = lcu.ID  
        LEFT OUTER JOIN mdm.tblUserPreference pref on u.ID = pref.User_ID AND PreferenceName='lstEmail'  
    WHERE  
        u.ID = @User_ID   
        AND u.Status_ID <> 2  
  
    SET NOCOUNT OFF  
END --proc
go

