/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
mdm.udpUserDelete 'admin','jsmith'  
select * from mdm.tblUser  
*/  
CREATE PROCEDURE mdm.udpUserDelete  
(  
    @SystemUser_ID  INT, --Person performing save  
    @User_MUID      UNIQUEIDENTIFIER,  
    @SID            NVARCHAR(250) = NULL OUTPUT,  
    @CorrelationID  UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    DECLARE @GuidEmpty  UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER),  
            @User_ID    INT;  
  
    SET @User_MUID = NULLIF(@User_MUID, @GuidEmpty);  
  
    SELECT @User_ID = ID, @SID = [SID] FROM mdm.tblUser WHERE MUID = @User_MUID  
    IF @User_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR500043|The user cannot be deleted. The ID is not valid.', 16, 1);  
        RETURN;  
    END  
  
    IF @SystemUser_ID = @User_ID  
    BEGIN  
        RAISERROR('MDSERR500019|The logged-in user cannot be deleted.', 16, 1);  
        RETURN;   
    END  
  
    IF NOT EXISTS (  
        SELECT 1  
        FROM [mdm].[viw_SYSTEM_SECURITY_USER_FUNCTION]  
        WHERE [User_ID] != @User_ID AND Function_ID = 6 /*Super User*/  
    )  
    BEGIN  
        RAISERROR('MDSERR500047|The administrator cannot be deleted.', 16, 1);  
        RETURN;  
    END  
  
    --Start transaction, being careful to check if we are nested  
    DECLARE @TranCounter INT = @@TRANCOUNT;  
    IF @TranCounter > 0   
    BEGIN  
        SAVE TRANSACTION TX;  
    END ELSE   
    BEGIN  
        BEGIN TRANSACTION;  
    END;  
  
    BEGIN TRY  
        DECLARE   
             @PrincipalType_User TINYINT = 1  
            ,@Status_Inactive    TINYINT = 2;  
  
        -- Save all the users we need renbuild the member security  
        DECLARE @SecurityMemberProcessEvent mdm.SecurityMemberProcessEvent  
  
        INSERT @SecurityMemberProcessEvent ([User_ID], [Entity_ID], Version_ID)  
        SELECT DISTINCT [User_ID], [Entity_ID], Version_ID  
        FROM [mdm].[viw_SYSTEM_SECURITY_ROLE_MEMBER] rm  
        INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ROLE ur  
        ON rm.Role_ID = ur.Role_ID  
        WHERE ur.[User_ID] = @User_ID;  
  
        EXEC mdm.udpSecurityPrivilegesDeleteByPrincipalID @SystemUser_ID, @User_ID, @PrincipalType_User  
  
        UPDATE  
            mdm.tblUser  
        SET  
            Status_ID = @Status_Inactive,  
            LastChgUserID = @SystemUser_ID,  
            LastChgDTM = GETUTCDATE()  
        FROM  
            mdm.tblUser  
        WHERE  
            ID = @User_ID  
  
        EXEC mdm.udpUserGroupAssignmentDelete @SystemUser_ID, @User_ID, NULL, 0;  
  
        -- Queue a event to immediate recompute affected user  
        EXEC mdm.udpSecurityMemberProcessRebuildEvent @SecurityMemberProcessEvent, 1;  
  
        -- Commit transaction only if not nested.  
        IF @TranCounter = 0  
        BEGIN  
            COMMIT TRANSACTION;  
        END;  
    END TRY  
    BEGIN CATCH  
  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        -- Roll back the transaction.  
        IF @TranCounter = 0 ROLLBACK TRANSACTION;  
        ELSE IF XACT_STATE() <> -1 ROLLBACK TRANSACTION TX;  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
  
    END CATCH;  
  
    SET NOCOUNT OFF  
END --proc
go

