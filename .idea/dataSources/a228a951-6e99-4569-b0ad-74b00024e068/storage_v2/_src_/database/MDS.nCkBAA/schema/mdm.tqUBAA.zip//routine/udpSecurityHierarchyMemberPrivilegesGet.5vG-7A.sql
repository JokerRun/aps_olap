/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    Returns the specified groups.  
  
    DECLARE @RoleAccessTable mdm.Identifier  
    EXEC udpSecurityHierarchyMemberPrivilegesGet  
        @SystemUser_ID          = 1,  
        @Permission_ID          = NULL,  
        @Model_MUID             = NULL,  
        @Model_Name             = NULL,  
        @Entity_MUID            = NULL,  
        @Entity_Name            = NULL,  
        @Hierarchy_MUID         = NULL,  
        @Hierarchy_Name         = NULL,  
        @HierarchyType_ID       = NULL,  
        @Principal_MUID         = NULL,  
        @Principal_Name         = NULL,  
        @PrincipalType_ID       = NULL,  
        @RoleAccessTable        = @RoleAccessTable  
*/  
CREATE PROCEDURE mdm.udpSecurityHierarchyMemberPrivilegesGet  
(  
    @SystemUser_ID          INT, -- The user requesting the permissions  
    @Permission_ID          INT = NULL,  
    @AccessPermission_ID    TINYINT = NULL,  
    @Model_MUID             UNIQUEIDENTIFIER = NULL,  
    @Model_Name             NVARCHAR(100) = NULL,  
    @Entity_MUID            UNIQUEIDENTIFIER = NULL,  
    @Entity_Name            NVARCHAR(MAX) = NULL,  
    @Hierarchy_MUID         UNIQUEIDENTIFIER = NULL,  
    @Hierarchy_Name         NVARCHAR(100) = NULL,  
    @HierarchyType_ID       INT = NULL,  
    @Principal_MUID         UNIQUEIDENTIFIER = NULL,  
    @Principal_Name         NVARCHAR(355) = NULL, -- max user group name length  
    @PrincipalType_ID       INT = NULL,  
    @RoleAccessTable        mdm.Identifier READONLY,-- caller should ensure table does not include rows where both MUID and Name are blank  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    IF(EXISTS (SELECT 1 FROM sys.sysobjects WHERE name = '#tblPrivileges'))  
    BEGIN  
        DROP TABLE #tblPrivileges;  
    END  
  
    DECLARE @PrincipalType_User TINYINT = 1;  
  
    CREATE TABLE #tblPrivileges(  
               [RoleAccess_ID]      INT  
              ,[RoleAccess_MUID]    UNIQUEIDENTIFIER  
              ,[Privilege_ID]       INT  
              ,[AccessPermission]   TINYINT  
              ,[PrincipalType_ID]   TINYINT  
              ,[Principal_ID]       INT  
              ,[Principal_MUID]     UNIQUEIDENTIFIER  
              ,[Principal_Name]     NVARCHAR(100) COLLATE DATABASE_DEFAULT  
              ,[Model_ID]           INT  
              ,[Model_MUID]         UNIQUEIDENTIFIER  
              ,[Model_Name]         NVARCHAR(100) COLLATE DATABASE_DEFAULT  
              ,[Version_ID]         INT  
              ,[Version_MUID]       UNIQUEIDENTIFIER  
              ,[Version_Name]       NVARCHAR(100) COLLATE DATABASE_DEFAULT  
              ,[Entity_ID]          INT  
              ,[Entity_MUID]        UNIQUEIDENTIFIER  
              ,[Entity_Name]        NVARCHAR(MAX) COLLATE DATABASE_DEFAULT  
              ,[HierarchyType_ID]   TINYINT  
              ,[Hierarchy_ID]       INT  
              ,[Hierarchy_MUID]     UNIQUEIDENTIFIER  
              ,[Hierarchy_Name]     NVARCHAR(250) COLLATE DATABASE_DEFAULT  
              ,[MemberType_ID]      TINYINT  
              ,[Member_ID]          INT  
              ,[Member_MUID]        UNIQUEIDENTIFIER  
              ,[Member_Name]        NVARCHAR(250) COLLATE DATABASE_DEFAULT  
              ,[Member_Code]        NVARCHAR(250) COLLATE DATABASE_DEFAULT  
              ,EnterUserID          INT  
              ,EnterUserMUID        UNIQUEIDENTIFIER  
              ,EnterUser            NVARCHAR(256) COLLATE DATABASE_DEFAULT  
              ,EnterDTM             DATETIME2(2)  
              ,LastChgUserID        INT  
              ,LastChgUserMUID      UNIQUEIDENTIFIER  
              ,LastChgUser          NVARCHAR(256) COLLATE DATABASE_DEFAULT  
              ,LastChgDTM           DATETIME2(2)  
              ,IsModelAdministrator BIT  
                );  
  
    DECLARE @MemberIds TABLE (  
        ID                       INT IDENTITY (1, 1) NOT NULL,  
        Version_ID               INT,  
        Entity_ID                INT,  
        MemberType_ID            INT,  
        TableName                NVARCHAR(100) COLLATE DATABASE_DEFAULT  
            );  
  
    INSERT INTO #tblPrivileges  
    SELECT  
         r.RoleAccess_ID  
        ,r.RoleAccess_MUID  
        ,r.Privilege_ID  
        ,r.AccessPermission  
        ,r.PrincipalType_ID  
        ,r.Principal_ID  
        ,r.Principal_MUID  
        ,r.Principal_Name  
        ,r.Model_ID  
        ,r.Model_MUID  
        ,r.Model_Name  
        ,r.Version_ID  
        ,r.Version_MUID  
        ,r.Version_Name  
        ,r.Entity_ID  
        ,r.Entity_MUID  
        ,r.Entity_Name  
        ,r.HierarchyType_ID  
        ,r.Hierarchy_ID  
        ,r.Hierarchy_MUID  
        ,r.Hierarchy_Name  
        ,r.MemberType_ID  
        ,r.Member_ID  
        ,NULL Member_MUID  
        ,NULL Member_Name  
        ,NULL Member_Code  
        ,r.EnterUserID  
        ,r.EnterUserMUID  
        ,r.EnterUser  
        ,r.EnterDTM  
        ,r.LastChgUserID  
        ,r.LastChgUserMUID  
        ,r.LastChgUser  
        ,r.LastChgDTM  
        ,CASE modSec.Privilege_ID WHEN 5 /*Admin*/ THEN 1 ELSE 0 END IsModelAdministrator  
    FROM mdm.viw_SYSTEM_SECURITY_ROLE_ACCESSCONTROL_MEMBER r  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_MODEL sysModelSec -- Gets the model permission of the user requesting the permissions.  
    ON      sysModelSec.User_ID = @SystemUser_ID  
        AND sysModelSec.ID = r.Model_ID  
    LEFT JOIN mdm.viw_SYSTEM_SECURITY_USER_MODEL modSec -- Gets the model permissions of the principal (user only) being requested.  
    ON      modSec.ID = r.Model_ID  
        AND modSec.User_ID = r.Principal_ID  
        AND r.PrincipalType_ID = @PrincipalType_User  
    WHERE  (   sysModelSec.Privilege_ID = 5 /*Admin*/                                         -- To see permissions, the requesting user must either be a model admin ...  
            OR (@SystemUser_ID = r.Principal_ID AND @PrincipalType_ID = @PrincipalType_User)) -- ... or asking for his own permissions  
  
    -- apply additional filtering  
    IF EXISTS(SELECT 1 FROM @RoleAccessTable)  
    BEGIN  
        DELETE p  
        FROM #tblPrivileges p  
        LEFT JOIN @RoleAccessTable crit  
        ON      p.RoleAccess_MUID = ISNULL(crit.MUID, p.RoleAccess_MUID)  
            AND p.RoleAccess_ID = ISNULL(crit.ID, p.RoleAccess_ID)  
        WHERE crit.ID IS NULL AND crit.MUID IS NULL  
    END  
  
    DECLARE @PrincialNameUpper NVARCHAR(355) = UPPER(@Principal_Name);  
    IF (@Permission_ID IS NOT NULL AND @Permission_ID > 0)  
        DELETE FROM #tblPrivileges WHERE Privilege_ID       <> @Permission_ID;  
    IF (@AccessPermission_ID IS NOT NULL)  
        DELETE FROM #tblPrivileges WHERE AccessPermission <> @AccessPermission_ID;  
    IF (@Model_MUID IS NOT NULL)  
        DELETE FROM #tblPrivileges WHERE Model_MUID         <> @Model_MUID;  
    IF (@Model_Name IS NOT NULL)  
        DELETE FROM #tblPrivileges WHERE Model_Name         <> @Model_Name;  
    IF (@Entity_MUID IS NOT NULL)  
        DELETE FROM #tblPrivileges WHERE Entity_MUID        <> @Entity_MUID;  
    IF (@Entity_Name IS NOT NULL)  
        DELETE FROM #tblPrivileges WHERE Entity_Name        <> @Entity_Name;  
    IF (@Hierarchy_MUID IS NOT NULL)  
        DELETE FROM #tblPrivileges WHERE Hierarchy_MUID     <> @Hierarchy_MUID;  
    IF (@Hierarchy_Name IS NOT NULL)  
        DELETE FROM #tblPrivileges WHERE Hierarchy_Name     <> @Hierarchy_Name;  
    DECLARE @HierarchyType_All INT = 3; -- constant  
    IF (@HierarchyType_ID IS NOT NULL AND @HierarchyType_ID <> @HierarchyType_All)  
        DELETE FROM #tblPrivileges WHERE HierarchyType_ID   <> @HierarchyType_ID;  
    IF (@Principal_MUID IS NOT NULL)  
        DELETE FROM #tblPrivileges WHERE Principal_MUID     <> @Principal_MUID;  
    IF (@Principal_Name IS NOT NULL)  
        DELETE FROM #tblPrivileges WHERE UPPER(Principal_Name)     <> @PrincialNameUpper;  
    IF (@PrincipalType_ID IS NOT NULL AND @PrincipalType_ID > 0)  
        DELETE FROM #tblPrivileges WHERE PrincipalType_ID   <> @PrincipalType_ID;  
  
    INSERT INTO @MemberIds (Version_ID, Entity_ID, MemberType_ID, TableName)  
    SELECT DISTINCT  
        Version_ID,  
        Entity_ID,  
        MemberType_ID,  
        mdm.udfTableNameGetByID(Entity_ID, MemberType_ID)  
    FROM #tblPrivileges  
    WHERE Member_ID > 0 -- Ignore ROOT and MDMUNUSED (they will be handled later)  
  
    DECLARE  
        @ID             INT,  
        @SQL            NVARCHAR(MAX),  
        @Version_ID     INT,  
        @Entity_ID      INT,  
        @MemberType_ID  INT,  
        @TableName      SYSNAME,  
        @ParamList      NVARCHAR(MAX) = N'  
            @Version_ID INT,  
            @Entity_ID INT,  
            @MemberType_ID INT';  
  
    --Update the Member_Name and Member_MUID columns  
    WHILE EXISTS(SELECT 1 FROM @MemberIds)  
    BEGIN  
        SELECT TOP 1  
             @ID = ID  
            ,@Version_ID = Version_ID  
            ,@Entity_ID = Entity_ID  
            ,@TableName = TableName  
            ,@MemberType_ID = MemberType_ID  
        FROM @MemberIds  
        ORDER BY ID;  
  
        SET @SQL = N'  
        UPDATE p  
        SET  Member_Name        = Name  
            ,Member_MUID        = MUID  
            ,Member_Code        = Code  
        FROM  mdm.' + QUOTENAME(@TableName) + N' T  
        INNER JOIN #tblPrivileges p  
        ON      T.ID = p.Member_ID  
            AND T.Version_ID = @Version_ID  
            AND p.Entity_ID = @Entity_ID  
            AND p.MemberType_ID = @MemberType_ID';  
  
        EXEC sp_executesql @SQL, @ParamList,  
            @Version_ID, @Entity_ID, @MemberType_ID;  
  
        DELETE FROM @MemberIds WHERE ID = @ID;  
    END  
  
    --Update the privileges where id is 0 or less.  
    UPDATE #tblPrivileges  
    SET  Member_Name = N'ROOT'  
        ,Member_Code = N'ROOT'  
    WHERE Member_ID = 0 ;  
    UPDATE #tblPrivileges  
    SET  Member_Name = CASE  
            WHEN Member_ID = -1 THEN NULL -- Top-level unused node  
            ELSE CONVERT(NVARCHAR, ABS(Member_ID) - 10) END -- Level number for level-specific unused node.  
        ,Member_Code = N'MDMUNUSED'  
    WHERE Member_ID < 0;  
  
    SELECT * -- It is generally considered bad practice to do a "SELECT *" because of maintainability issues if the table schema changes. But in this case, it is a temp table that is defined inside of this sproc, so it is okay.  
    FROM #tblPrivileges  
    ORDER BY  
        Hierarchy_Name,  
        Member_Name,  
        Privilege_ID;  
  
    SET NOCOUNT OFF;  
END; --proc
go

