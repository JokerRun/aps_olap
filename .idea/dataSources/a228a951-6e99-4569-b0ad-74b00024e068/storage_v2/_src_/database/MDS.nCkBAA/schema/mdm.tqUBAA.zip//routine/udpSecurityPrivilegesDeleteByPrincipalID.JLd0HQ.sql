/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Deletes all permissions (functional, model, and member) explicitly assigned   
to the given principal.  
EXEC mdm.udpSecurityPrivilegesDeleteByPrincipalID 1,1  
*/  
CREATE PROCEDURE mdm.udpSecurityPrivilegesDeleteByPrincipalID  
(  
    @SystemUser_ID      INT, --Person performing action  
    @Principal_ID       INT,  
    @PrincipalType_ID   TINYINT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON  
  
    DECLARE   
         @FunctionalPrivilege_SuperUser TINYINT = 6  
        ,@PrincipalType_Group           INT = 2  
  
    -- Get the role ID(s) for the given principal.  
    DECLARE @RoleIds TABLE (Role_ID INT PRIMARY KEY);  
    INSERT INTO @RoleIds (Role_ID)  
    SELECT Role_ID  
    FROM mdm.tblSecurityAccessControl  
    WHERE   PrincipalType_ID = @PrincipalType_ID  
        AND Principal_ID = @Principal_ID  
  
    -- Get the role ID(s) that currently have super user functional privilege.  
    DECLARE @SuperUserRoles TABLE(Role_ID INT PRIMARY KEY);  
    INSERT INTO @SuperUserRoles(Role_ID)  
    SELECT DISTINCT Role_ID  
    FROM mdm.tblSecurityRoleAccessFunctional  
    WHERE FunctionalPrivilege_ID = @FunctionalPrivilege_SuperUser;  
  
    -- Determine if the principal is having a SuperUser functional privilege deleted.  
    IF EXISTS (  
        SELECT 1   
        FROM @SuperUserRoles ar  
        INNER JOIN @RoleIds r  
        ON ar.Role_ID = r.Role_ID)  
    BEGIN  
        -- Only SuperUsers can delete a SuperUser permission. Note: That the user performing the operation has at least Security functional privilege should have been verified before calling this sproc.  
        IF NOT EXISTS (  
            SELECT 1   
            FROM mdm.udfSecurityUserFunctionList(@SystemUser_ID)   
            WHERE Function_ID = @FunctionalPrivilege_SuperUser)   
        BEGIN  
            RAISERROR('MDSERR500067|The Super User function can only be granted or revoked by a user that already has that function.', 16, 1);  
            RETURN;  
        END;  
          
        -- Ensure that the principal is not the last super user.  
        IF EXISTS (SELECT 1 FROM @SuperUserRoles) -- This *should* always be true (unless the db has somehow been corrupted), but do the check anyway to prevent the possibility of a misleading error message.  
           AND NOT EXISTS (SELECT 1   
                           FROM @SuperUserRoles ar  
                           LEFT JOIN @RoleIds r  
                           ON ar.Role_ID = r.Role_ID  
                           WHERE r.Role_ID IS NULL)  
        BEGIN  
            IF @PrincipalType_ID = @PrincipalType_Group  
            BEGIN  
                RAISERROR('MDSERR500059|The group cannot be deleted. At least one user or group must have the Super User function.', 16, 1);  
            END ELSE  
            BEGIN  
                RAISERROR('MDSERR500056|The user cannot be deleted. At least one user or group must have the Super User function.', 16, 1);  
            END;  
            RETURN;  
        END;  
    END;  
  
    -- Delete functional permissions  
    DELETE ra  
    FROM mdm.tblSecurityRoleAccessFunctional ra  
    INNER JOIN @RoleIds r  
    ON ra.Role_ID = r.Role_ID  
  
    -- Delete model object permissions  
    DELETE ra  
    FROM mdm.tblSecurityRoleAccess ra  
    INNER JOIN @RoleIds r  
    ON ra.Role_ID = r.Role_ID  
  
    -- Delete member permissions  
    DELETE ra  
    FROM mdm.tblSecurityRoleAccessMember ra  
    INNER JOIN @RoleIds r  
    ON ra.Role_ID = r.Role_ID  
  
    SET NOCOUNT OFF  
END --proc
go

