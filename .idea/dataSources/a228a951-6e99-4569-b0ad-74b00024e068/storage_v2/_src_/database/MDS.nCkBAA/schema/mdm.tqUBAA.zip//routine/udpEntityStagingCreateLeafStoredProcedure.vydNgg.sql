/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE [mdm].[udpEntityStagingCreateLeafStoredProcedure]  
(  
    @Entity_ID    INT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE @SQL                        NVARCHAR(MAX) = N'',  
            @SQLNonDBAColumns           NVARCHAR(MAX) = N'',  
            @SQLDBAColumns              NVARCHAR(MAX) = N'',  
            @SQLNonDBA                  NVARCHAR(MAX) = N'',  
            @SQLDBA                     NVARCHAR(MAX) = N'',  
            @SQLDBAJoin                 NVARCHAR(MAX) = N'',  
            @SQLDBACheck                NVARCHAR(MAX) = N'',  
            @SQLSelfReferencingDBACheck_Initial     NVARCHAR(MAX) = N'',  
            @SQLSelfReferencingDBACheck_Propagate   NVARCHAR(MAX) = N'',  
            @SQLSelfReferencingDBAUpdate            NVARCHAR(MAX) = N'',  
            @EntityTable                SYSNAME = N'',  
            @EntityView                 SYSNAME = N'',  
            @CollectionTable            SYSNAME = N'',  
            @HierarchyParentTable       SYSNAME = N'',  
            @HierarchyRelationshipTable SYSNAME = N'',  
            @AttributeFilterCheckSQL    NVARCHAR(MAX) = N'',  
            @SQLMergeOptimisticNonDBA   NVARCHAR(MAX) = N'',  
            @SQLMergeOptimisticDBA      NVARCHAR(MAX) = N'',  
            @SQLMergeOverwriteNonDBA    NVARCHAR(MAX) = N'',  
            @SQLMergeOverwriteDBA       NVARCHAR(MAX) = N'',  
            @SQLInsertTemp              NVARCHAR(MAX) = N'',  
            @SQLAttributeTypeErrorCheck NVARCHAR(MAX) = N'',  
            @StagingBase                NVARCHAR(60),  
            @StagingLeafTable           SYSNAME,  
            @StagingLeafTableWithEscapedQuotes      SYSNAME,  -- Contains same value as @StagingLeafTable, but with the single quotes escaped out. This should be used when using the staging name inside of a dynamic SQL statement that is nested inside another dynamic SQL statement.  
            @IsCollectionEnabled        BIT,  
            @IsHierarchyEnabled         BIT,  
            @SQLAttributeValueSetMergeOverwrite     NVARCHAR(MAX) = N'',  
            @SQLAttributeValueSetMergeOptimistic    NVARCHAR(MAX) = N'',  
  
            --Entity member status  
            @MemberStatus_Active        TINYINT = 1,  
            @MemberStatus_Deactivated   TINYINT = 2,  
  
            -- staging data status constants  
            @StatusDefault              TINYINT = 0,  
            @StatusOK                   TINYINT = 1,  
            @StatusError                TINYINT = 2,  
            @StatusProcessing           TINYINT = 3,  
  
            -- This pseudo-constant is for use in string concatenation operations to prevent string truncation. When concatenating two or more strings,  
            -- if none of the strings is an NVARCHAR(MAX) or an NVARCHAR constant that is longer than 4,000 characters, then the resulting string  
            -- will be silently truncated to 4,000 characters. Concatenating with this empty NVARCHAR(MAX), is sufficient to prevent truncation.  
            -- See http://connect.microsoft.com/SQLServer/feedback/details/283368/nvarchar-max-concatenation-yields-silent-truncation.  
            @TruncationGuard            NVARCHAR(MAX) = N'',  
  
            -- attribute type constant  
            @AttributeType_File         INT = 4,  
  
            @Model_ID                   INT,  
            @TranOldColumn              NVARCHAR(MAX) = N'',  
            @TranNewColumn              NVARCHAR(MAX) = N'',  
            @TranDeletedColumn          NVARCHAR(MAX) = N'',  
            @TranBlankColumn            NVARCHAR(MAX) = N'',  
            @TranInsertedColumn         NVARCHAR(MAX) = N'',  
  
            --Transaction and annotation table names  
            @TransactionTableName       SYSNAME,  
            @OutputDeletionToTransactionTableQuery  NVARCHAR(MAX) = N'',  
            @ENHistoryOutputQuery       NVARCHAR(MAX) = N'',  
            @HRHistoryOutputQuery       NVARCHAR(MAX) = N'',  
  
            @MemberType_Leaf            TINYINT = 1,  
            @MemberType_Hierarchy       TINYINT = 4,  
              
            --Import Type Constants  
            @IT_MergeOptimistic         NVARCHAR(30) = N'0/*MergeOptimistic*/', -- specified null values are left unchanged.  
            @IT_Insert                  NVARCHAR(30) = N'1/*Insert*/',  
            @IT_MergeOverwrite          NVARCHAR(30) = N'2/*MergeOverwrite*/', -- all values are overwritten with specified values (including null)  
            @IT_Delete                  NVARCHAR(30) = N'3/*Delete*/',  
            @IT_Purge                   NVARCHAR(30) = N'4/*Purge*/',  
            @IT_DeleteSetNullToRef      NVARCHAR(30) = N'5/*DeleteSetNullToRef*/',  
            @IT_PurgeSetNullToRef       NVARCHAR(30) = N'6/*PurgeSetNullToRef*/',  
            @IT_Max                     NVARCHAR(30) = N'6/*max*/',  
  
  
            -- transaction log type constants  
            @TransactionLogType            TINYINT,  
            @TransactionLogType_Attribute  TINYINT = 1,  
            @TransactionLogType_Member     TINYINT = 2,  
            @TransactionLogType_None       TINYINT = 3;  
  
    --Initialize the variables  
  
    SELECT  @EntityTable = QUOTENAME(EntityTable),  
            @EntityView = mdm.udfViewNameGet(Model_ID, ID, @MemberType_Leaf, 0, 0),  
            @CollectionTable = QUOTENAME(CollectionTable),  
            @HierarchyParentTable = QUOTENAME(HierarchyParentTable),  
            @HierarchyRelationshipTable = QUOTENAME(HierarchyTable),  
  
            @Model_ID = Model_ID,  
            @StagingBase = StagingBase,  
            @StagingLeafTable = QUOTENAME(StagingLeafTable),  
            @IsCollectionEnabled = CASE WHEN CollectionTable IS NULL THEN 0 ELSE 1 END,  
            @IsHierarchyEnabled  = CASE WHEN HierarchyTable  IS NULL THEN 0 ELSE 1 END,  
            @TransactionLogType = TransactionLogType  
    FROM mdm.viw_SYSTEM_SCHEMA_ENTITY  
    WHERE ID = @Entity_ID;  
  
    -- Escape out the single quotes in the staging table name and put it into another var that will be used for referencing the table name from nested dynamic SQL.  
    SET @StagingLeafTableWithEscapedQuotes = QUOTENAME(@StagingLeafTable, N'''');  
    -- Remove the leading and trailing single quotes that the above QUOTENAME added (we only want the escaped quotes within the table name)  
    SET @StagingLeafTableWithEscapedQuotes = SUBSTRING(@StagingLeafTableWithEscapedQuotes, 2, LEN(@StagingLeafTableWithEscapedQuotes) - 2);  
  
    IF @TransactionLogType = @TransactionLogType_Member  
    BEGIN  
        SET @ENHistoryOutputQuery = mdm.udfGetHistoryOutputQuery(@Entity_ID, @MemberType_Leaf, N'@User_ID', N'@Now');  
        SET @HRHistoryOutputQuery = mdm.udfGetHistoryOutputQuery(@Entity_ID, @MemberType_Hierarchy, N'@User_ID', N'@Now');  
    END  
    ELSE  
    BEGIN  
        --Load the transaction and annotation table names  
        SET @TransactionTableName = mdm.udfGetTransactionTableName(@Model_ID);  
  
        IF @TransactionLogType = @TransactionLogType_Attribute  
        BEGIN  
            SET @OutputDeletionToTransactionTableQuery = CONCAT(N'  
        OUTPUT  
            CASE DELETED.Status_ID WHEN ', @MemberStatus_Active, N'/*Active*/ THEN DELETED.ID END, -- leave ID null for members that are already soft-deleted. They will not be logged.  
            DELETED.MUID,  
            DELETED.Code  
        INTO #TRANLOG  
        (  
            MemberID,  
            MemberMUID,  
            Code  
        )')  
        END  
    END  
  
    -- In case when the entity is a system entity (StagingBase is not specified)  
    -- simply don't create the staging SProc (don't raise an error).  
    IF COALESCE(@StagingBase, N'') = N''  
    BEGIN  
        RETURN;  
    END;  
  
    --If the leaf staging SProc exists drop it.  
    EXEC mdm.udpEntityStagingDeleteStoredProcedures @Entity_ID, 1/*Leaf proc*/  
  
    DECLARE @AttributeTable TABLE  
    (  
        ViewColumn              NVARCHAR(100) COLLATE DATABASE_DEFAULT,  
        TableColumn             NVARCHAR(128) COLLATE DATABASE_DEFAULT NOT NULL,  
        AttributeType_ID        TINYINT NOT NULL,  
        DataType_ID             TINYINT NOT NULL,  
        DomainEntity_ID         INT NULL,  
        DomainTable             NVARCHAR(128) COLLATE DATABASE_DEFAULT NULL,  
        FilterParentAttributeName               NVARCHAR(100) COLLATE DATABASE_DEFAULT NULL,  
        FilterHierarchyEntityViewName           SYSNAME NULL,  
        FilterHierarchyParentAttributeName      NVARCHAR(100) COLLATE DATABASE_DEFAULT NULL,  
        FilterHierarchyM2MChildAttributeName    NVARCHAR(100) COLLATE DATABASE_DEFAULT NULL,  
        SortOrder               INT  
    );  
  
    INSERT INTO @AttributeTable  
    SELECT   
         a.Name AS ViewColumn  
        ,a.TableColumn  
        ,a.AttributeType_ID  
        ,a.DataType_ID  
        ,a.DomainEntity_ID  
        ,e.EntityTable AS DomainTable  
        ,parentAttribute.Name AS FilterParentAttributeName  
        ,mdm.udfViewNameGet(@Model_ID, levelEntity.ID, @MemberType_Leaf, 0, 0) AS FilterHierarchyEntityViewName  
        ,levelParentAttribute.Name AS FilterHierarchyParentAttributeName  
        ,m2mChildAttribute.Name AS FilterHierarchyM2MChildAttributeName  
        ,a.SortOrder  
    FROM mdm.tblAttribute a   
    LEFT JOIN mdm.tblEntity e   
    ON a.DomainEntity_ID = e.ID  
  
    LEFT JOIN mdm.tblAttribute parentAttribute  
    ON a.FilterParentAttribute_ID = parentAttribute.ID  
  
    LEFT JOIN mdm.tblDerivedHierarchyDetail filterLevel  
    ON a.FilterHierarchyDetail_ID = filterLevel.ID  
    LEFT JOIN mdm.tblAttribute levelParentAttribute  
    ON filterLevel.Foreign_ID = levelParentAttribute.ID  
    LEFT JOIN mdm.tblEntity levelEntity  
    ON levelParentAttribute.Entity_ID = levelEntity.ID  
    LEFT JOIN mdm.tblAttribute m2mChildAttribute  
    ON filterLevel.ManyToManyChildAttribute_ID = m2mChildAttribute.ID  
  
    WHERE   a.Entity_ID = @Entity_ID  
        AND a.MemberType_ID = 1--Leaf  
        AND a.IsSystem = 0   
        AND a.IsReadOnly = 0  
  
    DECLARE  
        @CurrentViewColumn          NVARCHAR(120) = N'', --specifically made to be less than 128 for truncation reasons  
        @CurrentTableColumn         SYSNAME = N'',  
        @CurrentTableColumnNoQuote  SYSNAME = N'',  
        @CurrentAttributeType_ID    TINYINT,  
        @CurrentDataType_ID         TINYINT,  
        @CurrentDomainEntity_ID     INT,  
        @CurrentDomainTable         SYSNAME = N'',  
        @CurrentFilterParentAttributeName       NVARCHAR(100),  
        @CurrentFilterHierarchyEntityViewName   SYSNAME,  
        @CurrentFilterHierarchyParentAttributeName NVARCHAR(100),  
        @CurrentFilterHierarchyM2MChildAttributeName NVARCHAR(100)  
  
  
    WHILE EXISTS(SELECT 1 FROM @AttributeTable)   
    BEGIN  
        SELECT TOP 1  
            @CurrentViewColumn = QUOTENAME(ViewColumn),  
            @CurrentTableColumn = QUOTENAME(TableColumn),  
            @CurrentTableColumnNoQuote = TableColumn,  
            @CurrentAttributeType_ID = AttributeType_ID,  
            @CurrentDataType_ID =  DataType_ID,  
            @CurrentDomainEntity_ID = DomainEntity_ID,  
            @CurrentDomainTable = DomainTable,  
            @CurrentFilterParentAttributeName = QUOTENAME(FilterParentAttributeName),  
            @CurrentFilterHierarchyEntityViewName = FilterHierarchyEntityViewName,  
            @CurrentFilterHierarchyParentAttributeName = QUOTENAME(FilterHierarchyParentAttributeName),  
            @CurrentFilterHierarchyM2MChildAttributeName = QUOTENAME(FilterHierarchyM2MChildAttributeName)  
        FROM @AttributeTable  
        ORDER BY SortOrder;  
  
        SET @TranOldColumn += CONCAT(N'  
        ,', @CurrentTableColumnNoQuote, N' NVARCHAR(MAX)  COLLATE DATABASE_DEFAULT NULL ');  
        SET @TranDeletedColumn += CONCAT(N', CONVERT(NVARCHAR(MAX), deleted.', @CurrentTableColumn, N') ');  
        SET @TranBlankColumn += N', NULL ';  
        SET @TranNewColumn += CONCAT(N'  
        ,New_', @CurrentTableColumnNoQuote, N' NVARCHAR(MAX) COLLATE DATABASE_DEFAULT NULL ');  
        SET @TranInsertedColumn += CONCAT(N', CONVERT(NVARCHAR(MAX), inserted.', @CurrentTableColumn, N') ');  
  
        IF @CurrentDomainEntity_ID IS NULL   
        BEGIN -- Non DBA  
            SET @SQLNonDBAColumns += N'  
                ,' + @CurrentTableColumn + N' --' + @CurrentViewColumn;  
  
            -- When the data type is text and the value is @NULLText (~NULL~) set NULL.  
            -- When the data type is number and the value is @NULLNumber (-98765432101234567890) set NULL.  
            -- When the data type is DateTime and the value is @NULLDateTime (5555-11-22T12:34:56) set NULL.  
  
            SET @SQLAttributeValueSetMergeOverwrite = CASE  
                                    WHEN @CurrentDataType_ID IN (1 /*Text*/, 6 /*Link*/) THEN  
                                        N'NULLIF(stgl.' + @CurrentViewColumn + N',@NULLText)'  
                                    WHEN @CurrentDataType_ID = 2 THEN -- Data type is Number  
                                        N'NULLIF(stgl.' + @CurrentViewColumn + N',@NULLNumber)'  
                                    WHEN @CurrentDataType_ID = 3 THEN -- Data type is DateTime  
                                        N'NULLIF(stgl.' + @CurrentViewColumn + N',@NULLDateTime)'  
                                    ELSE  
                                        N'stgl.' + @CurrentViewColumn  
                                    END;  
  
            IF LEN(COALESCE(@SQLNonDBA, N'')) > 0  
            BEGIN -- Not at the beginning.  
                SET @SQLNonDBA += N',  
';  
            END;  
            SET @SQLNonDBA += @SQLAttributeValueSetMergeOverwrite;  
  
            -- Even in case of merge optimistic set NULL when the value is @NULLText, @NULLNumber, or @NULLDateTime depending on the data type.  
            SET @SQLAttributeValueSetMergeOptimistic = CASE  
                                    WHEN @CurrentDataType_ID IN (1 /*Text*/, 6 /*Link*/) THEN  
                                        N'CASE WHEN stgl.' + @CurrentViewColumn + N' = @NULLText THEN NULL  
                                               WHEN stgl.' + @CurrentViewColumn + N' IS NULL THEN en.'  + @CurrentTableColumn + N'  
                                               ELSE stgl.' + @CurrentViewColumn + N'  
                                          END '  
                                    WHEN @CurrentDataType_ID = 2 THEN -- Data type is Number  
                                        N'CASE WHEN stgl.' + @CurrentViewColumn + N' = @NULLNumber THEN NULL  
                                               WHEN stgl.' + @CurrentViewColumn + N' IS NULL THEN en.'  + @CurrentTableColumn + N'  
                                               ELSE stgl.' + @CurrentViewColumn + N'  
                                          END '  
                                    WHEN @CurrentDataType_ID = 3 THEN -- Data type is DateTime  
                                        N'CASE WHEN stgl.' + @CurrentViewColumn + N' = @NULLDateTime THEN NULL  
                                               WHEN stgl.' + @CurrentViewColumn + N' IS NULL THEN en.'  + @CurrentTableColumn + N'  
                                               ELSE stgl.' + @CurrentViewColumn + N'  
                                          END '  
                                    ELSE  
                                        N'stgl.' + @CurrentViewColumn  
                                    END;  
  
            SET @SQLMergeOptimisticNonDBA += N',' + @CurrentTableColumn + N' = ' + @SQLAttributeValueSetMergeOptimistic;  
            SET @SQLMergeOverwriteNonDBA += N',' + @CurrentTableColumn + N' = ' + @SQLAttributeValueSetMergeOverwrite;  
        END  
        ELSE BEGIN -- DBA  
  
            SET @SQLDBAColumns += N'  
                ,' + @CurrentTableColumn + N' --' + @CurrentViewColumn;  
  
            IF NULLIF(@SQLDBA, N'') IS NOT NULL  
            BEGIN -- Not at the beginning.  
                SET @SQLDBA += N',  
'  
            END;  
            SET @SQLDBA += N'CASE WHEN stgl.' + @CurrentViewColumn + N' = @NULLText THEN NULL ELSE ' + @CurrentViewColumn + N'.ID END';  
  
            -- Even in case of merge optimistic set NULL when the value is @NULLText.  
            SET @SQLMergeOptimisticDBA += N',' + @CurrentTableColumn + N' = CASE WHEN stgl.' + @CurrentViewColumn + N' = @NULLText THEN NULL  
            ELSE ISNULL(' + @CurrentViewColumn + N'.ID, en.' + @CurrentTableColumn + N') END  
            ';  
  
            SET @SQLMergeOverwriteDBA += N',' + @CurrentTableColumn + N' = CASE WHEN stgl.' + @CurrentViewColumn + N' = @NULLText THEN NULL  
            ELSE ' + @CurrentViewColumn + N'.ID END  
            ';  
  
            -- In case when there are multiple DBAs using the same entity table use @CurrentViewColumn as  
            -- an alias to each entity table to avoid SQL error.  
            SET @SQLDBAJoin += CONCAT(N'  
LEFT JOIN mdm.', @CurrentDomainTable, N' ', @CurrentViewColumn, N'  
ON      stgl.', @CurrentViewColumn, N' = ', @CurrentViewColumn, N'.Code  
    AND ', @CurrentViewColumn, N'.Version_ID = @Version_ID  
    AND ', @CurrentViewColumn, N'.Status_ID = ', @MemberStatus_Active/*DO NOT replace this hardcoded value with a var. It would be bad for perf*/, N' -- Active')  
            IF @CurrentDomainEntity_ID = @Entity_ID  
            BEGIN  
                -- Update the SQL fragment used to find members whose self-referencing DBA(s) reference invalid members.  
                SET @SQLSelfReferencingDBACheck_Initial += @TruncationGuard +  
                    CASE WHEN LEN(@SQLSelfReferencingDBACheck_Initial) > 0 THEN N'  
UNION -- not UNION ALL because deduplication is needed  
'                       ELSE N'' END + CONCAT(N'  
SELECT stgl.ID, stgl.Code, N', QUOTENAME(@CurrentViewColumn, N''''), N', stgl.', @CurrentViewColumn, N'  
FROM [stg].', @StagingLeafTable, N' stgl  
WHERE EXISTS(  
SELECT 1 FROM mdm.', @EntityTable, N' dm -- First see if the member already exists  
WHERE stgl.', @CurrentViewColumn, N' = dm.Code  
AND dm.Status_ID = ', @MemberStatus_Active/*DO NOT replace this hardcoded value with a var. It would be bad for perf*/, N' -- Active  
AND dm.Version_ID = @Version_ID)  
AND EXISTS(  
SELECT 1 FROM stg.', @StagingLeafTable, N' dm2 -- Self-referencing DBA. See if the domain member is being created in the same batch.  
WHERE stgl.', @CurrentViewColumn, N' = dm2.Code  
AND stgl.Batch_ID = dm2.Batch_ID  
AND dm2.ErrorCode = 0  
AND stgl.ImportType NOT IN (', @IT_Delete, N', ', @IT_Purge, N', ', @IT_DeleteSetNullToRef, N', ', @IT_PurgeSetNullToRef, N')  
AND LEN(ISNULL(NULLIF(stgl.', @CurrentViewColumn, N', @NULLText), N'''')) > 0  
AND stgl.Batch_ID = @Batch_ID AND stgl.ImportStatus_ID = ', @StatusDefault, N' -- Default  
AND dm2.Code IS NULL)');  
  
                -- Update the SQL fragment used to propagate errors down to descendants.  
                SET @SQLSelfReferencingDBACheck_Propagate += @TruncationGuard +  
                    CASE WHEN LEN(@SQLSelfReferencingDBACheck_Propagate) > 0 THEN N'  
    UNION -- not UNION ALL because deduplication is needed  
'                       ELSE N'' END + CONCAT(N'  
    SELECT  
         child.ID  
        ,child.Code  
        , N', QUOTENAME(@CurrentViewColumn, N''''), N'  
        ,child.', @CurrentViewColumn, N'  
    FROM @PreviousIterationOrphans parent  
    INNER JOIN stg.', @StagingLeafTable, N' child  
    ON parent.Code = child.', @CurrentViewColumn, N'  
    AND child.Batch_ID = @Batch_ID  
    AND child.ErrorCode = 0  
    LEFT JOIN @Orphans o  
    ON child.ID = o.ID  
    WHERE o.ID IS NULL -- exclude known orphans (protects against redundant lookups that would cause an infinite loop)');  
  
                -- Update the SQL fragment used for updating the self-referencing DBA value after new members have been added to the table.  
                SET @SQLSelfReferencingDBAUpdate += CONCAT(N'  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Update the self-referencing DBA value after new members have been added to the table.'')  
    UPDATE en  
    SET ', @CurrentTableColumn, N' = parent.MemberID  
    FROM mdm.', @EntityTable, N' en  
    INNER JOIN stg.', @StagingLeafTable, N' stgl  
    ON      en.Code = stgl.Code  
        AND en.Status_ID = ', @MemberStatus_Active/*DO NOT replace this hardcoded value with a var. It would be bad for perf*/, N' -- Active  
        AND en.Version_ID = @Version_ID  
    INNER JOIN #TRANLOG parent  
    ON stgl.', @CurrentViewColumn, N' = parent.Code  
    WHERE   stgl.ImportStatus_ID = ', @StatusProcessing, N' -- Processing  
        AND stgl.Batch_ID = @Batch_ID;  
');  
            END ELSE -- IF self-referencing DBA  
            BEGIN  
                -- The DBA is not self-referencing, so validate by ensuring that the referenced domain member exists and is active.  
                SET @SQLDBACheck += CONCAT(@TruncationGuard, N'  
IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' (', REPLACE(@CurrentViewColumn, N'''', N''''''),') Check for Error 210003- The attribute value references a member that does not exist or is inactive'')  
-- Error 210003 The attribute value references a member that does not exist or is inactive. Binary Location 2^2:  
UPDATE stgl  
SET ErrorCode = ErrorCode | 4  
    OUTPUT inserted.Batch_ID, inserted.Code, N', QUOTENAME(@CurrentViewColumn, N''''), N', inserted.', @CurrentViewColumn, N', 210003  
    INTO [mdm].[tblStgErrorDetail] (Batch_ID, Code, AttributeName, AttributeValue, UniqueErrorCode)  
FROM [stg].', @StagingLeafTable, N' stgl  
LEFT JOIN mdm.', @CurrentDomainTable, N' dm  
ON      stgl.', @CurrentViewColumn, N' = dm.Code  
    AND dm.Status_ID = ', @MemberStatus_Active/*DO NOT replace this hardcoded value with a var. It would be bad for perf*/, N' -- Active  
    AND dm.Version_ID = @Version_ID  
WHERE   stgl.ImportType NOT IN (', @IT_Delete, N', ', @IT_Purge, N', ', @IT_DeleteSetNullToRef, N', ', @IT_PurgeSetNullToRef, N')  
    AND LEN(ISNULL(NULLIF(stgl.', @CurrentViewColumn, N',  @NULLText), N'''')) > 0  
    AND stgl.Batch_ID = @Batch_ID   
    AND stgl.ImportStatus_ID = ', @StatusDefault, N' -- Default  
    AND dm.Code IS NULL  
',  
                -- The attribute has a filter. Check for incompatible values.  
                CASE WHEN @CurrentFilterParentAttributeName IS NOT NULL THEN CONCAT(N'  
IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' (', REPLACE(@CurrentViewColumn, N'''', N''''''),', Insert and MergeOverwrite) Check for 310055- The attribute value is not compatible with the attribute filter'')  
-- Error 310055 The attribute value is not compatible with the attribute filter. Binary Location 2^20:  
-- Insert and MergeOverwrite is the simple case because the staging row is complete (what you see is what you get)  
UPDATE stgl  
SET ErrorCode = ErrorCode | 1048576  
    OUTPUT inserted.Batch_ID, inserted.Code, N', QUOTENAME(@CurrentViewColumn, N''''), N', inserted.', @CurrentViewColumn, N', 310055  
    INTO mdm.tblStgErrorDetail (Batch_ID, Code, AttributeName, AttributeValue, UniqueErrorCode)  
FROM stg.', @StagingLeafTable, N' stgl  
LEFT JOIN mdm.', @CurrentFilterHierarchyEntityViewName, N' filter -- Note: the %_CHILDATTRIBUTES view excludes inactive members  
ON      @Version_ID = filter.Version_ID  
    AND stgl.', @CurrentViewColumn, N' = filter.', COALESCE(@CurrentFilterHierarchyM2MChildAttributeName, N'Code'), N'  
    AND ISNULL(NULLIF(stgl.', @CurrentFilterParentAttributeName, N', @NULLText),N'''') = ISNULL(filter.', @CurrentFilterHierarchyParentAttributeName, N', N'''')  
WHERE   stgl.ImportType IN (', @IT_Insert, N', ', @IT_MergeOverwrite, N')  
    AND stgl.Batch_ID = @Batch_ID   
    AND stgl.ImportStatus_ID = ', @StatusDefault, N' -- Default  
    AND NULLIF(NULLIF(stgl.', @CurrentViewColumn, N',  @NULLText), N'''') IS NOT NULL -- null child values are always valid  
    AND filter.ID IS NULL -- could not find a match',   
CASE WHEN @CurrentFilterHierarchyM2MChildAttributeName IS NOT NULL THEN CONCAT(N'  
    AND (stgl.', @CurrentFilterParentAttributeName, N' IS NOT NULL -- M2M level: not finding a filter row match is okay if the parent is null  
         OR EXISTS( SELECT 1                                       -- and the child is not under another parent  
                    FROM mdm.', @CurrentFilterHierarchyEntityViewName, N' filter  
                    WHERE   @Version_ID = filter.Version_ID    
                        AND stgl.', @CurrentViewColumn, N' = filter.', COALESCE(@CurrentFilterHierarchyM2MChildAttributeName, N'Code'), N'  
                        AND filter.', @CurrentFilterHierarchyParentAttributeName, N' IS NOT NULL))')   
    END, N'  
  
IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' (', REPLACE(@CurrentViewColumn, N'''', N''''''),', MergeOptimistic) Check for 310055- The attribute value is not compatible with the attribute filter'')  
-- Error 310055 The attribute value is not compatible with an attribute filter. Binary Location 2^20:  
-- For MergeOptimistic, the staging row is combined with the already-existing row in the EN table to get the complete picture, because the staging row may not contain values for attributes that are not changing.   
UPDATE stgl  
SET ErrorCode = ErrorCode | 1048576  
    OUTPUT inserted.Batch_ID, inserted.Code, N', QUOTENAME(@CurrentViewColumn, N''''), N', inserted.', @CurrentViewColumn, N', 310055  
    INTO mdm.tblStgErrorDetail (Batch_ID, Code, AttributeName, AttributeValue, UniqueErrorCode)  
FROM stg.', @StagingLeafTable, N' stgl  
LEFT JOIN mdm.', @EntityView , N' viw -- join to get current values  
ON      @Version_ID = viw.Version_ID  
    AND stgl.Code = viw.Code  
LEFT JOIN mdm.', @CurrentFilterHierarchyEntityViewName, N' filter -- Note: the %_CHILDATTRIBUTES view excludes inactive members  
ON      @Version_ID = filter.Version_ID  
    AND ISNULL(stgl.', @CurrentViewColumn, N', viw.', @CurrentViewColumn, N') = filter.', COALESCE(@CurrentFilterHierarchyM2MChildAttributeName, N'Code'), N'  
    AND ISNULL(NULLIF(ISNULL(stgl.', @CurrentFilterParentAttributeName, N',viw.', @CurrentFilterParentAttributeName, N'), @NULLText),'''') = ISNULL(filter.', @CurrentFilterHierarchyParentAttributeName, N',N'''')  
WHERE   stgl.ImportType = ', @IT_MergeOptimistic, N'  
    AND stgl.Batch_ID = @Batch_ID   
    AND stgl.ImportStatus_ID = ', @StatusDefault, N' -- Default  
    AND NULLIF(ISNULL(stgl.', @CurrentViewColumn, N', viw.', @CurrentViewColumn, N'), @NULLText) IS NOT NULL -- null child values are always valid  
    AND filter.ID IS NULL -- could not find a match',   
CASE WHEN @CurrentFilterHierarchyM2MChildAttributeName IS NOT NULL THEN CONCAT(N'  
    AND (NULLIF(ISNULL(stgl.', @CurrentFilterParentAttributeName, N', viw.', @CurrentViewColumn, N'), @NULLText) IS NOT NULL -- M2M level: not finding a filter row match is okay if the parent is null  
         OR EXISTS( SELECT 1                                                -- and the child is not under another parent  
                    FROM mdm.', @CurrentFilterHierarchyEntityViewName, N' filter  
                    WHERE   @Version_ID = filter.Version_ID    
                        AND ISNULL(stgl.', @CurrentViewColumn, N', viw.', @CurrentViewColumn, N') = filter.', COALESCE(@CurrentFilterHierarchyM2MChildAttributeName, N'Code'), N'  
                        AND filter.', @CurrentFilterHierarchyParentAttributeName, N' IS NOT NULL))  
      
    ') END,  
N'  
')              END)  
            END -- IF non-self-referencing DBA  
  
        END; -- IF DBA  
  
        IF @CurrentAttributeType_ID = @AttributeType_File  
        BEGIN  
            SET @SQLAttributeTypeErrorCheck += CONCAT(@TruncationGuard, N'  
IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Check for Error 200066- Binary Location 2^18: The file attribute cannot be saved'')  
--Error 200066 Binary Location 2^18: The file attribute cannot be saved  
--If the user tries to set any value in a file attribute when the Import type is  
--Merge Optimistic, Merge Overwrite or Insert, set the error code.  
UPDATE [stg].', @StagingLeafTable, N'  
SET ErrorCode = ErrorCode | 262144  
WHERE ImportStatus_ID = ', @StatusDefault, N' -- Default   
AND Batch_ID = @Batch_ID  
AND ImportType IN (', @IT_MergeOptimistic, N', ', @IT_MergeOverwrite, N', ', @IT_Insert, N')  
AND ', @CurrentViewColumn, N' IS NOT NULL  
');  
        END; -- IF  
        DELETE FROM @AttributeTable WHERE QUOTENAME(ViewColumn) = @CurrentViewColumn;  
  
    END; --WHILE  
  
    SET @SQL = CONCAT(@TruncationGuard, CONCAT(@TruncationGuard, -- using nested CONCAT since CONCAT can't have more than 254 args  
N'CREATE PROCEDURE [stg].', QUOTENAME(N'udp_' + @StagingBase + N'_Leaf'), N'  
@VersionName NVARCHAR(50), @LogFlag INT=0, @BatchTag NVARCHAR(50)=N'''', @Batch_ID INT=NULL, @UserName NVARCHAR(100) = NULL, @User_ID INT = 0, @Debug BIT = 0  
WITH EXECUTE AS ''mds_schema_user''  
AS  
BEGIN  
  
IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' [stg].', REPLACE(QUOTENAME(N'udp_' + @StagingBase + N'_Leaf'), N'''', N''''''),'  start'')  
  
SET NOCOUNT ON;  
DECLARE @Model_ID           INT,  
@Version_ID                 INT,  
@VersionStatus_ID           INT,  
@VersionStatus_Committed    INT = 3,  
@Entity_ID                  INT,  
@MemberCount                INT = 0,  
@ErrorCount                 INT = 0,  
@NewBatch_ID                INT = 0,  
@GetNewBatch_ID             INT = 0,  
@CurrentHierarchy_ID        INT,  
@Now                        DATETIME2,  
  
-- member type constant  
@LeafMemberTypeID           INT = 1,  
  
-- attribute type constants  
@FreeformTypeId             INT = 1,  
@DomainTypeId               INT = 2,  
@SystemTypeId               INT = 3,  
  
-- transaction type constants  
@StatusChangedId            INT = 2,  
@AttributeChangedId         INT = 3,  
  
-- error return code constants  
@UserIDError                INT = 1,  
@VersionNameError           INT = 3,  
@UserPermissionError        INT = 4,  
@VersionStatusError         INT = 5,  
@NoRecordToProcessError     INT = 6,  
@BatchIDAndBatchTagSpecifiedError   INT = 7,  
@BatchStatusError           INT = 8,  
@OtherRuntimeError          INT = 9,  
  
-- batch status constants  
@QueuedToRun                INT = 1,  
@NotRunning                 INT = 2,  
@Running                    INT = 3,  
@QueueToClear               INT = 4,  
@Cleared                    INT = 5,  
@AllExceptCleared           INT = 6,  
@Completed                  INT = 7,  
  
-- GetNewBatch_ID constants  
@BatchIDFound               INT = 0,  
@BatchIDNotFound            INT = 1,  
@BatchIDForBatchTagNotFound INT = 2,  
  
--Special attribute values that are used as aliases for NULL, to allow Merge Optimistic mode to change values to NULL..  
--When changing these values, also change them in the GetPostfixItemSql() method of \Core\BusinessLogic\BusinessRules\SqlGeneration\SqlGenerator.cs  
@NULLNumber                 DECIMAL(38,0) = -98765432101234567890,  
@NULLText                   NVARCHAR(10) = N''~NULL~'',  
@NULLDateTime               NVARCHAR(30) = N''5555-11-22T12:34:56'',  
  
--Validation status  
@NewAwaitingValidation      INT = 0,  
@AwaitingRevalidation       INT = 4,  
@AwaitingDependentMemberRevalidation  INT = 5,  
  
@DependentValidationStatus      INT,  
@DependentEntityTable           SYSNAME,  
@DependentAttributeColumnName   SYSNAME,  
  
--Code generation  
@AllowCodeGen               BIT = 0,  
@StartCode                  BIGINT,  
@EndCode                    BIGINT,  
@NumberOfCodes              INT,  
  
--Change Tracking Group  
@ChangedAttributeID         INT,  
@ChangedAttributeName       NVARCHAR(100),  
@ChagendAttributeColumnName NVARCHAR(50),  
@ChangeTrackingGroup        INT,  
@SQLCTG                     NVARCHAR(MAX),  
@ChangedAttributeType_ID    TINYINT,  
@ChangedAttributeDomainEntityTableName SYSNAME,  
@AttributeType_Domain       TINYINT = 2,  
  
--Transaction Log Types  
@MemberCreateTransaction        INT = 1,  
@MemberStatusSetTransaction     INT = 2,  
@MemberAttributeSetTransaction  INT = 3,  
@HierarchyParentSetTransaction  INT = 4,  
  
--XACT_STATE() constants  
@UncommittableTransaction   INT = -1;  
  
DECLARE @MandatoryHierarchy TABLE  
(  
    Hierarchy_ID INT  
);  
  
SET @Model_ID = ', @Model_ID, N'  
SET @Entity_ID = ', @Entity_ID, N'  
  
-- @UserName overwrites @User_ID  
IF @UserName IS NOT NULL  
BEGIN  
    SET @User_ID = mdm.udfUserIDGetByUserName(@UserName)  
    IF @User_ID IS NULL  
    BEGIN  
        RAISERROR(''MDSERR500041|The UserName is unknown.'', 16, 1);  
        RETURN @UserIDError;  
    END  
END  
  
-- Check for invalid Version Name.  
IF @VersionName IS NULL RETURN @VersionNameError;  
  
-- Set @AllowCodeGen (1: Code generation is allowed for the entity. 0: Code generation is not allowed for the entity)  
EXEC @AllowCodeGen = mdm.udpIsCodeGenEnabled @Entity_ID;  
  
IF LEN(@BatchTag) > 0 AND @Batch_ID IS NOT NULL BEGIN  
    RAISERROR(''MDSERR310043|The Batch Tag and the Batch ID cannot be specified at the same time.'', 16, 1);  
    RETURN @BatchIDAndBatchTagSpecifiedError;  
END; --IF  
  
SELECT @Version_ID = ID, @VersionStatus_ID = Status_ID FROM mdm.tblModelVersion WHERE Model_ID = @Model_ID AND [Name] = @VersionName;  
  
IF @Version_ID IS NULL BEGIN  
    RAISERROR(''MDSERR100036|The version name is not valid.'', 16, 1);  
    RETURN @VersionNameError;  
END; --IF  
  
--Ensure that Version is not committed  
IF (@VersionStatus_ID = @VersionStatus_Committed) BEGIN  
    RAISERROR(''MDSERR310040|Data cannot be loaded into a committed version.'', 16, 1);  
    RETURN @VersionStatusError;  
END;  
  
-- Verify the entity is not a sync target.  
IF EXISTS(  
    SELECT 1 FROM mdm.tblSyncRelationship   
    WHERE   TargetEntity_ID = @Entity_ID  
        AND TargetVersion_ID = @Version_ID)  
BEGIN  
    RAISERROR(''MDSERR200220|The entity member(s) cannot be saved. The entity version is the target of a sync relationship.'', 16, 1);  
    RETURN;  
END  
  
  
IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Check if there is any record to process.'')  
  
--Check if there is any record to process.  
IF LEN(@BatchTag) > 0 BEGIN  
    SELECT @MemberCount = COUNT(ID) FROM [stg].', @StagingLeafTable, N'  
        WHERE BatchTag = @BatchTag AND ImportStatus_ID = ', @StatusDefault, N' -- Default  
    IF @MemberCount = 0 BEGIN  
        RETURN @NoRecordToProcessError;  
    END; -- IF  
END; -- IF  
ELSE IF @Batch_ID IS NOT NULL BEGIN  
    SELECT @MemberCount = COUNT(ID) FROM [stg].', @StagingLeafTable, N'  
        WHERE Batch_ID = @Batch_ID AND ImportStatus_ID = ', @StatusDefault, N' -- Default  
    IF @MemberCount = 0 BEGIN  
        RETURN @NoRecordToProcessError;  
    END; -- IF  
END; -- IF  
  
IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' If neither @BatchTag nor @Batch_ID is specified assume that a blank @BatchTag is specified.'')  
-- If neither @BatchTag nor @Batch_ID is specified assume that a blank @BatchTag is specified.  
  
IF @Batch_ID IS NULL AND LEN(@BatchTag) = 0 BEGIN  
    SELECT @MemberCount = COUNT(ID) FROM [stg].', @StagingLeafTable, N'  
        WHERE (BatchTag IS NULL OR BatchTag = N'''') AND ImportStatus_ID = ', @StatusDefault, N' -- Default  
    IF @MemberCount = 0 BEGIN  
        RETURN @NoRecordToProcessError;  
    END; -- IF  
END; -- IF  
  
IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Check if there is any record with an invalid status.'')  
--Check if there is any record with an invalid status.  
IF LEN(@BatchTag) > 0 BEGIN  
    -- Determine if there is a running batch with the given batch tag.  
    DECLARE @IsBatchTagRunning BIT =  
        CASE WHEN EXISTS (SELECT 1  
                          FROM mdm.tblStgBatch  
                          WHERE  
                                LTRIM(RTRIM(BatchTag)) = @BatchTag  
                            AND Status_ID = @Running)  
        THEN 1 ELSE 0 END;  
  
    IF      @IsBatchTagRunning = 1  
        AND EXISTS (SELECT 1  
               FROM [stg].', @StagingLeafTable, N'  
               WHERE  
                     BatchTag = @BatchTag  
                 AND ImportStatus_ID = ', @StatusDefault, N' -- Default  
                 )  
    BEGIN  
        RAISERROR(''MDSERR310029|The status of the specified batch is not valid.'', 16, 1);  
        RETURN @BatchStatusError;  
    END; -- IF  
END; -- IF  
  
IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' IF @Batch_ID IS NOT NULL (check batch status).'')  
IF @Batch_ID IS NOT NULL BEGIN  
    DECLARE @BatchStatus_ID INT = (SELECT Status_ID FROM mdm.tblStgBatch WHERE ID = @Batch_ID);  
    IF @BatchStatus_ID IN (@Running, @QueueToClear, @Cleared)  
        AND EXISTS (  
            SELECT ID  
            FROM [stg].', @StagingLeafTable, N'  
            WHERE  
                    Batch_ID = @Batch_ID  
                AND ImportStatus_ID = ', @StatusDefault, N' -- Default  
                )  
    BEGIN  
        RAISERROR(''MDSERR310029|The status of the specified batch is not valid.'', 16, 1);  
        RETURN @BatchStatusError;  
    END; -- IF  
END; -- IF  
  
IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' IF @Batch_ID IS NOT NULL.'')  
IF @Batch_ID IS NOT NULL  BEGIN  
    IF NOT EXISTS (SELECT ID FROM mdm.tblStgBatch WHERE ID = @Batch_ID AND Status_ID NOT IN (@Running, @QueueToClear, @Cleared)  
                   AND Version_ID = @Version_ID AND Entity_ID = @Entity_ID AND MemberType_ID = 1) BEGIN  
        SET @GetNewBatch_ID = @BatchIDNotFound  
    END; --IF  
END; --IF  
ELSE BEGIN  
    -- Check if udpEntityStagingFlagForProcessing already assigned a new batch ID (in this case the status is QueuedToRun).  
    SELECT TOP 1 @Batch_ID = ID FROM mdm.tblStgBatch  
        WHERE BatchTag = @BatchTag AND Status_ID = @QueuedToRun  
        AND Version_ID = @Version_ID AND Entity_ID = @Entity_ID AND MemberType_ID = @LeafMemberTypeID ORDER BY ID DESC  
  
    IF @Batch_ID IS NULL BEGIN  
        SET @GetNewBatch_ID = @BatchIDForBatchTagNotFound  
    END; --IF  
    ELSE BEGIN  
        -- Set the member count  
        UPDATE mdm.tblStgBatch  
        SET TotalMemberCount = @MemberCount  
        WHERE BatchTag = @BatchTag AND Status_ID = @QueuedToRun  
            AND Version_ID = @Version_ID AND Entity_ID = @Entity_ID AND MemberType_ID = @LeafMemberTypeID  
    END; --IF  
END; --IF  
  
IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' IF @GetNewBatch_ID IN (@BatchIDNotFound, @BatchIDForBatchTagNotFound)'')  
IF @GetNewBatch_ID IN (@BatchIDNotFound, @BatchIDForBatchTagNotFound) BEGIN  
-- Create a new batch ID.  
    INSERT INTO mdm.tblStgBatch  
    (MUID  
    ,Version_ID  
    ,Status_ID  
    ,BatchTag  
    ,Entity_ID  
    ,MemberType_ID  
    ,TotalMemberCount  
    ,ErrorMemberCount  
    ,TotalMemberAttributeCount  
    ,ErrorMemberAttributeCount  
    ,TotalMemberRelationshipCount  
    ,ErrorMemberRelationshipCount  
    ,LastRunStartDTM  
    ,LastRunStartUserID  
    ,LastRunEndDTM  
    ,LastRunEndUserID  
    ,LastClearedDTM  
    ,LastClearedUserID  
    ,EnterDTM  
    ,EnterUserID)  
    SELECT  
        NEWID(),  
        @Version_ID,  
        @Running,  
        @BatchTag,  
        @Entity_ID,  
        1,  
        @MemberCount,  
        NULL,  
        NULL,  
        NULL,  
        NULL,  
        NULL,  
        GETUTCDATE(),  
        @User_ID,  
        NULL,  
        NULL,  
        NULL,  
        NULL,  
        GETUTCDATE(),  
        @User_ID  
  
    SELECT @NewBatch_ID = SCOPE_IDENTITY();  
  
    -- Update batch ID.  
    IF @GetNewBatch_ID = @BatchIDNotFound BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' @GetNewBatch_ID = @BatchIDNotFound'')  
        UPDATE [stg].', @StagingLeafTable, N'  
        SET Batch_ID = @NewBatch_ID  
        WHERE Batch_ID = @Batch_ID AND ImportStatus_ID = ', @StatusDefault, N' -- Default  
    END; --IF  
    ELSE BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' @GetNewBatch_ID <> @BatchIDNotFound'')  
        UPDATE [stg].', @StagingLeafTable, N'  
        SET Batch_ID = @NewBatch_ID  
        WHERE BatchTag = @BatchTag AND ImportStatus_ID = ', @StatusDefault, N' -- Default  
    END; --IF  
  
    SET @Batch_ID = @NewBatch_ID;  
END --IF  
ELSE BEGIN  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' The user specified a valid batch ID.'')  
    -- The user specified a valid batch ID.  
    -- Set the status of the batch as Running and set the total member count.  
    UPDATE mdm.tblStgBatch  
    SET Status_ID = @Running,  
        TotalMemberCount = @MemberCount,  
        LastRunStartDTM = GETUTCDATE(),  
        LastRunStartUserID = @User_ID  
    WHERE ID = @Batch_ID  
END; --IF  
  
IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Populate @UsedImportTypes'')  
DECLARE @UsedImportTypes TABLE  
(  
    ImportType TINYINT PRIMARY KEY  
)  
INSERT INTO @UsedImportTypes  
SELECT DISTINCT ImportType  
FROM [stg].', @StagingLeafTable, N'  
WHERE ImportStatus_ID = ', @StatusDefault, N' -- Default  
    AND Batch_ID = @Batch_ID;  
  
IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Check for Error 210001- Multiple Records for the same member record'')  
--Error Check all staged members  
--Error 210001 Binary Location 2^1: Multiple Records for the same member record  
UPDATE stgl  
SET ErrorCode = stgl.ErrorCode | 2  
FROM [stg].', @StagingLeafTable, N' stgl  
INNER JOIN [stg].', @StagingLeafTable, N' stgl2  
ON      stgl.Code = stgl2.Code  
    AND stgl.ID <> stgl2.ID  
    AND stgl.Batch_ID = stgl2.Batch_ID  
WHERE stgl.ImportStatus_ID = ', @StatusDefault, N' -- Default  
    AND stgl.Batch_ID = @Batch_ID;  
      
-- skip DBA and auto-gen Code check for Delete/Purge  
IF EXISTS(SELECT 1 FROM @UsedImportTypes WHERE ImportType IN (', @IT_Insert,N', ', @IT_MergeOverwrite, N', ', @IT_MergeOptimistic, N'))  
BEGIN  
  
',  
  
  
@SQLDBACheck, N'  
  
    IF (@AllowCodeGen = 0)  
    BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Check for Error 210035- Code generation is not allowed for the entity, Code is Mandatory'')  
        --Error 210035 Binary Location 2^5: Code generation is not allowed for the entity, Code is Mandatory  
        UPDATE [stg].', @StagingLeafTable, N'  
        SET ErrorCode = ErrorCode | 32  
        WHERE ISNULL(Code, N'''') = N'''' AND ImportStatus_ID = ', @StatusDefault, N' -- Default  
            AND Batch_ID = @Batch_ID;  
    END  
    ELSE  
    BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Check for Error 210035- Code generation is allowed for the entity and the Code is an empty string (NULL is allowed)'')  
        --Error 210035 Binary Location 2^5: Code generation is allowed for the entity and the Code is an empty string (NULL is allowed).  
        UPDATE [stg].', @StagingLeafTable, N'  
        SET ErrorCode = ErrorCode | 32  
        WHERE Code = N'''' AND ImportStatus_ID = ', @StatusDefault, N' -- Default  
            AND Batch_ID = @Batch_ID;  
  
    END; --IF  
END -- IF Insert/Merge  
  
  
IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Check for Error 210041- ROOT is not a valid MemberCode'')  
--Error 210041 Binary Location 2^6: ROOT is not a valid MemberCode  
UPDATE [stg].', @StagingLeafTable, N'  
SET ErrorCode = ErrorCode | 64  
WHERE UPPER(Code) = N''ROOT'' AND ImportStatus_ID = ', @StatusDefault, N' -- Default  
    AND Batch_ID = @Batch_ID;  
  
IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Check for Error 210042- MDMUnused is not a valid MemberCode'')  
--Error 210042 Binary Location 2^7: MDMUnused is not a valid MemberCode  
UPDATE [stg].', @StagingLeafTable, N'  
SET ErrorCode = ErrorCode | 128  
WHERE UPPER(Code) = N''MDMUNUSED'' AND ImportStatus_ID = ', @StatusDefault, N' -- Default  
    AND Batch_ID = @Batch_ID;',  
  @SQLAttributeTypeErrorCheck, N'  
  
IF EXISTS(SELECT 1 FROM @UsedImportTypes WHERE ImportType IN (', @IT_Delete, N', ', @IT_Purge, N', ', @IT_DeleteSetNullToRef, N', ', @IT_PurgeSetNullToRef, N'))  
BEGIN  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Populate a temp table of MemberCodes to be removed (soft-deleted or purged).'')  
    -- Populate a temp table of MemberCodes to be removed (soft-deleted or purged).  
    CREATE TABLE #MembersToRemove  
    (  
         Member_ID  INT  
        ,Staging_ID INT NOT NULL  
        ,MemberCode NVARCHAR(250) COLLATE DATABASE_DEFAULT  
        ,IsPurge    BIT NOT NULL -- 0 Delete, 1 Purge  
        ,SetToNull  BIT NOT NULL  
        ,IsActive   BIT NOT NULL  
    );  
    CREATE UNIQUE CLUSTERED INDEX #ix_MembersToRemove_IsPurge_Member_ID_IsActive ON #MembersToRemove(IsPurge, Member_ID, IsActive);  
    CREATE UNIQUE INDEX #ix_MembersToRemove_SetToNull_Member_ID ON #MembersToRemove(SetToNull, Member_ID);  
  
    INSERT INTO #MembersToRemove(Member_ID, Staging_ID, MemberCode, IsPurge, SetToNull, IsActive)  
    SELECT en.ID  
        , stgl.ID  
        , stgl.Code  
        , CASE WHEN stgl.ImportType IN (', @IT_Purge, N', ', @IT_PurgeSetNullToRef, N') THEN 1 ELSE 0 END -- IsPurge  
        , CASE WHEN stgl.ImportType IN (', @IT_DeleteSetNullToRef, N', ', @IT_PurgeSetNullToRef, N') THEN 1 ELSE 0 END -- SetToNull  
        , CASE WHEN en.Status_ID = ', @MemberStatus_Active, N'/*Active*/ THEN 1 ELSE 0 END -- IsActive  
    FROM [stg].', @StagingLeafTable, N' stgl  
    LEFT JOIN mdm.', @EntityTable, N' en  
    ON      en.Version_ID = @Version_ID  
        AND stgl.Code = en.Code  
    WHERE   stgl.ImportType IN (', @IT_Delete, N', ', @IT_Purge, N', ', @IT_DeleteSetNullToRef, N', ', @IT_PurgeSetNullToRef, N')  
        AND stgl.ImportStatus_ID = ', @StatusDefault, N'-- Default  
        AND stgl.Batch_ID = @Batch_ID;  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Populate @BadMemberCodes TABLE.'')  
    DECLARE @BadMemberCodes TABLE  
    (  
        Staging_ID INT PRIMARY KEY  
    )  
    DELETE #MembersToRemove  
    OUTPUT deleted.Staging_ID  
    INTO @BadMemberCodes  
    WHERE   Member_ID IS NULL  
        OR (    IsPurge = 0  -- Cannot delete an already deleted member  
            AND IsActive = 0)  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Check for Error 300002- The member code is not valid'')  
    --Error 300002 Binary Location 2^8: The member code is not valid  
    UPDATE stgl  
    SET ErrorCode = ErrorCode | 256  
    FROM [stg].', @StagingLeafTable, N' stgl  
    INNER JOIN @BadMemberCodes bmc  
    ON stgl.ID = bmc.Staging_ID  
END -- IF Delete or Purge  
  
IF EXISTS(SELECT 1 FROM @UsedImportTypes WHERE ImportType = ', @IT_Insert, N')  
BEGIN  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Check for Error 300003 (Insert)- The Member code already exists'')  
    --Error 300003 Binary Location 2^9: The Member code already exists  
    --Verify uniqueness of Code against the entity table  
    UPDATE sc  
    SET ErrorCode = ErrorCode | 512  
    FROM [stg].', @StagingLeafTable, N' sc  
    INNER JOIN mdm.', @EntityTable, N' AS tSource  
    ON sc.Code = tSource.Code  
    WHERE   tSource.Status_ID = ', @MemberStatus_Active/*DO NOT replace this hardcoded value with a var. It would be bad for perf*/, N' -- Active  
        AND tSource.Version_ID = @Version_ID  
        AND sc.ImportType = ', @IT_Insert, N'  
        AND sc.ImportStatus_ID = ', @StatusDefault, N' -- Default  
        AND sc.Batch_ID = @Batch_ID;  
END -- IF Insert  
  
IF EXISTS(SELECT 1 FROM @UsedImportTypes WHERE ImportType IN (', @IT_MergeOptimistic, N', ', @IT_MergeOverwrite, N'))  
BEGIN  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Check for Error 300003 (MergeOptimistic, MergeOverwrite)- The Member code already exists'')  
    --Error 300003 Binary Location 2^9: The Member code already exists  
    --Verify uniqueness of the new code against the entity table  
    UPDATE sc  
    SET ErrorCode = ErrorCode | 512  
    FROM [stg].', @StagingLeafTable, N' sc  
    INNER JOIN mdm.', @EntityTable, N' AS tSource  
    ON sc.NewCode = tSource.Code  
    WHERE   tSource.Status_ID = ', @MemberStatus_Active/*DO NOT replace this hardcoded value with a var. It would be bad for perf*/, N' -- Active  
        AND tSource.Version_ID = @Version_ID  
        AND sc.ImportType IN (', @IT_MergeOptimistic, N', ', @IT_MergeOverwrite, N')  
        AND sc.ImportStatus_ID = ', @StatusDefault, N' -- Default  
        AND sc.Batch_ID = @Batch_ID;  
END -- IF Merge  
  
IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Check for Error 210058- Invalid ImportType'')  
--Error 210058 Binary Location 2^10: Invalid ImportType  
UPDATE [stg].', @StagingLeafTable, N'  
SET ErrorCode = ErrorCode | 1024  
WHERE ImportType > ', @IT_Max, N' AND ImportStatus_ID = ', @StatusDefault, N' -- Default  
    AND Batch_ID = @Batch_ID;'  
  
) -- end nested CONCAT  
,  
  
CASE WHEN LEN(COALESCE(@HierarchyParentTable, N'')) > 0 THEN CONCAT(N'  
IF EXISTS(SELECT 1 FROM @UsedImportTypes WHERE ImportType IN (', @IT_Insert, N', ', @IT_MergeOptimistic, N', ', @IT_MergeOverwrite, N'))  
BEGIN  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Check for Error 300003 (HP table, Code)- The Member code already exists'')  
    --Error 300003 Binary Location 2^9: The Member code already exists  
    --Verify uniqueness of code against the parent table  
    UPDATE sc  
    SET ErrorCode = ErrorCode | 512  
    FROM [stg].', @StagingLeafTable, N' sc  
    INNER JOIN mdm.', @HierarchyParentTable, N' AS tSource  
    ON sc.Code = tSource.Code  
    WHERE   tSource.Status_ID = ', @MemberStatus_Active/*DO NOT replace this hardcoded value with a var. It would be bad for perf*/, N' -- Active  
        AND tSource.Version_ID = @Version_ID  
        AND sc.ImportType IN (', @IT_Insert, N', ', @IT_MergeOptimistic, N', ', @IT_MergeOverwrite, N')  
        AND sc.ImportStatus_ID = ', @StatusDefault, N' -- Default  
        AND sc.Batch_ID = @Batch_ID;  
END -- IF Insert or Merge  
  
IF EXISTS(SELECT 1 FROM @UsedImportTypes WHERE ImportType IN (', @IT_MergeOptimistic, N', ', @IT_MergeOverwrite, N'))  
BEGIN  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Check for Error 300003 (HP table, NewCode)- The Member code already exists'')  
    --Error 300003 Binary Location 2^9: The Member code already exists  
    --Verify uniqueness of the new code against the parent table  
    UPDATE sc  
    SET ErrorCode = ErrorCode | 512  
    FROM [stg].', @StagingLeafTable, N' sc  
    INNER JOIN mdm.', @HierarchyParentTable, N' AS tSource  
    ON sc.NewCode = tSource.Code  
    WHERE   tSource.Status_ID = ', @MemberStatus_Active/*DO NOT replace this hardcoded value with a var. It would be bad for perf*/, N' -- Active  
        AND tSource.Version_ID = @Version_ID  
        AND sc.ImportType IN (', @IT_MergeOptimistic, N', ', @IT_MergeOverwrite, N')  
        AND sc.ImportStatus_ID = ', @StatusDefault, N' -- Default  
        AND sc.Batch_ID = @Batch_ID;  
END -- IF Merge  
') END,  
  
CASE WHEN @IsCollectionEnabled = 1 THEN CONCAT(N'  
IF EXISTS(SELECT 1 FROM @UsedImportTypes WHERE ImportType IN (', @IT_Insert, N', ', @IT_MergeOptimistic, N', ', @IT_MergeOverwrite, N'))  
BEGIN  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Check for Error 300003 (CN table, Code)- The Member code already exists'')  
    --Error 300003 Binary Location 2^9: The Member code already exists  
    --Verify uniqueness of code against the collection table  
    UPDATE sc  
    SET ErrorCode = ErrorCode | 512  
    FROM [stg].', @StagingLeafTable, N' sc  
    INNER JOIN mdm.' + @CollectionTable + N' AS tSource  
    ON sc.Code = tSource.Code  
    WHERE   tSource.Status_ID = ', @MemberStatus_Active/*DO NOT replace this hardcoded value with a var. It would be bad for perf*/, N' -- Active  
        AND tSource.Version_ID = @Version_ID  
        AND sc.ImportType IN (', @IT_Insert, N', ', @IT_MergeOptimistic, N', ', @IT_MergeOverwrite, N')  
        AND sc.ImportStatus_ID = ', @StatusDefault, N' -- Default  
        AND sc.Batch_ID = @Batch_ID;  
  
END -- IF Insert or Merge  
  
IF EXISTS(SELECT 1 FROM @UsedImportTypes WHERE ImportType IN (', @IT_MergeOptimistic, N', ', @IT_MergeOverwrite, N'))  
BEGIN  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Check for Error 300003 (CN table, NewCode)- The Member code already exists'')  
    --Error 300003 Binary Location 2^9: The Member code already exists  
    --Verify uniqueness of the new code against the collection table  
    UPDATE sc  
    SET ErrorCode = ErrorCode | 512  
    FROM [stg].', @StagingLeafTable, N' sc  
    INNER JOIN mdm.' + @CollectionTable + N' AS tSource  
    ON sc.NewCode = tSource.Code  
    WHERE   tSource.Status_ID = ', @MemberStatus_Active/*DO NOT replace this hardcoded value with a var. It would be bad for perf*/, N' -- Active  
        AND tSource.Version_ID = @Version_ID  
        AND sc.ImportType IN (', @IT_MergeOptimistic, N', ', @IT_MergeOverwrite, N')  
        AND sc.ImportStatus_ID = ', @StatusDefault, N' -- Default  
        AND sc.Batch_ID = @Batch_ID;  
END -- IF Merge  
') END,  
  
-- Add errors for invalid self-referencing DBA values  
CASE WHEN LEN(@SQLSelfReferencingDBACheck_Initial) > 0 THEN CONCAT(N'  
  
IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Get a list of members with whose self-referencing DBA(s) reference invalid parent members.'')  
-- Get a list of members with whose self-referencing DBA(s) reference invalid parent members.  
DECLARE @Orphans TABLE  
(  
     ID INT PRIMARY KEY  
    ,ColumnName SYSNAME  
    ,ColumnValue NVARCHAR(250) COLLATE DATABASE_DEFAULT  
);  
DECLARE @PreviousIterationOrphans TABLE  
(  
    Code NVARCHAR(250) COLLATE DATABASE_DEFAULT PRIMARY KEY  
);  
DECLARE @NewOrphans TABLE  
(  
     ID INT PRIMARY KEY  
    ,Code NVARCHAR(250) COLLATE DATABASE_DEFAULT  
    ,ColumnName SYSNAME  
    ,ColumnValue NVARCHAR(250) COLLATE DATABASE_DEFAULT  
);  
INSERT INTO @NewOrphans(ID, Code, ColumnName, ColumnValue)  
', @SQLSelfReferencingDBACheck_Initial, N'  
  
-- Propagate the errors down to the orphans'' descendants  
WHILE EXISTS (SELECT 1 FROM @NewOrphans)  
BEGIN  
    INSERT INTO @Orphans(ID, ColumnName, ColumnValue)  
    SELECT ID, ColumnName, ColumnValue  
    FROM @NewOrphans;  
  
    DELETE FROM @PreviousIterationOrphans;  
    INSERT INTO @PreviousIterationOrphans(Code)  
    SELECT Code  
    FROM @NewOrphans;  
  
    DELETE FROM @NewOrphans;  
    INSERT INTO @NewOrphans  
', @SQLSelfReferencingDBACheck_Propagate, N'  
END;  
  
IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Check for Error 210003- The attribute value references a member that does not exist or is inactive.'')  
-- Error 210003 The attribute value references a member that does not exist or is inactive. Binary Location 2^2:  
MERGE stg.', @StagingLeafTable, N' stgl  
USING  
(  
    SELECT  
        ID  
       ,ColumnName  
       ,ColumnValue  
    FROM @Orphans  
) o  
ON o.ID = stgl.ID  
WHEN MATCHED THEN  
UPDATE  
    SET ErrorCode = COALESCE(ErrorCode, 0) | 4  
        OUTPUT inserted.Batch_ID, inserted.Code, o.ColumnName, o.ColumnValue, 210003  
        INTO mdm.tblStgErrorDetail (Batch_ID, Code, AttributeName, AttributeValue, UniqueErrorCode)  
;  
') END,   
  
    --Get the Attributes for the Entity (Leaf Attributes).  
CONCAT(@TruncationGuard, N'  
  
IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Set ImportStatus on all records with at least one error'')  
--Set ImportStatus on all records with at least one error  
UPDATE [stg].', @StagingLeafTable, N'  
SET ImportStatus_ID = ', @StatusError, N' -- Error  
WHERE ErrorCode > 0 AND ImportStatus_ID = ', @StatusDefault, N' -- Default  
    AND Batch_ID = @Batch_ID;  
  
IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Start transaction'')  
--Start transaction, being careful to check if we are nested  
DECLARE @TranCounter INT;  
SET @TranCounter = @@TRANCOUNT;  
IF @TranCounter > 0 SAVE TRANSACTION TX;  
ELSE BEGIN TRANSACTION;  
  
BEGIN TRY  
IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Get all the non-system attributes plus name and code attribute info for current entity'')  
-- get all the non-system attributes plus name and code attribute info for current entity  
-- We need track entity attribute change for 3 scenarios  
-- 0x1. The attribute has a tracking group  
-- 0x10. The attribute is self referencing DBA  
-- 0x100. The entity is a DBA, The attribute is used in BR changeValue by dependent entity  
DECLARE @TrackingAttributeInfo TABLE  
(  
    AttributeID         INT NOT NULL PRIMARY KEY,  
    AttributeName       NVARCHAR(100) COLLATE DATABASE_DEFAULT NOT NULL,  
    AttributeColumnName SYSNAME,  
    AttributeTypeID     TINYINT,  
    ChangeTrackingGroupID    INT,  
    TrackingType        TINYINT NOT NULL,  
    DomainEntityID      INT,  
    DomainEntityTableName SYSNAME NULL  
);  
  
INSERT INTO @TrackingAttributeInfo (  
    AttributeID,  
    AttributeName,  
    AttributeColumnName,  
    AttributeTypeID,  
    ChangeTrackingGroupID,  
    TrackingType,  
    DomainEntityID,  
    DomainEntityTableName  
)  
SELECT DISTINCT  
    attr.ID,  
    attr.Name,  
    attr.TableColumn,  
    attr.AttributeType_ID,  
    attr.ChangeTrackingGroup,  
    CASE WHEN attr.ChangeTrackingGroup <> 0 THEN 1 ELSE 0 END, --1. The attribute has a tracking group  
    attr.DomainEntity_ID,  
    ent.EntityTable  
FROM mdm.tblAttribute attr  
LEFT JOIN mdm.tblEntity ent ON ent.ID = attr.DomainEntity_ID  
WHERE  
    attr.Entity_ID = @Entity_ID AND  
    attr.MemberType_ID = @LeafMemberTypeID AND  
    (attr.IsSystem = 0 OR attr.IsCode = 1 OR attr.IsName = 1); -- Exclude system attributes other than Code and Name.  
  
--2. The attribute is self referencing DBA  
UPDATE a  
SET TrackingType = TrackingType | 2  
FROM @TrackingAttributeInfo a  
INNER JOIN mdm.tblDerivedHierarchyDetail d  
    ON a.DomainEntityID = @Entity_ID  
       AND a.AttributeID = d.Foreign_ID  
       AND d.ForeignParent_ID = @Entity_ID  
  
--3. The entity is a DBA, The attribute is used in BR changeValue by dependent entity  
UPDATE a  
SET TrackingType = TrackingType | 4  
FROM @TrackingAttributeInfo a  
INNER JOIN mdm.viw_SYSTEM_BUSINESSRULES_ATTRIBUTE_INHERITANCE_HIERARCHY i  
    ON i.ParentAttributeName = a.AttributeName AND i.ParentEntityID = @Entity_ID  
  
DELETE @TrackingAttributeInfo  
WHERE TrackingType = 0  
  
IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Store the changed attribute name and Member_ID for the changed row.'')  
--store the changed attribute name and Member_ID for the changed row  
--This must be temp tables vs. table variables because we need to reference it in dynamic SQL.  
CREATE TABLE #MemberAttributeWorkingSet (  
    MemberID                INT NOT NULL,  
    AttributeID             INT  NOT NULL  
);  
  
CREATE INDEX #ix_MemberAttributeWorkingSet_MemberID_AttributeID ON #MemberAttributeWorkingSet(MemberID, AttributeID);  
  
IF @AllowCodeGen = 1  
BEGIN  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Gather up the valid user provided codes.'')  
    --Gather up the valid user provided codes.  
    DECLARE @CodesToProcess mdm.MemberCodes;  
  
    INSERT @CodesToProcess (MemberCode)  
    SELECT Code FROM [stg].', @StagingLeafTable, N'  
    WHERE ErrorCode = 0 AND ImportStatus_ID = ', @StatusDefault, N' -- Default  
        AND Batch_ID = @Batch_ID AND Code IS NOT NULL;  
  
    INSERT @CodesToProcess (MemberCode)  
    SELECT NewCode FROM [stg].', @StagingLeafTable, N'  
    WHERE ErrorCode = 0 AND ImportStatus_ID = ', @StatusDefault, N' -- Default  
        AND Batch_ID = @Batch_ID AND NewCode IS NOT NULL;  
  
    --Process the user-provided codes to update the code gen info table with the largest one.  
    EXEC mdm.udpProcessCodes @Entity_ID, @CodesToProcess;  
  
    --If code generation is allowed populate new codes into the staging table.  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Generate the codes.'')  
    --Generate the codes.  
    SELECT @NumberOfCodes = COUNT(*) FROM [stg].', @StagingLeafTable, N'  
    WHERE ImportStatus_ID = ', @StatusDefault, N' -- Default  
        AND Batch_ID = @Batch_ID AND Code IS NULL;  
  
    EXEC mdm.udpGenerateCodeRange @Entity_ID = @Entity_ID, @NumberOfCodesToGenerate = @NumberOfCodes, @CodeRangeStart = @StartCode OUTPUT, @CodeRangeEnd = @EndCode OUTPUT;  
  
    DECLARE @CodeCounter BIGINT = @StartCode - 1;  
  
    --Set generated codes into the staging table.  
    UPDATE [stg].', @StagingLeafTable, N'  
    SET @CodeCounter += 1,  
        Code = CONVERT(NVARCHAR(25), @CodeCounter)  
    WHERE ImportStatus_ID = ', @StatusDefault, N' -- Default  
        AND Batch_ID = @Batch_ID AND Code IS NULL;  
  
END; -- IF  
  
IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Table for transaction log.'')  
--Table for transaction log  
CREATE TABLE #TRANLOG  
(  
     MemberID    INT  
    ,MemberMUID  UNIQUEIDENTIFIER  
    ,Code       NVARCHAR(250) COLLATE DATABASE_DEFAULT  
    ,New_Code    NVARCHAR(250) COLLATE DATABASE_DEFAULT  
    ,Name       NVARCHAR(250) COLLATE DATABASE_DEFAULT NULL  
    ,New_Name    NVARCHAR(250) COLLATE DATABASE_DEFAULT NULL  
', @TranOldColumn, @TranNewColumn, N'  
);', CASE WHEN LEN(@SQLSelfReferencingDBACheck_Initial) > 0 THEN N'  
-- The entity has at least one self-referencing DBA, so add an index on the Code column to speed up looking up new member DBA values.  
CREATE INDEX #ix_TRANLOG_Code ON #TRANLOG(Code)  
' END, N'  
  
IF EXISTS(SELECT 1 FROM @UsedImportTypes WHERE ImportType IN (', @IT_MergeOptimistic, N', ', @IT_Insert, N', ', @IT_MergeOverwrite, N'))  
BEGIN  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Set ImportStatus_ID to Processing for new members.'')  
    --Process Insert all new error free records into MDS internal table.  
    UPDATE stgl  
    SET ImportStatus_ID = ', @StatusProcessing, N' -- Processing  
    FROM [stg].', @StagingLeafTable, N' stgl  
    LEFT JOIN  mdm.', @EntityTable, N' en  
    ON      stgl.Code = en.Code  
        AND en.Status_ID = ', @MemberStatus_Active/*DO NOT replace this hardcoded value with a var. It would be bad for perf*/, N' -- Active  
        AND en.Version_ID = @Version_ID  
    WHERE stgl.Batch_ID = @Batch_ID  
        AND stgl.ImportType IN (', @IT_MergeOptimistic, N', ', @IT_Insert, N', ', @IT_MergeOverwrite, N')  
        AND stgl.ImportStatus_ID = ', @StatusDefault, N' -- Default  
        AND en.Code IS NULL;  
  
    IF @LogFlag != 1  
    BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Insert into EN table (@LogFlag != 1).'')  
  
        INSERT INTO mdm.', @EntityTable, N'  
        (  
            Version_ID,  
            Status_ID,  
            ValidationStatus_ID,  
            Name,  
            Code,  
            EnterDTM,  
            EnterUserID,  
            EnterVersionID,  
            LastChgDTM,  
            LastChgUserID,  
            LastChgVersionID', @SQLNonDBAColumns, @SQLDBAColumns, N'  
        ) ', CASE WHEN LEN(@SQLSelfReferencingDBACheck_Initial) > 0 THEN N'  
            -- Need to capture new member IDs for updating self-referencing DBAs  
            OUTPUT inserted.ID, inserted.Code  
                INTO #TRANLOG(MemberID, Code)  
        ' END, N'  
        SELECT  
            @Version_ID,  
            1,  
            @NewAwaitingValidation,  
            stgl.Name,  
            stgl.Code,  
            GETUTCDATE(),  
            @User_ID,  
            @Version_ID,  
            GETUTCDATE(),  
            @User_ID,  
            @Version_ID',  
                CASE  
                    WHEN LEN(COALESCE(@SQLNonDBA, N'') + COALESCE(@SQLDBA, N'')) = 0 THEN N''  
                    WHEN LEN(COALESCE(@SQLNonDBA, N'')) > 0 AND LEN(COALESCE(@SQLDBA, N'')) > 0 THEN CONCAT(N',', @SQLNonDBA, N',',@SQLDBA)  
                    ELSE CONCAT(N',',@SQLNonDBA, @SQLDBA)  
                END, N'  
        FROM [stg].', @StagingLeafTable, N' stgl ', @SQLDBAJoin, N'  
        WHERE stgl.ImportStatus_ID = ', @StatusProcessing, N' -- Processing   
            AND stgl.Batch_ID = @Batch_ID;  
        ', CASE WHEN LEN(@SQLSelfReferencingDBACheck_Initial) > 0 THEN CONCAT(N'  
        -- Update the values of self-referencing DBA(s) with the IDs of newly created members  
        ', @SQLSelfReferencingDBAUpdate) END, N'  
        END  
    ELSE  
    BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Insert into EN table (@LogFlag = 1).'')  
        INSERT INTO mdm.', @EntityTable, N'  
        (  
            Version_ID,  
            Status_ID,  
            ValidationStatus_ID,  
            Name,  
            Code,  
            EnterDTM,  
            EnterUserID,  
            EnterVersionID,  
            LastChgDTM,  
            LastChgUserID,  
            LastChgVersionID', @SQLNonDBAColumns, @SQLDBAColumns, N'  
        )  
        ', CASE @TransactionLogType  
                WHEN @TransactionLogType_Attribute THEN CONCAT(N'  
        OUTPUT inserted.ID, inserted.MUID, inserted.Code, inserted.Code, inserted.Name, inserted.Name ', @TranBlankColumn, @TranInsertedColumn, N'  
            INTO #TRANLOG')  
                ELSE N'  
        -- Need to capture new member IDs for updating self-referencing DBAs  
        OUTPUT inserted.ID, inserted.Code  
            INTO #TRANLOG(MemberID, Code)'  
            END, N'  
        SELECT  
            @Version_ID,  
            1,  
            @NewAwaitingValidation,  
            stgl.Name,  
            stgl.Code,  
            GETUTCDATE(),  
            @User_ID,  
            @Version_ID,  
            GETUTCDATE(),  
            @User_ID,  
            @Version_ID',  
                CASE  
                    WHEN LEN(COALESCE(@SQLNonDBA, N'') + COALESCE(@SQLDBA, N'')) = 0 THEN N''  
                    WHEN LEN(COALESCE(@SQLNonDBA, N'')) > 0 AND LEN(COALESCE(@SQLDBA, N'')) > 0 THEN CONCAT(N',',@SQLNonDBA, N',', @SQLDBA)  
                    ELSE CONCAT(N',', @SQLNonDBA, @SQLDBA)  
                END, N'  
        FROM [stg].', @StagingLeafTable, N' stgl ', @SQLDBAJoin, N'  
        WHERE stgl.ImportStatus_ID = ', @StatusProcessing, N' -- Processing   
            AND stgl.Batch_ID = @Batch_ID;  
    ', CASE WHEN LEN(@SQLSelfReferencingDBACheck_Initial) > 0 THEN CONCAT(N'  
        -- Update the values of self-referencing DBA(s) with the IDs of newly created members  
    ', @SQLSelfReferencingDBAUpdate) END, N'  
    END; --IF  
'  
)-- end nested CONCAT  
,  
  
CASE WHEN @IsHierarchyEnabled = 1 THEN CONCAT(@TruncationGuard, N'  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Add HR records for each mandatory hierarchy.'')  
    -- After the insertion add HR records for each mandatory hierarchies  
  
    INSERT INTO @MandatoryHierarchy  
    SELECT DISTINCT ID AS Hierarchy_ID FROM mdm.tblHierarchy WHERE Entity_ID = ', @Entity_ID, N' AND IsMandatory = 1  
  
    WHILE EXISTS(SELECT 1 FROM @MandatoryHierarchy) BEGIN  
  
        SELECT TOP 1  
            @CurrentHierarchy_ID = Hierarchy_ID  
        FROM @MandatoryHierarchy;  
  
        -- Add the member to the root of the hierarchy.  
        INSERT INTO mdm.', @HierarchyRelationshipTable, N'  
        (  
            [Version_ID]  
            ,[Status_ID]  
            ,[ValidationStatus_ID]  
            ,[Hierarchy_ID]  
            ,[Parent_HP_ID]  
            ,[ChildType_ID]  
            ,[Child_EN_ID]  
            ,[Child_HP_ID]  
            ,[SortOrder]  
            ,[LevelNumber]  
            ,[EnterDTM]  
            ,[EnterUserID]  
            ,[EnterVersionID]  
            ,[LastChgDTM]  
            ,[LastChgUserID]  
            ,[LastChgVersionID]  
        )  
        SELECT  
        @Version_ID,  
        1,  
        @NewAwaitingValidation,  
        @CurrentHierarchy_ID,  
        NULL,  
        1,  
        en.ID,  
        NULL,  
        0,  
        0,  
        GETUTCDATE(),  
        @User_ID,  
        @Version_ID,  
        GETUTCDATE(),  
        @User_ID,  
        @Version_ID  
        FROM [stg].', @StagingLeafTable, N' stgl  
        INNER JOIN mdm.', @EntityTable, N' en  
        ON      stgl.Code = en.Code  
            AND en.Status_ID = ', @MemberStatus_Active/*DO NOT replace this hardcoded value with a var. It would be bad for perf*/, N' -- Active  
            AND en.Version_ID = @Version_ID  
        WHERE stgl.ImportStatus_ID = ', @StatusProcessing, N' -- Processing   
            AND stgl.Batch_ID = @Batch_ID;  
',  
    CASE WHEN @TransactionLogType = @TransactionLogType_Attribute THEN CONCAT(@TruncationGuard, N'  
        IF @LogFlag = 1  
        BEGIN  
            -- Record addition of the members to the ROOT node of the hierarchy.  
            -- OldCode and NewCode are set to ROOT (this is the same as the existing transaction log).  
            INSERT INTO [mdm].', QUOTENAME(@TransactionTableName), N'  
            (  
                Version_ID,  
                TransactionType_ID,  
                OriginalTransaction_ID,  
                Hierarchy_ID,  
                Entity_ID,  
                Member_ID,  
                Member_MUID,  
                MemberType_ID,  
                MemberCode,  
                OldValue,  
                OldCode,  
                NewValue,  
                NewCode,  
                Batch_ID,  
                EnterDTM,  
                EnterUserID,  
                LastChgDTM,  
                LastChgUserID  
            )  
            SELECT  
                @Version_ID, --Version_ID  
                @HierarchyParentSetTransaction, --TransactionType_ID  
                0, --OriginalTransaction_ID  
                @CurrentHierarchy_ID, --Hierarchy_ID  
                @Entity_ID, --Entity_ID  
                en.ID, --Member_ID  
                en.MUID, --Member_MUID  
                @LeafMemberTypeID, --MemberType_ID  
                stgl.Code,  
                N''0'', --OldValue  
                N''ROOT'', --OldCode  
                N''0'', --NewValue  
                N''ROOT'', --NewCode  
                @Batch_ID,  
                GETUTCDATE(),  
                @User_ID,  
                GETUTCDATE(),  
                @User_ID  
            FROM mdm.', @EntityTable, N' en  
            INNER JOIN [stg].', @StagingLeafTable, N' stgl  
            ON      en.Code = stgl.Code  
                AND en.Status_ID = ', @MemberStatus_Active/*DO NOT replace this hardcoded value with a var. It would be bad for perf*/, N' -- Active  
                AND en.Version_ID = @Version_ID  
                AND stgl.ImportStatus_ID = ', @StatusProcessing, N' -- Processing  
                AND stgl.Batch_ID = @Batch_ID  
        END;') END,   
  
N'  
        DELETE FROM @MandatoryHierarchy WHERE Hierarchy_ID = @CurrentHierarchy_ID  
    END; -- WHILE  
') END,   
  
N'  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' SELECT TOP 1 @ChangedAttributeID = AttributeID.'')  
    SELECT TOP 1 @ChangedAttributeID = AttributeID, @ChangedAttributeName = AttributeName  
    FROM @TrackingAttributeInfo  
    ORDER BY AttributeID  
  
    WHILE @@ROWCOUNT > 0  
    BEGIN  
        -- All new insert entity will be in tracking working set  
        SET @SQLCTG = N''  
        INSERT INTO #MemberAttributeWorkingSet  
        SELECT DISTINCT en.ID, '' + CAST (@ChangedAttributeID AS NVARCHAR(10)) + N''  
        FROM [stg].', @StagingLeafTableWithEscapedQuotes, -- This is being used in a nested dynamic SQL statement, so any single quotes within the table name must be escaped out  
                                                                N' stgl  
        INNER JOIN [mdm].', @EntityTable, N' en  
        ON      en.Code = stgl.Code  
            AND en.Status_ID = ', @MemberStatus_Active/*DO NOT replace this hardcoded value with a var. It would be bad for perf*/, N' -- Active  
            AND en.Version_ID = @Version_ID  
        WHERE stgl.ImportStatus_ID = ', @StatusProcessing, N'-- Processing  
            AND stgl.Batch_ID = @Batch_ID  
            AND stgl.'' + QUOTENAME(@ChangedAttributeName) + N'' IS NOT NULL; '';  
  
        EXEC sp_executesql @SQLCTG, N''@Batch_ID INT, @Version_ID INT'', @Batch_ID, @Version_ID;  
  
      SELECT TOP 1 @ChangedAttributeID = AttributeID, @ChangedAttributeName = AttributeName  
      FROM @TrackingAttributeInfo  
      WHERE AttributeID > @ChangedAttributeID  
      ORDER BY AttributeID  
    END  
',  
  
CASE WHEN @TransactionLogType = @TransactionLogType_Attribute THEN CONCAT(@TruncationGuard, N'  
    IF @LogFlag = 1  
    BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Insert into TransactionTble (@LogFlag = 1)'')  
        --Log member creation transactions.  
        --In this case OldValue, OldCode, NewValue, and NewCode are blank.  
        INSERT INTO [mdm].', QUOTENAME(@TransactionTableName), N'  
        (  
            Version_ID,  
            TransactionType_ID,  
            OriginalTransaction_ID,  
            Hierarchy_ID,  
            Entity_ID,  
            Member_ID,  
            Member_MUID,  
            MemberType_ID,  
            MemberCode,  
            OldValue,  
            OldCode,  
            NewValue,  
            NewCode,  
            Batch_ID,  
            EnterDTM,  
            EnterUserID,  
            LastChgDTM,  
            LastChgUserID  
        )  
        SELECT  
            @Version_ID, --Version_ID  
            @MemberCreateTransaction, --TransactionType_ID  
            0, --OriginalTransaction_ID  
            NULL, --Hierarchy_ID  
            @Entity_ID, --Entity_ID  
            en.ID, --Member_ID  
            en.MUID, --Member_MUID  
            @LeafMemberTypeID, --MemberType_ID  
            stgl.Code,  
            N'''', --OldValue  
            N'''', --OldCode  
            N'''', --NewValue  
            N'''', --NewCode  
            @Batch_ID,  
            GETUTCDATE(),  
            @User_ID,  
            GETUTCDATE(),  
            @User_ID  
        FROM mdm.', @EntityTable, N' en  
        INNER JOIN [stg].', @StagingLeafTable, N' stgl  
        ON      en.Code = stgl.Code  
            AND en.Status_ID = ', @MemberStatus_Active/*DO NOT replace this hardcoded value with a var. It would be bad for perf*/, N' -- Active  
            AND en.Version_ID = @Version_ID  
            AND stgl.ImportStatus_ID = ', @StatusProcessing, N' -- Processing  
            AND stgl.Batch_ID = @Batch_ID  
    END;') END,   
  
N'  
    -- Inserting records is done. Updated the status.  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Inserting records is done. Updated the status'')  
  
    UPDATE [stg].', @StagingLeafTable, N'  
    SET ImportStatus_ID = ', @StatusOK, N' -- OK  
    WHERE ImportStatus_ID = ', @StatusProcessing, N' -- Processing   
        AND Batch_ID = @Batch_ID;  
END; -- Insert or Merge  
  
IF EXISTS(SELECT 1 FROM @UsedImportTypes WHERE ImportType IN (', @IT_MergeOptimistic, N', ', @IT_MergeOverwrite, N'))  
BEGIN  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Set status to process updates.'')  
    -- Set status to process updates.  
    UPDATE stgl  
    SET ImportStatus_ID = ', @StatusProcessing, N' -- Processing  
    FROM [stg].', @StagingLeafTable, N' stgl  
    INNER JOIN mdm.', @EntityTable, N' en  
    ON      stgl.Code = en.Code  
        AND en.Status_ID = ', @MemberStatus_Active/*DO NOT replace this hardcoded value with a var. It would be bad for perf*/, N' -- Active  
        AND en.Version_ID = @Version_ID  
    WHERE   stgl.ImportType in (', @IT_MergeOptimistic, N', ', @IT_MergeOverwrite, N')  
        AND stgl.ImportStatus_ID = ', @StatusDefault, N' -- Default  
        AND stgl.Batch_ID = @Batch_ID;  
  
    --Process Updates  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Tracking updates.'')  
    -- Tracking updates  
    SELECT TOP 1 @ChangedAttributeID = AttributeID, @ChangedAttributeName = AttributeName, @ChagendAttributeColumnName = AttributeColumnName,  
                 @ChangedAttributeType_ID = AttributeTypeID, @ChangedAttributeDomainEntityTableName = DomainEntityTableName  
    FROM @TrackingAttributeInfo  
    ORDER BY AttributeID  
  
    WHILE @@ROWCOUNT > 0  
    BEGIN  
        IF @ChangedAttributeType_ID = @AttributeType_Domain  
        BEGIN  
            -- Update change tracking mask for merge optimistic.  
            SET @SQLCTG = N''  
            INSERT INTO #MemberAttributeWorkingSet  
            SELECT DISTINCT  
                en.ID,  
                '' + CAST (@ChangedAttributeID AS NVARCHAR(10)) + N''  
            FROM mdm.', @EntityTable, N' en  
            INNER JOIN [stg].', @StagingLeafTableWithEscapedQuotes, -- This is being used in a nested dynamic SQL statement, so any single quotes within the table name must be escaped out  
                                                                        N' stgl  
            ON      en.Code = stgl.Code  
                AND en.Status_ID = ', @MemberStatus_Active/*DO NOT replace this hardcoded value with a var. It would be bad for perf*/, N' -- Active  
                AND en.Version_ID = @Version_ID  
                AND stgl.ImportStatus_ID = ', @StatusProcessing, N'-- Processing  
                AND stgl.Batch_ID = @Batch_ID  
                AND stgl.ImportType = ', @IT_MergeOptimistic, N'  
                AND stgl.'' + QUOTENAME(@ChangedAttributeName) + N'' IS NOT NULL  
            LEFT JOIN [mdm].'' + QUOTENAME(@ChangedAttributeDomainEntityTableName) + N'' domain ON domain.Code = stgl.'' + QUOTENAME(@ChangedAttributeName) + N''  
                AND domain.Status_ID = ', @MemberStatus_Active/*DO NOT replace this hardcoded value with a var. It would be bad for perf*/, N' -- Active  
                AND domain.Version_ID = @Version_ID  
            WHERE  
                ISNULL(NULLIF(domain.ID, en.'' + QUOTENAME(@ChagendAttributeColumnName) + N''), NULLIF(en.'' + QUOTENAME(@ChagendAttributeColumnName) + N'', domain.ID)) IS NOT NULL;  
                '';  
  
            EXEC sp_executesql @SQLCTG, N''@Version_ID INT, @Batch_ID INT'', @Version_ID, @Batch_ID;  
  
            -- Update change tracking mask for merge overwrite.  
            SET @SQLCTG = N''  
            INSERT INTO #MemberAttributeWorkingSet  
            SELECT DISTINCT  
                en.ID,  
                '' + CAST (@ChangedAttributeID AS NVARCHAR(10)) + N''  
            FROM mdm.', @EntityTable, N' en  
            INNER JOIN [stg].', @StagingLeafTableWithEscapedQuotes, -- This is being used in a nested dynamic SQL statement, so any single quotes within the table name must be escaped out  
                                                                        N' stgl  
            ON      en.Code = stgl.Code  
                AND en.Status_ID = ', @MemberStatus_Active/*DO NOT replace this hardcoded value with a var. It would be bad for perf*/, N' -- Active  
                AND en.Version_ID = @Version_ID  
                AND stgl.ImportStatus_ID = ', @StatusProcessing, N'-- Processing  
                AND stgl.Batch_ID = @Batch_ID  
                AND stgl.ImportType = ', @IT_MergeOverwrite, N'  
            LEFT JOIN [mdm].'' + QUOTENAME(@ChangedAttributeDomainEntityTableName) + N'' domain ON domain.Code = stgl.'' + QUOTENAME(@ChangedAttributeName) + N''  
                AND domain.Status_ID = ', @MemberStatus_Active/*DO NOT replace this hardcoded value with a var. It would be bad for perf*/, N' -- Active  
                AND domain.Version_ID = @Version_ID  
            WHERE  
                ISNULL(NULLIF(domain.ID, en.'' + QUOTENAME(@ChagendAttributeColumnName) + N''), NULLIF(en.'' + QUOTENAME(@ChagendAttributeColumnName) + N'', domain.ID)) IS NOT NULL;  
                    '';  
  
            EXEC sp_executesql @SQLCTG, N''@Version_ID INT, @Batch_ID INT'', @Version_ID, @Batch_ID;  
        END  
        ELSE  
        BEGIN  
            -- Update change tracking mask for merge optimistic.  
            SET @SQLCTG = N''  
            INSERT INTO #MemberAttributeWorkingSet  
            SELECT DISTINCT  
                en.ID,  
                '' + CAST (@ChangedAttributeID AS NVARCHAR(10)) + N''  
            FROM mdm.', @EntityTable, N' en  
            INNER JOIN [stg].', @StagingLeafTableWithEscapedQuotes, -- This is being used in a nested dynamic SQL statement, so any single quotes within the table name must be escaped out  
                                                                        N' stgl  
            ON      en.Code = stgl.Code  
                AND en.Status_ID = ', @MemberStatus_Active/*DO NOT replace this hardcoded value with a var. It would be bad for perf*/, N' -- Active  
                AND en.Version_ID = @Version_ID  
                AND stgl.ImportStatus_ID = ', @StatusProcessing, N'-- Processing  
                AND stgl.Batch_ID = @Batch_ID  
                AND stgl.ImportType = ', @IT_MergeOptimistic, N'  
                AND stgl.'' + QUOTENAME(@ChangedAttributeName) + N'' IS NOT NULL  
                AND ISNULL(NULLIF(stgl.'' + QUOTENAME(@ChangedAttributeName) + N'', en.'' + QUOTENAME(@ChagendAttributeColumnName) + N''), NULLIF(en.'' + QUOTENAME(@ChagendAttributeColumnName) + N'', stgl.'' + QUOTENAME(@ChangedAttributeName) + N'')) IS NOT NULL;  
                '';  
  
            EXEC sp_executesql @SQLCTG, N''@Version_ID INT, @Batch_ID INT'', @Version_ID, @Batch_ID;  
  
            -- Update change tracking mask for merge overwrite.  
            SET @SQLCTG = N''  
            INSERT INTO #MemberAttributeWorkingSet  
            SELECT DISTINCT  
                en.ID,  
                '' + CAST (@ChangedAttributeID AS NVARCHAR(10)) + N''  
            FROM mdm.', @EntityTable, N' en  
            INNER JOIN [stg].', @StagingLeafTableWithEscapedQuotes, -- This is being used in a nested dynamic SQL statement, so any single quotes within the table name must be escaped out  
                                                                        N' stgl  
            ON      en.Code = stgl.Code  
                AND en.Status_ID = ', @MemberStatus_Active/*DO NOT replace this hardcoded value with a var. It would be bad for perf*/, N' -- Active  
                AND en.Version_ID = @Version_ID  
                AND stgl.ImportStatus_ID = ', @StatusProcessing, N'-- Processing  
                AND stgl.Batch_ID = @Batch_ID  
                AND stgl.ImportType = ', @IT_MergeOverwrite, N'  
                AND ISNULL(NULLIF(stgl.'' + QUOTENAME(@ChangedAttributeName) + N'', en.'' + QUOTENAME(@ChagendAttributeColumnName) + N''), NULLIF(en.'' + QUOTENAME(@ChagendAttributeColumnName) + N'', stgl.'' + QUOTENAME(@ChangedAttributeName) + N'')) IS NOT NULL;  
                '';  
  
            EXEC sp_executesql @SQLCTG, N''@Version_ID INT, @Batch_ID INT'', @Version_ID, @Batch_ID;  
        END  
  
        SELECT TOP 1 @ChangedAttributeID = AttributeID, @ChangedAttributeName = AttributeName, @ChagendAttributeColumnName = AttributeColumnName,  
                     @ChangedAttributeType_ID = AttributeTypeID, @ChangedAttributeDomainEntityTableName = DomainEntityTableName  
        FROM @TrackingAttributeInfo  
        WHERE AttributeID > @ChangedAttributeID  
        ORDER BY AttributeID  
    END; -- WHILE  
  
    IF EXISTS(SELECT 1 FROM @UsedImportTypes WHERE ImportType = ', @IT_MergeOptimistic, N')  
    BEGIN  
        --Process update (Merge Optimistic)  
        SET @Now = GETUTCDATE();  
        IF @LogFlag != 1  
        BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Process update (Merge Optimistic, @LogFlag != 1).'')  
            UPDATE en  
            SET Code = CASE WHEN stgl.[NewCode] IS NULL THEN en.[Code] ELSE stgl.[NewCode] END  
                ,ValidationStatus_ID = @AwaitingRevalidation  
                ,LastChgDTM = @Now  
                ,LastChgUserID = @User_ID  
                ,LastChgVersionID = @Version_ID  
                ,[Name] = CASE  
                            WHEN stgl.[Name] = @NULLText THEN NULL  
                            WHEN stgl.[Name] IS NULL THEN en.[Name]  
                            ELSE stgl.[Name]   
                          END  
                ', @SQLMergeOptimisticDBA, N'  
                ', @SQLMergeOptimisticNonDBA, N'  
            FROM mdm.', @EntityTable, N' en  
            INNER JOIN [stg].', @StagingLeafTable, N' stgl  
            ON      en.Code = stgl.Code  
                AND en.Status_ID = ', @MemberStatus_Active/*DO NOT replace this hardcoded value with a var. It would be bad for perf*/, N' -- Active  
                AND en.Version_ID = @Version_ID  
            ', @SQLDBAJoin, N'  
            WHERE stgl.ImportType = ', @IT_MergeOptimistic, N'  
                AND stgl.ImportStatus_ID = ', @StatusProcessing, N'-- Processing  
                AND stgl.Batch_ID = @Batch_ID;  
        END  
        ELSE  
        BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Insert update information into _HS table (@LogFlag = 1).'')  
            -- Insert update information into _HS table.  
            UPDATE en  
            SET Code = CASE WHEN stgl.[NewCode] IS NULL THEN en.[Code] ELSE stgl.[NewCode] END  
                ,ValidationStatus_ID = @AwaitingRevalidation  
                ,LastChgDTM = @Now  
                ,LastChgUserID = @User_ID  
                ,LastChgVersionID = @Version_ID  
                ,[Name] = CASE  
                            WHEN stgl.[Name] = @NULLText THEN NULL  
                            WHEN stgl.[Name] IS NULL THEN en.[Name]  
                            ELSE stgl.[Name]   
                          END  
                ', @SQLMergeOptimisticDBA, N'  
                ', @SQLMergeOptimisticNonDBA,   
                CASE @TransactionLogType  
                    WHEN @TransactionLogType_Member THEN @ENHistoryOutputQuery  
                    WHEN @TransactionLogType_Attribute THEN CONCAT(N'  
                OUTPUT inserted.ID, inserted.MUID, deleted.Code, inserted.Code, deleted.Name, inserted.Name ', @TranDeletedColumn, @TranInsertedColumn, N'  
                INTO #TRANLOG')  
                    ELSE N''  
                END, N'  
            FROM mdm.', @EntityTable, N' en  
            INNER JOIN [stg].', @StagingLeafTable, N' stgl  
            ON      en.Code = stgl.Code  
                AND en.Status_ID = ', @MemberStatus_Active/*DO NOT replace this hardcoded value with a var. It would be bad for perf*/, N' -- Active  
                AND en.Version_ID = @Version_ID  
            ', @SQLDBAJoin, N'  
            WHERE stgl.ImportType = ', @IT_MergeOptimistic, N'  
                AND stgl.ImportStatus_ID = ', @StatusProcessing, N'-- Processing  
                AND stgl.Batch_ID = @Batch_ID;  
        END; --IF  
    END; -- IF MergeOptimistic  
  
    IF EXISTS(SELECT 1 FROM @UsedImportTypes WHERE ImportType = ', @IT_MergeOverwrite, N')  
    BEGIN  
         --Process update (Merge Overwrite)  
        SET @Now = GETUTCDATE();  
        IF @LogFlag != 1  
        BEGIN  
            IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Process update (Merge Overwrite, @LogFlag != 1).'')  
            UPDATE en  
            SET Code = CASE WHEN stgl.[NewCode] IS NULL THEN en.[Code] ELSE stgl.[NewCode] END  
                ,ValidationStatus_ID = @AwaitingRevalidation  
                ,LastChgDTM = @Now  
                ,LastChgUserID = @User_ID  
                ,LastChgVersionID = @Version_ID  
                ,Name = NULLIF(stgl.[Name], @NULLText)  
                ', @SQLMergeOverwriteDBA, N'  
                ', @SQLMergeOverwriteNonDBA, N'  
            FROM mdm.', @EntityTable, N' en  
            INNER JOIN [stg].', @StagingLeafTable, N' stgl  
            ON      en.Code = stgl.Code  
                AND en.Status_ID = ', @MemberStatus_Active/*DO NOT replace this hardcoded value with a var. It would be bad for perf*/, N' -- Active  
                AND en.Version_ID = @Version_ID  
            ', @SQLDBAJoin, N'  
            WHERE stgl.ImportType = ', @IT_MergeOverwrite, N'  
                AND stgl.ImportStatus_ID = ', @StatusProcessing, N'-- Processing  
                AND stgl.Batch_ID = @Batch_ID;  
        END  
        ELSE  
        BEGIN  
            IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Insert update information into _HS table (@LogFlag = 1).'')  
            -- Insert update information into _HS table.  
            UPDATE en  
            SET Code = CASE WHEN stgl.[NewCode] IS NULL THEN en.[Code] ELSE stgl.[NewCode] END  
                ,ValidationStatus_ID = @AwaitingRevalidation  
                ,LastChgDTM = @Now  
                ,LastChgUserID = @User_ID  
                ,LastChgVersionID = @Version_ID  
                ,Name = NULLIF(stgl.[Name], @NULLText)  
                ', @SQLMergeOverwriteDBA, N'  
                ', @SQLMergeOverwriteNonDBA,   
                CASE @TransactionLogType  
                    WHEN @TransactionLogType_Member THEN @ENHistoryOutputQuery  
                    WHEN @TransactionLogType_Attribute THEN CONCAT(N'  
                OUTPUT inserted.ID, inserted.MUID, deleted.Code, inserted.Code, deleted.Name, inserted.Name ', @TranDeletedColumn, @TranInsertedColumn, N'  
                INTO #TRANLOG')  
                END, N'  
            FROM mdm.', @EntityTable, N' en  
            INNER JOIN [stg].', @StagingLeafTable, N' stgl  
            ON      en.Code = stgl.Code  
                AND en.Status_ID = ', @MemberStatus_Active/*DO NOT replace this hardcoded value with a var. It would be bad for perf*/, N' -- Active  
                AND en.Version_ID = @Version_ID  
            ', @SQLDBAJoin, N'  
            WHERE stgl.ImportType = ', @IT_MergeOverwrite, N'  
                AND stgl.ImportStatus_ID = ', @StatusProcessing, N'-- Processing  
                AND stgl.Batch_ID = @Batch_ID;  
        END;  
    END; -- IF MergeOverwrite  
  
    ----------------------------------------------------------------------------------------  
    --Check for Inheritance Business Rules and update dependent members validation status.  
    ----------------------------------------------------------------------------------------  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Check for Inheritance Business Rules and update dependent members validation status.'')  
  
    IF EXISTS(SELECT 1 FROM @TrackingAttributeInfo WHERE TrackingType & 4 <> 0)  
    BEGIN  
        --check DBA Inheritance  
        DECLARE @BRInherit AS TABLE (  
             RowNumber INT IDENTITY(1,1) NOT NULL PRIMARY KEY  
            ,DependentAttributeColumnName SYSNAME NOT NULL  
            ,DependentEntityTable SYSNAME NULL  
            ,AttributeID int null  
                    );  
  
        DECLARE @Counter       INT = 0,  
                @MaxCounter    INT = 0;  
  
        --DBA Inheritance  
        INSERT INTO @BRInherit (DependentEntityTable, DependentAttributeColumnName, AttributeID)  
        SELECT DISTINCT  
             depEnt.EntityTable  
            ,i.ChildAttributeColumnName  
            ,a.AttributeID  
        FROM mdm.viw_SYSTEM_BUSINESSRULES_ATTRIBUTE_INHERITANCE_HIERARCHY i  
        INNER JOIN @TrackingAttributeInfo a  
            ON a.AttributeName = i.ParentAttributeName  AND i.ParentEntityID = @Entity_ID AND a.TrackingType & 4 <> 0  
        INNER JOIN mdm.tblEntity AS depEnt  
            ON i.ChildEntityID = depEnt.ID;  
  
        IF EXISTS(SELECT 1 FROM @BRInherit) BEGIN  
            SELECT  
                 @DependentValidationStatus = @AwaitingDependentMemberRevalidation  
                ,@Counter = 1  
                ,@MaxCounter = MAX(RowNumber)  
            FROM @BRInherit;  
  
            --Loop through each DBA Entity updating the dependent members validation status.  
            WHILE @Counter <= @MaxCounter  
            BEGIN  
                SELECT  
                    @DependentEntityTable = DependentEntityTable,  
                    @DependentAttributeColumnName = DependentAttributeColumnName,  
                    @ChangedAttributeID = AttributeID  
                FROM @BRInherit WHERE [RowNumber] = @Counter;  
  
                --Update immediate dependent member table validation status.  
                SELECT @SQLCTG = N''  
                UPDATE   dep  
                SET dep.ValidationStatus_ID = @DependentValidationStatus  
                FROM  mdm.'' + @DependentEntityTable + N'' AS dep  
                INNER JOIN #MemberAttributeWorkingSet AS ws  
                ON dep.'' + @DependentAttributeColumnName + N'' = ws.MemberID  
                    AND ws.AttributeID = @ChangedAttributeID  
                    AND dep.Version_ID = @Version_ID  
                    AND dep.ValidationStatus_ID <> @DependentValidationStatus;  
                    '';  
  
                --PRINT @SQLCTG;  
                EXEC sp_executesql @SQLCTG, N''@Version_ID INT, @DependentValidationStatus INT, @ChangedAttributeID INT'', @Version_ID, @DependentValidationStatus, @ChangedAttributeID;  
  
                SET @Counter += 1;  
  
            END; -- WHILE  
        END; -- IF @BRInherit  
    END; -- IF @TrackingAttributeInfo  
END; -- IF Merge  
',  
CASE WHEN @TransactionLogType = @TransactionLogType_Attribute THEN CONCAT(@TruncationGuard, N'  
  
IF @LogFlag = 1  
BEGIN  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Update Attribute Transaction table (@LogFlag = 1).'')  
    DECLARE @TempTable TABLE(  
        ID              INT,  
        TableColumn     NVARCHAR(128) COLLATE DATABASE_DEFAULT NOT NULL,  
        DomainEntity_ID INT NULL,  
        SortOrder       INT,  
        DomainTable     SYSNAME NULL);  
  
    DECLARE     @CurrentID              INT,  
                @CurrentTableColumn     NVARCHAR(128),  
                @CurrentDomainEntity_ID INT,  
                @CurrentSortOrder       INT,  
                @CurrentDomainTable     SYSNAME,  
                @TranSQL                NVARCHAR(MAX) = N'''';  
  
    INSERT INTO @TempTable  
    SELECT  
        A.ID,  
        A.TableColumn,  
        A.DomainEntity_ID,  
        A.SortOrder,  
        E.EntityTable AS DomainTable  
    FROM  
    mdm.tblAttribute A  
    LEFT OUTER JOIN mdm.tblEntity E  
    ON A.DomainEntity_ID = E.ID  
    WHERE A.Entity_ID = @Entity_ID AND A.MemberType_ID = @LeafMemberTypeID  
    AND (A.IsSystem = 0 OR A.IsCode = 1 OR A.IsName = 1) -- Exclude system attributes other than Code and Name.  
    ORDER BY  
        SortOrder ASC;  
  
    -- For each attribute, set the attribute update information to the Transaction table.  
    WHILE EXISTS(SELECT 1 FROM @TempTable) BEGIN  
        SELECT TOP 1  
            @CurrentID = ID,  
            @CurrentTableColumn = TableColumn,  
            @CurrentDomainEntity_ID = DomainEntity_ID,  
            @CurrentSortOrder = SortOrder,  
            @CurrentDomainTable = DomainTable  
        FROM @TempTable  
        ORDER BY SortOrder;  
        -- Get Old and New values from #TRANLOG table and insert into the transaction table.  
  
        IF @CurrentDomainEntity_ID IS NULL -- Handle non DBA  
        BEGIN  
  
            SET @TranSQL = N''  
    INSERT INTO [mdm].', QUOTENAME(@TransactionTableName), N'  
    (  
        Version_ID,  
        TransactionType_ID,  
        OriginalTransaction_ID,  
        Hierarchy_ID,  
        Entity_ID,  
        Attribute_ID,  
        Member_ID,  
        Member_MUID,  
        MemberType_ID,  
        MemberCode,  
        OldValue,  
        OldCode,  
        NewValue,  
        NewCode,  
        Batch_ID,  
        EnterDTM,  
        EnterUserID,  
        LastChgDTM,  
        LastChgUserID  
    )  
    SELECT  
        @Version_ID, --Version_ID  
        3, --TransactionType_ID (Member attribute set)  
        0, --OriginalTransaction_ID  
        NULL, --Hierarchy_ID  
        @Entity_ID, --Entity_ID  
        @Attribute_ID, -- Attribute_ID  
        MemberID, --Member_ID  
        MemberMUID, --Member_MUID  
        1, -- Leaf Member Type ID  
        CASE WHEN ISNULL(Code, N'''''''') = N'''''''' THEN New_Code ELSE Code END,  
        '' + @CurrentTableColumn + N'',  
        '' + @CurrentTableColumn + N'',  
        New_'' + @CurrentTableColumn + N'',  
        New_'' + @CurrentTableColumn + N'',  
        @Batch_ID,  
        GETUTCDATE(),  
        @User_ID,  
        GETUTCDATE(),  
        @User_ID  
    FROM #TRANLOG  
    WHERE ISNULL(NULLIF('' + @CurrentTableColumn + N'', New_'' + @CurrentTableColumn + N''), NULLIF(New_'' + @CurrentTableColumn + N'', '' + @CurrentTableColumn + N'')) IS NOT NULL  
        '';  
  
            EXEC sp_executesql @TranSQL, N''@Version_ID INT, @Attribute_ID INT, @Entity_ID INT, @Batch_ID INT, @User_ID INT '', @Version_ID, @CurrentID, @Entity_ID, @Batch_ID, @User_ID;  
        END  
        ELSE  
        BEGIN  
            -- Handle DBA  
            -- Get the old code value and the new code value by table join.  
            SET @TranSQL = N''  
    INSERT INTO [mdm].', QUOTENAME(@TransactionTableName), N'  
    (  
        Version_ID,  
        TransactionType_ID,  
        OriginalTransaction_ID,  
        Hierarchy_ID,  
        Entity_ID,  
        Attribute_ID,  
        Member_ID,  
        Member_MUID,  
        MemberType_ID,  
        MemberCode,  
        OldValue,  
        OldCode,  
        NewValue,  
        NewCode,  
        Batch_ID,  
        EnterDTM,  
        EnterUserID,  
        LastChgDTM,  
        LastChgUserID  
    )  
    SELECT  
        @Version_ID, --Version_ID  
        3, --TransactionType_ID (Member attribute set)  
        0, --OriginalTransaction_ID  
        NULL, --Hierarchy_ID  
        @Entity_ID, --Entity_ID  
        @Attribute_ID, -- Attribute_ID  
        T.MemberID, --Member_ID  
        T.MemberMUID, --Member_MUID  
        1, -- Leaf Member Type ID  
        CASE WHEN ISNULL(T.Code, N'''''''') = N'''''''' THEN T.New_Code ELSE T.Code END,  
        T.'' + @CurrentTableColumn + N'',  
        DO.Code,  
        New_'' + @CurrentTableColumn + N'',  
        DN.Code,  
        @Batch_ID,  
        GETUTCDATE(),  
        @User_ID,  
        GETUTCDATE(),  
        @User_ID  
    FROM #TRANLOG T  
    LEFT OUTER JOIN mdm.'' + QUOTENAME(@CurrentDomainTable) + N'' DN  
    ON T.New_'' + @CurrentTableColumn + N'' = DN.ID  
    LEFT OUTER JOIN mdm.'' + QUOTENAME(@CurrentDomainTable) + N'' DO  
    ON T.'' + @CurrentTableColumn + N'' = DO.ID  
    WHERE ISNULL(NULLIF(T.'' + @CurrentTableColumn + N'', T.New_'' + @CurrentTableColumn + N''), NULLIF(T.New_'' + @CurrentTableColumn + N'', T.'' + @CurrentTableColumn + N'')) IS NOT NULL  
        '';  
  
            EXEC sp_executesql @TranSQL, N''@Version_ID INT, @Attribute_ID INT, @Entity_ID INT, @Batch_ID INT, @User_ID INT '', @Version_ID, @CurrentID, @Entity_ID, @Batch_ID, @User_ID;  
  
        END; --IF  
  
        DELETE FROM @TempTable WHERE ID = @CurrentID;  
  
    END; --WHILE  
  
    TRUNCATE TABLE #TRANLOG;  
  
END; --IF')   
END, N'  
IF EXISTS(SELECT 1 FROM @UsedImportTypes WHERE ImportType IN (', @IT_MergeOptimistic, N', ', @IT_MergeOverwrite, N'))  
BEGIN  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Updating is done. Update the status.'')  
    -- Updating is done. Update the status.  
    UPDATE sc  
    SET ImportStatus_ID = ', @StatusOK, N' -- OK  
    FROM [stg].', @StagingLeafTable, N' sc  
    WHERE sc.ImportStatus_ID = ', @StatusProcessing, N'-- Processing   
        AND sc.Batch_ID = @Batch_ID;  
END -- IF Merge  
  
-- Update Tracking group  
IF EXISTS (SELECT 1 FROM @TrackingAttributeInfo WHERE TrackingType & 1 <> 0) BEGIN  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Update Tracking group.'')  
    UPDATE en  
    SET en.ChangeTrackingMask = ISNULL(en.ChangeTrackingMask, 0) | trackingMask.ChangeTrackingMask  
    FROM mdm.', @EntityTable, N' en  
    INNER JOIN     (  
        SELECT MemberID, SUM(Distinct(ISNULL(POWER(2, a.ChangeTrackingGroupID - 1), 0))) as ChangeTrackingMask  
        FROM #MemberAttributeWorkingSet ws  
        INNER JOIN @TrackingAttributeInfo a  
            ON a.AttributeID = ws.AttributeID AND a.TrackingType & 1 <> 0  
        GROUP BY MemberID) as trackingMask  
        ON en.ID = trackingMask.MemberID  and en.Version_ID = @Version_ID  
END  
  
----------------------------------------------------------------------------------------  
--Check circular reference  
----------------------------------------------------------------------------------------  
IF EXISTS (SELECT 1 FROM @TrackingAttributeInfo WHERE TrackingType & 2 <> 0) BEGIN  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Check circular reference.'')  
    -- Check circular references only when there is a DBA to check.  
    DECLARE @RecursiveHierarchy_ID              INT = 0,  
            @RecursiveHierarchyAttribute_ID     INT = 0,  
            @CircularReferenceErrors            INT = 0,  
            @CRMembers           mdm.MemberAttributes;  
  
    -- Determine if a recursive derived hierarchy is in play.  There may be multiple but just grab the first one.  
    SELECT TOP 1  
         @RecursiveHierarchy_ID  = d.DerivedHierarchy_ID  
        ,@RecursiveHierarchyAttribute_ID = att.Attribute_ID  
    FROM mdm.tblDerivedHierarchyDetail d  
    INNER JOIN [mdm].[viw_SYSTEM_SCHEMA_ATTRIBUTES] att  
        ON att.Attribute_DBAEntity_ID = @Entity_ID  
        AND att.Attribute_ID = d.Foreign_ID  
        AND d.ForeignParent_ID = att.Attribute_DBAEntity_ID  
  
    IF @RecursiveHierarchy_ID > 0 BEGIN  
        INSERT INTO @CRMembers (MemberCode)  
        SELECT en.Code  
        FROM #MemberAttributeWorkingSet ws  
        INNER JOIN mdm.', @EntityTable, N' en  
        ON en.ID = ws.MemberID AND en.Version_ID = @Version_ID  
        WHERE AttributeID = @RecursiveHierarchyAttribute_ID  
    END  
  
    IF EXISTS(SELECT 1 FROM @CRMembers) BEGIN  
  
        --There is a recursive derived hierarchy in play therefore we need to check the DBA values for circular references.  
        DECLARE @CircularReferenceCodeList TABLE  
        (  
            MemberCode            NVARCHAR(MAX) COLLATE DATABASE_DEFAULT NULL  
        );  
  
        --Call [udpCircularReferenceMemberCodesGet] and get the number of circular reference errors and the member codes  
        --that participate in the circular reference  
        INSERT INTO @CircularReferenceCodeList EXEC    @CircularReferenceErrors = [mdm].[udpCircularReferenceMemberCodesGet]  
                                                    @Model_ID = @Model_ID,  
                                                    @RecursiveHierarchy_ID = @RecursiveHierarchy_ID,  
                                                    @MemberAttributes = @CRMembers;  
  
        --If we found circular references, rollback the transaction and set the error code.  
        IF @CircularReferenceErrors > 0  
        BEGIN  
            IF @TranCounter = 0 ROLLBACK TRANSACTION;  
            ELSE IF XACT_STATE() <> -1 ROLLBACK TRANSACTION TX;  
  
            -- Set error 210016 (Binary Location: 2^13) for record(s) that caused the issue.  
            UPDATE stgl  
            SET ErrorCode = stgl.ErrorCode | 8192,  
                ImportStatus_ID = ', @StatusError, N' -- Error  
            FROM [stg].', @StagingLeafTable, N' stgl  
            INNER JOIN @CircularReferenceCodeList cref  
            ON stgl.Code = cref.MemberCode  
            WHERE stgl.ImportType IN (', @IT_MergeOptimistic, N', ', @IT_Insert, N', ', @IT_MergeOverwrite, N')  
                AND stgl.Batch_ID = @Batch_ID;  
  
            -- If there is any circular reference the entire batch process fails.  
            -- Since the records without an error status in the batch process rolled back as well,  
            -- Set their status as not processed.  
  
            UPDATE [stg].', @StagingLeafTable, N'  
            SET ImportStatus_ID = ', @StatusDefault, N' -- Default  
            WHERE Batch_ID = @Batch_ID AND ImportStatus_ID <> ', @StatusError, N' -- Error  
  
            --Get the number of errors for the batch ID  
            SELECT @ErrorCount = COUNT(ID) FROM [stg].', @StagingLeafTable, N'  
            WHERE Batch_ID = @Batch_ID AND ImportStatus_ID = ', @StatusError, N' -- Error  
  
            -- Set the status of the batch as Not Running (Completed).  
            -- Set the error member count.  
            UPDATE mdm.tblStgBatch  
            SET Status_ID = @Completed,  
                LastRunEndDTM = GETUTCDATE(),  
                LastRunEndUserID = @User_ID,  
                ErrorMemberCount = @ErrorCount  
            WHERE ID = @Batch_ID;  
  
            RETURN @OtherRuntimeError;  
  
        END; --IF  
    END;--IF  
END;--IF  
  
IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Determine if any purge or delete records exist.'')  
  
--Determine if any purge or delete records exist  
IF EXISTS(SELECT 1 FROM @UsedImportTypes WHERE ImportType IN (', @IT_Delete, N', ', @IT_Purge, N', ', @IT_DeleteSetNullToRef, N', ', @IT_PurgeSetNullToRef, N'))  
BEGIN  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Populate a temp table of FK Relationships.'')  
    --Populate a temp table of FK Relationships  
    DECLARE @TABLEFK TABLE  
    (  
         ID                 INT IDENTITY (1, 1) NOT NULL PRIMARY KEY  
        ,Entity_ID          INT  
        ,TableName          SYSNAME COLLATE DATABASE_DEFAULT NULL  
        ,AttributeName      NVARCHAR(100) COLLATE DATABASE_DEFAULT NULL  
        ,TableColumn        SYSNAME COLLATE DATABASE_DEFAULT NOT NULL  
        ,MemberType_ID      INT  
    );  
  
    INSERT INTO @TABLEFK (Entity_ID, TableName, AttributeName, TableColumn, MemberType_ID)  
    SELECT   
        Entity_ID,  
        mdm.udfTableNameGetByID(Entity_ID, MemberType_ID),  
        Name,  
        TableColumn,  
        MemberType_ID  
    FROM mdm.tblAttribute  
    WHERE DomainEntity_ID = @Entity_ID;  
  
    DECLARE @FkTotalCount INT = 0;  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' SELECT @FkTotalCount = COUNT(ID) FROM @TABLEFK;'')  
    SELECT @FkTotalCount = COUNT(ID) FROM @TABLEFK;  
  
    IF @FkTotalCount > 0  
    BEGIN  
        DECLARE   
            @Row_ID         INT,  
            @TableName      SYSNAME,  
            @TableColumn    SYSNAME,  
            @FKSQL          NVARCHAR(MAX) = N''''  
  
        -- When not setting references to null, add errors for any existing references. This must be done for all FK before setting any refs to null.  
        IF EXISTS(SELECT 1 FROM #MembersToRemove WHERE SetToNull = 0)  
        BEGIN  
            IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' CREATE TABLE #ErrorRows'')  
            CREATE TABLE #ErrorRows  
            (  
                Staging_ID      INT,  
                Member_ID       INT,  
                MemberCode      NVARCHAR(250) COLLATE DATABASE_DEFAULT,  
                TableColumn     SYSNAME COLLATE DATABASE_DEFAULT,   
            )  
            CREATE CLUSTERED INDEX #ErrorRows_Staging_ID ON #ErrorRows(Staging_ID);  
  
            -- Loop through FK references, to check for errors  
            SET @Row_ID = 0;  
            WHILE @FkTotalCount > @Row_ID  
            BEGIN  
                SELECT TOP 1  
                    @TableName = TableName,  
                    @TableColumn = TableColumn,  
                    @Row_ID = ID  
                FROM @TABLEFK  
                WHERE ID > @Row_ID  
                ORDER BY ID;  
  
                SET @FKSQL = CONCAT(N''  
                    DELETE mtr  
                    OUTPUT deleted.Staging_ID, deleted.Member_ID, deleted.MemberCode, '', QUOTENAME(@TableColumn, N''''''''), N''  
                    INTO #ErrorRows (Staging_ID, Member_ID, MemberCode, TableColumn)  
                    FROM #MembersToRemove mtr  
                    INNER JOIN mdm.'', QUOTENAME(@TableName), N'' en  
                    ON      en.Version_ID = @Version_ID  
                        AND mtr.Member_ID = en.'', QUOTENAME(@TableColumn), N''  
                    WHERE mtr.SetToNull = 0'');  
  
                EXEC sp_executesql @FKSQL, N''@Version_ID INT'', @Version_ID;  
            END -- loop through FKs, error check  
  
            IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Check for Error 210052- The member cannot be deleted or purged when it is referenced as a domain-based attribute value.'')  
            --In case of @IT_Delete and @IT_Purge when the entity is referenced via foreign key, set as an error.  
            --Error 210052 Binary Location 2^19: The member cannot be deleted or purged when it is referenced as a domain-based attribute value.  
            UPDATE stg  
            SET ErrorCode = ErrorCode | 524288,  
                ImportStatus_ID = ', @StatusError, N' -- Error  
            FROM [stg].', @StagingLeafTable, N' stg  
            INNER JOIN #ErrorRows er  
            ON stg.ID = er.Staging_ID  
  
            IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Insert the error detail information.'')  
            -- Insert the error detail information.  
            INSERT INTO [mdm].[tblStgErrorDetail]  
                (Batch_ID, Code, AttributeName, AttributeValue, UniqueErrorCode)  
            SELECT  
                @Batch_ID, MemberCode, TableColumn, Member_ID, 210052  
            FROM #ErrorRows  
        END -- If exists SetToNull = 0  
  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Set references to null'')  
        -- Set references to null. This must be done after the above error checks.  
        IF EXISTS(SELECT 1 FROM #MembersToRemove WHERE SetToNull = 1)  
        BEGIN  
            -- Loop through FK references, setting referencing DBAs to null  
            SET @Row_ID = 0;  
            WHILE @FkTotalCount > @Row_ID  
            BEGIN  
                SELECT TOP 1  
                    @TableName = TableName,  
                    @TableColumn = TableColumn,  
                    @Row_ID = ID  
                FROM @TABLEFK  
                WHERE ID > @Row_ID  
                ORDER BY ID;  
  
                SET @FKSQL = CONCAT(N''  
                    UPDATE en  
                    SET '', QUOTENAME(@TableColumn), N'' = NULL  
                    FROM #MembersToRemove mtr  
                    INNER JOIN mdm.'', QUOTENAME(@TableName), N'' en  
                    ON      en.Version_ID = @Version_ID  
                        AND mtr.Member_ID = en.'', QUOTENAME(@TableColumn), N''  
                        AND mtr.SetToNull = 1'');  
  
                 EXEC sp_executesql @FKSQL, N''@Version_ID INT'', @Version_ID;  
            END -- loop through FKs, set DBAs to null  
        END  
    END -- IF FK  
    ',  
CASE WHEN @IsHierarchyEnabled = 1 THEN CONCAT(@TruncationGuard, N'  
    -- Deactivate (soft delete) the member in Hierarchy Relationship table.  
    SET @Now = GETUTCDATE();  
    IF @LogFlag != 1  
    BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Deactivate (soft delete) the member in Hierarchy Relationship table (@LogFlag != 1).'')  
        UPDATE hr  
        SET Status_ID = ', @MemberStatus_Deactivated, N' -- Deactivated  
           ,LastChgDTM = @Now  
           ,LastChgUserID = @User_ID  
           ,LastChgVersionID = @Version_ID  
        FROM mdm.', @HierarchyRelationshipTable, N' hr  
        INNER JOIN #MembersToRemove mtr  
        ON      hr.Version_ID = @Version_ID  
            AND hr.Child_EN_ID = mtr.Member_ID  
            AND mtr.IsPurge = 0;  
    END  
    ELSE  
    BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Deactivate (soft delete) the member in Hierarchy Relationship table (@LogFlag = 1).'')  
        UPDATE hr  
        SET Status_ID = ', @MemberStatus_Deactivated, N' -- Deactivated  
           ,LastChgDTM = @Now  
           ,LastChgUserID = @User_ID  
           ,LastChgVersionID = @Version_ID',  
        CASE @TransactionLogType  
            WHEN @TransactionLogType_Member THEN @HRHistoryOutputQuery  
        END, N'  
        FROM mdm.', @HierarchyRelationshipTable, N' hr  
        INNER JOIN #MembersToRemove mtr  
        ON      hr.Version_ID = @Version_ID  
            AND hr.Child_EN_ID = mtr.Member_ID  
            AND mtr.IsPurge = 0;  
    END;  
    ')  
END, N'  
    -- Deactivate (soft delete) the member in Entity table.  
    SET @Now = GETUTCDATE();  
    IF @LogFlag != 1  
    BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Deactivate (soft delete) the member in Entity table. (@LogFlag != 1).'')  
        UPDATE en  
        SET Status_ID = ', @MemberStatus_Deactivated, N' -- Deactivated  
           ,LastChgDTM = @Now  
           ,LastChgUserID = @User_ID  
           ,LastChgVersionID = @Version_ID  
        FROM mdm.', @EntityTable, N' en  
        INNER JOIN #MembersToRemove mtr  
        ON      en.Version_ID = @Version_ID  
            AND en.ID = mtr.Member_ID  
            AND mtr.IsPurge = 0;  
    END  
    ELSE  
    BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Deactivate (soft delete) the member in Entity table. (@LogFlag = 1).'')  
        UPDATE en  
        SET Status_ID = ', @MemberStatus_Deactivated, N' -- Deactivated  
           ,LastChgDTM = @Now  
           ,LastChgUserID = @User_ID  
           ,LastChgVersionID = @Version_ID',  
        CASE @TransactionLogType  
            WHEN @TransactionLogType_Member THEN @ENHistoryOutputQuery  
            WHEN @TransactionLogType_Attribute THEN @OutputDeletionToTransactionTableQuery  
        END, N'  
        FROM mdm.', @EntityTable, N' en  
        INNER JOIN #MembersToRemove mtr  
        ON      en.Version_ID = @Version_ID  
            AND en.ID = mtr.Member_ID  
            AND mtr.IsPurge = 0;  
    END',  
  
    CASE WHEN @IsHierarchyEnabled = 1 THEN CONCAT(@TruncationGuard, N'  
    -- ImportType is Purge.  
    -- Hard delete the member FROM Hierarchy Relationship table.  
    SET @Now = GETUTCDATE();  
    IF @LogFlag != 1  
    BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Hard delete the member FROM Hierarchy Relationship table (@LogFlag != 1).'')  
        DELETE hr  
        FROM mdm.', @HierarchyRelationshipTable, N' hr  
        INNER JOIN #MembersToRemove mtr  
        ON      hr.Version_ID = @Version_ID  
            AND hr.Child_EN_ID = mtr.Member_ID  
            AND mtr.IsPurge = 1;  
    END  
    ELSE  
    BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Hard delete the member FROM Hierarchy Relationship table (@LogFlag = 1).'')  
        DELETE hr',  
        CASE @TransactionLogType  
            WHEN @TransactionLogType_Member THEN @HRHistoryOutputQuery  
        END, N'  
        FROM mdm.', @HierarchyRelationshipTable, N' hr  
        INNER JOIN #MembersToRemove mtr  
        ON      hr.Version_ID = @Version_ID  
            AND hr.Child_EN_ID = mtr.Member_ID  
            AND mtr.IsPurge = 1;  
    END  
    ') END, N'  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Delete member security.'')  
    -- Delete member security  
    DELETE sra  
    FROM mdm.tblSecurityRoleAccessMember sra  
    INNER JOIN #MembersToRemove mtr  
    ON      sra.Version_ID = @Version_ID  
        AND sra.Member_ID = mtr.Member_ID  
        AND sra.Entity_ID = @Entity_ID  
        AND sra.HierarchyType_ID IN (0, 1) -- Derived and Explicit Hierarchy  
        AND sra.MemberType_ID = ', @MemberType_Leaf, N'-- Leaf  
        AND mtr.IsPurge = 1;  
  
    -- Hard delete the member from Entity table.  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Get the IDs of any rows in tblFile that are about to be orphaned.'')  
    -- Get the IDs of any rows in tblFile that are about to be orphaned  
    CREATE TABLE #FileIDsToDelete  
    (  
        ID  INT  
    );  
    DECLARE @GetFileIdsSQL NVARCHAR(MAX) = mdm.udfFileIDReferencesGetSQL(@Entity_ID, 1/*Leaf*/, NULL, 1/*Soft-deleted members only*/)  
    IF LEN(@GetFileIdsSQL) > 0  
    BEGIN  
        SET @GetFileIdsSQL = CONCAT(N''INSERT INTO #FileIDsToDelete(ID)  
'', @GetFileIdsSQL);  
        EXEC sp_executesql @GetFileIdsSQL;  
    END  
  
    SET @Now = GETUTCDATE();  
    IF @LogFlag != 1  
    BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Hard delete the member from Entity table (@LogFlag != 1).'')  
        DELETE en  
        FROM mdm.', @EntityTable, N' en  
        INNER JOIN #MembersToRemove mtr  
        ON      en.Version_ID = @Version_ID  
            AND en.ID = mtr.Member_ID  
            AND mtr.IsPurge = 1;  
    END  
    ELSE  
    BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Hard delete the member from Entity table (@LogFlag = 1).'')  
        DELETE en',  
        CASE @TransactionLogType  
            WHEN @TransactionLogType_Member THEN @ENHistoryOutputQuery  
            WHEN @TransactionLogType_Attribute THEN @OutputDeletionToTransactionTableQuery  
        END, N'  
        FROM mdm.', @EntityTable, N' en  
        INNER JOIN #MembersToRemove mtr  
        ON      en.Version_ID = @Version_ID  
            AND en.ID = mtr.Member_ID  
            AND mtr.IsPurge = 1;',  
  
CASE WHEN @TransactionLogType = @TransactionLogType_Attribute THEN CONCAT(@TruncationGuard, N'  
  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Log delete and purge of members (Attribute log type).'')  
        --Log delete and purge of members.  
        --Because there is no transaction status for hard delete, record hard delete as deactivation.  
        INSERT INTO [mdm].', QUOTENAME(@TransactionTableName), N'  
        (  
            Version_ID,  
            TransactionType_ID,  
            OriginalTransaction_ID,  
            Hierarchy_ID,  
            Entity_ID,  
            Member_ID,  
            Member_MUID,  
            MemberType_ID,  
            MemberCode,  
            OldValue,  
            OldCode,  
            NewValue,  
            NewCode,  
            Batch_ID,  
            EnterDTM,  
            EnterUserID,  
            LastChgDTM,  
            LastChgUserID  
        )  
        SELECT  
            @Version_ID, --Version_ID  
            @MemberStatusSetTransaction, --TransactionType_ID  
            0, --OriginalTransaction_ID  
            NULL, --Hierarchy_ID  
            @Entity_ID, --Entity_ID  
            MemberID, --Member_ID  
            MemberMUID, --Member_MUID  
            @LeafMemberTypeID, --MemberType_ID  
            Code,  
            N''1'', --OldValue  
            N''Active'', --OldCode  
            N''2'', --NewValue  
            N''De-Activated'', --NewCode  
            @Batch_ID,  
            GETUTCDATE(),  
            @User_ID,  
            GETUTCDATE(),  
            @User_ID  
        FROM #TRANLOG  
        WHERE MemberID IS NOT NULL -- exclude members that were already soft-deleted')  
    END, N'  
    END  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Delete orphaned files.'')  
    -- Delete orphaned files.  
    IF EXISTS(SELECT 1 FROM #FileIDsToDelete)  
    BEGIN  
        DECLARE @File_ID mdm.IdList;  
        INSERT INTO @File_ID  
        SELECT ID   
        FROM #FileIDsToDelete;  
  
        EXEC mdm.udpFilesDelete @File_ID = @File_ID  
    END  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' EXEC mdm.udpSecurityMemberProcessRebuildModelVersion @Version_ID, 1'')  
    EXEC mdm.udpSecurityMemberProcessRebuildModelVersion @Version_ID, 1;  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Update the status after the delete (soft delete) and the purge (hard delete)'')  
    --Update the status after the delete (soft delete) and the purge (hard delete)  
    UPDATE [stg].', @StagingLeafTable, N'  
    SET ImportStatus_ID = ', @StatusOK, N' -- OK  
    WHERE ImportType IN (', @IT_Delete, N', ', @IT_Purge, N', ', @IT_DeleteSetNullToRef, N', ', @IT_PurgeSetNullToRef, N')  
        AND ErrorCode = 0  
        AND Batch_ID = @Batch_ID;  
END -- IF Delete/Purge  
  
  
IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Get the number of errors for the batch ID'')  
--Get the number of errors for the batch ID  
SELECT @ErrorCount = COUNT(ID) FROM [stg].', @StagingLeafTable, N'  
    WHERE Batch_ID = @Batch_ID AND ErrorCode != 0  
  
IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Set the status of the batch as Not Running (Completed).'')  
-- Set the status of the batch as Not Running (Completed).  
-- Set the error member count.  
UPDATE mdm.tblStgBatch  
SET Status_ID = @Completed,  
    LastRunEndDTM = GETUTCDATE(),  
    LastRunEndUserID = @User_ID,  
    ErrorMemberCount = @ErrorCount  
WHERE ID = @Batch_ID  
  
IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' Commit only if not nested'')  
IF @TranCounter = 0 COMMIT TRANSACTION; --Commit only if we are not nested  
  
IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' [stg].', REPLACE(QUOTENAME(N'udp_' + @StagingBase + N'_Leaf'), N'''', N''''''),'  end'')  
RETURN 0;  
  
END TRY  
BEGIN CATCH  
    SET NOCOUNT OFF;  
  
    -- Get error info  
    DECLARE  
        @ErrorMessage NVARCHAR(4000),  
        @ErrorSeverity INT,  
        @ErrorState INT,  
        @ErrorNumber INT,  
        @ErrorLine INT,  
        @ErrorProcedure NVARCHAR(126);  
    EXEC mdm.udpGetErrorInfo  
        @ErrorMessage = @ErrorMessage OUTPUT,  
        @ErrorSeverity = @ErrorSeverity OUTPUT,  
        @ErrorState = @ErrorState OUTPUT,  
        @ErrorNumber = @ErrorNumber OUTPUT,  
        @ErrorLine = @ErrorLine OUTPUT,  
        @ErrorProcedure = @ErrorProcedure OUTPUT  
  
    SET @ErrorMessage = CONCAT(@ErrorMessage, N'', @ErrorNumber = '', @ErrorNumber, N'', @ErrorProcedure = "'', @ErrorProcedure, N''", line '', @ErrorLine);  
  
    IF @TranCounter = 0 ROLLBACK TRANSACTION;  
    ELSE IF XACT_STATE() <> -1 ROLLBACK TRANSACTION TX;  
  
    RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), '' [stg].', REPLACE(QUOTENAME(N'udp_' + @StagingBase + N'_Leaf'), N'''', N''''''),'  end'')  
    RETURN @OtherRuntimeError;  
END CATCH  
SET NOCOUNT OFF;  
END;')  
    --SELECT @SQL AS [processing-instruction(x)] FOR XML PATH('');  
    EXEC sp_executesql @SQL;  
  
    SET NOCOUNT OFF;  
END; --proc
go

