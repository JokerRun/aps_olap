/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
/*  
--This can be called to delete Annotations for a transaction  
EXEC udpAnnotationDelete 7, 1  
*/  
CREATE PROCEDURE mdm.udpAnnotationDelete  
(  
    @Model_ID       INT,  
    @AnnotationID	INT	,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    DECLARE @AnnotationTableName    sysname,  
            @SQL                    NVARCHAR(MAX);  
  
    SET @AnnotationTableName = mdm.udfGetTransactionAnnotationTableName(@Model_ID);  
  
    --Delete the annotation  
    SET @SQL = N'DELETE FROM [mdm].' + QUOTENAME(@AnnotationTableName) + N' WHERE ID = @AnnotationID';  
    EXEC sp_executesql @SQL, N'@AnnotationID INT', @AnnotationID;  
  
END --proc
go

