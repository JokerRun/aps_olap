/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Returns the member permissions that apply to the given principal, optionally  
including permissions inherited from groups.  
  
SELECT * FROM mdm.udfSecurityUserExplicitMemberPermissions(1,2,1,0)  
SELECT * FROM mdm.udfSecurityUserExplicitMemberPermissions(1,2,1,1) WHERE Entity_ID = 41  
SELECT * FROM mdm.udfSecurityUserExplicitMemberPermissions(1,2,1,1)  
SELECT * FROM mdm.udfSecurityUserExplicitMemberPermissions(1,11,1,1)  
*/  
CREATE FUNCTION mdm.udfSecurityUserExplicitMemberPermissions  
(  
     @SystemUser_ID             INT -- The ID of the user requesting the permission info  
    ,@Principal_ID              INT  
    ,@PrincipalType_ID          INT  
    ,@IncludeGroupAssignments   BIT  
)  
RETURNS @UserPermissions TABLE  
(  
     RoleAccess_ID          INT  
    ,RoleAccess_MUID        UNIQUEIDENTIFIER  
    ,Privilege_ID           TINYINT  
    ,AccessPermission       TINYINT  
    ,Model_ID               INT  
    ,Model_MUID             UNIQUEIDENTIFIER  
    ,Model_Name             NVARCHAR(50) COLLATE DATABASE_DEFAULT  
    ,Version_ID             INT  
    ,Version_MUID           UNIQUEIDENTIFIER  
    ,Version_Name           NVARCHAR(50) COLLATE DATABASE_DEFAULT  
    ,IsModelAdministrator   BIT  
    ,HierarchyType_ID       TINYINT  
    ,Hierarchy_ID           INT  
    ,Hierarchy_MUID         UNIQUEIDENTIFIER  
    ,Hierarchy_Name         NVARCHAR(50) COLLATE DATABASE_DEFAULT  
    ,Entity_ID              INT  
    ,Entity_MUID            UNIQUEIDENTIFIER  
    ,Entity_Name            NVARCHAR(MAX) COLLATE DATABASE_DEFAULT  
    ,MemberType_ID          TINYINT  
    ,Member_ID              INT  
    ,PrincipalType_ID       TINYINT  
    ,Principal_ID           INT  
    ,Principal_MUID         UNIQUEIDENTIFIER  
    ,Principal_Name         NVARCHAR(355) COLLATE DATABASE_DEFAULT  
    ,EnterUserID            INT  
    ,EnterUserMUID          UNIQUEIDENTIFIER  
    ,EnterUser              NVARCHAR(256) COLLATE DATABASE_DEFAULT  
    ,EnterDTM               DATETIME2(3)  
    ,LastChgUserID          INT  
    ,LastChgUserMUID        UNIQUEIDENTIFIER  
    ,LastChgUser            NVARCHAR(256) COLLATE DATABASE_DEFAULT  
    ,LastChgDTM             DATETIME2(3)  
)  
/*WITH SCHEMABINDING*/  
AS BEGIN  
  
    DECLARE  
         @PrincipalType_User    TINYINT = 1  
        ,@PrincipalType_Group   TINYINT = 2  
        ,@Privilege_Deny        TINYINT = 1;  
  
    -- Explicit Object permissions  
    INSERT INTO @UserPermissions  
    SELECT  
         rac.RoleAccess_ID  
        ,rac.RoleAccess_MUID  
        ,rac.Privilege_ID  
        ,rac.AccessPermission  
        ,rac.Model_ID  
        ,rac.Model_MUID  
        ,rac.Model_Name  
        ,rac.Version_ID  
        ,rac.Version_MUID  
        ,rac.Version_Name  
        ,rac.IsModelAdministrator  
        ,rac.HierarchyType_ID  
        ,rac.Hierarchy_ID  
        ,rac.Hierarchy_MUID  
        ,rac.Hierarchy_Name  
        ,rac.Entity_ID  
        ,rac.Entity_MUID  
        ,rac.Entity_Name  
        ,rac.MemberType_ID  
        ,rac.Member_ID  
        ,rac.PrincipalType_ID  
        ,rac.Principal_ID  
        ,rac.Principal_MUID  
        ,rac.Principal_Name  
        ,rac.EnterUserID  
        ,rac.EnterUserMUID  
        ,rac.EnterUser  
        ,rac.EnterDTM  
        ,rac.LastChgUserID  
        ,rac.LastChgUserMUID  
        ,rac.LastChgUser  
        ,rac.LastChgDTM  
    FROM mdm.viw_SYSTEM_SECURITY_ROLE_ACCESSCONTROL_MEMBER rac  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_MODEL modSec  
    ON      rac.Model_ID = modSec.ID  
    WHERE   modSec.User_ID = @SystemUser_ID  
        AND (modSec.Privilege_ID = 5 /*Admin*/                              -- User must be a model admin to see another user's permission on the model.  
             OR (   @SystemUser_ID = @Principal_ID                          -- User can see his own permissions (except Deny)  
                AND @PrincipalType_ID = @PrincipalType_User  
                AND COALESCE(rac.Privilege_ID, @Privilege_Deny) <> @Privilege_Deny))  
        AND rac.PrincipalType_ID = @PrincipalType_ID  
        AND rac.Principal_ID = @Principal_ID  
  
    IF (@PrincipalType_ID = @PrincipalType_User) AND (COALESCE(@IncludeGroupAssignments, 0) = 1)  
    BEGIN  
        -- Explicit permissions inherited from group assignments  
        INSERT INTO @UserPermissions  
        SELECT  
             rac.RoleAccess_ID  
            ,rac.RoleAccess_MUID  
            ,rac.Privilege_ID  
            ,rac.AccessPermission  
            ,rac.Model_ID  
            ,rac.Model_MUID  
            ,rac.Model_Name  
            ,rac.Version_ID  
            ,rac.Version_MUID  
            ,rac.Version_Name  
            ,rac.IsModelAdministrator  
            ,rac.HierarchyType_ID  
            ,rac.Hierarchy_ID  
            ,rac.Hierarchy_MUID  
            ,rac.Hierarchy_Name  
            ,rac.Entity_ID  
            ,rac.Entity_MUID  
            ,rac.Entity_Name  
            ,rac.MemberType_ID  
            ,rac.Member_ID  
            ,rac.PrincipalType_ID  
            ,rac.Principal_ID  
            ,rac.Principal_MUID  
            ,rac.Principal_Name  
            ,rac.EnterUserID  
            ,rac.EnterUserMUID  
            ,rac.EnterUser  
            ,rac.EnterDTM  
            ,rac.LastChgUserID  
            ,rac.LastChgUserMUID  
            ,rac.LastChgUser  
            ,rac.LastChgDTM  
        FROM mdm.viw_SYSTEM_SECURITY_ROLE_ACCESSCONTROL_MEMBER rac  
        INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ROLE sur  
        ON      rac.Role_ID = sur.Role_ID  
            AND sur.User_ID = @Principal_ID  
        INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_MODEL modSec  
        ON      rac.Model_ID = modSec.ID  
        WHERE   modSec.User_ID = @SystemUser_ID  
            AND (modSec.Privilege_ID = 5 /*Admin*/                              -- User must be a model admin to see another user's permission on the model.  
                 OR (   @SystemUser_ID = @Principal_ID                          -- User can see his own permissions (except Deny)  
                    AND @PrincipalType_ID = @PrincipalType_User  
                    AND COALESCE(rac.Privilege_ID, @Privilege_Deny) <> @Privilege_Deny))  
            AND rac.PrincipalType_ID = @PrincipalType_Group  
    END  
  
    RETURN  
END --fn
go

