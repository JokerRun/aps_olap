/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    --Con  
    DECLARE @RC int;  
    EXECUTE @RC = mdm.udpMemberCopy @User_ID=1, @Version_ID=4, @Entity_ID=7,@SourceMemberCode='10',@DestinationMemberCode='10_NEW'  
    SELECT @RC;  
  
    --Leaf  
    DECLARE @RC int;  
    EXECUTE @RC = mdm.udpMemberCopy @User_ID=1, @Version_ID=4, @Entity_ID=7,@SourceMemberCode='1110',@DestinationMemberCode='1110_NEW'  
    SELECT @RC;  
  
    --Invalid - Source does NOT exist  
    EXECUTE mdm.udpMemberCopy @User_ID=1, @Version_ID=4, @Entity_ID=7,@SourceMemberCode='KABOOM',@DestinationMemberCode='1110_NEW'  
  
    --Invalid - Destination DEOS NOT exist  
    EXECUTE mdm.udpMemberCopy @User_ID=1, @Version_ID=4, @Entity_ID=7,@SourceMemberCode='1110',@DestinationMemberCode='1110'  
*/  
  
CREATE PROCEDURE mdm.udpMemberCopy  
(  
    @User_ID                INT,  
    @Version_ID             INT,  
    @Entity_ID              INT,  
    @SourceMemberCode       NVARCHAR(250),  
    @DestinationMemberCode  NVARCHAR(250),  
    @CorrelationID          UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE  
         @VersionStatus_NotSpecified    TINYINT = 0  
        ,@VersionStatus_Open            TINYINT = 1  
        ,@VersionStatus_Locked          TINYINT = 2  
        ,@VersionStatus_Committed       TINYINT = 3  
  
        ,@Permission_Admin              INT = 5  
  
        ,@ModelPermission       TINYINT  
        ,@VersionStatus         TINYINT  
        ,@MemberType_ID         TINYINT  
        ,@MemberType_Consolidated   TINYINT = 2  
        ,@Member_ID             INT  
        ,@NewMember_ID          INT  
        ,@ParentMember_ID       INT  
        ,@Hierarchy_ID          INT  
        ,@TempHierarchy_ID      INT  
        ,@AttributeName         NVARCHAR(250)  
        ,@AttributeValue        NVARCHAR(2000)  
        ,@ActiveCodeExists      BIT = 0  
        ,@DeactivatedCodeExists BIT = 0;  
  
    DECLARE @TempAttributeTable TABLE([Name] NVARCHAR(250) COLLATE database_default,  
                                       SortOrder INT)  
    DECLARE    @TempHierarchyTable TABLE(ID INT)  
  
    SELECT   
         @VersionStatus = mv.Status_ID  
        ,@ModelPermission = m.Privilege_ID  
    FROM mdm.tblModelVersion mv  
    LEFT JOIN mdm.viw_SYSTEM_SECURITY_USER_MODEL m  
    ON      mv.Model_ID = m.ID  
        AND m.User_ID = @User_ID  
    WHERE mv.ID = @Version_ID  
  
    IF @VersionStatus = @VersionStatus_Committed  
        OR (@VersionStatus = @VersionStatus_Locked AND @ModelPermission <> @Permission_Admin)  
    BEGIN  
        RAISERROR('MDSERR300012|The version is read-only. You do not have permission to update the version.', 16, 1);  
        RETURN;  
    END  
  
    -- Verify the entity version is not a sync target.  
    IF EXISTS(SELECT 1 FROM mdm.tblSyncRelationship  
              WHERE TargetEntity_ID = @Entity_ID  
                AND TargetVersion_ID = @Version_ID)  
    BEGIN  
        RAISERROR('MDSERR200220|The entity member(s) cannot be saved. The entity version is the target of a sync relationship.', 16, 1);  
        RETURN;  
    END  
  
    --Check the source code to make sure it EXISTS  
    SET @ActiveCodeExists = 0;  
    SET @DeactivatedCodeExists = 0;  
    EXEC mdm.udpMemberCodeCheck @Version_ID, @Entity_ID, @SourceMemberCode, @ActiveCodeExists OUTPUT, @DeactivatedCodeExists OUTPUT;  
    IF @ActiveCodeExists = 0 --Invalid  
    BEGIN  
        RAISERROR('MDSERR300002|Error - The member code is not valid.', 16, 1);  
        RETURN(1);  
    END  
  
    --Check the destination code to make sure it DOES NOT exist  
    SET @ActiveCodeExists = 0;  
    SET @DeactivatedCodeExists = 0;  
    EXEC mdm.udpMemberCodeCheck @Version_ID, @Entity_ID, @DestinationMemberCode, @ActiveCodeExists OUTPUT, @DeactivatedCodeExists OUTPUT;  
    IF @ActiveCodeExists = 1 --Exists  
    BEGIN  
        RAISERROR('MDSERR300003|The member code already exists.', 16, 1);  
        RETURN(1);  
    END  
  
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED  
    BEGIN TRAN  
  
    -- Get the MemberType_ID and ID from the existing Code  
    EXEC mdm.udpMemberTypeIDAndIDGetByCode @Version_ID,@Entity_ID,@SourceMemberCode,@MemberType_ID OUTPUT,@Member_ID OUTPUT  
  
    --If consolidated, get the Hierarchy for the existing member, else NULL  
    IF @MemberType_ID = @MemberType_Consolidated  
    BEGIN  
        EXECUTE mdm.udpHierarchyIDGetByMemberID @Version_ID,@Entity_ID,@Member_ID,@MemberType_ID,0,@Hierarchy_ID OUTPUT  
    END  
    ELSE  
    BEGIN  
        SET @Hierarchy_ID = NULL  
    END  
  
    --Create the new member and get the ID  
    EXEC mdm.udpMemberCreate @User_ID,@Version_ID,@Hierarchy_ID,@Entity_ID,@MemberType_ID,'',@DestinationMemberCode, @NewMember_ID OUTPUT  
  
    --Get the List of Attributes that the user has security for  
    INSERT INTO @TempAttributeTable  
    SELECT  
        a.Name AS AttributeName,  
        a.SortOrder  
    FROM mdm.viw_SYSTEM_SECURITY_USER_ATTRIBUTE atSec  
    INNER JOIN mdm.tblAttribute a  
    ON atSec.ID = a.ID  
    WHERE atSec.User_ID = @User_ID  
        AND a.Entity_ID = @Entity_ID  
        AND a.MemberType_ID = @MemberType_ID  
        AND(a.IsSystem = 0  
            OR a.[Name] = N'Name')  
    ORDER BY a.SortOrder ASC  
  
    WHILE EXISTS(SELECT 1 FROM @TempAttributeTable)  
    BEGIN  
  
        SELECT TOP 1 @AttributeName = [Name] FROM @TempAttributeTable ORDER BY SortOrder;  
  
        --Get the value for the selected attribute for the source member  
        EXECUTE mdm.udpMemberAttributeGet @Version_ID,@Entity_ID,@Member_ID,@MemberType_ID,@AttributeName,@AttributeValue OUTPUT  
  
        --Set the value for the selected attribute for the new member  
        EXECUTE mdm.udpMemberAttributeSave @User_ID,@Version_ID,@Entity_ID,NULL,@NewMember_ID,@MemberType_ID,@AttributeName,@AttributeValue,NULL  
  
        DELETE FROM @TempAttributeTable WHERE [Name] = @AttributeName;  
    END; --while  
  
    --Get a list of Hierarchies for the Entity  
    INSERT INTO @TempHierarchyTable SELECT ID FROM tblHierarchy WHERE Entity_ID=@Entity_ID ORDER BY ID  
    WHILE EXISTS(SELECT 1 FROM @TempHierarchyTable)  
    BEGIN  
        SELECT TOP 1 @TempHierarchy_ID=ID FROM @TempHierarchyTable ORDER BY ID  
  
        --Get the parent for the selected hierachy for the new member  
        EXECUTE mdm.udpHierarchyParentIDGet @Version_ID,@TempHierarchy_ID,@Entity_ID,@Member_ID,@MemberType_ID,@ParentMember_ID OUTPUT  
  
        --Set the parent for the selected hierachy for the new member  
        IF (@ParentMember_ID > 0) --Do nothing if there is no parent  
        BEGIN  
            -- Lookup the parent member code from the ID.  
            DECLARE  
                @ParentMemberType_ID TINYINT = 2/*Consolidated*/,  
                @ParentMemberCode NVARCHAR(250);  
            EXECUTE mdm.udpMemberCodeGetByID @Version_ID=@Version_ID, @Entity_ID=@Entity_ID, @Member_ID=@ParentMember_ID, @MemberType_ID=@ParentMemberType_ID, @ReturnCode=@ParentMemberCode OUTPUT;  
  
            DECLARE @HierarchyMembers AS mdm.HierarchyMembers  
            INSERT INTO @HierarchyMembers  
                (Hierarchy_ID,      Child_ID,      ChildCode,              ChildMemberType_ID, Target_ID,        TargetCode,        TargetMemberType_ID,  TargetType_ID) VALUES  
                (@TempHierarchy_ID, @NewMember_ID, @DestinationMemberCode, @MemberType_ID,     @ParentMember_ID, @ParentMemberCode, @ParentMemberType_ID, 1/*Parent*/);  
  
            EXECUTE mdm.udpHierarchyMembersUpdate @User_ID=@User_ID, @Version_ID=@Version_ID, @Entity_ID=@Entity_ID, @HierarchyMembers=@HierarchyMembers, @LogFlag=1;  
        END  
  
        DELETE FROM @TempHierarchyTable WHERE ID = @TempHierarchy_ID;  
    END; --while  
  
  
    IF (@@ERROR <> 0) BEGIN  
        RAISERROR('MDSERR500052|The entity member cannot be copied.', 16, 1);  
        ROLLBACK TRAN;  
        RETURN(1);  
    END    ELSE BEGIN  
        COMMIT TRAN;  
        RETURN(0);  
    END; --if  
  
    SET NOCOUNT OFF;  
END; --proc
go

