/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Gets the effective (overlapping user and group permissions are combined) permissions   
of the given user.  
  
EXEC mdm.udpSecurityPrivilegesFunctionGetEffective 11  
  
*/  
CREATE PROCEDURE mdm.udpSecurityPrivilegesFunctionGetEffective  
(  
    @User_ID INT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE @PrincipalType_Group TINYINT = 2;  
  
    SELECT DISTINCT   
         RoleAccess_ID  
        ,RoleAccess_MUID  
  
        ,Principal_ID  
        ,Principal_MUID  
        ,PrincipalType_ID  
        ,Principal_Name  
  
        ,Function_ID  
        ,Function_Name + CASE WHEN PrincipalType_ID = @PrincipalType_Group THEN N' *' ELSE N'' END Function_Name  
  
        -- Audit info  
        ,EnterDTM  
        ,EnterUserID  
        ,EnterUserMUID  
        ,EnterUserName  
        ,LastChgDTM  
        ,LastChgUserID  
        ,LastChgUserMUID  
        ,LastChgUserName  
    FROM   
        mdm.udfSecurityUserFunctionList(@User_ID)  
    ORDER BY Function_ID  
  
    SET NOCOUNT OFF;  
END
go

