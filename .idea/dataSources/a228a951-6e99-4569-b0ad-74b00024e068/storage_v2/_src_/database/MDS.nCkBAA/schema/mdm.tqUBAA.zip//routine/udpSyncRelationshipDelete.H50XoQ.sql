/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Removes a sync relationship that targets the given entity version. This makes the master data of that version writable.   
The entity metadata is also becomes writable if there are no other sync relationships pertaining to other versions   
of the target entity.  
*/  
CREATE PROCEDURE mdm.udpSyncRelationshipDelete  
(  
     @User_ID               INT -- Must have admin permission on the target model and Sys Admin functional permission.  
    ,@TargetModel_MUID      UNIQUEIDENTIFIER = NULL -- Target Model name and/or muid is required.  
    ,@TargetModelName       NVARCHAR(50) = NULL  
    ,@TargetVersion_MUID    UNIQUEIDENTIFIER = NULL -- Target Version name and/or muid is required.  
    ,@TargetVersionName     NVARCHAR(50) = NULL  
    ,@TargetVersion_ID      INT = NULL -- for internal use only  
    ,@TargetEntity_MUID     UNIQUEIDENTIFIER = NULL -- when NULL, a random MUID will be generated  
    ,@TargetEntityName      NVARCHAR(50) = NULL -- when NULL, the target entity will have the same name as the source entity.  
    ,@TargetEntity_ID       INT = NULL -- for internal use only  
    ,@IsVersionOrEntityDelete  BIT = 0 -- Should only be set to 1 when being called from udpVersionDelete or udpEntityDelete. Causes the sproc to skip target entity permission checks.  
    ,@CorrelationID         UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS  
BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE   
         @TargetModel_ID    INT  
        ,@TargetEntity_EN_TableName sysname  
  
        ,@PermissionType_Deny           TINYINT = 1  
        ,@PermissionType_Admin          TINYINT = 5  
  
        ,@FunctionalPrivilege_SysAdmin  TINYINT = 5  
    ;  
    -- Ensure the user has Sys Admin functional permissions (can modify metadata)  
    IF @IsVersionOrEntityDelete = 0 -- when deleting the source/target entity or version, the appropriate permissions will have already been checked at this point.  
    BEGIN  
        SET @TargetVersion_ID = NULL;  
        SET @TargetEntity_ID = NULL;  
  
        IF mdm.udfSecurityUserFunctionIsAllowed(@User_ID, @FunctionalPrivilege_SysAdmin) = 0  
        BEGIN   
            RAISERROR('MDSERR120002|The user does not have permission to perform this operation.', 16, 1);  
            RETURN;  
        END  
  
        -- Lookup target model ID and verify user is model admin  
        DECLARE @TargetModelPrivilege_ID TINYINT  
        EXEC mdm.udpInformationLookupModel @User_ID = @User_ID, @Model_MUID = @TargetModel_MUID, @Model_Name = @TargetModelName, @ID = @TargetModel_ID OUTPUT, @Privilege_ID = @TargetModelPrivilege_ID OUTPUT;  
        IF COALESCE(@TargetModelPrivilege_ID, @PermissionType_Deny) <> @PermissionType_Admin  
        BEGIN  
            SET @TargetModel_ID = NULL;  
        END  
  
        IF @TargetModel_ID IS NULL   
        BEGIN  
            -- Either the model doesn't exist, or the user doesn't have permission to see it.  
            RAISERROR('MDSERR200204|Sync target model ID is not valid or the user does not have sufficient permission.', 16, 1);  
            RETURN;  
        END;  
  
        -- Lookup target version ID. Note: not using udpInformationLookupVersion to avoid needlessly querying the model security view again.  
        SELECT @TargetVersion_ID = ID  
        FROM mdm.tblModelVersion   
        WHERE  
                (@TargetVersion_MUID IS NOT NULL OR @TargetVersionName IS NOT NULL)   
            AND (@TargetVersion_MUID IS NULL OR MUID = @TargetVersion_MUID)   
            AND (@TargetVersionName IS NULL OR Name = @TargetVersionName)  
            AND Model_ID = @TargetModel_ID;  
  
        -- Lookup target entity ID. Note: not using udpInformationLookupEntity to avoid needlessly querying the model security view again.  
        SELECT   
             @TargetEntity_ID = ID  
            ,@TargetEntity_EN_TableName = e.EntityTable  
        FROM mdm.tblEntity e  
        WHERE  
                (@TargetEntity_MUID IS NOT NULL OR @TargetEntityName IS NOT NULL)   
            AND (@TargetEntity_MUID IS NULL OR MUID = @TargetEntity_MUID)   
            AND (@TargetEntityName IS NULL OR Name = @TargetEntityName)  
            AND Model_ID = @TargetModel_ID;  
    END ELSE  
    BEGIN  
        -- When deleting a version or entity, the entity ID will be passed in directly. Use it to look up the entity table name.  
        SELECT @TargetEntity_EN_TableName = EntityTable  
        FROM mdm.tblEntity  
        WHERE ID = @TargetEntity_ID;  
    END  
  
    IF @TargetVersion_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR200205|Sync target version ID is not valid.', 16, 1);  
        RETURN;  
    END;  
    IF @TargetEntity_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR200209|Sync target entity ID is not valid.', 16, 1);  
        RETURN;  
    END;  
  
PRINT CONCAT(SYSDATETIME(), N': Deleting sync relationship @TargetVersion_ID = ', @TargetVersion_ID, N', @TargetEntity_ID = ', @TargetEntity_ID);  
  
  
    --Start transaction, being careful to check if we are nested  
    DECLARE @TranCounter INT = @@TRANCOUNT;  
    IF @TranCounter > 0 SAVE TRANSACTION TX;  
    ELSE BEGIN TRANSACTION;  
  
    BEGIN TRY  
  
        DELETE FROM mdm.tblSyncRelationship  
        WHERE   TargetVersion_ID = @TargetVersion_ID  
            AND TargetEntity_ID  = @TargetEntity_ID  
  
        DECLARE   
             @Source_IDColumnName SYSNAME = N'Source_ID'  
            ,@Source_LastChgTSColumnName SYSNAME = N'Source_LastChgTS'  
            ,@SQL NVARCHAR(MAX);  
  
        IF EXISTS (SELECT 1 FROM mdm.tblSyncRelationship WHERE TargetEntity_ID  = @TargetEntity_ID)  
        BEGIN  
            -- At least one other version of the entity is a sync target.  
  
            -- Clear out the Source_ID column for the specified target version (EN table only. Leave the metadata tables)  
            SET @SQL = CONCAT(N'  
UPDATE mdm.', QUOTENAME(@TargetEntity_EN_TableName), N'  
SET ', QUOTENAME(@Source_IDColumnName), ' = NULL  
    ,', QUOTENAME(@Source_LastChgTSColumnName), N' = NULL  
WHERE Version_ID = @TargetVersion_ID');  
            EXEC sp_executesql @SQL, N'@TargetVersion_ID INT', @TargetVersion_ID;;  
        END ELSE  
        BEGIN  
            -- No other versions of the entity is a sync target.  
  
            -- Clear the metadata tables' Source_ID columns  
            UPDATE mdm.tblAttribute  
            SET  Source_ID = NULL  
                ,Source_LastChgTS = NULL  
            WHERE Entity_ID = @TargetEntity_ID  
  
            --UPDATE agd  
            --SET agd.Source_ID = NULL  
            --FROM mdm.tblAttributeGroupDetail agd  
            --INNER JOIN mdm.tblAttributeGroup ag  
            --ON agd.AttributeGroup_ID = ag.ID  
            --WHERE ag.Entity_ID = @TargetEntity_ID  
  
            --UPDATE mdm.tblAttributeGroup  
            --SET Source_ID = NULL  
            --FROM mdm.tblAttributeGroup  
            --WHERE Entity_ID = @TargetEntity_ID  
  
            -- Drop the Source_ID column from the EN table if it exists (idempotency means the column might have already been deleted)  
            DECLARE @Table_ID INT = (SELECT object_id FROM sys.tables WHERE name = @TargetEntity_EN_TableName and schema_id = schema_id('mdm'))  
            IF EXISTS(  SELECT 1 FROM sys.columns c  
                        WHERE name = @Source_IDColumnName  
                        AND c.object_id = @Table_ID)  
            BEGIN  
                DECLARE @Source_IDIndexName sysname = CONCAT('ix_', @TargetEntity_EN_TableName, N'_Version_ID_', @Source_IDColumnName, N'_', @Source_LastChgTSColumnName);  
                SET @SQL = CONCAT(N'  
DROP INDEX ', QUOTENAME(@Source_IDIndexName), N' ON mdm.', QUOTENAME(@TargetEntity_EN_TableName), N';  
ALTER TABLE mdm.', QUOTENAME(@TargetEntity_EN_TableName), N' DROP COLUMN ', QUOTENAME(@Source_IDColumnName), N';  
ALTER TABLE mdm.', QUOTENAME(@TargetEntity_EN_TableName), N' DROP COLUMN ', QUOTENAME(@Source_LastChgTSColumnName), N';'  
);  
  
                EXEC sp_executesql @SQL;  
            END;  
  
        END;  
  
        --Commit only if we are not nested  
        IF @TranCounter = 0 COMMIT TRANSACTION;  
  
    END TRY  
    --Compensate as necessary  
    BEGIN CATCH  
  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        IF @TranCounter = 0 ROLLBACK TRANSACTION;  
        ELSE IF XACT_STATE() <> -1 ROLLBACK TRANSACTION TX;  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
    END CATCH;  
  
    SET NOCOUNT OFF;  
END -- Proc
go

