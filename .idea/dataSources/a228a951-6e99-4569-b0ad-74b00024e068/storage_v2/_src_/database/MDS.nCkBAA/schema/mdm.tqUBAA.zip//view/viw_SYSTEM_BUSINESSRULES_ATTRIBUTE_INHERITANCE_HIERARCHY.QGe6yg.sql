/*  
  
     SELECT * FROM mdm.viw_SYSTEM_BUSINESSRULES_ATTRIBUTE_INHERITANCE_HIERARCHY WHERE ParentEntityID = 81  
     SELECT * FROM mdm.viw_SYSTEM_BUSINESSRULES_ATTRIBUTE_INHERITANCE_HIERARCHY WHERE ParentEntityID = 80  
     SELECT * FROM mdm.viw_SYSTEM_BUSINESSRULES_ATTRIBUTE_INHERITANCE_HIERARCHY WHERE ParentEntityID = 79  
     SELECT * FROM mdm.viw_SYSTEM_BUSINESSRULES_ATTRIBUTE_INHERITANCE_HIERARCHY WHERE ParentEntityID = 78  
     SELECT * FROM mdm.viw_SYSTEM_BUSINESSRULES_ATTRIBUTE_INHERITANCE_HIERARCHY WHERE ParentModelID = 9  
*/  
/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE VIEW mdm.viw_SYSTEM_BUSINESSRULES_ATTRIBUTE_INHERITANCE_HIERARCHY  
/*WITH SCHEMABINDING*/  
AS  
  
SELECT  
        a.Model_ID AS ParentModelID,  
        a.Attribute_Entity_ID AS ParentEntityID,  
        a.Attribute_Entity_Name AS ParentEntityName,  
        a.Attribute_Name AS ParentAttributeName,  
        a.Attribute_Column AS ParentAttributeColumnName,  
        dba.Attribute_Entity_ID ChildEntityID,  
        dba.Attribute_Entity_Name AS ChildEntityName,  
        dba.Attribute_Name AS ChildAttributeName,  
        dba.Attribute_Column AS ChildAttributeColumnName,  
        a.Attribute_MemberType_ID  
FROM    mdm.viw_SYSTEM_SCHEMA_BUSINESSRULE_PROPERTIES_ATTRIBUTES a  
        INNER JOIN mdm.viw_SYSTEM_SCHEMA_BUSINESSRULE_PROPERTIES_ATTRIBUTES dba  
            ON a.PropertyType_ID = 2  
            AND a.Property_IsLeftHandSide = 0  
            AND dba.PropertyType_ID = 4 -- DBA attribute  
            AND a.Property_Parent_ID = dba.Property_ID  
            AND a.BusinessRule_Status = 1 -- Active  
        INNER JOIN mdm.viw_SYSTEM_SCHEMA_BUSINESSRULE_ITEMTYPES itm  
            ON itm.BRSubTypeID = 3 -- Change value (Equals, Equals concatenated)  
            AND a.Item_AppliesTo_ID = itm.AppliesTo_ID
go

