/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
*/  
CREATE PROCEDURE mdm.udpNotificationQueueProcess  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE  
         @databaseMailProfileName       SYSNAME  
        ,@LocalizedEmailSubject         NVARCHAR(255) = N'MDS Notification'  
        ,@LocalizedTruncatedMessage     NVARCHAR(MAX) = N'This list of issues is truncated at {0} lines when sent by email.  {1} issues have been truncated.'  
        ,@CurrentLanguageCode           INT = 1033 -- Default language code is English (US).  
        ,@StringLanguageCode            NVARCHAR(MAX) = N''  
  
    --Load Database Profile name to use from config.  
    SET @databaseMailProfileName = CONVERT(SYSNAME, mdm.udfSystemSettingGet(N'DatabaseMailProfile'));  
    SET @databaseMailProfileName = NULLIF(LTRIM(RTRIM(@databaseMailProfileName)), N'')  
    IF @databaseMailProfileName IS NULL  
    BEGIN  
        RETURN;  
    END  
  
    -- Use default language code to get the notification language code.  
    SET @StringLanguageCode = mdm.udfLocalizedStringGet(N'NotificationLCID', @CurrentLanguageCode, 1033);  
  
    IF @StringLanguageCode <> N''  
    BEGIN  
        SET @CurrentLanguageCode = CONVERT(INT, @StringLanguageCode)  
    END; -- if  
  
    -- Get the localized message texts based on the notification language code in tblLocalizedStrings.  
    SET @LocalizedEmailSubject = CONVERT(NVARCHAR(255), mdm.udfLocalizedStringGet(N'NotificationSubject', @CurrentLanguageCode, @LocalizedEmailSubject));  
    SET @LocalizedTruncatedMessage = mdm.udfLocalizedStringGet(N'NotificationTruncatedMessage', @CurrentLanguageCode, @LocalizedTruncatedMessage);  
      
    --Get the notifications  
    DECLARE @Notifications TABLE (  
            RowNumber INT IDENTITY(1,1) NOT NULL  
        ,ID INT  
        ,NotificationType_ID INT  
        ,[Message] NVARCHAR(MAX) COLLATE database_default  
        ,[User_ID] INT  
        ,EmailAddress NVARCHAR(MAX) COLLATE database_default  
        ,EmailFormat INT  
        ,DefaultEmailFormat INT  
        );  
  
    DECLARE @NotificationTypes TABLE(  
            RowNumber INT IDENTITY(1,1) NOT NULL  
        ,NotificationType_ID INT  
        ,EmailType INT  
        ,EmailAddress VARCHAR(MAX) COLLATE database_default -- can't use NVARCHAR  
        ,User_ID INT  
    );  
  
    INSERT INTO @Notifications EXECUTE mdm.udpNotificationsGet  
  
    --Get distinct list of notification types and users from the list of notifications  
    INSERT INTO @NotificationTypes  
    SELECT DISTINCT  
        NotificationType_ID  
        ,COALESCE(EmailFormat, DefaultEmailFormat)  
        ,EmailAddress  
        ,User_ID  
    FROM @Notifications  
  
    --Load Notifications per email limit from config.  
    DECLARE @NotificationsPerEmail INT = CONVERT(INT, mdm.udfSystemSettingGet(N'NotificationsPerEmail'));  
    SET @NotificationsPerEmail =  
        CASE  
            WHEN COALESCE(@NotificationsPerEmail, 0) < 1 THEN 100 --Protect against NULL, zero and negative values  
            ELSE @NotificationsPerEmail  
        END  
  
    DECLARE @Counter INT = 1;  
    DECLARE @MaxCounter INT = (SELECT MAX(RowNumber) FROM @NotificationTypes);  
  
    -- Loop through the distinct list of notification types and users to email a batched list of notifications  
    WHILE @Counter <= @MaxCounter  
    BEGIN  
        DECLARE @EmailAddress   VARCHAR(MAX), -- can't be NVARCHAR  
                @StyleSheetName NVARCHAR(100),  
  
                @EmailType      INT,  
                @HtmlEmailType  INT = 1,  
                @TextEmailType  INT = 2,  
  
                @NotificationTypeID                     INT,  
                @ValidationIssuesNotificationType       INT = 1,  
                @VersionStatusChangeNotificationType    INT = 2,  
                @ChangesetStatusChangeNotificationType  INT = 3,  
  
                @EmailSubject   NVARCHAR(255),  
                @BodyFormat     VARCHAR(20), -- can't be NVARCHAR  
                @StyleSheet     XML,  
                @MessageData    XML,  
                @NotificationID INT,  
                @EmailBody      NVARCHAR(MAX),  
                @MailId         INT,  
  
                @NotificationElements           NVARCHAR(MAX) = N'',  
                @HeaderElement                  NVARCHAR(MAX) = N'',  
                @TruncationMessageElement       NVARCHAR(MAX) = N'',  
                @LocalizedNotificationTypeName  NVARCHAR(MAX) = N'',  
  
                @UserID                         INT,  
                @NotificationCount              INT,  
                @NotificationTruncationCount    INT,  
                @SendDBMailRet                  INT;  
  
        --Get the vars  
        SELECT  
             @NotificationTypeID = NotificationType_ID  
            ,@EmailAddress = EmailAddress  
            ,@EmailType = EmailType  
            ,@UserID = User_ID  
        FROM @NotificationTypes  
        WHERE RowNumber = @Counter;  
  
        SET @BodyFormat = CASE @EmailType WHEN @HtmlEmailType THEN N'HTML' ELSE N'TEXT' END;  
  
        SET @HeaderElement =  
            CASE @NotificationTypeID  
                WHEN @ValidationIssuesNotificationType THEN mdm.udfNotificationGetValidationIssueHeader()  
                WHEN @VersionStatusChangeNotificationType THEN mdm.udfNotificationGetVersionStatusChangeHeader()  
                WHEN @ChangesetStatusChangeNotificationType THEN mdm.udfNotificationGetChangesetStatusChangeHeader()  
            END;  
  
        SET @LocalizedNotificationTypeName =  
            CASE @NotificationTypeID  
                WHEN @ValidationIssuesNotificationType THEN mdm.udfLocalizedStringGet(N'NotificationValidationIssue', @CurrentLanguageCode, @LocalizedNotificationTypeName)  
                WHEN @VersionStatusChangeNotificationType THEN mdm.udfLocalizedStringGet(N'NotificationVersionStatusChange', @CurrentLanguageCode, @LocalizedNotificationTypeName)  
                WHEN @ChangesetStatusChangeNotificationType THEN mdm.udfLocalizedStringGet(N'NotificationChangesetStatusChange', @CurrentLanguageCode, @LocalizedNotificationTypeName)  
            END;  
  
        SET @StyleSheetName =  
            CASE @NotificationTypeID  
                WHEN @ValidationIssuesNotificationType THEN  
                    CASE @EmailType WHEN @HtmlEmailType THEN N'ValidationIssueHTML' ELSE N'ValidationIssueText' END  
                WHEN @VersionStatusChangeNotificationType THEN  
                    CASE @EmailType WHEN @HtmlEmailType THEN N'VersionStatusChangeHTML' ELSE N'VersionStatusChangeText' END  
                WHEN @ChangesetStatusChangeNotificationType THEN  
                    CASE @EmailType WHEN @HtmlEmailType THEN N'ChangesetStatusChangeHTML' ELSE N'ChangesetStatusChangeText' END  
            END;  
  
        --Get the number of notifications  
        SELECT @NotificationCount = COUNT(*)  
        FROM @Notifications  
        WHERE NotificationType_ID = @NotificationTypeID  
            AND User_ID = @UserID  
  
        -- Check the number of notifications against the email notification limit config.  
        IF @NotificationCount > @NotificationsPerEmail  
        BEGIN  
            SET @NotificationTruncationCount = @NotificationCount - @NotificationsPerEmail  
            -- Replace placeholders in the message.  
            SET @LocalizedTruncatedMessage = REPLACE(@LocalizedTruncatedMessage, N'{0}' , CONVERT(NVARCHAR(20), @NotificationsPerEmail));  
            SET @LocalizedTruncatedMessage = REPLACE(@LocalizedTruncatedMessage, N'{1}' , CONVERT(NVARCHAR(20), @NotificationTruncationCount));  
            -- Add the XML element tags.  
              
            SET @TruncationMessageElement = CONCAT(N'<truncated_message>', (SELECT @LocalizedTruncatedMessage FOR XML PATH('')), N'</truncated_message>')  
        END  
  
        -- Construct the list of notification XML elements for the distinct notification type and user.  
        SELECT TOP(@NotificationsPerEmail)  
            @NotificationElements += [Message]  
        FROM @Notifications  
        WHERE NotificationType_ID = @NotificationTypeID  
            AND User_ID = @UserID  
  
        --Construct XML message data  
        SET @MessageData = CONVERT(XML,N'<root>' + @HeaderElement + N'<notifications>' + @NotificationElements + N'</notifications>' + @TruncationMessageElement + N'</root>');  
  
        --Get XSLT stylesheet  
        SET @StyleSheet = CONVERT(XML, mdm.udfSystemSettingGet(@StyleSheetName));  
  
        --Apply stylesheet to create email body  
        SET @EmailBody = mdq.XmlTransform(@MessageData, @StyleSheet);  
  
        SET @EmailSubject = CONCAT(@LocalizedEmailSubject, N' : ', @LocalizedNotificationTypeName);  
  
        --Send Email  
        EXECUTE @SendDBMailRet = [msdb].[dbo].[sp_send_dbmail]  
            @profile_name = @databaseMailProfileName  
            ,@recipients  = @EmailAddress  
            ,@body        = @EmailBody  
            ,@subject     = @EmailSubject  
            ,@body_format = @BodyFormat  
            ,@mailitem_id = @MailId OUTPUT  
  
        IF @SendDBMailRet = 0  
        BEGIN  
            --Update the SentDTM  
            UPDATE mdm.tblNotificationQueue  
            SET SentDTM = GETUTCDATE()  
            WHERE ID IN  
            (  
                SELECT ID  
                FROM @Notifications  
                WHERE NotificationType_ID = @NotificationTypeID  
                    AND User_ID = @UserID  
            );  
        END  
  
        SET @Counter += 1;  
        --PRINT N'Processed notification ID: ' + CONVERT(NVARCHAR(MAX),@NotificationID);  
    END; --while  
  
    SET NOCOUNT OFF;  
END; --proc
go

