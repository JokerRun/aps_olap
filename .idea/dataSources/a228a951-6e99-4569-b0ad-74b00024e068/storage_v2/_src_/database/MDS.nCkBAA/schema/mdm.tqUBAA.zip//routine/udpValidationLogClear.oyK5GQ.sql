/*  
exec mdm.udpValidationLogClear 7, 3  
  
select * from mdm.tbl_7_VL  
*/  
/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpValidationLogClear  
(  
    @Model_ID   INT,  
	@Version_ID	INT,	  
	@ID			INT = NULL,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
	SET NOCOUNT ON  
  
    IF @Model_ID IS NULL OR NOT EXISTS(SELECT ID FROM mdm.tblModel WHERE ID = @Model_ID)  
    BEGIN  
        --A valid model must be supplied  
        RAISERROR('MDSERR300005|The supplied model is not valid.', 16, 1);   
        RETURN;  
    END;  
  
    DECLARE @ValidationLogTableName sysname,  
            @SQL                    NVARCHAR(MAX);  
  
    SET @ValidationLogTableName = mdm.udfGetValidationLogTableName(@Model_ID);  
  
	IF @ID IS NOT NULL  
		BEGIN  
			SET @SQL = N'  
            DELETE FROM [mdm].' + QUOTENAME(@ValidationLogTableName) + N' WHERE ID = @ID;  
            ';  
            EXEC sp_executesql @SQL, N'@ID INT', @ID;  
		END  
	ELSE  
		BEGIN  
			SET @SQL = N'  
            DELETE FROM mdm.' + QUOTENAME(@ValidationLogTableName) + N' WHERE Version_ID = @Version_ID;  
            ';  
            EXEC sp_executesql @SQL, N'@Version_ID INT', @Version_ID;  
		END  
  
	SET NOCOUNT OFF  
END --proc
go

