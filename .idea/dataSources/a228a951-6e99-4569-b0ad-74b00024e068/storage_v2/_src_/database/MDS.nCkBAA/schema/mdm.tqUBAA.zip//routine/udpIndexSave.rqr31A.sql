/*        
==============================================================================        
 Copyright (c) Microsoft Corporation. All Rights Reserved.        
==============================================================================        
        
    --Create Index        
    DECLARE @Return_ID INT, @Return_MUID UNIQUEIDENTIFIER;        
    --SET @Return_MUID = NEWID(); SELECT @Return_MUID; --Uncomment to test clone operation        
    EXEC mdm.udpIndexSave        
    @User_ID = 1,        
    @ModelName = N'Product',        
    @EntityName = N'Product',        
    @Name = 'Group 2',        
    @EditMode = 0, --Create        
    @Return_ID = @Return_ID OUTPUT,        
    @Return_MUID = @Return_MUID OUTPUT;        
    SELECT @Return_ID, @Return_MUID;        
    SELECT * FROM mdm.tblIndex WHERE ID = @Return_ID;        
        
    --Update Index        
    DECLARE @Return_ID INT, @Return_MUID UNIQUEIDENTIFIER;        
    EXEC mdm.udpIndexSave        
    @User_ID = 1,        
    @ModelName = N'Product',        
    @EntityName = N'Product',       
    @Name = 'Group 2',        
    @EditMode = 1, --Update       
    @Return_ID = @Return_ID OUTPUT,        
    @Return_MUID = @Return_MUID OUTPUT;        
    SELECT @Return_ID, @Return_MUID;        
    SELECT * FROM mdm.tblIndex WHERE ID = @Return_ID;        
*/        
CREATE PROCEDURE mdm.udpIndexSave  
(        
    @User_ID            INT,        
    @Model_ID           INT, -- caller should validate  
    @Entity_ID          INT, -- caller should validate  
    @DataCompression    TINYINT, -- caller should validate  
    @MUID               UNIQUEIDENTIFIER = NULL,        
    @Name               NVARCHAR(50),       
    @IsUnique           BIT = 0,      
    @IndexDetails       mdm.CustomIndexDetail READONLY,        
    @EditMode           TINYINT = 0, --0: Create, 1: Update, 4: Clone, defaults to Create    
    @IsSync             BIT = 0,  
    @Return_ID          INT = NULL OUTPUT,        
    @Return_MUID        UNIQUEIDENTIFIER = NULL OUTPUT,        
    @CorrelationID      UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability        
)        
/*WITH*/        
AS BEGIN        
    SET NOCOUNT ON;        
        
    SET @Return_ID = NULL;        
    SET @Return_MUID = NULL;        
        
        
    DECLARE   
            @CurrentDTM         AS DATETIME2(3),        
            @GuidEmpty          UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER),        
            @EditMode_Create    TINYINT = 0,        
            @EditMode_Update    TINYINT = 1,        
            @EditMode_Clone     TINYINT = 4,        
            @ExistingIndex_MUID UNIQUEIDENTIFIER = NULL,        
            @ExistingIndex_ID   INT = NULL,        
            @ExistingIndexName  NVARCHAR(MAX),        
            @TableOptions       NVARCHAR(MAX) = N'',        
            @IndexOptions       NVARCHAR(MAX) = N'',      
            @TableName          SYSNAME,  
            @SystemIndexName    SYSNAME,        
            @SQL                NVARCHAR(MAX);         
        
    --Initialize output parameters and local variables        
    SELECT        
        @Name = NULLIF(LTRIM(RTRIM(@Name)), N''), --Convert empty @Name to NULL        
        @IsUnique = ISNULL(@IsUnique, 0), --Convert NULL @IsUnique to 0        
        @Return_ID = NULL,        
        @CurrentDTM = GETUTCDATE(),        
        @MUID = NULLIF(@MUID, @GuidEmpty);       
        
    BEGIN TRY        
   
        --Raise an error if we are missing the entity ID        
        IF @Entity_ID IS NULL        
        BEGIN        
            RAISERROR('MDSERR200303|The index cannot be saved. The entity ID is not valid.', 16, 1);        
            RETURN;        
        END;        
  
        --If we are in the Update or Clone mode get the missing pieces of the identifier        
        IF @EditMode IN (@EditMode_Update, @EditMode_Clone)        
        BEGIN        
            --Only use the name if MUID is not available. This is important because we don't want        
            --to look up by name if the name is what the user is trying to update.        
            IF @MUID IS NULL        
            BEGIN        
                SELECT TOP 1  
                    @ExistingIndex_ID =  ID,  
                    @ExistingIndex_MUID = MUID,  
                    @ExistingIndexName = Name  
                FROM mdm.tblIndex  
                WHERE        
                    [Name] = @Name AND  
                    Entity_ID = @Entity_ID;  
            END        
            --Use the Index ID and MUID to look up the full identifier  
            ELSE  
            BEGIN  
                SELECT  
                    @ExistingIndex_ID =  ID,  
                    @ExistingIndex_MUID = MUID,  
                    @ExistingIndexName = Name  
                FROM mdm.tblIndex  
                WHERE  
                    MUID = @MUID AND  
                    Entity_ID = @Entity_ID;  
            END  
        
            --If we are in the Clone mode we need to figure out whether we are creating or updating an index       
            IF @EditMode = @EditMode_Clone        
            BEGIN        
                --If there is no existing index then set the edit mode to Create        
                IF @ExistingIndex_MUID IS NULL AND @ExistingIndex_ID IS NULL        
                BEGIN        
                    SET @EditMode = @EditMode_Create;        
                END        
                --If there is an existing index then set the edit mode to Update        
                ELSE        
                BEGIN        
                    SET @EditMode = @EditMode_Update;        
                    SET @MUID = @ExistingIndex_MUID;        
                END        
            END        
            --If we are in Update mode and could not find a matching existing index we need to raise an error and quit now        
            ELSE IF @EditMode = @EditMode_Update        
            BEGIN        
                IF @ExistingIndex_ID IS NULL OR @ExistingIndex_MUID IS NULL        
                BEGIN        
                    --On error, return NULL results        
                    SELECT @Return_ID = NULL, @Return_MUID = NULL;        
                    RAISERROR('MDSERR110007|The ID is not valid.', 16, 1);        
                    RETURN;        
                END        
                ELSE        
                BEGIN        
                    SET @MUID = @ExistingIndex_MUID;        
                END        
            END        
        END        
        
        --If the edit mode is Create. This code also needs to execute if the user sent in EditMode clone which ended up becoming Create (hence the IF instead of ELSE IF)      
        IF (@EditMode = @EditMode_Create)  
        BEGIN        
            --Set ID to null. We don't care what came in.        
            --SET @ID = NULL;        
        
            --If @MUID is not null then we need to ensure it does not already exist (since this is a create)        
            IF @MUID IS NOT NULL AND EXISTS(SELECT 1 FROM mdm.tblIndex WHERE MUID = @MUID)        
            BEGIN        
                --On error, return NULL results        
                SELECT @Return_ID = NULL, @Return_MUID = NULL;        
                RAISERROR('MDSERR110007|The ID is not valid.', 16, 1);        
                RETURN;        
            END        
        END        
        
        --Test for invalid parameters        
        IF (@Entity_ID IS NULL OR @User_ID IS NULL)        
        BEGIN        
            RAISERROR('MDSERR100010|The Parameters are not valid.', 16, 1);        
            RETURN;        
        END; --if        
        
        --Check the name of the index for duplicates        
        IF EXISTS        
        (        
            SELECT 1   
            FROM mdm.tblIndex  
            WHERE  
                @Name = Name AND  
                (@MUID IS NULL OR MUID <> @MUID) AND  
                Entity_ID = @Entity_ID  
        )        
        BEGIN        
            --On error, return NULL resultsudpSecurityPrivilegesSave        
            SELECT @Return_ID = NULL, @Return_MUID = NULL;        
            RAISERROR('MDSERR110003|The name already exists. Type a different name.', 16, 1);        
            RETURN;        
        END      
      
          
        --Update/Insert Index details        
        IF @EditMode = @EditMode_Update        
        --Update Index    
        BEGIN      
            --we need to get attributes of an index and check to see if the list has been changed or not      
            DECLARE @entityTable SYSNAME;      
            SELECT @entityTable = EntityTable FROM mdm.tblEntity WHERE ID = @Entity_ID;  
            DECLARE @sysIndex INT;      
            SELECT @sysIndex = SysIndex_ID FROM mdm.tblIndex WHERE ID = @ExistingIndex_ID;      
            DECLARE @entityObject_ID INT = OBJECT_ID(N'[mdm].' + QUOTENAME(@entityTable));      
      
            DECLARE @column_ids TABLE      
            (       
                id INT not null      
            )      
            DECLARE @AttributeIDs TABLE      
            (      
                MUID UNIQUEIDENTIFIER not null      
            )      
      
            INSERT INTO @column_ids       
            SELECT DISTINCT ic.column_id       
            FROM sys.indexes AS i       
            INNER JOIN sys.index_columns AS ic       
            ON i.object_id = ic.object_id AND i.index_id = ic.index_id       
            WHERE i.type= 2 and i.object_id = @entityObject_ID AND i.index_id = @sysIndex       
              
            WHILE EXISTS(SELECT 1 FROM @column_ids)   
            BEGIN      
                DECLARE @TempID INT;      
                SELECT TOP 1           
                    @TempID = id         
                FROM @column_ids         
                ORDER BY id ASC;      
      
                DECLARE @TempName sysname = COL_NAME(@entityObject_ID,@TempID);      
      
                INSERT INTO @AttributeIDs      
                SELECT MUID FROM mdm.tblAttribute att WHERE att.TableColumn = @TempName AND (att.IsSystem = 0 OR att.IsCode = 1 OR att.IsName = 1);      
      
                DELETE FROM @column_ids WHERE id = @TempID;      
           
            END --while      
      
            IF EXISTS (SELECT MUID FROM (SELECT DISTINCT(details.MUID) FROM @IndexDetails details UNION ALL SELECT DISTINCT(atr.MUID) from @AttributeIDs atr) data GROUP BY MUID HAVING count(*)!=2)   
                OR (@IsUnique <> (SELECT IsUnique FROM mdm.tblIndex where ID = @ExistingIndex_ID))      
            BEGIN -- the old index should be dropped and new one should be created      
    
                SELECT @SystemIndexName = name from sys.indexes WHERE object_id = @entityObject_ID AND index_id = @sysIndex;  
  
                IF @SystemIndexName IS NOT NULL   
                BEGIN      
                    SET @SQL =  CONCAT(N'DROP INDEX', QUOTENAME(@SystemIndexName),  N'ON mdm.', quotename(@entityTable));      
                    EXEC sp_executesql @SQL;      
                END      
                  
                SET @EditMode = @EditMode_Create  
            END ELSE   
            BEGIN  
                UPDATE mdm.tblIndex   
                SET        
                    [Name] = ISNULL(@Name, [Name]),      
                    [IsUnique] = ISNULL(@IsUnique, [IsUnique]),      
                    LastChgDTM = @CurrentDTM,        
                    LastChgUserID = @User_ID        
                WHERE        
                    ID = @ExistingIndex_ID;  
  
                SET @Return_MUID = @ExistingIndex_MUID  
            END        
        END         
          
        IF @EditMode <> @EditMode_Update          
        --New Index        
        BEGIN        
            --Accept an explicit MUID (for clone operations) or generate a new one        
            SET @Return_MUID = ISNULL(@MUID, NEWID());        
                  
            IF ((SELECT COUNT(*) FROM @IndexDetails) = 0)   
            BEGIN  
                RAISERROR('MDSERR200304| To create or update an index at least one attribute must be selected.', 16, 1);  
                RETURN;      
            END  
  
            DECLARE   
                    @StatusCheck            NVARCHAR(MAX) = N'Where [Status_ID] = 1 ',  
                    @Condition              NVARCHAR(MAX) =N'AND ',  
                    @VersionColumnName      sysname,  
                    @Status_IDColumName     sysname,  
                    @TableColumn            sysname,      
                    @IndexColumns           NVARCHAR(MAX),      
                    @IndexColumnsWithQuote  NVARCHAR(MAX),      
                    @Attribute_ID           INT,  
                    @AttributeName          NVARCHAR(100);  
                  
            SET @TableName = CONCAT(N'tbl_', @Model_ID, N'_', @Entity_ID, N'_', N'EN');      
      
            SET @SystemIndexName = CASE @IsUnique      
                WHEN 1 THEN CONCAT( N'uixud_' , @TableName , N'_Version_ID')      
                ELSE  CONCAT( N'ixud_' , @TableName , N'_Version_ID')      
                END      
              
            SET @IndexOptions = mdm.udfGetIndexOptions(@DataCompression, @Model_ID);  
  
            SET @VersionColumnName = N'Version_ID';  
            SET @Status_IDColumName = N'Status_ID';  
              
  
            DECLARE @TempDetailTable  TABLE  
            (  
                ID      INT,  
                MUID    UNIQUEIDENTIFIER NULL,  
                Name    NVARCHAR(100) NULL  
            );  
            INSERT INTO @TempDetailTable (MUID,Name)   
            SELECT MUID, Name   
            FROM @IndexDetails;  
  
            UPDATE @TempDetailTable   
            SET  
                    ID = atr.ID,  
                    MUID = atr.MUID,  
                    Name = atr.Name   
            FROM @TempDetailTable temp   
            INNER JOIN mdm.tblAttribute atr  
            ON      atr.Entity_ID = @Entity_ID   
                AND atr.MemberType_ID = 1 --only looking for leaf attributes   
            WHERE   (temp.MUID IS NOT NULL OR temp.Name IS NOT NULL)  
                AND (temp.MUID IS NULL OR temp.MUID = atr.MUID)  
                AND (temp.Name IS NULL OR temp.Name = atr.Name);  
              
            IF(EXISTS(SELECT 1 FROM @TempDetailTable temp JOIN mdm.tblAttribute atr ON temp.ID = atr.ID AND atr.AttributeType_ID = 4))  
            BEGIN  
                RAISERROR('MDSERR200305| The index cannot be created on file attributes.', 16, 1);  
                RETURN;   
            END  
            --check for already existing non-clustered index on dba attributes and Name attribute.  
            IF ((SELECT COUNT(*) FROM @TempDetailTable) = 1)   
            BEGIN  
                DECLARE @Attribute_MUID UNIQUEIDENTIFIER;  
                SELECT TOP 1 @Attribute_MUID = MUID FROM @TempDetailTable;  
                DECLARE @ReturnError AS INT;  
                EXEC mdm.udpIndexAttributeListCheck @Attribute_MUID, @IsUnique, @ReturnError OUTPUT;  
                IF @ReturnError != 0    
                BEGIN  
                    RAISERROR('MDSERR200306| There is already an index created by the system on the selected attribute.', 16, 1);  
                    RETURN;      
                END  
            END  
  
            WHILE EXISTS(SELECT 1 FROM @TempDetailTable )   
            BEGIN      
                SET @TableColumn = N'';      
                SELECT TOP 1      
                    @Attribute_ID = ID,  
                    @AttributeName = Name   
                    FROM @TempDetailTable ORDER BY ID ASC      
                          
                IF (@AttributeName = N'Code' OR @AttributeName = N'Name')   
                BEGIN  
                    SET @TableColumn = @AttributeName  
                END ELSE   
                BEGIN  
                    SET @TableColumn = CONCAT(N'uda_', @Entity_ID, N'_',@Attribute_ID);  
                END  
                SET @Condition = CONCAT(@Condition, @TableColumn, N' IS NOT NULL');  
                SET @SystemIndexName = CONCAT( @SystemIndexName , N'_', @Attribute_ID);  
                SET @IndexColumns = CONCAT(@IndexColumns, QUOTENAME(@TableColumn));  
                SET @IndexColumnsWithQuote = CONCAT(@IndexColumnsWithQuote, N'''',@TableColumn, N'''');  
      
                IF ((SELECT COUNT(*) from @TempDetailTable) > 1)   
                BEGIN      
                    SET @Condition = CONCAT (@Condition, N' AND ');      
                    SET @IndexColumns = CONCAT (@IndexColumns, N' , ');      
                    SET @IndexColumnsWithQuote = CONCAT (@IndexColumnsWithQuote, N' , ');      
                END       
      
                DELETE FROM @TempDetailTable WHERE ID = @Attribute_ID;  
            END      
      
            --check if the maximum index keys size exceeds 900 bytes.       
                  
                  
            DECLARE @TotalIndexKeySize INT;      
            DECLARE @TableNameWithQuote sysname;       
            SET @TableNameWithQuote = CONCAT(N'''mdm.',@TableName,N'''');  
            SET @SQL = CONCAT(N'      
            SELECT @TotalIndexKeySize = SUM(max_length)       
                    FROM sys.columns      
            WHERE name IN (',@IndexColumnsWithQuote,N')       
                    AND object_id = OBJECT_ID(',@TableNameWithQuote,N');');  
      
            EXEC sp_executesql @SQL, N'@TotalIndexKeySize INT OUTPUT ', @TotalIndexKeySize OUTPUT;      
      
            IF (@TotalIndexKeySize > 900)      
            BEGIN        
                --On error, return NULL resultsudpSecurityPrivilegesSave        
                SELECT @Return_ID = NULL, @Return_MUID = NULL;        
                RAISERROR('MDSERR200307| The index cannot be saved because the total size of the selected attributes exceeds the maximum index key size of 900 bytes.', 16, 1);  
                RETURN;        
            END      
      
            IF @IsUnique=1      
            BEGIN --CREATE UNIQUE Index      
                SET @SQL = CONCAT( N'      
                        -- CREATE NONCLUSTERED INDEX ON SELECTED ATTRIBUTES      
                        CREATE UNIQUE NONCLUSTERED INDEX ' , quotename(@SystemIndexName) , N'      
                            ON mdm.' , quotename(@TableName) , N'(' , quotename(@VersionColumnName), N',', quotename(@Status_IDColumName), N',', @IndexColumns , N')      
                            INCLUDE(ID)      
                            ' , @StatusCheck, @Condition , N' ', @IndexOptions, N';');      
            END ELSE   
            BEGIN      
                SET @SQL = CONCAT( N'      
                        -- CREATE NONCLUSTERED INDEX ON SELECTED ATTRIBUTES      
                        CREATE NONCLUSTERED INDEX ' , quotename(@SystemIndexName) , N'      
                            ON mdm.' , quotename(@TableName) , N'(' , quotename(@VersionColumnName), N',', quotename(@Status_IDColumName), N',', @IndexColumns , N')      
                            INCLUDE(ID)      
                            ' , N' ', @IndexOptions, N';');      
            END      
                      
      
            EXEC sp_executesql @SQL;       
            --finding the system index      
                  
            DECLARE @SysIdx int;      
            SELECT @SysIdx = index_id from sys.indexes where name = @SystemIndexName;      
      
            IF (@ExistingIndex_ID IS NULL)   
            BEGIN    
                INSERT INTO mdm.tblIndex        
                (        
                     [Entity_ID]      
                    ,[SysIndex_ID]       
                    ,[Name]         
                    ,[IsUnique]        
                    ,[MUID]        
                    ,[EnterDTM]        
                    ,[EnterUserID]        
                    ,[LastChgDTM]        
                    ,[LastChgUserID]        
                )        
                VALUES  
                (        
                    @Entity_ID,      
                    @SysIdx,         
                    @Name,        
                    @IsUnique,        
                    @Return_MUID,        
                    @CurrentDTM,        
                    @User_ID,        
                    @CurrentDTM,        
                    @User_ID  
                )     
                      
                --Save the identity value        
                SET @Return_ID = SCOPE_IDENTITY();        
            END ELSE    
            BEGIN    
                    UPDATE mdm.tblIndex SET      
                    [SysIndex_ID] = ISNULL(@SysIdx, [SysIndex_ID]),    
                    [Name] = ISNULL(@Name, [Name]),      
                    [IsUnique] = ISNULL(@IsUnique, [IsUnique]),      
                    LastChgDTM = @CurrentDTM,        
                    LastChgUserID = @User_ID        
                WHERE        
                    ID = @ExistingIndex_ID;    
            END    
  
        
        END; --if  for new index      
        
        RETURN(0);        
        
    END TRY        
    --Compensate as necessary        
    BEGIN CATCH        
        
        -- Get error info.        
        DECLARE        
            @ErrorMessage NVARCHAR(4000),        
            @ErrorSeverity INT,        
            @ErrorState INT,        
            @ErrorNumber INT,        
            @ErrorLine INT,        
            @ErrorProcedure NVARCHAR(126);        
        EXEC mdm.udpGetErrorInfo        
            @ErrorMessage = @ErrorMessage OUTPUT,        
            @ErrorSeverity = @ErrorSeverity OUTPUT,        
            @ErrorState = @ErrorState OUTPUT,        
            @ErrorNumber = @ErrorNumber OUTPUT,        
            @ErrorLine = @ErrorLine OUTPUT,        
            @ErrorProcedure = @ErrorProcedure OUTPUT        
        
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);        
        
        IF (@ErrorMessage LIKE N'SYSERR1505|%') BEGIN    
            RAISERROR('MDSERR200308|The unique index cannot be saved because duplicate value(s) were found for the selected list of attributes.', 16, 1);  
        END   
        ELSE IF (@ErrorMessage LIKE N'SYSERR1913|%') BEGIN   
            RAISERROR('MDSERR200309|The index cannot be saved because an index with the same list of attributes and the same unique flag already exists.', 16, 1);  
        END ELSE  
        BEGIN    
            RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);    
        END       
        
        --On error, return NULL results    
        SELECT @Return_ID = NULL, @Return_MUID = NULL;    
        RETURN;        
        
    END CATCH;        
        
    SET NOCOUNT OFF;        
END; --proc
go

