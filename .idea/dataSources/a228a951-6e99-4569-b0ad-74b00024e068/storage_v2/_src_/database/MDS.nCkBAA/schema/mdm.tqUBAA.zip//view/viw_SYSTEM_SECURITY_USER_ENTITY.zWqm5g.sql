/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE VIEW mdm.viw_SYSTEM_SECURITY_USER_ENTITY  
/*WITH SCHEMABINDING*/  
AS  
/*  
Determines the effective permissions for each entity. Effective permissions are determined based on the following:  
  
Rank    Permission  
----    ---------------------  
1       Model Admin - ALL  
2       Model Deny - Deny  
3       No explicit permission, Model not inferred permission - Model permission  
4       Entity permission, could be explicit permission or null.  
  
*/  
WITH syncTargets AS  
(  
    SELECT DISTINCT TargetEntity_ID ID  
    FROM mdm.tblSyncRelationship  
),  
allPermissions AS (  
    SELECT  
        tSec.User_ID,  
        MAX(tSec.IsSyncTarget) IsSyncTarget,  
        tSec.ID,  
        ABS(MIN(tSec.Privilege_ID)) Privilege_ID,  
        SUM(Distinct(tSec.AccessPermission & 0x1)) +  
        SUM(Distinct(tSec.AccessPermission & 0x2)) +  
        SUM(Distinct(tSec.AccessPermission & 0x4)) AS AccessPermission  
    FROM  
        (  
        SELECT  
            tModSec.User_ID,  
            IsSyncTarget = CASE WHEN sync.ID IS NULL THEN 0 ELSE 1 END,  
            tEnt.ID,  
            Privilege_ID =  
                CASE  
                    WHEN tModSec.Privilege_ID = 1 /*Deny*/ THEN 1 /*Deny*/  
                    WHEN tModSec.Privilege_ID = 5 /*Admin*/ THEN CASE WHEN sync.ID IS NOT NULL THEN 4 /*Access*/ ELSE -5 /*-Admin*/ END  
                    WHEN tExp.Entity_PrivilegeID = 5 /*Admin*/ THEN CASE WHEN sync.ID IS NOT NULL THEN 4 /*Access*/ ELSE -5 /*-Admin*/ END  
                    -- No explicit permission on entity per role and non-inferred permission on model, use model permision  
                    WHEN ISNULL(tHasExplicit.HasExplicit, 0) != 1 AND tModSec.Privilege_ID <> 99  
                         THEN tModSec.Privilege_ID  
                    ELSE tExp.Entity_PrivilegeID  
                END,  
            AccessPermission =  
            CASE  
                    WHEN tModSec.Privilege_ID = 1 /*Deny*/ THEN NULL /*None*/  
                    WHEN sync.ID IS NOT NULL THEN 0 -- An entity that is the target of a sync relationship is read-only  
                    WHEN tModSec.Privilege_ID = 5 /*Admin*/ THEN NULL /*None*/  
                    WHEN tExp.Entity_PrivilegeID = 5 /*Admin*/ THEN NULL /*None*/  
                    WHEN ISNULL(tHasExplicit.HasExplicit, 0) != 1 AND tModSec.Privilege_ID <> 99  
                         THEN tModSec.AccessPermission  
                    ELSE tExp.Entity_AccessPermission  
                    END  
        FROM mdm.tblEntity tEnt  
        -- Check Model security  
        INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_MODEL tModSec  
        ON tModSec.ID = tEnt.Model_ID  
  
        LEFT JOIN mdm.viw_SYSTEM_SECURITY_USER tExp  
        ON tEnt.ID = tExp.Entity_ID  
            AND tModSec.User_ID = tExp.User_ID  
  
        -- Check if entity has explicit permission per each role  
        LEFT JOIN (  
            SELECT Entity_ID, User_ID, Role_ID, MAX(Entity_IsExplicit) as HasExplicit  
            FROM mdm.viw_SYSTEM_SECURITY_USER  
            GROUP BY Entity_ID, User_ID, Role_ID  
        ) AS tHasExplicit  
        ON tEnt.ID = tHasExplicit.Entity_ID AND tExp.User_ID = tHasExplicit.User_ID AND tExp.Role_ID = tHasExplicit.Role_ID  
  
        LEFT JOIN syncTargets sync  
        ON tEnt.ID = sync.ID  
    ) tSec  
  
    WHERE  
        tSec.Privilege_ID IS NOT NULL  
    GROUP BY  
        tSec.User_ID,  
        tSec.ID  
)  
SELECT  
    [User_ID],  
    IsSyncTarget,  
    ID,  
    Privilege_ID,  
    CASE Privilege_ID WHEN 4 /*Access*/ THEN AccessPermission ELSE NULL END AccessPermission  
FROM allPermissions
go

