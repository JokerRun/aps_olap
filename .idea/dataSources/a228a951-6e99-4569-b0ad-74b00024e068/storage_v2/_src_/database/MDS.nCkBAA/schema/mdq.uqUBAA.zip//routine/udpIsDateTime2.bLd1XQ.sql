/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
This method is a temporary substitute for the SQL CLR function. It should be removed when SQL Azure adds support for SQL CLR.  
  
DECLARE @IsDateTime2 BIT = NULL;  
  
EXEC mdq.udpIsDateTime2 NULL, @IsDateTime2 OUTPUT; -- 0  
  
*/  
CREATE PROCEDURE mdq.udpIsDateTime2  
(  
    @Input NVARCHAR(MAX) = NULL,  
    @IsDateTime2 BIT OUTPUT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
AS  
BEGIN  
    IF @Input IS NULL  
    BEGIN  
        SET @IsDateTime2 = 0;  
    END ELSE  
    BEGIN   
        BEGIN TRY  
            DECLARE @DateTime2 DATETIME2 = CONVERT(DATETIME2, @Input);  
            SET @IsDateTime2 = 1;  
        END TRY  
        BEGIN CATCH  
            SET @IsDateTime2 = 0;  
        END CATCH;  
    END;  
END;
go

