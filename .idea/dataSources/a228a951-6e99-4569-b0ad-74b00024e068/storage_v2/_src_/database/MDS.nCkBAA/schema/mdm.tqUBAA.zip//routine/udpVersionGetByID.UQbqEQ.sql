/*  
exec mdm.udpVersionGetByID 1  
*/  
/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpVersionGetByID  
(  
    @Version_ID	INT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON  
  
    SELECT  
        vVer.ID,  
        vVer.MUID,  
        vVer.Name,  
        vVer.Model_ID,  
        vVer.Model_MUID,  
        vVer.Model_Name,  
        vVer.[Description],  
        vVer.Status_ID,  
        vVer.[Status],  
        vVer.VersionNbr Display_ID,  
        vVer.Flag_MUID,  
        vVer.Flag VersionFlag,  
        vVer.CopiedFrom_ID AS AsOfVersionID,  
        vVer.CopiedFrom_MUID AS AsOfVersionMUID,  
        vVer.CopiedFrom AS AsOfVersionName,  
        4 AS Privilege_ID, /*Access*/  
        0 AS AccessPermission, /*ReadOnly*/  
        vVer.EnteredUser_MUID,  
        vVer.EnteredUser_UserName,  
        vVer.EnteredUser_DTM,  
        vVer.LastChgUser_MUID,  
        vVer.LastChgUser_UserName,  
        vVer.LastChgUser_DTM  
    FROM  
        mdm.viw_SYSTEM_SCHEMA_VERSION AS vVer   
    WHERE  
        vVer.ID = @Version_ID;  
  
    SET NOCOUNT OFF  
END --proc
go

