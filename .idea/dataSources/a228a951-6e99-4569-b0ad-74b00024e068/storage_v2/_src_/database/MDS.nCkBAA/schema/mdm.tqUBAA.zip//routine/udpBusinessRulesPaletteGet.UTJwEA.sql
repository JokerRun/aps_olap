/*  
Returns the data for the business rules palette  
  
exec mdm.udpBusinessRulesPaletteGet 1  
*/  
/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpBusinessRulesPaletteGet  
(  
    @MemberType_ID TINYINT = NULL,    
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability    
)    
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN    
    SET NOCOUNT ON    
    
    -- create vars corresponding to tblListRelationshipType.ID values    
    DECLARE @BRType INT = 1    
            ,@BRItemTypeCategory INT = 2    
            ,@DataType INT = 3   
            ,@BRActionTypeID INT = 2;  
             
  
    -- Level 2 nodes, i.e. "Value Comparison", "Default value", "Change value", "Validation"    
    SELECT        
        c.OptionID AS Id,    
        CONVERT(BIT, p.OptionID - 1) AS IsAction,    
        c.ListOption AS [Name]    
    FROM        
        mdm.tblListRelationship lr     
        INNER JOIN    
        mdm.tblList c     
            ON     
                lr.ListRelationshipType_ID = @BRItemTypeCategory AND    
                lr.Child_ID = c.OptionID AND     
                lr.ChildListCode = c.ListCode AND     
                c.IsVisible = 1     
        INNER JOIN    
        mdm.tblList p     
            ON     
                lr.Parent_ID = p.OptionID AND    
                p.OptionID <>3 AND    -- Ignore Else actions which are duplicated.  
                lr.ParentListCode = p.ListCode     
    ORDER BY p.Seq, c.Seq    
    
    -- Rule item types (level 3 nodes)    
    SELECT         
        ssbi.BRItemType_ID  Id,    
        ssbi.BRSubTypeID    ParentId,  
        (CASE ssbi.BRTypeID WHEN @BRActionTypeID THEN 1 ELSE 0 END) IsAction               
    FROM    mdm.viw_SYSTEM_SCHEMA_BUSINESSRULE_ITEMTYPES ssbi    
    WHERE        
        ssbi.ApplyToCategoryID = @BRItemTypeCategory AND    
        ssbi.BRSubTypeIsVisible = 1 AND    
        EXISTS     
        (    
            SELECT    BRItemType_ID     
            FROM    mdm.viw_SYSTEM_SCHEMA_BUSINESSRULE_ITEMTYPES     
            WHERE        
                ApplyToCategoryID = @BRType AND    
                BRSubTypeID = @MemberType_ID AND    
                BRItemType_ID = ssbi.BRItemType_ID    
        )    
    ORDER BY     
        DisplaySequence,     
        DisplaySubSequence,  
        Id   
    
    -- Compatible attribute types    
    SELECT     
        itat.BRItemType_ID  BRItemType,    
        lr.Parent_ID        AttributeType,    
        lr.Child_ID         AttributeDataType    
    FROM        
        mdm.tblBRItemTypeAppliesTo itat     
        INNER JOIN    
        mdm.tblListRelationship lr     
        ON     
            lr.ListRelationshipType_ID = @DataType AND    
            itat.ApplyTo_ID = lr.ID    
    ORDER BY     
        itat.BRItemType_ID,     
        lr.Parent_ID,     
        lr.Child_ID    
    
    IF( @MemberType_ID = 1)  
    BEGIN   
         
        -- Condition scripts    
        SELECT     
            SO.name AS ScriptName    
            , P.name AS ParameterName    
            , P.parameter_id AS [Index]    
            , P.is_output IsOutput          
            , TYPE_NAME(P.system_type_id) AS TypeName    
            , P.scale AS Scale    
            , P.precision AS [Precision]    
            , P.max_length AS [MaxLength]    
        FROM sys.objects AS SO    
        INNER JOIN sys.parameters AS P     
        ON SO.object_id = P.object_id    
        WHERE  type ='FN' AND schema_id = SCHEMA_ID('usr')     
        AND mdm.udfScriptExists(SO.name, 1, 'usr') = 1      
    
        -- Action scripts    
        Select name As ScriptName    
        FROM sys.objects    
        WHERE  schema_id = SCHEMA_ID('usr')     
        AND type ='P'    
        AND mdm.udfScriptExists(name,2,'usr') = 1       
    END  
      
        
    SET NOCOUNT OFF    
END --proc
go

