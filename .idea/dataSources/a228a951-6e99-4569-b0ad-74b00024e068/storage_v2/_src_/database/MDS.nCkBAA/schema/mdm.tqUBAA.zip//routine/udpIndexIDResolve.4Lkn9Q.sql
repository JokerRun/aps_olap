/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
/*  
Resolves Index MUID and Name to ID.   
If ID is already provided, it is returned with no validation.  
If ID is NULL and MUID/Name match an ID, the ID is returned.  
If no matching ID is found for the given (MUID,Name) pair, ID is set to -1  
*/  
CREATE PROCEDURE [mdm].[udpIndexIDResolve]  
    @EntityID       INT,  
    @Index_MUID     UNIQUEIDENTIFIER = NULL,  
    @Index_Name     NVARCHAR(50) = NULL,  
    @Index_ID       INT OUTPUT,  
    @CorrelationID  UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
AS BEGIN  
    DECLARE @Invalid_ID INT = -1  
  
    IF @Index_ID IS NULL  
    BEGIN  
        IF @Index_MUID IS NOT NULL OR @Index_Name IS NOT NULL  
        BEGIN  
            SELECT @Index_ID = ID FROM mdm.tblIndex WHERE (MUID = ISNULL(@Index_MUID, MUID)) AND (Name = ISNULL(@Index_Name, Name))   
                AND (Entity_ID = ISNULL(@EntityID, Entity_ID))  
      
            IF @Index_ID IS NULL  
            BEGIN  
                SELECT @Index_ID = @Invalid_ID  
            END  
        END  
    END  
             
END
go

