/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    Returns the specified users.  
      
    DECLARE @@UserTable mdm.Identifier  
    EXEC udpSecurityUsersGet   
        @@UserTable = @UserTable  
*/  
CREATE PROCEDURE mdm.udpSecurityUsersGet  
(  
    @UserTable mdm.Identifier READONLY,-- caller should ensure table does not include rows where both MUID and Name are blank  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    IF EXISTS(SELECT 1 FROM @UserTable)  
    BEGIN  
        SELECT   
            u.ID,  
            u.MUID,  
            u.SID,  
            u.UserName,  
            u.DisplayName,  
            u.Description,  
            u.EmailAddress,  
            u.LastLoginDTM,  
            COALESCE(u.EnterUserID,0) AS EnterUserID,  
            eu.MUID AS EnterUserMUID,  
            COALESCE(eu.UserName,N'') AS EnterUserName,  
            COALESCE(eu.DisplayName,N'') AS EnterUserDisplayName,  
            u.EnterDTM,  
            COALESCE(u.LastChgUserID,0) AS LastChgUserID,  
            lcu.MUID AS LastChgUserMUID,  
            COALESCE(lcu.UserName,N'') AS LastChgUserName,  
            COALESCE(lcu.DisplayName,N'') AS LastChgUserDisplayName,  
            u.LastChgDTM,  
            pref.PreferenceValue AS EmailType    
        FROM mdm.tblUser u  
        INNER JOIN @UserTable crit  
        ON   
            u.Status_ID <> 2 AND  
            --(crit.MUID IS NOT NULL OR crit.Name IS NOT NULL OR crit.ID IS NOT NULL) AND -- return all when no identifiers are provided. This is inconsistent with udpSecurityGroupsGet??  
            (crit.MUID IS NULL OR crit.MUID = u.MUID) AND  
            (crit.Name IS NULL OR UPPER(crit.Name) = UPPER(u.UserName)) AND  
            (crit.ID IS NULL OR crit.ID = u.ID)  
        LEFT JOIN mdm.tblUser eu   
        ON u.EnterUserID = eu.ID   
        LEFT JOIN mdm.tblUser lcu   
        ON u.LastChgUserID = lcu.ID  
        LEFT JOIN mdm.tblUserPreference pref   
        ON u.ID = pref.User_ID AND   
           PreferenceName='lstEmail'  
        ORDER BY u.ID  
    END ELSE  
    BEGIN  
        SELECT   
            u.ID,  
            u.MUID,  
            u.SID,  
            u.UserName,  
            u.DisplayName,  
            u.Description,  
            u.EmailAddress,  
            u.LastLoginDTM,  
            COALESCE(u.EnterUserID,0) AS EnterUserID,  
            eu.MUID AS EnterUserMUID,  
            COALESCE(eu.UserName,N'') AS EnterUserName,  
            COALESCE(eu.DisplayName,N'') AS EnterUserDisplayName,  
            u.EnterDTM,  
            COALESCE(u.LastChgUserID,0) AS LastChgUserID,  
            lcu.MUID AS LastChgUserMUID,  
            COALESCE(lcu.UserName,N'') AS LastChgUserName,  
            COALESCE(lcu.DisplayName,N'') AS LastChgUserDisplayName,  
            u.LastChgDTM,  
            pref.PreferenceValue AS EmailType    
        FROM mdm.tblUser u  
        LEFT JOIN mdm.tblUser eu   
        ON u.EnterUserID = eu.ID   
        LEFT JOIN mdm.tblUser lcu   
        ON u.LastChgUserID = lcu.ID  
        LEFT JOIN mdm.tblUserPreference pref   
        ON u.ID = pref.User_ID AND   
           PreferenceName='lstEmail'  
        WHERE u.Status_ID <> 2  
        ORDER BY u.ID  
    END  
    SET NOCOUNT OFF;  
END; --proc
go

