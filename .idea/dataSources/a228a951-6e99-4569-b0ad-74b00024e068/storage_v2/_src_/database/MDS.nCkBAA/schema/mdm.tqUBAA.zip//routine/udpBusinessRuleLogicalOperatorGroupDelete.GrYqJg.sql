/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpBusinessRuleLogicalOperatorGroupDelete  
(  
    @User_ID        INT,  
    @MUID           UNIQUEIDENTIFIER,  
    @RuleMUID       UNIQUEIDENTIFIER = NULL OUTPUT,  
    @CorrelationID  UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
      
    DECLARE  
        @GuidEmpty          UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER),  
        @ID                 INT,  
  
        @Permission_Admin   TINYINT = 5;  
  
    SET @RuleMUID = NULL;  
    SET @MUID = NULLIF(@MUID, @GuidEmpty);  
  
    -- find the item ID  
    DECLARE @RuleID INT;  
  
    SELECT   
        @ID = lg.ID,  
        @RuleMUID = br.MUID  
    FROM mdm.tblBRLogicalOperatorGroup lg  
    INNER JOIN mdm.tblBRBusinessRule br  
    ON lg.BusinessRule_ID = br.ID  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ENTITY se  
    ON br.Entity_ID = se.ID AND se.User_ID = @User_ID  
    WHERE @MUID IS NOT NULL  
        AND lg.MUID = @MUID  
        AND se.Privilege_ID = @Permission_Admin;  
  
    IF @ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR400006|The logical operator group MUID is not valid.', 16, 1);  
        RETURN;  
    END  
          
    -- delete all child rule items and their properties  
    DECLARE @ChildMuids TABLE (MUID UNIQUEIDENTIFIER PRIMARY KEY)  
    INSERT INTO @ChildMuids  
        SELECT MUID FROM mdm.tblBRItem WHERE BRLogicalOperatorGroup_ID = @ID;  
    DECLARE @ChildMuid UNIQUEIDENTIFIER SET @ChildMuid = (SELECT TOP 1 MUID FROM @ChildMuids);  
    WHILE @ChildMuid IS NOT NULL BEGIN  
        EXEC mdm.udpBusinessRuleItemDelete @User_ID, @ChildMuid  
        DELETE FROM @ChildMuids WHERE MUID = @ChildMuid  
        SET @ChildMuid = (SELECT TOP 1 MUID FROM @ChildMuids);  
    END  
  
    -- delete all child logical operator groups  
    INSERT INTO @ChildMuids  
        SELECT MUID FROM mdm.tblBRLogicalOperatorGroup WHERE ISNULL(Parent_ID, 0) = @ID;  
    SET @ChildMuid = (SELECT TOP 1 MUID FROM @ChildMuids);  
    WHILE @ChildMuid IS NOT NULL BEGIN  
        EXEC mdm.udpBusinessRuleLogicalOperatorGroupDelete @User_ID, @ChildMuid  
        DELETE FROM @ChildMuids WHERE MUID = @ChildMuid  
        SET @ChildMuid = (SELECT TOP 1 MUID FROM @ChildMuids);  
    END  
  
    -- delete the logical operator group  
    DELETE FROM mdm.tblBRLogicalOperatorGroup WHERE ID = @ID  
  
    SET NOCOUNT OFF  
END
go

