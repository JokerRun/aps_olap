/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
This stored procedure determines if a user is an administrator a model.  A model administrator must have update permission of  
the model and all underlying child objects.  This can be determined by passing in the Model Id itself or it can be determined  
by passing in child objects (if that is all that is available) and then based on the FK links it can be determined if the user  
is an administrator of the model.  
  
The object context is optional and need only be passed in if the object Muid is not passed in, which is the case in add mode.  
  
declare @ret as INT  
exec mdm.udpUserIsModelAdministrator  
    1,  
    7,  
    NULL,  
    'EE851F25-8919-460F-8485-99D319C70AF2',  
    NULL,  
    @ret OUTPUT  
select @ret  
  
declare @ret as INT  
exec mdm.udpUserIsModelAdministrator  
    1,  
    5,  
    NULL,  
    'Department',  
    NULL,  
    NULL,  
    @ret OUTPUT  
select @ret  
*/  
CREATE PROCEDURE mdm.udpUserIsModelAdministrator  
(  
    @User_ID            INT,                        -- User id to check .  
    @ObjectType_ID      INT,                        -- The object type of the Muid being passed in.  
    @Object_MUID        UNIQUEIDENTIFIER = NULL,    -- The object's Muid.  Not passed in during add mode.  
    @Object_Name        NVARCHAR(MAX) = NULL,       -- The object's Name.  Not passed in during add mode.  
    @ObjectContext_MUID UNIQUEIDENTIFIER = NULL,    -- The object's context (or parent) Muid.  
    @ObjectContext_Name NVARCHAR(MAX) = NULL,       -- The object's context (or parent) name.  
    @Return_ID          INT = NULL OUTPUT,           -- The result: True if the user is a model admin.  False otherwise.  
    @CorrelationID      UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    DECLARE  
         @EmptyMuid UNIQUEIDENTIFIER = CONVERT(UNIQUEIDENTIFIER, 0x0)  
        ,@ObjectType_Model                  INT = 1  
        ,@ObjectType_DerivedHierarchy       INT = 2  
        ,@ObjectType_DerivedHierarchyLevel  INT = 3  
        ,@ObjectType_Version                INT = 4  
        ,@ObjectType_Entity                 INT = 5  
        ,@ObjectType_Hierarchy              INT = 6  
        ,@ObjectType_Attribute              INT = 7  
        ,@ObjectType_AttributeGroup         INT = 8  
        ,@ObjectType_VersionFlag            INT = 10  
        ,@ObjectType_Index                  INT = 23  
        ;  
  
    -- In an add scenario the object Muid will not be supplied.  
    SET @Object_MUID = NULLIF(@Object_MUID, @EmptyMuid);  
    SET @Object_Name = NULLIF(@Object_Name, N'');  
  
    --Null out the context Muid and Name if it is not supplied.  
    SET @ObjectContext_MUID = NULLIF(@ObjectContext_MUID, @EmptyMuid);  
    SET @ObjectContext_Name = NULLIF(@ObjectContext_Name, N'');  
  
    IF @Object_MUID IS NULL AND @Object_Name IS NULL AND @ObjectContext_MUID IS NULL AND @ObjectContext_Name IS NULL  
    BEGIN  
        SET @Return_ID = 0;  
        RETURN;  
    END  
  
    IF (@Object_MUID IS NULL AND @Object_Name IS NOT NULL) AND (@ObjectContext_MUID IS NULL AND @ObjectContext_Name IS NULL) AND @ObjectType_ID <> @ObjectType_Model -- Model's don't need context  
    BEGIN  
        SET @Return_ID = 0;  
        RETURN;  
    END  
  
    -- Lookup the Model ID  
    IF @ObjectType_ID = @ObjectType_Model  
    BEGIN  
        SELECT  
            @Return_ID = CASE acl.Privilege_ID WHEN 5 /*Admin*/ THEN 1 ELSE 0 END  
        FROM  
            mdm.tblModel itm INNER JOIN  
            mdm.viw_SYSTEM_SECURITY_USER_MODEL AS acl  
                ON  acl.ID = itm.ID  
                AND acl.User_ID = @User_ID  
                AND acl.Privilege_ID <> 1 /*Deny*/  
                AND (itm.MUID = @Object_MUID OR itm.Name = @Object_Name)  
    END  
    ELSE IF @ObjectType_ID = @ObjectType_Entity  
    BEGIN  
        IF @Object_MUID IS NOT NULL  
            SELECT  
                @Return_ID = CASE acl.Privilege_ID WHEN 5 /*Admin*/ THEN 1 ELSE 0 END  
            FROM  
                mdm.viw_SYSTEM_SCHEMA_ENTITY itm INNER JOIN  
                mdm.viw_SYSTEM_SECURITY_USER_MODEL AS acl  
                    ON  ((itm.MUID = @Object_MUID)  
                    OR  (itm.Name = @Object_Name AND (((@ObjectContext_MUID IS NULL) OR (itm.Model_MUID = @ObjectContext_MUID)) AND ((@ObjectContext_Name IS NULL) OR (itm.Model_Name = @ObjectContext_Name))))  
                    )  
                    AND acl.ID = itm.Model_ID  
                    AND acl.User_ID = @User_ID  
                    AND acl.Privilege_ID <> 1 /*Deny*/  
        ELSE  
            SELECT  
                @Return_ID = CASE acl.Privilege_ID WHEN 5 /*Admin*/ THEN 1 ELSE 0 END  
            FROM  
                mdm.tblModel ctx INNER JOIN  
                mdm.viw_SYSTEM_SECURITY_USER_MODEL AS acl  
                    ON ((@ObjectContext_MUID IS NULL) OR (ctx.MUID = @ObjectContext_MUID))  
                    AND ((@ObjectContext_Name IS NULL) OR (ctx.Name = @ObjectContext_Name))  
                    AND acl.ID = ctx.ID  
                    AND acl.User_ID = @User_ID  
                    AND acl.Privilege_ID <> 1 /*Deny*/  
  
    END  
    ELSE IF @ObjectType_ID = @ObjectType_Attribute  
        BEGIN  
            IF @Object_MUID IS NOT NULL  
                SELECT  
                    @Return_ID = CASE acl.Privilege_ID WHEN 5 /*Admin*/ THEN 1 ELSE 0 END  
                FROM  
                    mdm.viw_SYSTEM_SCHEMA_ATTRIBUTES itm INNER JOIN  
                    mdm.viw_SYSTEM_SECURITY_USER_MODEL AS acl  
                        ON  ((itm.Attribute_MUID = @Object_MUID)  
                        OR  (itm.Attribute_Name = @Object_Name AND (((@ObjectContext_MUID IS NULL) OR (itm.Entity_MUID = @ObjectContext_MUID)) AND ((@ObjectContext_Name IS NULL) OR (itm.Entity_Name = @ObjectContext_Name))))  
                        )  
                        AND acl.ID = itm.Model_ID  
                        AND acl.User_ID = @User_ID  
                        AND acl.Privilege_ID <> 1 /*Deny*/  
            ELSE  
                SELECT  
                    @Return_ID = CASE acl.Privilege_ID WHEN 5 /*Admin*/ THEN 1 ELSE 0 END  
                FROM  
                    mdm.tblEntity ctx INNER JOIN  
                    mdm.viw_SYSTEM_SECURITY_USER_MODEL AS acl  
                        ON ((@ObjectContext_MUID IS NULL) OR (ctx.MUID = @ObjectContext_MUID))  
                        AND ((@ObjectContext_Name IS NULL ) OR (ctx.Name = @ObjectContext_Name))  
                        AND acl.ID = ctx.Model_ID  
                        AND acl.User_ID = @User_ID  
                        AND acl.Privilege_ID <> 1 /*Deny*/  
  
        END  
    ELSE IF @ObjectType_ID = @ObjectType_AttributeGroup  
        BEGIN  
            IF @Object_MUID IS NOT NULL  
                SELECT  
                    @Return_ID = CASE acl.Privilege_ID WHEN 5 /*Admin*/ THEN 1 ELSE 0 END  
                FROM  
                    mdm.viw_SYSTEM_SCHEMA_ATTRIBUTEGROUPS itm INNER JOIN  
                    mdm.viw_SYSTEM_SECURITY_USER_MODEL AS acl  
                        ON  ((itm.MUID = @Object_MUID)  
                        OR  (itm.Name = @Object_Name AND (((@ObjectContext_MUID IS NULL) OR (itm.Entity_MUID = @ObjectContext_MUID)) AND ((@ObjectContext_Name IS NULL) OR (itm.Entity_Name = @ObjectContext_Name))))  
                        )  
                        AND acl.ID = itm.Model_ID  
                        AND acl.User_ID = @User_ID  
                        AND acl.Privilege_ID <> 1 /*Deny*/  
            ELSE  
                SELECT  
                    @Return_ID = CASE acl.Privilege_ID WHEN 5 /*Admin*/ THEN 1 ELSE 0 END  
                FROM  
                    mdm.tblEntity ctx INNER JOIN  
                    mdm.viw_SYSTEM_SECURITY_USER_MODEL AS acl  
                        ON ((@ObjectContext_MUID IS NULL) OR (ctx.MUID = @ObjectContext_MUID))  
                        AND ((@ObjectContext_Name IS NULL) OR (ctx.Name = @ObjectContext_Name))  
                        AND acl.ID = ctx.Model_ID  
                        AND acl.User_ID = @User_ID  
                        AND acl.Privilege_ID <> 1 /*Deny*/  
  
        END  
    ELSE IF @ObjectType_ID = @ObjectType_Hierarchy  
        BEGIN  
            IF @Object_MUID IS NOT NULL  
            SELECT  
                @Return_ID = CASE acl.Privilege_ID WHEN 5 /*Admin*/ THEN 1 ELSE 0 END  
            FROM  
                mdm.viw_SYSTEM_SCHEMA_HIERARCHY_EXPLICIT itm INNER JOIN  
                mdm.viw_SYSTEM_SECURITY_USER_MODEL AS acl  
                    ON  ((itm.Hierarchy_MUID = @Object_MUID)  
                    OR  (itm.Hierarchy_Name = @Object_Name AND (((@ObjectContext_MUID IS NULL) OR (itm.Entity_MUID = @ObjectContext_MUID)) AND ((@ObjectContext_Name IS NULL) OR (itm.Entity_Name = @ObjectContext_Name))))  
                    )  
                    AND acl.ID = itm.Model_ID  
                    AND acl.User_ID = @User_ID  
                    AND acl.Privilege_ID <> 1 /*Deny*/  
            ELSE  
                SELECT  
                    @Return_ID = CASE acl.Privilege_ID WHEN 5 /*Admin*/ THEN 1 ELSE 0 END  
                FROM  
                    mdm.tblEntity ctx INNER JOIN  
                    mdm.viw_SYSTEM_SECURITY_USER_MODEL AS acl  
                        ON ((@ObjectContext_MUID IS NULL) OR (ctx.MUID = @ObjectContext_MUID))  
                        AND ((@ObjectContext_Name IS NULL) OR (ctx.Name = @ObjectContext_Name))  
                        AND acl.ID = ctx.Model_ID  
                        AND acl.User_ID = @User_ID  
                        AND acl.Privilege_ID <> 1 /*Deny*/  
  
        END  
    ELSE IF @ObjectType_ID = @ObjectType_DerivedHierarchy  
        BEGIN  
            IF @Object_MUID IS NOT NULL  
                SELECT  
                    @Return_ID = CASE acl.Privilege_ID WHEN 5 /*Admin*/ THEN 1 ELSE 0 END  
                FROM  
                    mdm.viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED itm INNER JOIN  
                    mdm.viw_SYSTEM_SECURITY_USER_MODEL AS acl  
                        ON  ((itm.Hierarchy_MUID = @Object_MUID)  
                        OR  (itm.Hierarchy_Name = @Object_Name AND (((@ObjectContext_MUID IS NULL) OR (itm.Model_MUID = @ObjectContext_MUID)) AND ((@ObjectContext_Name IS NULL) OR (itm.Model_Name = @ObjectContext_Name))))  
                        )  
                        AND acl.ID = itm.Model_ID  
                        AND acl.User_ID = @User_ID  
                        AND acl.Privilege_ID <> 1 /*Deny*/  
            ELSE  
                SELECT  
                    @Return_ID = CASE acl.Privilege_ID WHEN 5 /*Admin*/ THEN 1 ELSE 0 END  
                FROM  
                    mdm.tblModel ctx INNER JOIN  
                    mdm.viw_SYSTEM_SECURITY_USER_MODEL AS acl  
                        ON ((@ObjectContext_MUID IS NULL) OR (ctx.MUID = @ObjectContext_MUID))  
                        AND ((@ObjectContext_Name IS NULL) OR (ctx.Name = @ObjectContext_Name))  
                        AND acl.ID = ctx.ID  
                        AND acl.User_ID = @User_ID  
                        AND acl.Privilege_ID <> 1 /*Deny*/  
        END  
    ELSE IF @ObjectType_ID = @ObjectType_DerivedHierarchyLevel  
        BEGIN  
            IF @Object_MUID IS NOT NULL  
                SELECT  
                    @Return_ID = CASE acl.Privilege_ID WHEN 5 /*Admin*/ THEN 1 ELSE 0 END  
                FROM  
                    mdm.viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED_LEVELS itm INNER JOIN  
                    mdm.viw_SYSTEM_SECURITY_USER_MODEL AS acl  
                        ON  ((itm.MUID = @Object_MUID)  
                        OR  (itm.Name = @Object_Name AND (((@ObjectContext_MUID IS NULL) OR (itm.Hierarchy_MUID = @ObjectContext_MUID)) AND ((@ObjectContext_Name IS NULL) OR (itm.Hierarchy_Name = @ObjectContext_Name))))  
                        )  
                        AND acl.ID = itm.Model_ID  
                        AND acl.User_ID = @User_ID  
                        AND acl.Privilege_ID <> 1 /*Deny*/  
            ELSE  
                SELECT  
                    @Return_ID = CASE acl.Privilege_ID WHEN 5 /*Admin*/ THEN 1 ELSE 0 END  
                FROM  
                    mdm.tblDerivedHierarchy ctx INNER JOIN  
                    mdm.tblModel mdl  
                        ON ctx.Model_ID = mdl.ID  
                    INNER JOIN  
                    mdm.viw_SYSTEM_SECURITY_USER_MODEL AS acl  
                        ON ((@ObjectContext_MUID IS NULL) OR (ctx.MUID = @ObjectContext_MUID))  
                        AND ((@ObjectContext_Name IS NULL) OR (ctx.Name = @ObjectContext_Name))  
                        AND acl.ID = mdl.ID  
                        AND acl.User_ID = @User_ID  
                        AND acl.Privilege_ID <> 1 /*Deny*/  
        END  
    ELSE IF @ObjectType_ID = @ObjectType_VersionFlag  
        BEGIN  
            IF @Object_MUID IS NOT NULL  
                SELECT  
                    @Return_ID = CASE acl.Privilege_ID WHEN 5 /*Admin*/ THEN 1 ELSE 0 END  
                FROM  
                    mdm.viw_SYSTEM_SCHEMA_VERSION_FLAGS itm INNER JOIN  
                    mdm.viw_SYSTEM_SECURITY_USER_MODEL AS acl  
                        ON  ((itm.MUID = @Object_MUID)  
                        OR  (itm.Name = @Object_Name AND (((@ObjectContext_MUID IS NULL) OR (itm.Model_MUID = @ObjectContext_MUID)) AND ((@ObjectContext_Name IS NULL) OR (itm.Model_Name = @ObjectContext_Name))))  
                        )  
                        AND acl.ID = itm.Model_ID  
                        AND acl.User_ID = @User_ID  
                        AND acl.Privilege_ID <> 1 /*Deny*/  
            ELSE  
                SELECT  
                    @Return_ID = CASE acl.Privilege_ID WHEN 5 /*Admin*/ THEN 1 ELSE 0 END  
                FROM  
                    mdm.tblModel ctx INNER JOIN  
                    mdm.viw_SYSTEM_SECURITY_USER_MODEL AS acl  
                        ON ((@ObjectContext_MUID IS NULL) OR (ctx.MUID = @ObjectContext_MUID))  
                        AND ((@ObjectContext_Name IS NULL) OR (ctx.Name = @ObjectContext_Name))  
                        AND acl.ID = ctx.ID  
                        AND acl.User_ID = @User_ID  
                        AND acl.Privilege_ID <> 1 /*Deny*/  
  
        END  
    ELSE IF @ObjectType_ID = @ObjectType_Version  
        BEGIN  
            IF @Object_MUID IS NOT NULL  
                SELECT  
                    @Return_ID = CASE acl.Privilege_ID WHEN 5 /*Admin*/ THEN 1 ELSE 0 END  
                FROM  
                    mdm.viw_SYSTEM_SCHEMA_VERSION itm INNER JOIN  
                    mdm.viw_SYSTEM_SECURITY_USER_MODEL AS acl  
                        ON  ((itm.MUID = @Object_MUID)  
                        OR  (itm.Name = @Object_Name AND (((@ObjectContext_MUID IS NULL) OR (itm.Model_MUID = @ObjectContext_MUID)) AND ((@ObjectContext_Name IS NULL) OR (itm.Model_Name = @ObjectContext_Name))))  
                        )  
                        AND acl.ID = itm.Model_ID  
                        AND acl.User_ID = @User_ID  
                        AND acl.Privilege_ID <> 1 /*Deny*/  
            ELSE  
                SELECT  
                    @Return_ID = CASE acl.Privilege_ID WHEN 5 /*Admin*/ THEN 1 ELSE 0 END  
                FROM  
                    mdm.tblModel ctx INNER JOIN  
                    mdm.viw_SYSTEM_SECURITY_USER_MODEL AS acl  
                        ON ((@ObjectContext_MUID IS NULL) OR (ctx.MUID = @ObjectContext_MUID))  
                        AND ((@ObjectContext_Name IS NULL) OR (ctx.Name = @ObjectContext_Name))  
                        AND acl.ID = ctx.ID  
                        AND acl.User_ID = @User_ID  
                        AND acl.Privilege_ID <> 1 /*Deny*/  
  
        END  
  
    ELSE IF @ObjectType_ID = @ObjectType_Index  
    BEGIN  
        IF @Object_MUID IS NOT NULL  
            SELECT  
                @Return_ID = CASE acl.Privilege_ID WHEN 5 /*Admin*/ THEN 1 ELSE 0 END  
            FROM  
                mdm.viw_SYSTEM_SCHEMA_INDEXES itm INNER JOIN  
                mdm.viw_SYSTEM_SECURITY_USER_MODEL AS acl  
                    ON  ((itm.Index_MUID = @Object_MUID)  
                    OR  (itm.Index_Name = @Object_Name AND (((@ObjectContext_MUID IS NULL) OR (itm.Model_MUID = @ObjectContext_MUID)) AND ((@ObjectContext_Name IS NULL) OR (itm.Model_Name = @ObjectContext_Name))))  
                    )  
                    AND acl.ID = itm.Model_ID  
                    AND acl.User_ID = @User_ID  
                    AND acl.Privilege_ID <> 1 /*Deny*/  
        ELSE  
            SELECT  
                @Return_ID = CASE acl.Privilege_ID WHEN 5 /*Admin*/ THEN 1 ELSE 0 END  
            FROM  
                mdm.tblModel ctx INNER JOIN  
                mdm.viw_SYSTEM_SECURITY_USER_MODEL AS acl  
                    ON ((@ObjectContext_MUID IS NULL) OR (ctx.MUID = @ObjectContext_MUID))  
                    AND ((@ObjectContext_Name IS NULL) OR (ctx.Name = @ObjectContext_Name))  
                    AND acl.ID = ctx.ID  
                    AND acl.User_ID = @User_ID  
                    AND acl.Privilege_ID <> 1 /*Deny*/  
  
    END  
  
    SET @Return_ID = ISNULL(@Return_ID,0)  
  
    SET NOCOUNT OFF  
END --proc
go

