/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Changes the derived hierarchy parent of the given leaf members to the given parent.  
The given hierarchy level's type must be either DBA or Many-to-Many (M2M).  
  
*/  
CREATE PROCEDURE mdm.udpDerivedHierarchyParentSave  
(  
     @User_ID               INT  
    ,@ModelName             NVARCHAR(50) = NULL  
    ,@ModelMuid             UNIQUEIDENTIFIER = NULL  
    ,@VersionName           NVARCHAR(50) = NULL  
    ,@VersionMuid           UNIQUEIDENTIFIER = NULL  
    ,@DerivedHierarchyName  NVARCHAR(50) = NULL  
    ,@DerivedHierarchyMuid  UNIQUEIDENTIFIER = NULL  
    ,@LevelNumber           INT  
    ,@NewParentID           UNIQUEIDENTIFIER  
    ,@OldParentChildIds     mdm.ParentChildId READONLY -- old parent id is only required for M2M levels. It is ignored for DBA levels  
    ,@CorrelationID         UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE  
         @Model_ID                      INT  
        ,@Version_ID                    INT  
        ,@DerivedHierarchy_ID           INT  
        ,@Entity_ID                     INT  
        ,@ParentEntity_ID               INT  
        ,@ParentEntityTableName         SYSNAME  
        ,@ParentAttribute_ID            INT  
        ,@ParentAttributeName           SYSNAME  
        ,@ManyToManyChildAttribute_ID   INT  
        ,@ManyToManyChildAttributeName  SYSNAME  
        ,@LevelType                     TINYINT  
        ,@NewParentCode                 NVARCHAR(250)  
        ,@Members                       mdm.MemberSaveList  
        ,@MemberAttributes              mdm.MemberAttributeValues  
        ,@SaveMode                      TINYINT  
  
        ,@MemberType_Leaf               TINYINT = 1  
  
        ,@ForeignType_DBA               TINYINT = 1  
        ,@ForeignType_ManyToMany        TINYINT = 5  
  
        ,@Permission_Deny               INT = 1  
  
        ,@SaveMode_Create               TINYINT = 1  
        ,@SaveMode_Merge                TINYINT = 2  
        ,@SaveMode_Update               TINYINT = 3  
  
        ,@TransactionBehavior_AllOrNothingByBatch   TINYINT = 2  
  
        ,@SQL                           NVARCHAR(MAX)  
        ,@GuidEmpty                     UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER)  
        ;  
  
    SELECT  
         @ModelMuid = NULLIF(@ModelMuid, @GuidEmpty)  
        ,@ModelName = NULLIF(@ModelName, N'')  
        ,@VersionMuid = NULLIF(@VersionMuid, @GuidEmpty)  
        ,@VersionName = NULLIF(@VersionName, N'')  
        ,@DerivedHierarchyMuid = NULLIF(@DerivedHierarchyMuid, @GuidEmpty)  
        ,@DerivedHierarchyName = NULLIF(@DerivedHierarchyName, N'')  
        ,@NewParentID = NULLIF(LTRIM(RTRIM(@NewParentID)), N'');  
  
    SELECT @Model_ID = m.ID  
    FROM mdm.tblModel m  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_MODEL s  
    ON      m.ID = s.ID  
        AND COALESCE(s.Privilege_ID, @Permission_Deny) <> @Permission_Deny  
        AND s.User_ID = @User_ID  
    WHERE   (@ModelMuid IS NOT NULL OR @ModelName IS NOT NULL) -- At least one Identifier param must be provided.  
        AND (@ModelMuid IS NULL OR @ModelMuid = m.MUID)  
        AND (@ModelName IS NULL OR @ModelName = m.Name)  
  
    IF @Model_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300005|The supplied model is not valid.', 16, 1);  
        RETURN;  
    END  
  
    SELECT @Version_ID = ID  
    FROM mdm.tblModelVersion  
    WHERE  
        (@VersionMuid IS NOT NULL OR @VersionName IS NOT NULL) -- At least one Identifier param must be provided.  
    AND (@VersionMuid IS NULL OR @VersionMuid = MUID)  
    AND (@VersionName IS NULL OR @VersionName = Name)  
    AND Model_ID = @Model_ID  
    IF @Version_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300006|The supplied version is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    SELECT @DerivedHierarchy_ID = ID  
    FROM mdm.tblDerivedHierarchy  
    WHERE   Model_ID = @Model_ID  
        AND (@DerivedHierarchyMuid IS NOT NULL OR @DerivedHierarchyName IS NOT NULL)  
        AND (@DerivedHierarchyMuid IS NULL OR @DerivedHierarchyMuid = MUID)  
        AND (@DerivedHierarchyName IS NULL OR @DerivedHierarchyName = Name)  
  
    IF @DerivedHierarchy_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300007|The supplied derived hierarchy is not valid.', 16, 1);  
        RETURN;  
    END  
  
    -- Lookup Hierarchy level (level type, entity name, parent attribute name)  
    SELECT   
         @LevelType                     = l.ForeignType_ID   
        ,@ParentAttribute_ID            = l.Foreign_ID  
        ,@ParentAttributeName           = l.Foreign_Name  
        ,@ManyToManyChildAttribute_ID   = l.ManyToManyChildAttribute_ID  
        ,@ManyToManyChildAttributeName  = l.ManyToManyChildAttribute_Name  
        ,@Entity_ID                     = l.ForeignEntity_ID   
        ,@ParentEntity_ID               = l.Entity_ID  
        ,@ParentEntityTableName         = pe.EntityTable  
    FROM mdm.viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED_LEVELS l  
    LEFT JOIN mdm.tblEntity pe  
    ON l.Entity_ID = pe.ID  
    WHERE   l.Hierarchy_ID = @DerivedHierarchy_ID  
        AND l.LevelNumber = @LevelNumber  
  
    IF @LevelType IS NULL OR @LevelType NOT IN (@ForeignType_DBA, @ForeignType_ManyToMany)  
    BEGIN  
        RAISERROR('MDSERR300038|The supplied derived hierarchy level is not valid.', 16, 1);  
        RETURN;  
    END  
  
    IF EXISTS(SELECT 1 FROM @OldParentChildIds WHERE ChildId IS NULL OR ChildId = @GuidEmpty)  
    BEGIN  
        RAISERROR('MDSERR300040|Child ID is required.', 16, 1);  
        RETURN;  
    END   
  
    IF @NewParentID IS NOT NULL  
    BEGIN  
        -- Lookup parent code  
        SET @SQL = CONCAT(N'  
SELECT TOP 1 @NewParentCode = Code  
FROM mdm.', QUOTENAME(@ParentEntityTableName), N'  
WHERE   Version_ID = @Version_ID  
    AND MUID = @NewParentID  
')  
  
        EXEC sp_executesql @SQL, N'@Version_ID INT, @NewParentID UNIQUEIDENTIFIER, @NewParentCode NVARCHAR(250) OUTPUT', @Version_ID, @NewParentID, @NewParentCode OUTPUT;  
  
        IF @NewParentCode IS NULL  
        BEGIN  
            RAISERROR('MDSERR300041|The provided parent ID is not valid.', 16, 1);  
            RETURN;  
        END  
  
    END  
  
    IF @LevelType = @ForeignType_DBA  
    BEGIN  
        -- Simple case for basic one-to-many relationship, just overwrite the existing member attribute with the new parent (ignore old parent)  
        SET @SaveMode = @SaveMode_Update;  
  
        INSERT INTO @Members(RowID, MemberMUID)  
        SELECT   
             CONVERT(INT, ROW_NUMBER() OVER(ORDER BY (SELECT NULL/*order doesn't matter*/)))  
            ,ChildId  
        FROM @OldParentChildIds  
  
        INSERT INTO @MemberAttributes(MemberRowID, AttributeID, AttributeValue)  
        SELECT  
             RowID  
            ,@ParentAttribute_ID  
            ,@NewParentCode  
        FROM @Members  
  
    END ELSE  
    BEGIN  
        -- M2M level, need to change the mapping entity  
        DECLARE   
             @MappingViewName           SYSNAME = mdm.udfViewNameGet(@Model_ID, @Entity_ID, @MemberType_Leaf, 0, 0)  
            ,@CodeGenEnabled            BIT = CASE WHEN EXISTS(SELECT 1 FROM mdm.tblCodeGenInfo cg WHERE EntityId = @Entity_ID) THEN 1 ELSE 0 END  
  
        -- Lookup the mapping entity rows to update or insert  
        CREATE TABLE #MappingRows  
        (  
             RowNumber          INT IDENTITY(1,1) PRIMARY KEY  
            ,MappingMemberId    UNIQUEIDENTIFIER  
            ,MappingMemberCode  NVARCHAR(250) COLLATE DATABASE_DEFAULT  
            ,ChildId            UNIQUEIDENTIFIER  
            ,ChildCode          NVARCHAR(250) COLLATE DATABASE_DEFAULT -- only populated for new mapping table rows  
            ,ParentId           UNIQUEIDENTIFIER  
        )  
        CREATE INDEX #ix_MappingRows_ParentId_ChildId_MappingMemberId ON #MappingRows(ParentId, ChildId, MappingMemberId);  
  
        INSERT INTO #MappingRows (ChildId, ParentId)  
        SELECT   
             ChildId  
            ,NULLIF(ParentId, @GuidEmpty)  
        FROM @OldParentChildIds  
  
        SET @SQL = CONCAT(N'  
-- Look for existing rows to be updated  
UPDATE mr  
SET MappingMemberId = v.MUID  
FROM #MappingRows mr  
INNER JOIN mdm.', QUOTENAME(@MappingViewName), N' v  
ON      mr.ChildId = v.', QUOTENAME(@ManyToManyChildAttributeName + N'.MUID'), N'  
    AND (   mr.ParentId IS NULL AND v.', QUOTENAME(@ParentAttributeName + N'.MUID'), N' IS NULL  
         OR mr.ParentId = v.', QUOTENAME(@ParentAttributeName + N'.MUID'), N')  
WHERE v.Version_ID = @Version_ID');  
        EXEC sp_executesql @SQL, N'@Version_ID INT', @Version_ID;  
  
        -- Throw error for any rows with non-empty parent ID that wasn't found  
        DECLARE   
             @NotFoundChildId UNIQUEIDENTIFIER  
            ,@NotFoundParentId UNIQUEIDENTIFIER  
        SELECT TOP 1   
             @NotFoundChildId = ChildId  
            ,@NotFoundParentId = ParentId  
        FROM #MappingRows   
        WHERE   ParentId IS NOT NULL   
            AND MappingMemberId IS NULL  
  
        IF @NotFoundParentId IS NOT NULL  
        BEGIN  
            DECLARE @ErrorMessage NVARCHAR(MAX) = CONCAT('MDSERR300039|Could not find a mapping relationship between parent {0} and child {1}.|', @NotFoundParentId, N'|', @NotFoundChildId);  
            RAISERROR(@ErrorMessage, 16, 1)  
            RETURN;  
        END  
  
        DECLARE   
             @AddingMembers     BIT = CASE WHEN EXISTS(SELECT 1 FROM #MappingRows WHERE MappingMemberId IS NULL) THEN 1 ELSE 0 END  
            ,@UpdatingMembers   BIT = CASE WHEN EXISTS(SELECT 1 FROM #MappingRows WHERE MappingMemberId IS NOT NULL) THEN 1 ELSE 0 END  
          
        SET @SaveMode = CASE  
            WHEN    @AddingMembers = 1   
                AND @UpdatingMembers = 1 THEN   @SaveMode_Merge  
            WHEN @AddingMembers = 1 THEN        @SaveMode_Create  
            ELSE                                @SaveMode_Update  
            END;  
  
        IF @AddingMembers = 1  
        BEGIN  
            IF @CodeGenEnabled = 0  
                BEGIN  
                UPDATE #MappingRows  
                SET MappingMemberCode = CONVERT(NVARCHAR(250), NEWID())-- use a Guid as the Code for the new member of the mapping entity, to ensure uniqueness  
                WHERE MappingMemberId IS NULL  
            END  
  
            -- Lookup child member Code for the new mapping rows.  
            SELECT @SQL = CONCAT(N'  
UPDATE mr  
SET ChildCode = c.Code  
FROM #MappingRows mr  
INNER JOIN mdm. ', QUOTENAME(e.EntityTable), N' c  
ON      mr.ChildId = c.MUID  
    AND c.Version_ID = @Version_ID  
WHERE mr.MappingMemberId IS NULL -- new row  
            ')  
            FROM mdm.tblEntity e  
            INNER JOIN mdm.tblAttribute a  
            ON e.ID = a.DomainEntity_ID  
            WHERE a.ID = @ManyToManyChildAttribute_ID;  
              
            EXEC sp_executesql @SQL, N'@Version_ID INT', @Version_ID;  
  
            IF EXISTS(SELECT 1 FROM #MappingRows   
                      WHERE MappingMemberId IS NULL  
                        AND ChildCode IS NULL)  
            BEGIN  
                RAISERROR('MDSERR300042|The provided child ID is not valid.', 16, 1);  
                RETURN;  
            END  
  
            INSERT INTO @MemberAttributes(MemberRowID, AttributeID, AttributeValue)  
            SELECT  
                 RowNumber  
                ,@ManyToManyChildAttribute_ID  
                ,ChildCode  
            FROM #MappingRows  
            WHERE MappingMemberId IS NULL  
        END  
  
  
        INSERT INTO @Members(RowID, MemberMUID, MemberCode)  
        SELECT   
             RowNumber  
            ,MappingMemberId  
            ,MappingMemberCode  
        FROM #MappingRows  
  
        INSERT INTO @MemberAttributes(MemberRowID, AttributeID, AttributeValue)  
        SELECT  
             RowNumber  
            ,@ParentAttribute_ID  
            ,@NewParentCode  
        FROM #MappingRows  
  
    END  
  
    EXEC mdm.udpEntityMembersSave  
         @User_ID = @User_ID  
        ,@Model_ID = @Model_ID  
        ,@Entity_ID = @Entity_ID  
        ,@Version_ID = @Version_ID  
        ,@MemberType_ID = @MemberType_Leaf  
        ,@Members = @Members  
        ,@MemberAttributes = @MemberAttributes  
        ,@SaveMode = @SaveMode  
        ,@TransactionBehavior = @TransactionBehavior_AllOrNothingByBatch -- If any of the given member changes has an error, ignore all changes to all members (not just those with errors) in this batch. I.e, abort the whole batch if any errors are found.  
        ,@LogFlag = 1  
        ,@DoInheritanceRuleCheck = 1  
        ,@CorrelationID = @CorrelationID  
  
    SET NOCOUNT OFF;  
END; --proc
go

