/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
    SELECT * FROM mdm.viw_SYSTEM_SECURITY_ROLE_ACCESSCONTROL   
  
*/  
CREATE VIEW mdm.viw_SYSTEM_SECURITY_ROLE_ACCESSCONTROL  
/*WITH SCHEMABINDING*/  
AS  
SELECT  
     ra.ID      RoleAccess_ID  
    ,ra.MUID    RoleAccess_MUID  
    ,ra.Role_ID  
    ,ac.Principal_ID  
    ,CASE ac.PrincipalType_ID WHEN 1 THEN u.MUID ELSE ug.MUID END AS Principal_MUID  
    ,ac.PrincipalType_ID  
    ,CASE ac.PrincipalType_ID WHEN 1 THEN u.UserName ELSE ug.Name END AS Principal_Name  
    ,ra.[Object_ID]  
    ,ra.Model_ID  
    ,mdl.MUID Model_MUID  
    ,mdl.Name Model_Name  
    ,CASE modSecUsr.Privilege_ID WHEN 5 /*Admin*/ THEN 1 ELSE 0 END IsModelAdministrator  
    ,ra.Securable_ID  
    ,CASE   
        WHEN ra.Object_ID = 1 THEN --Model  
            (SELECT MUID FROM mdm.tblModel WHERE ID = ra.Securable_ID)  
        WHEN ra.Object_ID = 3 OR ra.Object_ID = 8 OR ra.Object_ID = 9 OR ra.Object_ID = 10 THEN --Entity  
            (SELECT MUID FROM mdm.tblEntity WHERE ID = ra.Securable_ID)  
        WHEN ra.Object_ID = 4 THEN --Attribute  
            (SELECT MUID FROM mdm.tblAttribute WHERE ID = ra.Securable_ID)  
        WHEN ra.Object_ID = 5 THEN --Attribute Group  
            (SELECT MUID FROM mdm.tblAttributeGroup WHERE ID = ra.Securable_ID)  
        END Securable_MUID  
    ,mdm.udfSecurableNameGetByObjectID(ra.Object_ID, ra.Securable_ID) Securable_Name  
    ,ra.Privilege_ID  
    ,ra.AccessPermission  
    ,ra.EnterUserID  
    ,eu.MUID AS EnterUserMUID  
    ,eu.DisplayName EnterUserName  
    ,ra.EnterDTM  
    ,ra.LastChgUserID  
    ,lcu.MUID AS LastChgUserMUID  
    ,lcu.DisplayName AS LastChgUserName  
    ,ra.LastChgDTM  
FROM mdm.tblSecurityRole r  
INNER JOIN mdm.tblSecurityAccessControl ac   
ON r.ID = ac.Role_ID  
INNER JOIN mdm.tblSecurityRoleAccess ra  
ON ra.Role_ID = r.ID  
INNER JOIN  mdm.tblModel mdl  
ON ra.Model_ID = mdl.ID  
  
-- Get user ModelAdmin status.  
LEFT JOIN mdm.viw_SYSTEM_SECURITY_USER_MODEL modSecUsr  
ON      ac.PrincipalType_ID = 1/*User*/  
    AND ac.Principal_ID = modSecUsr.User_ID  
    AND mdl.ID = modSecUsr.ID  
  
LEFT JOIN mdm.tblUser eu   
ON ra.EnterUserID = eu.ID  
LEFT JOIN mdm.tblUser lcu   
ON ra.LastChgUserID = lcu.ID  
LEFT JOIN mdm.tblUserGroup ug   
ON      ac.PrincipalType_ID = 2/*Group*/   
    AND ac.Principal_ID = ug.ID  
LEFT JOIN mdm.tblUser u   
ON      ac.PrincipalType_ID = 1/*User*/   
    AND ac.Principal_ID = u.ID
go

