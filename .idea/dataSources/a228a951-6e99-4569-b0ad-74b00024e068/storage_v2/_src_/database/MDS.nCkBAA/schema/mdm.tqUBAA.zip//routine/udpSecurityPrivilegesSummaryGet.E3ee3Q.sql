/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
EXEC mdm.udpSecurityPrivilegesSummaryGet 118,1,1,0  
EXEC mdm.udpSecurityPrivilegesSummaryGet 1,1,2,1  
EXEC mdm.udpSecurityPrivilegesSummaryGet 118,27,1,1  
*/  
CREATE PROCEDURE mdm.udpSecurityPrivilegesSummaryGet  
(  
     @SystemUser_ID     INT  
    ,@Principal_ID      INT  
    ,@PrincipalType_ID  TINYINT  
    ,@ResolutionType    TINYINT  
    ,@CorrelationID     UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    DECLARE  
         @PrincipalType_Group           TINYINT = 2  
  
        ,@ResolutionType_UserAndGroup   TINYINT = 0  
        ,@ResolutionType_User           TINYINT = 1  
        ,@ResolutionType_Effective      TINYINT = 2  
  
        ,@MemberType_Leaf               TINYINT = 1  
        ,@MemberType_Consolidated       TINYINT = 2  
        ,@MemberType_Collection         TINYINT = 3  
        ;  
    IF (@PrincipalType_ID = @PrincipalType_Group AND @ResolutionType = @ResolutionType_Effective)  
    BEGIN  
        SET @ResolutionType = @ResolutionType_User;  
    END;  
  
    DECLARE @IncludeGroupAssignments BIT = (CASE @ResolutionType WHEN @ResolutionType_User THEN 0 ELSE 1 END)  
  
    IF (@ResolutionType = @ResolutionType_Effective)  
    BEGIN  
        WITH privileges AS(  
            SELECT  
                modelSec.Privilege_ID,  
                modelSec.AccessPermission,  
                1 /*Model*/ AS Object_ID,  
                model.ID AS Securable_ID,  
                model.MUID AS Securable_MUID,  
                QUOTENAME(model.Name) AS Securable_Name,  
                model.ID AS Model_ID,  
                model.MUID AS Model_MUID,  
                model.Name AS Model_Name,  
                CASE modelSec.Privilege_ID WHEN 5 /*Admin*/ THEN 1 ELSE 0 END AS IsModelAdministrator  
            FROM mdm.viw_SYSTEM_SECURITY_USER_MODEL AS modelSec  
            INNER JOIN mdm.tblModel AS model  
            ON modelSec.ID = model.ID  
            WHERE User_ID = @Principal_ID  
                AND modelSec.Privilege_ID <> 1 /*Deny*/  
            UNION ALL  
            SELECT  
                entitySec.Privilege_ID,  
                entitySec.AccessPermission,  
                3 /*Entity*/ AS Object_ID,  
                entity.ID AS Securable_ID,  
                entity.MUID AS Securable_MUID,  
                CONCAT(QUOTENAME(model.Name), N':', QUOTENAME(entity.Name)) AS Securable_Name,  
                model.ID AS Model_ID,  
                model.MUID AS Model_MUID,  
                model.Name AS Model_Name,  
                CASE entitySec.Privilege_ID WHEN 5 /*Admin*/ THEN 1 ELSE 0 END AS IsModelAdministrator  
            FROM mdm.viw_SYSTEM_SECURITY_USER_ENTITY AS entitySec  
            INNER JOIN mdm.tblEntity AS entity  
            ON entitySec.ID = entity.ID  
            INNER JOIN mdm.tblModel AS model  
            ON entity.Model_ID = model.ID  
            WHERE User_ID = @Principal_ID  
                AND entitySec.Privilege_ID <> 1 /*Deny*/  
            UNION ALL  
            SELECT  
                mtSec.Privilege_ID,  
                mtSec.AccessPermission,  
                mtSec.ID + 7 /*MemberType*/ AS Object_ID,  
                entity.ID AS Securable_ID,  
                entity.MUID AS Securable_MUID,  
                CONCAT(QUOTENAME(model.Name), N':', QUOTENAME(entity.Name), N':', QUOTENAME(  
                CASE mtSec.ID  
                    WHEN @MemberType_Leaf THEN N'Leaf'  
                    WHEN @MemberType_Consolidated THEN N'Consolidated'  
                    WHEN @MemberType_Collection THEN N'Collection'  
                END)) AS Securable_Name,  
                model.ID AS Model_ID,  
                model.MUID AS Model_MUID,  
                model.Name AS Model_Name,  
                mtSec.IsAdmin AS IsModelAdministrator  
            FROM mdm.viw_SYSTEM_SECURITY_USER_MEMBERTYPE AS mtSec  
            INNER JOIN mdm.tblEntity AS entity  
            ON mtSec.Entity_ID = entity.ID  
            INNER JOIN mdm.tblModel AS model  
            ON entity.Model_ID = model.ID  
            WHERE User_ID = @Principal_ID  
                AND mtSec.Privilege_ID <> 1 /*Deny*/  
            UNION ALL  
            SELECT  
                attSec.Privilege_ID,  
                attSec.AccessPermission,  
                4 /*Attribute*/ AS Object_ID,  
                att.ID AS Securable_ID,  
                att.MUID AS Securable_MUID,  
                CONCAT(QUOTENAME(model.Name), N':', QUOTENAME(entity.Name), N':', QUOTENAME(  
                CASE att.MemberType_ID  
                    WHEN @MemberType_Leaf THEN N'Leaf'  
                    WHEN @MemberType_Consolidated THEN N'Consolidated'  
                    WHEN @MemberType_Collection THEN N'Collection'  
                END), N':', QUOTENAME(att.Name))  AS Securable_Name ,  
                model.ID AS Model_ID,  
                model.MUID AS Model_MUID,  
                model.Name AS Model_Name,  
                attSec.IsAdmin AS IsModelAdministrator  
            FROM mdm.viw_SYSTEM_SECURITY_USER_ATTRIBUTE AS attSec  
            INNER JOIN mdm.tblAttribute AS att  
            ON attSec.ID = att.ID  
            INNER JOIN mdm.tblEntity AS entity  
            ON att.Entity_ID = entity.ID  
            INNER JOIN mdm.tblModel AS model  
            ON entity.Model_ID = model.ID  
            WHERE User_ID = @Principal_ID  
        )  
        SELECT  
             NULL AS RoleAccess_ID  
            ,NULL AS RoleAccess_MUID  
            ,Privilege_ID  
            ,AccessPermission  
            ,Object_ID  
            ,Securable_ID  
            ,Securable_MUID  
            ,Securable_Name  
            ,Model_ID  
            ,Model_MUID  
            ,Model_Name  
            ,IsModelAdministrator  
            ,@PrincipalType_ID AS PrincipalType_ID  
            ,@Principal_ID AS Principal_ID  
            ,NULL AS Principal_MUID  
            ,NULL AS Principal_Name  
            ,NULL AS EnterUserID  
            ,NULL AS EnterUserMUID  
            ,NULL AS EnterUserName  
            ,NULL AS EnterDTM  
            ,NULL AS LastChgUserID  
            ,NULL AS LastChgUserMUID  
            ,NULL AS LastChgUserName  
            ,NULL AS LastChgDTM  
    FROM privileges  
    END -- If getting effective permissions.  
    ELSE  
    BEGIN  
        -- Get all permissions assigned to the user.  
       SELECT *  
       FROM mdm.udfSecurityUserExplicitPermissions(@SystemUser_ID, @Principal_ID, @PrincipalType_ID, @IncludeGroupAssignments)  
       ORDER BY Securable_Name  
    END  
  
    SET NOCOUNT OFF  
END --proc
go

