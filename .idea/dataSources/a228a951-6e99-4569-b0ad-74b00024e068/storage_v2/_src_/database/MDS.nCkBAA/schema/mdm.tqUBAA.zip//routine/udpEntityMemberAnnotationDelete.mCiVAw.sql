/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
This can be called to delete Annotations  
EXEC mdm.udpEntityMemberAnnotationDelete @User_ID = 1, @Model_Name = N'Product', @Entity_Name = N'Product', @Version_Name = N'Version 1', @MemberType_ID= 1, @Annotation_ID = 1;  
*/  
CREATE PROCEDURE mdm.udpEntityMemberAnnotationDelete  
(  
    @User_ID        INT,  
    @Model_Name     NVARCHAR(50) = NULL,  
    @Model_MUID     UNIQUEIDENTIFIER = NULL,  
    @Entity_Name    NVARCHAR(50) = NULL,  
    @Entity_MUID    UNIQUEIDENTIFIER= NULL,  
    @Version_Name   NVARCHAR(50) = NULL,  
    @Version_MUID   UNIQUEIDENTIFIER = NULL,  
    @MemberType_ID  TINYINT,  
    @Annotation_ID  INT,  
    @CorrelationID  UNIQUEIDENTIFIER = NULL -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    DECLARE @GuidEmpty              UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER),  
            @Model_ID               INT,  
            @Entity_ID              INT,  
            @Version_ID             INT,  
            @Owner_ID               INT,  
            @AnnotationTableName    SYSNAME,  
            @SQL                    NVARCHAR(MAX);  
  
   SELECT   
        @Model_MUID = NULLIF(@Model_MUID, @GuidEmpty),  
        @Model_Name = NULLIF(LTRIM(RTRIM(@Model_Name)), N''),  
        @Entity_MUID = NULLIF(@Entity_MUID, @GuidEmpty),  
        @Entity_Name = NULLIF(LTRIM(RTRIM(@Entity_Name)), N''),  
        @Version_MUID = NULLIF(@Version_MUID, @GuidEmpty),  
        @Version_Name = NULLIF(LTRIM(RTRIM(@Version_Name)), N'');  
  
    IF @User_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR100009|The User ID is not valid.', 16, 1);  
        RETURN;  
    END  
  
    IF @MemberType_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR210021|MemberType ID is not valid.', 16, 1);  
        RETURN;  
    END  
  
    IF @Annotation_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR310032|Annotation ID are not valid.', 16, 1);  
        RETURN;  
    END  
  
    EXEC mdm.udpInformationLookupModel @User_ID = @User_ID, @Model_MUID = @Model_MUID, @Model_Name = @Model_Name, @ID = @Model_ID OUTPUT ;  
    IF @Model_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300005|The supplied model is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    SELECT @Version_ID = ID  
    FROM mdm.tblModelVersion   
    WHERE  
            (@Version_MUID IS NOT NULL OR @Version_Name IS NOT NULL)   
        AND (@Version_MUID IS NULL OR MUID = @Version_MUID)   
        AND (@Version_Name IS NULL OR Name = @Version_Name)  
        AND Model_ID = @Model_ID;  
    IF @Version_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300006|The supplied version is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    EXEC mdm.udpInformationLookupEntity @User_ID = @User_ID, @Model_ID = @Model_ID, @Entity_MUID = @Entity_MUID, @Entity_Name = @Entity_Name, @ID = @Entity_ID OUTPUT;  
    IF @Entity_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300008|The supplied entity is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    SET @AnnotationTableName = CONCAT(mdm.udfTableNameGetByID(@Entity_ID, @MemberType_ID), N'_AN');  
  
    SET @SQL = CONCAT(N'  
        SELECT @Owner_ID = [EnterUserID]  
        FROM [mdm].', QUOTENAME(@AnnotationTableName), N'  
        WHERE Version_ID = @VersionID AND ID = @Annotation_ID');  
    EXEC sp_executesql @SQL, N'@VersionID INT, @Annotation_ID INT, @Owner_ID INT OUTPUT', @Version_ID, @Annotation_ID, @Owner_ID = @Owner_ID OUTPUT;  
    IF @Owner_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR310032|The annotation ID is not valid.', 16, 1);  
        RETURN;  
    END  
  
    IF @User_ID != @Owner_ID AND NOT EXISTS(  
        SELECT 1 FROM [mdm].[viw_SYSTEM_SECURITY_USER_MODEL] WHERE [User_ID] = @User_ID AND Privilege_ID = 5 /*Admin*/  
    )  
    BEGIN  
        RAISERROR('MDSERR120002|The user does not have permission to perform this operation.', 16, 1);  
        RETURN;  
    END  
  
    SET @SQL = CONCAT(N'DELETE [mdm].', QUOTENAME(@AnnotationTableName), N' WHERE Version_ID = @VersionID AND ID = @Annotation_ID');  
    EXEC sp_executesql @SQL, N'@VersionID INT, @Annotation_ID INT', @Version_ID, @Annotation_ID;  
END --proc
go

