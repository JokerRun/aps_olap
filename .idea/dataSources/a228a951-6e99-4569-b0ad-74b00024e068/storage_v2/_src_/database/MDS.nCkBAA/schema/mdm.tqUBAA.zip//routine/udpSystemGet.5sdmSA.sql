/*  
    Gets the record from tblSystem  
*/  
/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpSystemGet  
(  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    DECLARE @NeedsRepair    BIT = 1,  
            @DbName         NVARCHAR(MAX)  
  
    SET @DbName = DB_NAME()  
  
    -- A DB does not need repair if has both the broker enabled and trustworthy on  
    SELECT @NeedsRepair = 0 from sys.databases where name=@DbName AND is_broker_enabled=1 and is_trustworthy_on=1  
  
    SELECT TOP 1 [ID]  
      ,[SchemaVersion]  
      ,@@VERSION as [SQLServerVersion]  
      ,[EnterDTM]  
      ,[EnterUserID]  
      ,[LastChgUserID]  
      ,[LastChgDTM]  
      ,@NeedsRepair AS NeedsRepair  
       ,(select  
            compatibility_level  
         from sys.databases  
            where name = @DbName) as [CompatibilityLevel]  
    FROM [mdm].[tblSystem]  
    ORDER BY [ID]  
  
    SET NOCOUNT OFF  
END --proc
go

