/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    SELECT * FROM mdm.viw_SYSTEM_SECURITY_USER_MODEL;  
*/  
CREATE VIEW mdm.viw_SYSTEM_SECURITY_USER_MODEL  
/*WITH SCHEMABINDING*/  
AS  
WITH superUsersCte AS  
(  
    SELECT DISTINCT User_ID  
    FROM mdm.viw_SYSTEM_SECURITY_USER_FUNCTION  
    WHERE Function_ID = 6 -- Super User  
)  
,users AS  
(  
    SELECT   
         u.ID User_ID  
        ,CASE WHEN su.User_ID IS NULL THEN 0 ELSE 1 END IsSuperUser  
    FROM mdm.tblUser u  
    LEFT JOIN superUsersCte su  
    ON u.ID = su.User_ID  
    WHERE u.Status_ID = 1 -- Active  
)  
,allPermissions AS  
(  
    SELECT  
         u.User_ID  
        ,model.ID ID  
        ,Privilege_ID =  
            CASE  
                WHEN u.IsSuperUser = 1 THEN -5 /*-Admin, use -5 to make sure Admin won over Deny 1 and Access 4*/   
                WHEN ssu.Model_PrivilegeID = 5 /*Admin*/ THEN -5 /*-Admin*/  
                ELSE ssu.Model_PrivilegeID  
            END  
        ,AccessPermission =  
            CASE  
                WHEN u.IsSuperUser = 1 THEN 0  
                ELSE ssu.Model_AccessPermission  
            END  
    FROM mdm.tblModel model  
    CROSS JOIN users u  
    LEFT JOIN mdm.viw_SYSTEM_SECURITY_USER ssu  
    ON      u.[User_ID] = ssu.[User_ID]   
        AND model.ID = ssu.Model_ID   
        AND u.IsSuperUser = 0  
)  
,combinedPermissions AS  
(  
    SELECT  
         [User_ID]  
        ,ID  
        ,ABS(MIN(Privilege_ID)) Privilege_ID -- Reset -Admin -5 to Admin 5  
        ,SUM(Distinct(AccessPermission & 0x1)) +  
            SUM(Distinct(AccessPermission & 0x2)) +  
            SUM(Distinct(AccessPermission & 0x4)) AS AccessPermission  
    FROM allPermissions  
    WHERE Privilege_ID IS NOT NULL  
    GROUP BY  
         [User_ID]  
        ,ID  
)  
SELECT  
     [User_ID]  
    ,ID  
    ,Privilege_ID  
    ,CASE Privilege_ID WHEN 4 /*Access*/ THEN AccessPermission ELSE NULL END AccessPermission  
FROM combinedPermissions
go

