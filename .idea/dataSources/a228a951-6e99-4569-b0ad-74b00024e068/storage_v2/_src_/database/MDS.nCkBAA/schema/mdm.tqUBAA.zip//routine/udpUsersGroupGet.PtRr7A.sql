/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Gets information about the groups to which the given users belong.  
  
*/  
CREATE PROCEDURE mdm.udpUsersGroupGet  
(  
     @UserIds        mdm.IdList READONLY  
    ,@CorrelationID  UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    -- Load the user IDs into an indexed table var, for faster join perf.  
    DECLARE @UserIdTable TABLE(User_ID INT PRIMARY KEY);  
    INSERT INTO @UserIdTable(User_ID)  
    SELECT DISTINCT ID   
    FROM @UserIds;  
  
    -- Get info on the groups to which the user(s) belong.  
    SELECT   
         ug.User_ID  
        ,ug.UserGroup_ID  
        ,ug.UserGroup_MUID  
        ,ug.UserGroup_Name  
    FROM mdm.viw_SYSTEM_USERGROUP_USERS ug  
    INNER JOIN @UserIdTable u  
    ON ug.User_ID = u.User_ID  
    ORDER BY   
         ug.User_ID -- Sorting by user will make processing the results more efficient.  
        ,ug.UserGroup_Name -- Sorting the groups alphabetically will make the results cleaner.  
  
    SET NOCOUNT OFF  
END --proc
go

