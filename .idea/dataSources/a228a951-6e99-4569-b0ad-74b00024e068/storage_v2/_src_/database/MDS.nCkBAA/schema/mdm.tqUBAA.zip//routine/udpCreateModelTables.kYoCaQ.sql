/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
EXEC mdm.udpCreateModelTables @Model_ID = 2;  
  
*/  
CREATE PROCEDURE mdm.udpCreateModelTables  
(  
    @Model_ID    INT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON;  
  
    --Start transaction, being careful to check if we are nested  
    DECLARE @SQL                            NVARCHAR(MAX),  
            @ChangesetTable                 SYSNAME,  
            @TransactionTableName           SYSNAME,  
            @AnnotationTableName            SYSNAME,  
            @ValidationLogTableName         SYSNAME,  
  
            @TableOptions                   NVARCHAR(MAX) = N'',  
            @IndexOptions                   NVARCHAR(MAX) = N'';  
  
    --Set up table and view names  
    SET @ChangesetTable = CONCAT(N'tbl_', @Model_ID, N'_CS');  
    SET @TransactionTableName = mdm.udfGetTransactionTableName(@Model_ID);  
    SET @AnnotationTableName = mdm.udfGetTransactionAnnotationTableName(@Model_ID);  
    SET @ValidationLogTableName = mdm.udfGetValidationLogTableName(@Model_ID);  
    SET @TableOptions = mdm.udfGetTableOptions(1, @Model_ID);  
    SET @IndexOptions = mdm.udfGetIndexOptions(1, @Model_ID);  
  
    --Create the Workflow Instance (_CS) table  
    SET @SQL = CONCAT(N'  
    CREATE TABLE mdm.', QUOTENAME(@ChangesetTable), N'  
    (  
        Version_ID          INT NOT NULL,  
        ID                  INT IDENTITY(1, 1) NOT NULL,  
        Entity_ID           INT NOT NULL,  
  
        Name                NVARCHAR(250) NULL,  
        Description         NVARCHAR(500) NULL,  
        Status              TINYINT NOT NULL,  
  
        --Auditing  
        EnterDTM            DATETIME2(3) NOT NULL CONSTRAINT ', QUOTENAME(N'df_' + @ChangesetTable  + N'_EnterDTM'), N' DEFAULT GETUTCDATE(),  
        EnterUserID         INT NOT NULL,  
        LastChgDTM          DATETIME2(3) NOT NULL CONSTRAINT ', QUOTENAME(N'df_' + @ChangesetTable  + N'_LastChgDTM'), N' DEFAULT GETUTCDATE(),  
        LastChgUserID       INT NOT NULL,  
        MUID                UNIQUEIDENTIFIER NOT NULL CONSTRAINT ', QUOTENAME(N'df_' + @ChangesetTable + N'_MUID'), N' DEFAULT NEWID(),  
  
        --Create PRIMARY KEY constraint  
        CONSTRAINT ', QUOTENAME(N'pk_' + @ChangesetTable), N'  
            PRIMARY KEY CLUSTERED (Version_ID, ID)  
    )  
    ', @TableOptions, N';  
  
    CREATE NONCLUSTERED INDEX ', QUOTENAME(N'ix_' + @ChangesetTable + N'_Version_ID_Name'), N'  
        ON mdm.', QUOTENAME(@ChangesetTable), N'(Version_ID, Name)  
        ', @IndexOptions, N';  
  
    CREATE NONCLUSTERED INDEX ', QUOTENAME(N'ix_' + @ChangesetTable + N'_Version_ID_Entity_ID_EnterUserID'), N'  
        ON mdm.', QUOTENAME(@ChangesetTable), N'(Version_ID, Entity_ID, EnterUserID)  
        ', @IndexOptions, N';  
    ');  
  
    --PRINT @SQL;  
    EXEC sp_executesql @SQL;  
  
    --Create the transaction table  
    SET @SQL = CONCAT(N'  
    CREATE TABLE [mdm].', QUOTENAME(@TransactionTableName), N'  
    (  
        [Version_ID]                INT NOT NULL,  
        [ID]                        INT IDENTITY(1,1) NOT NULL,  
        [TransactionType_ID]        INT NOT NULL,  
        [OriginalTransaction_ID]    INT NULL,  
        [Hierarchy_ID]              INT NULL,  
        [Entity_ID]                 INT NULL,  
        [Attribute_ID]              INT NULL,  
        [Member_ID]                 INT NOT NULL,  
        [Member_MUID]               UNIQUEIDENTIFIER NOT NULL,  
        [MemberType_ID]             TINYINT NOT NULL,  
        [MemberCode]                NVARCHAR(250) NULL,  
        [OldValue]                  NVARCHAR(MAX) NULL,  
        [OldCode]                   NVARCHAR(MAX) NULL,  
        [NewValue]                  NVARCHAR(MAX) NULL,  
        [NewCode]                   NVARCHAR(MAX) NULL,  
        [Batch_ID]                  INT NULL,  
        [EnterDTM]                  DATETIME2(3) NOT NULL CONSTRAINT '+ QUOTENAME(N'df_' + @TransactionTableName + N'_EnterDTM'), N' DEFAULT GETUTCDATE(),  
        [EnterUserID]               INT NOT NULL,  
        [LastChgDTM]                DATETIME2(3) NOT NULL CONSTRAINT ', QUOTENAME(N'df_' + @TransactionTableName + N'_LastChgDTM'), N' DEFAULT GETUTCDATE(),  
        [LastChgUserID]             INT NOT NULL,  
  
        --Create PRIMARY KEY constraint  
        CONSTRAINT ', QUOTENAME(N'pk_' + @TransactionTableName), N'  
            PRIMARY KEY CLUSTERED (Version_ID, ID)  
    )', @TableOptions, N';  
  
    CREATE NONCLUSTERED INDEX ', QUOTENAME(N'ix_' + @TransactionTableName + N'_MemberType_ID'), N'  
        ON mdm.', QUOTENAME(@TransactionTableName), N'(MemberType_ID)  
        ', @IndexOptions, N';  
  
    CREATE NONCLUSTERED INDEX ', QUOTENAME(N'ix_' + @TransactionTableName + N'_Attribute_ID'), N'  
        ON mdm.', QUOTENAME(@TransactionTableName), N'(Attribute_ID)  
        ', @IndexOptions, N';  
  
    CREATE NONCLUSTERED INDEX ', QUOTENAME(N'ix_' + @TransactionTableName + N'_Entity_ID'), N'  
        ON mdm.', QUOTENAME(@TransactionTableName), N'(Entity_ID)  
        ', @IndexOptions, N';  
  
    CREATE NONCLUSTERED INDEX ', QUOTENAME(N'ix_' + @TransactionTableName + N'_Hierarchy_ID'), N'  
        ON mdm.', QUOTENAME(@TransactionTableName), N'(Hierarchy_ID)  
        ', @IndexOptions, N';  
  
    CREATE NONCLUSTERED INDEX ', QUOTENAME(N'ix_' + @TransactionTableName + N'_TransactionType_ID'), N'  
        ON mdm.', QUOTENAME(@TransactionTableName), N'(TransactionType_ID)  
        ', @IndexOptions, N';  
    ');  
    --PRINT @SQL;  
    EXEC sp_executesql @SQL;  
  
    --Create the annotation table  
    SET @SQL = CONCAT(N'  
    CREATE TABLE [mdm].', QUOTENAME(@AnnotationTableName), N'  
    (  
        [Version_ID]        INT NOT NULL,  
        [ID]                INT IDENTITY (1, 1) NOT NULL,  
        [Transaction_ID]    INT NOT NULL,  
        [Comment]           NVARCHAR(500) NULL,  
        [EnterUserID]       INT NOT NULL,  
        [EnterDTM]          DATETIME2(3) NOT NULL CONSTRAINT ', QUOTENAME(N'df_' + @AnnotationTableName + N'_EnterDTM'), N' DEFAULT GETUTCDATE(),  
        [LastChgDTM]        DATETIME2(3) NOT NULL CONSTRAINT ', QUOTENAME(N'df_' + @AnnotationTableName + N'_LastChgDTM'), N' DEFAULT GETUTCDATE(),  
        [LastChgUserID]     INT NOT NULL,  
  
        --Create PRIMARY KEY constraint  
        CONSTRAINT ', QUOTENAME(N'pk_' + @AnnotationTableName), N'  
            PRIMARY KEY CLUSTERED (Version_ID, ID),  
  
        --Create FOREIGN KEY constraints  
        CONSTRAINT ', QUOTENAME(N'fk_' + @AnnotationTableName + N'_' + @TransactionTableName + N'_Version_ID_Transaction_ID'), N'  
            FOREIGN KEY(Version_ID, Transaction_ID) REFERENCES [mdm].', QUOTENAME(@TransactionTableName), N' (Version_ID, ID)  
            ON UPDATE NO ACTION  
            ON DELETE CASCADE  
    )', @TableOptions, N';  
  
    CREATE NONCLUSTERED INDEX ', QUOTENAME(N'ix_' + @AnnotationTableName + N'_Version_ID_Transaction_ID'), N'  
        ON mdm.', QUOTENAME(@AnnotationTableName), N'(Version_ID, Transaction_ID)  
        ', @IndexOptions, N';  
    ');  
    EXEC sp_executesql @SQL;  
  
    --Create the validation log table  
    SET @SQL = CONCAT(N'  
    CREATE TABLE [mdm].', QUOTENAME(@ValidationLogTableName), N'  
    (  
        [ID]                    [INT] IDENTITY (1, 1)    NOT NULL,  
        [Status_ID]             [TINYINT]                NOT NULL,  
        [Version_ID]            [INT]                    NOT NULL,  
        [Hierarchy_ID]          [INT]                    NOT NULL,  
        [Entity_ID]             [INT]                    NOT NULL,  
        [Member_ID]             [INT]                    NOT NULL,  
        [Member_MUID]           [UNIQUEIDENTIFIER]       NOT NULL,  
        [MemberCode]            [NVARCHAR] (250)         NOT NULL,  
        [MemberType_ID]         [TINYINT]                NOT NULL,  
        [Description]           [NVARCHAR] (1000)        NOT NULL,  
        [BRBusinessRule_ID]     [INT]                    NOT NULL,  
        [BRItem_ID]             [INT]                    NOT NULL,  
        [NotificationStatus_ID] [INT]                    NOT NULL CONSTRAINT df_', @ValidationLogTableName, N'_NotificationStatus_ID DEFAULT 0,  
        [EnterDTM]              DATETIME2(3)             NOT NULL CONSTRAINT [df_', @ValidationLogTableName, N'_EnterDTM] DEFAULT GETUTCDATE(),  
        [EnterUserID]           [INT]                    NOT NULL,  
        [LastChgDTM]            DATETIME2(3)             NOT NULL CONSTRAINT [df_', @ValidationLogTableName, N'_LastChgDTM] DEFAULT GETUTCDATE(),  
        [LastChgUserID]         [INT]                    NOT NULL,  
        CONSTRAINT ck_', @ValidationLogTableName, N'_NotificationStatus_ID CHECK (NotificationStatus_ID BETWEEN 0 AND 5), --!  
        CONSTRAINT ck_', @ValidationLogTableName, N'_Status_ID CHECK (Status_ID BETWEEN 0 AND 3), --!  
        CONSTRAINT ck_', @ValidationLogTableName, N'_MemberType_ID CHECK (MemberType_ID BETWEEN 1 AND 5),  
        CONSTRAINT [pk_', @ValidationLogTableName, N'] PRIMARY KEY CLUSTERED (Version_ID, ID)  
    )', @TableOptions, N';  
  
    CREATE NONCLUSTERED INDEX [ix_', @ValidationLogTableName, N'_Version_ID_Entity_ID_Member_ID_MemberType_ID_BRBusinessRule_ID_BRItem_ID]  
    ON [mdm].', QUOTENAME(@ValidationLogTableName), N'([Version_ID] ASC, [Entity_ID] ASC, [Member_ID] ASC, [MemberType_ID] ASC, [BRBusinessRule_ID] ASC, [BRItem_ID] ASC)  
    ', @IndexOptions, N';');  
    EXEC sp_executesql @SQL;  
  
    SET NOCOUNT OFF;  
END; --proc
go

