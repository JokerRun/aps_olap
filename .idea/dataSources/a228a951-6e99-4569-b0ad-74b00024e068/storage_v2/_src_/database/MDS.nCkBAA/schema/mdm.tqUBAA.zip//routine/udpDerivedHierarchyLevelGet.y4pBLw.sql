/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpDerivedHierarchyLevelGet  
(  
     @User_ID       INT  
  
    ,@Model_MUID    UNIQUEIDENTIFIER = NULL  
    ,@Model_Name    NVARCHAR(50) = NULL  
    ,@Model_ID      INT = NULL -- set internally only  
  
    ,@HierarchyTable mdm.Identifier READONLY-- caller should ensure table does not include rows where both MUID and Name are blank  
    ,@HierarchyLevelTable mdm.Identifier READONLY-- caller should ensure table does not include rows where both MUID and Name are blank  
  
    ,@IncludeParentIdentifiers  BIT = 1 -- Return results sets for parent Model and Entity identifiers. Set to 0 when getting attributes as part of a parent object (because the parent identifiers will already have been looked up).  
    ,@Debug                     BIT = 0  
    ,@CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
  
    SET NOCOUNT ON  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': begin udpDerivedHierarchyLevelGet')  
  
    -- Get model ID  
    IF @Model_ID IS NULL -- If the ID was already provided, don't bother looking it up again  
        AND (@Model_Name IS NOT NULL OR @Model_MUID IS NOT NULL)  
    BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': lookup @Model_ID')  
        SELECT   
             @Model_ID = ID  
            ,@Model_MUID = MUID  
            ,@Model_Name = Name  
        FROM mdm.tblModel  
        WHERE   MUID = ISNULL(@Model_MUID, MUID)  
            AND Name = ISNULL(@Model_Name, Name)  
  
        SET @Model_ID = COALESCE(@Model_ID, 0)  
    END  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': getting selected derived hierarchy levels from criteria')  
    DECLARE @SelectedLevel TABLE   
    (  
         ID             INT PRIMARY KEY  
        ,Hierarchy_ID   INT  
    )  
  
    INSERT INTO @SelectedLevel  
    SELECT  
         l.ID  
        ,l.Hierarchy_ID  
    FROM mdm.viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED_LEVELS l  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_HIERARCHY_DERIVED acl  
    ON l.Hierarchy_ID = acl.ID  
    WHERE   acl.User_ID = @User_ID  
        AND l.Model_ID = ISNULL(@Model_ID, l.Model_ID)  
  
    IF EXISTS(SELECT 1 FROM @HierarchyTable)  
    BEGIN  
        -- Remove rows that don't match the hierarchy filter  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': removing rows that do not match the hierarchy table filter')  
        DELETE l  
        FROM @SelectedLevel l  
        INNER JOIN mdm.tblDerivedHierarchy h  
        ON l.Hierarchy_ID = h.ID  
        LEFT JOIN @HierarchyTable ht   
        ON      h.MUID = ISNULL(ht.MUID, h.MUID)  
            AND h.Name = ISNULL(ht.Name, h.Name)  
        WHERE (ht.MUID IS NULL AND ht.Name IS NULL)  
    END  
    IF EXISTS(SELECT 1 FROM @HierarchyLevelTable)  
    BEGIN  
        -- Remove rows that don't match the hierarchy level filter  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': removing rows that do not match the hierarchy level table filter')  
        DELETE l  
        FROM @SelectedLevel l  
        INNER JOIN mdm.tblDerivedHierarchyDetail hl  
        ON l.Hierarchy_ID = hl.DerivedHierarchy_ID  
        LEFT JOIN @HierarchyLevelTable hlt   
        ON      hl.MUID = ISNULL(hlt.MUID, hl.MUID)  
            AND hl.Name = ISNULL(hlt.Name, hl.Name)  
        WHERE (hlt.MUID IS NULL AND hlt.Name IS NULL)  
    END  
  
    IF @IncludeParentIdentifiers = 1  
    BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': returning parent identifiers')  
        -- Return model Identifier(s)  
        IF @Model_ID IS NOT NULL  
        BEGIN  
            IF @Model_Name IS NULL OR @Model_MUID IS NULL  
            BEGIN  
                SELECT   
                     @Model_MUID = MUID  
                    ,@Model_Name = Name  
                FROM mdm.tblModel  
                WHERE ID = @Model_ID  
            END  
  
            -- A single model was specified, and its info has already been looked up, so simply return it  
            SELECT   
                 @Model_MUID    AS Model_MUID  
                ,@Model_Name    AS Model_Name  
                ,@Model_ID      AS Model_ID  
        END ELSE  
        BEGIN  
            SELECT DISTINCT  
                 m.MUID AS Model_MUID  
                ,m.Name AS Model_Name  
                ,m.ID   AS Model_ID  
            FROM @SelectedLevel l  
            INNER JOIN mdm.tblDerivedHierarchy dh  
            ON l.Hierarchy_ID = dh.ID  
            INNER JOIN mdm.tblModel m  
            ON dh.Model_ID = m.ID  
        END  
  
        -- Return derived hierarchy Identifier(s)  
        SELECT DISTINCT  
             dh.Model_ID    AS Model_ID  
            ,dh.MUID        AS Hierarchy_MUID  
            ,dh.Name        AS Hierarchy_Name  
            ,dh.ID          AS Hierarchy_ID  
        FROM @SelectedLevel l  
        INNER JOIN mdm.tblDerivedHierarchy dh  
        ON l.Hierarchy_ID = dh.ID  
    END  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': returning derived hierarchy level info')  
    SELECT  
         l.MUID AS HierarchyLevel_MUID  
        ,l.Name AS HierarchyLevel_Name  
        ,l.ID   AS HierarchyLevel_ID  
  
        ,l.Hierarchy_ID  
  
        ,l.DisplayName  
        ,l.Entity_MUID  
        ,l.Entity_Name  
        ,l.Entity_ID  
        ,NULLIF(l.ForeignEntity_MUID, 0x0)  AS ForeignEntity_MUID  
        ,NULLIF(l.ForeignEntity_Name, N'')  AS ForeignEntity_Name  
        ,NULLIF(l.ForeignEntity_ID, 0)      AS ForeignEntity_ID  
        ,l.Foreign_MUID  
        ,l.Foreign_Name  
        ,l.Foreign_ID  
        ,l.ForeignType_ID  
        ,CONVERT(BIT, l.IsRecursive) IsRecursive  
        ,l.IsLevelVisible  
        ,l.LevelNumber  
        ,NULLIF(l.ManyToManyChildAttribute_MUID, 0x0)   AS ManyToManyChildAttribute_MUID  
        ,NULLIF(l.ManyToManyChildAttribute_Name, N'')   AS ManyToManyChildAttribute_Name  
        ,NULLIF(l.ManyToManyChildAttribute_ID, 0)       AS ManyToManyChildAttribute_ID  
        ,l.MemberType_ID  
  
        -- Audit info  
        ,l.Detail_EnteredUser_DTM AS EnteredUser_DTM  
        ,l.Detail_EnteredUser_MUID AS EnteredUser_MUID  
        ,l.Detail_EnteredUser_UserName AS EnteredUser_UserName  
        ,l.Detail_EnteredUser_ID AS EnteredUser_ID  
        ,l.Detail_LastChgUser_DTM AS LastChgUser_DTM  
        ,l.Detail_LastChgUser_MUID AS LastChgUser_MUID  
        ,l.Detail_LastChgUser_UserName AS LastChgUser_UserName  
        ,l.Detail_LastChgUser_ID AS LastChgUser_ID  
    FROM @SelectedLevel sl  
    INNER JOIN mdm.viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED_LEVELS l  
    ON sl.ID = l.ID  
    ORDER BY   
         l.Model_ID  
        ,l.Hierarchy_ID  
        ,l.Level_ID  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': end udpDerivedHierarchyLevelGet')  
  
    SET NOCOUNT OFF  
END --proc
go

