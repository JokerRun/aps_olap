/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    EXEC mdm.udpVersionDelete 7;  
    SELECT * FROM mdm.tblModelVersion;  
*/  
CREATE PROCEDURE mdm.udpVersionDelete  
(  
    @Version_ID    INT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE  
        @ID                     INT,  
        @Model_ID               INT,  
        @Entity_ID              INT,  
        @MemberType_ID          TINYINT,  
        @MemberType_Leaf        TINYINT = 1,  
        @TableName              SYSNAME,  
        @SQL                    NVARCHAR(MAX),  
        @DbaUpdateSeqment       NVARCHAR(MAX),  
        @DbaRowCount            INT,  
        @ValidationLogTableName SYSNAME,  
        @TransactionTableName   SYSNAME,  
        @ChangeSetTableName     SYSNAME;  
  
    --Get the @Model_ID that owns the specific @Version_ID  
    SELECT @Model_ID = Model_ID FROM mdm.tblModelVersion WHERE ID = @Version_ID;  
  
    --Check for invalid parameters  
    IF (@Version_ID IS NULL OR @Model_ID IS NULL) BEGIN  
        RAISERROR('MDSERR100010|The Parameters are not valid.', 16, 1);  
        RETURN(1);  
    END; --if  
  
    --Get the validation log table name  
    SET @ValidationLogTableName = mdm.udfGetValidationLogTableName(@Model_ID);  
    SET @TransactionTableName = CONCAT(N'tbl_', @Model_ID, N'_TR');  
    SET @ChangeSetTableName = CONCAT(N'tbl_', @Model_ID, N'_CS');;  
  
    --Start transaction, being careful to check if we are nested  
    DECLARE @TranCounter INT;  
    SET @TranCounter = @@TRANCOUNT;  
    IF @TranCounter > 0 SAVE TRANSACTION TX;  
    ELSE BEGIN TRANSACTION;  
  
    BEGIN TRY  
  
        -- Remove any sync relationships for which the deleted version is source or target.  
        DECLARE  
             @TargetVersion_ID  INT  
            ,@TargetEntity_ID   INT  
        CREATE TABLE #SyncRelationshipsToDelete  
        (  
             TargetVersion_ID   INT  
            ,TargetEntity_ID    INT  
        );  
        CREATE UNIQUE CLUSTERED INDEX #pk_SyncRelationshipsToDelete ON #SyncRelationshipsToDelete(TargetVersion_ID, TargetEntity_ID);  
        INSERT INTO #SyncRelationshipsToDelete  
        SELECT  
              sr.TargetVersion_ID  
             ,sr.TargetEntity_ID  
        FROM mdm.tblSyncRelationship sr  
        WHERE  SourceVersion_ID = @Version_ID  
            OR TargetVersion_ID = @Version_ID;  
  
        WHILE EXISTS(SELECT 1 FROM #SyncRelationshipsToDelete)  
        BEGIN  
            SELECT TOP 1  
                 @TargetVersion_ID  = TargetVersion_ID  
                ,@TargetEntity_ID   = TargetEntity_ID  
            FROM #SyncRelationshipsToDelete  
  
            EXEC mdm.udpSyncRelationshipDelete  
                 @User_ID = 0 -- Unused when @IsVersionOrEntityDelete = 1  
                ,@TargetVersion_ID = @TargetVersion_ID  
                ,@TargetEntity_ID = @TargetEntity_ID  
                ,@IsVersionOrEntityDelete = 1  
                ,@CorrelationID = @CorrelationID  
  
            DELETE FROM #SyncRelationshipsToDelete  
            WHERE   TargetVersion_ID  = @TargetVersion_ID  
                AND TargetEntity_ID = @TargetEntity_ID  
        END;  
  
        --Temporary table to hold all the entity table names  
        DECLARE @EntityTable TABLE  
        (  
             RowNumber INT IDENTITY(1, 1) NOT NULL PRIMARY KEY  
            ,TableName SYSNAME NOT NULL  
            ,MemberType_ID TINYINT NOT NULL  
        );  
  
        --Temporary table to hold all the DBA column names  
        DECLARE @DbaTable TABLE  
        (  
             RowNumber INT IDENTITY(1, 1) NOT NULL PRIMARY KEY  
            ,Entity_ID INT NOT NULL  
            ,MemberType_ID TINYINT NOT NULL  
            ,TableName SYSNAME NOT NULL  
            ,DbaColumnName SYSNAME NOT NULL  
        );  
  
        --Pre-deletion step  
  
        --Delete the subscription views associated with the version  
        EXEC mdm.udpSubscriptionViewsDelete  
            @Model_ID               = NULL,  
            @Version_ID             = @Version_ID,  
            @Entity_ID                = NULL,  
            @DerivedHierarchy_ID    = NULL;  
  
        --Update all DBA values to NULL for this version.  This ensures there will be no FK violations when deleting member data below.  
        INSERT INTO @DbaTable  
        SELECT  
             att.Entity_ID  
            ,att.Attribute_MemberType_ID  
            ,seq.TableName  
            ,att.Attribute_Column AS DbaColumnName  
        FROM mdm.viw_SYSTEM_SCHEMA_ATTRIBUTES att  
        INNER JOIN mdm.udfEntityDependencyTree(@Model_ID) seq  
        ON seq.Entity_ID = att.Entity_ID  
        AND att.Attribute_MemberType_ID = seq.MemberType_ID  
        AND att.Attribute_DBAEntity_ID <> 0  
        AND att.Model_ID = @Model_ID  
        ORDER BY att.Entity_ID, att.Attribute_MemberType_ID;  
  
        DECLARE @Counter INT    = 1,  
                @MaxCounter INT = (SELECT MAX(RowNumber) FROM @DbaTable);  
  
        WHILE @Counter <= @MaxCounter  
        BEGIN  
  
            SELECT  
                 @Entity_ID = Entity_ID  
                ,@MemberType_ID = MemberType_ID  
                ,@TableName = TableName  
            FROM @DbaTable  
            WHERE RowNumber = @Counter;  
  
            SELECT @DbaUpdateSeqment=N'';  
            --Generate the portion of the UPDATE statment that sets the DBA columns to NULL  
            --This sets and appends to the variable all in one statement.  
            SELECT  
                @DbaUpdateSeqment = @DbaUpdateSeqment + DbaColumnName + N'=NULL,'  
            FROM @DbaTable  
            WHERE Entity_ID = @Entity_ID  
            AND   MemberType_ID = @MemberType_ID;  
  
            --Get the rowcount of the number of DBAs.  
            SELECT @DbaRowCount = @@ROWCOUNT;  
  
            --Drop the comma on the end.  
            SELECT @DbaUpdateSeqment = SUBSTRING(@DbaUpdateSeqment,1,LEN(@DbaUpdateSeqment)-1)  
  
            SET @SQL = N'  
                UPDATE mdm.' + QUOTENAME(@TableName) + N' SET ' + @DbaUpdateSeqment + N'  
                WHERE Version_ID = ' + CONVERT(NVARCHAR(30), @Version_ID) + N';';  
  
            --PRINT @SQL  
            EXEC sp_executesql @SQL;  
  
            --Increment by the number of DBAs to get to the next Entity or MemberType.  
            SET @Counter += @DbaRowCount;  
  
        END; --while  
  
        --Delete Member data for this version.  Order of deletion doesn't matter since all DBA values have been set to NULL above.  
        INSERT INTO @EntityTable  
            SELECT  TableName, MemberType_ID  
            FROM mdm.udfEntityDependencyTree(@Model_ID)  
            ORDER BY [Level] DESC;  
  
        SELECT @Counter = 1,  
                @MaxCounter = (SELECT MAX(RowNumber) FROM @EntityTable);  
  
        --Entity level  
        --EN/HP/HR/CN/CM and their HS/AN/PD tables will be deleted explicitly  
        --MS table will be deleted by foreign key cascade delete  
        WHILE @Counter <= @MaxCounter  
        BEGIN  
            SELECT  
                @TableName = TableName,  
                @MemberType_ID = MemberType_ID  
            FROM @EntityTable  
            WHERE RowNumber = @Counter;  
  
            SET @SQL = CONCAT(N'  
                DELETE FROM mdm.', QUOTENAME(@TableName), N'  
                WHERE Version_ID = @Version_ID;  
  
                DELETE FROM mdm.', QUOTENAME(@TableName + N'_HS'), N'  
                WHERE Version_ID = @Version_ID;  
  
                DELETE FROM mdm.', QUOTENAME(@TableName + N'_AN'), N'  
                WHERE Version_ID = @Version_ID;');  
  
            IF @MemberType_ID = @MemberType_Leaf  
            BEGIN  
                SET @SQL = CONCAT(@SQL, N'  
                    DELETE FROM mdm.', QUOTENAME(@TableName + N'_PD'), N'  
                    WHERE Version_ID = @Version_ID;');  
            END  
  
            --PRINT @SQL  
            EXEC sp_executesql @SQL, N'@Version_ID INT', @Version_ID;  
  
            SET @Counter += 1;  
        END; --while  
  
        --Delete all notification queue related items  
        DELETE FROM mdm.tblNotificationUsers WHERE Notification_ID IN (select ID from mdm.tblNotificationQueue WHERE Version_ID = @Version_ID);  
        DELETE FROM mdm.tblNotificationQueue WHERE Version_ID = @Version_ID;  
  
        --Model level  
        --TR/VL/CS tables will be deleted explicitly  
        --AN table will be deleted by forign key cascade delete  
        SET @SQL = CONCAT(N'  
            DELETE FROM [mdm].', QUOTENAME(@ValidationLogTableName), N'  
            WHERE Version_ID = @Version_ID;  
  
            DELETE FROM [mdm].', QUOTENAME(@TransactionTableName), N'  
            WHERE Version_ID = @Version_ID;  
  
            DELETE FROM [mdm].', QUOTENAME(@ChangeSetTableName), N'  
            WHERE Version_ID = @Version_ID;');  
        EXEC sp_executesql @SQL, N'@Version_ID INT', @Version_ID;  
  
        --Delete all security role access member items  
        DELETE FROM mdm.tblSecurityRoleAccessMember WHERE Version_ID = @Version_ID;  
  
        -- Delete the Version out of ModelVersion table  
        DELETE FROM mdm.tblModelVersion WHERE ID = @Version_ID;  
  
        --Commit only if we are not nested  
        IF @TranCounter = 0 COMMIT TRANSACTION;  
        RETURN(0);  
  
    END TRY  
    --Compensate as necessary  
    BEGIN CATCH  
  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        IF @TranCounter = 0 ROLLBACK TRANSACTION;  
        ELSE IF XACT_STATE() <> -1 ROLLBACK TRANSACTION TX;  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
  
        --On error, return NULL results  
        --SELECT @Return_ID = NULL;  
        RETURN(1);  
  
    END CATCH;  
  
    SET NOCOUNT OFF;  
END; --proc
go

