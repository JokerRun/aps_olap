/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    --Create new Model  
    DECLARE @Return_ID INT, @Return_MUID UNIQUEIDENTIFIER;  
    EXEC mdm.udpModelSave @User_ID = 1, @ModelName = N'test', @EditMode = 0, @Return_ID = @Return_ID OUTPUT, @Return_MUID = @Return_MUID OUTPUT;  
    SELECT @Return_ID, @Return_MUID;  
    SELECT * FROM mdm.tblModel WHERE ID = @Return_ID;  
  
    --Update existing Model  
    DECLARE @Return_ID INT, @Return_MUID UNIQUEIDENTIFIER;  
    EXEC mdm.udpModelSave @User_ID = 1, @Model_ID = 1, @ModelName = N'test new', @EditMode = 1, @Return_ID = @Return_ID OUTPUT, @Return_MUID = @Return_MUID OUTPUT;  
    SELECT @Return_ID, @Return_MUID;  
    SELECT * FROM mdm.tblModel WHERE ID = @Return_ID;  
*/  
CREATE PROCEDURE mdm.udpModelSave  
(  
    @User_ID                        INT,  
    @Model_MUID                     UNIQUEIDENTIFIER = NULL,  
    @ModelName                      NVARCHAR(50),  
    @Description                    NVARCHAR(500) = NULL,  
    @EditMode                       TINYINT = 0, --0: Create, 1: Update, 4: Clone, defaults to Create  
    @LogRetentionDays               SMALLINT = NULL,  
    @Return_ID                      INT = NULL OUTPUT,  
    @Return_MUID                    UNIQUEIDENTIFIER = NULL OUTPUT, --Also an input parameter for clone operations  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE @TempDescription                    NVARCHAR(250),  
            @CurrentDTM                         DATETIME2(3),  
            @CurrentModelName                   NVARCHAR(50),  
            @CurrentDescription                 NVARCHAR(MAX),  
            @CurrentLogRetentionDays            INT = NULL,  
            @SystemSettingLogRetentionDays      INT = NULL,  
            @EditMode_Create                    TINYINT = 0,  
            @EditMode_Update                    TINYINT = 1,  
            @EditMode_Clone                     TINYINT = 4,  
            @ExistingModel_MUID                 UNIQUEIDENTIFIER = NULL,  
            @ExistingModel_ID                   INT = NULL,  
            @ObjectType_Model                   INT = 1,  
            @IsModelAdmin                       INT = NULL,  
            @PartitionFunction                  SYSNAME,  
            @PartitionSchema                    SYSNAME,  
            @FileGroupName                      SYSNAME,  
            @SQL                                NVARCHAR(MAX),  
            @GuidEmpty                          UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER);  
  
    --Initialize output parameters and local variables  
    SELECT  
        @ModelName = NULLIF(LTRIM(RTRIM(@ModelName)), N''),  
        @Description = NULLIF(LTRIM(RTRIM(@Description)), N''),  
        @Return_ID = NULL,  
        @CurrentDTM = GETUTCDATE(),  
        @CurrentModelName = NULL,  
        @Model_MUID = NULLIF(@Model_MUID, @GuidEmpty),  
        @SystemSettingLogRetentionDays = CONVERT(INT,mdm.udfSystemSettingGet('LogRetentionDays'));  
    --On error, return NULL results  
    SELECT @Return_ID = NULL, @Return_MUID = NULL;  
  
    --Test for invalid EditMode  
    IF @EditMode IS NULL OR @EditMode NOT IN (@EditMode_Create, @EditMode_Update, @EditMode_Clone)  
    BEGIN  
        RAISERROR('MDSERR100010|The Parameters are not valid.', 16, 1);  
        RETURN;  
    END; --if  
  
  
    --If we are in the Update or Clone mode get the missing pieces of the identifier  
    IF @EditMode IN (@EditMode_Update, @EditMode_Clone)  
    BEGIN  
        --Only use the name if the MUID is not available. This is important because we don't want  
        --to look up by name if the name is what the user is trying to update.  
        IF @Model_MUID IS NULL  
        BEGIN  
            SELECT TOP 1  
                @ExistingModel_ID =  ID,  
                @ExistingModel_MUID = MUID,  
                @CurrentModelName = Name,  
                @CurrentDescription = [Description],  
                @CurrentLogRetentionDays = LogRetentionDays  
            FROM mdm.tblModel  
            WHERE [Name] = @ModelName;  
        END  
        --Use the Model MUID to look up the full identifier  
        ELSE  
        BEGIN  
            SELECT  
                @ExistingModel_ID =  ID,  
                @ExistingModel_MUID = MUID,  
                @CurrentModelName = Name,  
                @CurrentDescription = [Description],  
                @CurrentLogRetentionDays = LogRetentionDays  
            FROM mdm.tblModel  
            WHERE MUID = @Model_MUID;  
        END  
  
        --If we are in the Clone mode we need to figure out whether we are creating or updating a model  
        IF @EditMode = @EditMode_Clone  
        BEGIN  
            --If there is no existing model then set the edit mode to Create  
            IF @ExistingModel_MUID IS NULL AND @ExistingModel_ID IS NULL  
            BEGIN  
                SET @EditMode = @EditMode_Create;  
            END  
            --If there is an existing model then set the edit mode to Update  
            ELSE  
            BEGIN  
                SET @EditMode = @EditMode_Update;  
                SET @Model_MUID = @ExistingModel_MUID;  
            END  
        END  
        --If we are in Update mode and could not find a matching existing model we need to raise an error and quit now  
        ELSE IF @EditMode = @EditMode_Update  
        BEGIN  
            IF @ExistingModel_ID IS NULL OR @ExistingModel_MUID IS NULL  
            BEGIN  
                RAISERROR('MDSERR110007|The ID is not valid.', 16, 1);  
                RETURN;  
            END  
            ELSE  
            BEGIN  
                SET @Model_MUID = @ExistingModel_MUID;  
            END  
        END  
    END  
  
    --If the edit mode is Create. This code also needs to execute if the user sent in EditMode clone which ended up becoming Create (hence the IF instead of ELSE IF)  
    IF @EditMode = @EditMode_Create  
    BEGIN  
        --If Model_MUID is not null then we need to ensure it does not already exist (since this is a create)  
        IF @Model_MUID IS NOT NULL AND EXISTS(SELECT * FROM mdm.tblModel WHERE MUID = @Model_MUID)  
        BEGIN  
            RAISERROR('MDSERR110007|The ID is not valid.', 16, 1);  
            RETURN;  
        END  
    END  
  
    --Check the name of the model for duplicates  
    IF EXISTS (SELECT 1 FROM mdm.tblModel WHERE @ModelName = Name AND (@Model_MUID IS NULL OR MUID <> @Model_MUID))  
    BEGIN  
        RAISERROR('MDSERR110003|The name already exists. Type a different name.', 16, 1);  
        RETURN;  
    END  
  
    --Start transaction, being careful to check if we are nested  
    DECLARE @TranCounter INT;  
    SET @TranCounter = @@TRANCOUNT;  
    IF @TranCounter > 0 SAVE TRANSACTION TX;  
    ELSE BEGIN TRANSACTION;  
  
    BEGIN TRY  
  
        IF @EditMode = @EditMode_Update  
        --Update model  
        BEGIN  
                -- Ensure the user is a model admin.  
                EXEC mdm.udpUserIsModelAdministrator  
                    @User_ID  = @User_ID,  
                    @ObjectType_ID = @ObjectType_Model,  
                    @Object_MUID = @Model_MUID,  
                    @Return_ID = @IsModelAdmin OUTPUT;  
  
                IF COALESCE(@IsModelAdmin, 0) = 0  
                BEGIN  
                    RAISERROR('MDSERR120003|The user does not have permission or the object ID is not valid.', 16, 1);  
                    RETURN;  
                END;  
  
                --Update details in Model table  
                UPDATE mdm.tblModel SET  
                    [Name] = ISNULL(@ModelName, [Name]),  
                    [Description] = @Description,  
                    LogRetentionDays = @LogRetentionDays,  
                    LastChgUserID = @User_ID,  
                    LastChgDTM = @CurrentDTM  
                WHERE  
                    ID = @ExistingModel_ID;  
  
                --Populate output parameters  
                SET @Return_MUID = @ExistingModel_MUID  
                SET @Return_ID = @ExistingModel_ID  
  
        END  
        ELSE  
        --New model  
        BEGIN  
            --Accept an explicit MUID (for clone operations) or generate a new one  
            SET @Return_MUID =  ISNULL(@Model_MUID, NEWID());  
  
            PRINT CONCAT(SYSDATETIME(), N': udpModelSave- Inserting model ', @ModelName);  
                          
            --Insert details into Model table  
            INSERT INTO mdm.tblModel  
            (  
                [Name],  
                [Description],  
                MUID,  
                LogRetentionDays,  
                EnterUserID,  
                LastChgUserID  
            ) VALUES (  
                @ModelName,  
                @Description,  
                @Return_MUID,  
                @LogRetentionDays,  
                @User_ID,  
                @User_ID  
            );  
  
            --Save the identity value  
            SET @Return_ID = SCOPE_IDENTITY();  
              
            IF mdm.udfIsEnterpriseEdition() = 1  
            BEGIN  
                SET @PartitionFunction = CONCAT(N'udpfModel_', @Return_ID);  
                SET @PartitionSchema = CONCAT(N'udpsModel_', @Return_ID);  
  
                SET @SQL = CONCAT(N'CREATE PARTITION FUNCTION ', @PartitionFunction, N' (INT) AS RANGE LEFT FOR VALUES ();');  
                EXEC sp_executesql @SQL;  
  
                SELECT TOP 1 @FileGroupName = name  
                FROM sys.filegroups  
                WHERE is_read_only = 0;  
  
                SET @SQL = CONCAT(N'CREATE PARTITION SCHEME ', @PartitionSchema, N' AS PARTITION ', @PartitionFunction, N' ALL TO (', QUOTENAME(@FileGroupName), N');');  
                EXEC sp_executesql @SQL;  
            END  
  
            --Set up validation log tables and views  
            EXEC mdm.udpCreateModelTables @Model_ID = @Return_ID;  
  
            --Assign admin privileges to the user who created the model.  
            DECLARE  
                 @PermissionType_Admin TINYINT = 5  
                ,@PrincipalType_User TINYINT = 1;  
            EXEC mdm.udpSecurityPrivilegesSave  
                 @SystemUser_ID = @User_ID  
                ,@Principal_ID = @User_ID  
                ,@PrincipalType_ID = @PrincipalType_User  
                ,@Principal_Name = NULL  
                ,@RoleAccess_ID = NULL  
                ,@Object_ID = @ObjectType_Model  
                ,@Privilege_ID = @PermissionType_Admin  
                ,@AccessPermission = 0  
                ,@Model_ID = @Return_ID  
                ,@Securable_ID = @Return_ID  
                ,@Securable_Name = @ModelName  
                ,@RoleAccess_MUID = NULL  
                ;  
  
            --Create the initial version  
            SET @TempDescription = LEFT(N'Version 1 for Model: ' + @ModelName, 250);  
            EXEC mdm.udpVersionSave   
                @User_ID = @User_ID,   
                @Model_ID = @Return_ID,  
                @Version_ID = NULL,  
                @CurrentVersion_ID = NULL,   
                @Status_ID = 1/*Open*/,   
                @Name = N'VERSION_1',   
                @Description = @TempDescription;  
  
            --Recreate the views  
            EXEC mdm.udpCreateViews @Return_ID;  
        END; --if  
  
        --Commit only if we are not nested  
        IF @TranCounter = 0 COMMIT TRANSACTION;  
        RETURN(0);  
  
    END TRY  
    --Compensate as necessary  
    BEGIN CATCH  
  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        IF @TranCounter = 0 ROLLBACK TRANSACTION;  
        ELSE IF XACT_STATE() <> -1 ROLLBACK TRANSACTION TX;  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
  
        RETURN;  
  
    END CATCH;  
  
    SET NOCOUNT OFF;  
END; --proc
go

