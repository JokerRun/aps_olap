/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    --Create new hierarchy  
    DECLARE @Return_ID INT, @Return_MUID UNIQUEIDENTIFIER, @Type INT;  
    EXEC mdm.udpEntityHierarchySave @User_ID = 1, @Model_ID = 5, @Entity_ID = 15, @HierarchyName = N'test2', @IsMandatory = 1, @EditMode = 0, @Return_ID = @Return_ID OUTPUT, @Return_MUID = @Return_MUID OUTPUT;  
    SELECT @Return_ID, @Return_MUID;  
    SELECT * FROM mdm.tblHierarchy WHERE ID = @Return_ID;  
  
    --Update existing hierarchy  
    DECLARE @Return_ID INT, @Return_MUID UNIQUEIDENTIFIER, @Type INT;  
    EXEC mdm.udpEntityHierarchySave @User_ID = 1, @Model_ID = 5, @Entity_ID = 15, @Hierarchy_ID = 1, @HierarchyName = N'test5', @IsMandatory = 1, @EditMode = 0, @Return_ID = @Return_ID OUTPUT, @Return_MUID = @Return_MUID OUTPUT;  
    SELECT @Return_ID, @Return_MUID;  
    SELECT * FROM mdm.tblHierarchy WHERE ID = @Return_ID;  
*/  
CREATE PROCEDURE mdm.udpEntityHierarchySave  
(  
    @User_ID            INT,  
    @Model_ID           INT, -- caller should validate  
    @Entity_ID          INT, -- caller should validate  
    @Version_ID         INT = NULL, -- used for audit info  
    @Hierarchy_MUID     UNIQUEIDENTIFIER = NULL,  
    @HierarchyName      NVARCHAR(100),  
    @IsMandatory        BIT,  
    @EditMode           TINYINT = 0, --0: Create, 1: Update, 4: Clone, defaults to Create  
    @RecreateLeafStagingProc BIT = 1, -- In can be useful, for efficiency, to turn this off for batch metadata changes  
    @Return_ID          INT = NULL OUTPUT,  
    @Return_MUID        UNIQUEIDENTIFIER = NULL OUTPUT, --Also an input parameter for clone operations  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE  
        @SQL                        NVARCHAR(MAX),  
        @IsCollectionEnabled        BIT = 0,  
        @IsHierarchyEnabled         BIT = 0,  
        @EntityTable                SYSNAME,  
        @HierarchyParentTable       SYSNAME,  
        @HierarchyParentHistoryTable    SYSNAME,  
        @HierarchyParentAnnotationTable SYSNAME,  
        @HierarchyTable             SYSNAME,  
        @HierarchyHistoryTable      SYSNAME,  
        @HierarchyAnnotationTable   SYSNAME,  
        @CollectionMemberTable      SYSNAME,  
        @CollectionMemberHistoryTable   SYSNAME,  
        @StagingConsolidatedTable   SYSNAME,  
        @StagingRelationshipTable   SYSNAME,  
        @StagingBase                NVARCHAR(MAX),  
        @SecurityTable              SYSNAME,  
        @CurrentDTM                 DATETIME2(3),  
        @Status_Active              TINYINT = 1,  
        @GuidEmpty                  UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER),  
        @EditMode_Create            TINYINT = 0,  
        @EditMode_Update            TINYINT = 1,  
        @EditMode_Clone             TINYINT = 4,  
        @ExistingHierarchy_MUID     UNIQUEIDENTIFIER = NULL,  
        @ExistingHierarchy_ID       INT = NULL,  
        @ObjectType_Model           INT = 1,  
        @IsModelAdmin               INT = NULL,  
        @DataCompression            TINYINT,  
        @TableOptions               NVARCHAR(MAX) = N'',  
        @IndexOptions               NVARCHAR(MAX) = N'',  
        @StagingTableOptions        NVARCHAR(MAX) = N'',  
        @StagingIndexOptions        NVARCHAR(MAX) = N'',  
        @TruncationGuard            NVARCHAR(MAX) = N'';  
  
    SELECT @Return_ID = NULL, @Return_MUID = NULL;  
  
    IF Len(@HierarchyName) > 50 -- Check to see if the HierarchyName exceeds the length limit (50).  
    BEGIN  
        RAISERROR('MDSERR200088|The explicit hierarchy cannot be saved. The explicit hierarchy name cannot be more than 50 characters.', 16, 1);  
        RETURN;  
    END;  
  
    --Test for invalid EditMode  
    IF @EditMode IS NULL OR @EditMode NOT IN (@EditMode_Create, @EditMode_Update, @EditMode_Clone)  
    BEGIN  
        --On error, return NULL results  
        SELECT @Return_ID = NULL, @Return_MUID = NULL;  
        RAISERROR('MDSERR100010|The Parameters are not valid.', 16, 1);  
        RETURN;  
    END; --if  
  
    --Initialize output parameters and local variables  
    SELECT  
        @Return_ID = NULL,  
        @CurrentDTM = GETUTCDATE(),  
        @Model_ID = NULLIF(@Model_ID, 0),  
        @Entity_ID = NULLIF(@Entity_ID, 0),  
        @Hierarchy_MUID = NULLIF(@Hierarchy_MUID, @GuidEmpty),  
        @HierarchyName = NULLIF(LTRIM(RTRIM(@HierarchyName)), N'');  
  
    --Load up the entity info  
    SELECT @DataCompression = DataCompression  
    FROM mdm.tblEntity  
    WHERE ID = @Entity_ID  
  
    --Raise an error if we are missing the entity ID  
    IF @DataCompression IS NULL --Missing Entity identifier  
    BEGIN  
        RAISERROR('MDSERR200011|The explicit hierarchy cannot be saved. The entity ID is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    --If we are in the Update or Clone mode get the missing pieces of the identifier  
    IF @EditMode IN (@EditMode_Update, @EditMode_Clone)  
    BEGIN  
        --Only use the name if neither MUID nor ID are available. This is important because we don't want  
        --to look up by name if the name is what the user is trying to update.  
        IF  @Hierarchy_MUID IS NULL  
        BEGIN  
            SELECT TOP 1  
                @ExistingHierarchy_ID =  ID,  
                @ExistingHierarchy_MUID = MUID  
            FROM mdm.tblHierarchy  
            WHERE  
                Name = @HierarchyName AND  
                Entity_ID = @Entity_ID;  
        END  
        --Use the Hierarchy ID and MUID to look up the full identifier  
        ELSE  
        BEGIN  
            SELECT  
            @ExistingHierarchy_ID =  ID,  
            @ExistingHierarchy_MUID = MUID  
            FROM mdm.tblHierarchy  
            WHERE  
                MUID = @Hierarchy_MUID AND  
                Entity_ID = @Entity_ID;  
        END  
  
        --If we are in the Clone mode we need to figure out whether we are creating or updating a hierarchy  
        IF @EditMode = @EditMode_Clone  
        BEGIN  
            --If there is no existing hierarchy then set the edit mode to Create  
            IF @ExistingHierarchy_MUID IS NULL AND @ExistingHierarchy_ID IS NULL  
            BEGIN  
                SET @EditMode = @EditMode_Create;  
            END  
            --If there is an existing hierarchy then set the edit mode to Update  
            ELSE  
            BEGIN  
                SET @EditMode = @EditMode_Update;  
                SET @Hierarchy_MUID = @ExistingHierarchy_MUID;  
            END  
        END  
        --If we are in Update mode and could not find a matching existing hierarchy we need to raise an error and quit now  
        ELSE IF @EditMode = @EditMode_Update  
        BEGIN  
            IF @ExistingHierarchy_ID IS NULL OR @ExistingHierarchy_MUID IS NULL  
            BEGIN  
                --On error, return NULL results  
                SELECT @Return_ID = NULL, @Return_MUID = NULL;  
                RAISERROR('MDSERR110007|The ID is not valid.', 16, 1);  
                RETURN;  
            END  
            ELSE  
            BEGIN  
                SET @Hierarchy_MUID = @ExistingHierarchy_MUID;  
            END;  
        END  
    END  
  
    --If the edit mode is Create. This code also needs to execute if the user sent in EditMode clone which ended up becoming Create (hence the IF instead of ELSE IF)  
    IF @EditMode = @EditMode_Create  
    BEGIN  
        --If @Hierarchy_MUID is not null then we need to ensure it does not already exist (since this is a create)  
        IF @Hierarchy_MUID IS NOT NULL AND EXISTS(SELECT * FROM mdm.tblHierarchy WHERE MUID = @Hierarchy_MUID)  
        BEGIN  
            --On error, return NULL results  
            SELECT @Return_ID = NULL, @Return_MUID = NULL;  
            RAISERROR('MDSERR110007|The ID is not valid.', 16, 1);  
            RETURN;  
        END  
    END  
  
    --Set the staging table names  
    SELECT  
        @Model_ID = Model_ID,  
        @IsCollectionEnabled = CASE WHEN CollectionTable IS NULL THEN 0 ELSE 1 END,  
        @IsHierarchyEnabled  = CASE WHEN HierarchyTable  IS NULL THEN 0 ELSE 1 END,  
        @EntityTable = EntityTable,  
        @CollectionMemberTable = CollectionMemberTable,  
        @StagingConsolidatedTable = StagingConsolidatedName,  
        @StagingRelationshipTable = StagingRelationshipName,  
        @StagingBase = StagingBase  
    FROM mdm.tblEntity  
    WHERE ID = @Entity_ID;  
  
    --Test for invalid parameters  
    IF @Model_ID IS NULL --Invalid @Entity_ID (via invalid @Model_ID)  
    BEGIN  
        SELECT @Return_ID = NULL, @Return_MUID = NULL;  
        RAISERROR('MDSERR100010|The Parameters are not valid.', 16, 1);  
        RETURN;  
    END; --if  
  
    --Check the name of the hierarchy for duplicates  
    IF EXISTS  
    (  
        SELECT 1 FROM  
        mdm.tblHierarchy  
        WHERE  
            @HierarchyName = Name AND  
            (@Hierarchy_MUID IS NULL OR MUID <> @Hierarchy_MUID) AND  
            Entity_ID = @Entity_ID  
    )  
    BEGIN  
        --On error, return NULL results  
        SELECT @Return_ID = NULL, @Return_MUID = NULL;  
        RAISERROR('MDSERR110003|The name already exists. Type a different name.', 16, 1);  
        RETURN;  
    END  
  
    --Start transaction, being careful to check if we are nested  
    DECLARE @TranCounter INT;  
    SET @TranCounter = @@TRANCOUNT;  
    IF @TranCounter > 0 SAVE TRANSACTION TX;  
    ELSE BEGIN TRANSACTION;  
  
    BEGIN TRY  
  
        --If Entity does not currently have hierarchies, create the necessary tables  
        IF @IsHierarchyEnabled = 0  
        BEGIN  
  
            SET @TableOptions = mdm.udfGetTableOptions(@DataCompression, @Model_ID);  
            SET @IndexOptions = mdm.udfGetIndexOptions(@DataCompression, @Model_ID);  
            SET @StagingTableOptions = mdm.udfGetTableOptions(@DataCompression, NULL);  
            SET @StagingIndexOptions = mdm.udfGetIndexOptions(@DataCompression, NULL);  
  
            --Generate table names  
            WITH cte(prefix) AS (SELECT N'tbl_' + CONVERT(SYSNAME, @Model_ID) + N'_' + CONVERT(SYSNAME, @Entity_ID))  
            SELECT  
                @HierarchyTable = prefix + N'_HR',  
                @HierarchyHistoryTable = prefix + N'_HR_HS',  
                @HierarchyAnnotationTable = prefix + N'_HR_AN',  
                @HierarchyParentTable = prefix + N'_HP',  
                @HierarchyParentHistoryTable = prefix + N'_HP_HS',  
                @HierarchyParentAnnotationTable = prefix + N'_HP_AN',  
                @CollectionMemberHistoryTable = prefix + N'_CM_HS',  
                @SecurityTable = prefix +  N'_HP_MS'  
            FROM cte;  
  
            -- Set the entity's hierarchy table names.  
            UPDATE mdm.tblEntity SET  
                --Assign table names  
                HierarchyTable = @HierarchyTable,  
                HierarchyParentTable = @HierarchyParentTable,  
                --Ensure changes are audited  
                LastChgDTM = @CurrentDTM,  
                LastChgUserID = @User_ID,  
                LastChgVersionID = @Version_ID  
            WHERE ID = @Entity_ID;  
  
            --Create the Hierarchy Parent table (HP)  
            SET @SQL =  @TruncationGuard + N'  
                CREATE TABLE mdm.' + QUOTENAME(@HierarchyParentTable) + N'  
                (  
                    --Identity  
                    Version_ID          INT NOT NULL,  
                    ID                  INT IDENTITY (1, 1) NOT NULL,  
                    --Status  
                    Status_ID           TINYINT NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @HierarchyParentTable  + N'_Status_ID') + N' DEFAULT ' + CONVERT(NVARCHAR, @Status_Active) + N',  
                    ValidationStatus_ID TINYINT NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @HierarchyParentTable  + N'_ValidationStatus_ID') + N' DEFAULT 0,  
  
                    --Data  
                    [Name]              NVARCHAR(250) NULL,  
                    Code                NVARCHAR(250) NOT NULL,  
                    Hierarchy_ID        INT NOT NULL,  
  
                    --Change Tracking  
                    ChangeTrackingMask  INT NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @HierarchyParentTable  + N'_ChangeTrackingMask') + N' DEFAULT 0,  
  
                    --Auditing  
                    EnterDTM            DATETIME2(3) NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @HierarchyParentTable  + N'_EnterDTM') + N' DEFAULT GETUTCDATE(),  
                    EnterUserID         INT NOT NULL,  
                    EnterVersionID      INT NOT NULL,  
                    LastChgDTM          DATETIME2(3) NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @HierarchyParentTable  + N'_LastChgDTM') + N' DEFAULT GETUTCDATE(),  
                    LastChgUserID       INT NOT NULL,  
                    LastChgVersionID    INT NOT NULL,  
                    LastChgTS           ROWVERSION NOT NULL,  
                    AsOf_ID             INT NULL,  
                    MUID                UNIQUEIDENTIFIER NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @HierarchyParentTable + N'_MUID') + N' DEFAULT NEWID(),  
  
                    --Create PRIMARY KEY constraint  
                    CONSTRAINT ' + QUOTENAME(N'pk_' + @HierarchyParentTable  + N'') + N'  
                        PRIMARY KEY CLUSTERED (Version_ID, ID),  
  
                    --Create FOREIGN KEY contraints  
                    CONSTRAINT ' + QUOTENAME(N'fk_' + @HierarchyParentTable  + N'_tblHierarchy_Hierarchy_ID') + N'  
                        FOREIGN KEY (Hierarchy_ID) REFERENCES mdm.tblHierarchy(ID)  
                        ON UPDATE NO ACTION  
                        ON DELETE CASCADE  
  
                    -- Note: the values of the Status_ID column should fall between 1 and 2. The ValidationStatus_ID column should be between 0 and 5. However,  
                    -- we do not enforce this via db constraint because it would slow down table writes and only trusted MDS sproc code should be writing to those columns.  
                )  
                ' + @TableOptions + N';  
                ';  
  
            SET @SQL = CONCAT(@SQL, N'  
                --Ensure uniqueness of [Code] for active members.  
                CREATE UNIQUE NONCLUSTERED INDEX ', QUOTENAME(N'ux_' + @HierarchyParentTable + N'_Version_ID_Code_Active'), N'  
                    ON mdm.', QUOTENAME(@HierarchyParentTable), N'(Version_ID, Code)  
                    WHERE Status_ID = ', @Status_Active, N'  
                    ', @IndexOptions, N';  
  
                --Index [Name] for performance  
                CREATE NONCLUSTERED INDEX ', QUOTENAME(N'ix_' + @HierarchyParentTable + N'_Version_ID_Name'), N'  
                    ON mdm.', QUOTENAME(@HierarchyParentTable), N'(Version_ID, Name)  
                    ', @IndexOptions, N';  
  
                --Ensure uniqueness of [MUID]  
                CREATE UNIQUE NONCLUSTERED INDEX ', QUOTENAME(N'ux_' + @HierarchyParentTable + N'_Version_ID_MUID'), N'  
                    ON mdm.', QUOTENAME(@HierarchyParentTable), N'(Version_ID, MUID)  
                    ', @IndexOptions, N';  
  
                --Index Status_ID and ValidationStatus_ID for performance (queried together in udpVersionValidationStatusGet)  
                CREATE NONCLUSTERED INDEX ', QUOTENAME(N'ix_' + @HierarchyParentTable + N'_Version_ID_Status_ID_ValidationStatus_ID'), N'  
                    ON mdm.', QUOTENAME(@HierarchyParentTable), N'(Version_ID, Status_ID, ValidationStatus_ID)  
                    ', @IndexOptions, N';  
  
                --Add an index on Hierarchy_ID corresponding to the FK  
                CREATE NONCLUSTERED INDEX ', QUOTENAME(N'ix_' + @HierarchyParentTable + N'_Hierarchy_ID'), N'  
                    ON mdm.', QUOTENAME(@HierarchyParentTable), N'(Hierarchy_ID)  
                    ', @IndexOptions, N';  
  
                --Required for VersionCopy operations  
                CREATE NONCLUSTERED INDEX ', QUOTENAME(N'ix_' + @HierarchyParentTable + N'_Version_ID_AsOf_ID_Status_ID'), N'  
                    ON mdm.', QUOTENAME(@HierarchyParentTable), N'(Version_ID, AsOf_ID, Status_ID)  
                    INCLUDE ([ID])  
                    WHERE [AsOf_ID] IS NOT NULL  
                    ', @IndexOptions, N';  
  
                --Create the history (_HP_HS) table  
                CREATE TABLE mdm.', QUOTENAME(@HierarchyParentHistoryTable), N'  
                (  
                    --Identity  
                    Version_ID          INT NOT NULL,  
                    ID                  BIGINT NOT NULL,  
  
                    HP_ID               INT NOT NULL,  
  
                    --Status  
                    Status_ID           TINYINT NOT NULL,  
  
                    --Data  
                    [Name]              NVARCHAR(250) NULL,  
                    Code                NVARCHAR(250) NOT NULL,  
                    Hierarchy_ID        INT NOT NULL,  
  
                    --Auditing  
                    EnterDTM            DATETIME2(3) NOT NULL,  
                    EnterUserID         INT NOT NULL,  
                    LastChgDTM          DATETIME2(3) NOT NULL,  
                    LastChgUserID       INT NOT NULL,  
                    MUID                UNIQUEIDENTIFIER NOT NULL,  
  
                    --Create PRIMARY KEY constraint  
                    CONSTRAINT ', QUOTENAME(N'pk_' + @HierarchyParentHistoryTable + N''), N'  
                        PRIMARY KEY CLUSTERED (Version_ID, ID)  
  
                    --Cannot have foreign key (Version_ID, HP_ID) on HP table, because HS table is used in OUTPUT clause  
                )  
                ', @TableOptions, N';  
  
                -- Required by udpEntityMemberHistoriesGet and type2 view  
                CREATE NONCLUSTERED INDEX ', QUOTENAME(N'ix_' + @HierarchyParentHistoryTable + N'_Version_ID_HP_ID'), N'  
                    ON mdm.', QUOTENAME(@HierarchyParentHistoryTable), N'(Version_ID, HP_ID, EnterDTM, LastChgDTM)  
                    ', @IndexOptions, N';  
  
                --Create the Annotation (_HP_AN) table  
                CREATE TABLE mdm.', QUOTENAME(@HierarchyParentAnnotationTable), N'  
                (  
                    Version_ID          INT NOT NULL,  
                    ID                  INT IDENTITY(1, 1) NOT NULL,  
  
                    Revision_ID         BIGINT NOT NULL,  
  
                    [Comment]           [NVARCHAR](500) NULL,  
  
                    --Auditing  
                    EnterDTM            DATETIME2(3) NOT NULL CONSTRAINT ', QUOTENAME(N'df_' + @HierarchyParentAnnotationTable + N'_EnterDTM'), N' DEFAULT GETUTCDATE(),  
                    EnterUserID         INT NOT NULL,  
                    LastChgDTM          DATETIME2(3) NOT NULL CONSTRAINT ', QUOTENAME(N'df_' + @HierarchyParentAnnotationTable + N'_LastChgDTM'), N' DEFAULT GETUTCDATE(),  
                    LastChgUserID       INT NOT NULL,  
                    LastChgTS           ROWVERSION NOT NULL,  
  
                    --Create PRIMARY KEY constraint  
                    CONSTRAINT ', QUOTENAME(N'pk_' + @HierarchyParentAnnotationTable), N'  
                        PRIMARY KEY CLUSTERED (Version_ID, ID)  
                )  
                ', @TableOptions, N';  
  
                -- Required for udpEntityMemberAnnotationsGet operations  
                CREATE NONCLUSTERED INDEX ', QUOTENAME(N'ix_' + @HierarchyParentAnnotationTable +  N'_Version_ID_Revision_ID'), N'  
                    ON mdm.', QUOTENAME(@HierarchyParentAnnotationTable), N'(Version_ID, Revision_ID)  
                    ', @IndexOptions, N';  
  
                --Create the Member Security (HP_MS) table  
                --There is no IDENTITY() column since this table gets bulk- deleted & inserted frequently  
                CREATE TABLE mdm.', QUOTENAME(@SecurityTable), N'  
                (  
                    Version_ID          INT NOT NULL,  
                    User_ID             INT NOT NULL,  
                    ID                  INT NOT NULL,  
                    AccessPermission    TINYINT NOT NULL,  
  
                    --Create PRIMARY KEY constraint  
                    CONSTRAINT ', QUOTENAME(N'pk_' + @SecurityTable), N'  
                        PRIMARY KEY CLUSTERED (Version_ID, User_ID, ID),  
  
                    --Create FOREIGN KEY constraints  
                    CONSTRAINT ', QUOTENAME(N'fk_' + @SecurityTable + N'_' + @HierarchyParentTable + '_Version_ID_ID'), N'  
                        FOREIGN KEY (Version_ID, ID) REFERENCES mdm.' + @HierarchyParentTable + '(Version_ID, ID)  
                        ON UPDATE NO ACTION  
                        ON DELETE CASCADE  
                )  
                ', @TableOptions, N'  
  
                -- Create index for the FK, to improve perf of cascaded deletes from HP table.  
                CREATE NONCLUSTERED INDEX ', QUOTENAME(N'ix_' + @SecurityTable + N'_Version_ID_ID'), N'  
                    ON mdm.', QUOTENAME(@SecurityTable), N'(Version_ID, ID)  
                    ', @IndexOptions, N';  
                ');  
  
            --Execute the dynamic SQL  
            --PRINT(@SQL);  
            EXEC sp_executesql @SQL;  
  
            --If @StagingConsolidatedTable is specified create the Consolidated Staging table (_Consolidated) in Staging (stg) Schema  
            IF COALESCE(@StagingConsolidatedTable, N'') <> N''  
            BEGIN  
                EXEC mdm.udpEntityStagingCreateConsolidatedTable  
                     @StagingTableName = @StagingConsolidatedTable  
                    ,@TableOptions = @StagingTableOptions  
                    ,@IndexOptions = @StagingIndexOptions;  
  
  
                EXEC mdm.udpEntityStagingCreateConsolidatedStoredProcedure @Entity_ID  
  
            END; --IF  
  
            --Create the Hierarchy Relationship table (HR)  
            SET @SQL = N'  
                CREATE TABLE mdm.' + QUOTENAME(@HierarchyTable) + N'  
                (  
                    --Identity  
                    Version_ID          INT NOT NULL,  
                    ID                  INT IDENTITY(1, 1) NOT NULL,  
  
                    --Status  
                    Status_ID           TINYINT NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @HierarchyTable + N'_Status_ID') + N' DEFAULT ' + CONVERT(NVARCHAR, @Status_Active) + N',  
                    ValidationStatus_ID TINYINT NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @HierarchyTable + N'_ValidationStatus_ID') + N' DEFAULT 0,  
  
                    --Pointers  
                    Hierarchy_ID        INT NOT NULL,  
                    Parent_HP_ID        INT NULL, --Root is NULL  
                    ChildType_ID        TINYINT NOT NULL,  
                    Child_EN_ID         INT NULL, --Only used when ChildType_ID = 1 (EN)  
                    Child_HP_ID         INT NULL, --Only used when ChildType_ID = 2 (HP)  
  
                    --Data  
                    SortOrder           INT NOT NULL,  
                    LevelNumber         SMALLINT NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @HierarchyTable + N'_LevelNumber_ID') + N' DEFAULT -1,  
  
                    --Auditing  
                    EnterDTM            DATETIME2(3) NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @HierarchyTable + N'_EnterDTM') + N' DEFAULT GETUTCDATE(),  
                    EnterUserID         INT NOT NULL,  
                    EnterVersionID      INT NOT NULL,  
                    LastChgDTM          DATETIME2(3) NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @HierarchyTable + N'_LastChgDTM') + N' DEFAULT GETUTCDATE(),  
                    LastChgUserID       INT NOT NULL,  
                    LastChgVersionID    INT NOT NULL,  
                    LastChgTS           ROWVERSION NOT NULL,  
                    AsOf_ID             INT NULL,  
                    MUID                UNIQUEIDENTIFIER NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @HierarchyTable + N'_MUID') + N' DEFAULT NEWID(),  
  
                    --Create PRIMARY KEY constraint  
                    CONSTRAINT ' + QUOTENAME(N'pk_' + @HierarchyTable) + N'  
                        PRIMARY KEY NONCLUSTERED (Version_ID, ID)  
                        ' + @IndexOptions + N',  
  
                    --Create FOREIGN KEY constraints  
                    CONSTRAINT ' + QUOTENAME(N'fk_' + @HierarchyTable + N'_tblHierarchy_Hierarchy_ID') + N'  
                        FOREIGN KEY (Hierarchy_ID) REFERENCES mdm.tblHierarchy(ID)  
                        ON UPDATE NO ACTION  
                        ON DELETE CASCADE,  
                    CONSTRAINT ' + QUOTENAME(N'fk_' + @HierarchyTable + N'_' + @HierarchyParentTable + N'_Parent_HP_ID') + N'  
                        FOREIGN KEY (Version_ID, Parent_HP_ID) REFERENCES mdm.' + QUOTENAME(@HierarchyParentTable) + N'(Version_ID, ID)  
                        ON UPDATE NO ACTION  
                        ON DELETE NO ACTION, --Cannot use DELETE SET NULL since Version_ID is NOT NULLable  
                    CONSTRAINT ' + QUOTENAME(N'fk_' + @HierarchyTable + N'_' + @EntityTable + N'_Child_EN_ID') + N'  
                        FOREIGN KEY (Version_ID, Child_EN_ID) REFERENCES mdm.' + QUOTENAME(@EntityTable) + N'(Version_ID, ID)  
                        ON UPDATE NO ACTION  
                        ON DELETE CASCADE,  
                    CONSTRAINT ' + QUOTENAME(N'fk_' + @HierarchyTable + N'_' + @HierarchyParentTable + N'_Child_HP_ID') + N'  
                        FOREIGN KEY (Version_ID, Child_HP_ID) REFERENCES mdm.' + QUOTENAME(@HierarchyParentTable) + N'(Version_ID, ID)  
                        ON UPDATE NO ACTION  
                        ON DELETE NO ACTION, --Cannot use DELETE CASCADE due to chance of cycles  
  
                    --Create CHECK constraints  
                    -- Note: the values of the Status_ID column should fall between 1 and 2. The ValidationStatus_ID column should be between 0 and 5. However,  
                    -- we do not enforce this via db constraint because it would slow down table writes and only trusted MDS sproc code should be writing to those columns.  
                    CONSTRAINT ' + QUOTENAME(N'ck_' + @HierarchyTable + N'_ChildType_ID') + N'  
                        CHECK (    (ChildType_ID = 1 AND Child_EN_ID IS NOT NULL AND Child_HP_ID IS NULL) OR  
                                (ChildType_ID = 2 AND Child_HP_ID IS NOT NULL AND Child_EN_ID IS NULL)),  
                    CONSTRAINT ' + QUOTENAME(N'ck_' + @HierarchyTable + N'_Parent_HP_ID_Child_HP_ID') + N'  
                        CHECK (NOT (ChildType_ID = 2 AND Parent_HP_ID = Child_HP_ID)) --Prevent self-reference  
                )  
                ' + @TableOptions + N';  
                ';  
  
            --Direct assignment of expression > 4000 nchars seems to truncate string. Workaround is to concatenate.  
            SET @SQL = @SQL + N'  
                --Ensure uniqueness of keyset  
                CREATE UNIQUE CLUSTERED INDEX ' + QUOTENAME(N'ux_' + @HierarchyTable + N'_Version_ID_Hierarchy_ID_ChildType_ID_Child_HP_ID_Child_EN_ID') + N'  
                    ON mdm.' + QUOTENAME(@HierarchyTable) + N'(Version_ID, Hierarchy_ID, ChildType_ID, Child_HP_ID, Child_EN_ID)  
                    ' + @IndexOptions + N';  
  
                --Required for mdm.udpMembersStatusSet to avoid the deadlock when delete entity members  
                CREATE NONCLUSTERED INDEX ' + QUOTENAME(N'ix_' + @HierarchyTable  + N'_Version_ID_Child_EN_ID') + N'  
                    ON mdm.' + QUOTENAME(@HierarchyTable) + N'([Version_ID],[Child_EN_ID])  
                    ' + @IndexOptions + N';  
  
                --Required for faster hierarchy moves  
                CREATE NONCLUSTERED INDEX ' + QUOTENAME(N'ix_' + @HierarchyTable  + N'_Version_ID_Hierarchy_ID_Parent_HP_ID') + N'  
                    ON mdm.' + QUOTENAME(@HierarchyTable) + N'([Version_ID],[Hierarchy_ID],[Parent_HP_ID])  
                    ' + @IndexOptions + N';  
  
                --Index Status_ID for performance  
                CREATE NONCLUSTERED INDEX ' + QUOTENAME(N'ix_' + @HierarchyTable + N'_Version_ID_Status_ID') + N'  
                    ON mdm.' + QUOTENAME(@HierarchyTable) + N'(Version_ID, Status_ID)  
                    ' + @IndexOptions + N';  
  
                --Create the History (_HR_HS) table  
                CREATE TABLE mdm.' + QUOTENAME(@HierarchyHistoryTable) + N'  
                (  
                    --Identity  
                    Version_ID          INT NOT NULL,  
                    ID                  BIGINT NOT NULL,  
  
                    HR_ID               INT NOT NULL,  
  
                    --Status  
                    Status_ID           TINYINT NOT NULL,  
  
                    --Pointers  
                    Hierarchy_ID        INT NOT NULL,  
                    Parent_HP_ID        INT NULL, --Root is NULL  
                    ChildType_ID        TINYINT NOT NULL,  
                    Child_EN_ID         INT NULL, --Only used when ChildType_ID = 1 (EN)  
                    Child_HP_ID         INT NULL, --Only used when ChildType_ID = 2 (HP)  
  
                    --Data  
                    SortOrder           INT NOT NULL,  
                    LevelNumber         SMALLINT NOT NULL,  
  
                    --Auditing  
                    EnterDTM            DATETIME2(3) NOT NULL,  
                    EnterUserID         INT NOT NULL,  
                    LastChgDTM          DATETIME2(3) NOT NULL,  
                    LastChgUserID       INT NOT NULL,  
                    MUID                UNIQUEIDENTIFIER NOT NULL,  
  
                    --Create PRIMARY KEY constraint  
                    CONSTRAINT ' + QUOTENAME(N'pk_' + @HierarchyHistoryTable) + N'  
                        PRIMARY KEY CLUSTERED (Version_ID, ID)  
  
                    --Cannot have foreign key (Version_ID, HR_ID) on HR table, because HS table is used in OUTPUT clause  
                )  
                ' + @TableOptions + N';  
  
                --Required for udpEntityMemberHistoriesGet operations  
                CREATE NONCLUSTERED INDEX ' + QUOTENAME(N'ix_' + @HierarchyHistoryTable + N'_Version_ID_HR_ID') + N'  
                    ON mdm.' + QUOTENAME(@HierarchyHistoryTable) + N'(Version_ID, HR_ID)  
                    ' + @IndexOptions + N';  
  
                --Create the Annotation (_HR_AN) table  
                CREATE TABLE mdm.' + QUOTENAME(@HierarchyAnnotationTable) + N'  
                (  
                    Version_ID          INT NOT NULL,  
                    ID                  INT IDENTITY(1, 1) NOT NULL,  
  
                    Revision_ID         BIGINT NOT NULL,  
  
                    [Comment]           [NVARCHAR](500) NULL,  
  
                    --Auditing  
                    EnterDTM            DATETIME2(3) NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @HierarchyAnnotationTable  + N'_EnterDTM') + N' DEFAULT GETUTCDATE(),  
                    EnterUserID         INT NOT NULL,  
                    LastChgDTM          DATETIME2(3) NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @HierarchyAnnotationTable  + N'_LastChgDTM') + N' DEFAULT GETUTCDATE(),  
                    LastChgUserID       INT NOT NULL,  
                    LastChgTS           ROWVERSION NOT NULL,  
  
                    --Create PRIMARY KEY constraint  
                    CONSTRAINT ' + QUOTENAME(N'pk_' + @HierarchyAnnotationTable) + N'  
                        PRIMARY KEY CLUSTERED (Version_ID, ID)  
                )  
                ' + @TableOptions + N';  
  
                --Required for udpEntityMemberAnnotationsGet operations  
                CREATE NONCLUSTERED INDEX ' + QUOTENAME(N'ix_' + @HierarchyAnnotationTable + N'_Version_ID_Revision_ID') + N'  
                    ON mdm.' + QUOTENAME(@HierarchyAnnotationTable) + N'(Version_ID, Revision_ID)  
                    ' + @IndexOptions + N';  
                ';  
  
            --Execute the dynamic SQL  
            --PRINT(@SQL);  
            EXEC sp_executesql @SQL;  
  
            --If @StagingRelationshipTable is specified create the Hierarchy Relationship Staging table (_Relationship) in Staging (stg) Schema  
            IF COALESCE(@StagingRelationshipTable, N'') <> N'' BEGIN  
                SET @SQL =  N'  
                    CREATE TABLE [stg].' + QUOTENAME(@StagingRelationshipTable) + N'  
                    (  
                        --Identity  
                        ID                  INT IDENTITY (1, 1) NOT NULL,  
  
                        --Import Specific  
                        RelationshipType    TINYINT NOT NULL,  
  
                        --Status  
                        ImportStatus_ID     TINYINT NOT NULL,  
  
                        --Info  
                        Batch_ID            INT NULL,  
                        BatchTag            NVARCHAR(50) NOT NULL,  
  
                        --Error Code  
                        ErrorCode           INT NOT NULL CONSTRAINT ' + QUOTENAME(N'df_' + @StagingRelationshipTable  + N'_ErrorCode') + N' DEFAULT 0,  
                        HierarchyName       NVARCHAR(250) NOT NULL,  
                        ParentCode          NVARCHAR(250) NOT NULL,  
                        ChildCode           NVARCHAR(250) NOT NULL,  
                        SortOrder           INT,  
  
                        --Create PRIMARY KEY constraint  
                        CONSTRAINT ' + QUOTENAME(N'pk_' + @StagingRelationshipTable) + N'  
                            PRIMARY KEY CLUSTERED (ID),  
  
                        --Create CHECK constraints  
                        CONSTRAINT ' + QUOTENAME(N'ck_' + @StagingRelationshipTable + N'_RelationshipType') + N'  
                            CHECK (RelationshipType BETWEEN 1 AND 2),  
                        CONSTRAINT ' + QUOTENAME(N'ck_' + @StagingRelationshipTable + N'_ImportStatus_ID') + N'  
                            CHECK (ImportStatus_ID BETWEEN 0 and 3)  
                    )  
                    ' + @StagingTableOptions + N';  
  
                    --Index [Batch_ID_ImportStatus_ID_RelationshipType] for performance  
                    CREATE NONCLUSTERED INDEX ' + QUOTENAME(N'ix_' + @StagingRelationshipTable + N'_Batch_ID_ImportStatus_ID_RelationshipType') + N'  
                        ON [stg].' + QUOTENAME(@StagingRelationshipTable) + N'(Batch_ID, ImportStatus_ID, RelationshipType)  
                        INCLUDE([ID], [ErrorCode])  
                        ' + @StagingIndexOptions + N';  
  
                    --Index [BatchTag_ImportStatus_ID] for performance  
                    CREATE NONCLUSTERED INDEX ' + QUOTENAME(N'ix_' + @StagingRelationshipTable + N'_BatchTag_ImportStatus_ID') + N'  
                        ON [stg].' + QUOTENAME(@StagingRelationshipTable) + N'(BatchTag, ImportStatus_ID)  
                        INCLUDE([ID], [Batch_ID])  
                        ' + @StagingIndexOptions + N';'  
  
                EXEC sp_executesql @SQL;  
  
                EXEC mdm.udpEntityStagingCreateRelationshipStoredProcedure @Entity_ID;  
  
            END; --IF  
  
            IF @IsCollectionEnabled = 1  
            BEGIN  
                -- Collections are supported and this's the first time we add EH to this entity, so need to add a column to the collection membership table to allow collections to contain consolidated members.  
                SET @SQL = N'  
                -- Add the Child_HP_ID column.  
                ALTER TABLE mdm.' + QUOTENAME(@CollectionMemberTable) + N'  
                ADD Child_HP_ID         INT NULL; --Used when the child is of type HP (ChildType_ID = 2)  
  
                ALTER TABLE mdm.' + QUOTENAME(@CollectionMemberHistoryTable) + N'  
                ADD Child_HP_ID         INT NULL; --Used when the child is of type HP (ChildType_ID = 2)  
  
                -- Add a FK contraint to the HP table.  
                ALTER TABLE mdm.' + QUOTENAME(@CollectionMemberTable) + N'  
                ADD CONSTRAINT ' + QUOTENAME(N'fk_' + @CollectionMemberTable + N'_' + @HierarchyParentTable + N'_Child_HP_ID') + N'  
                        FOREIGN KEY ([Version_ID], [Child_HP_ID]) REFERENCES mdm.' + QUOTENAME(@HierarchyParentTable) + N'([Version_ID], [ID])  
                        ON DELETE CASCADE;  
                ';  
                --Execute the dynamic SQL  
                --PRINT(@SQL);  
                EXEC sp_executesql @SQL;  
  
                SET @SQL = N'  
                -- Drop and recreate the ChildType_ID constraint so that it includes the Child_HP_ID column.  
                ALTER TABLE mdm.' + QUOTENAME(@CollectionMemberTable) + N'  
                DROP CONSTRAINT ' + QUOTENAME(N'ck_' + @CollectionMemberTable + N'_ChildType_ID') + N';  
                ALTER TABLE mdm.' + QUOTENAME(@CollectionMemberTable) + N'  
                ADD CONSTRAINT ' + QUOTENAME(N'ck_' + @CollectionMemberTable + N'_ChildType_ID') + N'  
                    CHECK ( (ChildType_ID = 1 AND Child_EN_ID IS NOT NULL AND Child_HP_ID IS NULL AND Child_CN_ID IS NULL) OR  
                            (ChildType_ID = 2 AND Child_HP_ID IS NOT NULL AND Child_EN_ID IS NULL AND Child_CN_ID IS NULL) OR  
                            (ChildType_ID = 3 AND Child_CN_ID IS NOT NULL AND Child_EN_ID IS NULL AND Child_HP_ID IS NULL));  
  
                CREATE NONCLUSTERED INDEX ' + QUOTENAME(N'ix_' + @CollectionMemberTable + N'_Version_ID_Child_HP_ID') + N'  
                ON mdm.' + QUOTENAME(@CollectionMemberTable) + N'(Version_ID, Child_HP_ID)  
                WHERE [Child_HP_ID] IS NOT NULL  
                ' + @IndexOptions + N';'  
                EXEC sp_executesql @SQL  
            END;  
  
            --Document the columns we have just physically created:  
  
            --HierarchyParent (HP)  
            INSERT INTO mdm.tblAttribute (Entity_ID,SortOrder,DomainEntity_ID,AttributeType_ID,MemberType_ID,IsSystem,IsReadOnly,IsCode,IsName,[Name],DisplayName,TableColumn,DisplayWidth,DataType_ID,DataTypeInformation,InputMask_ID,EnterUserID,EnterVersionID,LastChgUserID,LastChgVersionID)  
            VALUES  
             (@Entity_ID,1,NULL,3,2,1,1,0,0, N'ID', N'ID', N'ID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID,2,NULL,3,2,1,1,0,0, N'Version_ID', N'Version_ID', N'Version_ID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID,4,NULL,3,2,1,1,0,0, N'Status_ID', N'Status_ID', N'Status_ID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID,5,NULL,3,2,1,1,0,0, N'ValidationStatus_ID', N'ValidationStatus_ID', N'ValidationStatus_ID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID,6,NULL,3,2,1,1,0,0, N'EnterDTM', N'EnterDTM', N'EnterDTM',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID,7,NULL,3,2,1,1,0,0, N'EnterUserID', N'EnterUserID', N'EnterUserID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID,8,NULL,3,2,1,1,0,0, N'EnterVersionID', N'EnterVersionID', N'EnterVersionID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID,9,NULL,3,2,1,1,0,0, N'LastChgDTM', N'LastChgDTM', N'LastChgDTM',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID,10,NULL,3,2,1,1,0,0, N'LastChgUserID', N'LastChgUserID', N'LastChgUserID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID,11,NULL,3,2,1,1,0,0, N'LastChgVersionID', N'LastChgVersionID', N'LastChgVersionID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID,12,NULL,3,2,1,1,0,0, N'LastChgTS', N'LastChgTS', N'LastChgTS',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID,13,NULL,3,2,1,1,0,0, N'Hierarchy_ID', N'Hierarchy_ID', N'Hierarchy_ID',0,1,100,1,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID,14,NULL,1,2,1,0,0,1, N'Name', N'Name', N'Name',250,1,250,1,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID,15,NULL,1,2,1,0,1,0, N'Code', N'Code', N'Code',250,1,250,1,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID,16,NULL,3,2,1,1,0,0, N'MUID', N'MUID', N'MUID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID,17,NULL,3,2,1,1,0,0, N'AsOf_ID', N'AsOf_ID', N'AsOf_ID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID,18,NULL,3,2,1,0,0,0, N'ChangeTrackingMask', N'ChangeTrackingMask', N'ChangeTrackingMask',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ;  
  
            --Hierarchy (HR)  
            INSERT INTO mdm.tblAttribute (Entity_ID,SortOrder,DomainEntity_ID,AttributeType_ID,MemberType_ID,IsSystem,IsReadOnly,[Name],DisplayName,TableColumn,DisplayWidth,DataType_ID,DataTypeInformation,InputMask_ID,EnterUserID,EnterVersionID,LastChgUserID,LastChgVersionID)  
            VALUES  
             (@Entity_ID, 1,NULL,3,4,1,1, N'ID', N'ID', N'ID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 2,NULL,3,4,1,1, N'Version_ID', N'Version_ID', N'Version_ID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 3,NULL,3,4,1,1, N'Status_ID', N'Status_ID', N'Status_ID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 4,NULL,3,4,1,1, N'ValidationStatus_ID', N'ValidationStatus_ID', N'ValidationStatus_ID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 5,NULL,3,4,1,1, N'EnterDTM', N'EnterDTM', N'EnterDTM',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 6,NULL,3,4,1,1, N'EnterUserID', N'EnterUserID', N'EnterUserID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 7,NULL,3,4,1,1, N'EnterVersionID', N'EnterVersionID', N'EnterVersionID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 8,NULL,3,4,1,1, N'LastChgDTM', N'LastChgDTM', N'LastChgDTM',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 9,NULL,3,4,1,1, N'LastChgUserID', N'LastChgUserID', N'LastChgUserID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 10,NULL,3,4,1,1, N'LastChgVersionID', N'LastChgVersionID', N'LastChgVersionID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 11,NULL,3,4,1,1, N'LastChgTS', N'LastChgTS', N'LastChgTS',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 12,NULL,3,4,1,1, N'Hierarchy_ID', N'Hierarchy_ID', N'Hierarchy_ID',0,1,100,1,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 13,NULL,3,4,1,1, N'Parent_HP_ID', N'Parent_HP_ID', N'Parent_HP_ID',0,1,100,1,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 14,NULL,3,4,1,1, N'Child_EN_ID', N'Child_EN_ID', N'Child_EN_ID',0,1,100,1,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 15,NULL,3,4,1,1, N'Child_HP_ID', N'Child_HP_ID', N'Child_HP_ID',0,1,100,1,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 16,NULL,3,4,1,1, N'ChildType_ID', N'ChildType_ID', N'ChildType_ID',0,1,100,1,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 17,NULL,3,4,1,1, N'SortOrder', N'SortOrder', N'SortOrder',0,1,NULL,1,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 18,NULL,1,4,1,1, N'LevelNumber', N'LevelNumber', N'LevelNumber',0,2,NULL,1,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 20,NULL,3,4,1,1, N'MUID', N'MUID', N'MUID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ,(@Entity_ID, 21,NULL,3,4,1,1, N'AsOf_ID', N'AsOf_ID', N'AsOf_ID',0,0,NULL,0,@User_ID,@Version_ID,@User_ID,@Version_ID)  
            ;  
        END; --if  
  
        SELECT @HierarchyTable = HierarchyTable FROM mdm.tblEntity WHERE ID = @Entity_ID;  
  
        --Update/Insert Hierarchy details  
        IF @EditMode = @EditMode_Update  
        BEGIN  
  
            --Update details in Hierarchy table  
            UPDATE mdm.tblHierarchy SET  
                [Name] = ISNULL(@HierarchyName, [Name]),  
                IsMandatory = ISNULL(@IsMandatory, IsMandatory),  
                LastChgDTM = @CurrentDTM,  
                LastChgUserID = @User_ID,  
                LastChgVersionID = @Version_ID  
            WHERE  
                ID = @ExistingHierarchy_ID;  
  
            --Populate output parameters  
            SET @Return_MUID = @ExistingHierarchy_MUID;  
  
            --Add all leaf nodes if mandatory  
            IF @IsMandatory = 1  
            BEGIN  
  
                SET @SQL = N'  
                DECLARE @TempTable TABLE (ID INT NOT NULL, Version_ID INT NOT NULL);  
                DECLARE @TempID AS INT, @Version_ID AS INT;  
  
                INSERT INTO @TempTable (ID, Version_ID)  
                SELECT  
                    ID,  
                    Version_ID  
                FROM  
                    mdm.' + QUOTENAME(@EntityTable) + N' AS EN  
                WHERE  
                    EN.Status_ID = 1 AND  
                    EN.ID NOT IN  
                    (  
                        SELECT Child_EN_ID  
                        FROM mdm.' + QUOTENAME(@HierarchyTable) + N' AS HR  
                        WHERE  
                            HR.ChildType_ID = 1 AND  
                            HR.Status_ID = 1 AND  
                            HR.Hierarchy_ID = @Hierarchy_ID  
                    )  
                 ORDER BY ID ASC;  
  
                WHILE EXISTS(SELECT 1 FROM @TempTable) BEGIN  
  
                    SELECT TOP 1 @TempID = ID, @Version_ID = Version_ID FROM @TempTable  ORDER BY ID;  
  
                    EXEC mdm.udpHierarchyCreate @User_ID, @Version_ID, @Entity_ID, @Hierarchy_ID, 0, @TempID, 1;  
  
                    DELETE FROM @TempTable WHERE ID = @TempID AND Version_ID = @Version_ID;  
  
                END; --while';  
  
                --Execute the dynamic SQL  
                --PRINT(@SQL):  
                EXEC sp_executesql @SQL,  
                N'@User_ID INT, @Entity_ID INT, @Hierarchy_ID INT',  
                @User_ID, @Entity_ID, @ExistingHierarchy_ID;  
  
            END; --if  
  
        END  
        ELSE  
        BEGIN --New Hierarchy  
  
            -- Validate @Name  
            IF NULLIF(@HierarchyName, N'') IS NULL  
            BEGIN  
                RAISERROR('MDSERR100003|The Name is not valid.', 16, 1);  
                RETURN;  
            END;  
  
            --Accept an explicit MUID (for clone operations) or generate a new one  
            SET @Return_MUID = ISNULL(@Hierarchy_MUID, NEWID());  
  
            --Insert details into Hierarchy table  
            INSERT INTO mdm.tblHierarchy  
            (  
                 Entity_ID  
                ,[Name]  
                ,IsMandatory  
                ,MUID  
                ,EnterDTM  
                ,EnterUserID  
                ,EnterVersionID  
                ,LastChgDTM  
                ,LastChgUserID  
                ,LastChgVersionID  
            )  
            VALUES  
            (  
                @Entity_ID,  
                LEFT(@HierarchyName, 50),  
                @IsMandatory,  
                @Return_MUID,  
                @CurrentDTM,  
                @User_ID,  
                @Version_ID,  
                @CurrentDTM,  
                @User_ID,  
                @Version_ID  
            );  
  
            --Save the identity value  
            SET @ExistingHierarchy_ID = SCOPE_IDENTITY();  
  
            /*  
            Copy all the members into the hierarchy if it is a mandatory hierarchy (in case the entity was created  
            without a Hierarchy and then one was added) or another Hierarchy was just added.  
            */  
            IF @IsMandatory = 1 BEGIN  
  
                SELECT @SQL = N'  
                INSERT INTO mdm.' + QUOTENAME(@HierarchyTable) + N'  
                (  
                    Version_ID,  
                    Status_ID,  
                    ValidationStatus_ID,  
                    Hierarchy_ID,  
                    Parent_HP_ID,  
                    ChildType_ID,  
                    Child_EN_ID,  
                    SortOrder,  
                    EnterUserID,  
                    EnterVersionID,  
                    LastChgUserID,  
                    LastChgVersionID  
                )  
                SELECT  
                    E.Version_ID,  
                    1,  
                    0,  
                    @Hierarchy_ID,  
                    NULL,    --Parent_HP_ID  
                    1,       --ChildType_ID = EN  
                    E.ID,    --Child_EN_ID  
                    E.ID,    --SortOrder  
                    @User_ID,  
                    @Version_ID,  
                    @User_ID,  
                    @Version_ID  
                FROM mdm.' + QUOTENAME(@EntityTable) + N' AS E  
                INNER JOIN mdm.tblModelVersion AS V  
                    ON E.Version_ID = V.ID  
                WHERE V.Status_ID <> 3;';  
  
                --Execute the dynamic SQL  
                --PRINT(@SQL);  
                EXEC sp_executesql @SQL,  
                    N'@User_ID INT, @Version_ID INT, @Hierarchy_ID INT',  
                    @User_ID, @Version_ID, @ExistingHierarchy_ID;  
  
            END; --if  
        END; --if  
  
        --Recreate the views  
        EXEC mdm.udpCreateViews @Model_ID = @Model_ID;  
        EXEC mdm.udpEntityStagingCreateErrorDetailViews @Entity_ID = @Entity_ID;  
  
        --Recreate leaf staging SProc when HP and CM tables are added.  
        IF @IsHierarchyEnabled = 0 -- if hierarchies were not already enabled ...  
            AND @RecreateLeafStagingProc = 1  
        BEGIN  
            EXEC mdm.udpEntityStagingCreateLeafStoredProcedure @Entity_ID;  
        END  
  
        --Return values  
        SET @Return_ID = @ExistingHierarchy_ID;  
  
        --Commit only if we are not nested  
        IF @TranCounter = 0 COMMIT TRANSACTION;  
        RETURN(0);  
  
    END TRY  
    --Compensate as necessary  
    BEGIN CATCH  
  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        IF @TranCounter = 0 ROLLBACK TRANSACTION;  
        ELSE IF XACT_STATE() <> -1 ROLLBACK TRANSACTION TX;  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
  
        SELECT @Return_ID = NULL, @Return_MUID = NULL;  
        RETURN;  
  
    END CATCH;  
  
    SET NOCOUNT OFF;  
END; --proc
go

