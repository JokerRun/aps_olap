/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Call the udpIsCodeGenEnabled to check whether an entity supports code generation.  
  
Example  
    DECLARE @IsCodeGenEnabled BIT;  
    EXEC @IsCodeGenEnabled = mdm.udpIsCodeGenEnabled @Entity_ID = 20;  
*/  
CREATE PROCEDURE mdm.udpIsCodeGenEnabled  
(  
    @Entity_ID		INT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
AS BEGIN  
  
    SET NOCOUNT ON;  
  
    DECLARE @IsCodeGenEnabled BIT = 0;  
  
    IF EXISTS(SELECT * FROM mdm.tblCodeGenInfo WHERE EntityId = @Entity_ID)  
        BEGIN  
            SET @IsCodeGenEnabled = 1;  
        END  
  
    -- Return the result of the SPROC  
    RETURN @IsCodeGenEnabled;  
  
END; --proc mdm.udpIsCodeGenEnabled
go

