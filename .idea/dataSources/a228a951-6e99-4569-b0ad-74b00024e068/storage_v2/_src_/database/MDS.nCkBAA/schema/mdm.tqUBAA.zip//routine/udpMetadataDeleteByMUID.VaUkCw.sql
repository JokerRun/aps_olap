/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    Deletes the metadata object pertaining to the given MUID. Verifies that  
    the given user has appropriate permission  
*/  
CREATE PROCEDURE mdm.udpMetadataDeleteByMUID  
(  
     @User_ID       INT  
    ,@Object_MUID   UNIQUEIDENTIFIER  
    ,@ObjectType_ID TINYINT -- The object type of the Muid being passed in.  
    ,@CorrelationID UNIQUEIDENTIFIER = NULL -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE   
         @FunctionalPrivilege_Versions  TINYINT = 2  
        ,@FunctionalPrivilege_SysAdmin  TINYINT = 5  
  
        ,@ObjectType_Model                  TINYINT = 1  
        ,@ObjectType_DerivedHierarchy       TINYINT = 2  
        ,@ObjectType_DerivedHierarchyLevel  TINYINT = 3  
        ,@ObjectType_Version                TINYINT = 4  
        ,@ObjectType_Entity                 TINYINT = 5  
        ,@ObjectType_Hierarchy              TINYINT = 6  
        ,@ObjectType_Attribute              TINYINT = 7  
        ,@ObjectType_AttributeGroup         TINYINT = 8  
        ,@ObjectType_VersionFlag            TINYINT = 10  
        ,@ObjectType_Index                  TINYINT = 23  
        ;  
  
    -- Functional permission check  
    IF mdm.udfSecurityUserFunctionIsAllowed(@User_ID, @FunctionalPrivilege_SysAdmin) = 0  
        AND (@ObjectType_ID NOT IN (@ObjectType_Version, @ObjectType_VersionFlag) -- can modify versions and version flags with Versions functional privilege  
            OR mdm.udfSecurityUserFunctionIsAllowed(@User_ID, @FunctionalPrivilege_Versions) = 0)  
    BEGIN  
        RAISERROR('MDSERR120002|The user does not have permission to perform this operation.', 16, 1);  
        RETURN;  
    END  
  
    -- Model admin check  
    DECLARE @IsModelAdmin  INT;  
    EXEC mdm.udpUserIsModelAdministrator @User_ID = @User_ID, @ObjectType_ID = @ObjectType_ID, @Object_MUID = @Object_MUID, @Return_ID = @IsModelAdmin OUTPUT  
    IF COALESCE(@IsModelAdmin, 0) = 0  
    BEGIN  
        RAISERROR('MDSERR120003|The user does not have permission or the object ID is not valid.', 16, 1);  
        RETURN;  
    END  
  
    --Start transaction, being careful to check if we are nested  
    DECLARE @TranCounter INT = @@TRANCOUNT;  
    IF @TranCounter > 0 SAVE TRANSACTION TX;  
    ELSE BEGIN TRANSACTION;  
  
    BEGIN TRY  
  
        -- Check for dependencies that would prevent deletion.  
        DECLARE @Object_ID INT;  
        EXEC mdm.udpObjectDeleteCheckByMUID @Object_MUID = @Object_MUID, @ObjectType_ID = @ObjectType_ID, @Object_ID = @Object_ID OUTPUT  
  
        IF COALESCE(@Object_ID, 0) <= 0  
        BEGIN  
            RAISERROR('MDSERR120003|The user does not have permission or the object ID is not valid.', 16, 1);  
            RETURN;  
        END  
  
        IF @ObjectType_ID = @ObjectType_Model  
        BEGIN  
            EXEC mdm.udpModelDelete @Model_ID = @Object_ID;  
        END   
          
        ELSE IF @ObjectType_ID = @ObjectType_DerivedHierarchy  
        BEGIN  
            EXEC mdm.udpDerivedHierarchyDelete @ID = @Object_ID;  
        END   
          
        ELSE IF @ObjectType_ID = @ObjectType_DerivedHierarchyLevel  
        BEGIN  
            EXEC mdm.udpDerivedHierarchyDetailDelete @ID = @Object_ID;  
        END   
          
        ELSE IF @ObjectType_ID = @ObjectType_Version  
        BEGIN  
            EXEC mdm.udpVersionDelete @Version_ID = @Object_ID;  
        END   
          
        ELSE IF @ObjectType_ID = @ObjectType_Entity  
        BEGIN  
            EXEC mdm.udpEntityDelete @Entity_ID = @Object_ID, @CreateViewsInd = 1;  
        END   
          
        ELSE IF @ObjectType_ID = @ObjectType_Hierarchy  
        BEGIN  
            EXEC mdm.udpEntityHierarchyDelete @User_ID = @User_ID, @Hierarchy_ID = @Object_ID  
        END   
          
        ELSE IF @ObjectType_ID = @ObjectType_Attribute  
        BEGIN  
            EXEC mdm.udpAttributeDelete @Attribute_ID = @Object_ID, @CreateViewsInd = 1  
        END   
          
        ELSE IF @ObjectType_ID = @ObjectType_AttributeGroup  
        BEGIN  
            EXEC mdm.udpAttributeGroupDelete @ID = @Object_ID;  
        END   
          
        ELSE IF @ObjectType_ID = @ObjectType_VersionFlag  
        BEGIN  
            EXEC mdm.udpModelVersionFlagDelete @VersionFlag_ID = @Object_ID;  
        END   
          
        ELSE IF @ObjectType_ID = @ObjectType_Index  
        BEGIN  
            EXEC mdm.udpIndexDelete @ID = @Object_ID;  
        END   
  
        --Commit only if we are not nested  
        IF @TranCounter = 0 COMMIT TRANSACTION;  
        RETURN(0);  
  
    END TRY  
    --Compensate as necessary  
    BEGIN CATCH  
  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        IF @TranCounter = 0 ROLLBACK TRANSACTION;  
        ELSE IF XACT_STATE() <> -1 ROLLBACK TRANSACTION TX;  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
  
    END CATCH;  
  
    SET NOCOUNT OFF;  
END; --proc
go

