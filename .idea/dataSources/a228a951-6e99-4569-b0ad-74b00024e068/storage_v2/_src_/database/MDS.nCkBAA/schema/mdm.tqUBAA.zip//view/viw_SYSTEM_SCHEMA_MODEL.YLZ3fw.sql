/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
    SELECT * FROM mdm.viw_SYSTEM_SCHEMA_MODEL  
*/  
CREATE VIEW mdm.viw_SYSTEM_SCHEMA_MODEL  
/*WITH SCHEMABINDING*/  
AS  
  
  
SELECT	  
    mod.ID,  
    mod.MUID,  
    mod.Name,  
    mod.[Description],  
    mod.LogRetentionDays LogRetentionDays,  
    COALESCE(mod.EnterUserID, 0) EnteredUser_ID,  
    COALESCE(usrE.MUID, CAST(0x0 AS UNIQUEIDENTIFIER)) EnteredUser_MUID,  
    usrE.UserName EnteredUser_UserName,  
    mod.EnterDTM EnteredUser_DTM,  
    COALESCE(mod.LastChgUserID, 0) LastChgUser_ID,  
    COALESCE(usrL.MUID, CAST(0x0 AS UNIQUEIDENTIFIER)) LastChgUser_MUID,  
    usrL.UserName LastChgUser_UserName,  
    mod.LastChgDTM LastChgUser_DTM  
  
FROM  
    mdm.tblModel [mod]   
    LEFT JOIN mdm.tblUser usrE  
        ON mod.EnterUserID = usrE.ID  
    LEFT JOIN mdm.tblUser usrL  
        ON mod.LastChgUserID = usrL.ID
go

