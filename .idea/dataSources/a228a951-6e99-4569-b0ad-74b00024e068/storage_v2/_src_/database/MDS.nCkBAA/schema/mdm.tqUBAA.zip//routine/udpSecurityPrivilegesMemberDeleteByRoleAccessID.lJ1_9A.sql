/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
EXEC mdm.udpSecurityPrivilegesMemberDeleteByRoleAccessID 1, 100  
  
*/  
CREATE PROCEDURE mdm.udpSecurityPrivilegesMemberDeleteByRoleAccessID  
(  
    @SystemUser_ID      INT,  
    @RoleAccess_ID      INT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON  
  
    DECLARE @Role_ID            INT,  
            @Version_ID         INT,  
            @Entity_ID          INT,  
            @Hierarchy_ID       INT,  
            @HierarchyType_ID   INT;  
  
    SELECT   
        @Role_ID=Role_ID,  
        @Version_ID=Version_ID,  
        @Entity_ID=[Entity_ID],  
        @Hierarchy_ID=[Hierarchy_ID],  
        @HierarchyType_ID=[HierarchyType_ID]  
    FROM mdm.tblSecurityRoleAccessMember   
    WHERE ID = @RoleAccess_ID;  
  
    DECLARE @SecurityMemberProcessEvent mdm.SecurityMemberProcessEvent  
    INSERT @SecurityMemberProcessEvent ([User_ID], [Entity_ID], Version_ID)  
    SELECT DISTINCT [User_ID], [Entity_ID], [Version_ID]  
    FROM [mdm].[viw_SYSTEM_SECURITY_ROLE_MEMBER] rm  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ROLE ur  
    ON rm.Role_ID = ur.Role_ID  
    WHERE rm.Role_ID = @Role_ID   
        AND rm.Version_ID = @Version_ID  
        AND Hierarchy_ID = @Hierarchy_ID  
        AND HierarchyType_ID = @HierarchyType_ID  
  
    DELETE FROM mdm.tblSecurityRoleAccessMember WHERE ID = @RoleAccess_ID;  
  
    EXEC mdm.udpSecurityMemberProcessRebuildEvent @SecurityMemberProcessEvent, 1;  
  
    SET NOCOUNT OFF  
END --proc
go

