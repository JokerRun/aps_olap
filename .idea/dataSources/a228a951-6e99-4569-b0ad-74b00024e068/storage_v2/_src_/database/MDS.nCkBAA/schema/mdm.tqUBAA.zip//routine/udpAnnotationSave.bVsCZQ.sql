/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
--This can be called to save or create a new Annotations  
--new annotation Transaction  
  
--new via Member: Account/Version 3/Account/1110  
exec mdm.udpAnnotationSave 1,7,4,null,41,"test annotation 1"  
  
--update existing  
exec mdm.udpAnnotationSave @UserID=1,@Model_ID=7,@AnnotationID=8,@Version_ID=2,@TransactionID=NULL,@Comment=N'Updated annotation: 20081001235440'  
  
*/  
CREATE PROCEDURE mdm.udpAnnotationSave  
(  
    @UserID         INT,  
    @Model_ID       INT,  
    @Version_ID     INT,  
    @AnnotationID   INT = NULL,  
    @TransactionID  INT = NULL,  
    @Comment        NVARCHAR(500),  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
  
    --Validate Input  
    IF @Model_ID IS NULL OR @Version_ID IS NULL OR (@AnnotationID IS NULL AND @TransactionID IS NULL)  
    BEGIN  
        RAISERROR('MDSERR100010|The Parameters are not valid.', 16, 1);  
        RETURN(1);  
    END  
  
    IF @AnnotationID IS NOT NULL  
    BEGIN  
        DECLARE @AnnotationTableName    SYSNAME = mdm.udfGetTransactionAnnotationTableName(@Model_ID)  
                ,@SQL                   NVARCHAR(MAX);  
  
        SET @SQL = N'  
        UPDATE [mdm].' + QUOTENAME(@AnnotationTableName) + N'  
        SET Comment = @Comment,  
            LastChgDTM = GETUTCDATE(),  
            LastChgUserID = @UserID  
        WHERE ID = @AnnotationID AND Version_ID = @Version_ID  
        ';  
        EXEC sp_executesql @SQL, N'@Version_ID INT, @AnnotationID INT, @Comment NVARCHAR(500), @UserID INT', @Version_ID, @AnnotationID, @Comment, @UserID;  
    END ELSE  
    IF @TransactionID IS NOT NULL  
    BEGIN  
        EXEC [mdm].[udpTransactionAnnotationSave] @UserID, @Model_ID, @Version_ID, @TransactionID, @Comment  
    END  
  
END --proc
go

