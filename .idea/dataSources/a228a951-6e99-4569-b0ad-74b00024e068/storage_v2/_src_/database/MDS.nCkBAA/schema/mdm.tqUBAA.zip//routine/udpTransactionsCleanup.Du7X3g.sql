/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
    SELECT * FROM mdm.tbl_7_TR where LastChgDTM < '2014-10-22';  
    EXEC mdm.udpLogCLeanup 7, '2014-10-22';  
    SELECT * FROM mdm.tbl_7_TR where LastChgDTM < '2014-10-22';  
*/  
CREATE PROCEDURE mdm.udpTransactionsCleanup  
(  
    @Model_ID    INT,  
    @CleanupOlderThanDate  DATE,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS N'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    DECLARE  
        @SQL                            NVARCHAR(MAX),  
         --Annotation table names  
        @TableName                      SYSNAME,  
        @TransactionTableName           SYSNAME,  
        @AnnotationTableName            SYSNAME,  
        @ValidationLogHistoryTableName  SYSNAME;  
  
  
    SET @TransactionTableName = mdm.udfGetTransactionTableName(@Model_ID);  
    SET @AnnotationTableName = mdm.udfGetTransactionAnnotationTableName(@Model_ID);  
  
    BEGIN TRY  
  
        --Delete all Annotations on transactions being deleted issues  
        SET @SQL = CONCAT(N'  
        DELETE an  
        FROM [mdm].', QUOTENAME(@AnnotationTableName), N' an  
        INNER JOIN[mdm].', QUOTENAME(@TransactionTableName), N' tr  
        ON an.Transaction_ID = tr.ID AND an.Version_ID = tr.Version_ID  
        WHERE tr.LastChgDTM <= @CleanupOlderThanDate');  
        EXEC sp_executesql @SQL, N'@CleanupOlderThanDate DATE', @CleanupOlderThanDate;  
  
  
        --Delete all transactions older than the specified date  
        SET @SQL = CONCAT(N'  
        DELETE FROM [mdm].' , QUOTENAME(@TransactionTableName) , N'  
        WHERE LastChgDTM <= @CleanupOlderThanDate');  
  
        EXEC sp_executesql @SQL, N'@CleanupOlderThanDate DATE', @CleanupOlderThanDate;  
  
        DECLARE entity_cursor CURSOR  
            FOR  
                SELECT EntityTable AS TableName  
                FROM mdm.tblEntity  
                WHERE Model_ID = @Model_ID AND EntityTable IS NOT NULL  
                UNION ALL  
                SELECT HierarchyParentTable AS TableName  
                FROM mdm.tblEntity  
                WHERE Model_ID = @Model_ID AND HierarchyParentTable IS NOT NULL  
                UNION ALL  
                SELECT CollectionTable AS TableName  
                FROM mdm.tblEntity  
                WHERE Model_ID = @Model_ID AND CollectionTable IS NOT NULL  
                UNION ALL  
                SELECT HierarchyTable AS TableName  
                FROM mdm.tblEntity  
                WHERE Model_ID = @Model_ID AND HierarchyTable IS NOT NULL  
                UNION ALL  
                SELECT CollectionMemberTable AS TableName  
                FROM mdm.tblEntity  
                WHERE Model_ID = @Model_ID AND CollectionMemberTable IS NOT NULL  
        OPEN entity_cursor  
        FETCH NEXT FROM entity_cursor INTO @TableName  
  
        WHILE @@FETCH_STATUS = 0  
        BEGIN  
            SET @TransactionTableName = CONVERT(SYSNAME, CONCAT(@TableName, '_HS'));  
            SET @AnnotationTableName = CONVERT(SYSNAME, CONCAT(@TableName, '_AN'));  
  
            SET @SQL = CONCAT(N'  
            DELETE an  
            FROM [mdm].', QUOTENAME(@AnnotationTableName), N' an  
            INNER JOIN[mdm].', QUOTENAME(@TransactionTableName), N' tr  
            ON an.Revision_ID = tr.ID AND an.Version_ID = tr.Version_ID  
            WHERE tr.LastChgDTM <= @CleanupOlderThanDate;');  
            EXEC sp_executesql @SQL, N'@CleanupOlderThanDate DATE', @CleanupOlderThanDate;  
  
            SET @SQL = CONCAT(N'  
            DELETE FROM [mdm].' , QUOTENAME(@TransactionTableName) , N'  
            WHERE LastChgDTM <= @CleanupOlderThanDate;');  
  
            EXEC sp_executesql @SQL, N'@CleanupOlderThanDate DATE', @CleanupOlderThanDate;  
            FETCH NEXT FROM entity_cursor INTO @TableName  
        END  
  
        CLOSE entity_cursor;  
        DEALLOCATE entity_cursor;  
  
        RETURN(0);  
    END TRY  
    --Compensate as necessary  
    BEGIN CATCH  
  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
  
        --On error, return NULL results  
        --SELECT @Return_ID = NULL;  
        RETURN(1);  
  
    END CATCH;  
  
    SET NOCOUNT OFF  
END --proc
go

