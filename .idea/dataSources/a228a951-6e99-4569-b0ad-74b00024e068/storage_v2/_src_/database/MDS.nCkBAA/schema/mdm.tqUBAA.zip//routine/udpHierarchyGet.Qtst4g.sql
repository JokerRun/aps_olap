/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    THIS SPROC (IN THEORY) SHOULD ONLY BE CALLED BY udpHierarchyMembersGet.  
    The reason nothing should call this sproc directly is that the wrapper(udpHierarchyMembersGet) was written  
    to do the lookups necesary to provide the parameters for this sproc.  
  
    --Examples  
    EXEC mdm.udpHierarchyGet @User_ID=1,@Version_ID=4,@Hierarchy_ID=1,@HierarchyType_ID=0,@Item_ID=6,@ItemType_ID=0,@ParentItem_ID=0,@ParentItemType_ID=0,@Parent_ID=0,@RowLimit=N'51'  
*/  
  
CREATE PROCEDURE mdm.udpHierarchyGet  
(  
    @User_ID                INT,  
    @Version_ID             INT,  
    @Hierarchy_ID           INT,  
    @HierarchyType_ID       TINYINT,  
    @Item_ID                INT = NULL,  
    @ItemType_ID            INT = NULL,  
    @ParentItem_ID          INT = NULL,  
    @ParentItemType_ID      INT = NULL,  
    @Parent_ID              INT,  
    @RowLimit               INT = NULL,  
    @IncludeDeny            BIT = 0,  
    @AnchorNullRecursions   BIT = 0,  
    @ReturnXML              BIT = 0,  
    @EntityMemberTypeID     TINYINT = 0,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE @EntityTable                    SYSNAME,  
            @HierarchyParentTable           SYSNAME,  
            @HierarchyTable                 SYSNAME,  
            @HierarchyView                  SYSNAME,  
            @CollectionMemberTable          SYSNAME,  
            @CollectionTable                SYSNAME,  
            @ViewName                       SYSNAME,  
            @SQL                            NVARCHAR(MAX),  
            @Model_ID                       INT,  
            @ModelPrivilege_ID              INT,  
            @ModelAccessPermission          TINYINT,  
            @ModelLeafPrivilege_ID          INT,  
            @ModelLeafAccessPermission      TINYINT,  
            @ModelConsolidatedPrivilege_ID  INT,  
            @ModelConsolidatedAccessPermission  TINYINT,  
            @HRPrivilege_ID                 INT,  
            @HRAccessPermission             TINYINT,  
            @MemberType_ID                  TINYINT,  
            @Object_ID                      INT, --Security object  
            @SecItem_ID                     INT, --Security item  
            @RootSecured                    INT,  
            @MemberPrivilege_ID             INT,  
            @MemberAccessPermission         TINYINT,  
            @Entity_ID                      INT,  
            @UseMemberSecurity              INT, --0=No,1=Yes,2 LeafOnly  
  
            @MemberType_Leaf                TINYINT = 1,  
            @MemberType_Consolidated        TINYINT = 2,  
  
            @EntityMUID                     UNIQUEIDENTIFIER,  
            @HierarchyMUID                  UNIQUEIDENTIFIER,  
            @strEntityName                  NVARCHAR(MAX),  
            @ParamList                      NVARCHAR(MAX),  
            @RowLimitText                   NVARCHAR(11),  
            @MemberSecurityCTE              NVARCHAR(MAX),  
            @EntitySecurityTable            SYSNAME,  
            @HierarchyParentSecurityTable   SYSNAME;  
  
    DECLARE @ProcID SYSNAME; SET @ProcID = OBJECT_NAME(@@PROCID);  
  
    DECLARE @ExplicitHierarchyType_ID TINYINT = 0;  
    DECLARE @DerivedHierarchyType_ID TINYINT = 1;  
    DECLARE @CollectionType_ID TINYINT = 2;  
  
    IF @HierarchyType_ID < 0 OR @HierarchyType_ID > 2 -- Hierarchy type should be 0, 1, 2  
        OR (@HierarchyType_ID <> 0 AND (@Item_ID IS NULL OR @ItemType_ID IS NULL OR @ItemType_ID < 0 OR @ItemType_ID > 3)) -- Item type and ID can not be NULL, item type should be 0-3  
    BEGIN  
        RAISERROR('MDSERR100010|The Parameters are not valid.', 16, 1);  
        RETURN(1);  
    END  
  
    SET @MemberPrivilege_ID = 4;  
    SET @MemberAccessPermission = 7;  
  
    SELECT @Model_ID = Model_ID FROM mdm.tblModelVersion WHERE ID = @Version_ID  
  
    SET @RootSecured=0  
  
    --Get Entity_ID  
    IF @HierarchyType_ID = @ExplicitHierarchyType_ID --Explicit  
        BEGIN  
            SET @Entity_ID = @Item_ID  
        END  
    ELSE --Derived  
        BEGIN  
            SET @Entity_ID =  
            CASE  
                WHEN @ItemType_ID = 0 THEN @Item_ID  
                WHEN @ItemType_ID = 1 THEN (SELECT DomainEntity_ID FROM mdm.tblAttribute WHERE ID = @Item_ID)  
                WHEN @ItemType_ID = 2 THEN (SELECT Entity_ID FROM mdm.tblHierarchy WHERE ID = @Item_ID)  
                WHEN @ItemType_ID = 3 THEN @Item_ID  
            END  
        END  
  
  
    --Assign the Object ID  
    --This used be different based on the Parent_ID. See TFS 142134  
    SET @Object_ID = CASE @HierarchyType_ID  
        WHEN @ExplicitHierarchyType_ID THEN 6  
        WHEN @CollectionType_ID THEN 11  
        ELSE  
        CASE @ItemType_ID  
            WHEN 0 THEN 3  
            WHEN 1 THEN 4  
            WHEN 2 THEN 6  
            WHEN 3 THEN 3  
            ELSE 0 END  
        END  
  
    /*  
    Assign the member type:  
    ----------------------  
    2: Default value  
    1: Start ID = -1 indicates Unused (non-mandatory hierarchy)  
    1: Hierarchy ID = 1 indicates a Derived Hierarchy  
    3: Hierarchy ID = 2 indicates a Collection  
    */  
    SELECT @MemberType_ID = CASE WHEN @Parent_ID = -1 THEN 1 WHEN @HierarchyType_ID = @DerivedHierarchyType_ID THEN 1 WHEN @HierarchyType_ID = @CollectionType_ID THEN 3 ELSE 2 END  
  
    --For an Explicit Hierarchy the MemberType ID represents the Item ID  
    IF @HierarchyType_ID = @ExplicitHierarchyType_ID SET @Item_ID = ISNULL(@Item_ID, (SELECT Entity_ID FROM mdm.tblHierarchy WHERE ID = @Hierarchy_ID))  
  
    --Determine the item ID to use when determining the default security permissions (Explicit Hierarchies are secured on the Hierarchy_ID).  
    --This used be different based on the Parent_ID.  See TFS 142134  
    SET @SecItem_ID = CASE @HierarchyType_ID WHEN @ExplicitHierarchyType_ID THEN @Hierarchy_ID ELSE @Item_ID END  
  
    --Fetch the default privilege for the selected member type within the current hierarchy.  
    --SELECT @ModelPrivilege_ID = mdm.udfSecurityUserMemberDefault(@User_ID, @SecItem_ID, @Object_ID, @MemberType_ID)  
    --SELECT @ModelLeafPrivilege_ID = mdm.udfSecurityUserMemberDefault(@User_ID, @SecItem_ID, @Object_ID, 1)  
    --PERF - moved these calls to a udp to decrease the execution plan compile time.  
    EXEC mdm.udpSecurityUserMemberDefault  
        @User_ID = @User_ID,  
        @Item_ID = @SecItem_ID,  
        @Object_ID = @Object_ID,  
        @MemberType_ID = @MemberType_ID,  
        @Privilege_ID = @ModelPrivilege_ID OUTPUT,  
        @AccessPermission = @ModelAccessPermission OUTPUT;  
  
    EXEC mdm.udpSecurityUserMemberDefault  
        @User_ID = @User_ID,  
        @Item_ID = @SecItem_ID,  
        @Object_ID = @Object_ID,  
        @MemberType_ID = 1,  
        @Privilege_ID = @ModelLeafPrivilege_ID OUTPUT,  
        @AccessPermission = @ModelLeafAccessPermission OUTPUT;  
  
        IF(@MemberType_ID = 3)  
        BEGIN  
            EXEC mdm.udpSecurityUserMemberDefault  
                @User_ID = @User_ID,  
                @Item_ID = @SecItem_ID,  
                @Object_ID = @Object_ID,  
                @MemberType_ID = 2,  
                @Privilege_ID = @ModelConsolidatedPrivilege_ID OUTPUT,  
                @AccessPermission = @ModelConsolidatedAccessPermission OUTPUT;  
        END  
  
    --Initialize variables  
    SET @SQL = N''  
    IF @ModelPrivilege_ID = 1 --if default privilege is Deny then do not return any rows  
        SET @RowLimitText = N'0'  
    ELSE  
        BEGIN  
            SET @RowLimitText = ISNULL(CAST(@RowLimit as NVARCHAR(11)), N'100 Percent')  
        END  
  
    --Figure out if Member security is used  
    SET @UseMemberSecurity = mdm.udfUseMemberSecurity (@User_ID, @Entity_ID, @Version_ID, @MemberType_ID);  
  
    --If UseMemberSecurity is false for Consolidated Members, check again for Leaf Members to handle the case  
    --where member security was set for a Derived Hierarchy whose leaf members fall within this Explicit Hierarchy.  
    IF @UseMemberSecurity = 0 AND @MemberType_ID = @MemberType_Consolidated  
        AND mdm.udfUseMemberSecurity(@User_ID, @Entity_ID, @Version_ID, @MemberType_Leaf) = 1  
    BEGIN  
        SET @UseMemberSecurity = 2;  
    END  
  
    --PRINT '@User_ID: ' + convert(nvarchar(100),@User_ID);  
    --PRINT '@Version_ID: ' + convert(nvarchar(100),@Version_ID);  
    --PRINT '@Hierarchy_ID: ' + convert(nvarchar(100),@Hierarchy_ID);  
    --PRINT '@HierarchyType_ID: ' + convert(nvarchar(100),@HierarchyType_ID);  
    --PRINT '@Entity_ID: ' + convert(nvarchar(100),@Entity_ID);  
    --PRINT '@Item_ID: ' + convert(nvarchar(100),@Item_ID);  
    --PRINT '@ItemType_ID: ' + convert(nvarchar(100),@ItemType_ID);  
  
    --PRINT '@UseMemberSecurity: ' + convert(nvarchar(100),@UseMemberSecurity);  
    --Check to see if Root is secured  
    IF EXISTS(  
        SELECT * FROM mdm.viw_SYSTEM_SECURITY_USER_MEMBER  
        WHERE  
            IsMapped=1 AND  
            User_ID = @User_ID AND  
            Hierarchy_ID = @Hierarchy_ID AND  
            HierarchyType_ID = @HierarchyType_ID AND  
            Member_ID=0  
        ) AND @UseMemberSecurity=1  
    SET @RootSecured=1  
    ----------------------------------------------------------------------------------------  
  
  
    SELECT @EntityMUID=MUID,@strEntityName=[Name] FROM mdm.tblEntity WHERE ID=@Entity_ID  
    IF @HierarchyType_ID = @ExplicitHierarchyType_ID SELECT @HierarchyMUID=MUID FROM mdm.tblHierarchy WHERE ID=@Hierarchy_ID  
  
  
    --BEGIN PROCESSING  
    --Criterion 1: process explicit hierarchy  
    IF @HierarchyType_ID = @ExplicitHierarchyType_ID  
        BEGIN  
            SELECT  
                @EntityTable = EntityTable,  
                @HierarchyParentTable = HierarchyParentTable,  
                @HierarchyTable = HierarchyTable,  
                @EntitySecurityTable = CAST(EntityTable + '_MS' AS SYSNAME),  
                @HierarchyParentSecurityTable = CASE WHEN HierarchyParentTable IS NOT NULL THEN CAST(HierarchyParentTable + '_MS' AS SYSNAME) ELSE NULL END  
            FROM  
                mdm.tblEntity  
            WHERE  
                ID = @Item_ID;  
  
  
            SET @MemberSecurityCTE = CONCAT(N'  
                            --Member security cte  
                            DECLARE @Ancestors TABLE(MemberID INT, MemberTypeID INT, AncestorID INT,AncestorMemberTypeID INT,LevelNumber SMALLINT);  
                            DECLARE @RAM TABLE(VersionID INT,[HierarchyID] INT,MemberID INT, MemberTypeID INT);  
                            DECLARE @TempVersionID INT;  
                            DECLARE @TempHierarchyID INT;  
                            DECLARE @TempMemberID INT;  
                            DECLARE @TempMemberTypeID INT;  
                            INSERT INTO @RAM  SELECT Version_ID,Hierarchy_ID, Member_ID,MemberType_ID FROM mdm.tblSecurityRoleAccessMember WHERE Hierarchy_ID=', @Hierarchy_ID, N' AND HierarchyType_ID = ', @HierarchyType_ID, N' ;  
                            WHILE (SELECT COUNT(*) FROM @RAM) <> 0  
                            BEGIN  
                                SELECT TOP 1  
                                    @TempVersionID=VersionID, @TempHierarchyID=HierarchyID, @TempMemberID=MemberID, @TempMemberTypeID=MemberTypeID  
                                FROM @RAM ORDER BY VersionID;  
  
                                INSERT INTO @Ancestors  
                                EXEC mdm.udpHierarchyAncestorsGet @User_ID, @TempVersionID, @TempHierarchyID, @TempMemberID, @TempMemberTypeID, 1;  
  
                                DELETE FROM @RAM WHERE VersionID=@TempVersionID AND HierarchyID=@TempHierarchyID AND MemberID=@TempMemberID AND MemberTypeID=@TempMemberTypeID;  
                            END;  
                            WITH membersresolved as  
                            (  
                                SELECT  
                                    ID AS Member_ID,  
                                    ', @MemberType_Leaf, N' AS MemberType_ID,  
                                    AccessPermission  
                                FROM  
                                    mdm.', QUOTENAME(@EntitySecurityTable), N' X  
                                WHERE X.User_ID = @User_ID  
                                    AND X.Version_ID = @Version_ID',  
                                    CASE  
                                        WHEN @HierarchyParentSecurityTable IS NOT NULL THEN CONCAT(N'  
                                UNION ALL  
                                SELECT  
                                    ID AS Member_ID,  
                                    ', @MemberType_Consolidated, N' AS MemberType_ID,  
                                    AccessPermission  
                                FROM  
                                    mdm.', QUOTENAME(@HierarchyParentSecurityTable), N' X  
                                WHERE X.User_ID = @User_ID  
                                    AND X.Version_ID = @Version_ID')  
                                        ELSE N''  
                                    END, N'  
                            ),  
                            TopMostSecuredNodes as  
                            (  
                            SELECT DISTINCT MemberID,MemberTypeID FROM @Ancestors  
                            WHERE MemberID NOT IN (select MemberID from @Ancestors WHERE AncestorID IN(SELECT MemberID FROM @Ancestors) )  
                            )');  
  
            SELECT @HierarchyView = mdm.udfViewNameGetByID(@Item_ID, 4, 0, 0)  
  
            IF @Parent_ID = -1 --Unused (non-mandatory hierarchy)  
                BEGIN  
                --Are the table variables we want to use not null?  
                    IF @HierarchyTable IS NULL  
                    BEGIN  
                        RAISERROR('MDSERR100104|A required schema object for this call is missing. Verify that the Hierarchy table exists for this entity.', 16, 1);  
                        RETURN;  
                    END  
                    IF @EntityTable IS NULL  
                    BEGIN  
                        RAISERROR('MDSERR100103|A required schema object for this call is missing. Verify that the Entity table exists for this entity.', 16, 1);  
                        RETURN;  
                    END  
  
                    --For Non-Mandatory hierarchies, we always use the member security as we  
                    --have to get the permissions of the nodes of where they reside now  
                    SET @SQL = CASE WHEN @UseMemberSecurity <> 0 THEN @MemberSecurityCTE ELSE + ' ' END + N'  
                        SELECT TOP ' + @RowLimitText + N'  
                            tEN.Code                    AS Code,  
                            ISNULL(tEN.Name, '''')        AS Name,  
                            ''MDMUNUSED''                AS ParentCode,  
                            ''''                        AS ParentName,  
                            @EntityMUID                    AS ChildEntity_MUID ,  
                            @EntityName                    AS ChildEntity_Name ,  
                            @EntityID                    AS ParentEntity_ID,  
                            @EntityMUID                    AS ParentEntity_MUID,  
                            @EntityName                    AS ParentEntity_Name,  
                            @HierarchyMUID                AS RelationshipId,  
                            2                            AS RelationshipTypeId,  
                            -1                            AS Parent_ID,  
                            0                            AS Hierarchy_ID,  
                            tEN.ID                        AS Child_ID,  
                            CONVERT(INT,1)                AS ChildType_ID,  
                            CONVERT(INT,2)                AS ParentType_ID,  
                            -1                            AS SortOrder,  
                            0                            AS NextHierarchyType_ID,  
                            @MemberPrivilegeID AS Privilege_ID,  
                            CONVERT(INTEGER,ISNULL(SR.AccessPermission, @MemberAccessPermission)) AS AccessPermission,  
                            @ModelPrivilegeID               AS ModelPrivilege_ID,  
                            @ModelAccessPermission          AS ModelAccessPermission  
                        FROM  
                            mdm.' + QUOTENAME(@EntityTable) + N' AS tEN '  
                        IF @UseMemberSecurity <> 0 SET @SQL = @SQL + N'  
                                INNER JOIN membersresolved AS SR  
                                        ON SR.Member_ID = tEN.ID  
                                        AND SR.MemberType_ID = 1 '  
                        IF @UseMemberSecurity = 0 SET @SQL = @SQL + N'  
                                LEFT JOIN membersresolved AS SR  
                                        ON SR.Member_ID = tEN.ID  
                                        AND SR.MemberType_ID = 1 '  
                         SET @SQL = @SQL + N'  
                            WHERE  
                                tEN.Status_ID = 1 AND '  
                            IF @IncludeDeny <> 1 SET @SQL = @SQL + N'SR.AccessPermission IS NOT NULL AND '  
                            SET @SQL = @SQL + N'  
                                tEN.Version_ID = @Version_ID AND  
                                NOT EXISTS  
                                (  
                                    SELECT  
                                        tHR.Child_EN_ID  
                                    FROM  
                                        mdm.' + QUOTENAME(@HierarchyTable) + N' AS tHR  
                                    WHERE  
                                        tHR.Child_EN_ID = tEN.ID AND  
                                        tHR.Version_ID = @Version_ID AND  
                                        tHR.ChildType_ID = 1 AND  
                                        tHR.Status_ID = 1 AND  
                                        tHR.Hierarchy_ID = @HierarchyID  
                                )  
                            ORDER BY  
                                tEN.Code  
                        '  
                        IF @ReturnXML=1  
                            SET @SQL = @SQL + N'  
                            FOR XML PATH(''MemberData''),ELEMENTS,ROOT(''ArrayOfMemberData'');'  
  
                        SET @ParamList = N'@MemberPrivilegeID       INT  
                                          ,@MemberAccessPermission  INT  
                                          ,@ModelPrivilegeID        INT  
                                          ,@ModelAccessPermission   INT  
                                          ,@User_ID                 INT  
                                          ,@EntityID                INT  
                                          ,@Version_ID              INT  
                                          ,@HierarchyID             INT  
                                          ,@EntityMUID              UNIQUEIDENTIFIER  
                                          ,@EntityName              NVARCHAR(MAX)  
                                          ,@HierarchyMUID           UNIQUEIDENTIFIER'  
  
                        EXEC sp_executesql @SQL, @ParamList  
                                ,@MemberPrivilege_ID  
                                ,@MemberAccessPermission  
                                ,@ModelPrivilege_ID  
                                ,@ModelAccessPermission  
                                ,@User_ID  
                                ,@Entity_ID  
                                ,@Version_ID  
                                ,@Hierarchy_ID  
                                ,@EntityMUID  
                                ,@strEntityName  
                                ,@HierarchyMUID  
  
            END ELSE BEGIN --Used (mandatory hierarchy)  
  
                IF OBJECT_ID(N'mdm.'+@HierarchyView,N'V') IS NULL BEGIN  
                        RAISERROR('MDSERR100102|A view is required.', 16, 1);  
                        RETURN;  
                END; --if  
  
                SET @SQL = CASE WHEN @UseMemberSecurity <> 0 THEN @MemberSecurityCTE ELSE + ' ' END + N'  
                    SELECT TOP ' + @RowLimitText + N'  
                        tHR.Child_Code                    AS Code,  
                        tHR.Child_Name                    AS Name,  
                        tHR.Parent_Code                    AS ParentCode,  
                        tHR.Parent_Name                    AS ParentName,  
                        @EntityID                        AS Item_ID,  
                        0                                AS ItemType_ID,  
                        @EntityID                        AS ParentItem_ID,  
                        @EntityID                        AS ChildEntity_ID,  
                        @EntityMUID                        AS ChildEntity_MUID ,  
                        @EntityName                        AS ChildEntity_Name ,  
                        @EntityID                        AS ParentEntity_ID,  
                        @EntityMUID                        AS ParentEntity_MUID,  
                        @EntityName                        AS ParentEntity_Name,  
                        @HierarchyMUID                    AS RelationshipId,  
                        2                                AS RelationshipTypeId,  
                        0                                AS ParentItemType_ID,  
                        tHR.Parent_ID,  
                        tHR.Hierarchy_ID,  
                        tHR.Child_ID                    AS Child_ID,  
                        CONVERT(INT,tHR.ChildType_ID)    AS ChildType_ID,  
                        2                                AS ParentType_ID,  
                        tHR.Child_SortOrder                AS SortOrder,  
                        @HierarchyID                    AS NextHierarchy_ID,  
                        0                                AS NextHierarchyType_ID,  
                        CASE WHEN tHR.ChildType_ID=1 THEN @ModelLeafPrivilegeID ELSE @ModelPrivilegeID END AS ModelPrivilege_ID,  
                        CASE WHEN tHR.ChildType_ID=1 THEN @ModelLeafAccessPermission ELSE @ModelAccessPermission END AS ModelAccessPermission,';  
                IF @UseMemberSecurity <> 0 SET @SQL = @SQL + N'  
                        @MemberPrivilegeID AS Privilege_ID,  
                        CONVERT(INTEGER,ISNULL(SR.AccessPermission, @MemberAccessPermission)) AS AccessPermission'  
                ELSE SET @SQL += N'  
                        CASE WHEN tHR.ChildType_ID=1 AND @ModelLeafPrivilegeID =1 THEN @ModelLeafPrivilegeID ELSE @ModelPrivilegeID END AS Privilege_ID,  
                        CASE WHEN tHR.ChildType_ID=1 AND @ModelLeafPrivilegeID =1 THEN @ModelLeafAccessPermission ELSE @ModelAccessPermission END AS AccessPermission'  
                SET @SQL = @SQL + N'  
                    FROM '  
                IF @RootSecured=0 AND ISNULL(@Parent_ID, 0) = 0 AND @UseMemberSecurity = 1 SET @SQL = @SQL + N'  
                        TopMostSecuredNodes AS SU  
                    INNER JOIN mdm.' + QUOTENAME(@HierarchyView) + N' AS tHR  
                        ON SU.MemberID = tHR.Child_HP_ID  
                        AND SU.MemberTypeID = tHR.ChildType_ID  
                        AND tHR.Hierarchy_ID = @HierarchyID  
                        '  
                IF (ISNULL(@Parent_ID, 0) = 0 AND @UseMemberSecurity <> 1) OR @RootSecured=1 OR ISNULL(@Parent_ID, 0) <> 0 SET @SQL = @SQL + N'  
                        mdm.' + QUOTENAME(@HierarchyView) + N' tHR '  
                IF @UseMemberSecurity = 1 SET @SQL = @SQL + N'  
                    LEFT JOIN membersresolved AS SR  
                        ON SR.Member_ID = tHR.Child_ID  
                        AND SR.MemberType_ID = tHR.ChildType_ID'  
                IF @UseMemberSecurity = 2 SET @SQL = @SQL + N'  
                    LEFT JOIN membersresolved AS SR  
                        ON SR.Member_ID = tHR.Child_ID  
                        AND SR.MemberType_ID = tHR.ChildType_ID  
                        AND tHR.ChildType_ID = 1'  
                SET @SQL = @SQL + N'  
                    WHERE  
                        tHR.Version_ID = @Version_ID  
                        AND tHR.Hierarchy_ID = @HierarchyID'  
                  IF ISNULL(@Parent_ID, 0) > 0 OR @RootSecured=1 OR (ISNULL(@Parent_ID, 0) = 0 AND @UseMemberSecurity <> 1) SET @SQL = @SQL + N'  
                        AND ((tHR.Parent_ID IS NULL AND NULLIF(@ParentID, 0) IS NULL) OR (tHR.Parent_ID = @ParentID))'  
                IF @IncludeDeny <> 1 AND @UseMemberSecurity <> 0 SET @SQL = @SQL + N'  
                        AND SR.AccessPermission IS NOT NULL'  
                IF @UseMemberSecurity = 2 SET @SQL = @SQL + N'  
                        AND ISNULL(SR.AccessPermission, 0) <> CASE  
                                WHEN tHR.ChildType_ID = 2 THEN -1  
                                WHEN tHR.ChildType_ID = 1 THEN 0  
                            END'  
                -- Add @EntityMemberTypeID  
                IF @EntityMemberTypeID > 0 SET @SQL += N'  
                        AND tHR.ChildType_ID = @EntityMemberTypeID'  
  
                SET @SQL = @SQL + N'  
                    ORDER BY SortOrder'  
  
                IF @ReturnXML=1  
                    SET @SQL = @SQL + N'  
                    FOR XML PATH(''MemberData''),ELEMENTS,ROOT(''ArrayOfMemberData'');'  
  
                SET @ParamList = N'  
                     @EntityID                  INT  
                    ,@EntityMemberTypeID        INT  
                    ,@EntityMUID                UNIQUEIDENTIFIER  
                    ,@EntityName                NVARCHAR(MAX)  
                    ,@HierarchyID               INT  
                    ,@ModelLeafPrivilegeID      INT  
                    ,@ModelLeafAccessPermission TINYINT  
                    ,@MemberPrivilegeID         INT  
                    ,@MemberAccessPermission    TINYINT  
                    ,@ModelPrivilegeID          INT  
                    ,@ModelAccessPermission     TINYINT  
                    ,@User_ID                   INT  
                    ,@Version_ID                INT  
                    ,@ParentID                  INT  
                    ,@HierarchyMUID             UNIQUEIDENTIFIER';  
  
                EXEC sp_executesql  
                     @SQL  
                    ,@ParamList  
                    ,@Entity_ID  
                    ,@EntityMemberTypeID  
                    ,@EntityMUID  
                    ,@strEntityName  
                    ,@Hierarchy_ID  
                    ,@ModelLeafPrivilege_ID  
                    ,@ModelLeafAccessPermission  
                    ,@MemberPrivilege_ID  
                    ,@MemberAccessPermission  
                    ,@ModelPrivilege_ID  
                    ,@ModelAccessPermission  
                    ,@User_ID  
                    ,@Version_ID  
                    ,@Parent_ID  
                    ,@HierarchyMUID;  
            END; --if  
        END; --if  
  
    --Criterion 2: process Derived Hierarchy  
    ELSE IF @HierarchyType_ID = @DerivedHierarchyType_ID  
        BEGIN  
            SET @ViewName = CONCAT(N'viw_SYSTEM_', @Model_ID, N'_', @Hierarchy_ID, N'_PARENTCHILD_DERIVED')  
            IF OBJECT_ID(N'mdm.'+@ViewName,N'V') IS NULL  
                BEGIN  
                    RAISERROR('MDSERR100102|A view is required.', 16, 1);  
                    RETURN;  
                END  
            SELECT  
                @EntitySecurityTable = CAST(EntityTable + '_MS' AS SYSNAME),  
                @HierarchyParentSecurityTable = CASE WHEN HierarchyParentTable IS NOT NULL THEN CAST(HierarchyParentTable + '_MS' AS SYSNAME) ELSE NULL END  
            FROM mdm.tblEntity WHERE ID = @Entity_ID;  
  
            SET @MemberSecurityCTE = CONCAT(N'  
                            --Member security cte  
                            WITH membersresolved as  
                            (  
                                SELECT  
                                    ID AS Member_ID,  
                                    ', @MemberType_Leaf, N' AS MemberType_ID,  
                                    AccessPermission  
                                FROM  
                                    mdm.', QUOTENAME(@EntitySecurityTable), N' X  
                                WHERE X.User_ID = @User_ID  
                                    AND X.Version_ID = @Version_ID',  
                                    CASE  
                                        WHEN @HierarchyParentSecurityTable IS NOT NULL THEN CONCAT(N'  
                                UNION ALL  
                                SELECT  
                                    ID AS Member_ID,  
                                    ', @MemberType_Consolidated, N' AS MemberType_ID,  
                                    AccessPermission  
                                FROM  
                                    mdm.', QUOTENAME(@HierarchyParentSecurityTable), N' X  
                                WHERE X.User_ID = @User_ID  
                                    AND X.Version_ID = @Version_ID')  
                                        ELSE N''  
                                    END, N'  
                            ),  
                            TopMostSecuredNodes as  
                            (  
                            SELECT Version_ID, Hierarchy_ID, Entity_ID, Member_ID, MemberType_ID, Privilege_ID, AccessPermission  
                            FROM mdm.tblSecurityRoleAccessMember X  
                            INNER JOIN [mdm].[viw_SYSTEM_SECURITY_USER_ROLE] U ON X.Role_ID = U.Role_ID  
                                    AND U.User_ID = @User_ID  
                            WHERE Hierarchy_ID= ', @Hierarchy_ID, N' AND HierarchyType_ID = ', @HierarchyType_ID, N'  
                            )');  
            SET @SQL =  CASE WHEN @UseMemberSecurity <> 0 THEN @MemberSecurityCTE ELSE + ' ' END + N'  
                SELECT TOP ' + @RowLimitText + N'  
                    tHR.Child_ID                AS Child_ID,  
                    CONVERT(INT,ChildType_ID)    AS ChildType_ID,  
                    tHR.Entity_ID,  
                    NextEntity_ID,  
                    tHR.Entity_ID as ChildEntity_ID,  
                    Entity_MUID as ChildEntity_MUID,  
                    NextEntity_ID as ParentEntity_ID,  
                    NextEntity_MUID as ParentEntity_MUID,  
                    tHR.Item_ID,  
                    tHR.Item_MUID as RelationshipId,  
                    tHR.ItemType_ID as RelationshipTypeId,  
                    tHR.ItemType_ID,  
                    tHR.NextItem_ID,  
                    tHR.NextItemType_ID,  
                    tHR.ParentItem_ID,  
                    tHR.ParentItemType_ID,  
                    tHR.DomainAttribute_ID,  
                    CASE  
                        WHEN tHR.ItemType_ID = 3 THEN tHR.NextItem_ID  
                        WHEN tHR.ItemType_ID = 2 AND tHR.NextItemType_ID = 2 THEN tHR.Item_ID  
                        ELSE ''''  
                    END Hierarchy_ID,  
                    tHR.ChildCode Code,  
                    tHR.ChildName Name,  
                    tHR.ParentCode ParentCode,  
                    tHR.ParentName ParentName,  
                    tHR.ParentType_ID,  
                    ParentVisible,  
                    @HierarchyID  NextHierarchy_ID,  
                    1 NextHierarchyType_ID,  
                    tHR.Level,'  
                    SET @SQL = @SQL + N' @ModelPrivilegeID  AS ModelPrivilege_ID, @ModelAccessPermission AS ModelAccessPermission, '  
                    IF @UseMemberSecurity <> 0 BEGIN  
                        IF  @RootSecured = 0 AND ISNULL(@Parent_ID, 0) = 0 BEGIN  
                            SET @SQL = @SQL + N'CONVERT(INTEGER,ISNULL(SU.Privilege_ID, @MemberPrivilegeID )) AS Privilege_ID, CONVERT(INTEGER,ISNULL(SU.AccessPermission, @MemberAccessPermission )) AS AccessPermission';  
                        END ELSE BEGIN  
                            SET @SQL = @SQL + N'CONVERT(INTEGER, @MemberPrivilegeID) AS Privilege_ID, CONVERT(INTEGER,ISNULL(SR.AccessPermission, @MemberAccessPermission )) AS AccessPermission';  
                        END  
                    END ELSE BEGIN  
                        SET @SQL = @SQL + ' @ModelPrivilegeID AS Privilege_ID,  @ModelAccessPermission AS AccessPermission';  
                    END  
                    SET @SQL = @SQL + N' FROM '  
                    IF @RootSecured=0 AND ISNULL(@Parent_ID, 0) = 0 AND @UseMemberSecurity <> 0  
                        SET @SQL += N' TopMostSecuredNodes AS SU  
                        INNER JOIN mdm.' + QUOTENAME(@ViewName) + N' AS tHR  
                            ON SU.Entity_ID = tHR.Entity_ID  
                            AND SU.MemberType_ID = tHR.ChildType_ID  
                            AND SU.Member_ID = tHR.Child_ID  
                            --AND tHR.NextItem_ID = @ParentItemID  
                            --AND tHR.NextItemType_ID = @ParentItemTypeID  
                            AND SU.Hierarchy_ID = @HierarchyID  
                            AND SU.Privilege_ID <> 1 -- deny access';  
                    IF (ISNULL(@Parent_ID, 0) = 0 AND @UseMemberSecurity = 0) OR ISNULL(@Parent_ID, 0) <> 0 OR @RootSecured=1  
                        SET @SQL = @SQL + N' mdm.' + QUOTENAME(@ViewName) + N' AS tHR '  
                    IF ISNULL(@Parent_ID, 0) = 0 AND @UseMemberSecurity = 1 AND @RootSecured<>1 SET @SQL = @SQL + N'  
                    LEFT JOIN membersresolved AS SR  
                            ON SR.Member_ID = tHR.Child_ID  
                            AND SR.MemberType_ID = tHR.ChildType_ID'  
                    IF (ISNULL(@Parent_ID, 0) <> 0 AND @UseMemberSecurity = 1) OR (@RootSecured=1 AND @UseMemberSecurity = 1) SET @SQL = @SQL + N'  
                    LEFT JOIN membersresolved AS SR  
                            ON SR.Member_ID = tHR.Child_ID  
                            AND SR.MemberType_ID = tHR.ChildType_ID '  
                    IF @UseMemberSecurity = 2 SET @SQL = @SQL + N'  
                    LEFT JOIN membersresolved AS SR  
                            ON SR.Member_ID = tHR.Child_ID  
                            AND SR.MemberType_ID = tHR.ChildType_ID'  
  
                DECLARE @PartialSearchTerm NVARCHAR(MAX) = N'';  
  
                IF ISNULL(@Parent_ID, 0) > 0 OR (ISNULL(@Parent_ID, 0) = 0 AND @UseMemberSecurity = 0) OR @RootSecured=1 SET @PartialSearchTerm = @PartialSearchTerm + CASE @PartialSearchTerm WHEN N'' THEN N' WHERE ' ELSE N' AND ' END + N'tHR.Item_ID = @ItemID AND  
                    tHR.ItemType_ID = @ItemTypeID  AND  
                    tHR.Parent_ID = @ParentID'  
                IF ISNULL(@Parent_ID, 0) > 0 AND @ParentItem_ID=@Item_ID AND @ItemType_ID=@ParentItemType_ID AND @ItemType_ID<>2 SET @PartialSearchTerm = @PartialSearchTerm + CASE @PartialSearchTerm WHEN N'' THEN N' WHERE ' ELSE N' AND ' END + N'  
                    tHR.ParentItem_ID = @ParentItemID  AND  
                    tHR.ParentItemType_ID = @ParentItemTypeID'  
                SET @PartialSearchTerm = @PartialSearchTerm + CASE @PartialSearchTerm WHEN N'' THEN N' WHERE ' ELSE N' AND ' END + N'tHR.Version_ID = @Version_ID '  
                IF @UseMemberSecurity = 2 SET @PartialSearchTerm = @PartialSearchTerm + CASE @PartialSearchTerm WHEN N'' THEN N' WHERE ' ELSE N' AND ' END + N'ISNULL(SR.AccessPermission, 0) <> CASE  
                                                                                                        WHEN tHR.ChildType_ID = 2 THEN -1  
                                                                                                        WHEN tHR.ChildType_ID = 1 THEN 0  
                                                                                                    END'  
  
                IF @AnchorNullRecursions = 1 SET @PartialSearchTerm = @PartialSearchTerm + CASE @PartialSearchTerm WHEN N'' THEN N' WHERE ' ELSE N' AND ' END +  
                    N'(tHR.Child_ID NOT IN (SELECT tHR2.Child_ID  
                         FROM mdm.' + QUOTENAME(@ViewName) + N' AS tHR2  
                         WHERE tHR2.Version_ID = @Version_ID AND tHR2.Parent_ID <> 0 AND tHR2.[Entity_ID] = tHR.[Entity_ID]))'  
  
                IF @IncludeDeny <> 1 AND @UseMemberSecurity <> 0 SET @PartialSearchTerm = @PartialSearchTerm + CASE @PartialSearchTerm WHEN N'' THEN N' WHERE ' ELSE N' AND ' END + N'SR.AccessPermission IS NOT NULL '  
                IF ISNULL(@Parent_ID, 0) > 0 AND @ParentItem_ID=@Item_ID AND @ItemType_ID=@ParentItemType_ID AND @ItemType_ID<>2 SET @PartialSearchTerm = @PartialSearchTerm + CASE @PartialSearchTerm WHEN N'' THEN N' WHERE ' ELSE N' AND ' END + N'tHR.Level >=  
                        (  
                        SELECT  
                            MAX(Level) FROM mdm.' + QUOTENAME(@ViewName) + N'  
                        WHERE  
                            Item_ID = @ItemID  AND  
                            ItemType_ID = @ItemTypeID  AND  
                            Parent_ID = @ParentID  AND  
                            ParentItem_ID = @ParentItemID  AND  
                            ParentItemType_ID = @ParentItemTypeID AND  
                            Version_ID = @Version_ID  
                        )'  
                SET @SQL = @SQL + @PartialSearchTerm + N' ORDER BY SortItem '  
  
                SET @ParamList = N'@HierarchyID             INT  
                                ,@ModelPrivilegeID          INT  
                                ,@ModelAccessPermission     TINYINT  
                                ,@MemberPrivilegeID         INT  
                                ,@MemberAccessPermission    TINYINT  
                                ,@User_ID                    INT  
                                ,@Version_ID                INT  
                                ,@EntityID                  INT  
                                ,@ItemID                    INT  
                                ,@ItemTypeID                INT  
                                ,@ParentID                  INT  
                                ,@ParentItemID              INT  
                                ,@ParentItemTypeID          INT'  
  
                IF @ReturnXML = 1  
                    SET @SQL = @SQL + N' FOR XML PATH(''MemberData''),ELEMENTS,ROOT(''ArrayOfMemberData'');';  
  
                --PRINT(@SQL);  
                EXEC sp_executesql  
                     @SQL  
                    ,@ParamList  
                    ,@Hierarchy_ID  
                    ,@ModelPrivilege_ID  
                    ,@ModelAccessPermission  
                    ,@MemberPrivilege_ID  
                    ,@MemberAccessPermission  
                    ,@User_ID  
                    ,@Version_ID  
                    ,@Entity_ID  
                    ,@Item_ID  
                    ,@ItemType_ID  
                    ,@Parent_ID  
                    ,@ParentItem_ID  
                    ,@ParentItemType_ID;  
  
  
        END  
  
    --Criterion 3: process Collection or Collection members  
    ELSE IF @HierarchyType_ID = @CollectionType_ID  
        BEGIN  
            SELECT  
                @EntityTable = EntityTable,  
                @HierarchyParentTable = HierarchyParentTable,  
                @CollectionMemberTable = CollectionMemberTable,  
                @CollectionTable = CollectionTable  
            FROM [mdm].tblEntity WHERE ID = @Item_ID  
  
            IF @Hierarchy_ID = 0 --List all Collections  
                BEGIN  
                    --Are the table variables we want to use not null?  
                    IF @CollectionTable IS NULL  
                    BEGIN  
                        -- No collections have been defined yet, so return.  
                        RETURN;  
                    END  
  
                    SET @SQL =  
                    N'  
                    SELECT  TOP ' + @RowLimitText + N'  
                        tCN.ID Member_ID,  
                        3 MemberType_ID,  
                        tCN.ID Hierarchy_ID,  
                        tCN.ID SortOrder,  
                        tCN.Code Code,  
                        tCN.Name Name,  
                        CONVERT(DECIMAL(18, 2), 0) Weight,  
                        tCN.ID AS Child_ID,  
                        CONVERT(INT,3) ChildType_ID,  
                        tCN.ID NextHierarchy_ID,  
                        2 NextHierarchyType_ID,  
                        @ModelPrivilegeID  ModelPrivilege_ID,  
                        @ModelAccessPermission  ModelAccessPermission,  
                        @ModelPrivilegeID  Privilege_ID  
                        @ModelAccessPermission  AccessPermission  
                    FROM  
                        mdm.' + QUOTENAME(@CollectionTable) + N' tCN  
                    WHERE  
                        tCN.Version_ID = @Version_ID  AND  
                        tCN.Status_ID = 1  
                    ORDER BY tCN.ID  
                    '  
                    SET @ParamList = N'@ModelPrivilegeID        INT  
                                      ,@ModelAccessPermission   TINYINT  
                                      ,@Version_ID              INT'  
                    --PRINT(@SQL);  
                    IF @ReturnXML=1  
                    BEGIN  
                        SET @SQL = @SQL + N' FOR XML PATH(''MemberData''),ELEMENTS,ROOT(''ArrayOfMemberData'');'  
                    END  
                    EXEC sp_executesql @SQL, @ParamList  
                                ,@ModelPrivilege_ID  
                                ,@ModelAccessPermission  
                                ,@Version_ID  
  
  
                END  
            ELSE  --List members in a Collection  
            BEGIN  
                IF @CollectionTable IS NULL  
                BEGIN  
                    -- No collections have been created yet, so return.  
                    RETURN;  
                END  
  
                -- Verify that the leaf member table is defined.  
                IF @EntityTable IS NULL  
                BEGIN  
                    RAISERROR('MDSERR100103|A required schema object for this call is missing. Verify that the Entity table exists for this entity.', 16, 1);  
                    RETURN;  
                END  
  
                SET @SQL =  
                N'  
                SELECT  TOP ' + @RowLimitText + N'  
  
                    @EntityID ChildEntity_ID,  
                    @EntityMUID ChildEntity_MUID,  
                    @EntityID ParentEntity_ID,  
                    @EntityMUID ParentEntity_MUID,  
                    N''ROOT'' ParentCode,  
                    N'''' ParentName,  
                    2 as ParentType_ID,  
                    CASE tCM.ChildType_ID  
                        WHEN 1 THEN tEN.ID' +  
                        CASE WHEN @HierarchyParentTable IS NOT NULL THEN N'  
                        WHEN 2 THEN tHP.ID' ELSE N'' END + N'  
                        WHEN 3 THEN tCN.ID  
                        END Member_ID,  
                    tCM.ChildType_ID MemberType_ID,  
                    CASE tCM.ChildType_ID  
                        WHEN 1 THEN 0' +  
                        CASE WHEN @HierarchyParentTable IS NOT NULL THEN N'  
                        WHEN 2 THEN tHP.Hierarchy_ID' ELSE N'' END + N'  
                        WHEN 3 THEN tCN.ID  
                        END Hierarchy_ID,  
                    tCM.SortOrder,  
                    CASE tCM.ChildType_ID  
                        WHEN 1 THEN tEN.Code' +  
                        CASE WHEN @HierarchyParentTable IS NOT NULL THEN N'  
                        WHEN 2 THEN tHP.Code' ELSE N'' END + N'  
                        WHEN 3 THEN tCN.Code  
                        END Code,  
                    CASE tCM.ChildType_ID  
                        WHEN 1 THEN tEN.Name' +  
                        CASE WHEN @HierarchyParentTable IS NOT NULL THEN N'  
                        WHEN 2 THEN tHP.Name' ELSE N'' END + N'  
                        WHEN 3 THEN tCN.Name  
                        END Name,  
                    CONVERT(DECIMAL(18, 2), tCM.Weight) Weight,  
                    CASE tCM.ChildType_ID  
                        WHEN 1 THEN tCM.Child_EN_ID' +  
                        CASE WHEN @HierarchyParentTable IS NOT NULL THEN N'  
                        WHEN 2 THEN tCM.Child_HP_ID' ELSE N'' END + N'  
                        WHEN 3 THEN tCM.Child_CN_ID  
                        END AS Child_ID,  
                    CASE tCM.ChildType_ID  
                        WHEN 1 THEN tEN.MUID' +  
                        CASE WHEN @HierarchyParentTable IS NOT NULL THEN N'  
                        WHEN 2 THEN tHP.MUID' ELSE N'' END + N'  
                        WHEN 3 THEN tCN.MUID  
                        END Child_MUID,  
                    CONVERT(INT,tCM.ChildType_ID) ChildType_ID,  
                    CASE tCM.ChildType_ID  
                        WHEN 1 THEN 0' +  
                        CASE WHEN @HierarchyParentTable IS NOT NULL THEN N'  
                        WHEN 2 THEN tHP.Hierarchy_ID' ELSE N'' END + N'  
                        WHEN 3 THEN tCN.ID  
                    END NextHierarchy_ID,  
                    CASE  
                        WHEN tCM.ChildType_ID = 3 THEN 2  
                        ELSE 0  
                    END NextHierarchyType_ID,  
                    @ModelPrivilegeID  ModelPrivilege_ID,  
                    @ModelAccessPermission  ModelAccessPermission,  
                    CASE WHEN tCM.ChildType_ID=1 AND @ModelLeafPrivilegeID =1 THEN @ModelLeafPrivilegeID ELSE  
                    CASE WHEN tCM.ChildType_ID=2 AND @ModelConsolidatedPrivilegeID =1  THEN @ModelConsolidatedPrivilegeID ELSE @ModelPrivilegeID END END AS Privilege_ID,  
                    CASE WHEN tCM.ChildType_ID=1 AND @ModelLeafPrivilegeID =1 THEN @ModelLeafAccessPermission ELSE  
                    CASE WHEN tCM.ChildType_ID=2 AND @ModelConsolidatedPrivilegeID =1  THEN @ModelConsolidatedAccessPermission ELSE @ModelAccessPermission END END AS AccessPermission,  
                    @EntityMUID RelationshipId,  
                    4 RelationshipTypeId  
                FROM  
                    mdm.' + QUOTENAME(@CollectionMemberTable) + N' AS tCM';  
  
                --Direct assignment of expression > 4000 nchars truncates nvarchar(max) to nvarchar(4000). Workaround is to concatenate.  
                --Details here: http://connect.microsoft.com/SQLServer/feedback/details/283368/nvarchar-max-concatenation-yields-silent-truncation  
                SET @SQL += N'  
                            LEFT JOIN mdm.' + QUOTENAME(@EntityTable) + N' AS tEN  
                            ON tCM.Child_EN_ID = tEN.ID  
                            AND tCM.Version_ID = tEN.Version_ID  
                            AND tEN.Version_ID = @Version_ID  
                            AND tCM.Parent_CN_ID = @HierarchyID  
                            AND tCM.ChildType_ID = 1  
                            AND tEN.Status_ID = 1' +  
                        CASE WHEN @HierarchyParentTable IS NOT NULL THEN N'  
                        LEFT JOIN mdm.' + QUOTENAME(@HierarchyParentTable) + N' AS tHP  
                            ON tCM.Child_HP_ID = tHP.ID  
                            AND tCM.Version_ID = tHP.Version_ID  
                            AND tHP.Version_ID = @Version_ID  
                            AND tCM.Parent_CN_ID = @HierarchyID  
                            AND tCM.ChildType_ID = 2  
                            AND tHP.Status_ID = 1' ELSE N'' END + N'  
                        LEFT JOIN mdm.' + QUOTENAME(@CollectionTable) + N' AS tCN  
                            ON tCM.Child_CN_ID = tCN.ID  
                            AND tCM.Version_ID = tCN.Version_ID  
                            AND tCN.Version_ID = @Version_ID  
                            AND tCM.Parent_CN_ID = @HierarchyID  
                            AND tCM.ChildType_ID = 3  
                            AND tCN.Status_ID = 1  
                WHERE  
                    tCM.Version_ID = @Version_ID AND  
                    tCM.Status_ID = 1 AND  
                    tCM.Parent_CN_ID = @HierarchyID AND  
                    (tEN.ID IS NOT NULL' +  
                    CASE WHEN @HierarchyParentTable IS NOT NULL THEN N' OR tHP.ID IS NOT NULL' ELSE N'' END + N' OR tCN.ID IS NOT NULL)  
                ORDER BY tCM.SortOrder';  
  
  
                SET @ParamList = N'@EntityID                    INT  
                            ,@EntityMUID                        UNIQUEIDENTIFIER  
                            ,@ModelPrivilegeID                  INT  
                            ,@ModelAccessPermission             TINYINT  
                            ,@ModelLeafPrivilegeID              INT  
                            ,@ModelLeafAccessPermission         TINYINT  
                            ,@ModelConsolidatedPrivilegeID      INT  
                            ,@ModelConsolidatedAccessPermission TINYINT  
                            ,@Version_ID                        INT  
                            ,@HierarchyID                       INT'  
  
                IF @ReturnXML=1  
                    SET @SQL = @SQL + N' FOR XML PATH(''MemberData''),ELEMENTS,ROOT(''ArrayOfMemberData'');';  
  
                --PRINT(@SQL);  
                EXEC sp_executesql @SQL, @ParamList  
                            ,@Entity_ID  
                            ,@EntityMUID  
                            ,@ModelPrivilege_ID  
                            ,@ModelAccessPermission  
                            ,@ModelLeafPrivilege_ID  
                            ,@ModelLeafAccessPermission  
                            ,@ModelConsolidatedPrivilege_ID  
                            ,@ModelAccessPermission  
                            ,@Version_ID  
                            ,@Hierarchy_ID  
  
            END; --if (list members in a collection)  
        END; --if  
  
    SET NOCOUNT OFF;  
END; --proc
go

