/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    SELECT * FROM mdm.viw_SYSTEM_SCHEMA_ENTITY_MEMBERTYPE  
*/  
CREATE VIEW mdm.viw_SYSTEM_SCHEMA_ENTITY_MEMBERTYPE  
/*WITH SCHEMABINDING*/  
AS  
SELECT ID AS Entity_ID, 1 AS MemberType_ID FROM mdm.tblEntity  
UNION ALL  
SELECT ID AS Entity_ID, 2 AS MemberType_ID FROM mdm.tblEntity WHERE HierarchyTable IS NOT NULL  
UNION ALL  
SELECT ID AS Entity_ID, 3  AS MemberType_ID FROM mdm.tblEntity;
go

