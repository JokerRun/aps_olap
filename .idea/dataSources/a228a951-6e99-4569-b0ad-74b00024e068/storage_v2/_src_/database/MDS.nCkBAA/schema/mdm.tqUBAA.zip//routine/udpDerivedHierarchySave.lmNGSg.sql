/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
--Create derived hierarchy  
exec mdm.udpDerivedHierarchySave @User_ID = 1, @Model_ID = 5, @Name = 'DHTest', @EditMode = 0;  
  
--Update  
exec mdm.udpDerivedHierarchySave @User_ID = 1, @Model_ID = 5, @ID = 10, @Name = 'NewName', @EditMode = 1;  
select * from mdm.tblDerivedHierarchy  
*/  
CREATE PROCEDURE mdm.udpDerivedHierarchySave  
(  
    @User_ID                INT,  
    @Model_ID               INT, -- caller should validate  
    @Version_ID             INT = NULL, -- used for audit info. When NULL, the highest value for the model will be used  
    @MUID                   UNIQUEIDENTIFIER = NULL,  
    @Name                   NVARCHAR(50) = NULL,  
    @AnchorNullRecursions   BIT = 1,  
    @EditMode               TINYINT = 0, --0: Create, 1: Update, 4: Clone, defaults to Create  
    @Return_ID	            INT = NULL OUTPUT,  
    @Return_MUID            UNIQUEIDENTIFIER = NULL OUTPUT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON  
  
    DECLARE   
            @GuidEmpty  UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER),  
            @ExistingDerivedHierarchy_MUID  UNIQUEIDENTIFIER = NULL,  
            @ExistingDerivedHierarchy_ID    INT = NULL,  
            @ExistingDerivedHierarchy_Name  NVARCHAR(MAX),  
            @ExistingDerivedHierarchy_AnchorNullRecursions BIT,  
            @EditMode_Create                TINYINT = 0,  
            @EditMode_Update                TINYINT = 1,  
            @EditMode_Clone                 TINYINT = 4;  
      
    SELECT  @Model_ID = NULLIF(@Model_ID, 0),  
            @MUID = NULLIF(@MUID, @GuidEmpty),  
            @Name = NULLIF(LTRIM(RTRIM(@Name)), N'');  
  
    SELECT @Return_ID = NULL, @Return_MUID = NULL;  
  
    --Test for invalid EditMode  
    IF @EditMode IS NULL OR @EditMode NOT IN (@EditMode_Create, @EditMode_Update, @EditMode_Clone)  
    BEGIN  
        RAISERROR('MDSERR100010|The Parameters are not valid.', 16, 1);  
        RETURN;  
    END; --if  
  
      
    --If we are in the Update or Clone mode get the missing pieces of the identifier  
    IF @EditMode IN (@EditMode_Update, @EditMode_Clone)  
    BEGIN  
        --Only use the name if the MUID is not available. This is important because we don't want  
        --to look up by name if the name is what the user is trying to update.  
        IF @MUID IS NULL  
        BEGIN  
            SELECT TOP 1  
                @ExistingDerivedHierarchy_ID = ID,  
                @ExistingDerivedHierarchy_MUID = MUID,  
                @ExistingDerivedHierarchy_Name = Name,  
                @ExistingDerivedHierarchy_AnchorNullRecursions = AnchorNullRecursions  
            FROM mdm.tblDerivedHierarchy   
            WHERE   
                Name = @Name AND  
                Model_ID = @Model_ID;  
        END  
        --Use the derived hierarchy ID and MUID to look up the full identifier  
        ELSE  
        BEGIN  
            SELECT  
                @ExistingDerivedHierarchy_ID =  ID,   
                @ExistingDerivedHierarchy_MUID = MUID,  
                @ExistingDerivedHierarchy_Name = Name,  
                @ExistingDerivedHierarchy_AnchorNullRecursions = AnchorNullRecursions  
            FROM mdm.tblDerivedHierarchy   
            WHERE  
                MUID = @MUID AND  
                Model_ID = @Model_ID;  
        END  
  
        --If we are in the Clone mode we need to figure out whether we are creating or updating a derived hierarchy  
        IF @EditMode = @EditMode_Clone  
        BEGIN  
            --If there is no existing derived hierarchy then set the edit mode to Create  
            IF @ExistingDerivedHierarchy_MUID IS NULL AND @ExistingDerivedHierarchy_ID IS NULL  
            BEGIN  
                SET @EditMode = @EditMode_Create;  
            END  
            --If there is an existing derived hierarchy then set the edit mode to Update  
            ELSE  
            BEGIN  
                SET @EditMode = @EditMode_Update;  
                SET @MUID = @ExistingDerivedHierarchy_MUID;  
            END  
        END  
        --If we are in Update mode and could not find a matching existing derived hierarchy we need to raise an error and quit now  
        ELSE IF @EditMode = @EditMode_Update  
        BEGIN  
  
            IF (@AnchorNullRecursions = 0)  
            BEGIN  
                If (EXISTS (SELECT 1 FROM mdm.tblSecurityRoleAccessMember WHERE DerivedHierarchy_ID = @ExistingDerivedHierarchy_ID))  
                BEGIN    
                    RAISERROR('MDSERR200112|Cannot un-anchor null recursions on the derived hierarchy. The hierarchy has member security permissions assigned.', 16, 1);  
                    RETURN;  
                END   
            END  
  
            IF @ExistingDerivedHierarchy_ID IS NULL OR @ExistingDerivedHierarchy_MUID IS NULL  
            BEGIN  
                --On error, return NULL results  
                SELECT @Return_ID = NULL, @Return_MUID = NULL;  
                RAISERROR('MDSERR110007|The ID is not valid.', 16, 1);  
                RETURN;  
            END  
            ELSE  
            BEGIN  
                SET @MUID = @ExistingDerivedHierarchy_MUID;  
            END  
        END  
    END  
  
    --If the edit mode is Create. This code also needs to execute if the user sent in EditMode clone which ended up becoming Create (hence the IF instead of ELSE IF)  
    IF @EditMode = @EditMode_Create  
    BEGIN  
        --If MUID is not null then we need to ensure it does not already exist (since this is a create)  
        IF @MUID IS NOT NULL AND EXISTS(SELECT 1 FROM mdm.tblDerivedHierarchy WHERE MUID = @MUID)  
        BEGIN  
            --On error, return NULL results  
            SELECT @Return_ID = NULL, @Return_MUID = NULL;  
            RAISERROR('MDSERR110007|The ID is not valid.', 16, 1);  
            RETURN;  
        END  
    END  
  
      
    --Check the name of the derived hierarchy for duplicates  
    IF EXISTS   
    (  
        SELECT 1   
        FROM mdm.tblDerivedHierarchy   
        WHERE   
            @Name = Name AND   
            (@MUID IS NULL OR MUID <> @MUID) AND  
            Model_ID = @Model_ID  
    )  
    BEGIN  
        --On error, return NULL results  
        SELECT @Return_ID = NULL, @Return_MUID = NULL;  
        RAISERROR('MDSERR110003|The name already exists. Type a different name.', 16, 1);  
        RETURN;  
    END  
  
    BEGIN TRY  
  
        IF @Version_ID IS NULL  
        BEGIN  
            --Get the Latest Version  
            SET @Version_ID = (SELECT MAX(ID) FROM mdm.tblModelVersion WHERE Model_ID = @Model_ID)  
        END  
  
        IF @EditMode = @EditMode_Update  
        --Update  
        BEGIN  
            --Don't do anything if nothing is being updated (such as in a clone scenario).   
            --The cost of updating a derived hierarchy (regenerate all model views) is just too high  
            --TODO: Figure out if we can get away with regenerating fewer views  
            IF @ExistingDerivedHierarchy_Name <> @Name OR @ExistingDerivedHierarchy_AnchorNullRecursions <> @AnchorNullRecursions  
            BEGIN  
                UPDATE mdm.tblDerivedHierarchy              
                SET  
                    Name = ISNULL(@Name,Name),  
                    AnchorNullRecursions = @AnchorNullRecursions,  
                    LastChgDTM = GETUTCDATE(),  
                    LastChgUserID = @User_ID,  
                    LastChgVersionID = @Version_ID  
                WHERE  
                    ID = @ExistingDerivedHierarchy_ID;                   
  
                --Re Gen All Views  
                EXEC mdm.udpCreateViews @Model_ID = @Model_ID, @CorrelationID = @CorrelationID;  
  
                -- Regenerate subscription views if there are any  
                EXEC mdm.udpCreateAllSubscriptionViews @Model_ID = @Model_ID, @CorrelationID = @CorrelationID;  
            END  
  
            --Populate output parameters  
            SELECT @Return_ID = @ExistingDerivedHierarchy_ID;  
            SELECT @Return_MUID = @ExistingDerivedHierarchy_MUID;  
        END ELSE  
        --Create  
        BEGIN  
            --Accept an explicit MUID (for clone operations) or generate a new one  
            SET @Return_MUID = COALESCE(@MUID, NEWID());  
  
            INSERT INTO mdm.tblDerivedHierarchy   
            (  
                [Model_ID]  
                ,[Name]  
                ,[AnchorNullRecursions]  
                ,[MUID]  
                ,[EnterDTM]  
                ,[EnterUserID]  
                ,[EnterVersionID]  
                ,[LastChgDTM]  
                ,[LastChgUserID]  
                ,[LastChgVersionID]  
            )  
            SELECT   
                @Model_ID,  
                ISNULL(@Name,N''),  
                @AnchorNullRecursions,  
                @Return_MUID,  
                GETUTCDATE(),  
                @User_ID,  
                @Version_ID,  
                GETUTCDATE(),  
                @User_ID,  
                @Version_ID  
  
            SELECT @Return_ID = SCOPE_IDENTITY()  
        END  
  
    END TRY  
  
    --Compensate as necessary  
    BEGIN CATCH  
  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
  
        --On error, return NULL results  
        SELECT @Return_ID = NULL, @Return_MUID = NULL;  
        RETURN;  
  
    END CATCH;  
  
  
    SET NOCOUNT OFF  
END --proc
go

