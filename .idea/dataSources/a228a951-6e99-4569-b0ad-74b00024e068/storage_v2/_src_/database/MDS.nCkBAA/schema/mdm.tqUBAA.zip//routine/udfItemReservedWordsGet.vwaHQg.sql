/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Gets a table containing all reserved words for the given object type.  
  
*/  
CREATE FUNCTION mdm.udfItemReservedWordsGet (@ObjectType_ID INT)   
RETURNS @ReservedWords TABLE (ReservedWord NVARCHAR(250) PRIMARY KEY)  
/*WITH SCHEMABINDING*/  
AS BEGIN   
    IF @ObjectType_ID IN (3, 4) --3=Entity; 4=Attribute  
    BEGIN  
        INSERT INTO @ReservedWords   
        VALUES  
            (N'ID'),   
            (N'Code'),   
            (N'Name'),   
            (N'EnterDTM'),   
            (N'EnterUserID'),   
            (N'LastChgDTM'),   
            (N'LastChgUserID'),  
            (N'Status'),   
            (N'Status_ID'),   
            (N'ValidationStatus_ID'),  
            (N'MDMMemberStatus'),  
            (N'ValidationStatus'),  
            (N'EnterDateTime'),  
            (N'EnterUserName'),  
            (N'LastChgDateTime'),  
            (N'LastChgUserName');  
    END ELSE  
    IF @ObjectType_ID IN (12, 13, 14) --12=Leaf member; 13=Consolidated member; 14=Collection member  
    BEGIN  
        INSERT INTO @ReservedWords   
        VALUES  
            (N'ROOT'),   
            (N'MDMUNUSED'),   
            (N'MDMMemberStatus');  
    END;   
    RETURN;  
END;
go

