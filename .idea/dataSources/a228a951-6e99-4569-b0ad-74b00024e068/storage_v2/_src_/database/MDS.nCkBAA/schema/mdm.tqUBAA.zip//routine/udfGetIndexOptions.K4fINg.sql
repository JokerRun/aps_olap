/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE FUNCTION mdm.udfGetIndexOptions  
(  
    @dataCompression    TINYINT,  
    @modelId            INT = NULL  
)  
RETURNS NVARCHAR(MAX)  
/*WITH SCHEMABINDING*/  
AS BEGIN  
    DECLARE @dataCompressionOption    NVARCHAR(MAX) = N'NONE',  
            @fillFactor               INT,  
            @indexOptions             NVARCHAR(MAX);  
  
    IF mdm.udfIsEnterpriseEdition() = 1  
    BEGIN  
        SET @dataCompressionOption = CASE @dataCompression WHEN 1 THEN N'ROW' WHEN 2 THEN N'PAGE' ELSE N'NONE' END;  
    END  
    SET @fillFactor = CONVERT(INT, mdm.udfSystemSettingGet(N'IndexFillFactor'));  
    -- Default fill factor 80.  
    IF @fillFactor IS NULL OR @fillFactor <= 0 OR @fillFactor > 100 SET @fillFactor = 80  
    SET @indexOptions = CONCAT(N'WITH (DATA_COMPRESSION = ', @dataCompressionOption, N', FILLFACTOR = ', CAST(@fillFactor AS NVARCHAR(3)) , N')');  
  
    IF mdm.udfIsEnterpriseEdition() = 1 AND @modelId IS NOT NULL  
    BEGIN  
        SET @indexOptions = CONCAT(@indexOptions, N' ON udpsModel_', @modelId, N'([Version_ID])');  
    END  
    RETURN @indexOptions;  
END; --fn
go

