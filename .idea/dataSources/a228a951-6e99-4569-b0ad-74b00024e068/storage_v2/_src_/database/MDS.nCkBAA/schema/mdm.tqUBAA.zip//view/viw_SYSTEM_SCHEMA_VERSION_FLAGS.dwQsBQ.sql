/*  
SELECT * FROM mdm.viw_SYSTEM_SCHEMA_VERSION_FLAGS  
*/  
/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE VIEW mdm.viw_SYSTEM_SCHEMA_VERSION_FLAGS  
/*WITH SCHEMABINDING*/  
AS  
SELECT   
    F.ID,  
    F.MUID,  
    F.Model_ID,  
    M.MUID Model_MUID,  
    M.Name Model_Name,  
    F.Status_ID,  
    CAST(F.CommittedOnly_ID AS BIT) AS IsCommittedOnly,  
    F.Name,  
    F.Description,  
    ISNULL(V.ID, 0) as AssignedVersion_ID,  
    ISNULL(V.MUID,0x0) as AssignedVersion_MUID,  
    ISNULL(V.Name,N'') as AssignedVersion_Name,  
    F.EnterUserID EnteredUser_ID,  
    usrE.MUID EnteredUser_MUID,  
    usrE.UserName EnteredUser_UserName,  
    F.EnterDTM EnteredUser_DTM,  
    F.LastChgUserID LastChgUser_ID,  
    usrL.MUID LastChgUser_MUID,  
    usrL.UserName LastChgUser_UserName,  
    F.LastChgDTM LastChgUser_DTM  
FROM   
    mdm.tblModelVersionFlag F  
    INNER JOIN mdm.tblModel M ON F.Model_ID = M.ID  
    LEFT JOIN mdm.tblUser usrE ON F.EnterUserID = usrE.ID  
    LEFT JOIN mdm.tblUser usrL ON F.LastChgUserID = usrL.ID  
    LEFT JOIN mdm.tblModelVersion V ON F.ID = V.VersionFlag_ID
go

