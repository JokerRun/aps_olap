/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
EXEC mdm.udpDerivedHierarchyDelete 1  
select * from mdm.tblDerivedHierarchy  
*/  
CREATE PROCEDURE mdm.udpDerivedHierarchyDelete  
(  
   @ID       INT = NULL,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    DECLARE @ModelName      NVARCHAR(50),  
            @Model_ID       INT,  
            @ViewName       sysname,  
            @SQL			NVARCHAR(MAX),  
            @HierarchyMUID	UNIQUEIDENTIFIER;  
  
    SELECT   
         @Model_ID = dh.Model_ID   
        ,@HierarchyMUID = dh.MUID   
        ,@ModelName = m.Name  
    FROM mdm.tblDerivedHierarchy dh  
    LEFT JOIN mdm.tblModel m  
    ON dh.Model_ID = m.ID  
    WHERE dh.ID = @ID;  
  
    -- Remove any attribute filters that are referencing a level pertaining to the deleted hierarchy.  
    UPDATE a  
    SET   
         FilterParentAttribute_ID = NULL  
        ,FilterHierarchyDetail_ID = NULL  
    FROM mdm.tblAttribute a  
    INNER JOIN mdm.tblDerivedHierarchyDetail dhd  
    ON a.FilterHierarchyDetail_ID = dhd.ID  
    WHERE dhd.DerivedHierarchy_ID = @ID  
  
    --Delete the subscription views associated with the derived hierarchy  
    EXEC mdm.udpSubscriptionViewsDelete   
        @Model_ID               = NULL,  
        @Version_ID             = NULL,  
        @Entity_ID              = NULL,  
        @DerivedHierarchy_ID    = @ID;  
  
  
    --Delete any security assignments  
    DECLARE	@Object_ID	INT  
    SELECT	@Object_ID = mdm.udfSecurityObjectIDGetByCode(N'HIRDER')  
    EXEC mdm.udpSecurityPrivilegesDelete NULL, NULL, @Object_ID, @ID  
    DELETE FROM mdm.tblSecurityRoleAccessMember WHERE HierarchyType_ID = 1 AND Hierarchy_ID = @ID   
  
    --Delete the system view  
    SET @ViewName = CONCAT(N'viw_SYSTEM_', @Model_ID, N'_', @ID, N'_PARENTCHILD_DERIVED')  
    IF EXISTS(SELECT 1 FROM sys.views WHERE [name] = @ViewName AND [schema_id] = SCHEMA_ID('mdm'))  
    BEGIN  
        SET @SQL = CONCAT(N'DROP VIEW [mdm].', quotename(@ViewName), N';');  
        EXEC sp_executesql @SQL;  
    END  
  
  
    DELETE FROM mdm.tblDerivedHierarchyDetail WHERE DerivedHierarchy_ID = @ID  
    DELETE FROM mdm.tblDerivedHierarchy WHERE ID = @ID  
  
    --Put a msg onto the SB queue to process member security   
    --for all entities in All versions in the model to be safe - revisit  
    EXEC mdm.udpSecurityMemberProcessRebuildModel @Model_ID = @Model_ID, @ProcessNow=0;  
  
    IF @@ERROR <> 0  
    BEGIN  
        RAISERROR('MDSERR200060|The derived hierarchy level cannot be deleted. A database error occurred.', 16, 1);  
        RETURN       
    END  
  
    SET NOCOUNT OFF  
END --proc
go

