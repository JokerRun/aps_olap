/*  
exec mdm.udpUserListGetByItem 1,6   -- Model  
exec mdm.udpUserListGetByItem 2,6   -- Should return an empty resultset  
exec mdm.udpUserListGetByItem 3,1   -- Entity  
exec mdm.udpUserListGetByItem 4,158 -- Attribute  
*/  
/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpUserListGetByItem  
(  
	@Object_ID	INT,  
	@Securable_ID	INT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
	SET NOCOUNT ON  
  
	DECLARE @SQL            NVARCHAR(MAX)  
	DECLARE @ViewName		sysname;  
    DECLARE @ParamList		NVARCHAR(MAX)  
	SET @ParamList = N'@Securable_IDx	INT ';  
	  
	SELECT @ViewName = ViewName FROM mdm.tblSecurityObject WHERE ID = @Object_ID  
	IF @ViewName IS NULL BEGIN  
		SET  @Securable_ID = -11111  
		SELECT @ViewName = ViewName FROM mdm.tblSecurityObject WHERE ID = 1  
	END; --if  
	  
	SELECT @SQL =  
				N'  
				SELECT   
						u.ID,  
						u.UserName,  
						u.UserName + '' ('' + u.DisplayName + '')'' AS Name,  
						u.Description,  
						u.EmailAddress,  
						sec.Privilege_ID  AS Privilege_ID,  
                        sec.AccessPermission AS AccessPermission  
  
				FROM	mdm.' +  QUOTENAME(@ViewName) + N' sec  
						INNER JOIN mdm.tblUser u  
							ON sec.User_ID = u.ID AND sec.ID = @Securable_IDx AND u.Status_ID = 1  
				ORDER BY u.UserName;'  
	EXEC sp_executesql @SQL, @ParamList,@Securable_ID;  
  
	SET NOCOUNT OFF  
END --proc
go

