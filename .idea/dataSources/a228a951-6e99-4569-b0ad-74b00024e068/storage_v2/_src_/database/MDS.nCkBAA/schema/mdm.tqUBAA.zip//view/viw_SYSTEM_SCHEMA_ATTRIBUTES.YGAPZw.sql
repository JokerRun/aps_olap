/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    SELECT * FROM mdm.viw_SYSTEM_SCHEMA_ATTRIBUTES WHERE Attribute_DBAEntity_ID > 0  
    SELECT * FROM mdm.viw_SYSTEM_SCHEMA_ATTRIBUTES WHERE Entity_ID = 23  
    SELECT * FROM mdm.viw_SYSTEM_SCHEMA_ATTRIBUTES WHERE Entity_ID = 31 AND Attribute_MemberType_ID = 1  
    SELECT * FROM mdm.viw_SYSTEM_SCHEMA_ATTRIBUTES WHERE Entity_ID = 23 AND Attribute_Name = 'Weight'  
    SELECT * FROM mdm.viw_SYSTEM_SCHEMA_ATTRIBUTES WHERE Attribute_ID = 1067  
*/  
CREATE VIEW mdm.viw_SYSTEM_SCHEMA_ATTRIBUTES  
/*WITH SCHEMABINDING*/  
AS  
WITH attributesCte AS  
(  
    SELECT  
        tEnt.Model_ID                Model_ID,  
        tMod.MUID                    Model_MUID,  
        tMod.Name                    Model_Name,  
        tAtt.Entity_ID               Entity_ID,  
        tEnt.MUID                    Entity_MUID,  
        tEnt.Name                    Entity_Name,  
        tAtt.ID                      Attribute_ID,  
        tAtt.MUID                    Attribute_MUID,  
        tAtt.Name                    Attribute_Name,  
        tAtt.Description             Attribute_Description,  
        tAtt.DisplayName             Attribute_DisplayName,  
        tAtt.DisplayWidth            Attribute_DisplayWidth,  
        tAtt.ChangeTrackingGroup     Attribute_ChangeTrackingGroup,  
        tAtt.TableColumn             Attribute_Column,  
        tAtt.IsSystem                Attribute_IsSystem,  
        tAtt.IsReadOnly              Attribute_IsReadOnly,  
        tAtt.IsCode                  Attribute_IsCode,  
        tAtt.IsName                  Attribute_IsName,  
        tAtt.MemberType_ID           Attribute_MemberType_ID,  
        CASE tAtt.MemberType_ID   
            WHEN 1 THEN N'Leaf'  
            WHEN 2 THEN N'Consolidated'  
            WHEN 3 THEN N'Collection'  
            WHEN 4 THEN N'Hierarchy'  
            WHEN 5 THEN N'CollectionMember'  
            ELSE N'' END             Attribute_MemberType_Name,  
        tAtt.AttributeType_ID        Attribute_Type_ID,  
        CASE tAtt.AttributeType_ID  
            WHEN 1 THEN N'Freeform'  
            WHEN 2 THEN N'Domain'  
            WHEN 3 THEN N'System'  
            WHEN 4 THEN N'File'  
            ELSE N'' END             Attribute_Type_Name,  
        COALESCE(tAtt.DomainEntity_ID, 0)                           Attribute_DBAEntity_ID,  
        COALESCE(tDBAEnt.MUID, 0x0)                                 Attribute_DBAEntity_MUID,  
        COALESCE(tDBAEnt.Name, N'')                                 Attribute_DBAEntity_Name,  
        CASE WHEN tDBAEnt.HierarchyTable IS NULL THEN 0 ELSE 1 END  Attribute_DBAEntity_IsHierarchyEnabled,  
  
        COALESCE(tAtt.FilterParentAttribute_ID, 0)          FilterParentAttribute_ID,  
        COALESCE(filterParent.MUID, 0x0)                    FilterParentAttribute_MUID,  
        COALESCE(filterParent.Name, N'')                    FilterParentAttribute_Name,  
        COALESCE(filterHierarchyLevel.Hierarchy_ID, 0)      FilterParentHierarchy_ID,  
        COALESCE(filterHierarchyLevel.Hierarchy_MUID, 0x0)  FilterParentHierarchy_MUID,  
        COALESCE(filterHierarchyLevel.Hierarchy_Name, N'')  FilterParentHierarchy_Name,  
        COALESCE(filterHierarchyLevel.LevelNumber, -1)      FilterParentHierarchy_LevelNumber,  
  
        tAtt.DataType_ID             Attribute_DataType_ID,  
        CASE tAtt.DataType_ID  
            WHEN 1  THEN N'Text'  
            WHEN 2  THEN N'Number'  
            WHEN 3  THEN N'DateTime'  
            WHEN 6  THEN N'Link'  
            ELSE N'' END             Attribute_DataType_Name,  
        tAtt.DataTypeInformation     Attribute_DataType_Information,  
        tAtt.InputMask_ID            Attribute_DataMask_ID,  
        tDataMask.ListOption         Attribute_DataMask_Name,  
        CASE tAtt.MemberType_ID  
            WHEN 1 THEN tEnt.EntityTable  
            WHEN 2 THEN tEnt.HierarchyParentTable  
            WHEN 3 THEN tEnt.CollectionTable  
            WHEN 4 THEN tEnt.HierarchyTable  
            WHEN 5 THEN tEnt.CollectionMemberTable  
            ELSE N'' END             Entity_PhysicalTableName,  
        tAtt.SortOrder              Attribute_SortOrder,  
        COALESCE(tAtt.EnterUserID, 0)   EnteredUser_ID,  
        COALESCE(usrE.MUID, 0x0)    EnteredUser_MUID,  
        usrE.UserName               EnteredUser_UserName,  
        tAtt.EnterDTM               EnteredUser_DTM,  
        COALESCE(tAtt.LastChgUserID, 0) LastChgUser_ID,  
        COALESCE(usrL.MUID, 0x0)    LastChgUser_MUID,  
        usrL.UserName               LastChgUser_UserName,  
        tAtt.LastChgDTM             LastChgUser_DTM  
    FROM mdm.tblModel tMod  
    INNER JOIN mdm.tblEntity tEnt   
    ON tMod.ID = tEnt.Model_ID  
    INNER JOIN mdm.tblAttribute tAtt   
    ON tEnt.ID = tAtt.Entity_ID  
    LEFT JOIN mdm.tblUser usrE   
    ON tAtt.EnterUserID = usrE.ID  
    LEFT JOIN mdm.tblUser usrL   
    ON tAtt.LastChgUserID = usrL.ID  
    LEFT JOIN mdm.tblList tDataMask   
    ON      tDataMask.ListCode = N'lstInputMask'   
        AND tAtt.InputMask_ID = tDataMask.OptionID   
        AND tAtt.DataType_ID = tDataMask.Group_ID  
    LEFT JOIN mdm.tblEntity tDBAEnt   
    ON tAtt.DomainEntity_ID = tDBAEnt.ID  
  
    -- Filtered DBA parents  
    LEFT JOIN mdm.tblAttribute filterParent  
    ON tAtt.FilterParentAttribute_ID = filterParent.ID  
    LEFT JOIN mdm.viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED_LEVELS filterHierarchyLevel  
    ON tAtt.FilterHierarchyDetail_ID = filterHierarchyLevel.ID  
)  
SELECT  
    *, -- Usually it is best to not SELECT *, but in this case it is okay because we are selecting from the CTE whose columns are defined above.  
    CONCAT(QUOTENAME(Model_Name), N':', QUOTENAME(Entity_Name), N':', QUOTENAME(Attribute_MemberType_Name), N':', QUOTENAME(Attribute_Name)) Attribute_FullyQualifiedName  
FROM attributesCte
go

