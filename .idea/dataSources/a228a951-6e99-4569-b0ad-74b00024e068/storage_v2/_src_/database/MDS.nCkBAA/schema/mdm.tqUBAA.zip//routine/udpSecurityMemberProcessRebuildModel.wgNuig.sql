/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
--Puts a msg on the qureue for all entities and all versions in the model  
Then inserts a timer msg onto the queue to effectively "kick it off"  
  
--Account  
EXEC mdm.udpSecurityMemberProcessRebuildModel @Model_ID=3  
*/  
CREATE PROCEDURE mdm.udpSecurityMemberProcessRebuildModel  
(  
    @Model_ID       INT, --Required  
    @ProcessNow     BIT = 0  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE @SecurityMemberProcessEvent mdm.SecurityMemberProcessEvent  
  
    INSERT @SecurityMemberProcessEvent([User_ID],[Entity_ID],Version_ID)  
    SELECT NULL, e.ID, v.ID  
    FROM mdm.tblEntity AS e  
    INNER JOIN mdm.tblModelVersion AS v  
    ON v.Model_ID = e.Model_ID  
    WHERE v.Model_ID = @Model_ID;  
  
    EXEC mdm.udpSecurityMemberProcessRebuildEvent @SecurityMemberProcessEvent, @ProcessNow  
  
    SET NOCOUNT OFF;  
END; --proc
go

