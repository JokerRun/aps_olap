/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE VIEW mdm.viw_SYSTEM_SECURITY_USER_MEMBER  
/*WITH SCHEMABINDING*/  
AS  
SELECT  
    tRol.[User_ID],  
    MIN(tMbr.Privilege_ID) Privilege_ID,  
    SUM(Distinct(tMbr.AccessPermission & 0x1)) +  
    SUM(Distinct(tMbr.AccessPermission & 0x2)) +  
    SUM(Distinct(tMbr.AccessPermission & 0x4)) AS AccessPermission,  
    Version_ID,  
    Entity_ID,  
    Hierarchy_ID,  
    HierarchyType_ID,  
    Member_ID,  
    MemberType_ID,  
    tMbr.IsInitialized IsMapped  
FROM  
    mdm.tblSecurityRoleAccessMember tMbr  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ROLE tRol ON tMbr.Role_ID = tRol.Role_ID  
    LEFT JOIN mdm.viw_SYSTEM_SECURITY_USER_ENTITY e  
    ON      tMbr.Entity_ID = e.ID  
        AND tRol.[User_ID] = e.[User_ID]  
WHERE  
    HierarchyType_ID = 0 /*Explicit*/  
    AND e.Privilege_ID != 5 /*Admin*/-- Ignore member permissions if the user is a entity administrator.  
GROUP BY  
    tRol.[User_ID],  
    Version_ID,  
    Entity_ID,  
    Hierarchy_ID,  
    HierarchyType_ID,  
    Member_ID,  
    MemberType_ID,  
    tMbr.IsInitialized  
  
UNION ALL  
SELECT  
    tRol.[User_ID],  
    MIN(tMbr.Privilege_ID) Privilege_ID,  
    SUM(Distinct(tMbr.AccessPermission & 0x1)) +  
    SUM(Distinct(tMbr.AccessPermission & 0x2)) +  
    SUM(Distinct(tMbr.AccessPermission & 0x4)) AS AccessPermission,  
    Version_ID,  
    Entity_ID,  
    Hierarchy_ID,  
    HierarchyType_ID,  
    Member_ID,  
    MemberType_ID,  
    tMbr.IsInitialized IsMapped  
FROM  
    mdm.tblSecurityRoleAccessMember tMbr  
    JOIN mdm.viw_SYSTEM_SECURITY_USER_ROLE tRol ON tMbr.Role_ID = tRol.Role_ID  
    LEFT JOIN mdm.viw_SYSTEM_SECURITY_USER_ENTITY e  
    ON      tMbr.Entity_ID = e.ID  
        AND tRol.[User_ID] = e.[User_ID]  
WHERE  
    HierarchyType_ID = 1 /*Derived*/  
    AND e.Privilege_ID != 5 /*Admin*/-- Ignore member permissions if the user is a entity administrator.  
GROUP BY  
    tRol.[User_ID],  
    Version_ID,  
    Entity_ID,  
    Hierarchy_ID,  
    HierarchyType_ID,  
    Member_ID,  
    MemberType_ID,  
    tMbr.IsInitialized
go

