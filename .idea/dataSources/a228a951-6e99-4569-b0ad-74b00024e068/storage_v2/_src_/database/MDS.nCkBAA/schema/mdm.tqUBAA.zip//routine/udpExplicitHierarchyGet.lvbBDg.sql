/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpExplicitHierarchyGet  
(  
     @User_ID       INT  
  
    ,@Model_MUID    UNIQUEIDENTIFIER = NULL  
    ,@Model_Name    NVARCHAR(50) = NULL  
    ,@Model_ID      INT = NULL -- set internally only  
  
    ,@Entity_MUID   UNIQUEIDENTIFIER = NULL  
    ,@Entity_Name   NVARCHAR(50) = NULL  
    ,@Entity_ID     INT = NULL -- set internally only  
  
    ,@HierarchyTable mdm.Identifier READONLY  
  
    ,@IncludeParentIdentifiers  BIT = 1 -- Return results sets for parent Model and Entity identifiers. Set to 0 when getting explicit hierarchies as part of a parent object (because the parent identifiers will already have been looked up).  
    ,@Debug                     BIT = 0  
    ,@CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
  
    SET NOCOUNT ON  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': begin udpExplicitHierarchyGet')  
  
    -- Get model ID  
    IF @Model_ID IS NULL -- If the ID was already provided, don't bother looking it up again  
        AND (@Model_Name IS NOT NULL OR @Model_MUID IS NOT NULL)  
    BEGIN  
        SELECT   
             @Model_ID = ID  
            ,@Model_MUID = MUID  
            ,@Model_Name = Name  
        FROM mdm.tblModel  
        WHERE   MUID = ISNULL(@Model_MUID, MUID)  
            AND Name = ISNULL(@Model_Name, Name)  
  
        SET @Model_ID = COALESCE(@Model_ID, 0)  
    END  
  
    -- Get entity ID  
    IF @Entity_ID IS NULL -- If the ID was already provided, don't bother looking it up again  
        AND (@Entity_Name IS NOT NULL OR @Entity_MUID IS NOT NULL)  
    BEGIN  
        SELECT  
             @Model_ID = Model_ID  
            ,@Entity_ID = ID  
            ,@Entity_MUID = MUID  
            ,@Entity_Name = Name  
        FROM mdm.tblEntity  
        WHERE   MUID = ISNULL(@Entity_MUID, MUID)  
            AND Name = ISNULL(@Entity_Name, Name)  
            AND Model_ID = ISNULL(@Model_ID, Model_ID) -- If a model filter is specified, use it  
  
        SET @Entity_ID = COALESCE(@Entity_ID, 0)  
    END  
  
    DECLARE @SelectedHierarchy TABLE   
    (  
         ID                 INT PRIMARY KEY  
        ,Entity_ID          INT  
        ,Model_ID           INT  
        ,Privilege_ID       TINYINT  
        ,AccessPermission   TINYINT  
    )  
  
    IF EXISTS(SELECT 1 FROM @HierarchyTable)  
    BEGIN  
        INSERT INTO @SelectedHierarchy  
        SELECT  
             h.Hierarchy_ID AS ID  
            ,h.Entity_ID  
            ,h.Model_ID  
            ,acl.Privilege_ID  
            ,acl.AccessPermission  
        FROM mdm.viw_SYSTEM_SCHEMA_HIERARCHY_EXPLICIT h  
        INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_HIERARCHY acl  
        ON h.Hierarchy_ID = acl.ID  
        INNER JOIN @HierarchyTable ht  
        ON      h.Hierarchy_MUID = ISNULL(ht.MUID, h.Hierarchy_MUID)  
            AND h.Hierarchy_Name = ISNULL(ht.Name, h.Hierarchy_Name)  
        WHERE   acl.User_ID = @User_ID  
            AND h.Model_ID = ISNULL(@Model_ID, h.Model_ID)  
            AND h.Entity_ID = ISNULL(@Entity_ID, h.Entity_ID)  
            AND (ht.MUID IS NOT NULL OR ht.Name IS NOT NULL)  
    END ELSE  
    BEGIN  
        INSERT INTO @SelectedHierarchy  
        SELECT  
             h.Hierarchy_ID AS ID  
            ,h.Entity_ID  
            ,h.Model_ID  
            ,acl.Privilege_ID  
            ,acl.AccessPermission  
        FROM mdm.viw_SYSTEM_SCHEMA_HIERARCHY_EXPLICIT h  
        INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_HIERARCHY acl  
        ON h.Hierarchy_ID = acl.ID  
        WHERE   acl.User_ID = @User_ID  
            AND h.Model_ID = ISNULL(@Model_ID, h.Model_ID)  
            AND h.Entity_ID = ISNULL(@Entity_ID, h.Entity_ID)  
    END  
  
    IF @IncludeParentIdentifiers = 1  
    BEGIN  
        -- Return model Identifier(s)  
        IF @Model_ID IS NOT NULL  
        BEGIN  
            IF @Model_Name IS NULL OR @Model_MUID IS NULL  
            BEGIN  
                SELECT   
                     @Model_MUID = MUID  
                    ,@Model_Name = Name  
                FROM mdm.tblModel  
                WHERE ID = @Model_ID  
            END  
  
            -- A single model was specified, and its info has already been looked up, so simply return it  
            SELECT   
                 @Model_MUID    AS Model_MUID  
                ,@Model_Name    AS Model_Name  
                ,@Model_ID      AS Model_ID  
        END ELSE  
        BEGIN  
            SELECT DISTINCT  
                 m.MUID AS Model_MUID  
                ,m.Name AS Model_Name  
                ,m.ID   AS Model_ID  
            FROM @SelectedHierarchy h  
            INNER JOIN mdm.tblEntity e  
            ON h.Entity_ID = e.ID  
            INNER JOIN mdm.tblModel m  
            ON e.Model_ID = m.ID  
        END  
  
        -- Return entity Identifier(s)  
        IF @Entity_ID IS NOT NULL  
        BEGIN  
            -- A single entity was specified, and its info has already been looked up, so simply return it  
            SELECT   
                 @Model_ID      AS Model_ID  
                ,@Entity_MUID   AS Entity_MUID  
                ,@Entity_Name   AS Entity_Name  
                ,@Entity_ID     AS Entity_ID  
        END ELSE  
        BEGIN  
            SELECT DISTINCT  
                 e.Model_ID AS Model_ID  
                ,e.MUID AS Entity_MUID  
                ,e.Name AS Entity_Name  
                ,e.ID   AS Entity_ID  
            FROM @SelectedHierarchy h  
            INNER JOIN mdm.tblEntity e  
            ON h.Entity_ID = e.ID  
        END  
    END  
  
    SELECT  
         h.Hierarchy_MUID   AS ExplicitHierarchy_MUID  
        ,h.Hierarchy_Name   AS ExplicitHierarchy_Name  
        ,h.Hierarchy_ID     AS ExplicitHierarchy_ID  
        ,sh.Privilege_ID  
        ,sh.AccessPermission  
  
        ,h.Entity_ID  
        ,h.Hierarchy_IsMandatory AS IsMandatory  
  
        ,h.EnteredUser_DTM  
        ,h.EnteredUser_MUID  
        ,h.EnteredUser_UserName  
        ,h.EnteredUser_ID  
        ,h.LastChgUser_DTM  
        ,h.LastChgUser_MUID  
        ,h.LastChgUser_UserName  
        ,h.LastChgUser_ID  
    FROM @SelectedHierarchy sh  
    INNER JOIN mdm.viw_SYSTEM_SCHEMA_HIERARCHY_EXPLICIT h  
    ON sh.ID = h.Hierarchy_ID  
    ORDER BY sh.Model_ID, sh.Entity_ID, h.Hierarchy_Name  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': end udpExplicitHierarchyGet')  
  
    SET NOCOUNT OFF  
END --proc
go

