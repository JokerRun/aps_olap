/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
DECLARE @IsValidated BIT  
EXEC mdm.udpVersionValidationStatusGet 20, @IsValidated OUTPUT  
SELECT @IsValidated  
*/  
CREATE PROCEDURE mdm.udpVersionValidationStatusGet  
(  
    @Model_ID   INT,  
    @Version_ID  INT,  
    @IsValidated BIT = NULL OUTPUT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON  
  
    SET @IsValidated = 1  
  
  
    DECLARE @tblList TABLE   
    (  
         RowNumber          INT IDENTITY (1, 1) PRIMARY KEY CLUSTERED NOT NULL  
        ,ValidationTable    sysname COLLATE database_default --Flag to track if the table is used for validation.  
    )   
    DECLARE @SQL     NVARCHAR(MAX)  
    DECLARE @Table   sysname  
      
    --Get the list of entity table names for the model  
    INSERT INTO @tblList  
      SELECT EntityTable AS ValidationTable   
      FROM mdm.tblEntity   
      WHERE Model_ID = @Model_ID  
      UNION ALL  
      SELECT HierarchyParentTable   
      FROM mdm.tblEntity   
      WHERE Model_ID = @Model_ID   
        AND HierarchyParentTable IS NOT NULL  
  
    DECLARE @Counter INT = 1;  
    DECLARE @MaxCounter INT = (SELECT MAX(RowNumber) FROM @tblList);  
  
    WHILE @Counter <= @MaxCounter  
    BEGIN  
       SELECT @Table = ValidationTable   
       FROM @tblList   
       WHERE [RowNumber] = @Counter  
  
        SET @SQL = N'SELECT @IsValidated = CASE WHEN EXISTS(SELECT ID FROM mdm.' + quotename(@Table) + N' WHERE Version_ID = @Version_ID AND ValidationStatus_ID <> 3 AND Status_ID = 1) THEN 0 ELSE 1 END';  
         
       EXEC sp_executesql @SQL, N'@Version_ID INT, @IsValidated INT OUTPUT', @Version_ID, @IsValidated OUTPUT;  
         
       -- Return as soon as we find a member table that is not validated.  No need to check any further.  
        IF @IsValidated = 0  
        BEGIN  
            RETURN @IsValidated;  
        END  
  
        SET @Counter += 1;  
    END  
  
    SET NOCOUNT OFF  
      
    RETURN @IsValidated;  
END --proc
go

