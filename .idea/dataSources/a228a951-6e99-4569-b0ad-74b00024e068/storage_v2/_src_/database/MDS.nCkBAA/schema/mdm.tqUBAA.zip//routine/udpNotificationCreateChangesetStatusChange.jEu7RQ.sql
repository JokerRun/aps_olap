/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
This SPROC is only called by mdm.udpEntityMemberChangesetSave, so no need to valid the parameter value again  
*/  
CREATE PROCEDURE mdm.udpNotificationCreateChangesetStatusChange  
(  
    @User_ID            INT,  
    @Model_Name         NVARCHAR(50) = NULL,  
    @Model_MUID         UNIQUEIDENTIFIER = NULL,  
    @Model_ID           INT,  
    @Entity_Name        NVARCHAR(50) = NULL,  
    @Entity_MUID        UNIQUEIDENTIFIER= NULL,  
    @Entity_ID          INT,  
    @Version_Name       NVARCHAR(50) = NULL,  
    @Version_MUID       UNIQUEIDENTIFIER = NULL,  
    @Version_ID         INT,  
    @Changeset_Name     NVARCHAR(250) = NULL,  
    @Changeset_MUID     UNIQUEIDENTIFIER = NULL,  
    @Onwer_ID           INT,  
    @PriorStatus_ID     INT,  
    @NewStatus_ID       INT,  
    @CorrelationID      UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE  
        @NotificationType           INT = 3,  
        @LocalizedPriorStatus       NVARCHAR(MAX) = N'',  
        @LocalizedNewStatus         NVARCHAR(MAX) = N'',  
  
        @NotificationQueue_ID       INT,  
  
        @CurrentLanguageCode        INT = 1033, -- Default language code is English (US).  
        @StringLanguageCode         NVARCHAR(MAX) = N'',  
  
        @Permission_Admin           TINYINT = 5,  
  
        @ChangesetStatus_Open       TINYINT = 1,  
        @ChangesetStatus_Pending    TINYINT = 2,  
        @ChangesetStatus_Approved   TINYINT = 3,  
        @ChangesetStatus_Rejected   TINYINT = 4,  
        @ChangesetStatus_Committed  TINYINT = 5;  
  
    -- Use default language code to get the notification language code.  
    SET @StringLanguageCode = mdm.udfLocalizedStringGet(N'NotificationLCID', @CurrentLanguageCode, 1033);  
  
    IF @StringLanguageCode <> N''  
    BEGIN  
        SET @CurrentLanguageCode = CONVERT(INT, @StringLanguageCode)  
    END; -- if  
  
    SET @LocalizedPriorStatus =  
        CASE @PriorStatus_ID  
            WHEN @ChangesetStatus_Open THEN N'Open'  
            WHEN @ChangesetStatus_Pending THEN N'Pending'  
            WHEN @ChangesetStatus_Approved THEN N'Approved'  
            WHEN @ChangesetStatus_Rejected THEN N'Rejected'  
            WHEN @ChangesetStatus_Committed THEN N'Committed'  
        END;  
  
    SET @LocalizedNewStatus =  
        CASE @NewStatus_ID  
            WHEN @ChangesetStatus_Open THEN N'Open'  
            WHEN @ChangesetStatus_Pending THEN N'Pending'  
            WHEN @ChangesetStatus_Approved THEN N'Approved'  
            WHEN @ChangesetStatus_Rejected THEN N'Rejected'  
            WHEN @ChangesetStatus_Committed THEN N'Committed'  
        END;  
  
    -- Get the localized message texts based on the notification language code in tblLocalizedStrings.  
    SET @LocalizedPriorStatus = mdm.udfLocalizedStringGet(CONCAT(N'NotificationChangesetStatus', @LocalizedPriorStatus), @CurrentLanguageCode, @LocalizedPriorStatus);  
    SET @LocalizedNewStatus = mdm.udfLocalizedStringGet(CONCAT(N'NotificationChangesetStatus', @LocalizedNewStatus), @CurrentLanguageCode, @LocalizedNewStatus);  
  
    BEGIN TRAN  
        INSERT INTO mdm.tblNotificationQueue (  
             NotificationType_ID  
            ,Version_ID  
            ,Model_ID  
            ,[Entity_ID]  
            ,[Message]  
            ,EnterDTM  
            ,EnterUserID  
        )  
        SELECT  
            @NotificationType  
            ,@Version_ID  
            ,@Model_ID  
            ,@Entity_ID  
            ,CONCAT(N'  
                <notification>  
                  <model>', (SELECT @Model_Name FOR XML PATH('')), N'</model>  
                  <model_muid>', @Model_MUID, N'</model_muid>  
                  <version>', (SELECT @Version_Name FOR XML PATH('')), N'</version>  
                  <version_muid>', @Version_MUID, N'</version_muid>  
                  <entity>', (SELECT @Entity_Name FOR XML PATH('')), N'</entity>  
                  <entity_muid>', @Entity_MUID, N'</entity_muid>  
                  <changeset>', (SELECT @Changeset_Name FOR XML PATH('')), N'</changeset>  
                  <changeset_muid>', @Changeset_MUID, N'</changeset_muid>  
                  <prior_status>', (SELECT @LocalizedPriorStatus FOR XML PATH('')), N'</prior_status>  
                  <new_status>', (SELECT @LocalizedNewStatus FOR XML PATH('')), N'</new_status>  
                </notification>')  
            ,GETUTCDATE()  
            ,@User_ID  
  
        IF (@@ERROR <> 0)  
        BEGIN  
            RAISERROR('MDSERR100029|Cannot insert into notification queue because of general insert error.', 16, 1);  
            ROLLBACK TRAN;  
            RETURN;  
        END; --if  
  
        SET @NotificationQueue_ID = SCOPE_IDENTITY();  
  
        -- Insert into mdm.tblNotificationUsers  
        INSERT INTO mdm.tblNotificationUsers (  
            Notification_ID,  
            [User_ID]  
        )  
        SELECT @NotificationQueue_ID, [User_ID]  
        FROM mdm.viw_SYSTEM_SECURITY_USER_ENTITY  
        WHERE ID = @Entity_ID  
            AND (Privilege_ID = @Permission_Admin OR [User_ID] = @Onwer_ID);  
  
        IF (@@ERROR <> 0) BEGIN  
            RAISERROR('MDSERR100030|Cannot insert into notification users because of general insert error.', 16, 1);  
            ROLLBACK TRAN;  
            RETURN;  
        END; --if  
  
    COMMIT TRAN;  
  
    SET NOCOUNT OFF;  
END; --proc
go

