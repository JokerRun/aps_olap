/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
SELECT * FROM mdm.viw_SYSTEM_SECURITY_ROLE_ACCESSCONTROL_MEMBER  
  
*/  
CREATE VIEW mdm.viw_SYSTEM_SECURITY_ROLE_ACCESSCONTROL_MEMBER  
/*WITH SCHEMABINDING*/  
AS  
SELECT  
     ra.ID AS RoleAccess_ID  
    ,ra.MUID AS RoleAccess_MUID  
    ,ra.Privilege_ID  
    ,ra.AccessPermission  
    ,mdl.ID AS Model_ID  
    ,mdl.MUID AS Model_MUID  
    ,mdl.Name AS Model_Name  
    ,CASE modSec.Privilege_ID WHEN 5 /*Admin*/ THEN 1 ELSE 0 END IsModelAdministrator  
    ,ra.Version_ID  
    ,modv.MUID AS Version_MUID  
    ,modv.Name as Version_Name  
    ,ra.HierarchyType_ID  
    ,ra.Hierarchy_ID  
    ,ISNULL(hi.MUID, dh.MUID) AS Hierarchy_MUID  
    ,ISNULL(hi.Name, dh.Name) AS Hierarchy_Name  
    ,ra.Entity_ID  
    ,ent.MUID AS Entity_MUID  
    ,ent.Name AS Entity_Name  
    ,ra.MemberType_ID  
    ,ra.Member_ID  
    ,ra.Role_ID  
    ,ac.PrincipalType_ID  
    ,ac.Principal_ID  
    ,CASE ac.PrincipalType_ID WHEN 1/*User*/ THEN u.MUID     ELSE ug.MUID END AS Principal_MUID  
    ,CASE ac.PrincipalType_ID WHEN 1/*User*/ THEN u.UserName ELSE ug.Name END AS Principal_Name  
    ,ra.EnterUserID  
    ,eu.MUID AS EnterUserMUID  
    ,eu.DisplayName AS EnterUser  
    ,ra.EnterDTM  
    ,ra.LastChgUserID  
    ,lcu.MUID AS LastChgUserMUID  
    ,lcu.DisplayName AS LastChgUser  
    ,ra.LastChgDTM  
FROM mdm.tblSecurityRole r  
INNER JOIN mdm.tblSecurityAccessControl ac   
ON r.ID = ac.Role_ID  
INNER JOIN mdm.tblSecurityRoleAccessMember ra   
ON ra.Role_ID = r.ID  
LEFT JOIN mdm.tblEntity ent   
ON ra.Entity_ID = ent.ID   
LEFT JOIN mdm.tblModelVersion modv   
ON ra.Version_ID = modv.ID  
LEFT JOIN mdm.tblModel mdl   
ON modv.Model_ID = mdl.ID  
LEFT JOIN mdm.viw_SYSTEM_SECURITY_USER_MODEL modSec  
ON      ac.PrincipalType_ID = 1/*User*/  
    AND ac.Principal_ID = modSec.User_ID  
    AND mdl.ID = modSec.ID  
LEFT JOIN mdm.tblHierarchy hi   
ON      ra.Hierarchy_ID = hi.ID   
    AND ra.HierarchyType_ID = 0/*Explicit Hierarchy*/  
LEFT JOIN mdm.tblDerivedHierarchy dh   
ON      ra.Hierarchy_ID = dh.ID   
    AND ra.HierarchyType_ID = 1/*Derived Hierarchy*/  
LEFT JOIN mdm.tblUserGroup ug   
ON      ac.PrincipalType_ID = 2/* UserGroup*/   
    AND ac.Principal_ID = ug.ID   
    AND ug.Status_ID = 1 /*Active*/  
LEFT JOIN mdm.tblUser u   
ON      ac.PrincipalType_ID = 1/*User*/   
    AND ac.Principal_ID = u.ID   
LEFT JOIN mdm.tblUser eu   
ON ra.EnterUserID = eu.ID   
LEFT JOIN mdm.tblUser lcu   
ON ra.LastChgUserID = lcu.ID
go

