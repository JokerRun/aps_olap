/*    
==============================================================================    
 Copyright (c) Microsoft Corporation. All Rights Reserved.    
==============================================================================    
*/    
CREATE PROCEDURE [mdm].[udpRegenerateViewsAndStoredProcedures]      
(  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
AS BEGIN    
    SET NOCOUNT ON;  
        
    -- Add staging SProcs and staging error views   
  
    DECLARE @ID                 INT,  
            @EntityID           INT,  
            @IsHierarchyEnabled BIT,  
            @EntityName         NVARCHAR(MAX),  
            @StagingBase        NVARCHAR(MAX),   
            @SQL                NVARCHAR(MAX);  
              
    DECLARE @tblEntity TABLE     
    (    
        ID          INT IDENTITY (1, 1) NOT NULL,      
        Entity_ID   INT,    
        IsHierarchyEnabled      BIT,  
        EntityName NVARCHAR(MAX),  
        StagingBase NVARCHAR(MAX)  
    );    
              
    INSERT INTO @tblEntity  
    (  
        Entity_ID, IsHierarchyEnabled, EntityName, StagingBase  
    )  
    SELECT   
        ID,  
        CASE WHEN HierarchyTable IS NULL THEN 0 ELSE 1 END,  
        [Name],  
        StagingBase  
    FROM mdm.tblEntity  
          
    WHILE EXISTS(SELECT 1 FROM @tblEntity) BEGIN  
  
        SELECT TOP 1  
            @ID = ID,  
            @EntityID = Entity_ID,  
            @IsHierarchyEnabled = IsHierarchyEnabled,  
            @EntityName = EntityName,  
            @StagingBase = StagingBase  
        FROM @tblEntity  
        ORDER BY ID;	  
                  
        -- Generate staging SProcs  
        EXEC mdm.udpEntityStagingCreateLeafStoredProcedure @EntityID  
  
        IF @IsHierarchyEnabled = 1   
        BEGIN  
            EXEC mdm.udpEntityStagingCreateConsolidatedStoredProcedure @EntityID  
            EXEC mdm.udpEntityStagingCreateRelationshipStoredProcedure @EntityID  
        END  
          
        -- Change entity staging error views.   
        EXEC mdm.udpEntityStagingCreateErrorDetailViews @EntityID;    
                                           
        DELETE FROM @tblEntity WHERE ID = @ID  
          
    END -- WHILE  
  
    -- Regenerate views for entities.  
    EXEC mdm.udpCreateAllViews;  
  
    SET NOCOUNT OFF;  
        
END; --proc
go

