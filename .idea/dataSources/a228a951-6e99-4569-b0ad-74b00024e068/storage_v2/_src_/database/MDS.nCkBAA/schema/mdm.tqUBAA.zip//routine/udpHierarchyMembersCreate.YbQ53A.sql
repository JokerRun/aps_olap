/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Description: Bulk creates hierarchy member records.  
  
    EXEC mdm.udpHierarchyMembersCreate 1, 8, 0, 50, 2;  
*/  
CREATE PROCEDURE mdm.udpHierarchyMembersCreate  
(  
    @User_ID            INT,  
    @Version_ID         INT,  
    @Entity_ID          INT,  
    @HierarchyMembers   mdm.HierarchyMembers READONLY,  
    @LogFlag            INT = NULL, --1 = log the transaction; anything else = do not log  
    @CorrelationID      UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE  
         @HierarchyTable            SYSNAME  
        ,@SQL                       NVARCHAR(MAX)  
        ,@strMemberTypeLeaf         NVARCHAR(1) = N'1'  
        ,@strMemberTypeConsolidated NVARCHAR(1) = N'2'  
        ,@strStatus_Active          NVARCHAR(1) = N'1'  
        ,@MemberType_Hierarchy      TINYINT = 4  
        ,@HRHistoryOutputQuery      NVARCHAR(MAX)  
  
        ,@TransactionLogType        TINYINT  
        ,@TransactionLogType_Member TINYINT = 2  
        ,@TransactionLogType_None   TINYINT = 3;  
  
    CREATE TABLE #NewMembers  
        (ID	INT);  
  
    --Get the Entity Hierarchy Table Name  
    SELECT @HierarchyTable = QUOTENAME(HierarchyTable)  
           ,@TransactionLogType = CASE @LogFlag WHEN 1 THEN TransactionLogType ELSE @TransactionLogType_None END  
    FROM mdm.tblEntity  
    WHERE ID = @Entity_ID;  
  
    IF @TransactionLogType = @TransactionLogType_Member  
    BEGIN  
        SET @HRHistoryOutputQuery = mdm.udfGetHistoryOutputQuery(@Entity_ID, @MemberType_Hierarchy, N'@User_ID', N'@Now');  
    END  
  
    IF @HierarchyTable IS NULL  
    BEGIN  
        RAISERROR('MDSERR310021|For consolidated members, the entity must be enabled for hierarchies and collections.', 16, 1);  
        RETURN;  
    END  
  
    --Insert into the Correct Hierarchy Relationship table  
    SELECT @SQL = N'  
        --Hard-delete any soft deleted hierarchy relationship records for any leaf children  
        --being added  
        DECLARE @Now DATETIME = GETUTCDATE();  
  
        DELETE FROM mdm.' + @HierarchyTable + CASE @TransactionLogType WHEN @TransactionLogType_Member THEN @HRHistoryOutputQuery ELSE N'' END + N'  
        FROM mdm.' + @HierarchyTable + N' hr  
        INNER JOIN @HierarchyMembers hm ON  
        hr.Hierarchy_ID = hm.Hierarchy_ID AND  
        hr.ChildType_ID = hm.ChildMemberType_ID AND  
        hr.Child_EN_ID = hm.Child_ID  
        WHERE hr.Status_ID <> ' + @strStatus_Active + N' AND hm.ChildMemberType_ID = ' + @strMemberTypeLeaf + N';  
  
        --Hard-delete any soft deleted hierarchy relationship records for any consolidated children  
        --being added  
        DELETE FROM mdm.' + @HierarchyTable + CASE @TransactionLogType WHEN @TransactionLogType_Member THEN @HRHistoryOutputQuery ELSE N'' END +  N'  
        FROM mdm.' + @HierarchyTable + N' hr  
        INNER JOIN @HierarchyMembers hm ON  
        hr.Hierarchy_ID = hm.Hierarchy_ID AND  
        hr.ChildType_ID = hm.ChildMemberType_ID AND  
        hr.Child_HP_ID = hm.Child_ID  
        WHERE hr.Status_ID <> ' + @strStatus_Active + N' AND hm.ChildMemberType_ID = ' + @strMemberTypeConsolidated + N';  
  
        INSERT INTO mdm.' + @HierarchyTable + N'  
        (  
            Version_ID,  
            Status_ID,  
            Hierarchy_ID,  
            Parent_HP_ID,  
            ChildType_ID,  
            Child_EN_ID,  
            Child_HP_ID,  
            SortOrder,  
            LevelNumber,  
            EnterDTM,  
            EnterUserID,  
            EnterVersionID,  
            LastChgDTM,  
            LastChgUserID,  
            LastChgVersionID  
        )  
        OUTPUT inserted.ID INTO #NewMembers  
        SELECT  
             @Version_ID  
            ,1  
            ,hm.Hierarchy_ID  
            ,NULLIF(hm.Parent_ID, 0) --Parent_HP_ID  
            ,hm.ChildMemberType_ID  
            ,CASE hm.ChildMemberType_ID WHEN 1 THEN hm.Child_ID ELSE NULL END --Child_EN_ID  
            ,CASE hm.ChildMemberType_ID WHEN 2 THEN hm.Child_ID ELSE NULL END --Child_HP_ID  
            ,1  
            ,-1  
            ,GETUTCDATE()  
            ,@User_ID  
            ,@Version_ID  
            ,GETUTCDATE()  
            ,@User_ID  
            ,@Version_ID  
        FROM @HierarchyMembers hm;  
  
        UPDATE mdm.' + @HierarchyTable + N'  
        SET SortOrder = nm.ID  
        FROM mdm.' + @HierarchyTable + N' hr INNER JOIN #NewMembers	nm  
            ON hr.ID = nm.ID AND Version_ID = @Version_ID;  
        ';  
  
    --PRINT(@SQL);  
    EXEC sp_executesql @SQL,  
        N'@User_ID INT, @Version_ID INT, @HierarchyMembers mdm.HierarchyMembers READONLY',  
        @User_ID, @Version_ID, @HierarchyMembers;  
  
    SET NOCOUNT OFF;  
END; --proc
go

