/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Bulk saves entity members. Leaf and Collection members only (not Consolidated)  
  
Returned tables:  
- Errors, if @ErrorReportingType indicates that errors should be included in the result set.  
- Created Members, if @ReturnCreatedMembers = 1  
  
Permission:  
---         MemberType, Attribute,      Member  
-- Create,  N/A,        Create*,        N/A  
-- Update,  N/A,        Update,         Update  
-- Merge,   N/A,        CreateUpdate**, Update  
-- Get,     N/A,        Read,           Read  
-- Delete   Delete,     N/A,            Delete  
  
*Includes Code and Name  
**Depends on the member is new or existing, will require Create or Update  
  
If this sproc raises an error, it means that the entire batch was rolled back and no tables were changed.  
On the other hand, if the sproc doesn't raise an error but does return errors (in the result set and/or in the @Errors XML  
output param), the member table(s) may have been modified.  
  
  
**********************************************************  
The below code can be used to help troubleshoot issues and measure perf.  
  
-- Create a log table for measuring perf  
CREATE TABLE mdm.tblPerfLog  
(  
     ID INT IDENTITY(1,1) NOT NULL  
    ,SPID INT NOT NULL  
    ,[Message] NVARCHAR(MAX)  
    ,[Time]   DATETIME2(7)  
)  
  
-- Create a sproc to write messages to the log table.  
CREATE PROC mdm.udpLogMessage  
(  
    @Message NVARCHAR(MAX) = NULL  
)  
AS  
BEGIN  
    DECLARE @Len INT = LEN(@Message)  
    PRINT CONVERT(NVARCHAR, SYSDATETIME()) + N': ' + @Message  
    DECLARE @StartIndex INT = 4000  
    WHILE @StartIndex < @Len  
    BEGIN  
        PRINT SUBSTRING(@Message, @StartIndex, 4000)  
        SET @StartIndex += 4000;  
    END  
  
    INSERT INTO mdm.tblPerfLog  
        (SPID, [Message], [Time])  
    VALUES  
        (@@SPID, @Message, SYSDATETIME());  
END;  
  
  
-- Get the items from the perf log table, and compute duration between entries. This is useful for identifying  
-- bottlenecks in the sproc. Run this query after changing all of the "IF @Debug = 1" lines to call udpLogMessage  
-- instead of calling PRINT, and then set the @Debug flag when running this sproc.  
SELECT  
     msg.*  
    ,DATEDIFF(ms, msg.[Time], nextMessage.[Time]) AS DurationInMs  -- How much time passed between when this message and the very next message were logged.  
FROM mdm.tblPerfLog msg  
LEFT JOIN mdm.tblPerfLog nextMessage  
ON msg.ID + 1 = nextMessage.ID  
ORDER BY msg.ID  
  
*/  
CREATE PROCEDURE mdm.udpEntityMembersSave  
(  
     @User_ID                   INT  
  
     -- The metadata item (Model, Version, Entity) identifier properties are output params because this sproc looks up complete identifier info for the caller,  
     -- which is useful when only partial info was passed in. For example,  
     -- If the caller passes in @EntityMuid but leaves @EntityName null, then by the time this sproc finishes @EntityName will be populated with the correct  
     -- value (if the Entity MUID was valid and the user has permission to see the Entity). Doing metadata item lookups in this sproc reduces the number  
     -- of db calls from the web service.  
    ,@ModelName                 NVARCHAR(50) = NULL OUTPUT  
    ,@ModelMuid                 UNIQUEIDENTIFIER = NULL  OUTPUT  
    ,@Model_ID                  INT = NULL OUTPUT  
    ,@EntityName                NVARCHAR(50) = NULL OUTPUT  
    ,@EntityMuid                UNIQUEIDENTIFIER = NULL OUTPUT  
    ,@Entity_ID                 INT = NULL OUTPUT  
    ,@VersionName               NVARCHAR(50) = NULL OUTPUT  
    ,@VersionMuid               UNIQUEIDENTIFIER = NULL OUTPUT  
    ,@Version_ID                INT = NULL OUTPUT  
  
    ,@MemberType_ID             TINYINT = NULL -- Only Leaf and Collection supported.  
  
    ,@Members                   mdm.MemberSaveList READONLY -- Contains member identifier info (i.e. Name, Code, Muid, etc) for the members being created/updated  
    ,@MemberAttributes          mdm.MemberAttributeValues READONLY  -- Contains new attribute values of the members in the @Members param  
  
    ,@SaveMode                  TINYINT = 0 -- 1 = Create, 2 = Merge, 3 = Update  
    ,@TransactionBehavior       TINYINT = 0 -- 0 = BestEffort,  
                                            -- 1 = AllOrNothingByMember (if any part of a member has an error, then all member-related changes will be aborted)  
                                            -- 2 = AllOrNothingByBatch  (if any part of any member has an error, then all changes in the entire batch will be aborted)  
  
    ,@LogFlag                   BIT = NULL -- 1 = log the transaction  
    ,@ReturnCreatedMembers      BIT = 0  
    ,@ValidateDataTypes         BIT = 1 -- Do not set to 0 unless the attribute data types have been validated before calling this sproc. Otherwise, unhandled conversion errors may be thrown.  
    ,@DoInheritanceRuleCheck    BIT = NULL -- Only set to 1 from C#  
  
    ,@ChangesetName             NVARCHAR(250) = NULL  
    ,@ChangesetMuid             UNIQUEIDENTIFIER = NULL  
    ,@Approved                  BIT = 0 -- Called by udpEntityMemberChangesetSave  
  
    ,@ErrorReportingType        TINYINT = 1 -- A flag (values can be combined) that indicates how the sproc should report any errors  
                                            -- 0 = Errors are not reported back to the caller  
                                            -- 1 = Return errors in result set  
                                            -- 2 = Add errors to the XML out param.  
                                            -- 4 = Raise the first error found (results in the whole batch being rolled back)  
    ,@Errors                    XML = NULL OUTPUT -- @ErrorReportingType indicates whether this param should be filled with any errors found.  
  
    ,@Debug                     BIT = 0 -- Set to 1 to facilitate troubleshooting this sproc. Causes various print statements to provide info about the internal sproc execution steps.  
    ,@CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'udpEntityMembersSave started.'  
  
    DECLARE  
        -- Looked up from tblEntity  
         @MemberTableName               SYSNAME -- E.g. "tbl_7_31_[EN|HP|CN]". The name of the table in which this sproc call will add/update members.  
        ,@MemberViewName                SYSNAME -- E.g. "viw_SYSTEM_7_31_[CHILD|COLLECTION|PARENT]ATTRIBUTES". The name of the view corresponding to the member table.  
        ,@MemberAnnotationTableName     SYSNAME  
        ,@EntityTableName               SYSNAME -- E.g. "tbl_7_31_EN". Contains Leaf members.  
        ,@HierarchyParentTableName      SYSNAME -- E.g. "tbl_7_31_HP". Contains Consolidated members.  
        ,@CollectionTableName           SYSNAME -- E.g. "tbl_7_31_CN". Contains Collection members.  
        ,@HierarchyTableName            SYSNAME -- E.g. "tbl_7_31_HR"  
        ,@SecurityTableName             SYSNAME -- E.g. "tbl_7_31_EN_MS"  
        ,@PendingTableName              SYSNAME -- E.g. "tbl_7_31_EN_PD"  
        ,@ChangesetTableName            SYSNAME -- E.g. "tbl_7_CS"  
        ,@ChangesetStatus               TINYINT  
        ,@GetMemeberHistoryOutputQuery  NVARCHAR(MAX)  
        ,@IsCollectionEnabled           BIT  
        ,@IsHierarchyEnabled            BIT  
        ,@DataCompression               TINYINT  
        ,@RequireApproval               BIT  
        ,@Changeset_ID                  INT = NULL  
  
        ,@HasDba                        BIT  
        ,@HasFile                       BIT  
  
        -- Looked up from tblAttribute (Code and Name attribute metadata)  
        ,@AttributeName_Code            NVARCHAR(100)  
        ,@AttributeName_Name            NVARCHAR(100)  
        ,@AttributeName_MUID            NVARCHAR(100)  
        ,@AttributeMUID_Code            UNIQUEIDENTIFIER  
        ,@AttributeMUID_Name            UNIQUEIDENTIFIER  
        ,@AttributeMUID_MUID            UNIQUEIDENTIFIER  
        ,@AttributeID_Code              INT  
        ,@AttributeID_Name              INT  
        ,@AttributeMaxLength_Code       INT  
        ,@AttributeMaxLength_Name       INT  
  
        --Member Types  
        ,@MemberType_Unknown            TINYINT = 0  
        ,@MemberType_Leaf               TINYINT = 1  
        ,@MemberType_Consolidated       TINYINT = 2  
        ,@MemberType_Collection         TINYINT = 3  
        ,@MemberType_Hierarchy          TINYINT = 4  
  
        --Member status  
        ,@MemberStatus_Active           TINYINT = 1  
        ,@MemberStatus_Inactive         TINYINT = 2  
  
        ,@VersionStatus                 TINYINT  
        ,@VersionStatus_NotSpecified    TINYINT = 0  
        ,@VersionStatus_Open            TINYINT = 1  
        ,@VersionStatus_Locked          TINYINT = 2  
        ,@VersionStatus_Committed       TINYINT = 3  
  
        ,@TransactionLogType            TINYINT  
        ,@TransactionLogType_Attribute  TINYINT = 1  
        ,@TransactionLogType_Member     TINYINT = 2  
        ,@TransactionLogType_None       TINYINT = 3  
  
        ,@HistoryTableName              SYSNAME  
        ,@MemberIDColumn                SYSNAME  
  
        --Error ObjectTypes  
        ,@ObjectType_MemberCode         TINYINT = 12  
        ,@ObjectType_MemberId           TINYINT = 19  
        ,@ObjectType_MemberAttribute    TINYINT = 22  
  
        ,@ChangesetStatus_Open          TINYINT = 1  
        ,@ChangesetStatus_Rejected      TINYINT = 4  
        --Error Codes  
        ,@ErrorCode_FailedDueToAllOrNothingErrorPropagation     INT = -1 -- This error type is for internal use only. It should not be reported back to the user. It flags rows that should be ignored (not used to update master data tables) because it pertains to a member that had an error somewhere, and the @TransactionBehavior is AllOrNothingByMember.  
        ,@ErrorCode_ReservedWord                                INT = 110006  
        ,@ErrorCode_IdNotValid                                  INT = 110007  
        ,@ErrorCode_IdAlreadyExists                             INT = 110008  
        ,@ErrorCode_AttributeValueLengthGreaterThanMaximum      INT = 110017  
        ,@ErrorCode_NoPermissionForThisOperation                INT = 120002  
        ,@ErrorCode_NoPermissionForThisOperationOnThisObject    INT = 120003  
        ,@ErrorCode_InvalidMemberCode                           INT = 300002  
        ,@ErrorCode_MemberCodeExists                            INT = 300003  
        ,@ErrorCode_InvalidAttribute                            INT = 300010  
        ,@ErrorCode_ReadOnlyAttribute                           INT = 300014  
        ,@ErrorCode_DuplicateInputMemberCodes                   INT = 300019  
        ,@ErrorCode_MemberCausesCircularReference               INT = 300020  
        ,@ErrorCode_MemberMergeConflict                         INT = 300021  
        ,@ErrorCode_AttributeMergeConflict                      INT = 300022  
        ,@ErrorCode_InvalidBlankMemberCode                      INT = 310022  
        ,@ErrorCode_InvalidAttributeValueForDataType            INT = 310033  
        ,@ErrorCode_InvalidAttributeValueForMember              INT = 310042  
        ,@ErrorCode_AttributeValueNotCompatibleWithFilter       INT = 310055  
        ,@ErrorCode_PossiblyImpactedByIncompatibleFilteredValue INT = 310056  
  
        -- Error reporting types  
        ,@ErrorReportingType_None           TINYINT = 0 -- Errors are not reported back to the caller  
        ,@ErrorReportingType_Return         TINYINT = 1 -- Return errors in result set  
        ,@ErrorReportingType_Xml            TINYINT = 2 -- Add errors to the XML out param.  
        ,@ErrorReportingType_Raise          TINYINT = 4 -- Raise the first error found, rolling back the entire batch  
  
        ,@PrincipalType_User                TINYINT = 1  
  
        ,@SecurityRoleID                    INT  
  
        ,@MemberSecurity                    INT = 0  
  
        --Permission  
        ,@ModelPermission                   INT  
        ,@MemberTypePermission              INT = NULL  
        ,@Permission_None                   INT = 0  
        ,@Permission_Deny                   INT = 1  
        ,@Permission_Access                 INT = 4  
        ,@Permission_Admin                  INT = 5  
        ,@Permission_Inferred               INT = 99  
  
        ,@MemberTypeAccessPermission        TINYINT = NULL  
        ,@AccessPermission_None             TINYINT = 0  
        ,@AccessPermission_Read             TINYINT = 0  
        ,@AccessPermission_Create           TINYINT = 1  
        ,@AccessPermission_Update           TINYINT = 2  
        ,@AccessPermission_All              TINYINT = 7  
        ,@AccessPermission_CreateUpdate     TINYINT = 3  
  
        --Validation Statuses  
        ,@ValidationStatus_Succeeded                            INT = 3  
        ,@ValidationStatus_AwaitingRevalidation                 INT = 4  
        ,@ValidationStatus_AwaitingDependentMemberRevalidation  INT = 5  
        ,@ValidationStatus                                      INT = NULL  
  
        --Transaction type  
        ,@TransactionType_Create                INT = 1  
        ,@TransactionType_Update                INT = 3  
        ,@TransactionType_HierarchyParentSet    INT = 4  
  
        -- Save mode  
        ,@SaveMode_NotSpecified         TINYINT = 0  
        ,@SaveMode_Create               TINYINT = 1  
        ,@SaveMode_Merge                TINYINT = 2  
        ,@SaveMode_Update               TINYINT = 3  
  
        -- Transaction behavior  
        ,@TransactionBehavior_BestEffort            TINYINT = 0 -- Apply all possible member changes. For example, user tries to create a member and set one of its attributes to an invalid value. The member will be created, but the attribute will be left blank.  
        ,@TransactionBehavior_AllOrNothingByMember  TINYINT = 1 -- If any of the given member changes has an error, ignore all changes for that member. For example, user tries to create a member and set one of its attributes to an invalid value. The member will not be created.  
        ,@TransactionBehavior_AllOrNothingByBatch   TINYINT = 2 -- If any of the given member changes has an error, ignore all changes to all members (not just those with errors) in this batch. I.e, abort the whole batch if any errors are found.  
  
        --Attribute Types  
        ,@AttributeType_NotSpecified    TINYINT = 0  
        ,@AttributeType_FreeForm        TINYINT = 1  
        ,@AttributeType_DBA             TINYINT = 2  
        ,@AttributeType_File            TINYINT = 4  
  
        --Attribute DataTypes  
        ,@AttributeDataType_NotSpecified    TINYINT = 0  
        ,@AttributeDataType_Text            TINYINT = 1  
        ,@AttributeDataType_Number          TINYINT = 2  
        ,@AttributeDataType_DateTime        TINYINT = 3  
        ,@AttributeDataType_Link            TINYINT = 6  
  
        --Special values that input attribute NULL values get mapped to.  
        ,@SysNull_Text          NVARCHAR(1) = NCHAR(0)  
        ,@SysNull_ForeignKey    INT = 0  
        ,@SysNull_Number        DECIMAL(38,0) = -98765432101234567890  
        ,@SysNull_DateTime      DATETIME2(3) = CAST(N'5555-11-22T12:34:56' AS DATETIME2(3))  
  
        --Table column SQL snippets  
        ,@AttributeIdList               NVARCHAR(MAX) = N''-- a comma-delimited list of int attribute IDs, each wrapped in square brackets (needed for pivot)  
        ,@AttributeIdListWithDBACode    NVARCHAR(MAX) = N''-- same as @AttributeIdList, but with an extra domain member Code column for each DBA  
        ,@AttributeValueMappedAsColumns NVARCHAR(MAX) = N''  
        ,@TableColumnsUnPivotDefn       NVARCHAR(MAX) = N''  
        ,@ViewColumnsUnPivotDefn        NVARCHAR(MAX) = N''  
        ,@TableColumnsUpdateDefn        NVARCHAR(MAX) = N''  
        ,@TableColumnsUpdateDbaIdsDefn  NVARCHAR(MAX) = N''  
  
        --A flag indicating whether this entity supports auto code generation for Leaf members.  
        ,@CodeGenEnabled                BIT = 0  
  
        ,@SQL                           NVARCHAR(MAX)  
  
        -- This pseudo-constant is for use in string concatenation operations to prevent string truncation. When concatenating two or more strings,  
        -- if none of the strings is an NVARCHAR(MAX) or an NVARCHAR constant that is longer than 4,000 characters, then the resulting string  
        -- will be silently truncated to 4,000 characters. Concatenating wPrivilege_IDith this empty NVARCHAR(MAX), is sufficient to prevent truncation.  
        -- See http://connect.microsoft.com/SQLServer/feedback/details/283368/nvarchar-max-concatenation-yields-silent-truncation.  
        ,@TruncationGuard            NVARCHAR(MAX) = N''  
  
        ,@ValidationLogTableName            SYSNAME  
        ,@TransactionTableName              SYSNAME  
        ,@TransactionAnnotationTableName    SYSNAME  
  
  
        ,@GuidEmpty                     UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER)  
        ;  
  
    DECLARE @MemberPermissions AS TABLE (ID INT PRIMARY KEY, MemberType_ID INT, Privilege_ID INT, AccessPermission TINYINT);  
  
    -- Replace null param values with defaults.  
    SET @SaveMode = COALESCE(@SaveMode, @SaveMode_NotSpecified);  
    SET @ValidateDataTypes = COALESCE(@ValidateDataTypes, 0);  
    SET @TransactionBehavior = COALESCE(@TransactionBehavior, @TransactionBehavior_BestEffort);  
    SET @ErrorReportingType = COALESCE(@ErrorReportingType, @ErrorReportingType_None);  
    SET @LogFlag = COALESCE(@LogFlag, 0);  
    SET @Errors = NULL;  
  
    -- Validate save mode.  
    IF @SaveMode NOT IN (@SaveMode_Create, @SaveMode_Merge, @SaveMode_Update)  
    BEGIN  
        RAISERROR('MDSERR100010|The Parameters are not valid.', 16, 1);  
        RETURN;  
    END;  
  
    -- Validate model, entity, version request IDs and member type  
    SET @ModelName  = NULLIF(@ModelName, N'');  
    SET @EntityName = NULLIF(@EntityName, N'');  
    SET @VersionName = NULLIF(@VersionName, N'');  
    SET @ChangesetName = NULLIF(@ChangesetName, N'');  
    SET @ModelMuid = NULLIF(@ModelMuid, @GuidEmpty);  
    SET @EntityMuid = NULLIF(@EntityMuid, @GuidEmpty);  
    SET @VersionMuid = NULLIF(@VersionMuid, @GuidEmpty);  
    SET @ChangesetMuid = NULLIF(@ChangesetMuid, @GuidEmpty);  
    SET @Model_ID = NULLIF(@Model_ID, 0);  
    SET @Entity_ID = NULLIF(@Entity_ID, 0);  
    SET @Version_ID = NULLIF(@Version_ID, 0);  
    SET @MemberType_ID = COALESCE(@MemberType_ID, @MemberType_Unknown);  
  
    DECLARE @LocalModelID INT = NULL;-- used to determine if the model exists  
  
    -- Validate @Model_ID and the user's permission to see the model.  
    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Validate model.'  
    SELECT  
         @LocalModelID = m.ID  
        ,@ModelName = m.Name  
        ,@ModelMuid = m.MUID  
        ,@ModelPermission = s.Privilege_ID  
    FROM mdm.tblModel m  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_MODEL s  
    ON      m.ID = s.ID  
        AND ISNULL(s.Privilege_ID, @Permission_Deny) <> @Permission_Deny  
        AND s.User_ID = @User_ID  
    WHERE  
            (@ModelMuid IS NOT NULL OR @ModelName IS NOT NULL OR @Model_ID IS NOT NULL) -- At least one Identifier param must be provided.  
        AND (@ModelMuid IS NULL OR @ModelMuid = m.MUID)  
        AND (@ModelName IS NULL OR @ModelName = m.Name)  
        AND (@Model_ID  IS NULL OR @Model_ID  = m.ID)  
  
    IF @LocalModelID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300005|The supplied model is not valid.', 16, 1);  
        RETURN;  
    END  
    ELSE  
    BEGIN  
        SELECT @Model_ID = @LocalModelID;  
    END;  
  
    SET @ValidationLogTableName = mdm.udfGetValidationLogTableName(@Model_ID);  
  
    -- Validate @Version_ID  
    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Validate version.'  
    SELECT  
         @Version_ID = ID  
        ,@VersionName = Name  
        ,@VersionMuid = MUID  
        ,@VersionStatus = Status_ID  
    FROM mdm.tblModelVersion  
    WHERE  
        (@VersionMuid IS NOT NULL OR @VersionName IS NOT NULL OR @Version_ID IS NOT NULL) -- At least one Identifier param must be provided.  
    AND (@VersionMuid IS NULL OR @VersionMuid = MUID)  
    AND (@VersionName IS NULL OR @VersionName = Name)  
    AND (@Version_ID  IS NULL OR @Version_ID  = ID)  
    AND Model_ID = @Model_ID  
    IF @Version_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300006|The supplied version is not valid.', 16, 1);  
        RETURN;  
    END;  
    SET @VersionStatus = COALESCE(@VersionStatus, @VersionStatus_NotSpecified);  
  
    IF @VersionStatus = @VersionStatus_Committed  
        OR (@VersionStatus = @VersionStatus_Locked AND @ModelPermission <> @Permission_Admin)  
    BEGIN  
        RAISERROR(N'MDSERR300012|The version is read-only. You do not have permission to update the version.', 16, 1);  
        RETURN;  
    END;  
  
    -- Lookup @Entity_ID and related info, validating that it exists and (if applicable) that the user has permissions to see it.  
    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Validate entity.'  
    SELECT  
         @Entity_ID = e.ID  
        ,@EntityName = e.Name  
        ,@EntityMuid = e.MUID  
        ,@EntityTableName = e.EntityTable  
        ,@PendingTableName = CAST(e.EntityTable + '_PD' AS SYSNAME)  
        ,@HierarchyTableName = e.HierarchyTable  
        ,@HierarchyParentTableName = e.HierarchyParentTable  
        ,@CollectionTableName = e.CollectionTable  
        ,@DataCompression = e.DataCompression  
        ,@RequireApproval = RequireApproval  
        ,@TransactionLogType = CASE @LogFlag WHEN 1 THEN TransactionLogType ELSE @TransactionLogType_None END  
        ,@HistoryTableName =  
            CASE TransactionLogType  
                WHEN @TransactionLogType_Member THEN  
                    CASE @MemberType_ID  
                        WHEN @MemberType_Leaf THEN e.EntityTable  
                        WHEN @MemberType_Consolidated THEN e.HierarchyParentTable  
                        WHEN @MemberType_Collection THEN e.CollectionTable  
                    END + N'_HS'  
                ELSE NULL  
            END  
    FROM mdm.tblEntity e  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ENTITY s  
    ON      e.ID = s.ID  
        AND ISNULL(s.Privilege_ID, @Permission_Deny) <> @Permission_Deny  
        AND s.User_ID = @User_ID  
    WHERE  
            (@EntityMuid IS NOT NULL OR @EntityName IS NOT NULL OR @Entity_ID IS NOT NULL) -- At least one Identifier param must be provided.  
        AND (@EntityMuid IS NULL OR @EntityMuid = e.MUID)  
        AND (@EntityName IS NULL OR @EntityName = e.Name)  
        AND (@Entity_ID  IS NULL OR @Entity_ID  = e.ID)  
        AND e.Model_ID = @Model_ID;  
  
    SET @MemberIDColumn =  
        CASE @MemberType_ID  
            WHEN @MemberType_Leaf THEN N'[EN_ID]'  
            WHEN @MemberType_Consolidated THEN N'[HP_ID]'  
            WHEN @MemberType_Collection THEN N'[CN_ID]'  
        END;  
  
    IF @EntityTableName IS NULL  
    BEGIN  
        RAISERROR('MDSERR300008|The supplied entity is not valid..', 16, 1);  
        RETURN;  
    END;  
  
    SET @ChangesetTableName = CONCAT(N'tbl_', @Model_ID, N'_CS');  
    IF @ChangesetName IS NOT NULL OR @ChangesetName IS NOT NULL  
    BEGIN  
        SET @SQL = CONCAT(N'  
                SELECT @Changeset_ID = ID, @ChangesetStatus = Status, @ChangesetMuid = MUID  
                FROM [mdm].', @ChangesetTableName, N'  
                WHERE Version_ID = @Version_ID  
                    AND Entity_ID = @Entity_ID  
                    AND EnterUserID = @User_ID  
                    AND (@ChangesetMuid IS NOT NULL OR @ChangesetName IS NOT NULL)  
                    AND (@ChangesetMuid IS NULL OR MUID = @ChangesetMuid)  
                    AND (@ChangesetName IS NULL OR Name = @ChangesetName)');  
        EXEC sp_executesql @SQL, N'@Version_ID INT, @Entity_ID INT, @User_ID INT, @ChangesetName NVARCHAR(250), @ChangesetMuid UNIQUEIDENTIFIER OUTPUT, @Changeset_ID INT OUTPUT, @ChangesetStatus TINYINT OUTPUT',  
                @Version_ID, @Entity_ID, @User_ID, @ChangesetName, @ChangesetMuid OUTPUT, @Changeset_ID OUTPUT, @ChangesetStatus OUTPUT;  
  
        IF @Changeset_ID IS NULL OR @ChangesetStatus NOT IN (@ChangesetStatus_Open, @ChangesetStatus_Rejected)  
        BEGIN  
            RAISERROR(N'MDSERR300028|The changeset id is invalid or you don''t have the permission to update pending changes of this changeset.', 16, 1);  
            RETURN;  
        END  
  
        IF @ChangesetStatus = @ChangesetStatus_Rejected  
        BEGIN  
            EXEC mdm.udpEntityMemberChangesetSave  
                @User_ID = @User_ID,  
                @Model_Name = @ModelName,  
                @Model_MUID = @ModelMuid,  
                @Entity_Name = @EntityName,  
                @Entity_MUID = @EntityMuid,  
                @Version_Name = @VersionName,  
                @Version_MUID = @VersionMuid,  
                @ChangesetMUID = @ChangesetMuid,  
                @ChangesetStatus = @ChangesetStatus_Open;  
        END  
    END  
  
    IF @RequireApproval = 1 AND @MemberType_ID = @MemberType_Leaf AND @Approved = 0 AND @Changeset_ID IS NULL  
    BEGIN  
        RAISERROR(N'MDSERR300023|The entity requires approval for leaf member changes.', 16, 1);  
        RETURN;  
    END;  
  
    -- Verify the entity version is not a sync target.  
    IF EXISTS(SELECT 1 FROM mdm.tblSyncRelationship   
              WHERE TargetEntity_ID = @Entity_ID  
                AND TargetVersion_ID = @Version_ID)  
    BEGIN  
        RAISERROR('MDSERR200220|The entity member(s) cannot be saved. The entity version is the target of a sync relationship.', 16, 1);  
        RETURN;  
    END  
  
    SET @IsCollectionEnabled = CASE WHEN @CollectionTableName IS NULL THEN 0 ELSE 1 END;  
    SET @IsHierarchyEnabled  = CASE WHEN @HierarchyTableName  IS NULL THEN 0 ELSE 1 END;  
  
    IF @MemberType_ID = @MemberType_Collection  
        AND @IsCollectionEnabled = 0  
    BEGIN  
        DECLARE  
             @TableOptions NVARCHAR(MAX) = mdm.udfGetTableOptions(@DataCompression, @Model_ID)  
            ,@IndexOptions NVARCHAR(MAX) = mdm.udfGetIndexOptions(@DataCompression, @Model_ID);  
  
        EXEC mdm.udpCollectionTablesCreate @User_ID, @Model_ID, @Version_ID, @Entity_ID, @IsHierarchyEnabled, @TableOptions, @IndexOptions, @CollectionTableName OUTPUT;  
        SET @IsCollectionEnabled = 1;  
    END;  
  
    -- Note: This sproc assumes that the caller has already verified that the user has functional area permission.  
  
    ----------------------------------------------------------------------------------------  
    -- Check member type security and version editability.  
    ----------------------------------------------------------------------------------------  
    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Check member type permission.'  
    -- Check the object permission on the Entity Member Type.  
    SELECT @MemberTypePermission = Privilege_ID,  
        @MemberTypeAccessPermission = AccessPermission  
    FROM mdm.viw_SYSTEM_SECURITY_USER_MEMBERTYPE  
    WHERE [User_ID] = @User_ID  
        AND [Entity_ID] = @Entity_ID  
        AND ID = @MemberType_Leaf;  
  
    SET @MemberTypePermission = COALESCE(@MemberTypePermission, @Permission_Deny);  
  
    IF @MemberTypePermission = @Permission_Deny   
    BEGIN  
        RAISERROR(N'MDSERR120002|The user does not have permission to perform this operation.', 16, 1);  
        RETURN;  
    END;  
  
    -- Get the name of the member table to which the new members will be added.  
    SET @MemberTableName = CASE @MemberType_ID  
        WHEN @MemberType_Leaf           THEN @EntityTableName  
        WHEN @MemberType_Collection     THEN @CollectionTableName  
        END;  
      
    SET @MemberViewName = mdm.udfViewNameGet(@Model_ID, @Entity_ID, @MemberType_ID, 0, 0);  
  
    SET @SecurityTableName =  
        CASE @MemberType_ID  
            WHEN @MemberType_Leaf THEN CONCAT(N'tbl_', @Model_ID, N'_', @Entity_ID ,N'_EN_MS')  
        END;  
  
    IF @TransactionLogType = @TransactionLogType_Member  
    BEGIN  
        SET @MemberAnnotationTableName = CONCAT(@MemberTableName, N'_AN');  
        SET @GetMemeberHistoryOutputQuery = mdm.udfGetHistoryOutputQuery(@Entity_ID, @MemberType_ID, NULL, NULL);  
    END  
    ELSE IF @TransactionLogType = @TransactionLogType_Attribute  
    BEGIN  
        SET @TransactionTableName = mdm.udfGetTransactionTableName(@Model_ID);  
        SET @TransactionAnnotationTableName = mdm.udfGetTransactionAnnotationTableName(@Model_ID);  
    END;  
  
    --Figure out whether code generation is enabled  
    DECLARE @result INT;  
    EXEC @result = mdm.udpIsCodeGenEnabled @Entity_ID;  
    SET @CodeGenEnabled = CONVERT(BIT, @result);  
  
    ----------------------------------------------------------------------------------------  
    -- Create working set temporary tables  
    --  Note that these are temp tables rather than table vars because  
    --  1. They will be referenced in dynamic SQL, and  
    --  2. Table vars are too limited with respect to how they can be indexed.  
    ----------------------------------------------------------------------------------------  
    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Create working sets.'  
    -- Create working set temp table for new members.  
    CREATE TABLE #MembersWorkingSet  
    (  
         Row_ID                 INT PRIMARY KEY CLUSTERED  
        ,MemberCode             NVARCHAR(251) COLLATE DATABASE_DEFAULT NULL -- Can't use NVARCHAR(MAX) for an indexed column, but need something longer than the max code length (250) to detect codes that are too long)  
        ,MemberName             NVARCHAR(MAX) COLLATE DATABASE_DEFAULT NULL  
        ,MemberMUID             UNIQUEIDENTIFIER NULL  
        ,MemberID               INT NULL  
        ,TransactionAnnotation  NVARCHAR(500) COLLATE DATABASE_DEFAULT NULL  
        ,RevisionID             BIGINT NULL  
        ,ErrorAttributeMUID     UNIQUEIDENTIFIER NULL  
        ,ErrorAttributeName     NVARCHAR(100) COLLATE DATABASE_DEFAULT NULL  
        ,ErrorCode              INT NULL  
        ,ErrorParameters        NVARCHAR(MAX) NULL -- optionally add here any error message format string parameters, delimited by '|'  
        ,ErrorObjectType        TINYINT NULL  
        ,IsNewMember            BIT DEFAULT(0)  
    );  
    CREATE INDEX #ix_NewMemberWorkingSet_MemberID_MemberMUID_MemberCode_ErrorCode ON #MembersWorkingSet(MemberID, MemberMUID, MemberCode, ErrorCode);  
    CREATE INDEX #ix_NewMemberWorkingSet_IsNewMember ON #MembersWorkingSet(IsNewMember);  
  
    -- Create working set temp table for attribute value changes.  
    CREATE TABLE #MemberAttributeWorkingSet  
    (  
         Row_ID                 INT IDENTITY(1,1) PRIMARY KEY NOT NULL  
        ,MemberRowID            INT  
        ,AttributeID            INT NULL  
        ,AttributeValue         NVARCHAR(MAX) COLLATE DATABASE_DEFAULT NULL  
        ,AttributeValueMapped   NVARCHAR(MAX) COLLATE DATABASE_DEFAULT NULL -- The final value that gets written to the member table. For DBA's, set to the INT ID of the domain entity member.  
        ,PriorValue             NVARCHAR(MAX) COLLATE DATABASE_DEFAULT NULL  
        ,PriorValueMapped       NVARCHAR(MAX) COLLATE DATABASE_DEFAULT NULL  
        ,PriorFileId            NVARCHAR(MAX) COLLATE DATABASE_DEFAULT NULL  
        ,IsChanged              BIT NULL  
        ,ChangeTrackingMask     INT NULL DEFAULT 0  
        ,TransactionAnnotation  NVARCHAR(500) COLLATE DATABASE_DEFAULT NULL  
        ,ErrorCode              INT NULL  
        ,ErrorParameters        NVARCHAR(MAX) NULL -- optionally add here any error message format string parameters, delimited by '|'  
        ,ErrorObjectType        TINYINT NULL -- This will usually be Attribute, but could occasionally be something different, like MemberCode  
    );  
    CREATE INDEX #ix_MemberAttributeWorkingSet_MemberRowID_AttributeID_ErrorCode ON #MemberAttributeWorkingSet(MemberRowID, AttributeID, ErrorCode);  
  
    -- Store attribute definitions for attributes being updated.  
    CREATE TABLE #AttributeDefinition  
    (  
         AttributeID                    INT PRIMARY KEY  
        ,AttributeMUID                  UNIQUEIDENTIFIER  
        ,IsSystem                       BIT  
        ,AttributeName                  NVARCHAR(100) COLLATE DATABASE_DEFAULT NULL  
        ,AttributeType_ID               TINYINT NULL  
        ,DataType_ID                    TINYINT NULL  
        ,DataTypeInformation            INT NULL  
        ,Dba_Entity_ID                  INT NULL  
        ,Dba_Entity_Table_Name          SYSNAME COLLATE DATABASE_DEFAULT NULL  
        ,ChangeTrackingGroup_ID         INT NULL  
        ,TableColumn                    SYSNAME COLLATE DATABASE_DEFAULT NULL  
        ,TableColumnUnPivotDefn         NVARCHAR(MAX) COLLATE DATABASE_DEFAULT NULL  
        ,TableColumnUpdateDefn          NVARCHAR(MAX) COLLATE DATABASE_DEFAULT NULL  
        ,TableColumnUpdateDbaIdsDefn    NVARCHAR(MAX) COLLATE DATABASE_DEFAULT NULL  
    );  
    CREATE NONCLUSTERED INDEX #ix_AttributeDefinition_AttributeName ON #AttributeDefinition(AttributeName);  
    CREATE NONCLUSTERED INDEX #ix_AttributeDefinition_AttributeType_ID ON #AttributeDefinition(AttributeType_ID);  
    CREATE NONCLUSTERED INDEX #ix_AttributeDefinition_DataType_ID ON #AttributeDefinition(DataType_ID);  
  
    ----------------------------------------------------------------------------------------  
    -- Copy the new member data from the param to the working set.  
    ----------------------------------------------------------------------------------------  
    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Load #MembersWorkingSet.'  
    INSERT INTO #MembersWorkingSet  
    (  
         Row_ID  
        ,MemberCode  
        ,MemberName  
        ,MemberMUID  
        ,TransactionAnnotation  
        ,RevisionID  
    )  
    SELECT  
         RowID  
        ,NULLIF(MemberCode, N'')  
        ,MemberName  
        ,NULLIF(MemberMUID, @GuidEmpty) -- Note: Do not generate a MUID here if one is not provided. The MUID will be looked up for existing members. For new members, a new MUID will be generated right before adding the members to the member table.  
        ,NULLIF(LTRIM(RTRIM(TransactionAnnotation)), N'')  
        ,NULLIF(RevisionID, 0)  
    FROM @Members;  
  
    ----------------------------------------------------------------------------------------  
    -- Copy the member attribute data from the param to the working set.  
    ----------------------------------------------------------------------------------------  
    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Load #MemberAttributeWorkingSet.'  
    INSERT INTO #MemberAttributeWorkingSet  
    (  
         MemberRowID  
        ,AttributeID  
        ,AttributeValue  
        ,AttributeValueMapped  
        ,TransactionAnnotation  
        ,IsChanged  
    )  
    SELECT  
         MemberRowID  
        ,AttributeID  
        ,AttributeValue  
        ,AttributeValue  
        ,NULLIF(LTRIM(RTRIM(TransactionAnnotation)), N'')  
        ,CASE @SaveMode WHEN @SaveMode_Create THEN 1 ELSE NULL END -- IsChanged is always true when creating new members.  
    FROM @MemberAttributes a  
  
    -----------------------------------------------------------------------------------------------  
    -- Add errors for attribute rows that do not reference a row in the members working set.  
    -----------------------------------------------------------------------------------------------  
    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Add errors for attribute rows that do not reference a row in the members working set.'  
    UPDATE aws  
    SET  ErrorCode = @ErrorCode_IdNotValid  
        ,ErrorObjectType = @ObjectType_MemberId  
    FROM #MemberAttributeWorkingSet aws  
    LEFT JOIN #MembersWorkingSet mws  
    ON aws.MemberRowID = mws.Row_ID  
    WHERE mws.Row_ID IS NULL  
  
    ----------------------------------------------------------------------------------------  
    --Get Code, Name, and MUID attribute metadata.  
    ----------------------------------------------------------------------------------------  
    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Get Code, Name, and MUID attribute metadata.'  
    SELECT  
         @AttributeName_Code = Name  
        ,@AttributeMUID_Code = MUID  
        ,@AttributeID_Code = ID  
        ,@AttributeMaxLength_Code = DataTypeInformation  
    FROM mdm.tblAttribute  
    WHERE   [Entity_ID] = @Entity_ID  
        AND MemberType_ID = @MemberType_ID  
        AND IsCode = 1;  
  
    SELECT  
         @AttributeName_Name = Name  
        ,@AttributeMUID_Name = MUID  
        ,@AttributeID_Name = ID  
        ,@AttributeMaxLength_Name = DataTypeInformation  
    FROM mdm.tblAttribute  
    WHERE   [Entity_ID] = @Entity_ID  
        AND MemberType_ID = @MemberType_ID  
        AND IsName = 1;  
  
    SELECT  
         @AttributeName_MUID = Name  
        ,@AttributeMUID_MUID = MUID  
    FROM mdm.tblAttribute a  
    WHERE   [Entity_ID] = @Entity_ID  
        AND MemberType_ID = @MemberType_ID  
        AND Name = N'MUID'  
        AND IsSystem = 1;  
  
    -- Lookup IDs of existing active members.  
    IF @SaveMode IN (@SaveMode_Update, @SaveMode_Merge)-- In create mode, don't bother looking in the member table for pre-existing members. This check will be done later (on all member tables) to ensure new member Code and MUID uniqueness.  
    BEGIN  
        -- !!!The following queries (to load existing members based on codes and MUID) have been separated on purpose.  
        --Combining the two results in significantly worse performance!!!  
  
        IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Lookup pre-existing member MUIDs and IDs from the member table based on input codes'  
        SET @SQL = CONCAT(@TruncationGuard, N'  
            UPDATE ws  
            SET  ws.MemberID   = m.ID  
                ,ws.MemberCode = m.Code  
                ,ws.MemberMUID = m.MUID  
                ,ws.MemberName = m.Name  
            FROM #MembersWorkingSet ws  
            INNER JOIN mdm.', @MemberTableName, N' m  
            ON      m.Version_ID = @Version_ID  
                AND ws.MemberCode = m.Code  
                AND m.Status_ID = ', @MemberStatus_Active, N' -- include only active members (i.e. do not include soft deleted members). DO NOT replace this hardcoded number with a var. It would be bad for perf.  
            WHERE   ws.ErrorCode IS NULL  
                AND ws.MemberCode IS NOT NULL --We are only looking for members that have MemberCode set up  
        ');  
        --IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT @SQL  
        EXEC sp_executesql @SQL, N'@Version_ID INT', @Version_ID  
  
        IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Lookup pre-existing member MUIDs and IDs from the member table based on input MUIDs'  
        SET @SQL = CONCAT(@TruncationGuard, N'  
            UPDATE ws  
            SET  ws.MemberID   = m.ID  
                ,ws.MemberCode = m.Code  
                ,ws.MemberMUID = m.MUID  
                ,ws.MemberName = m.Name  
            FROM #MembersWorkingSet ws  
            INNER JOIN mdm.', @MemberTableName, N' m  
            ON      m.Version_ID = @Version_ID  
                AND ws.MemberMUID = m.MUID  
            WHERE   ws.ErrorCode IS NULL  
                AND ws.MemberID IS NULL --Only look for members that have not already been looked up  
                AND ws.MemberMUID IS NOT NULL --We are only looking for members that have MUID set up  
                AND m.Status_ID = ', @MemberStatus_Active, N'; -- include only active members (i.e. do not include soft deleted members). DO NOT replace this hardcoded number with a var. It would be bad for perf.  
        ');  
        --IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT @SQL  
        EXEC sp_executesql @SQL, N'@Version_ID INT', @Version_ID;  
  
        --IF it is for pending changes, set a dummy MemberID  
        IF @Changeset_ID IS NOT NULL  
        BEGIN  
            SET @SQL = CONCAT(N'  
                UPDATE ws  
                SET ws.MemberID   = 0,  
                    ws.MemberCode = m.Code,  
                    ws.MemberMUID = m.MUID,  
                    ws.MemberName = m.Name  
                FROM #MembersWorkingSet ws  
                INNER JOIN mdm.', @PendingTableName, N' m  
                ON ws.MemberMUID = m.MUID AND m.CS_ID = @Changeset_ID AND m.Version_ID = @Version_ID  
                WHERE ws.ErrorCode IS NULL  
                    AND ws.MemberID IS NULL --Only look for members that have not already been looked up  
                    AND ws.MemberMUID IS NOT NULL --We are only looking for members that have MUID set up  
                    AND m.Status_ID = ', @MemberStatus_Active, ';');  
            --IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT @SQL  
            EXEC sp_executesql @SQL, N'@Version_ID INT, @Changeset_ID INT', @Version_ID, @Changeset_ID;  
        END  
  
        -- Add an error if trying to update a member that doesn't exist.  
        IF @SaveMode = @SaveMode_Update  
        BEGIN  
            UPDATE #MembersWorkingSet  
            SET  ErrorCode = @ErrorCode_InvalidMemberCode  
                ,ErrorObjectType = @ObjectType_MemberAttribute  
                ,ErrorAttributeName = @AttributeName_Code  
                ,ErrorAttributeMUID = @AttributeMUID_Code  
            WHERE   MemberID IS NULL  
                AND ErrorCode IS NULL;  
        END;  
    END; -- Lookup existing members for Update and Merge.  
  
    ----------------------------------------------------------------------------------------  
    -- Check for missing MemberCode.  
    -- Blank MemberCodes are allowed only when creating (not merging) Leaf members on an  
    -- entity that is CodeGen-enabled.  
    ----------------------------------------------------------------------------------------  
    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Check for missing MemberCode.';  
    IF     @MemberType_ID <> @MemberType_Leaf  
        OR @CodeGenEnabled = 0  
        OR @SaveMode <> @SaveMode_Create -- In a Merge or Update operation all codes must be specified, even when the Entity is CodeGen enabled.  
    BEGIN  
        -- Add errors for all blank member codes.  
        UPDATE #MembersWorkingSet  
        SET  ErrorCode = @ErrorCode_InvalidBlankMemberCode  
            ,ErrorObjectType = @ObjectType_MemberAttribute  
            ,ErrorAttributeName = @AttributeName_Code  
            ,ErrorAttributeMUID = @AttributeMUID_Code  
        WHERE   MemberCode IS NULL  
            AND ErrorCode IS NULL;  
    END;  
  
    ----------------------------------------------------------------------------------------  
    -- Check for duplicate Code values in the working set.  
    ----------------------------------------------------------------------------------------  
    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Check for duplicate Code values in the working set.';  
    WITH duplicateCodes AS  
    (  
        SELECT MemberCode  
        FROM #MembersWorkingSet  
        WHERE   MemberCode IS NOT NULL  
            AND ErrorCode IS NULL  
        GROUP BY MemberCode  
        HAVING COUNT(*) > 1  
    )  
    UPDATE ws  
    SET  ErrorCode = @ErrorCode_DuplicateInputMemberCodes  
        ,ErrorObjectType = @ObjectType_MemberAttribute  
        ,ErrorAttributeName = @AttributeName_Code  
        ,ErrorAttributeMUID = @AttributeMUID_Code  
    FROM #MembersWorkingSet AS ws  
    INNER JOIN duplicateCodes AS dup  
    ON ws.MemberCode = dup.MemberCode  
    WHERE ws.ErrorCode IS NULL;  
  
    ----------------------------------------------------------------------------------------  
    -- Check for duplicate MUIDs in the working set.  
    ----------------------------------------------------------------------------------------  
    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Check for duplicate MUIDs in the working set.';  
    WITH duplicateMuids AS  
    (  
        SELECT MemberMUID  
        FROM #MembersWorkingSet  
        WHERE   ErrorCode IS NULL  
            AND MemberMUID IS NOT NULL  
        GROUP BY MemberMUID  
        HAVING COUNT(*) > 1  
    )  
    UPDATE ws  
    SET  ErrorCode = @ErrorCode_IdNotValid  
        ,ErrorObjectType = @ObjectType_MemberAttribute  
        ,ErrorAttributeName = @AttributeName_MUID  
        ,ErrorAttributeMUID = @AttributeMUID_MUID  
    FROM #MembersWorkingSet AS ws  
    INNER JOIN duplicateMuids AS dup  
    ON ws.MemberMUID = dup.MemberMUID  
    WHERE ws.ErrorCode IS NULL;  
  
    -- Create a SQL fragment that gets all pre-existing member ids.  
    DECLARE @ExistingCodesCteSQL NVARCHAR(MAX) = CONCAT(N'  
        ;WITH existingCodesCte AS  
        (  
            SELECT  
                 Code  
                ,MUID  
                ,Status_ID  
            FROM mdm.', @EntityTableName, N'  
            WHERE Version_ID = @Version_ID',  
            -- Only look at Consolidated and Collection tables if they exist  
            CASE WHEN @IsHierarchyEnabled = 1 THEN CONCAT(N'  
            UNION ALL -- deduplication not needed  
            SELECT  
                 Code  
                ,MUID  
                ,Status_ID  
            FROM mdm.', @HierarchyParentTableName, N'  
            WHERE Version_ID = @Version_ID') END +  
            CASE WHEN @IsCollectionEnabled = 1 THEN CONCAT(N'  
            UNION ALL -- deduplication not needed  
            SELECT  
                 Code  
                ,MUID  
                ,Status_ID  
            FROM mdm.', @CollectionTableName, N'  
            WHERE Version_ID = @Version_ID') END, N'  
        )');  
  
    IF @SaveMode IN (@SaveMode_Create, @SaveMode_Merge)  
    BEGIN  
        ----------------------------------------------------------------------------------------  
        -- Check for reserved words in the MemberCode.  
        ----------------------------------------------------------------------------------------  
        IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Check for reserved words in the MemberCode.';  
        UPDATE ws  
        SET  ErrorCode = @ErrorCode_ReservedWord  
            ,ErrorObjectType = @ObjectType_MemberAttribute  
            ,ErrorAttributeName = @AttributeName_Code  
            ,ErrorAttributeMUID = @AttributeMUID_Code  
        FROM #MembersWorkingSet ws  
        INNER JOIN mdm.udfItemReservedWordsGet(12/*Leaf member*/) rw  
        ON UPPER(ws.MemberCode) = UPPER(rw.ReservedWord)  
        WHERE   ws.MemberID IS NULL -- If the member ID is not null, then the member already exists (for a Merge operation) and can be skipped for this check.  
            AND ws.ErrorCode IS NULL;  
  
        ----------------------------------------------------------------------------------------  
        -- Check for Name and Code values that are too long.  
        ----------------------------------------------------------------------------------------  
        IF @ValidateDataTypes = 1  
        BEGIN  
            IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Check for Name and Code values that are too long.';  
            UPDATE #MembersWorkingSet  
            SET  ErrorCode = @ErrorCode_AttributeValueLengthGreaterThanMaximum  
                ,ErrorObjectType = @ObjectType_MemberAttribute  
                ,ErrorAttributeName = @AttributeName_Code  
                ,ErrorAttributeMUID = @AttributeMUID_Code  
            WHERE   ErrorCode IS NULL  
                AND MemberID IS NULL -- If the member ID is not null, then the member already exists (for a Merge operation) and can be skipped for this check.  
                AND ISNULL(LEN(MemberCode), 0) > @AttributeMaxLength_Code;  
  
            UPDATE #MembersWorkingSet  
            SET  ErrorCode = @ErrorCode_AttributeValueLengthGreaterThanMaximum  
                ,ErrorObjectType = @ObjectType_MemberAttribute  
                ,ErrorAttributeName = @AttributeName_Name  
                ,ErrorAttributeMUID = @AttributeMUID_Name  
            WHERE   ErrorCode IS NULL  
                AND MemberID IS NULL -- If the member ID is not null, then the member already exists (for a Merge operation) and can be skipped for this check.  
                AND ISNULL(LEN(MemberName), 0) > @AttributeMaxLength_Name;  
        END; -- Name and Code length  
  
        -- !!!The following checks (for duplicate MUIDs and codes) have been separated on purpose. Combining the two results in significantly worse performance!!!  
  
        ----------------------------------------------------------------------------------------  
        -- Ensure that new members' Codes don't conflict with existing members.  
        -- !!!This check has been separated from the MUID check on purpose. Combining the two results in significantly worse performance!!!  
        ----------------------------------------------------------------------------------------  
        IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Ensure that new members Codes don''t conflict with existing members.';  
        SET @SQL = CONCAT(@ExistingCodesCteSQL, N'  
            UPDATE ws  
            SET  ErrorCode = @ErrorCode_MemberCodeExists  
                ,ErrorObjectType = @ObjectType_MemberAttribute  
                ,ErrorAttributeName = @AttributeName_Code  
                ,ErrorAttributeMUID = @AttributeMUID_Code  
            FROM #MembersWorkingSet AS ws  
            INNER JOIN existingCodesCte c  
            ON      ws.MemberCode = c.Code  
                AND c.Status_ID = ', @MemberStatus_Active, N' -- include only active members (i.e. do not include soft deleted members). DO NOT replace this hardcoded number with a var. It would be bad for perf.  
            WHERE   ws.ErrorCode IS NULL  
                AND ws.MemberID IS NULL -- If the member ID is not null, then the member already exists (for a Merge operation) and can be skipped for this check.  
            ');  
  
        EXEC sp_executesql @SQL,  
            N'@Version_ID INT,  @ErrorCode_MemberCodeExists INT, @ErrorCode_IdAlreadyExists INT, @ObjectType_MemberAttribute INT, @ObjectType_MemberId INT, @AttributeName_Code NVARCHAR(100), @AttributeMUID_Code UNIQUEIDENTIFIER',  
              @Version_ID,       @ErrorCode_MemberCodeExists,     @ErrorCode_IdAlreadyExists,     @ObjectType_MemberAttribute,     @ObjectType_MemberId,     @AttributeName_Code,               @AttributeMUID_Code;  
  
        ----------------------------------------------------------------------------------------  
        -- Ensure that new members' MUIDs don't conflict with existing members.  
        -- !!!This check has been separated from the Code check on purpose. Combining the two results in significantly worse performance!!!  
        ----------------------------------------------------------------------------------------  
        IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Ensure that new members MUIDs don''t conflict with existing members.';  
        SET @SQL = @ExistingCodesCteSQL + N'  
            UPDATE ws  
            SET  ErrorCode = @ErrorCode_IdAlreadyExists  
                ,ErrorObjectType = @ObjectType_MemberId  
            FROM #MembersWorkingSet AS ws  
            INNER JOIN existingCodesCte c  
            ON     ws.MemberMUID = c.MUID  
            WHERE   ws.ErrorCode IS NULL  
                AND ws.MemberID IS NULL -- If the member ID is not null, then the member already exists (for a Merge operation) and can be skipped for this check.  
            ';  
  
        EXEC sp_executesql @SQL,  
            N'@Version_ID INT, @ErrorCode_MemberCodeExists INT, @ErrorCode_IdAlreadyExists INT, @ObjectType_MemberAttribute INT, @ObjectType_MemberId INT, @AttributeName_Code NVARCHAR(100), @AttributeMUID_Code UNIQUEIDENTIFIER',  
              @Version_ID,     @ErrorCode_MemberCodeExists,     @ErrorCode_IdAlreadyExists,     @ObjectType_MemberAttribute,     @ObjectType_MemberId,     @AttributeName_Code,               @AttributeMUID_Code;  
    END; -- Create or Merge  
  
    -----------------------------------------------------------------------------------------------  
    -- Delete attribute working set rows that pertain to new members that  
    -- have an error (Can't set the attributes of members that don't exist).  
    -----------------------------------------------------------------------------------------------  
    IF EXISTS(SELECT 1 FROM #MembersWorkingSet WHERE ErrorCode IS NOT NULL)  
    BEGIN  
        IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Delete attribute rows that pertain to members that have an error.';  
        DELETE aws  
        FROM #MemberAttributeWorkingSet aws  
        INNER JOIN #MembersWorkingSet nm  
        ON aws.MemberRowID = nm.Row_ID  
        WHERE nm.ErrorCode IS NOT NULL  
  
-- TODO: Also delete from the collections working set  
  
    END;  
  
    -----------------------------------------------------------------------------------------------  
    -- Process attribute value changes.  
    -----------------------------------------------------------------------------------------------  
  
    ----------------------------------------------------------------------------------------  
    -- Load SysNull Datatype mappings.    
    ----------------------------------------------------------------------------------------  
    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Load SysNull Datatype mappings.'  
    CREATE TABLE #SysNullDataTypeMap  
    (  
         AtributeType_ID    TINYINT NOT NULL  
        ,DataType_ID        TINYINT NOT NULL  
        ,SysNullName        NVARCHAR(20) COLLATE DATABASE_DEFAULT NOT NULL  
        ,SysNullValue       NVARCHAR(60) COLLATE DATABASE_DEFAULT NOT NULL  
    );  
    CREATE UNIQUE CLUSTERED INDEX #ix_SysNullDataTypeMap_AtributeType_ID_DataType_ID ON #SysNullDataTypeMap(AtributeType_ID, DataType_ID);  
    INSERT INTO #SysNullDataTypeMap  
        (AtributeType_ID,           DataType_ID,                    SysNullName,                SysNullValue)  
    VALUES  
         (@AttributeType_FreeForm,  @AttributeDataType_Text,        N'@SysNull_Text',           @SysNull_Text)  
        ,(@AttributeType_FreeForm,  @AttributeDataType_Number,      N'@SysNull_Number',         CONVERT(NVARCHAR(60), @SysNull_Number))  
        ,(@AttributeType_FreeForm,  @AttributeDataType_DateTime,    N'@SysNull_DateTime',       CONVERT(NVARCHAR(60), @SysNull_DateTime))  
        ,(@AttributeType_FreeForm,  @AttributeDataType_Link,        N'@SysNull_Text',           @SysNull_Text)  
        ,(@AttributeType_DBA,       @AttributeDataType_Text,        N'@SysNull_ForeignKey' ,    CONVERT(NVARCHAR(60), @SysNull_ForeignKey))  
        ,(@AttributeType_File,      @AttributeDataType_Link,        N'@SysNull_ForeignKey',     CONVERT(NVARCHAR(60), @SysNull_ForeignKey))  
    ;  
  
    ----------------------------------------------------------------------------------------  
    -- Get attribute definitions  
    ----------------------------------------------------------------------------------------  
    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Load #AttributeDefinition.';  
    ;WITH attributeIdCte AS -- Get all distinct attribute names.  
    (  
        SELECT DISTINCT  
            AttributeID  
        FROM #MemberAttributeWorkingSet  
        WHERE ErrorCode IS NULL  
    )  
    INSERT INTO #AttributeDefinition  
    (  
         AttributeID  
        ,AttributeMUID  
        ,IsSystem  
        ,AttributeName  
        ,AttributeType_ID  
        ,DataType_ID  
        ,DataTypeInformation  
        ,Dba_Entity_ID  
        ,Dba_Entity_Table_Name  
        ,ChangeTrackingGroup_ID  
        ,TableColumn  
        ,TableColumnUnPivotDefn  
        ,TableColumnUpdateDbaIdsDefn  
        ,TableColumnUpdateDefn  
    )  
    SELECT DISTINCT  
         att.ID  
        ,att.MUID  
        ,att.IsSystem  
        ,att.Name  
        ,att.AttributeType_ID  
        ,att.DataType_ID  
        ,att.DataTypeInformation  
        ,att.DomainEntity_ID  
        ,dbaEnt.EntityTable  
        ,att.ChangeTrackingGroup  
        ,att.TableColumn  
        ,  
        CASE  
            WHEN att.AttributeType_ID = @AttributeType_FreeForm AND att.DataType_ID = @AttributeDataType_DateTime  
            THEN N'CONVERT(NVARCHAR(MAX),' + QUOTENAME(att.TableColumn) + N', 126) AS ' + QUOTENAME(att.ID) -- Datetime is passed in as ISO8601  
            ELSE N'CONVERT(NVARCHAR(MAX),' + QUOTENAME(att.TableColumn) + N') AS ' + QUOTENAME(att.ID)  
        END -- TableColumnUnPivotDefn  
        ,CASE  
            WHEN att.AttributeType_ID = @AttributeType_DBA  
             THEN CONCAT(N'SELECT ID, Code, ', att.ID, N' AS AttributeID FROM mdm.', QUOTENAME(dbaEnt.EntityTable), N' WHERE Version_ID = @Version_ID AND Status_ID = 1')  
            ELSE N''  
         END -- TableColumnUpdateDbaIdsDefn  
        ,CASE  
            WHEN att.Name = N'Code'  
            THEN  
                CASE  
                    WHEN @Changeset_ID IS NULL THEN N'm.' + att.TableColumn + N'= ISNULL(updates.' + att.TableColumn + N',m.' + att.TableColumn + N')'  
                    ELSE CONCAT(N'm.', att.TableColumn, N' = CASE WHEN isChanged.', att.TableColumn, N' = 1 THEN updates.', att.TableColumn +N' ELSE NULL END')  
                END  
  
            --Special handling for Owner_ID on collection members because in tblAttribute this  
            --attribute is registered as text. However, the column itself is an int. If we don't  
            --add this handling, the ELSE logic will try and put SysNull_Text as the relevant null value. We  
            --don't care about null values because the user can't possibly supply a null value (there will always  
            --be at least one user on the application)  
            WHEN att.Name = N'Owner_ID' AND @MemberType_ID = @MemberType_Collection  
            THEN N'm.' + att.TableColumn + N'= ISNULL(updates.' + att.TableColumn + N',m.' + att.TableColumn + N')'  
  
            ELSE  
                CASE  
                    WHEN @Changeset_ID IS NULL THEN N'm.' + att.TableColumn + N' = NULLIF(ISNULL(updates.' + att.TableColumn + N', m.' + att.TableColumn + '),' + m.SysNullName + N')'  
                    ELSE CONCAT(N'm.', att.TableColumn, N' = CASE WHEN isChanged.', att.TableColumn, N' = 1 THEN CASE WHEN m.EN_ID IS NULL THEN NULLIF(updates.', att.TableColumn, N' ,', m.SysNullName, N') ELSE updates.', att.TableColumn, N' END ELSE NULL END')  
                END  
         END -- TableColumnUpdateDefn  
    FROM attributeIdCte AS ws  
    INNER JOIN mdm.tblAttribute att  
    ON      ws.AttributeID = att.ID  
    INNER JOIN #SysNullDataTypeMap m  
    ON      m.AtributeType_ID = att.AttributeType_ID  
        AND m.DataType_ID = att.DataType_ID  
    LEFT JOIN mdm.tblEntity dbaEnt  
    ON dbaEnt.ID = att.DomainEntity_ID;  
  
    --------------------------------------------------------------------------------------------------  
    -- Add errors for invalid attributes.  
    --------------------------------------------------------------------------------------------------  
    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Add errors for invalid attributes.'  
    UPDATE ws  
    SET ErrorCode = @ErrorCode_InvalidAttribute,  
        ErrorObjectType = @ObjectType_MemberAttribute  
    FROM #MemberAttributeWorkingSet ws  
    LEFT JOIN #AttributeDefinition att  
    ON ws.AttributeID = att.AttributeID  
    WHERE   att.AttributeMUID IS NULL  
        AND ws.ErrorCode IS NULL;  
  
    --------------------------------------------------------------------------------------------------  
    -- Check for duplicate member-attribute assignments. These are not allowed because they are ambiguous (i.e. which assignment wins?)  
    --------------------------------------------------------------------------------------------------  
    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Check for duplicate member-attribute assignments.';  
    WITH duplicateAttributes AS  
    (  
        SELECT  
             MemberRowID  
            ,AttributeID  
        FROM #MemberAttributeWorkingSet  
        WHERE ErrorCode IS NULL  
        GROUP BY MemberRowID, AttributeID  
        HAVING COUNT(*) > 1  
    )  
    UPDATE ws  
    SET  ErrorCode = @ErrorCode_InvalidAttributeValueForMember  
        ,ErrorObjectType = @ObjectType_MemberAttribute  
    FROM #MemberAttributeWorkingSet AS ws  
    INNER JOIN duplicateAttributes AS dup  
    ON      ws.MemberRowID = dup.MemberRowID  
        AND ws.AttributeID = dup.AttributeID  
    WHERE ws.ErrorCode IS NULL;  
  
    ----------------------------------------------------------------------------------------  
    --Check security  
    ----------------------------------------------------------------------------------------  
    IF @ModelPermission != @Permission_Admin  
    BEGIN  
        IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Lookup attribute permissions.'  
  
        DECLARE @AttributePermissions TABLE  
        (  
             AttributeID INT PRIMARY KEY  
            ,Privilege_ID TINYINT NOT NULL  
            ,AccessPermission TINYINT NOT NULL  
        )  
  
        ;WITH attributesCte AS  
        (  
            SELECT AttributeID  
            FROM #AttributeDefinition  
              
            UNION  
  
            -- Ensure Name and Code attributes are included  
            SELECT @AttributeID_Code  
            UNION   
            SELECT @AttributeID_Name  
        )  
        INSERT INTO @AttributePermissions  
        SELECT  
             a.AttributeID  
            ,COALESCE(sec.Privilege_ID, @Permission_Deny)  
            ,COALESCE(sec.AccessPermission, @AccessPermission_Read)  
        FROM attributesCte a  
        LEFT JOIN mdm.viw_SYSTEM_SECURITY_USER_ATTRIBUTE sec  
        ON a.AttributeID = sec.ID  
        WHERE sec.User_ID = @User_ID  
  
  
        IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Check Object Permissions: Create on Name and Code for new members.'  
        --Check Object Permissions.  Mark any attributes the user doesn't have permission to.  
  
        -- Require create on Name and Code for new members  
        IF EXISTS(  
            SELECT 1  
            FROM mdm.tblAttribute a  
            LEFT JOIN @AttributePermissions ap  
            ON a.ID = ap.AttributeID  
            WHERE   a.ID IN (@AttributeID_Code, @AttributeID_Name)  
                AND NOT (ap.Privilege_ID = @Permission_Access  
                    AND ap.AccessPermission & @AccessPermission_Create = @AccessPermission_Create)  
        )  
        BEGIN  
            UPDATE #MembersWorkingSet  
            SET ErrorCode = @ErrorCode_NoPermissionForThisOperation,  
                ErrorObjectType = @ObjectType_MemberId  
            WHERE MemberID IS NULL  
        END  
  
        IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Check Object Permissions: Create/Update on other attributes.'  
        -- Require create on attribute on new member  
        -- Require update on attribute on update member  
        UPDATE ws  
        SET  ErrorCode =  
                CASE COALESCE(ap.Privilege_ID, @Permission_Deny)  
                    WHEN @Permission_Access THEN @ErrorCode_ReadOnlyAttribute -- AccessPermission check is done below  
                    WHEN @Permission_Inferred THEN @ErrorCode_ReadOnlyAttribute  
                    WHEN @Permission_Deny THEN @ErrorCode_InvalidAttribute  
                    WHEN @Permission_None THEN @ErrorCode_InvalidAttribute  
                    ELSE NULL  
                END  
            ,ErrorObjectType = @ObjectType_MemberAttribute  
        FROM #MemberAttributeWorkingSet AS ws  
        INNER JOIN #MembersWorkingSet nm  
        ON ws.MemberRowID = nm.Row_ID  
        LEFT JOIN @AttributePermissions ap  
        ON ws.AttributeID = ap.AttributeID  
        WHERE    ws.ErrorCode IS NULL   
            AND (ap.Privilege_ID IS NULL  
                OR ap.Privilege_ID <> @Permission_Access  
                OR ap.AccessPermission & CASE WHEN nm.MemberID IS NULL THEN @AccessPermission_Create ELSE @AccessPermission_Update END = 0)  
  
        IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Determine whether member security applies.'  
        --Check Member Permissions.  Mark any members the user doesn't have permission to.  
        SET @MemberSecurity = mdm.udfUseMemberSecurity(@User_ID, @Entity_ID, @Version_ID, @MemberType_ID);  
    END  
  
    IF @MemberSecurity = 1  
    BEGIN  
        IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Check Member Permissions.  Mark any members the user doesn''t have permission to update.'  
        DECLARE @MemberIds mdm.MemberId;  
        INSERT INTO @MemberIds (ID, MemberType_ID)  
        SELECT DISTINCT  
                mws.MemberID  
            ,@MemberType_ID  
        FROM #MemberAttributeWorkingSet aws  
        INNER JOIN #MembersWorkingSet mws  
        ON aws.MemberRowID = mws.Row_ID  
        WHERE   mws.MemberID IS NOT NULL -- New members will have null MemberID, so they will be excluded from this query  
            AND aws.ErrorCode IS NULL;  
  
        IF EXISTS (SELECT 1 FROM @MemberIds)  
        BEGIN  
            DELETE FROM @MemberPermissions;  
            INSERT INTO @MemberPermissions  
            EXEC mdm.udpSecurityMembersResolverGet @User_ID, @Version_ID, @Entity_ID, @MemberIds;  
  
            UPDATE aws  
            SET ErrorCode = @ErrorCode_NoPermissionForThisOperationOnThisObject,  
                ErrorObjectType = @ObjectType_MemberCode  
            FROM #MemberAttributeWorkingSet aws  
            INNER JOIN #MembersWorkingSet mws  
            ON aws.MemberRowID = mws.Row_ID  
            LEFT JOIN @MemberPermissions prm  
            ON  mws.MemberID = prm.ID  
            WHERE NOT (ISNULL(prm.Privilege_ID, @Permission_Deny) = @Permission_Access AND (ISNULL(prm.AccessPermission, @AccessPermission_None) & @AccessPermission_Update) = @AccessPermission_Update)  
                AND mws.MemberID IS NOT NULL -- New members will have null MemberID, so they will be excluded from this query  
                AND aws.ErrorCode IS NULL;  
        END;  
    END;  
  
    SET @HasDba = CASE WHEN EXISTS(SELECT 1 FROM #AttributeDefinition WHERE ISNULL(AttributeType_ID, @AttributeType_NotSpecified) = @AttributeType_DBA)  
        THEN 1 ELSE 0 /*Can skip DBA processing*/ END;  
    SET @HasFile = CASE WHEN EXISTS(SELECT 1 FROM #AttributeDefinition WHERE ISNULL(AttributeType_ID, @AttributeType_NotSpecified) = @AttributeType_File)  
        THEN 1 ELSE 0 /*No file attributes to update*/ END;  
  
    ----------------------------------------------------------------------------------------  
    --Set column name strings.  
    ----------------------------------------------------------------------------------------  
    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Set column name strings.'  
    SELECT  
         @TableColumnsUnPivotDefn   +=  CONCAT(N'  
    ,', TableColumnUnPivotDefn, N' --', AttributeName)  
        ,@ViewColumnsUnPivotDefn += CONCAT(N'  
    ,CONVERT(NVARCHAR(MAX),', QUOTENAME(CONCAT(AttributeName, CASE WHEN AttributeType_ID = @AttributeType_DBA THEN N'.ID' END)), N') AS ', QUOTENAME(AttributeID), N' --', AttributeName, CASE WHEN AttributeType_ID = @AttributeType_DBA THEN CONCAT(N'  
    ,CONVERT(NVARCHAR(MAX),', QUOTENAME(AttributeName), N') AS ', QUOTENAME(CONCAT(AttributeID, N'_Code'))) END) -- extra column for DBA member code  
        ,@TableColumnsUpdateDefn    +=  CONCAT(N'  
    ,', TableColumnUpdateDefn)  
        ,@AttributeIdList           += CONCAT(CASE WHEN @AttributeIdList <> N'' THEN ',' END, QUOTENAME(AttributeID))   
        ,@AttributeIdListWithDBACode = CONCAT(@AttributeIdListWithDBACode, CASE WHEN AttributeType_ID = @AttributeType_DBA THEN CONCAT(CASE WHEN @AttributeIdListWithDBACode <> N'' THEN ',' END, QUOTENAME(CONCAT(AttributeID, N'_Code'))) END)   
        ,@AttributeValueMappedAsColumns += CONCAT(N'  
        ,MAX(', QUOTENAME(AttributeID), N') AS ', TableColumn)  
    FROM #AttributeDefinition  
    ORDER BY AttributeID;  
  
    If @HasDba = 1  
    BEGIN  
        SELECT @TableColumnsUpdateDbaIdsDefn += CONCAT(CASE WHEN @TableColumnsUpdateDbaIdsDefn <> N'' THEN N'  
                    UNION ALL  
                    ' END, TableColumnUpdateDbaIdsDefn)  
        FROM #AttributeDefinition   
        WHERE COALESCE(Dba_Entity_ID, 0) > 0   
        ORDER BY AttributeID;  
    END;  
  
    ----------------------------------------------------------------------------------------  
    -- Validate attribute working set.  
    ----------------------------------------------------------------------------------------  
    IF (@ValidateDataTypes = 1)  
    BEGIN  
        --Flag FreeForm and Link attributes where the value length exceeds the maximum length allowed.  
        UPDATE ws  
        SET  ErrorCode = @ErrorCode_AttributeValueLengthGreaterThanMaximum  
            ,ErrorObjectType = @ObjectType_MemberAttribute  
        FROM #MemberAttributeWorkingSet AS ws  
        INNER JOIN #AttributeDefinition AS att  
        ON ws.AttributeID = att.AttributeID  
        WHERE   att.AttributeType_ID = @AttributeType_FreeForm  
            AND (att.DataType_ID = @AttributeDataType_Text OR att.DataType_ID = @AttributeDataType_Link)  
            AND ISNULL(LEN(ws.AttributeValue), 0) > ISNULL(att.DataTypeInformation, 0)  
            AND ws.ErrorCode IS NULL;  
  
        DECLARE @SqlAzureEngineEdition INT = 5;  
        DECLARE  
             @IsAzure BIT = CASE SERVERPROPERTY(N'EngineEdition') WHEN @SqlAzureEngineEdition THEN 1 ELSE 0 END  
            ,@NewAttributeValue NVARCHAR(MAX)  
            ,@Row_ID INT  
  
        --Flag attributes with incorrect numeric types  
        IF (@IsAzure = 0)  
        BEGIN  
            -- SQL CLR is supported.  
            UPDATE ws  
            SET  ErrorCode = CASE mdq.IsNumber(ws.AttributeValue) WHEN 0 THEN  
                    @ErrorCode_InvalidAttributeValueForDataType ELSE -- 'Error - The AttributeValue must be a number.'  
                    @ErrorCode_InvalidAttributeValueForMember END  -- 'Error - The AttributeValue is too long.'  
                ,ErrorObjectType = @ObjectType_MemberAttribute  
            FROM #MemberAttributeWorkingSet AS ws  
            INNER JOIN #AttributeDefinition AS att  
            ON ws.AttributeID = att.AttributeID  
            WHERE   att.AttributeType_ID = @AttributeType_FreeForm  
                AND att.DataType_ID = @AttributeDataType_Number  
                AND ws.AttributeValue IS NOT NULL  
                AND CASE -- using a CASE statement here ensures Boolean short-circuiting. If the value isn't numeric then trying to convert it to float will crash  
                    WHEN ISNULL(mdq.IsNumber(ws.AttributeValue), 0) <> 1 THEN 1  
                    WHEN mdq.IsNumber(STR(CONVERT(FLOAT, ws.AttributeValue), 38 - att.DataTypeInformation, att.DataTypeInformation)) <> 1 THEN 1  
                    ELSE 0 END = 1  
                AND ws.ErrorCode IS NULL;  
  
        END ELSE  
        BEGIN  
            -- SQL CLR is not supported. Use a slower TSQL equivalent by checking one row at a time in a loop.  
            -- TODO: Consider removing this ELSE block when SQL Azure adds support for SQL CLR  
  
            -- Find all working set rows that change the value of a numeric attribute.  
            DECLARE @NumericAttributeRowIndexes TABLE  
            (  
                 ID INT PRIMARY KEY  
                ,NewAttributeValue NVARCHAR(MAX) COLLATE DATABASE_DEFAULT  
                ,DataTypeInformation INT  
            );  
            INSERT INTO @NumericAttributeRowIndexes  
            SELECT  
                 ws.Row_ID  
                ,ws.AttributeValue  
                ,att.DataTypeInformation  
            FROM #MemberAttributeWorkingSet AS ws  
            INNER JOIN #AttributeDefinition AS att  
            ON ws.AttributeID = att.AttributeID  
            WHERE   att.AttributeType_ID = @AttributeType_FreeForm  
                AND att.DataType_ID = @AttributeDataType_Number  
                AND ws.AttributeValue IS NOT NULL  
                AND ws.ErrorCode IS NULL;  
  
            -- Loop through each numeric attribute working set row, and ensure the new value is numeric.  
            DECLARE  
                 @IsNumeric           BIT  
                ,@ErrorCode           INT  
                ,@DataTypeInformation INT;  
            WHILE EXISTS (SELECT 1 FROM @NumericAttributeRowIndexes)  
            BEGIN  
                -- Get the next row  
                SELECT TOP 1  
                     @Row_ID = ID  
                    ,@NewAttributeValue = NewAttributeValue  
                    ,@DataTypeInformation = DataTypeInformation  
                FROM @NumericAttributeRowIndexes;  
  
                DELETE FROM @NumericAttributeRowIndexes WHERE ID = @Row_ID;  
  
                SET @IsNumeric = 0;  
                SET @ErrorCode = NULL;  
                EXEC mdq.udpIsNumber @NewAttributeValue, @IsNumeric OUTPUT  
                IF COALESCE(@IsNumeric, 0) = 0  
                BEGIN  
                    SET @ErrorCode = @ErrorCode_InvalidAttributeValueForDataType; -- 'Error - The AttributeValue must be a number.'  
                END ELSE  
                BEGIN  
                    -- The new value is numeric, but ensure it is not too long  
                    SET @NewAttributeValue = STR(CONVERT(FLOAT, @NewAttributeValue), 38 - @DataTypeInformation, @DataTypeInformation);  
                    SET @IsNumeric = 0;  
                    EXEC mdq.udpIsNumber @NewAttributeValue, @IsNumeric OUTPUT  
                    IF COALESCE(@IsNumeric, 0) = 0  
                    BEGIN  
                        SET @ErrorCode = @ErrorCode_InvalidAttributeValueForMember; -- 'Error - The AttributeValue is too long.'  
                    END;  
                END;  
  
                IF @ErrorCode IS NOT NULL  
                BEGIN  
                    UPDATE #MemberAttributeWorkingSet  
                    SET  ErrorCode = @ErrorCode  
                        ,ErrorObjectType = @ObjectType_MemberAttribute  
                    WHERE Row_ID = @Row_ID  
                END;  
            END;-- WHILE  
        END;  
  
        -- Numeric data types in scientific notation format cannot be directly converted to type  
        -- DECIMAL, so convert them to fixed-point notation.  
        UPDATE ws  
        SET AttributeValueMapped =  
            -- the CASE condition is redundant with part of the JOIN clause, but it is necessary because even when false the query will still  
            -- sometimes evaluate the right-hand side of this assignment, which can cause a "failure to convert NVARCHAR to float" error.  
                CASE COALESCE(ws.ErrorCode, N'')  
                    WHEN N'' THEN STR(CONVERT(FLOAT, ws.AttributeValue), 38 - att.DataTypeInformation, att.DataTypeInformation)  
                    ELSE ws.AttributeValue  
                END  
        FROM #MemberAttributeWorkingSet AS ws  
        INNER JOIN #AttributeDefinition AS att  
        ON ws.AttributeID = att.AttributeID  
        WHERE   ISNULL(att.DataType_ID, @AttributeDataType_NotSpecified) = @AttributeDataType_Number  
            AND ISNULL(CHARINDEX(N'E', UPPER(ws.AttributeValue)), 0) > 0     -- CHARINDEX uses 1-based indexing  
            AND ws.ErrorCode IS NULL;  
  
        --Flag attributes with incorrect data type  
        IF (@IsAzure = 0)  
        BEGIN  
            -- SQL CLR is supported.  
            UPDATE ws  
            SET  ErrorCode = @ErrorCode_InvalidAttributeValueForDataType  
                ,ErrorObjectType = @ObjectType_MemberAttribute  
            FROM #MemberAttributeWorkingSet AS ws  
            INNER JOIN #AttributeDefinition AS att  
            ON att.AttributeID = ws.AttributeID  
            WHERE   ISNULL(att.DataType_ID, @AttributeDataType_NotSpecified) = @AttributeDataType_DateTime  
                AND LEN(ISNULL(ws.AttributeValue, N'')) > 0  
                AND ISNULL(mdq.IsDateTime2(ws.AttributeValue), 1) = 0  
                AND ws.ErrorCode IS NULL;  
        END ELSE  
        BEGIN  
            -- SQL CLR is not supported. Use a slower TSQL equivalent by checking one row at a time in a loop.  
            -- TODO: Consider removing this ELSE block when SQL Azure adds support for SQL CLR  
  
            -- Find all working set rows that change the value of a datetime attribute.  
            DECLARE @DateTimeAttributeRowIndexes TABLE  
            (  
                 ID INT PRIMARY KEY  
                ,NewAttributeValue NVARCHAR(MAX) COLLATE DATABASE_DEFAULT  
            );  
            INSERT INTO @DateTimeAttributeRowIndexes  
            SELECT  
                 ws.Row_ID  
                ,ws.AttributeValue  
            FROM #MemberAttributeWorkingSet AS ws  
            INNER JOIN #AttributeDefinition AS att  
            ON att.AttributeID = ws.AttributeID  
            WHERE   att.DataType_ID = @AttributeDataType_DateTime  
                AND LEN(ISNULL(ws.AttributeValue, N'')) > 0  
                AND ws.ErrorCode IS NULL;  
  
            -- Loop through each datetime attribute working set row, and ensure the new value is a datetime2.  
            DECLARE @IsDateTime2 BIT;  
            WHILE EXISTS (SELECT 1 FROM @DateTimeAttributeRowIndexes)  
            BEGIN  
                -- Get the next row  
                SELECT TOP 1  
                     @Row_ID = ID  
                    ,@NewAttributeValue = NewAttributeValue  
                FROM @DateTimeAttributeRowIndexes  
                DELETE FROM @DateTimeAttributeRowIndexes WHERE ID = @Row_ID;  
  
                SET @IsDateTime2 = 0;  
                EXEC mdq.udpIsDateTime2 @NewAttributeValue, @IsDateTime2 OUTPUT  
                IF COALESCE(@IsDateTime2, 0) = 0  
                BEGIN  
                    UPDATE #MemberAttributeWorkingSet  
                    SET  ErrorCode = @ErrorCode_InvalidAttributeValueForDataType  
                        ,ErrorObjectType = @ObjectType_MemberAttribute  
                    WHERE Row_ID = @Row_ID  
                END;  
            END;-- WHILE  
        END  
  
        --Flag attributes with incorrect links.  
        UPDATE ws  
        SET  ErrorCode = @ErrorCode_InvalidAttributeValueForDataType  
            ,ErrorObjectType = @ObjectType_MemberAttribute  
        FROM #MemberAttributeWorkingSet AS ws  
        INNER JOIN #AttributeDefinition AS att  
        ON ws.AttributeID = att.AttributeID  
        WHERE   att.DataType_ID = @AttributeDataType_Link  
            AND att.AttributeType_ID = @AttributeType_FreeForm  
            AND LEN(ISNULL(ws.AttributeValue, N'')) > 0  
            AND ISNULL(mdq.IsLink(ws.AttributeValue), 1) = 0  
            AND ws.ErrorCode IS NULL;  
  
    END; -- IF @ValidateDataTypes  
  
    ----------------------------------------------------------------------------------------  
    -- Lookup DBA member IDs  
    ----------------------------------------------------------------------------------------  
    IF @HasDba = 1  
    BEGIN  
        IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Get Dba Ids.'  
  
        SET @SQL = @TruncationGuard + N'  
            UPDATE ws  
            SET AttributeValueMapped = dba.ID  
            FROM #MemberAttributeWorkingSet ws  
            INNER JOIN #AttributeDefinition AS att  
            ON      ws.AttributeID = att.AttributeID  
                AND att.Dba_Entity_ID > 0  
            LEFT JOIN (' + @TableColumnsUpdateDbaIdsDefn + N') dba  
            ON      ws.AttributeValue = dba.Code  
                AND ws.AttributeID = dba.AttributeID  
            WHERE ws.ErrorCode IS NULL;  
        ';  
        --IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT @SQL;  
        EXEC sp_executesql @SQL, N'@Version_ID INT', @Version_ID;  
  
        ---------------------------------------------------------------------------------------------------------------------  
        -- Get the ids of all attribute working set rows that are changing the value of a self-referencing DBA to a new member  
        -- that is being created in this sproc call. These rows will need to have their AttributeValueMapped column set to the  
        -- ID of the newly-created member after the members are created and before the attribute values are set.  
        ---------------------------------------------------------------------------------------------------------------------  
        CREATE TABLE #DbaReferencesToNewMembers  
        (  
             AttributeRowID     INT PRIMARY KEY  
            ,ChildMemberRowID   INT  
            ,ParentMemberRowID  INT  
        );  
        CREATE INDEX #ix_DbaReferencesToNewMembers_ChildMemberRowID ON #DbaReferencesToNewMembers(ChildMemberRowID);  
        CREATE INDEX #ix_DbaReferencesToNewMembers_ParentMemberRowID ON #DbaReferencesToNewMembers(ParentMemberRowID);  
        IF (@MemberType_ID = @MemberType_Leaf) -- Only leaf members can be DBA values.  
        BEGIN  
            WITH childMembersCte AS -- This references all DBA rows that references a member of the same entity, where the referenced member doesn't (yet) exist.  
            (  
                SELECT  
                     ws.Row_ID          AS AttributeRowID  
                    ,ws.MemberRowID  
                    ,ws.AttributeValue  AS NewParentCode  
                FROM #MemberAttributeWorkingSet ws  
                INNER JOIN #AttributeDefinition att     -- Only look at self-referencing DBA value assignments  
                ON      ws.AttributeID = att.AttributeID  
                    AND att.Dba_Entity_ID = @Entity_ID  
                WHERE   ws.ErrorCode IS NULL -- Exclude rows that have already been tagged with an error.  
                    AND ws.AttributeValue IS NOT NULL -- Exclude rows that change the attribute value to null.  
                    AND ws.AttributeValueMapped IS NULL -- Exclude rows that reference an existing member.  
            )  
            INSERT INTO #DbaReferencesToNewMembers  
            (  
                 AttributeRowID  
                ,ChildMemberRowID  
                ,ParentMemberRowID -- Note that if this column is null, then the DBA references an invalid member.  
            )  
            SELECT  
                 child.AttributeRowID  
                ,child.MemberRowID  
                ,parent.Row_ID  
            FROM childMembersCte child  
            LEFT JOIN #MembersWorkingSet parent  
            ON      child.NewParentCode = parent.MemberCode  
                AND parent.ErrorCode IS NULL;  
        END;  
  
  
        --Flag any invalid Dba values  
        UPDATE ws  
        SET  ws.ErrorCode = @ErrorCode_InvalidAttributeValueForMember  
            ,ws.ErrorObjectType = @ObjectType_MemberAttribute  
        FROM #MemberAttributeWorkingSet ws  
        LEFT JOIN #DbaReferencesToNewMembers selfRef  
        ON ws.Row_ID = selfRef.AttributeRowID  
        WHERE   ws.AttributeValue IS NOT NULL  
            AND ws.AttributeValueMapped IS NULL  
            AND ws.ErrorCode IS NULL  
            -- Don't add an error if the DBA references a member being created in this  sproc call  
            AND selfRef.ParentMemberRowID IS NULL -- If null, then the DBA does not reference a new member about to be created.  
  
        -- Prune self-referencing DBA rows that reference an invalid member.  
        DELETE FROM #DbaReferencesToNewMembers WHERE ParentMemberRowID IS NULL;  
  
        --Check DBA Member Permissions.  Mark any members the user doesn't have permission to.  
        IF @ModelPermission != @Permission_Admin  
        BEGIN  
            DECLARE @DbaTempTable TABLE  
            (  
                 RowNumber INT IDENTITY (1, 1) PRIMARY KEY CLUSTERED NOT NULL  
                ,Dba_Entity_ID INT NOT NULL  
            );  
  
            --Get the distinct list of Dba Entities.  
            INSERT INTO @DbaTempTable  
            SELECT DISTINCT att.Dba_Entity_ID  
            FROM #MemberAttributeWorkingSet ws  
            INNER JOIN #AttributeDefinition att  
            ON      att.AttributeID = ws.AttributeID  
                AND att.Dba_Entity_ID > 0  
            WHERE ws.ErrorCode IS NULL;  
  
            DECLARE  
                 @DbaEntityID INT  
                ,@DbaUseMemberSecurity INT  
                ,@Counter INT = 1  
                ,@MaxCounter INT = (SELECT MAX(RowNumber) FROM @DbaTempTable);  
  
            --Loop through each Dba Entity checking the user's permissions to the Dba members.  
            WHILE @Counter <= @MaxCounter  
            BEGIN  
                SELECT @DbaEntityID = Dba_Entity_ID FROM @DbaTempTable WHERE [RowNumber] = @Counter ;  
  
                SET @DbaUseMemberSecurity = 0;  
                IF @ModelPermission != @Permission_Admin  
                BEGIN  
                    SET @DbaUseMemberSecurity = mdm.udfUseMemberSecurity (@User_ID, @DbaEntityID, @Version_ID, @MemberType_Leaf);  
                END  
  
                --Check DBA Member Permissions.  Mark any members the user doesn't have permission to.  
                IF @DbaUseMemberSecurity = 1  
                BEGIN  
  
                    DELETE FROM @MemberIds;  
                    INSERT INTO @MemberIds (ID, MemberType_ID)  
                    SELECT DISTINCT  
                         CONVERT(INT, ws.AttributeValueMapped) --Contains the Dba Member ID.  
                        ,@MemberType_ID  
                    FROM #MemberAttributeWorkingSet ws  
                    INNER JOIN #AttributeDefinition att  
                    ON      att.AttributeID = ws.AttributeID  
                        AND att.Dba_Entity_ID = @DbaEntityID  
                    WHERE   ws.AttributeValueMapped IS NOT NULL  
                        AND ws.ErrorCode IS NULL;  
  
                    --Get member permissions  
                    DELETE FROM @MemberPermissions;  
                    INSERT INTO @MemberPermissions  
                    EXEC mdm.udpSecurityMembersResolverGet @User_ID, @Version_ID, @DbaEntityID, @MemberIds  
  
                    --Mark any member attribute values that don't have permissions  
                    UPDATE ws  
                    SET ErrorCode = @ErrorCode_NoPermissionForThisOperationOnThisObject,  
                        ErrorObjectType = @ObjectType_MemberCode  
                    FROM #MemberAttributeWorkingSet ws  
                    INNER JOIN #AttributeDefinition att  
                    ON ws.AttributeID = att.AttributeID  
                    LEFT JOIN @MemberPermissions prm  
                    ON ws.AttributeValueMapped = CONVERT(NVARCHAR, prm.ID) -- Convert to NVARCHAR avoids potential errors from the AttributeValueMapped column being implicitly converted to INT  
                    WHERE   att.Dba_Entity_ID = @DbaEntityID  
                        AND ISNULL(prm.Privilege_ID, @Permission_Deny) = @Permission_Deny  
                        AND ws.AttributeValueMapped IS NOT NULL -- don't add errors for rows that change the DBA to null  
                        AND ws.ErrorCode IS NULL;  
                END;  
                SET @Counter += 1;  
            END;  
        END;  
    END; -- IF @HasDba  
  
    ----------------------------------------------------------------------------------------------  
    --Check for any attribute value changes for the Code attribute.  Requires special handling.  
    ----------------------------------------------------------------------------------------------  
    IF EXISTS(SELECT 1 FROM #MemberAttributeWorkingSet WHERE AttributeID = @AttributeID_Code AND ErrorCode IS NULL)  
    BEGIN  
        ----------------------------------------------------------------------------------------  
        -- Check for empty Codes.  
        ----------------------------------------------------------------------------------------  
        IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Check for empty Codes.';  
        UPDATE #MemberAttributeWorkingSet  
        SET  ErrorCode = @ErrorCode_InvalidBlankMemberCode  
            ,ErrorObjectType = @ObjectType_MemberAttribute  
        WHERE   AttributeID = @AttributeID_Code  
            AND NULLIF(AttributeValue, N'') IS NULL  
            AND ErrorCode IS NULL;  
  
        ----------------------------------------------------------------------------------------  
        -- Check for reserved words in the MemberCode.  
        ----------------------------------------------------------------------------------------  
        IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Check for reserved words in the MemberCode.';  
        UPDATE ws  
        SET  ErrorCode = @ErrorCode_ReservedWord  
            ,ErrorObjectType = @ObjectType_MemberAttribute  
        FROM #MemberAttributeWorkingSet ws  
        INNER JOIN mdm.udfItemReservedWordsGet(12/*Leaf member*/) rw  
            ON UPPER(ws.AttributeValue) = UPPER(rw.ReservedWord)  
        WHERE   ws.AttributeID = @AttributeID_Code  
            AND ws.ErrorCode IS NULL;  
  
        ----------------------------------------------------------------------------------------  
        -- Check for duplicate MemberCodes values in the working set.  
        ----------------------------------------------------------------------------------------  
        IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Check for duplicate MemberCodes values in the working set.';  
        WITH duplicateCodes AS  
        (  
            SELECT AttributeValue AS MemberCode  
            FROM #MemberAttributeWorkingSet  
            WHERE   AttributeID = @AttributeID_Code  
                AND ErrorCode IS NULL  
            GROUP BY AttributeValue  
            HAVING COUNT(*) > 1  
        )  
        UPDATE ws  
        SET  ErrorCode = @ErrorCode_DuplicateInputMemberCodes  
            ,ErrorObjectType = @ObjectType_MemberAttribute  
        FROM #MemberAttributeWorkingSet AS ws  
        INNER JOIN duplicateCodes AS dup  
        ON ws.AttributeValue = dup.MemberCode  
        WHERE   ws.AttributeID = @AttributeID_Code  
            AND ws.ErrorCode IS NULL;  
  
        ----------------------------------------------------------------------------------------  
        -- Check for conflicts with existing MemberCodes.  
        ----------------------------------------------------------------------------------------  
        IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Check for conflicts with existing MemberCodes.'  
        -- TODO: Consider refactoring to support the scenario of swapping the codes of two existing members within the same call (should be allowed, but the check as written will fail it)  
        SET @SQL = @ExistingCodesCteSQL + N'  
            ,oldAndNewCodesCte AS  
            (  
                SELECT  
                     Code  
                    ,MUID  
                FROM existingCodesCte  
                WHERE Status_ID = 1 -- Only look at the codes of active members (reuse of soft-deleted member codes is allowed). DO NOT replace this hardcoded number with a var. It would be bad for perf.  
  
                UNION -- not UNION ALL because deduplication is needed  
  
                SELECT -- Joining with the new members prevents a constraint violation when a merge operation creates a new member and tries to update an existing member''s code to the same value as the new member.  
                     MemberCode AS Code  
                    ,MemberMUID AS MUID  
                FROM #MembersWorkingSet  
                WHERE ErrorCode IS NULL  
            )  
            UPDATE ws  
            SET  ErrorCode = @ErrorCode_MemberCodeExists  
                ,ErrorObjectType = @ObjectType_MemberAttribute  
            FROM #MemberAttributeWorkingSet AS ws  
            INNER JOIN oldAndNewCodesCte c  
            ON ws.AttributeValue = c.Code  
            INNER JOIN #MembersWorkingSet mws  
            ON ws.MemberRowID = mws.Row_ID  
            WHERE   ws.AttributeID = @AttributeID_Code  
                AND (mws.MemberMUID IS NULL OR c.MUID <> mws.MemberMUID) -- Changing a member''s code to the same value is a no-op, not an error.  
                AND ws.ErrorCode IS NULL;  
            ';  
        EXEC sp_executesql @SQL,  
          N'@Version_ID INT, @ErrorCode_MemberCodeExists INT, @ObjectType_MemberAttribute INT,  @AttributeID_Code INT',  
            @Version_ID,     @ErrorCode_MemberCodeExists,     @ObjectType_MemberAttribute,      @AttributeID_Code;  
  
    END; --Code special handling  
  
    ----------------------------------------------------------------------------------------  
    -- Map any NULL attribute values to the special value.  
    ----------------------------------------------------------------------------------------  
    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Map any NULL attribute values to the special value.'  
    UPDATE ws  
    SET AttributeValueMapped = m.SysNullValue  
    FROM #MemberAttributeWorkingSet AS ws  
    INNER JOIN #AttributeDefinition AS att  
    ON      ws.AttributeID = att.AttributeID  
        AND ws.AttributeValue IS NULL  
    INNER JOIN #SysNullDataTypeMap m  
    ON      att.AttributeType_ID = m.AtributeType_ID  
        AND att.DataType_ID = m.DataType_ID  
  
    ----------------------------------------------------------------------------------------  
    --Get current attribute values prior to update  
    ----------------------------------------------------------------------------------------  
    DECLARE @LookupPriorValues BIT = 0;  
    IF      @SaveMode <> @SaveMode_Create -- Don't bother looking up prior values when creating new members (the prior values will always be null)  
        AND NULLIF(@AttributeIdList, N'') IS NOT NULL  
    BEGIN  
        IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Get current attribute values prior to update.'  
        SET @LookupPriorValues = 1;  
  
        DECLARE @LookupPriorDBACodes BIT = CASE WHEN @TransactionLogType = @TransactionLogType_Attribute AND @HasDba = 1 AND @Changeset_ID IS NULL THEN 1 ELSE 0 END-- Don't need to bother joining with the domain entity tables to lookup member codes unless attribute transaction logging is being used  
  
        SET @SQL = CONCAT(@TruncationGuard, N'  
        WITH changingMembersCte AS -- The IDs of all existing members being changed.  
        (  
            SELECT DISTINCT  
                 mws.Row_ID MemberRowID  
                ,mws.MemberID  
            FROM #MembersWorkingSet mws  
            INNER JOIN #MemberAttributeWorkingSet aws  
            ON mws.Row_ID = aws.MemberRowID  
            WHERE   mws.MemberID IS NOT NULL -- Exclude new members, which will have a null MemberID at this point.  
                AND aws.ErrorCode IS NULL  
        )  
        ,currentValuesCte AS -- The current attribute values that may be about to change.  
        (  
            SELECT  
                 cm.MemberRowID', CASE WHEN @LookupPriorDBACodes = 1   
                                        THEN @ViewColumnsUnPivotDefn -- lookup in the view to get domain member Codes  
                                        ELSE @TableColumnsUnPivotDefn   
                                        END, N'  
            FROM mdm.', CASE WHEN @LookupPriorDBACodes = 1   
                                THEN @MemberViewName -- lookup in the view to get domain member Codes  
                                ELSE @MemberTableName  
                                END, N' AS m  
            INNER JOIN changingMembersCte cm  
            ON      m.Version_ID = @Version_ID  
                AND m.ID = cm.MemberID  
        )  
        ,', CASE WHEN @LookupPriorDBACodes = 1  
                THEN N'priorNonDBACte'  
                ELSE N'priorPivotCte' END, N' AS  
        (  
            SELECT  
                 MemberRowID  
                ,AttributeID  
                ,AttributeValue  
            FROM currentValuesCte  
            UNPIVOT   
            (AttributeValue FOR AttributeID IN (', @AttributeIdList, N')) AS up  
        )', CASE WHEN @LookupPriorDBACodes = 1  
                THEN CONCAT(N'  
        ,priorDBACodeCte AS  
        (  
            SELECT  
                 MemberRowID  
                ,SUBSTRING(Attribute_ID_Code, 1, CHARINDEX(N''_'', Attribute_ID_Code, 1) - 1) AttributeID  
                ,DBACode  
            FROM currentValuesCte  
            UNPIVOT   
            (DBACode FOR Attribute_ID_Code IN (', @AttributeIdListWithDBACode, N')) AS up  
        )  
        ,priorPivotCte AS  
        (  
            SELECT   
                 p.MemberRowID  
                ,p.AttributeID  
                ,p.AttributeValue  
                ,dba.DBACode  
            FROM priorNonDBACte p  
            LEFT JOIN priorDBACodeCte dba  
            ON      p.MemberRowID = dba.MemberRowID  
                AND p.AttributeID = dba.AttributeID  
        )') END, N'  
        UPDATE ws  
        SET  PriorValue = CASE att.AttributeType_ID  
                WHEN @AttributeType_DBA THEN ', CASE WHEN @LookupPriorDBACodes = 1 THEN N'prior.DBACode' ELSE N'NULL' END, N'  
                ELSE prior.AttributeValue END   
            ,PriorValueMapped = prior.AttributeValue -- Only set this column for non-file attributes  
            ,PriorFileId = CASE att.AttributeType_ID  
                WHEN @AttributeType_File THEN prior.AttributeValue -- Only set this column for file attributes  
                ELSE PriorFileId END  
        FROM #MemberAttributeWorkingSet AS ws  
        INNER JOIN priorPivotCte prior  
        ON      ws.MemberRowID = prior.MemberRowID  
            AND ws.AttributeID = prior.AttributeID  
        COLLATE DATABASE_DEFAULT  
        INNER JOIN #AttributeDefinition att  
        ON ws.AttributeID = att.AttributeID  
        ');  
  
        --IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT @SQL;  
        EXEC sp_executesql @SQL, N'@Version_ID INT, @AttributeType_DBA INT, @AttributeType_File INT', @Version_ID, @AttributeType_DBA, @AttributeType_File;  
    END  
  
    --------------------------------------------------  
    -- Determine whether the attribute has changed.  
    --------------------------------------------------  
    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Determine whether the attribute has changed.'  
  
    IF @SaveMode = @SaveMode_Create  
    BEGIN  
        -- Set the change tracking mask (IsChanged was previously set).  
        UPDATE aws  
        SET ChangeTrackingMask = COALESCE(POWER(2, att.ChangeTrackingGroup_ID - 1), 0)  
        FROM #MemberAttributeWorkingSet aws  
        INNER JOIN #AttributeDefinition att  
        ON aws.AttributeID = att.AttributeID  
        WHERE   aws.ErrorCode IS NULL  
            AND ISNULL(att.ChangeTrackingGroup_ID, 0) > 0;  
    END  
    ELSE  
    BEGIN  
        UPDATE aws  
        SET IsChanged =  
            CASE  
                WHEN mws.MemberID IS NULL OR mws.MemberID = 0 THEN 1-- When creating new members (the member ID won't be set yet), then assume the value has changed.  
                WHEN CASE att.AttributeType_ID  
                        WHEN @AttributeType_DBA THEN COALESCE(  
                                NULLIF(NULLIF(aws.AttributeValueMapped, 0), aws.PriorValueMapped)  
                            ,NULLIF(aws.PriorValueMapped, NULLIF(aws.AttributeValueMapped, 0))  
                            ,CASE WHEN NULLIF(aws.AttributeValueMapped, 0) IS NULL THEN aws.AttributeValue ELSE NULL END) -- If the DBA references a new member, then mark it as changed  
                        ELSE COALESCE(NULLIF(aws.AttributeValue, aws.PriorValue), NULLIF(aws.PriorValue, aws.AttributeValue)) END IS NOT NULL  
                    THEN 1  
                ELSE 0 END  
            ,ChangeTrackingMask = COALESCE(POWER(2, att.ChangeTrackingGroup_ID - 1), 0)  
        FROM #MemberAttributeWorkingSet aws  
        INNER JOIN #AttributeDefinition att  
        ON aws.AttributeID = att.AttributeID  
        INNER JOIN #MembersWorkingSet mws  
        ON aws.MemberRowID = mws.Row_ID  
        WHERE aws.ErrorCode IS NULL;  
  
        IF @Changeset_ID IS NULL  
        BEGIN  
            IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Remove unchanged attribute values from #MemberAttributeWorkingSet'  
            DELETE FROM #MemberAttributeWorkingSet WHERE IsChanged = 0;  
        END  
    END  
  
    ---------------------------------------------------------------------------------  
    -- Check for circular relationships in recursive derived hierarchies.  
    ---------------------------------------------------------------------------------  
    IF @HasDba = 1  
    BEGIN  
        /*  
            The hierarchy creation logic checks to make sure that a circular relationship does not exist when adding a recursive level. So,  
            the current state of the hierarchy should be free of circular relationships. The below algorithm is optimized for this. However,  
            in the unlikely event that a circular relationship somehow did get through validation checking and into the data, the below algorithm  
            will still work (it will return the correct result without crashing or getting into an infinite loop or recursion).  
        */  
        ---------------------------------------------------------------------------------  
        -- Determine if an attribute is changing that would impact member placement within any recursive derived hierarchies.  
        ---------------------------------------------------------------------------------  
        IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Determine if the entity participates in any recursive derived hierarchies.'  
        DECLARE @RecursiveDerivedHierarchyInfo TABLE  
        (  
             Row_ID              INT IDENTITY(1,1) PRIMARY KEY  
            ,AttributeID         INT  
            ,AttributeColumnName SYSNAME COLLATE DATABASE_DEFAULT  
        );  
        INSERT INTO @RecursiveDerivedHierarchyInfo (AttributeID, AttributeColumnName)  
        SELECT DISTINCT  
             att.AttributeID  
            ,att.TableColumn  
        FROM  #AttributeDefinition att  
        INNER JOIN mdm.tblDerivedHierarchyDetail d  
        ON      att.AttributeID = d.Foreign_ID  
            AND d.ForeignType_ID = 1 -- Attribute  
        WHERE att.Dba_Entity_ID = @Entity_ID -- If the attribute's entity is the same as its domain entity, then a recursive derived hierarchy is being changed.  
  
        IF EXISTS (SELECT 1 FROM @RecursiveDerivedHierarchyInfo)  
        BEGIN  
            IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Checking for circular relationships in recursive derived hierarchies.';  
  
            SELECT  
                 @Counter = 1  
                ,@MaxCounter = MAX(Row_ID)  
            FROM @RecursiveDerivedHierarchyInfo  
  
            DECLARE  
                 @RecursiveHierarchyAttribute_ID        INT  
                ,@RecursiveHierarchyAttributeColumnName SYSNAME;  
  
            -- Create a temp table for holding new parent (DBA value) assignments.  
            CREATE TABLE #NewParentAssignments  
            (  
                 WorkingSetRow_ID   INT PRIMARY KEY  
                ,ChildID            INT UNIQUE  
                ,NewParentID        INT  
            )  
            CREATE NONCLUSTERED INDEX #ix_NewParentAssignments_NewParentID ON #NewParentAssignments(NewParentID);  
  
            -- Create a temp table for holding combined (old updated with new) parent assignments.  
            CREATE TABLE #CombinedParentAssignments  
            (  
                 ChildID  INT PRIMARY KEY  
                ,ParentID INT  
            );  
            CREATE NONCLUSTERED INDEX #ix_CombinedParentAssignments_ParentID ON #CombinedParentAssignments(ParentID);  
  
            -- Loop through each recursive derived hierarchy.  
            WHILE @Counter <= @MaxCounter  
            BEGIN  
                -- Get hierarchy info.  
                SELECT  
                     @RecursiveHierarchyAttribute_ID = AttributeID  
                    ,@RecursiveHierarchyAttributeColumnName = AttributeColumnName  
                FROM @RecursiveDerivedHierarchyInfo  
                WHERE Row_ID = @Counter;  
  
                -- Get new parent assignments  
                DELETE FROM #NewParentAssignments;  
                INSERT INTO #NewParentAssignments  
                SELECT  
                     ws.Row_ID AS WorkingSetRow_ID  
                    --,mws.MemberCode AS ChildCode  
                     ,COALESCE(mws.MemberID, -mws.Row_ID) AS ChildID -- -- If the child doesn't already exist (is being created in this sproc call), then use the negative Row_ID as a pseudo-member ID. Negative, so that it doesn't conflict with existing member IDs.  
                    --,ws.AttributeValue AS NewParentCode  
                     ,COALESCE(ws.AttributeValueMapped, -newMem.ParentMemberRowID) AS NewParentID -- If the new parent doesn't already exist (is being created in this sproc call), then use the negative Row_ID as a pseudo-member ID. Negative, so that it doesn't conflict with existing member IDs.  
                FROM #MemberAttributeWorkingSet ws  
                INNER JOIN #MembersWorkingSet mws  
                ON ws.MemberRowID = mws.Row_ID  
  
                LEFT JOIN #DbaReferencesToNewMembers newMem  
                ON ws.Row_ID = newMem.AttributeRowID  
  
                WHERE   ws.ErrorCode IS NULL  
                    AND ws.AttributeID = @RecursiveHierarchyAttribute_ID;  
  
                -- Combined the new parent (DBA value) assignments with the old.  
                DELETE FROM #CombinedParentAssignments;  
                SET @SQL = @TruncationGuard + N'  
                -- Get existing parent assignments from the table.  
                WITH existingParentAssignmentsCte AS  
                (  
                    SELECT DISTINCT  
                         ID AS ChildID  
                        ,' + @RecursiveHierarchyAttributeColumnName + N' AS OldParentID  
                    FROM mdm.' + @MemberTableName + N'  
                    WHERE Version_ID = @Version_ID  
                )  
  
                -- Combine the new and old parent assignments.  
                ,combinedParentAssignmentsCte AS  
                (  
                    SELECT  
                         COALESCE(new.ChildID, old.ChildID) AS ChildID  
  
                         -- The new parent assignment (if provided) takes precedence over the old. Cannot use COALESCE here because the new parent might be NULL.  
                        ,CASE WHEN new.ChildID IS NULL THEN old.OldParentID ELSE new.NewParentID END AS ParentID  
                    FROM #NewParentAssignments new  
                    FULL JOIN existingParentAssignmentsCte old  
                    ON new.ChildID = old.ChildID  
                )  
                INSERT INTO #CombinedParentAssignments  
                SELECT  
                     ChildID  
                    ,ParentID  
                FROM combinedParentAssignmentsCte  
                WHERE ParentID IS NOT NULL; -- Exclude NULL parents for efficiency, since they cannot be part of a circular relationship.  
                ';  
                --IF @Debug = 1 PRINT @SQL  
                EXEC sp_executesql @SQL, N'@Version_ID INT, @Entity_ID INT', @Version_ID, @Entity_ID;  
  
                -- Recursively find all new ancestors of the members being moved, checking for circular relationships.  
                WITH ancestorsCte AS  
                (  
                    -- Start with only those members whose pending DBA value changes would move them to a  
                    -- different parent (and potentially cause a circular relationship).  
                    SELECT  
                         WorkingSetRow_ID  
                        ,ChildID AS MemberID  
                        ,NewParentID AS AncestorID  
                        ,0 AS RecursionLevel  
                        ,CASE WHEN ChildID = NewParentID THEN 1 ELSE 0 END AS IsCircular -- If a member is its own parent, then it is part of a circular relationship.  
                    FROM #NewParentAssignments  
  
                    UNION ALL  
  
                    -- Recursively find all new ancestors of the members being moved.  
                    SELECT  
                         cte.WorkingSetRow_ID  
                        ,cte.MemberID  
                        ,p.ParentID AS AncestorID  
                        ,cte.RecursionLevel + 1  
                        ,CASE WHEN cte.MemberID = p.ParentID THEN 1 ELSE 0 END AS IsCircular -- If a member is its own ancestor, then it is part of a circular relationship.  
                    FROM ancestorsCte cte  
                    INNER JOIN #CombinedParentAssignments p  
                    ON cte.AncestorID = p.ChildID  
                    WHERE   cte.RecursionLevel < 99 -- Protects against "The statement terminated. The maximum recursion 100 has been exhausted before statement completion" error.  
                        AND cte.IsCircular = 0 -- Stop when a circular relationship is found.  
                )  
  
                -- Get the IDs of the working set rows that would cause circular relationships.  
                ,circularRelationshipsCte AS  
                (  
                    SELECT DISTINCT WorkingSetRow_ID  
                    FROM ancestorsCte  
                    WHERE IsCircular = 1  
                )  
  
                -- Add errors for any circular relationships found.  
                UPDATE ws  
                SET  ErrorCode = @ErrorCode_MemberCausesCircularReference  
                    ,ErrorObjectType = @ObjectType_MemberAttribute  
                FROM #MemberAttributeWorkingSet ws  
                INNER JOIN circularRelationshipsCte cte  
                ON ws.Row_ID = cte.WorkingSetRow_ID;  
  
                SET @Counter += 1;  
            END; -- WHILE  
        END; -- IF recursive hierarchy exists  
    END; -- IF @HasDba  
  
  
    -------------------------------------------------------------------------------------------  
    -- Conflict  
    -- Check if the attribute value changed from the requested revision  
    -- If the transaction log type is attribute or none, returns conflict error if the member has be changed.  
    -- If the transaction log type is member, check if updating attribute value has be changed.  
    -------------------------------------------------------------------------------------------  
    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Determine whether the attribute has change conflict.'  
    IF @SaveMode <> @SaveMode_Create  
       AND @Changeset_ID IS NULL -- Skip merge conflicts for pending changes  
       AND NULLIF(@AttributeIdList, N'') IS NOT NULL  
       AND EXISTS (SELECT 1 FROM #MembersWorkingSet WHERE RevisionID IS NOT NULL)  
    BEGIN  
        IF @HistoryTableName IS NULL  
        BEGIN  
            SET @SQL = CONCAT(N'  
            WITH changedMembers AS -- The IDs of all existing members were changed  
            (  
                SELECT DISTINCT  
                     mws.Row_ID MemberRowID  
                FROM #MembersWorkingSet mws  
                INNER JOIN mdm.', @MemberTableName, N' m  
                ON m.ID = mws.MemberID AND m.Version_ID = @Version_ID  
                WHERE mws.RevisionID IS NOT NULL AND mws.RevisionID <> m.LastChgTS  
            )  
            UPDATE ws  
            SET  ErrorCode = ', @ErrorCode_MemberMergeConflict, N'  
                ,ErrorObjectType = ', @ObjectType_MemberAttribute, N'  
            FROM #MemberAttributeWorkingSet AS ws  
            INNER JOIN changedMembers cm  
            ON      ws.MemberRowID = cm.MemberRowID');  
  
            --IF @Debug = 1 PRINT @SQL;  
            EXEC sp_executesql @SQL, N'@Version_ID INT', @Version_ID;  
        END  
        ELSE  
        BEGIN  
            SET @SQL = CONCAT(N'  
            WITH changedMembers AS -- The IDs of all existing members were changed  
            (  
                SELECT  
                     mws.Row_ID MemberRowID  
                     ,mws.MemberID MemberID  
                     ,mws.RevisionID RevisionID  
                FROM #MembersWorkingSet mws  
                INNER JOIN mdm.', @MemberTableName, N' m  
                ON m.ID = mws.MemberID AND m.Version_ID = @Version_ID  
                WHERE mws.RevisionID IS NOT NULL AND mws.RevisionID <> m.LastChgTS  
            )  
            ,currentValuesCte AS -- The current attribute values of the changed member  
            (  
                SELECT  
                     cm.MemberRowID', @TableColumnsUnPivotDefn, N'  
                FROM mdm.' + @MemberTableName + N' AS m  
                INNER JOIN changedMembers cm  
                ON m.ID = cm.MemberID AND m.Version_ID = @Version_ID  
            )  
            ,currentValues AS  
            (  
                SELECT  
                     MemberRowID  
                    ,up.AttributeID  
                    ,up.AttributeValue  
                FROM currentValuesCte  
                UNPIVOT  
                (AttributeValue FOR AttributeID IN (', @AttributeIdList, N')) AS up  
            )  
            ,originalValuesCte AS -- The original attribute values of the changed member  
            (  
                SELECT  
                    cm.MemberRowID', @TableColumnsUnPivotDefn, N'  
                    ,ROW_NUMBER() OVER(  
                        PARTITION BY cm.MemberID  
                        ORDER BY hs.ID DESC) AS rank  
                FROM mdm.', @HistoryTableName, N' AS hs  
                INNER JOIN changedMembers cm  
                ON hs.', @MemberIDColumn, ' = cm.MemberID AND hs.Version_ID = @Version_ID AND hs.ID >= cm.RevisionID  
            )  
            ,originalValues AS  
            (  
                SELECT  
                     MemberRowID  
                    ,up.AttributeID  
                    ,up.AttributeValue  
                FROM (SELECT * FROM originalValuesCte WHERE rank = 1) o  
                UNPIVOT  
                (AttributeValue FOR AttributeID IN (', @AttributeIdList, N')) AS up  
            )  
            UPDATE ws  
            SET  ErrorCode = ', @ErrorCode_AttributeMergeConflict, N'  
                ,ErrorObjectType = ', @ObjectType_MemberAttribute, N'  
            FROM #MemberAttributeWorkingSet AS ws  
            INNER JOIN currentValues c  
            ON ws.MemberRowID = c.MemberRowID AND ws.AttributeID = c.AttributeID  
            INNER JOIN originalValues o  
            ON ws.MemberRowID = o.MemberRowID AND ws.AttributeID = o.AttributeID  
            WHERE c.AttributeValue <> o.AttributeValue');  
  
            --IF @Debug = 1 PRINT @SQL;  
            EXEC sp_executesql @SQL, N'@Version_ID INT', @Version_ID;  
        END  
    END  
  
  
    -- Check for attribute filter value inconsistencies. This check should be done after all other attribute checks, because of dependencies that cross attribute changes (i.e. attribute A filters B filters C ...)  
    IF @HasDba = 1 AND @MemberType_ID = @MemberType_Leaf -- filters are only supported for leaf members  
    BEGIN  
        -- Get relationships between all attributes that participate in filters, either as parent or child  
        CREATE TABLE #AttributeFilter  
        (  
             ChildAttribute_ID                  INT PRIMARY KEY  
            ,ChildColumnName                    SYSNAME COLLATE DATABASE_DEFAULT  
            ,ParentAttribute_ID                 INT NOT NULL  
            ,FilterParentColumnName             SYSNAME COLLATE DATABASE_DEFAULT  
            ,FilterHierarchyEntityTableName     SYSNAME COLLATE DATABASE_DEFAULT  
            ,FilterHierarchyParentColumName     SYSNAME COLLATE DATABASE_DEFAULT  
            ,FilterHierarchyM2MChildColumnName  SYSNAME COLLATE DATABASE_DEFAULT NULL  
        )  
        INSERT INTO #AttributeFilter  
        SELECT  
             a.ID                               AS ChildAttribute_ID  
            ,a.TableColumn                      AS ChildColumnName  
            ,a.FilterParentAttribute_ID         AS ParentAttribute_ID  
            ,parentAttribute.TableColumn        AS FilterParentColumnName  
            ,levelEntity.EntityTable            AS FilterHierarchyEntityTableName  
            ,levelParentAttribute.TableColumn   AS FilterHierarchyParentColumName  
            ,m2mChildAttribute.TableColumn      AS FilterHierarchyM2MChildColumnName  
        FROM mdm.tblAttribute a  
        LEFT JOIN #AttributeDefinition adChild -- JOIN to see if the child attribute is being changed  
        ON a.ID = adChild.AttributeID  
        LEFT JOIN #AttributeDefinition adParent -- JOIN to see if the parent attribute is being changed  
        ON a.FilterParentAttribute_ID = adParent.AttributeID  
        INNER JOIN mdm.tblAttribute parentAttribute  
        ON a.FilterParentAttribute_ID = parentAttribute.ID  
        INNER JOIN mdm.tblDerivedHierarchyDetail filterLevel  
        ON a.FilterHierarchyDetail_ID = filterLevel.ID  
        INNER JOIN mdm.tblAttribute levelParentAttribute  
        ON filterLevel.Foreign_ID = levelParentAttribute.ID  
        INNER JOIN mdm.tblEntity levelEntity  
        ON levelParentAttribute.Entity_ID = levelEntity.ID  
        LEFT JOIN mdm.tblAttribute m2mChildAttribute  
        ON filterLevel.ManyToManyChildAttribute_ID = m2mChildAttribute.ID  
        WHERE   a.Entity_ID = @Entity_ID  
            AND a.MemberType_ID = @MemberType_ID  
            AND ISNULL(adChild.AttributeID, adParent.AttributeID) IS NOT NULL -- ignore filters where neither the parent nor the child values are being changed in this operation  
  
        CREATE TABLE #FilterError  
        (  
             MemberRow_ID           INT  
            ,ChildAttributeRow_ID   INT  
            ,ParentAttributeRow_ID  INT  
        )  
        CREATE UNIQUE CLUSTERED INDEX #ix_FilterError_ChildAttributeRow_ID_ParentAttributeRow_ID ON #FilterError(ChildAttributeRow_ID, ParentAttributeRow_ID)  
  
        SET @SQL = N'';  
        SELECT @SQL += CONCAT(@TruncationGuard, CASE WHEN @SQL = N'' THEN N'  
INSERT INTO #FilterError  
' ELSE N'  
UNION ALL -- not UNION ALL because deduplication is needed' END, N'  
SELECT  
     mws.Row_ID             MemberRow_ID  
    ,newChildValue.Row_ID   ChildAttributeRow_ID  
    ,newParentValue.Row_ID  ParentAttributeRow_ID  
FROM #MembersWorkingSet mws', CASE WHEN @SaveMode <> @SaveMode_Create THEN CONCAT(N'  
LEFT JOIN mdm.', QUOTENAME(@MemberTableName), N' en -- Join with entity table to get current values (LEFT JOIN, because the member might not already exist)  
ON      @Version_ID = en.Version_ID  
    AND mws.MemberID = en.ID') END, N'  
LEFT JOIN #MemberAttributeWorkingSet newChildValue -- LEFT, rather than INNER, JOIN because not all attribute values may be specified  
ON      mws.Row_ID = newChildValue.MemberRowID  
    AND newChildValue.AttributeID = ', ChildAttribute_ID, N'  
    AND newChildValue.ErrorCode IS NULL -- ignore new child values that already have an error  
LEFT JOIN #MemberAttributeWorkingSet newParentValue -- LEFT, rather than INNER, JOIN because not all attribute values may be specified  
ON      mws.Row_ID = newParentValue.MemberRowID  
    AND newParentValue.AttributeID = ', ParentAttribute_ID, N'  
    AND newParentValue.ErrorCode IS NULL -- ignore new parent values that already have an error  
LEFT JOIN mdm.', QUOTENAME(FilterHierarchyEntityTableName), N' filter-- join with filter hierarchy entity table  
ON      @Version_ID = filter.Version_ID  
    AND ', CASE WHEN @SaveMode <> @SaveMode_Create THEN N'ISNULL(' END, N'newChildValue.AttributeValueMapped', CASE WHEN @SaveMode <> @SaveMode_Create THEN CONCAT(N', en.', QUOTENAME(ChildColumnName), N')') END, N' = filter.', QUOTENAME(COALESCE(FilterHierarchyM2MChildColumnName, N'ID')), N'  
    AND ISNULL(', CASE WHEN @SaveMode <> @SaveMode_Create THEN N'ISNULL(' END, N'newParentValue.AttributeValueMapped', CASE WHEN @SaveMode <> @SaveMode_Create THEN CONCAT(N', en.', QUOTENAME(FilterParentColumnName), N')') END,  N', 0) = ISNULL(filter.', QUOTENAME(FilterHierarchyParentColumName), N', 0)  
WHERE   mws.ErrorCode IS NULL  
    AND ISNULL(newChildValue.AttributeID, newParentValue.AttributeID) IS NOT NULL -- ignore members where neither the parent nor the child is being changed  
    AND NULLIF(', CASE WHEN @SaveMode <> @SaveMode_Create THEN N'ISNULL(' END, N'newChildValue.AttributeValueMapped', CASE WHEN @SaveMode <> @SaveMode_Create THEN CONCAT(N', en.', QUOTENAME(ChildColumnName), N')') END, N', 0) IS NOT NULL -- null child values are always valid  
    AND filter.ID IS NULL  -- could not find a match in the filter table',   
    CASE WHEN FilterHierarchyM2MChildColumnName IS NOT NULL THEN CONCAT(N'  
    AND (NULLIF(', CASE WHEN @SaveMode <> @SaveMode_Create THEN N'ISNULL(' END, N'newParentValue.AttributeValueMapped', CASE WHEN @SaveMode <> @SaveMode_Create THEN CONCAT(N', en.', QUOTENAME(FilterParentColumnName), N')') END, N', 0) IS NOT NULL') END,   
    CASE WHEN FilterHierarchyM2MChildColumnName IS NOT NULL THEN CONCAT(N'-- M2M level: not finding a filter row match is okay if the parent is null  
         OR EXISTS( SELECT 1                                                -- The child is under another parent  
                    FROM mdm.', QUOTENAME(FilterHierarchyEntityTableName), N' filter  
                    WHERE   @Version_ID = filter.Version_ID    
                        AND ', CASE WHEN @SaveMode <> @SaveMode_Create THEN N'ISNULL(' END, N'newChildValue.AttributeValueMapped', CASE WHEN @SaveMode <> @SaveMode_Create THEN CONCAT(N', en.', QUOTENAME(ChildColumnName), N')') END, N' = filter.', QUOTENAME(COALESCE(FilterHierarchyM2MChildColumnName, N'ID')), N'    
                        AND filter.', QUOTENAME(FilterHierarchyParentColumName), N' IS NOT NULL))  
        ') END)    
        FROM #AttributeFilter  
  
        IF @SQL <> N''  
        BEGIN  
            IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT @SQL  
            EXEC sp_executesql @SQL, N'@Version_ID INT', @Version_ID;  
  
            UPDATE aws  
            SET  ErrorCode = @ErrorCode_AttributeValueNotCompatibleWithFilter   
                ,ErrorObjectType = @ObjectType_MemberAttribute  
            FROM #MemberAttributeWorkingSet aws  
            INNER JOIN #FilterError e  
            ON     aws.Row_ID = e.ChildAttributeRow_ID  
                OR aws.Row_ID = e.ParentAttributeRow_ID  
            WHERE aws.ErrorCode IS NULL  
  
            IF @TransactionBehavior = @TransactionBehavior_BestEffort -- Add errors for related rows, to prevent them from being saved and possibly creating data inconsistency  
            BEGIN  
                -- Get the IDs of all attributes that participate in a filter relationship, either as parent and/or child  
                DECLARE @FilterParticipant TABLE  
                (     
                    Attribute_ID INT PRIMARY KEY  
                )  
                INSERT INTO @FilterParticipant(Attribute_ID)  
                SELECT ChildAttribute_ID AS Attribute_ID FROM #AttributeFilter  
                UNION -- not "UNION ALL" because deduplication is needed  
                SELECT ParentAttribute_ID AS Attribute_ID FROM #AttributeFilter  
  
                UPDATE aws  
                SET  ErrorCode = @ErrorCode_PossiblyImpactedByIncompatibleFilteredValue -- BestEffort only: The attribute itself doesn't necessarily have an incompatible value, but because of filter chaining it is possible this value could be impacted. So to be safe, just fail it.  
                    ,ErrorObjectType = @ObjectType_MemberAttribute  
                FROM #MemberAttributeWorkingSet aws  
                INNER JOIN @FilterParticipant fp -- only set errors for attribute values changes that participate in filter relationships  
                ON aws.AttributeID = fp.Attribute_ID   
                INNER JOIN #FilterError e  
                ON aws.MemberRowID = e.MemberRow_ID  
                WHERE   aws.ErrorCode IS NULL  
  
            END -- IF BestOffort  
        END -- IF @SQL is not empty  
    END -- IF Leaf with DBAs  
  
    -------------------------------------------------------------------------------------------  
    -- If the caller has specified all-or-nothing transaction behavior, then when a member has  
    -- an error in any working set, invalidate in all working sets any error-free rows that pertain  
    -- to that member.  
    -------------------------------------------------------------------------------------------  
    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Check transaction behavior.';  
    IF @TransactionBehavior = @TransactionBehavior_AllOrNothingByMember  
    BEGIN  
        -- Get the MUIDs of all members that have any errors  
        DECLARE @MembersWithErrors TABLE  
        (  
            MemberRowID INT PRIMARY KEY CLUSTERED NOT NULL  
        );  
        INSERT INTO @MembersWithErrors (MemberRowID)  
        SELECT  
            Row_ID AS MemberRowID  
        FROM #MembersWorkingSet  
        WHERE ErrorCode IS NOT NULL  
  
        UNION -- not "UNION ALL" because deduplication is needed  
  
        SELECT DISTINCT  
            MemberRowID  
        FROM #MemberAttributeWorkingSet  
        WHERE ErrorCode IS NOT NULL  
  
        IF @HasDba = 1  
        BEGIN  
        -- TODO: look for errors in the collection working set  
        ---------------------------------------------------------------------------------------------------------------------  
        -- Add special handling for self-referencing DBA attributes (i.e. domain entity id = @Entity_ID). Add errors and  
        -- update the @MemberWithErrors table for attributes that are trying to reference members that will not  
        -- be created due to errors.  
        ---------------------------------------------------------------------------------------------------------------------  
        IF EXISTS(SELECT 1 FROM #DbaReferencesToNewMembers)  
        BEGIN  
            DECLARE @NewErrors TABLE  
            (  
                 AttributeRowID INT PRIMARY KEY  
                ,MemberRowID    INT  
            );  
  
            -- Prune the members with newly-found errors from the table of self referencing DBAs.  
            DELETE sr  
            FROM #DbaReferencesToNewMembers sr  
            INNER JOIN @MembersWithErrors er  
            ON sr.ChildMemberRowID = er.MemberRowID  
  
            DECLARE @Continue BIT = CASE WHEN EXISTS(SELECT 1 FROM #DbaReferencesToNewMembers) THEN 1 ELSE 0 END;  
  
            WHILE (@Continue = 1)  
            BEGIN  
                -- Prune the members with newly-found errors from the table of self referencing DBAs.  
                DELETE sr  
                OUTPUT deleted.AttributeRowID, deleted.ChildMemberRowID  
                INTO @NewErrors(AttributeRowID, MemberRowID)  
                FROM #DbaReferencesToNewMembers sr  
                INNER JOIN @MembersWithErrors er  
                ON sr.ParentMemberRowID = er.MemberRowID;  
  
                -- Set a flag to indicate if any new errors were found. This will mean needing to continue through the loop another time to check for new errors.  
                SET @Continue = CASE WHEN EXISTS(SELECT 1 FROM @NewErrors) THEN 1 ELSE 0 END;  
  
                IF @Continue = 1  
                BEGIN  
                    -- Add errors to the attribute working set rows pertaining to the newly found errors.  
                    UPDATE ws  
                    SET  ErrorCode = @ErrorCode_InvalidAttributeValueForMember -- The new member creation is going to fail, so it cannot be referenced as a DBA.  
                        ,ErrorObjectType = @ObjectType_MemberAttribute  
                    FROM #MemberAttributeWorkingSet ws  
                    INNER JOIN @NewErrors newError  
                    ON ws.Row_ID = newError.AttributeRowID;  
  
                    -- Copy the new errors into the main errors table.  
                    INSERT INTO @MembersWithErrors  
                    SELECT MemberRowID FROM @NewErrors  
  
                    DELETE FROM @NewErrors;  
                END; -- IF new errors found  
            END; -- WHILE  
            END; -- IF #DbaReferencesToNewMembers has rows  
        END; -- IF @HasDBA  
  
        IF EXISTS (SELECT 1 FROM @MembersWithErrors)  
        BEGIN  
            -- Mark new members working set rows to be ignored.  
            UPDATE ws  
                SET ErrorCode = @ErrorCode_FailedDueToAllOrNothingErrorPropagation  
            FROM #MembersWorkingSet ws  
            INNER JOIN @MembersWithErrors er  
            ON ws.Row_ID = er.MemberRowID  
            WHERE ws.ErrorCode IS NULL; -- Only delete rows without errors  
  
            -- Mark attribute value working set rows to be ignored.  
            UPDATE ws  
                SET ErrorCode = @ErrorCode_FailedDueToAllOrNothingErrorPropagation  
            FROM #MemberAttributeWorkingSet ws  
            INNER JOIN @MembersWithErrors er  
            ON ws.MemberRowID = er.MemberRowID  
            WHERE ws.ErrorCode IS NULL; -- Only delete rows without errors  
  
            -- TODO: flag rows in the collection working set  
        END;  
    END; -- IF @TransactionBehavior_AllOrNothingByMember  
  
    --------------------------------------------------  
    -- Error reporting.  
    --------------------------------------------------  
  
    ----------------------------------------------------------------------------------------  
    -- Update MemberCode for any member attribute change errors that are associated with a successful member code change  
    -- so that the updated member code is returned to the consumer.  
    ----------------------------------------------------------------------------------------  
    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Update MemberCode for any member attribute change errors that are associated with a successful member code change.';  
    WITH cteCodeChgs AS  
    (  
        SELECT  
             MemberRowID  
            ,AttributeValue AS NewCode  
        FROM #MemberAttributeWorkingSet  
        WHERE   AttributeID = @AttributeID_Code  
            AND ErrorCode IS NULL  
    )  
    UPDATE ws  
    SET ws.MemberCode = cde.NewCode  
    FROM #MembersWorkingSet ws  
    INNER JOIN cteCodeChgs cde  
    ON      ws.Row_ID = cde.MemberRowID  
        AND ws.ErrorCode IS NOT NULL;  
  
    --------------------------------------------------  
    -- Load all errors into a temp table.  
    --------------------------------------------------  
    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Load all errors into a temp table.';  
  
    -- Member errors  
    CREATE TABLE #Errors  
    (  
         ErrorCode INT NULL  
        ,ErrorParameters NVARCHAR(MAX) NULL  
        ,ErrorObjectType TINYINT NULL  
        ,MemberID INT NULL  
        ,MemberMUID UNIQUEIDENTIFIER NULL  
        ,MemberCode NVARCHAR(MAX) COLLATE DATABASE_DEFAULT NULL  
        ,MemberName NVARCHAR(MAX) COLLATE DATABASE_DEFAULT NULL  
        ,AttributeMUID UNIQUEIDENTIFIER NULL  
        ,AttributeName NVARCHAR(MAX) COLLATE DATABASE_DEFAULT NULL  
    )  
  
    INSERT INTO #Errors  
    (  
         ErrorCode  
        ,ErrorParameters  
        ,ErrorObjectType  
        ,MemberID  
        ,MemberMUID  
        ,MemberCode  
        ,MemberName  
        ,AttributeMUID  
        ,AttributeName  
    )  
    SELECT  
         ErrorCode  
        ,ErrorParameters  
        ,ErrorObjectType  
        ,MemberID  
        ,MemberMUID  
        ,MemberCode  
        ,MemberName  
        ,ErrorAttributeMUID AS AttributeMUID  
        ,ErrorAttributeName AS AttributeName  
    FROM #MembersWorkingSet  
    WHERE NULLIF(ErrorCode  
                ,@ErrorCode_FailedDueToAllOrNothingErrorPropagation -- This error should not be returned to the user. It is for internal use only.  
                ) IS NOT NULL  
  
    UNION ALL  
  
    -- Attribute value errors.  
    SELECT  
         ws.ErrorCode  
        ,ws.ErrorParameters  
        ,ws.ErrorObjectType  
        ,mws.MemberID  
        ,mws.MemberMUID  
        ,mws.MemberCode  
        ,mws.MemberName  
        ,att.AttributeMUID  
        ,att.AttributeName  
    FROM #MemberAttributeWorkingSet ws  
    LEFT JOIN #MembersWorkingSet mws  
    ON ws.MemberRowID = mws.Row_ID  
    LEFT JOIN #AttributeDefinition att  
    ON ws.AttributeID = att.AttributeID  
    WHERE NULLIF(ws.ErrorCode  
                ,@ErrorCode_FailedDueToAllOrNothingErrorPropagation -- This error should not be returned to the user. It is for internal use only.  
                ) IS NOT NULL  
  
    -- TODO: Union with any collection errors.  
  
    IF (@ErrorReportingType & @ErrorReportingType_Return) > 0  
    BEGIN  
        IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Return errors.';  
        SELECT  
            ErrorCode,  
            ErrorParameters,  
            ErrorObjectType,  
            MemberID,  
            MemberMUID,  
            MemberCode,  
            MemberName,  
            AttributeMUID,  
            AttributeName  
        FROM #Errors;  
    END;  
  
    IF (@ErrorReportingType & @ErrorReportingType_Xml) > 0  
    BEGIN  
        IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Add errors to XML out param.';  
        SET @Errors = CONVERT(XML,  
            (SELECT  
                 ErrorCode  
                ,ErrorParameters  
                ,ErrorObjectType  
                ,MemberID  
                ,MemberMUID  
                ,MemberCode  
                ,MemberName  
                ,AttributeMUID  
                ,AttributeName  
            FROM #Errors FOR XML PATH(N'Error')));  
    END;  
  
    IF (@ErrorReportingType & @ErrorReportingType_Raise) > 0  
    BEGIN  
        IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Raise first error.';  
        -- Raise an error for the first error in the working set.  
        DECLARE @FirstErrorMessage NVARCHAR(MAX) = NULL;  
        SELECT TOP 1  
            @FirstErrorMessage = CONCAT(N'MDSERR', ErrorCode, N'<error message placeholder, will be replaced by localized string in C# layer>', CASE WHEN ErrorParameters IS NOT NULL THEN CONCAT(N'|', ErrorParameters) END)  
        FROM #Errors;  
  
        IF @FirstErrorMessage IS NOT NULL  
        BEGIN  
            SET @FirstErrorMessage = REPLACE(@FirstErrorMessage, '%', '%%')-- escape out format specifier  
            RAISERROR(@FirstErrorMessage, 16, 1);  
            RETURN;-- Return, to abort the entire batch.  
        END;  
    END;  
  
    IF @TransactionBehavior = @TransactionBehavior_AllOrNothingByBatch  
        AND EXISTS(SELECT 1 FROM #Errors)  
    BEGIN  
        IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'At least one error was found, so abort the whole batch.';  
       -- At least one error was found, so abort the whole batch (i.e. return without changing any member tables).  
        RETURN 0;  
    END;  
  
  
    ------------------------------------------------------------------------------------------------------------  
    -- All validation checks have completed, so begin writing data from the working sets to the member tables  
    ------------------------------------------------------------------------------------------------------------  
    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Validation checks complete, start transaction.';  
    --Start transaction, being careful to check if we are nested  
    DECLARE @TranCounter INT = @@TRANCOUNT;  
    IF @TranCounter > 0  
    BEGIN  
        SAVE TRANSACTION TX;  
    END ELSE  
    BEGIN  
        BEGIN TRANSACTION;  
    END;  
  
    BEGIN TRY  
  
        DECLARE @CurrentTime DATETIME2(3) = GETUTCDATE();  
  
        ----------------------------------------------------------------------------------------  
        -- Handle CodeGen-enabled entities.  
        ----------------------------------------------------------------------------------------  
        IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'If the entity is code gen enabled, populate null member codes.';  
        IF @CodeGenEnabled = 1  
        BEGIN  
            --Gather up the valid user provided codes  
            DECLARE @CodesToProcess mdm.MemberCodes;  
            INSERT @CodesToProcess (MemberCode)  
            SELECT MemberCode  
            FROM #MembersWorkingSet          -- new members  
            WHERE   MemberCode IS NOT NULL  
                AND MemberID IS NULL -- exclude pre-existing members, which will have a non-NULL MemberID at this point  
                AND ErrorCode IS NULL  
            UNION -- not "UNION ALL" because deduplication is needed  
            SELECT AttributeValue AS MemberCode  
            FROM #MemberAttributeWorkingSet     -- code attribute changes  
            WHERE   ErrorCode IS NULL  
                AND AttributeID = @AttributeID_Code;  
  
            --Process the user-provided codes to update the code gen info table with the largest one.  
            EXEC mdm.udpProcessCodes @Entity_ID, @CodesToProcess;  
  
            -- When creating leaf members, replace null member codes with autogenerated values.  
            IF      @SaveMode = @SaveMode_Create -- CodeGen only applies to the create operation (not merge)  
                AND @MemberType_ID = @MemberType_Leaf -- CodeGen only applies to leaf members  
            BEGIN  
                DECLARE @NumberOfCodeToGenerate INT = (SELECT COUNT(*) FROM #MembersWorkingSet WHERE MemberCode IS NULL AND ErrorCode IS NULL);  
  
                IF @NumberOfCodeToGenerate > 0  
                BEGIN  
                    DECLARE  
                         @AllocatedRangeStart BIGINT  
                        ,@AllocatedRangeEnd BIGINT;  
                    EXEC mdm.udpGenerateCodeRange   @Entity_ID = @Entity_ID,  
                                                    @NumberOfCodesToGenerate = @NumberOfCodeToGenerate,  
                                                    @CodeRangeStart = @AllocatedRangeStart OUTPUT,  
                                                    @CodeRangeEnd = @AllocatedRangeEnd OUTPUT;  
  
                    DECLARE @AllocatedCodeCounter BIGINT = @AllocatedRangeStart - 1;  
  
                    --Generate any codes the user did not provide  
                    UPDATE #MembersWorkingSet  
                    SET  @AllocatedCodeCounter = @AllocatedCodeCounter + 1  
                        ,MemberCode = CONVERT(NVARCHAR(250), @AllocatedCodeCounter)  
                    WHERE   MemberCode IS NULL  
                        AND ErrorCode IS NULL;  
                END; -- IF @NumberOfCodeToGenerate > 0  
            END; -- IF @MemberType_ID = @MemberType_Leaf  
        END; -- IF @CodeGenEnabled = 1  
  
        -- Replace NULL member MUIDs with new ones.  
        UPDATE #MembersWorkingSet  
        SET MemberMUID = NEWID()  
        WHERE   ErrorCode IS NULL  
            AND MemberMUID IS NULL;  
  
        IF @Changeset_ID IS NULL  
        BEGIN  
            ----------------------------------------------------------------------------------------  
            --Insert new members into the appropriate entity table.  
            ----------------------------------------------------------------------------------------  
            IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Insert new members into the appropriate entity table.';  
            --IDs of new members created.  
            CREATE TABLE #NewMembers  
            (  
                 MemberRowID        INT PRIMARY KEY  
                ,MemberMUID         UNIQUEIDENTIFIER  
                ,MemberID           INT  
                ,MemberCode         NVARCHAR(250) COLLATE DATABASE_DEFAULT  
                ,MemberName         NVARCHAR(250) COLLATE DATABASE_DEFAULT  
            );  
  
            IF @SaveMode IN (@SaveMode_Create, @SaveMode_Merge)  
            BEGIN  
  
                -- Insert the new members into the member table.  
                SET @SQL = CONCAT(@TruncationGuard, N'  
                    MERGE mdm.', @MemberTableName, N'  
                    USING  
                    (  
                        SELECT  
                             mws.Row_ID  
                            ,mws.MemberName  
                            ,mws.MemberCode  
                            ,mws.MemberMUID  
                        FROM #MembersWorkingSet mws  
                        WHERE   mws.ErrorCode IS NULL  
                            AND mws.MemberID IS NULL -- Already existing members (in a Merge operations) will have a non-null MemberID  
                    ) ws  
                    ON (1 = 0) -- An arbitrary condition that is always false, so that the NOT MATCHED block will always be hit.  
                    WHEN NOT MATCHED THEN  
                    INSERT  
                    (  
                         Version_ID  
                        ,Status_ID  
                        ,Name  
                        ,Code',  
                        CASE WHEN @MemberType_ID = @MemberType_Collection THEN N'  
                        ,[Owner_ID]' END, N'  
                        ,EnterDTM  
                        ,EnterUserID  
                        ,EnterVersionID  
                        ,LastChgDTM  
                        ,LastChgUserID  
                        ,LastChgVersionID  
                        ,MUID  
                    )  
                    VALUES  
                    (  
                         @Version_ID  
                        ,', @MemberStatus_Active, N'  
                        ,ws.MemberName  
                        ,ws.MemberCode',  
                        CASE WHEN @MemberType_ID = @MemberType_Collection THEN N'  
                        ,@User_ID' END, N'  
                        ,@CurrentTime  
                        ,@User_ID  
                        ,@Version_ID  
                        ,@CurrentTime  
                        ,@User_ID  
                        ,@Version_ID  
                        ,ws.MemberMUID  
                    )  
                    OUTPUT  
                         ws.Row_ID  
                        ,inserted.MUID  
                        ,inserted.ID  
                        ,inserted.Code  
                        ,inserted.Name  
                    INTO #NewMembers (MemberRowID, MemberMUID, MemberID, MemberCode, MemberName)  
                    ;  
                    ');  
  
                --IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT(@SQL);  
                EXEC sp_executesql @SQL,  
                    N'@User_ID INT, @Version_ID INT, @CurrentTime DATETIME2(3)',  
                      @User_ID,     @Version_ID,     @CurrentTime;  
  
                ----------------------------------------------------------------------------------------  
                --Update working sets with new member Ids.  
                ----------------------------------------------------------------------------------------  
                IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Update working sets with new member Ids.';  
                UPDATE ws  
                SET  ws.MemberID = nm.MemberID  
                    ,ws.IsNewMember = 1  
                FROM #MembersWorkingSet ws  
                INNER JOIN #NewMembers nm  
                ON ws.Row_ID = nm.MemberRowID;  
  
                ----------------------------------------------------------------------------------------  
                -- If DBA working set rows reference one of the newly created members (this is possible when the DBA's domain entity  
                -- is the same as the current entity), set their AttributeValueMapped column to the newly-created member's ID.  
                ----------------------------------------------------------------------------------------  
                IF      @HasDba = 1  
                    AND @MemberType_ID = @MemberType_Leaf -- Only leaf members can be DBA values.  
                BEGIN  
                    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Set DBA attributes'' AttributeValueMapped column to the newly-created member IDs.';  
                    UPDATE ws  
                    SET ws.AttributeValueMapped = nm.MemberID  
                    FROM #MemberAttributeWorkingSet ws  
                    INNER JOIN #DbaReferencesToNewMembers sr  
                    ON ws.Row_ID = sr.AttributeRowID  
                    INNER JOIN #NewMembers nm  
                    ON sr.ParentMemberRowID = nm.MemberRowID;  
                END;  
            END; -- Add new rows to member table  
            -- TODO: update collection working sets.  
  
            ----------------------------------------------------------------------------------------  
            -- Add new Leaf members to all mandatory explicit hierarchies, underneath each hierarchy's ROOT node.  
            ----------------------------------------------------------------------------------------  
            CREATE TABLE #MandatoryExplicitHierarchyIds  
            (  
                ID INT PRIMARY KEY  
            );  
            IF      @IsHierarchyEnabled = 1  
                AND @MemberType_ID = @MemberType_Leaf  
                AND EXISTS(SELECT 1 FROM #NewMembers)  
            BEGIN  
                IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Get the IDs of all mandatory explicit hierarchies.';  
                -- Get the IDs of all mandatory explicit hierarchies.  
                INSERT INTO #MandatoryExplicitHierarchyIds  
                SELECT ID  
                FROM mdm.tblHierarchy  
                WHERE   [Entity_ID] = @Entity_ID  
                    AND IsMandatory = 1;  
  
                IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Add new Leaf members to all mandatory explicit hierarchies.';  
                SET @SQL = CONCAT(@TruncationGuard, N'  
                INSERT INTO mdm.', @HierarchyTableName, N'  
                (  
                     Version_ID  
                    ,Status_ID  
                    ,Hierarchy_ID  
                    ,Parent_HP_ID  
                    ,ChildType_ID  
                    ,Child_EN_ID  
                    ,Child_HP_ID  
                    ,SortOrder  
                    ,LevelNumber  
                    ,EnterDTM  
                    ,EnterUserID  
                    ,EnterVersionID  
                    ,LastChgDTM  
                    ,LastChgUserID  
                    ,LastChgVersionID  
                )  
                SELECT  
                     @Version_ID  
                    ,', @MemberStatus_Active, N'  
                    ,h.ID  
                    ,NULL --Parent_HP_ID  
                    ,', @MemberType_Leaf, N' -- ChildType_ID  
                    ,nm.MemberID --Child_EN_ID  
                    ,NULL --Child_HP_ID  
                    ,0 -- SortOrder, adds the new members to the top because it is better for perf than adding them at the bottom (which would require computing the current maximum sort order, which can be expensive). Users can reorder members later, if desired.  
                    ,-1 -- LevelNumber  
                    ,@CurrentTime  
                    ,@User_ID  
                    ,@Version_ID  
                    ,@CurrentTime  
                    ,@User_ID  
                    ,@Version_ID  
                FROM #NewMembers nm  
                CROSS JOIN #MandatoryExplicitHierarchyIds h  
                ');  
                --IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT(@SQL);  
                EXEC sp_executesql @SQL,  
                    N'@User_ID INT, @Version_ID INT, @Entity_ID INT, @CurrentTime DATETIME2(3)',  
                      @User_ID,     @Version_ID,     @Entity_ID,     @CurrentTime;  
  
            END;  
  
            ----------------------------------------------------------------------------------------  
            -- Update attribute values.  
            ----------------------------------------------------------------------------------------  
            DECLARE @HasAttributeChanges BIT = CASE WHEN EXISTS(SELECT 1 FROM #MemberAttributeWorkingSet WHERE ErrorCode IS NULL) THEN 1 ELSE 0 END;  
            IF @HasAttributeChanges = 1  
            BEGIN  
                ----------------------------------------------------------------------------------------  
                -- Pivot and update entity member table.  
                ----------------------------------------------------------------------------------------  
                IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Pivot and update entity member table.';  
                -- ctePivotRowMerge  
                -- Given this input:  
                --  MemberRowID     AttributeID    AttributeValueMapped  
                --  --------        -------------   --------------------  
                --  1                 10               ABC  
                --  1                 11               1111  
                --  1                 12               Foo  
                --  Pivots to this:  
                --  MemberRowID       [10]             [11]            [12]  
                --  --------        ----------      ----------      ----------  
                --  1                 ABC              1111            Foo  
    SET @SQL = CONCAT(@TruncationGuard, N'  
;WITH ctePivotRowMerge AS  
(  
    SELECT  
         MemberRowID  
        ,SUM(DISTINCT ChangeTrackingMask) ChangeTrackingMask  
        ', @AttributeValueMappedAsColumns, N'  
    FROM #MemberAttributeWorkingSet  
    PIVOT  
    (  
        MAX(AttributeValueMapped)  
        FOR AttributeID IN (', @AttributeIdList, N')  
    ) AS P  
    WHERE   ErrorCode IS NULL  
    GROUP BY MemberRowID  
)  
UPDATE m  
SET  
     ValidationStatus_ID    = @ValidationStatus  
    ,LastChgDTM             = @CurrentTime  
    ,LastChgUserID          = @User_ID  
    ,LastChgVersionID       = @Version_ID'  
    --Update the ChangeTrackingMask only for Leaf  
    --member types (collections do not support this functionality)  
    ,CASE WHEN @MemberType_ID = @MemberType_Leaf THEN N'  
    ,m.ChangeTrackingMask = updates.ChangeTrackingMask ' END,  
    @TableColumnsUpdateDefn, N'{0}  
FROM #MembersWorkingSet mws  
INNER JOIN ctePivotRowMerge updates  
ON mws.Row_ID = updates.MemberRowID  
INNER JOIN mdm.', QUOTENAME(@MemberTableName), N' AS m  
ON      m.Version_ID = @Version_ID   
    AND m.ID = mws.MemberID{1};')  
  
                IF @TransactionLogType = @TransactionLogType_Member  
                BEGIN  
                    SET @SQL = CONCAT(@TruncationGuard, N'  
-- New member attribute, history output is not needed.',  
                        REPLACE(  
                            REPLACE(@SQL,   
                                N'{0}', N''),  
                            N'{1}', N'  
    AND mws.IsNewMember = 1'), N'  
  
-- Existing member attribute, history output is needed, based on @LogFlag.',  
                        REPLACE(  
                            REPLACE(@SQL, N'{0}', CASE @TransactionLogType WHEN @TransactionLogType_Member THEN @GetMemeberHistoryOutputQuery ELSE N'' END),  
                            N'{1}', N'  
    AND mws.IsNewMember = 0'));  
  
                END ELSE  
                BEGIN  
                    SET @SQL = REPLACE(REPLACE(@SQL, N'{0}', N''), N'{1}', N'');  
                END  
  
                IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT @SQL;  
                SET @ValidationStatus =  @ValidationStatus_AwaitingRevalidation;  
                EXEC sp_executesql @SQL, N'@Version_ID INT, @ValidationStatus INT, @CurrentTime DATETIME2(3), @User_ID INT, @SysNull_Text NVARCHAR(1), @SysNull_Number DECIMAL(38,0), @SysNull_DateTime DATETIME2(3), @SysNull_ForeignKey INT',  
                                           @Version_ID,     @ValidationStatus,      @CurrentTime,             @User_ID,     @SysNull_Text,              @SysNull_Number,               @SysNull_DateTime,              @SysNull_ForeignKey;  
  
                ----------------------------------------------------------------------------------------  
                --Update any existing validation issues associated with members whose code has changed  
                --to ensure they reference the new member code.  
                ----------------------------------------------------------------------------------------  
                IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Update any existing validation issues associated with members whose code has changed.';  
                SET @SQL = @TruncationGuard + N'  
                UPDATE v  
                SET v.MemberCode = ws.AttributeValue  
                FROM #MemberAttributeWorkingSet AS ws  
                INNER JOIN [mdm].' + QUOTENAME(@ValidationLogTableName) + N' AS v  
                ON ws.PriorValue = v.MemberCode  
                WHERE   ws.AttributeID = @AttributeID_Code  
                    AND v.MemberType_ID = @MemberType_ID  
                    AND v.Version_ID = @Version_ID  
                    AND ws.ErrorCode IS NULL;  
                ';  
                EXEC sp_executesql @SQL, N'@AttributeID_Code INT, @MemberType_ID TINYINT, @Version_ID INT',  
                                           @AttributeID_Code,     @MemberType_ID,         @Version_ID;  
  
                ----------------------------------------------------------------------------------------  
                --Check for Inheritance Business Rules and update dependent members validation status.  
                ----------------------------------------------------------------------------------------  
                IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Check for Inheritance Business Rules and update dependent members validation status.';  
                IF @DoInheritanceRuleCheck = 1  
                BEGIN  
                    DECLARE @BRInherit TABLE  
                    (  
                         RowNumber                      INT IDENTITY(1,1) NOT NULL  
                        ,DependentAttributeColumnName   SYSNAME COLLATE DATABASE_DEFAULT NOT NULL  
                        ,DependentEntityTable           SYSNAME COLLATE DATABASE_DEFAULT NULL  
                        ,DependentAttributeName         SYSNAME COLLATE DATABASE_DEFAULT NULL  
                        ,DependentAttributeID           INT NULL  
                    );  
  
                    --DBA Inheritance  
                    INSERT INTO @BRInherit (DependentEntityTable, DependentAttributeColumnName)  
                    SELECT DISTINCT  
                         depEnt.EntityTable  
                        ,i.ChildAttributeColumnName  
                    FROM mdm.viw_SYSTEM_BUSINESSRULES_ATTRIBUTE_INHERITANCE_HIERARCHY i  
                    INNER JOIN #AttributeDefinition att  
                    ON i.ParentAttributeName = att.AttributeName  
                    INNER JOIN #MemberAttributeWorkingSet ws  
                    ON att.AttributeID = ws.AttributeID  
                    INNER JOIN mdm.tblEntity depEnt  
                    ON i.ChildEntityID = depEnt.ID  
                    WHERE   ws.ErrorCode IS NULL  
                        AND i.ParentEntityID = @Entity_ID;  
  
                    IF EXISTS(SELECT 1 FROM @BRInherit)  
                    BEGIN  
                        DECLARE  
                             @DependentEntityTableName      NVARCHAR(MAX)  
                            ,@DependentAttributeColumnName  NVARCHAR(MAX);  
                        SELECT  
                             @Counter = 1  
                            ,@MaxCounter = MAX(RowNumber)  
                        FROM @BRInherit;  
  
                        --Loop through each Dba Entity updating the dependent members' validation status.  
                        WHILE @Counter <= @MaxCounter  
                        BEGIN  
                            SELECT  
                                 @DependentEntityTableName = DependentEntityTable  
                                ,@DependentAttributeColumnName = DependentAttributeColumnName  
                             FROM @BRInherit  
                             WHERE [RowNumber] = @Counter ;  
  
                            --Update immediate dependent member table's validation status.  
                            SET @SQL = @TruncationGuard + N'  
                                UPDATE dep  
                                SET dep.ValidationStatus_ID = @ValidationStatus_AwaitingDependentMemberRevalidation  
                                FROM  mdm.' + @DependentEntityTableName + N' dep  
                                INNER JOIN #MembersWorkingSet mws  
                                ON dep.' + @DependentAttributeColumnName + N' = mws.MemberID  
                                INNER JOIN #MemberAttributeWorkingSet aws  
                                ON mws.Row_ID = aws.MemberRowID  
                                WHERE   dep.Version_ID = @Version_ID  
                                    AND aws.ErrorCode IS NULL;  
                                ';  
  
                            --IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT @SQL;  
                            EXEC sp_executesql @SQL,  
                                N'@Version_ID INT, @ValidationStatus_AwaitingDependentMemberRevalidation INT',  
                                 @Version_ID,      @ValidationStatus_AwaitingDependentMemberRevalidation;  
  
                            SET @Counter += 1;  
  
                        END; -- WHILE  
                    END; -- IF @DependentEntityTable  
                END; --IF @DoInheritanceRuleCheck  
  
                ----------------------------------------------------------------------------------------  
                -- File Type attribute  
                -- Remove old record from mdm.tblFile for updates since the new record is being inserted  
                -- in Business Logic Save.  
                ----------------------------------------------------------------------------------------  
                IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'File Type attribute.';  
                IF @HasFile = 1  
                BEGIN  
                    -- Get the IDs of files which should not be deleted  
                    CREATE TABLE #FileIDsToKeep  
                    (  
                        ID INT  
                    );  
  
                    DECLARE @GetFileIdsSQL NVARCHAR(MAX) = mdm.udfFileIDReferencesGetSQL(@Entity_ID, NULL, NULL, 0)  
                    IF LEN(@GetFileIdsSQL) > 0  
                    BEGIN  
                        SET @GetFileIdsSQL = CONCAT(N'INSERT INTO #FileIDsToKeep(ID) ', @GetFileIdsSQL);  
                        EXEC sp_executesql @GetFileIdsSQL;  
                    END;  
  
                    -- IDs of file want to delete  
                    DECLARE @File_ID mdm.IdList;  
                    INSERT INTO @File_ID  
                    SELECT f.ID  
                    FROM mdm.tblFile f  
                    INNER JOIN #MemberAttributeWorkingSet ws  
                    ON ws.PriorFileId = f.ID  
                    INNER JOIN #AttributeDefinition att  
                    ON ws.AttributeID = att.AttributeID  
                    WHERE   ws.ErrorCode IS NULL  
                        AND att.AttributeType_ID = @AttributeType_File;  
  
                    -- Remove file which need to be kept from list  
                    DELETE f  
                    FROM @File_ID f  
                    WHERE EXISTS (Select ftk.ID  
                    FROM #FileIDsToKeep ftk  
                    WHERE f.ID = ftk.ID)  
  
                    EXEC mdm.udpFilesDelete @File_ID = @File_ID, @CorrelationID = @CorrelationID;  
                END;  
            END; -- @HasAttributeChanges = 1  
  
            IF @TransactionLogType = @TransactionLogType_Member  
            BEGIN  
                ----------------------------------------------------------------------------------------  
                --Insert annotation  
                ----------------------------------------------------------------------------------------  
                IF EXISTS(SELECT 1 FROM #MembersWorkingSet WHERE TransactionAnnotation IS NOT NULL AND ErrorCode IS NULL)  
                BEGIN  
                    SET @SQL = CONCAT(N'  
                        INSERT mdm.', @MemberAnnotationTableName, N' (Version_ID, Revision_ID, Comment, EnterUserID, LastChgUserID)  
                        SELECT @Version_ID, m.LastChgTS, mws.TransactionAnnotation, @User_ID, @User_ID  
                        FROM #MembersWorkingSet mws  
                        INNER JOIN mdm.' + @MemberTableName + N' m ON mws.MemberID = m.ID  
                        WHERE mws.TransactionAnnotation IS NOT NULL AND mws.ErrorCode IS NULL;');  
  
                    --PRINT(@SQL);  
                    EXEC sp_executesql @SQL, N'@User_ID INT, @Version_ID INT', @User_ID, @Version_ID;  
                END  
  
                IF EXISTS(SELECT 1 FROM #MemberAttributeWorkingSet WHERE TransactionAnnotation IS NOT NULL AND ErrorCode IS NULL)  
                BEGIN  
                    SET @SQL = CONCAT(N'  
                        INSERT mdm.', @MemberAnnotationTableName, N' (Version_ID, Revision_ID, Comment, EnterUserID, LastChgUserID)  
                        SELECT @Version_ID, m.LastChgTS, ws.TransactionAnnotation, @User_ID, @User_ID  
                        FROM #MemberAttributeWorkingSet ws  
                        INNER JOIN #MembersWorkingSet mws ON mws.Row_ID = ws.MemberRowID  
                        INNER JOIN mdm.' + @MemberTableName + N' m ON mws.MemberID = m.ID  
                        WHERE ws.TransactionAnnotation IS NOT NULL AND ws.ErrorCode IS NULL;');  
  
                    --PRINT(@SQL);  
                    EXEC sp_executesql @SQL, N'@User_ID INT, @Version_ID INT', @User_ID, @Version_ID;  
                END  
            END -- IF @TransactionType = @TransactionType_Row  
            ELSE IF @TransactionLogType = @TransactionLogType_Attribute  
            BEGIN  
                ----------------------------------------------------------------------------------------  
                --Log transactions.  
                ----------------------------------------------------------------------------------------  
                IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Log new member transactions.';  
  
                CREATE TABLE #TransactionAnnotations  
                (  
                     TransactionID  INT  
                    ,Annotation     NVARCHAR(500) COLLATE DATABASE_DEFAULT   
                );  
  
                ----------------------------------------------------------------------------------------  
                -- Log member add transactions.  
                ----------------------------------------------------------------------------------------  
                IF EXISTS(SELECT 1 FROM #NewMembers)  
                BEGIN  
                    -- Note that using a MERGE instead of an INSERT statement allows the TransactionAnnotation column to be  
                    -- matched with the TransactionID using the OUTPUT statement, rather than having to do an additional  
                    -- (potentially expensive) JOIN on the transaction table.  
                    SET @SQL = CONCAT(N'  
                    MERGE [mdm].', QUOTENAME(@TransactionTableName), N'  
                    USING  
                    (  
                        SELECT  
                             nm.MemberID  
                            ,nm.MemberMUID  
                            ,nm.MemberCode  
                            ,ws.TransactionAnnotation  
                        FROM #NewMembers nm  
                        INNER JOIN #MembersWorkingSet ws  
                        ON nm.MemberRowID = ws.Row_ID  
                    ) ws  
                    ON (1 = 0) -- An arbitrary condition that is always false, so that the NOT MATCHED block will always be hit.  
                    WHEN NOT MATCHED THEN  
                    INSERT  
                    (  
                         Version_ID  
                        ,TransactionType_ID  
                        ,OriginalTransaction_ID  
                        ,Hierarchy_ID  
                        ,[Entity_ID]  
                        ,Attribute_ID  
                        ,Member_ID  
                        ,Member_MUID  
                        ,MemberType_ID  
                        ,MemberCode  
                        ,OldValue  
                        ,OldCode  
                        ,NewValue  
                        ,NewCode  
                        ,EnterDTM  
                        ,EnterUserID  
                        ,LastChgDTM  
                        ,LastChgUserID  
                    )  
                    VALUES  
                    (  
                         @Version_ID  
                        ,@TransactionType_Create --TransactionType_ID  
                        ,0 --OriginalTransaction_ID  
                        ,NULL-- Hierarchy_ID  
                        ,@Entity_ID  
                        ,NULL -- Attribute_ID  
                        ,ws.MemberID  
                        ,ws.MemberMUID  
                        ,@MemberType_ID  
                        ,ws.MemberCode  
                        ,N'''' --OldValue  
                        ,N'''' --OldCode  
                        ,N'''' --NewValue  
                        ,N'''' --NewCode  
                        ,@CurrentTime  
                        ,@User_ID  
                        ,@CurrentTime  
                        ,@User_ID  
                    )  
                    OUTPUT                       inserted.ID,   ws.TransactionAnnotation  
                    INTO #TransactionAnnotations(TransactionID, Annotation) -- Note: it wouldn''t be appropriate to output directly into annotation table here because we want to filter out empty annotations  
                    ;  
                    ');  
                    EXEC sp_executesql @SQL, N'@Version_ID INT, @TransactionType_Create INT, @Entity_ID INT, @MemberType_ID TINYINT, @CurrentTime DATETIME2(3), @User_ID INT',  
                                               @Version_ID,     @TransactionType_Create,     @Entity_ID,     @MemberType_ID,         @CurrentTime,              @User_ID;  
  
                    ----------------------------------------------------------------------------------------  
                    -- Log Leaf members added to the ROOT node of mandatory explicit hierarchies.  
                    ----------------------------------------------------------------------------------------  
                    IF EXISTS(SELECT 1 FROM #MandatoryExplicitHierarchyIds)  
                    BEGIN  
                        IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Log Leaf members added to the ROOT node of mandatory explicit hierarchies.';  
                        DECLARE @RootCode NVARCHAR(10) = N'ROOT'; -- The member code of the top-level explicit hierarchy node.  
  
                        SET @SQL = CONCAT(N'  
                        MERGE [mdm].', QUOTENAME(@TransactionTableName), N'  
                        USING  
                        (  
                            SELECT  
                                 nm.MemberID  
                                ,nm.MemberMUID  
                                ,nm.MemberCode  
                                ,ws.TransactionAnnotation  
                                ,h.ID [HierarchyID]  
                            FROM #NewMembers nm  
                            INNER JOIN #MembersWorkingSet ws  
                            ON nm.MemberRowID = ws.Row_ID  
                            CROSS JOIN #MandatoryExplicitHierarchyIds h  
                        ) ws  
                        ON (1 = 0) -- An arbitrary condition that is always false, so that the NOT MATCHED block will always apply.  
                        WHEN NOT MATCHED THEN  
                        INSERT  
                        (  
                             Version_ID  
                            ,TransactionType_ID  
                            ,OriginalTransaction_ID  
                            ,Hierarchy_ID  
                            ,[Entity_ID]  
                            ,Member_ID  
                            ,Member_MUID  
                            ,MemberType_ID  
                            ,MemberCode  
                            ,OldValue  
                            ,OldCode  
                            ,NewValue  
                            ,NewCode  
                            ,EnterDTM  
                            ,EnterUserID  
                            ,LastChgDTM  
                            ,LastChgUserID  
                        )  
                        VALUES  
                        (  
                             @Version_ID  
                            ,@TransactionType_HierarchyParentSet  
                            ,0 -- OriginalTransaction_ID  
                            ,ws.[HierarchyID]  
                            ,@Entity_ID  
                            ,ws.MemberID  
                            ,ws.MemberMUID  
                            ,@MemberType_ID  
                            ,ws.MemberCode  
                            ,0 -- OldValue  
                            ,@RootCode -- OldCode  
                            ,0 -- NewValue  
                            ,@RootCode -- NewCode  
                            ,@CurrentTime  
                            ,@User_ID  
                            ,@CurrentTime  
                            ,@User_ID  
                        )  
                        OUTPUT                       inserted.ID,   ws.TransactionAnnotation  
                        INTO #TransactionAnnotations(TransactionID, Annotation);  
                        ');  
                        EXEC sp_executesql @SQL, N'@Version_ID INT, @TransactionType_HierarchyParentSet INT, @Entity_ID INT, @MemberType_ID TINYINT, @RootCode NVARCHAR(10), @CurrentTime DATETIME2(3), @User_ID INT',  
                                                    @Version_ID,     @TransactionType_HierarchyParentSet,     @Entity_ID,     @MemberType_ID,         @RootCode,              @CurrentTime,              @User_ID;  
  
                    END; -- IF exists mandatory explicit hierarchies.  
                END;-- IF added new members.  
  
                ----------------------------------------------------------------------------------------  
                -- Log attribute value change transactions.  
                ----------------------------------------------------------------------------------------  
                IF @HasAttributeChanges = 1  
                BEGIN  
                    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Log attribute value change transactions.';  
  
                    SET @SQL = N'  
                    MERGE [mdm].' + QUOTENAME(@TransactionTableName) + N'  
                    USING  
                    (  
                        SELECT  
                             mws.MemberID  
                            ,mws.MemberMUID  
                            ,mws.MemberCode  
                            ,aws.AttributeID  
                            ,aws.PriorValueMapped  
                            ,aws.PriorValue  
                            ,aws.AttributeValueMapped  
                            ,aws.AttributeValue  
                            ,aws.TransactionAnnotation  
                        FROM #MemberAttributeWorkingSet aws  
                        INNER JOIN #MembersWorkingSet mws  
                        ON aws.MemberRowID = mws.Row_ID  
                        WHERE aws.ErrorCode IS NULL  
                    ) ws  
                    ON (1 = 0) -- An arbitrary condition that is always false, so that the NOT MATCHED block will always apply.  
                    WHEN NOT MATCHED THEN  
                    INSERT  
                    (  
                         Version_ID  
                        ,TransactionType_ID  
                        ,OriginalTransaction_ID  
                        ,Hierarchy_ID  
                        ,[Entity_ID]  
                        ,Attribute_ID  
                        ,Member_ID  
                        ,Member_MUID  
                        ,MemberType_ID  
                        ,MemberCode  
                        ,OldValue  
                        ,OldCode  
                        ,NewValue  
                        ,NewCode  
                        ,EnterDTM  
                        ,EnterUserID  
                        ,LastChgDTM  
                        ,LastChgUserID  
                    )  
                    VALUES  
                    (  
                         @Version_ID  
                        ,@TransactionType_Update -- TransactionType_ID  -- Attribute value change  
                        ,0 -- OriginalTransaction_ID  
                        ,NULL --HierarchyID  
                        ,@Entity_ID  
                        ,ws.AttributeID  
                        ,ws.MemberID  
                        ,ws.MemberMUID  
                        ,@MemberType_ID  
                        ,ws.MemberCode  
                        ,ws.PriorValueMapped -- OldValue  
                        ,ws.PriorValue     -- OldCode  
                        ,ws.AttributeValueMapped -- NewValue  
                        ,ws.AttributeValue     --NewCode  
                        ,@CurrentTime  
                        ,@User_ID  
                        ,@CurrentTime  
                        ,@User_ID  
                    )  
                    OUTPUT                       inserted.ID,   ws.TransactionAnnotation  
                    INTO #TransactionAnnotations(TransactionID, Annotation);  
                    ';  
                    EXEC sp_executesql @SQL, N'@Version_ID INT, @TransactionType_Update INT, @Entity_ID INT, @MemberType_ID TINYINT, @CurrentTime DATETIME2(3), @User_ID INT',  
                                               @Version_ID,     @TransactionType_Update,     @Entity_ID,     @MemberType_ID,         @CurrentTime,              @User_ID;  
                END;  
                ----------------------------------------------------------------------------------------  
                --Add any transaction annotations.  
                ----------------------------------------------------------------------------------------  
                IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Add any transaction annotations.';  
  
                SET @SQL = N'  
                INSERT INTO [mdm].' + QUOTENAME(@TransactionAnnotationTableName) + N'  
                (  
                     Version_ID  
                    ,Transaction_ID  
                    ,Comment  
                    ,EnterUserID  
                    ,EnterDTM  
                    ,LastChgDTM  
                    ,LastChgUserID  
                )  
                SELECT  
                     @Version_ID  
                    ,TransactionID  
                    ,Annotation  
                    ,@User_ID  
                    ,@CurrentTime  
                    ,@CurrentTime  
                    ,@User_ID  
                FROM #TransactionAnnotations  
                WHERE NULLIF(Annotation, N'''') IS NOT NULL  
                ';  
                EXEC sp_executesql @SQL, N'@Version_ID INT, @CurrentTime DATETIME2(3), @User_ID INT',  
                                           @Version_ID,     @CurrentTime,              @User_ID;  
            END -- IF @TransactionType = @TransactionType_Column  
  
            ----------------------------------------------------------------------------------------  
            -- Update the member security (MS) tables(s) as appropriate for the new/updated members.  
            --  
            -- Note that this is being done after writing to the log table, to avoid having the  
            -- Service Broker asynchronously kick off an expensive update to the MS table while the  
            -- expensive (but synchronous) log write is happening and slowing it down.  
            ----------------------------------------------------------------------------------------  
            IF @MemberType_ID = @MemberType_Leaf -- Member security only applies to Leaf members.  
            BEGIN  
                DECLARE @NeedToUpdateMemberSecurity BIT = 0;  
  
                ----------------------------------------------------------------------------------------  
                -- If member security applies to the current user then add rows to the MS table for new members, so that the creating user can access them.  
                ----------------------------------------------------------------------------------------  
                IF @MemberSecurity = 1  
                    AND EXISTS(SELECT 1 FROM #NewMembers)  
                BEGIN  
                    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Add the appropriate member security records for new members.';  
                    -- Get the role for the user  
                    SELECT @SecurityRoleID = Role_ID  
                    FROM mdm.tblSecurityAccessControl  
                    WHERE   Principal_ID = @User_ID  
                        AND PrincipalType_ID = 1 /*User*/;  
  
                    -- Role ID can be null for a user when user permissions are inherited only from a group. The permission for the member added  
                    -- should be set to update for the user. This requires that the security role be added for the user.  
                    -- Correct security permissions are applied when the member security update batch process is run by the Service Broker.  
                    IF (@SecurityRoleID IS NULL)  
                    BEGIN  
                        DECLARE @Principal_Name NVARCHAR (100) = (SELECT UserName FROM mdm.tblUser WHERE ID = @User_ID);  
  
                        INSERT INTO mdm.tblSecurityRole  
                        (  
                             [Name]  
                            ,EnterUserID  
                            ,LastChgUserID  
                        )  
                        VALUES  
                        (  
                             CONCAT(N'Role for UserAccount ', @Principal_Name)  
                            ,@User_ID  
                            ,@User_ID  
                        );  
                        SET @SecurityRoleID = SCOPE_IDENTITY() ;  
  
                        INSERT INTO mdm.tblSecurityAccessControl  
                        (  
                             PrincipalType_ID  
                            ,Principal_ID  
                            ,Role_ID  
                            ,[Description]  
                            ,EnterUserID  
                            ,LastChgUserID  
                        )  
                        VALUES  
                        (  
                             @PrincipalType_User  
                            ,@User_ID  
                            ,@SecurityRoleID  
                            ,LEFT(@Principal_Name + N'UserAccount ', 110)  
                            ,@User_ID  
                            ,@User_ID  
                        );  
                    END; -- IF (@SecurityRoleID IS NULL)  
  
                    -- Add records to the MS table for the user which created the members so the members will be visible to the creator  
                    SET @SQL = CONCAT(@TruncationGuard, N'  
                        INSERT INTO mdm.', @SecurityTableName, N'  
                        (  
                             Version_ID  
                            ,User_ID  
                            ,ID  
                            ,AccessPermission  
                        )  
                        SELECT  
                             @Version_ID  
                            ,@User_ID  
                            ,nm.MemberID  
                            ,', @AccessPermission_All, N'  
                        FROM #NewMembers AS nm  
                        ;');  
                    EXEC sp_executesql @SQL ,N'@Version_ID INT, @User_ID INT'  
                                            ,@Version_ID,       @User_ID;  
  
                    SET @NeedToUpdateMemberSecurity = 1;  
                END  -- IF new members created and current user has member security  
  
                IF @HasAttributeChanges = 1  
                BEGIN  
                    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Determine if member security needs to be updated.';  
                    -- Determine if member security needs to be updated because either  
                    --  1. a DBA has been updated and that DBA's domain entity is a  
                    -- part of a derived hierarchy that has a member security permission, or  
                    --  2. New member(s) have been added and the current entity is part of a derived hierarchy with member security.  
                    --  
                    WITH changedDbaEntityId AS -- The domain entities of the domain-based attributes that have been updated.  
                    (  
                        SELECT DISTINCT  
                            att.Dba_Entity_ID AS [Entity_ID]  
                        FROM #MemberAttributeWorkingSet ws  
                        INNER JOIN #AttributeDefinition att  
                        ON ws.AttributeID = att.AttributeID  
                        WHERE   ws.ErrorCode IS NULL  
                            AND att.AttributeType_ID = @AttributeType_DBA  
                        UNION -- not "UNION ALL" because deduplication is needed  
  
                        -- Include the current Entity if new members were added.  
                        SELECT @Entity_ID  
                        WHERE EXISTS(SELECT 1 FROM #NewMembers)  
                    ),  
                    securedLevels AS -- The derived hierarchies that have member security, with their topmost level to which a member security assignment applies.  
                    (  
                        SELECT  
                             sram.DerivedHierarchy_ID  
                            ,MIN(CASE sram.Member_ID WHEN 0 THEN -1 ELSE lvl.LevelNumber END) AS LevelNumber -- If Member_ID is zero, then the permission applies to the ROOT (level -1) of the  hierarchy  
                        FROM mdm.tblSecurityRoleAccessMember sram  
                        LEFT JOIN mdm.viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED_LEVELS lvl  
                        ON      sram.DerivedHierarchy_ID = lvl.Hierarchy_ID -- Explicit hierarchy member permissions are ignored since this sproc won't change EH parent-child relationships.  
                            AND sram.Version_ID = @Version_ID  
                            AND lvl.[Entity_ID] = sram.[Entity_ID]  
                        GROUP BY sram.DerivedHierarchy_ID  
                    ),  
                    securedEntityId AS -- The domain entities to which security applies  
                    (  
                        SELECT DISTINCT  
                            lvl.[Entity_ID]  
                        FROM mdm.viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED_LEVELS lvl  
                        INNER JOIN securedLevels sec  
                        ON      lvl.Hierarchy_ID = sec.DerivedHierarchy_ID  
                            AND lvl.[Entity_ID] > 0  
                            AND lvl.LevelNumber > sec.LevelNumber -- Only domain entities underneath a member security assignment require the MS table to be recalculated  
                    ),  
                    updateNeeded AS  
                    (  
                        SELECT TOP 1  
                            1 UpdateNeeded  
                        FROM changedDbaEntityId dba  
                        INNER JOIN securedEntityId ent  
                        ON dba.[Entity_ID] = ent.[Entity_ID]  
                    )  
                    SELECT  
                        @NeedToUpdateMemberSecurity = UpdateNeeded  
                    FROM updateNeeded;  
                END; -- DBA changes  
  
                IF (@NeedToUpdateMemberSecurity = 1)  
                BEGIN  
                    ----------------------------------------------------------------------------------------  
                    -- Put a message onto the Service Broker queue to process member security.  
                    ----------------------------------------------------------------------------------------  
                    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Put a message onto the Service Broker queue to process member security.';  
                    EXEC mdm.udpSecurityMemberQueueSave  
                        @User_ID    = NULL,-- update member security for all users  
                        @Version_ID = @Version_ID,  
                        @Entity_ID  = @Entity_ID;  
                END;  
  
            END; -- IF @MemberType_ID = @MemberType_Leaf  
  
            ----------------------------------------------------------------------------------------  
            --Done creating/updating members. Update the entity.  
            ----------------------------------------------------------------------------------------  
            IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Update the entity audit info.';  
            UPDATE mdm.tblEntity  
            SET  LastChgDTM = @CurrentTime  
                ,LastChgUserID = @User_ID  
                ,LastChgVersionID = @Version_ID  
            WHERE ID = @Entity_ID;  
  
            --------------------------------------------------  
            -- Return created members, if requested.  
            --------------------------------------------------  
            IF @ReturnCreatedMembers = 1  
            BEGIN  
                IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Return created members.';  
                SELECT  
                     MemberID  
                    ,MemberMUID  
                    ,MemberCode  
                    ,MemberName  
                FROM #NewMembers;  
            END;  
        END -- End update member table  
        ELSE  
        BEGIN  -- Begin update PD table  
            -- Insert the new members into the pending table.  
            IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Insert the new members into the pending table.';  
            SET @SQL = CONCAT(N'  
                INSERT mdm.', @PendingTableName, N'  
                (  
                     Version_ID  
                    ,CS_ID  
                    ,EN_ID  
                    ,Status_ID  
                    ,Name  
                    ,Code  
                    ,EnterDTM  
                    ,EnterUserID  
                    ,LastChgDTM  
                    ,LastChgUserID  
                    ,Revision_ID  
                    ,MUID  
                )  
                SELECT  
                    @Version_ID  
                    ,@Changeset_ID  
                    ,ws.MemberID  
                    ,', @MemberStatus_Active, '  
                    ,CASE WHEN ws.MemberID IS NULL THEN ws.MemberName ELSE NULL END  
                    ,CASE WHEN ws.MemberID IS NULL THEN ws.MemberCode ELSE NULL END  
                    ,@CurrentTime  
                    ,@User_ID  
                    ,@CurrentTime  
                    ,@User_ID  
                    ,MIN_ACTIVE_ROWVERSION() + ws.Row_ID - 1  
                    ,ws.MemberMUID  
                    FROM #MembersWorkingSet ws  
                    LEFT JOIN mdm.', @PendingTableName, N' m  
                    ON ws.MemberMUID = m.MUID AND m.Version_ID = @Version_ID AND m.CS_ID = @Changeset_ID  
                    WHERE ws.ErrorCode IS NULL  
                        AND m.MUID IS NULL;');  
  
            EXEC sp_executesql @SQL,  
                    N'@User_ID INT, @Version_ID INT, @Changeset_ID INT, @CurrentTime DATETIME2(3)',  
                      @User_ID,     @Version_ID,     @Changeset_ID,     @CurrentTime;  
  
            IF @ReturnCreatedMembers = 1  
            BEGIN  
                SELECT  
                     0 MemberID  
                    ,MemberMUID  
                    ,MemberCode  
                    ,MemberName  
                FROM #MembersWorkingSet  
                WHERE MemberID IS NULL  
                    AND ErrorCode IS NULL;  
            END;  
  
            IF EXISTS(SELECT 1 FROM #MemberAttributeWorkingSet WHERE ErrorCode IS NULL)  
            BEGIN  
                IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Update pending table.';  
                SET @SQL = CONCAT(N'  
;WITH ctePivotRowMerge AS  
(  
    SELECT  
         MemberRowID  
        ', @AttributeValueMappedAsColumns, N'  
    FROM #MemberAttributeWorkingSet  
    PIVOT  
    (  
        MAX(AttributeValueMapped)  
        FOR AttributeID IN (', @AttributeIdList, N')  
    ) AS P  
    WHERE   ErrorCode IS NULL  
    GROUP BY MemberRowID  
),  
ctePivotRowIsChanged AS  
(  
    SELECT  
         MemberRowID  
        ', @AttributeValueMappedAsColumns, N'  
    FROM (  
        SELECT MemberRowID, AttributeID, ErrorCode, CONVERT(TINYINT, IsChanged) IsChanged  
        FROM #MemberAttributeWorkingSet  
    ) source  
    PIVOT  
    (  
        MAX(IsChanged)  
        FOR AttributeID IN (', @AttributeIdList, N')  
    ) AS P  
    WHERE   ErrorCode IS NULL  
    GROUP BY MemberRowID  
)  
UPDATE m  
SET  
     LastChgDTM = @CurrentTime  
    ,LastChgUserID = @User_ID  
    ', @TableColumnsUpdateDefn, N'  
FROM #MembersWorkingSet mws  
INNER JOIN ctePivotRowMerge updates  
ON mws.Row_ID = updates.MemberRowID  
INNER JOIN ctePivotRowIsChanged isChanged  
ON mws.Row_ID = isChanged.MemberRowID  
INNER JOIN mdm.', QUOTENAME(@PendingTableName), N' AS m  
ON      m.Version_ID = @Version_ID   
    AND m.MUID = mws.MemberMUID  
    AND m.CS_ID = @Changeset_ID;')  
  
                IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT @SQL;  
  
                EXEC sp_executesql @SQL,  
                    N'@User_ID INT, @Version_ID INT, @Changeset_ID INT, @CurrentTime DATETIME2(3), @SysNull_Text NVARCHAR(1), @SysNull_Number DECIMAL(38,0), @SysNull_DateTime DATETIME2(3), @SysNull_ForeignKey INT',  
                      @User_ID,     @Version_ID,     @Changeset_ID,     @CurrentTime,              @SysNull_Text,              @SysNull_Number,               @SysNull_DateTime,              @SysNull_ForeignKey;  
            END;  
        END -- End update PD table  
  
        --------------------------------------------------  
        -- Commit transaction only if not nested.  
        --------------------------------------------------  
        IF @TranCounter = 0  
        BEGIN  
            IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Commit the transaction.';  
            COMMIT TRANSACTION;  
        END;  
  
        IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'Done.';  
         RETURN 1;  
  
    END TRY  
    BEGIN CATCH  
  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        -- Roll back the transaction.  
        IF @Debug = 1  
        BEGIN  
            DECLARE @LogMessage NVARCHAR(MAX) = N'Roll back the transaction. Error message: ' + COALESCE(@ErrorMessage, N'NULL');  
            /*EXEC mdm.udpLogMessage*/ PRINT @LogMessage;  
        END;  
  
        IF @TranCounter = 0 ROLLBACK TRANSACTION;  
        ELSE IF XACT_STATE() <> -1 ROLLBACK TRANSACTION TX;  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
  
    END CATCH;  
  
    IF @Debug = 1 /*EXEC mdm.udpLogMessage*/ PRINT N'udpEntityMembersSave ended.'  
    SET NOCOUNT OFF;  
END; --proc
go

