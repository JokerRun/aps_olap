/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE [mdm].[udpUserSave]  
(  
    @SystemUser_ID      INT,  
    @User_ID            INT = NULL OUTPUT,  
    @User_MUID          UNIQUEIDENTIFIER = NULL OUTPUT, -- \  
    @SID                NVARCHAR(250) = NULL OUTPUT,    -- - One of these is required  
    @Name               NVARCHAR(100) = NULL,           -- /  
    @Status_ID          TINYINT,  
    @DisplayName        NVARCHAR(256) = NULL,  
    @Description        NVARCHAR(500) = NULL,  
    @EmailAddress       NVARCHAR(100) = NULL,  
    @CorrelationID      UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS  
BEGIN  
    SET NOCOUNT ON  
  
    DECLARE @GuidEmpty              UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER),  
  
            @Status_Create          INT = 0,  
            @Status_Activate        INT = 1,  
            @Status_Deactive        INT = 2,  
            @Status_Clone           INT = 3,  
  
            @UserStatus_ID          TINYINT,  
            @UserStatus_Active      TINYINT = 1,  
            @UserStatus_Deactive    TINYINT = 2,  
              
            @OldUser_MUID           UNIQUEIDENTIFIER,  
            @OldUser_SID            NVARCHAR(250),  
            @ErrorMessage           NVARCHAR(4000);  
  
    SELECT   
        @User_MUID = NULLIF(@User_MUID, @GuidEmpty),  
        @SID = NULLIF(LTRIM(RTRIM(@SID)), N''),  
        @Name = NULLIF(LTRIM(RTRIM(@Name)), N''),  
        @DisplayName = NULLIF(LTRIM(RTRIM(@DisplayName)), N''),  
        @Description = NULLIF(LTRIM(RTRIM(@Description)), N''),  
        @EmailAddress = NULLIF(LTRIM(RTRIM(@EmailAddress)), N'');  
  
    SELECT @User_ID = ID, @OldUser_MUID = MUID, @OldUser_SID = [SID]  
    FROM mdm.tblUser  
    WHERE  
        (@User_MUID IS NOT NULL OR @SID IS NOT NULL OR @Name IS NOT NULL)  
        AND (@Status_ID = @Status_Clone OR @User_MUID  IS NULL OR MUID = @User_MUID)  
        AND (@SID IS NULL OR [SID] = @SID)  
  
    -- New user  
    IF @User_ID IS NULL  
    BEGIN  
  
        IF @Status_ID = @Status_Activate OR @Status_ID = @Status_Deactive  
        BEGIN  
            RAISERROR('MDSERR500004|The principal cannot be updated because the principal identifier is not valid. The identifier must have an existing GUID, name, or both.', 16, 1);  
            RETURN  
        END  
  
        -- For new user, the name and sid should be unique  
        IF EXISTS(  
            SELECT 1  
            FROM mdm.tblUser  
            WHERE  
                (@SID IS NOT NULL OR @Name IS NOT NULL)  
                AND ((@SID IS NOT NULL AND [SID] = @SID)  
                    OR (@Name IS NOT NULL AND UserName = @Name))  
        )  
        BEGIN  
            SELECT  @ErrorMessage = N'MDSERR500015|Name and Security Identifier (SID) combination must be unique for user update, create, and copy operations. Name: {0}, Security Identifier: {1}.|' + REPLACE(@Name, N'|', N'') + '|' + @SID;  
            SET @ErrorMessage = REPLACE(@ErrorMessage, '%', '%%')-- escape out format specifier  
            RAISERROR(@ErrorMessage, 16, 1, @Name, @SID);  
        END  
  
        IF @User_MUID IS NULL  
        BEGIN  
            IF @Status_ID = @Status_Clone  
            BEGIN  
                RAISERROR('MDSERR500004|The principal cannot be updated because the principal identifier is not valid. The identifier must have an existing GUID, name, or both.', 16, 1);  
                RETURN  
            END  
            ELSE  
            BEGIN  
                SET @User_MUID = NEWID();  
            END  
        END  
  
        INSERT INTO mdm.tblUser  
        (  
            [Status_ID],  
            [UserName],  
            [SID],  
            [DisplayName],  
            [Description],  
            [EmailAddress],  
            [EnterUserID],  
            [LastChgUserID],  
            [MUID]  
        )  
        SELECT  
            @UserStatus_Active,  
            @Name,  
            @SID,  
            COALESCE(@DisplayName,N''),  
            @Description,  
            @EmailAddress,  
            @SystemUser_ID,  
            @SystemUser_ID,  
            @User_MUID  
  
        SET @User_ID = SCOPE_IDENTITY();  
    END  
    ELSE  
    BEGIN  
        SET @UserStatus_ID = CASE @Status_ID WHEN @Status_Deactive THEN @UserStatus_Deactive ELSE @UserStatus_Active END;  
  
        IF @Status_ID != @Status_Clone OR @User_MUID IS NULL  
        BEGIN  
            UPDATE tblUser  
            SET Status_ID = @UserStatus_ID,  
                UserName = COALESCE(@Name, UserName),  
                DisplayName = COALESCE(@DisplayName, DisplayName),  
                [Description] = COALESCE(@Description, [Description]),  
                EmailAddress = COALESCE(@EmailAddress, EmailAddress),  
                LastChgUserID = @SystemUser_ID,  
                LastChgDTM = GETUTCDATE()  
            WHERE ID = @User_ID  
            SET @User_MUID = @OldUser_MUID;  
        END  
        ELSE  
        BEGIN  
            UPDATE tblUser  
            SET MUID = @User_MUID,  
                Status_ID = @UserStatus_ID,  
                UserName = COALESCE(@Name, UserName),  
                DisplayName = COALESCE(@DisplayName, DisplayName),  
                [Description] = COALESCE(@Description, [Description]),  
                EmailAddress = COALESCE(@EmailAddress, EmailAddress),  
                LastChgUserID = @SystemUser_ID,  
                LastChgDTM = GETUTCDATE()  
            WHERE ID = @User_ID  
        END  
  
        SET @SID = @OldUser_SID;  
    END  
  
    SET NOCOUNT OFF  
END;
go

