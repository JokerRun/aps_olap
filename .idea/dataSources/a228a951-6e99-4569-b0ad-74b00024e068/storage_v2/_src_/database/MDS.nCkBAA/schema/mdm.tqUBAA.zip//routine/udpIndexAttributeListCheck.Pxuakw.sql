/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpIndexAttributeListCheck  
(  
    @Attribute_MUID		    UNIQUEIDENTIFIER,  
    @IsUnique               BIT,  
    @Return_ID              INT = NULL OUTPUT,  
    @CorrelationID          UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON  
  
  
    DECLARE	@AttributeID   INT,  
            @AttributeTypeID TINYINT;  
  
    --Default the Value  
    SELECT @Return_ID = 0;  
  
    SELECT @AttributeID = ID, @AttributeTypeID = AttributeType_ID FROM mdm.tblAttribute WHERE MUID = @Attribute_MUID  
  
    IF (@IsUnique = 0 ) BEGIN  
        IF @AttributeTypeID = 2 BEGIN --domain-based attribute  
            SET @Return_ID = 1;  
        END ELSE IF ((SELECT IsName FROM mdm.tblAttribute where ID = @AttributeID) = 1 ) BEGIN --There already exists a non-unique index on Name  
            SET @Return_ID = 2;  
        END  
    END ELSE BEGIN --There is a unique index on Code  
        IF ((SELECT IsCode FROM mdm.tblAttribute where ID = @AttributeID) = 1) BEGIN  
            SET @Return_ID = 3;  
        END  
    END  
    SET NOCOUNT OFF;  
END; --proc
go

