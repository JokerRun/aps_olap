/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
No need check user permission.  
The permission should be checked on BusinessRuleItem level  
*/  
CREATE PROCEDURE mdm.udpBusinessRuleItemPropertySave  
(  
    @SaveMode               TINYINT = 0, -- 0 = Create, 1 = Clone, 2 = Update    
    @BRItem_ID              INT = NULL,    
    @PropertyType_ID        INT = NULL,    
    @PropertyName_ID        INT = NULL,    
    @Value                  NVARCHAR(999) = NULL, -- possible values: freeform/blank string, Attribute muid, Hierarchy muid, or AttributeValue code    
    @AttributeName          NVARCHAR(128) = NULL, -- optional    
    @Sequence               INT = NULL,    
    @IsLeftHandSide         BIT = NULL,    
    @Parent_ID              INT = NULL,    
    @SuppressText           BIT = NULL,    
    @MUID                   UNIQUEIDENTIFIER = NULL OUTPUT, /*Input and output*/    
    @ID                     INT = NULL OUTPUT, /*Output only*/    
    @BypassUdsValidation     BIT = 0,  
    @CorrelationID          UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability    
)    
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN    
    SET NOCOUNT ON    
    
    DECLARE    
        @ValueMuid                          UNIQUEIDENTIFIER,    
    
        @SaveMode_Create                    TINYINT = 0,    
        @SaveMode_Clone                     TINYINT = 1,    
        @SaveMode_Update                    TINYINT = 2,    
    
        @PropertyType_Constant              INT = 1,    
        @PropertyType_Attribute             INT = 2,    
        @PropertyType_ParentAttribute       INT = 3,    
        @PropertyType_DBAAttribute          INT = 4,    
        @PropertyType_AttributeValue        INT = 5,    
        @PropertyType_Blank                 INT = 6,    
        @PropertyType_ChangeTrackingGroup   INT = 7,    
        @PropertyType_UserScriptParameter   INT = 8,    
    
        @GuidEmpty                          UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER);    
    
    SELECT    
        @Parent_ID = NULLIF(@Parent_ID, 0),    
        @BRItem_ID = NULLIF(@BRItem_ID, 0),    
        @MUID = NULLIF(@MUID, @GuidEmpty),    
        @ID = NULL;    
    
    IF @SaveMode = @SaveMode_Clone    
    BEGIN    
        IF @MUID IS NOT NULL AND EXISTS (SELECT 1 FROM mdm.tblBRItemProperties WHERE MUID = @MUID)    
        BEGIN    
            SET @SaveMode = @SaveMode_Update;    
        END    
        ELSE    
        BEGIN    
            SET @SaveMode = @SaveMode_Create;    
        END    
    END    
    
    IF @SaveMode = @SaveMode_Create    
    BEGIN    
        SET @MUID = COALESCE(@MUID, NEWID());    
    END    
    
    IF @SaveMode = @SaveMode_Update    
    BEGIN    
        -- made sure a MUID of an existing row was given    
        IF @MUID IS NULL OR NOT EXISTS (SELECT 1 FROM mdm.tblBRItemProperties WHERE MUID = @MUID)    
        BEGIN    
            RAISERROR('MDSERR400001|The Update operation failed. The MUID was not found.', 16, 1);    
            RETURN;    
        END    
    END    
    
    /*    
        The meaning of @Value's input value depends on @PropertyType_ID,    
        as given in the below table:    
    
           @PropertyType_ID         @Value (input)      @Value (output)    
          ******************       ****************    *****************    
            1 (Constant)            freeform string        unchanged    
            2 (Attribute)           Attribute MUID         int ID    
            3 (ParentAttribute)     Hierarchy MUID         int ID    
            4 (DBAAttribute)        Attribute MUID         int ID    
            5 (AttributeValue)      Code (i.e. 'Blue')     unchanged    
            6 (Blank)               doesn't matter         'Blank'    
            8 (UserScriptParameter) string(parameter name)    unchanged    
    
        @Value's output value will contain the correct value for writing to    
        tblBRItemProperties.Value.    
        For @PropertyType_ID values 2 and 4, if @Value's input value is null or invalid,    
        then the Attribute's int ID will be looked up from the given @AttributeName.    
        In all other cases, @AttributeName is ignored.    
    */    
    
    -- TODO EMMAYIN CHECK DATE TYPE COMPATIBILITY    
    IF @PropertyType_ID IN (@PropertyType_Attribute, @PropertyType_ParentAttribute, @PropertyType_DBAAttribute)    
    BEGIN    
        -- try to convert @Value to a GUID    
        BEGIN TRY    
            SET @ValueMuid = CONVERT(UNIQUEIDENTIFIER, @Value)    
        END TRY    
        BEGIN CATCH    
            SET @ValueMuid = NULL    
        END CATCH    
    END    
    
    IF @PropertyType_ID IN (@PropertyType_Attribute, @PropertyType_DBAAttribute)    
    BEGIN    
        IF @ValueMuid IS NOT NULL    
        BEGIN    
            -- lookup the Attribute's ID from its MUID    
            SET @Value = CONVERT(NVARCHAR(999), (SELECT ID FROM mdm.tblAttribute WHERE MUID = @ValueMuid));    
        END    
    
        IF @Value IS NULL AND @AttributeName IS NOT NULL    
        BEGIN    
            -- lookup the Attribute ID from the given @AttributeName    
            SET @Value = CONVERT(NVARCHAR(999),(    
                SELECT a.Attribute_ID    
                FROM mdm.tblBRItem it    
                 INNER JOIN mdm.tblBRLogicalOperatorGroup lg    
                 ON it.ID = @BRItem_ID    
                    AND it.BRLogicalOperatorGroup_ID = lg.ID    
                 INNER JOIN mdm.viw_SYSTEM_SCHEMA_BUSINESSRULES b    
                 ON lg.BusinessRule_ID = b.BusinessRule_ID    
                 INNER JOIN mdm.viw_SYSTEM_SCHEMA_ATTRIBUTES a    
                 ON a.Attribute_Name = @AttributeName    
                    AND b.Entity_ID = a.Entity_ID));    
        END    
    
        IF @Value IS NULL    
        BEGIN    
            RAISERROR('MDSERR400003|The attribute reference is not valid. The attribute was not found.', 16, 1);    
            RETURN;    
        END    
    END ELSE IF @PropertyType_ID = @PropertyType_ParentAttribute    
    BEGIN    
        -- lookup the Hierarchy's ID from its MUID    
        SET @Value = CONVERT(NVARCHAR(999), (SELECT ID FROM mdm.tblHierarchy WHERE MUID = @ValueMuid));    
    
        IF @Value IS NULL    
        BEGIN    
            RAISERROR('MDSERR400021|The hierarchy identifier is not valid. The MUID was not found.', 16, 1);    
            RETURN;    
        END    
    END    
    ELSE IF @PropertyType_ID = @PropertyType_AttributeValue    
    BEGIN    
        -- @Value is a member code, so trim its whitespace. Note that the member code should not be validated (i.e. checked to make sure    
        -- there exists a member with the specified code) here, so that it is possible for Model Deployment to deploy business rules with metadata, but    
        -- without master data.    
        SET @Value = LTRIM(RTRIM(@Value));    
    END    
    ELSE    
    IF @PropertyType_ID = @PropertyType_Blank    
    BEGIN    
        SET @Value = CONVERT(NVARCHAR(999), N'Blank')    
    END    
    ELSE IF @PropertyType_ID = 8 AND @BypassUdsValidation = 0   
    BEGIN -- User defined script name    
        DECLARE @BRItemAnchorName NVARCHAR(256),    
                @ErrorMsg NVARCHAR(MAX),    
                @AppliesToAction BIT;    
    
        -- Verify if corresponding BRItem's BRItemType is UserDefinedScript (ID:34)    
        SET @Value = LTRIM(RTRIM(@Value));    
    
        SELECT @BRItemAnchorName = AnchorName, @AppliesToAction = via.BRTypeID-1    
        FROM mdm.tblBRItem item    
        INNER JOIN mdm.viw_SYSTEM_SCHEMA_BUSINESSRULE_ITEMTYPES via    
        ON item.BRItemAppliesTo_ID = via.AppliesTo_ID    
        WHERE item.ID = @BRItem_ID AND via.BRItemType_ID = 34    
    
        IF @BRItemAnchorName = NULL    
        BEGIN    
            RAISERROR('MDSERR400063|Cannot assign a script parameter to a non user script business rule item.', 16, 1);    
            RETURN    
        END    
    
        SET @Sequence = NULL    
    
        SELECT @Sequence = P.parameter_id    
        FROM sys.objects AS SO    
        INNER JOIN sys.parameters AS P    
        ON SO.object_id = P.object_id    
        WHERE P.name = @Value    
            AND SO.object_id IN (    
                SELECT object_id    
                FROM sys.objects    
                WHERE type = (CASE WHEN @AppliesToAction = 1 THEN N'P' ELSE N'FN' END)    
                    AND schema_id = SCHEMA_ID(N'usr')    
                    AND name = @BRItemAnchorName)    
    
        IF @Sequence IS NULL    
        BEGIN    
            SET @ErrorMsg = 'MDSERR400064|The parameter {0} is not defined in {1}.|'+ @Value+'|'+ @BRItemAnchorName    
            SET @ErrorMsg = REPLACE(@ErrorMsg, '%', '%%')-- escape out format specifier    
            RAISERROR(@ErrorMsg, 16, 1);    
            RETURN    
        END    
    END    
    
    IF @SaveMode = @SaveMode_Create    
    BEGIN    
        -- add row    
        INSERT INTO mdm.tblBRItemProperties (    
            MUID,    
            BRItem_ID,    
            PropertyType_ID,    
            PropertyName_ID,    
            [Value],    
            [Sequence],    
            IsLeftHandSide,    
            Parent_ID,    
            SuppressText    
        )    
        VALUES (    
            @MUID,    
            @BRItem_ID,    
            @PropertyType_ID,    
            @PropertyName_ID,    
            @Value,    
            @Sequence,    
            @IsLeftHandSide,    
            @Parent_ID,    
            @SuppressText    
        );    
    
        -- set output params    
        IF @@ERROR = 0    
        BEGIN    
            SET @ID = SCOPE_IDENTITY();    
        END    
    END    
    ELSE    
    BEGIN    
        -- update row    
        UPDATE mdm.tblBRItemProperties    
        SET BRItem_ID = @BRItem_ID,    
            PropertyType_ID = @PropertyType_ID,    
            PropertyName_ID = @PropertyName_ID,    
            [Value] = @Value,    
            [Sequence] = @Sequence,    
            IsLeftHandSide = @IsLeftHandSide,    
            Parent_ID = @Parent_ID,    
            SuppressText = @SuppressText    
        WHERE MUID = @MUID    
    
        -- set output params    
        IF @@ERROR = 0    
        BEGIN    
            SELECT @ID = ID FROM mdm.tblBRItemProperties WHERE MUID = @MUID;    
        END    
    END    
    
    SET NOCOUNT OFF    
END
go

