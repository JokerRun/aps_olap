/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
/*  
Resolves model and entity muid and name to the corresponding ID  
  
Sample call: EXEC mdm.udpGetModelEntityIDByName NULL, N'Customer', NULL, N'Customer', @ModelID OUT, @EntityID OUT  
  
*/  
CREATE PROCEDURE [mdm].[udpModelEntityGetIDByName]  
(  
    @Model_MUID				UNIQUEIDENTIFIER = NULL,  
    @Model_Name				NVARCHAR(50) = NULL,  
    @Entity_MUID			UNIQUEIDENTIFIER = NULL,   
    @Entity_Name			NVARCHAR(50) = NULL,  
    @Model_ID				INT OUT,  
    @Entity_ID				INT OUT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
AS BEGIN  
    DECLARE @Invalid_ID INT = -1  
  
    SELECT @Model_ID = mdm.udfModelGetIDByName(@Model_MUID, @Model_Name);  
    -- filter invalid model name/muid  
    if ((@Model_MUID IS NOT NULL) OR  (@Model_Name IS NOT NULL)) AND (@Model_ID IS NULL)  
    BEGIN  
        SELECT @Model_ID =  @Invalid_ID  
    END  
  
    SELECT @Entity_ID = CASE   
                            WHEN (@Entity_MUID IS NULL) AND (@Entity_Name IS NULL) THEN NULL  
                            ELSE mdm.udfEntityGetIDByName(@Model_MUID, @Model_Name, @Entity_MUID, @Entity_Name)  
                        END	  
END
go

