/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
This method is a temporary substitute for the SQL CLR function. It should be removed when SQL Azure adds support for SQL CLR.  
  
DECLARE @IsNumeric BIT = NULL;  
  
EXEC mdq.udpIsNumber NULL, @IsNumeric OUTPUT; -- 0  
EXEC mdq.udpIsNumber N'123.45', @IsNumeric OUTPUT; -- 1  
EXEC mdq.udpIsNumber N'123', @IsNumeric OUTPUT; -- 1  
EXEC mdq.udpIsNumber N'foo', @IsNumeric OUTPUT; -- 0  
  
*/  
CREATE PROCEDURE mdq.udpIsNumber  
(  
    @Input NVARCHAR(MAX) = NULL,  
    @IsNumeric BIT OUTPUT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
AS  
BEGIN  
    IF @Input IS NULL  
    BEGIN  
        SET @IsNumeric = 0;  
    END ELSE  
    BEGIN   
        BEGIN TRY  
            DECLARE @Numeric DECIMAL = CONVERT(DECIMAL, @Input);  
            SET @IsNumeric = 1;  
        END TRY  
        BEGIN CATCH  
            SET @IsNumeric = 0;  
        END CATCH;  
    END;  
END;
go

