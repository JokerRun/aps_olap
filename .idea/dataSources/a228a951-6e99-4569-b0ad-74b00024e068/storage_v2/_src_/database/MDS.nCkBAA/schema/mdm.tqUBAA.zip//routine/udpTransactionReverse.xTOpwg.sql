/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
exec mdm.udpTransactionReverse @User_ID = 1, @Model_ID = 7, @Transaction_ID = 41  
  
select * from mdm.tbl1HPAccount where version_ID = 3  
*/  
CREATE PROCEDURE mdm.udpTransactionReverse  
(  
    @User_ID	    INT,  
	@Model_ID       INT,  
    @Transaction_ID INT,  
    @Return_ID		INT = NULL OUTPUT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    DECLARE @TempStatus_ID TINYINT  
    DECLARE @OriginalVersion_ID AS INT  
    DECLARE @OriginalTransactionType_ID AS INT  
    DECLARE @OriginalHierarchy_ID  AS INT  
    DECLARE @OriginalEntity_ID  AS INT  
    DECLARE @OriginalMember_ID  AS INT  
    DECLARE @OriginalMemberMUID  AS UNIQUEIDENTIFIER  
    DECLARE @OriginalMemberType_ID  AS TINYINT  
    DECLARE @OriginalMemberCode AS NVARCHAR(250)  
    DECLARE @OriginalAttribute_ID  AS INT  
    DECLARE @OriginalAttributeName AS NVARCHAR(100)  
    DECLARE @OriginalOldValue AS NVARCHAR(max)  
    DECLARE @OriginalOldCode AS NVARCHAR(max)  
    DECLARE @OriginalNewValue AS NVARCHAR(max)  
    DECLARE @OriginalNewCode AS NVARCHAR(max)  
    DECLARE @OriginalTargetMemberType_ID TINYINT  
    DECLARE @TransactionTableName sysname;  
    DECLARE @SQL NVARCHAR(MAX);  
    DECLARE @TransactionType_CreateMember INT = 1;  
    DECLARE @TransactionType_ChangeMemberStatus INT = 2;  
    DECLARE @TransactionType_SetAttributeValue INT = 3;  
    DECLARE @TransactionType_MoveToParent INT = 4;  
    DECLARE @TransactionType_MoveToSibling INT = 5;  
    DECLARE @TransactionType_MemberAnnotate INT = 6;  
  
    DECLARE  
         @MemberStatus_Active           TINYINT = 1  
        ,@MemberStatus_Deactivated      TINYINT = 2  
        ,@MemberIds                     mdm.MemberId;  
  
    --Validate model id  
    IF NOT EXISTS(SELECT 1 FROM mdm.tblModel WHERE ID = @Model_ID)  
    BEGIN  
        RAISERROR('MDSERR100010|The Parameters are not valid.', 16, 1);  
        RETURN(1);  
    END  
  
    SET @TransactionTableName = mdm.udfGetTransactionTableName(@Model_ID);      
	      
    --Create a constant like value for the logging flag to pass  
    --into the procedures that will actually be doing the reversing.  
    --We do NOT want those procedures to create a transaction log entry,  
    --for the reversal, as this procedure will do that. Otherwise 2 entries  
    --will be added to the transaction table.  
    DECLARE @LoggingFlag BIT = 0;  
      
    --As an alternative to returning an error when the transaction type isn't supported for reversal,  
    --the @RunTransactionSave is checked to see if a transaction reversal save should be run. Default  
    --to "no".   
    DECLARE @RunTransactionSave INT  
    SELECT @RunTransactionSave = 0  
  
    --Get the Original Transaction Information  
    SET @SQL = N'  
    SELECT   
        @OriginalVersion_ID = T.Version_ID,  
        @OriginalTransactionType_ID = T.TransactionType_ID,  
        @OriginalHierarchy_ID = T.Hierarchy_ID,  
        @OriginalEntity_ID = T.Entity_ID,  
        @OriginalAttribute_ID = T.Attribute_ID,  
        @OriginalMember_ID = T.Member_ID,  
        @OriginalMemberMUID = T.Member_MUID,  
        @OriginalMemberType_ID = T.MemberType_ID,  
        @OriginalMemberCode = T.MemberCode,  
        @OriginalOldValue = T.OldValue,  
        @OriginalOldCode = T.OldCode,  
        @OriginalNewValue = T.NewValue,  
        @OriginalNewCode = T.NewCode  
  
	FROM  
        [mdm].' + QUOTENAME(@TransactionTableName) + N' T  
    WHERE  
        ID = @Transaction_ID;  
    ';  
    EXEC sp_executesql @SQL, N'@OriginalVersion_ID INT OUTPUT, @OriginalTransactionType_ID INT OUTPUT, @OriginalHierarchy_ID INT OUTPUT, @OriginalEntity_ID INT OUTPUT, @OriginalAttribute_ID INT OUTPUT, @OriginalMember_ID INT OUTPUT, @OriginalMemberMUID UNIQUEIDENTIFIER OUTPUT, @OriginalMemberType_ID TINYINT OUTPUT, @OriginalMemberCode NVARCHAR(250) OUTPUT, @OriginalOldValue NVARCHAR(MAX) OUTPUT, @OriginalOldCode NVARCHAR(MAX) OUTPUT, @OriginalNewValue NVARCHAR(MAX) OUTPUT, @OriginalNewCode NVARCHAR(MAX) OUTPUT, @Transaction_ID INT',  
                               @OriginalVersion_ID OUTPUT,     @OriginalTransactionType_ID OUTPUT,     @OriginalHierarchy_ID OUTPUT,     @OriginalEntity_ID OUTPUT,     @OriginalAttribute_ID OUTPUT,     @OriginalMember_ID OUTPUT,     @OriginalMemberMUID OUTPUT,                  @OriginalMemberType_ID OUTPUT,         @OriginalMemberCode OUTPUT,               @OriginalOldValue OUTPUT,               @OriginalOldCode OUTPUT,               @OriginalNewValue OUTPUT,               @OriginalNewCode OUTPUT,               @Transaction_ID;  
  
    --Figure out whether we are looking at a reversible transaction type  
    --Member annotation transactions cannot be reversed at all  
    IF @OriginalTransactionType_ID  = @TransactionType_MemberAnnotate  
    BEGIN  
        RAISERROR('MDSERR310059|Transaction of this type cannot be reversed.', 16, 1);  
        RETURN(1);  
    END  
  
    --Start transaction, being careful to check if we are nested  
    DECLARE @TranCounter INT = @@TRANCOUNT;  
    IF @TranCounter > 0   
    BEGIN  
        SAVE TRANSACTION TX;  
    END ELSE   
    BEGIN  
        BEGIN TRANSACTION;  
    END;  
  
    BEGIN TRY  
        --Member Create  
        IF @OriginalTransactionType_ID = @TransactionType_CreateMember  
        BEGIN  
            INSERT INTO @MemberIds(ID, MemberType_ID)  
            VALUES (@OriginalMember_ID, @OriginalMemberType_ID)  
          
            -- Deactivate (soft-delete) the member.  
            EXEC mdm.udpMembersStatusSet   
                 @User_ID = @User_ID  
                ,@Model_ID = @Model_ID  
                ,@Version_ID = @OriginalVersion_ID  
                ,@Entity_ID = @OriginalEntity_ID  
                ,@MemberIds = @MemberIds  
                ,@MemberType_ID = @OriginalMemberType_ID  
                ,@Status_ID = @MemberStatus_Deactivated  
                ,@LogFlag = @LoggingFlag  
                ,@RaiseFirstError = 1  
  
            SET @RunTransactionSave = 1;  
  
            -- Undoing a Create transaction means soft-deleting (deactivating) the created member. So change the old value fields to look like reverting a transaction that activated the member.  
            SET @OriginalTransactionType_ID = @TransactionType_ChangeMemberStatus;  
            SET @OriginalNewValue = @MemberStatus_Active;  
            SET @OriginalOldValue = @MemberStatus_Deactivated;  
        END  
        --Member Status Set  
        ELSE IF @OriginalTransactionType_ID = @TransactionType_ChangeMemberStatus  
        BEGIN  
            INSERT INTO @MemberIds(ID, MemberType_ID)  
            VALUES (@OriginalMember_ID, @OriginalMemberType_ID)  
  
            DECLARE @OriginalStatus TINYINT = CONVERT(TINYINT, @OriginalOldValue);  
            EXEC mdm.udpMembersStatusSet   
                 @User_ID = @User_ID  
                ,@Model_ID = @Model_ID  
                ,@Version_ID = @OriginalVersion_ID  
                ,@Entity_ID = @OriginalEntity_ID  
                ,@MemberIds = @MemberIds  
                ,@MemberType_ID = @OriginalMemberType_ID  
                ,@Status_ID = @OriginalStatus  
                ,@LogFlag = @LoggingFlag  
                ,@RaiseFirstError = 1  
            SELECT @RunTransactionSave = 1  
        END  
        --Set Attribute Value  
        ELSE IF @OriginalTransactionType_ID = @TransactionType_SetAttributeValue  
        BEGIN  
            DECLARE  
                 @Members           mdm.MemberSaveList  
                ,@MemberAttributes  mdm.MemberAttributeValues;  
  
            INSERT INTO @Members(RowID, MemberMUID)  
            VALUES (1, @OriginalMemberMUID);  
  
            INSERT INTO @MemberAttributes(MemberRowID, AttributeID, AttributeValue)  
            VALUES (1, @OriginalAttribute_ID, @OriginalOldValue)  
  
            EXEC mdm.udpEntityMembersSave  
                 @User_ID = @User_ID  
                ,@Model_ID = @Model_ID  
                ,@Version_ID = @OriginalVersion_ID  
                ,@Entity_ID = @OriginalEntity_ID  
                ,@MemberType_ID = @OriginalMemberType_ID  
                ,@Members = @Members  
                ,@MemberAttributes = @MemberAttributes  
                ,@SaveMode = 3 -- Update  
                ,@LogFlag = @LoggingFlag  
                ,@ValidateDataTypes = 0 -- Shouldn't be necessary to revalidate the old value, since it would have been validated when originally set.  
                ,@ErrorReportingType = 4 -- Raise first error  
            SELECT @RunTransactionSave = 1  
        END  
        --Move Member to Parent AND Move Member to Sibling  
        --The reason why this is used for both is because we don't store the SortOrder of the original location  
        --Also, we store the original parent NOT the closest sibling of the original location  
        --So there is currently no way to navigate back to the exact location  
        ELSE IF @OriginalTransactionType_ID IN (@TransactionType_MoveToParent, @TransactionType_MoveToSibling)  
        BEGIN  
            DECLARE @OriginalOldValueInt INT = CONVERT(INT, @OriginalOldValue);  
            EXEC mdm.udpMemberTypeIDAndIDGetByCode @OriginalVersion_ID, @OriginalEntity_ID, @OriginalMemberCode, @OriginalTargetMemberType_ID OUTPUT  
            EXEC mdm.udpMemberStatusIDGetByMemberID @OriginalVersion_ID, @OriginalEntity_ID, @OriginalOldValueInt, 2, @TempStatus_ID OUTPUT  
            --Check to see if Target is Disabled, if so goto Root  
            DECLARE @HierarchyMembers AS mdm.HierarchyMembers    
            INSERT INTO @HierarchyMembers   
                (Hierarchy_ID,          Child_ID,           ChildCode,          ChildMemberType_ID,     TargetType_ID) VALUES   
                (@OriginalHierarchy_ID, @OriginalMember_ID, @OriginalMemberCode, @OriginalMemberType_ID, 1/*Parent*/);  
            IF @TempStatus_ID = (SELECT OptionID FROM mdm.tblList where ListCode = CAST(N'lstStatus' AS NVARCHAR(50)) AND ListOption = CAST(N'Deleted' AS NVARCHAR(250)))  
            BEGIN  
                UPDATE @HierarchyMembers  
                SET TargetMemberType_ID = 2/*Consolidated*/;  
            END  
            ELSE  
            BEGIN  
                UPDATE @HierarchyMembers  
                SET  
                    Target_ID = CONVERT(INT, @OriginalOldValue),  
                    TargetCode = CONVERT(NVARCHAR(250), @OriginalOldCode),  
                    TargetMemberType_ID = @OriginalTargetMemberType_ID;  
            END; --if  
          
            SET @LoggingFlag = 1;-- Have the below sproc update the transaction log (note that @RunTransactionSave is being left zero)  
            EXECUTE mdm.udpHierarchyMembersUpdate @User_ID=@User_ID, @Version_ID=@OriginalVersion_ID, @Entity_ID=@OriginalEntity_ID, @HierarchyMembers=@HierarchyMembers, @OriginalTransaction_ID=@Transaction_ID, @LogFlag=@LoggingFlag;   
      
        END; --if  
      
        --Only log a transaction record if something was actually reversed.  
        IF @RunTransactionSave = 1  
        BEGIN    
            -- log this transaction reverse. Since this is logging the reversal,  
            -- the oldvalue is stored in the new value column, and the New value is stored  
            -- in the old value column.  
            EXEC mdm.udpTransactionSave   
                @User_ID = @User_ID,  
                @Version_ID	= @OriginalVersion_ID,  
                @TransactionType_ID = @OriginalTransactionType_ID,  
                @OriginalTransaction_ID  = @Transaction_ID,  
                @Hierarchy_ID = @OriginalHierarchy_ID,  
                @Entity_ID = @OriginalEntity_ID,  
                @Member_ID = @OriginalMember_ID,  
                @MemberType_ID = @OriginalMemberType_ID,  
                @Attribute_ID = @OriginalAttribute_ID,  
                @OldValue = @OriginalNewValue,  
                @NewValue = @OriginalOldValue,  
                @Return_ID = @Return_ID OUTPUT;  
        END  
  
        --Commit only if we are not nested.  
        IF @TranCounter = 0   
        BEGIN  
            COMMIT TRANSACTION;  
        END;  
  
    END TRY  
    --Compensate as necessary  
    BEGIN CATCH  
  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
                  
        IF @TranCounter = 0   
        BEGIN  
            ROLLBACK TRANSACTION;  
        END ELSE IF XACT_STATE() <> -1   
        BEGIN  
            ROLLBACK TRANSACTION TX;  
        END;  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
    END CATCH;  
  
    SET NOCOUNT OFF;  
END; --proc
go

