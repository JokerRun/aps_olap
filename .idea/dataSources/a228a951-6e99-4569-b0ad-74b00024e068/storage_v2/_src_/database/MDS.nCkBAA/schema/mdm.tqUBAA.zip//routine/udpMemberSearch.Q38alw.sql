/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
*** NOTE: ANY CHANGES TO THE COLUMNS RETURNED IN THIS PROCEDURE MUST BE MADE IN THE COMPANION STORED PROCEDURE: mdm.udpSecurityHierarchyMemberSearchPrivilegesGet.  
  
  
EXEC mdm.udpMemberSearch @User_ID =1, @Version_ID = 3, @Hierarchy_ID = 1, @HierarchyType_ID = 0, @Entity_ID = 1, @SearchTerm = 'it''s'  
EXEC mdm.udpMemberSearch @User_ID =1, @Version_ID = 3, @Hierarchy_ID = 1, @HierarchyType_ID = 0, @Entity_ID = 1, @SearchTerm = '%profit%'  
--Derived Hierarchy  
EXEC mdm.udpMemberSearch @User_ID =1, @Version_ID = 19, @Hierarchy_ID = 7, @HierarchyType_ID = 1, @Entity_ID = 0, @SearchTerm = 'BK%'  
*/  
CREATE PROCEDURE mdm.udpMemberSearch  
(  
    @User_ID            INT,  
    @Version_ID         INT,  
    @Hierarchy_ID       INT,  
    @HierarchyType_ID   TINYINT,  
    @Entity_ID          INT,  
    @SearchTerm         NVARCHAR(500),  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED  
    DECLARE @ParamList          NVARCHAR(MAX),  
    @SQLString                  NVARCHAR(MAX),  
    @TempCNName                 NVARCHAR(100),  
    @Entity_Muid                UNIQUEIDENTIFIER,  
    @Hierarchy_Muid             UNIQUEIDENTIFIER,  
    @ViewName                   SYSNAME,  
    @EntitySecurityTable        SYSNAME,  
    @HierarchyParentSecurityTable   SYSNAME,  
    @LeafPrivilege_ID           INT,  
    @LeafAccessPermission       TINYINT,  
    @ConsolidatedPrivilege_ID   INT,  
    @ConsolidatedAccessPermission   TINYINT,  
    @CollectionPrivilege_ID     INT,  
    @CollectionAccessPermission TINYINT,  
    @PrivilegeID                INT,  
    @UseMemberSecurity          BIT,  
    @MemberSecurityCTE          NVARCHAR(MAX),  
  
    @MemberType_Leaf                TINYINT = 1,  
    @MemberType_Consolidated        TINYINT = 2,  
      
    @HierarchyType_Explicit         TINYINT = 0,  
    @HierarchyType_Derived          TINYINT = 1,  
    @HierarchyType_Collection       TINYINT = 2;  
  
  
    IF @Entity_ID IS NOT NULL --When searching a derived hierarchy the entity might not be passed in  
    BEGIN  
        --SELECT @LeafPrivilege_ID = mdm.udfSecurityUserMemberDefault(@User_ID, @Entity_ID, 3, 1)  
        --SELECT @ConsolidatedPrivilege_ID = mdm.udfSecurityUserMemberDefault(@User_ID, @Entity_ID, 3, 2)  
        --SELECT @CollectionPrivilege_ID = mdm.udfSecurityUserMemberDefault(@User_ID, @Entity_ID, 3, 3)  
        --PERF - moved these calls to a udp to decrease the execution plan compile time.  
        EXEC mdm.udpSecurityUserMemberType @User_ID = @User_ID, @Entity_ID = @Entity_ID, @MemberType_ID = 1, @Privilege_ID = @LeafPrivilege_ID OUTPUT, @AccessPermission = @LeafAccessPermission OUTPUT;  
        EXEC mdm.udpSecurityUserMemberType @User_ID = @User_ID, @Entity_ID = @Entity_ID, @MemberType_ID = 2, @Privilege_ID = @ConsolidatedPrivilege_ID OUTPUT, @AccessPermission = @LeafAccessPermission OUTPUT;  
        EXEC mdm.udpSecurityUserMemberType @User_ID = @User_ID, @Entity_ID = @Entity_ID, @MemberType_ID = 3, @Privilege_ID = @CollectionPrivilege_ID OUTPUT, @AccessPermission = @LeafAccessPermission OUTPUT;  
  
        SELECT  
            @EntitySecurityTable = CAST(EntityTable + '_MS' AS SYSNAME),  
            @HierarchyParentSecurityTable = CASE WHEN HierarchyParentTable IS NOT NULL THEN CAST(HierarchyParentTable + '_MS' AS SYSNAME) ELSE NULL END  
        FROM mdm.tblEntity  
        WHERE ID = @Entity_ID;  
  
        SET @UseMemberSecurity = mdm.udfUseMemberSecurity(@User_ID, @Entity_ID, @Version_ID, NULL);  
  
        IF @LeafPrivilege_ID = 99  
        BEGIN  
            SET @LeafPrivilege_ID = 4; -- Access  
            SET @LeafAccessPermission = 0; -- ReadOnly  
        END  
        IF @ConsolidatedPrivilege_ID = 99  
        BEGIN  
            SET @ConsolidatedPrivilege_ID = 4; -- Access  
            SET @ConsolidatedAccessPermission = 0; -- ReadOnly  
        END  
  
        --These cte's are selectively added to the overall query based on if member security is needed to be applied  
        SET @MemberSecurityCTE = CONCAT(N'  
        WITH membersresolved as  
        (  
            SELECT  
                ID AS Member_ID,  
                ', @MemberType_Leaf, N' AS MemberType_ID,  
                AccessPermission  
            FROM  
                mdm.', QUOTENAME(@EntitySecurityTable), N' X  
            WHERE X.User_ID = @User_ID  
                AND X.Version_ID = @Version_ID',  
                CASE  
                    WHEN @HierarchyParentSecurityTable IS NOT NULL THEN CONCAT(N'  
            UNION ALL  
            SELECT  
                ID AS Member_ID,  
                ', @MemberType_Consolidated, N' AS MemberType_ID,  
                AccessPermission  
            FROM  
                mdm.', QUOTENAME(@HierarchyParentSecurityTable), N' X  
            WHERE X.User_ID = @User_ID  
                AND X.Version_ID = @Version_ID')  
                    ELSE N''  
                END, N'  
        )');  
  
    END  
  
  
  
    IF @HierarchyType_ID = @HierarchyType_Explicit  
    BEGIN  
        SELECT @ViewName   = mdm.udfViewNameGetByID(@Entity_ID, 4, 0, 0)  
        SELECT @Entity_Muid=MUID FROM mdm.tblEntity WHERE ID=@Entity_ID  
        SELECT @Hierarchy_Muid=MUID FROM mdm.tblHierarchy WHERE ID=@Hierarchy_ID  
  
        SELECT @SQLString = CASE @UseMemberSecurity WHEN 1 THEN @MemberSecurityCTE ELSE '' END + N'  
                SELECT TOP 500  
                    Child_Code AS Code,  
                    Child_Name AS Name,  
                    CONVERT(int,T.ChildType_ID) AS ChildType_ID,  
                    @Entity_Muid AS ChildEntity_MUID,  
                    Parent_Code AS ParentCode,  
                    Parent_Name AS ParentName,  
                    2 AS ParentType_ID,  
                    @Entity_Muid AS ParentEntity_MUID,  
                    @Hierarchy_Muid AS RelationshipId,  
                    2 AS RelationshipTypeId, --2 is Hierarchy ItemType '  
                    IF @UseMemberSecurity <> 0 SET @SQLString = @SQLString + N'  
                    @LeafPrivilege_ID AS Privilege_ID, CONVERT(INTEGER,ISNULL(SR.AccessPermission, @LeafAccessPermission)) AS AccessPermission'  
                    ELSE IF @UseMemberSecurity = 0 SET @SQLString = @SQLString + N'  
                    @LeafPrivilege_ID AS Privilege_ID, @LeafAccessPermission as AccessPermission'  
                    SET @SQLString = @SQLString + N'  
  
                FROM  
                    mdm.' + QUOTENAME(@ViewName) + N' T '  
        IF @UseMemberSecurity <> 0 SET @SQLString = @SQLString + N'  
                LEFT JOIN membersresolved SR  
                    ON SR.MemberType_ID = T.ChildType_ID  
                    AND SR.Member_ID = T.Child_ID'  
  
        SELECT @SQLString = @SQLString + N'  
                WHERE  
                    T.Version_ID = @Version_ID AND  
                    Hierarchy_ID = @Hierarchy_ID AND '  
        IF @UseMemberSecurity <> 0  
        BEGIN  
            SET @SQLString += N'  
                    (SR.Privilege_ID IS NOT NULL OR T.ChildType_ID <> 1) AND';  
        END  
        SELECT @SQLString = @SQLString + N'  
                    (  
                        Child_Code LIKE @SearchTerm  
                    OR Child_Name LIKE @SearchTerm  
                    )  
                ORDER BY T.Child_ID'  
  
        SET @ParamList = CAST(N'@Entity_ID   INT  
            , @LeafPrivilege_ID             INT  
            , @LeafAccessPermission         TINYINT  
            , @User_ID                      INT  
            , @Version_ID                   INT  
            , @SearchTerm                   NVARCHAR(500)  
            , @ConsolidatedPrivilege_IDx    INT  
            , @Hierarchy_ID                 INT  
            , @Entity_Muid                    UNIQUEIDENTIFIER  
            , @Hierarchy_Muid               UNIQUEIDENTIFIER' AS NVARCHAR(max))  
  
        EXEC sp_executesql @SQLString, @ParamList  
                ,@Entity_ID  
                ,@LeafPrivilege_ID  
                ,@LeafAccessPermission  
                ,@User_ID  
                ,@Version_ID  
                ,@SearchTerm  
                ,@ConsolidatedPrivilege_ID  
                ,@Hierarchy_ID  
                ,@Entity_Muid  
                ,@Hierarchy_Muid  
  
    END  
    ELSE IF @HierarchyType_ID = @HierarchyType_Derived  
    BEGIN  
  
        DECLARE   
             @Model_ID          INT  
            ,@IsModelAdmin      BIT = 0  
              
            ,@Permission_Admin  TINYINT = 5;  
  
        SELECT   
             @Model_ID = dh.Model_ID   
            ,@IsModelAdmin = CASE WHEN m.Privilege_ID = @Permission_Admin THEN 1 ELSE 0 END  
        FROM mdm.tblDerivedHierarchy dh  
        LEFT JOIN mdm.viw_SYSTEM_SECURITY_USER_MODEL m  
        ON dh.Model_ID = m.ID  
        WHERE dh.ID = @Hierarchy_ID  
  
        SELECT @ViewName = CONCAT(N'viw_SYSTEM_', @Model_ID, N'_', @Hierarchy_ID, N'_PARENTCHILD_DERIVED')  
  
        IF @IsModelAdmin = 0  
        BEGIN  
            -- Need to check security for each entity. Store the results in a temp table for processing  
            CREATE TABLE #Matches  
            (  
                 Code               NVARCHAR(250) COLLATE DATABASE_DEFAULT  
                ,Name               NVARCHAR(250) COLLATE DATABASE_DEFAULT  
                ,Child_ID           INT  
                ,ChildType_ID       INT  
                ,ChildEntity_ID     INT  
                ,ChildEntity_MUID   UNIQUEIDENTIFIER  
                ,ParentCode         NVARCHAR(250) COLLATE DATABASE_DEFAULT  
                ,ParentName         NVARCHAR(250) COLLATE DATABASE_DEFAULT  
                ,ParentType_ID      INT  
                ,RelationshipId     UNIQUEIDENTIFIER  
                ,RelationshipTypeId INT  
                ,NextItem_ID        INT  
                ,NextItemType_ID    INT  
                ,DomainAttribute_ID INT  
                ,ParentEntity_MUID  UNIQUEIDENTIFIER  
  
                ,MemberTypePrivilege_ID       TINYINT  
                ,MemberTypeAccessPermission   TINYINT  
  
                ,ChildPrivilege_ID      INT  
                ,ChildAccessPermission  INT  
            );  
            CREATE INDEX #ix_Matches_ChildEntity_ID_ChildType_ID_Child_ID ON #Matches (ChildEntity_ID, ChildType_ID, Child_ID)  
        END  
        SELECT @SQLString = CONCAT(--CASE WHEN @UseMemberSecurity = 1 THEN @MemberSecurityCTE END, N'  
            CASE WHEN @IsModelAdmin = 0 THEN N'  
    INSERT INTO #Matches  
    (  
         Code  
        ,Name  
        ,ChildType_ID  
        ,ChildEntity_MUID  
        ,ParentCode  
        ,ParentName  
        ,ParentType_ID  
        ,RelationshipId  
        ,RelationshipTypeId  
        ,NextItem_ID  
        ,NextItemType_ID  
        ,DomainAttribute_ID  
        ,ParentEntity_MUID  
        ,MemberTypePrivilege_ID  
        ,MemberTypeAccessPermission  
        ,Child_ID  
        ,ChildEntity_ID  
    )' END, N'  
    SELECT TOP 500  
        ChildCode AS Code,  
        ChildName AS Name,  
        ChildType_ID,  
        Entity_MUID AS ChildEntity_MUID,  
        ParentCode,  
        ParentName,  
        ParentType_ID,  
        Item_MUID AS RelationshipId,  
        ItemType_ID AS RelationshipTypeId,  
        NextItem_ID,  
        NextItemType_ID,  
        DomainAttribute_ID,  
        ParentEntity_MUID,  
        mtSec.Privilege_ID,  
        mtSec.AccessPermission', CASE WHEN @IsModelAdmin = 0 THEN N',  
        T.Child_ID,  
        T.Entity_ID AS ChildEntity_ID' END, N'  
    FROM mdm.', QUOTENAME(@ViewName), N' T  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_MEMBERTYPE mtSec  
    ON      T.Entity_ID = mtSec.Entity_ID  
        AND T.ChildType_ID = mtSec.ID   
        AND mtSec.User_ID = @User_ID  
    WHERE   T.Version_ID = @Version_ID   
        AND T.ItemType_ID <> 3   
        AND (   T.ChildCode LIKE @SearchTerm  
             OR T.ChildName LIKE @SearchTerm  
            )   
    ORDER BY T.Item_ID')  
  
        SET @ParamList = CAST(N'  
                 @User_ID       INT  
                ,@Version_ID    INT  
                ,@SearchTerm    NVARCHAR(500)'  AS NVARCHAR(max))  
        PRINT @SQLString  
        EXEC sp_executesql @SQLString, @ParamList  
            ,@User_ID  
            ,@Version_ID  
            ,@SearchTerm  
  
        IF @IsModelAdmin = 0  
        BEGIN  
            -- The above query stored the results into a temp table. Lookup member permissions, if applicable, for each entity  
              
            -- If the hierarchy has an explicit cap, get the corresponding entity ID  
            DECLARE @ConsolidatedCapEntity_ID INT;              
            SELECT @ConsolidatedCapEntity_ID = h.Entity_ID   
            FROM mdm.tblDerivedHierarchyDetail dhd  
            INNER JOIN mdm.tblHierarchy h  
            ON dhd.Foreign_ID = h.ID  
            WHERE   dhd.DerivedHierarchy_ID = @Hierarchy_ID   
                AND dhd.ForeignType_ID = 2/*Hierarchy*/  
  
            -- Get all referenced entities  
            DECLARE @Entities TABLE  
            (  
                 ID                             INT PRIMARY KEY  
                ,EntitySecurityTable            SYSNAME COLLATE DATABASE_DEFAULT NULL  
                ,HierarchyParentSecurityTable   SYSNAME COLLATE DATABASE_DEFAULT NULL  
            );  
            INSERT INTO @Entities (ID)  
            SELECT DISTINCT ChildEntity_ID AS ID   
            FROM #Matches  
  
            -- Lookup entity member security table names  
            UPDATE eid  
            SET  EntitySecurityTable = CONCAT(e.EntityTable, N'_MS')  
                ,HierarchyParentSecurityTable = CASE WHEN HierarchyParentTable IS NOT NULL THEN CONCAT(HierarchyParentTable, N'_MS') END  
            FROM @Entities eid  
            INNER JOIN mdm.tblEntity e  
            ON eid.ID = e.ID  
  
            SET @Entity_ID = 0  
            WHILE EXISTS (SELECT 1 FROM @Entities WHERE ID > @Entity_ID)  
            BEGIN  
                SELECT TOP 1  
                     @Entity_ID = ID  
                    ,@EntitySecurityTable = EntitySecurityTable  
                    ,@HierarchyParentSecurityTable = HierarchyParentSecurityTable  
                FROM @Entities  
                WHERE ID > @Entity_ID  
                ORDER BY ID  
  
                SET @UseMemberSecurity = mdm.udfUseMemberSecurity(@User_ID, @Entity_ID, @Version_ID, @MemberType_Leaf);  
                IF @UseMemberSecurity = 1  
                BEGIN  
                    -- Get Leaf member security  
                    SET @SQLString = CONCAT (N'  
                        UPDATE m  
                        SET  ChildPrivilege_ID = MemberTypePrivilege_ID  
                            ,ChildAccessPermission = ms.AccessPermission  
                        FROM #Matches m  
                        INNER JOIN mdm.', QUOTENAME(@EntitySecurityTable), N' ms  
                        ON      ms.Version_ID = @Version_ID  
                            AND ms.User_ID = @User_ID  
                            AND m.Child_ID = ms.ID  
                            AND m.ChildEntity_ID = @Entity_ID  
                            AND m.ChildType_ID = ', @MemberType_Leaf, N'--Leaf  
                        ')  
                    SET @ParamList = N'@User_ID INT, @Version_ID INT, @Entity_ID INT';  
                    PRINT @SQLString  
                    EXEC sp_executesql @SQLString, @ParamList, @User_ID, @Version_ID, @Entity_ID  
                END ELSE  
                BEGIN  
                    -- Member security does not used for this entity's leaf members. So use the MemberType security.  
                    UPDATE #Matches  
                    SET  
                         ChildPrivilege_ID = MemberTypePrivilege_ID  
                        ,ChildAccessPermission = MemberTypeAccessPermission  
                    WHERE   ChildEntity_ID = @Entity_ID  
                        AND ChildType_ID = @MemberType_Leaf;  
                END -- Not using member security  
  
                IF @Entity_ID = @ConsolidatedCapEntity_ID AND @HierarchyParentSecurityTable IS NOT NULL  
                BEGIN  
                    -- The entity pertains to a consolidated cap. Determine if its consolidated members use member security.  
                    SET @UseMemberSecurity = mdm.udfUseMemberSecurity(@User_ID, @Entity_ID, @Version_ID, @MemberType_Consolidated);  
                    IF @UseMemberSecurity = 1  
                    BEGIN  
                        -- Get Consolidated member security  
                        SET @SQLString = CONCAT (N'  
                            UPDATE m  
                            SET  ChildPrivilege_ID = MemberTypePrivilege_ID  
                                ,ChildAccessPermission = ms.AccessPermission  
                            FROM #Matches m  
                            INNER JOIN mdm.', QUOTENAME(@HierarchyParentSecurityTable), N' ms  
                            ON      ms.Version_ID = @Version_ID  
                                AND ms.User_ID = @User_ID  
                                AND m.Child_ID = ms.ID  
                                AND m.ChildEntity_ID = @Entity_ID  
                                AND m.ChildType_ID = ', @MemberType_Consolidated, N'--Consolidated  
                            ')  
                        SET @ParamList = N'@User_ID INT, @Version_ID INT, @Entity_ID INT';  
                        PRINT @SQLString  
                        EXEC sp_executesql @SQLString, @ParamList, @User_ID, @Version_ID, @Entity_ID  
                    END ELSE  
                    BEGIN  
                        -- Member security does not used for this entity's leaf members. So use the MemberType security.  
                        UPDATE #Matches  
                        SET  
                             ChildPrivilege_ID = MemberTypePrivilege_ID  
                            ,ChildAccessPermission = MemberTypeAccessPermission  
                        WHERE   ChildEntity_ID = @Entity_ID  
                            AND ChildType_ID = @MemberType_Consolidated;  
                    END -- Not using consolidated member security  
                END -- loop through entities  
  
            END  
  
            -- Return the records which the user is authorized to see  
            SELECT   
                 Code  
                ,Name  
                ,ChildType_ID  
                ,ChildEntity_MUID  
                ,ParentCode  
                ,ParentName  
                ,ParentType_ID  
                ,RelationshipId  
                ,RelationshipTypeId  
                ,NextItem_ID  
                ,NextItemType_ID  
                ,DomainAttribute_ID  
                ,ParentEntity_MUID  
                ,ChildPrivilege_ID      AS Privilege_ID  
                ,ChildAccessPermission  AS AccessPermission  
            FROM #Matches m  
            WHERE ISNULL(ChildPrivilege_ID, 1) > 1  
        END -- Not model admin  
  
    END -- derived hierarchy  
    ELSE IF @HierarchyType_ID = @HierarchyType_Collection  
    BEGIN  
        SELECT @TempCNName = mdm.udfViewNameGetByID(@Entity_ID,3,1, 0)  
  
        SELECT @SQLString = @MemberSecurityCTE + N'  
                SELECT TOP 500  
                    ID,  
                    Code as Code,  
                    Name as Name,  
                    3 as MemberType_ID,  
                    @Entity_ID  as Item_ID,  
                    1 as ItemType_ID,  
                    @Entity_ID  as NextItem_ID,  
                    1 as NextItemType_ID,  
                    @CollectionPrivilegeID as ModelPrivilege_ID,  
                    4 AS Privilege_ID, -- Access  
                    0 AS AccessPermission  -- ReadOnly  
                WHERE  
                    T.Version_ID = @Version_ID AND  
                    @CollectionPrivilegeID <> 1 AND  
                    (  
                    Code LIKE @SearchTerm  
                    OR  
                    Name LIKE @SearchTerm  
                    )  ORDER BY ID  
                '  
  
                SET @ParamList = CAST(N'@Entity_ID       INT  
                    , @CollectionPrivilegeID       INT  
                    , @User_ID                     INT  
                    , @Version_ID                  INT  
                    , @SearchTerm                  NVARCHAR(500)'  AS NVARCHAR(max))  
  
                EXEC sp_executesql @SQLString, @ParamList  
                    ,@Entity_ID  
                    ,@CollectionPrivilege_ID  
                    ,@User_ID  
                    ,@Version_ID  
                    ,@SearchTerm  
    END  
  
    SET NOCOUNT OFF  
END --proc
go

