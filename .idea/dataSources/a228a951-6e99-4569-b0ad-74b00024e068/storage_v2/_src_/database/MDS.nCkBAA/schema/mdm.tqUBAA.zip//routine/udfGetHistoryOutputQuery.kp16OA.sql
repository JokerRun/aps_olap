/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
SELECT mdm.udfGetHistoryOutputQuery(27, 1, NULL, NULL)  
SELECT mdm.udfGetHistoryOutputQuery(27, 2, NULL, NULL)  
SELECT mdm.udfGetHistoryOutputQuery(27, 3, NULL, NULL)  
SELECT mdm.udfGetHistoryOutputQuery(27, 4, NULL, NULL)  
SELECT mdm.udfGetHistoryOutputQuery(27, 5, NULL, NULL)  
*/  
CREATE FUNCTION mdm.udfGetHistoryOutputQuery  
(  
    @Entity_ID      INT,  
    @MemberType_ID  TINYINT,  
    @User_ID        NVARCHAR(MAX) = NULL,  
    @LastChgDTM     NVARCHAR(MAX) = NULL  
)  
RETURNS NVARCHAR(MAX)  
/*WITH SCHEMABINDING*/  
AS BEGIN  
    DECLARE @SQL                            NVARCHAR(MAX) = N'',  
            @HistoryTable                   SYSNAME,  
            @IsHierarchyEnabled             BIT,  
            @MemberType_Leaf                TINYINT = 1,  
            @MemberType_Consolidated        TINYINT = 2,  
            @MemberType_Collection          TINYINT = 3,  
            @MemberType_Hierarchy           TINYINT = 4,  
            @MemberType_CollectionMember    TINYINT = 5;  
  
    SET @User_ID = COALESCE(@User_ID, N'INSERTED.[LastChgUserID]');  
    SET @LastChgDTM = COALESCE(@LastChgDTM, N'INSERTED.[LastChgDTM]');  
  
    SELECT @HistoryTable =  
        CASE @MemberType_ID  
            WHEN @MemberType_Leaf THEN EntityTable   
            WHEN @MemberType_Consolidated THEN HierarchyParentTable   
            WHEN @MemberType_Collection THEN CollectionTable   
            WHEN @MemberType_Hierarchy THEN HierarchyTable   
            WHEN @MemberType_CollectionMember THEN CollectionMemberTable  
            ELSE NULL  
        END,  
        @IsHierarchyEnabled = CASE WHEN HierarchyParentTable IS NOT NULL THEN 1 ELSE 0 END  
    FROM mdm.tblEntity   
    WHERE ID = @Entity_ID;  
  
    IF @HistoryTable IS NULL  
    BEGIN  
        RETURN @SQL;  
    END  
  
    SET @HistoryTable = QUOTENAME(@HistoryTable + N'_HS');  
  
    IF (@MemberType_ID = @MemberType_Leaf OR @MemberType_ID = @MemberType_Consolidated OR @MemberType_ID = @MemberType_Collection)  
    BEGIN  
        DECLARE @OutputColumns NVARCHAR(MAX) = CONCAT(N'  
        OUTPUT DELETED.[Version_ID]  
            , DELETED.[LastChgTS]  
            , DELETED.[ID]',  
            CASE @MemberType_ID   
                WHEN @MemberType_Leaf THEN N''  
                WHEN @MemberType_Consolidated THEN N'  
            , DELETED.[Hierarchy_ID]'   
                WHEN @MemberType_Collection THEN N'  
            , DELETED.[Owner_ID]  
            , DELETED.[Description]'  
            END,  
            N'  
            , DELETED.[Status_ID]  
            , DELETED.[Name]  
            , DELETED.[Code]  
            , DELETED.[MUID]  
            , DELETED.[LastChgDTM]  
            , DELETED.[LastChgUserID]  
            , ', @LastChgDTM, N'  
            , ', @User_ID),  
            @InputColumns NVARCHAR(MAX) = CONCAT(N'  
              [Version_ID]  
            , [ID]',   
            CASE @MemberType_ID   
                WHEN @MemberType_Leaf THEN N'  
            , [EN_ID]'   
                WHEN @MemberType_Consolidated THEN N'  
            , [HP_ID]  
            , [Hierarchy_ID]'   
                WHEN @MemberType_Collection THEN N'  
            , [CN_ID]  
            , [Owner_ID]  
            , [Description]'  
            END,  
            N'  
            , [Status_ID]  
            , [Name]  
            , [Code]  
            , [MUID]  
            , [EnterDTM]  
            , [EnterUserID]  
            , [LastChgDTM]  
            , [LastChgUserID]');  
  
        SELECT  @OutputColumns += CONCAT(N'  
            , DELETED.' , QUOTENAME(TableColumn)),  
                @InputColumns +=  CONCAT(N'  
            , ' , QUOTENAME(TableColumn))  
        FROM mdm.tblAttribute  
        WHERE [Entity_ID] = @Entity_ID AND MemberType_ID = @MemberType_ID AND IsSystem <> 1  
  
        SET @SQL = CONCAT(@OutputColumns, N'  
        INTO [mdm].', @HistoryTable, N'(', @InputColumns, N'  
        )');  
    END  
    ELSE IF @MemberType_ID = @MemberType_Hierarchy  
    BEGIN  
        SET @SQL = CONCAT(N'  
        OUTPUT DELETED.[Version_ID]  
            , DELETED.[LastChgTS]  
            , DELETED.[ID]  
            , DELETED.[Status_ID]  
            , DELETED.[Hierarchy_ID]  
            , DELETED.[Parent_HP_ID]  
            , DELETED.[ChildType_ID]  
            , DELETED.[Child_EN_ID]  
            , DELETED.[Child_HP_ID]  
            , DELETED.[SortOrder]  
            , DELETED.[LevelNumber]  
            , DELETED.[LastChgDTM]  
            , DELETED.[LastChgUserID]  
            , ', @LastChgDTM, N'  
            , ', @User_ID, N'  
            , DELETED.[MUID]  
        INTO [mdm].', @HistoryTable ,N'(  
            [Version_ID]  
            ,[ID]  
            ,[HR_ID]  
            ,[Status_ID]  
            ,[Hierarchy_ID]  
            ,[Parent_HP_ID]  
            ,[ChildType_ID]  
            ,[Child_EN_ID]  
            ,[Child_HP_ID]  
            ,[SortOrder]  
            ,[LevelNumber]  
            ,[EnterDTM]  
            ,[EnterUserID]  
            ,[LastChgDTM]  
            ,[LastChgUserID]  
            ,[MUID]  
        )  
');  
    END  
    ELSE  
    BEGIN  
        SET @SQL = CONCAT(N'  
        OUTPUT DELETED.[Version_ID]  
            , DELETED.[LastChgTS]  
            , DELETED.[ID]  
            , DELETED.[Status_ID]  
            , DELETED.[Parent_CN_ID]  
            , DELETED.[ChildType_ID]  
            , DELETED.[Child_EN_ID]',  
            CASE @IsHierarchyEnabled   
                WHEN 1 THEN N'  
            , DELETED.[Child_HP_ID]'   
                ELSE N''  
            END,  
            N'  
            , DELETED.[Child_CN_ID]  
            , DELETED.[SortOrder]  
            , DELETED.[Weight]  
            , DELETED.[LastChgDTM]  
            , DELETED.[LastChgUserID]  
            , ', @LastChgDTM, N'  
            , ', @User_ID, N'  
            , DELETED.[MUID]  
        INTO [mdm].', @HistoryTable ,N'(  
              [Version_ID]  
            , [ID]  
            , [CM_ID]  
            , [Status_ID]  
            , [Parent_CN_ID]  
            , [ChildType_ID]  
            , [Child_EN_ID]',  
            CASE @IsHierarchyEnabled   
                WHEN 1 THEN N'  
            , [Child_HP_ID]'  
                ELSE N''  
            END,  
            N'        
            , [Child_CN_ID]  
            , [SortOrder]  
            , [Weight]  
            , [EnterDTM]  
            , [EnterUserID]  
            , [LastChgDTM]  
            , [LastChgUserID]  
            , [MUID]  
        )  
');  
    END  
  
    RETURN @SQL;  
END; --fn
go

