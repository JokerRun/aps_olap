/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Syncs the target entity version with its registered source entity version. That is, the target entity version is changed as necessary to make it match the source entity version.   
  
Required user permissions:  
- Sys Admin functional permission  
- Source entity version:  
    -- At least Read permission on the entity and all attributes  
    -- No member permissions (i.e. udfUseMemberSecurity must return 0).  
- Target entity version:   
    -- Model Admin  
    -- Version status must not be Committed.   
  
Possible errors:  
1. The given entity version is not a target in an existing sync relationship.  
2. Conflict in the target entity. E.g. if the source entity has deleted a member that is being referenced as a DBA value in an entity of the target model.   
   In which case, sync will fail until the DBA dependency is removed.  
3. The target version is Committed  
*/  
CREATE PROCEDURE mdm.udpSyncRefresh  
(  
     @User_ID               INT -- Must have admin permission on the target model and Sys Admin functional permission.   
    ,@TargetModel_MUID      UNIQUEIDENTIFIER = NULL  
    ,@TargetModelName       NVARCHAR(50) = NULL  
    ,@TargetModel_ID        INT = NULL -- for internal use only  
    ,@TargetVersion_MUID    UNIQUEIDENTIFIER = NULL -- Sufficient context info must be provided to uniquely identify the target version. If the target version is (or becomes) Committed, the subscription relationship is dormant.  
    ,@TargetVersionName     NVARCHAR(50) = NULL  
    ,@TargetVersion_ID      INT = NULL -- for internal use only  
    ,@TargetEntity_MUID     UNIQUEIDENTIFIER = NULL-- Sufficient context info must be provided to uniquely identify the target entity.  
    ,@TargetEntityName      NVARCHAR(50) = NULL   
    ,@TargetEntity_ID       INT = NULL -- for internal use only  
    ,@CorrelationID         UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS N'mds_schema_user'      
AS  
BEGIN  
    SET NOCOUNT ON;  
  
PRINT CONCAT(SYSDATETIME(), N': Begin udpSyncRefresh')  
    DECLARE   
         @Found_ID    INT  
        ,@TargetVersion_Status_ID       TINYINT  
        ,@TargetEntity_EN_TableName     SYSNAME  
        ,@TargetEntityDataCompression   TINYINT  
        ,@TargetEntityStagingLeafName   SYSNAME  
  
        ,@MemberType_Leaf           TINYINT = 1  
        ,@MemberType_Consolidated   TINYINT = 2  
        ,@MemberType_Collection     TINYINT = 3  
  
        ,@PermissionType_Deny           TINYINT = 1  
        ,@PermissionType_Admin          TINYINT = 5  
  
        ,@FunctionalPrivilege_SysAdmin  TINYINT = 5  
  
        ,@EditMode_Create TINYINT = 0  
        ,@EditMode_Update TINYINT = 1  
  
        ,@VersionStatus_Committed   TINYINT = 3  
  
        ,@AttributeType_Freeform    TINYINT = 1  
        ,@AttributeType_Domain      TINYINT = 2  
        ,@AttributeType_System      TINYINT = 3  
        ,@AttributeType_File        TINYINT = 4  
  
        ,@SyncStatus_InProgress     TINYINT = 1  
        ,@SyncStatus_Success        TINYINT = 2  
        ,@SyncStatus_Failed         TINYINT = 3  
  
        -- Member status  
        ,@Status_Active                 TINYINT = 1  
        ,@Status_Deactivated            TINYINT = 2  
  
        ,@TransactionLogType_None       TINYINT = 3  
          
        ,@ErrorMessage NVARCHAR(4000)  
        ;  
  
    -- Lookup target model ID  
    SET @Found_ID = NULL;  
    DECLARE @TargetModelPrivilege_ID TINYINT  
    EXEC mdm.udpInformationLookupModel @User_ID = @User_ID, @Model_MUID = @TargetModel_MUID, @Model_Name = @TargetModelName, @Model_ID = @TargetModel_ID, @ID = @Found_ID OUTPUT, @Privilege_ID = @TargetModelPrivilege_ID OUTPUT;  
    SET @TargetModel_ID = @Found_ID;  
  
    -- Lookup target version ID. Note: not using udpInformationLookupVersion to avoid needlessly querying the model security view again.  
    SET @Found_ID = NULL;  
    SELECT   
         @Found_ID = ID  
        ,@TargetVersion_Status_ID = Status_ID  
    FROM mdm.tblModelVersion   
    WHERE  
            (@TargetVersion_MUID IS NOT NULL OR @TargetVersionName IS NOT NULL OR @TargetVersion_ID IS NOT NULL)   
        AND (@TargetVersion_MUID IS NULL OR MUID = @TargetVersion_MUID)   
        AND (@TargetVersionName IS NULL OR Name = @TargetVersionName)  
        AND (@TargetVersion_ID IS NULL OR ID = @TargetVersion_ID)  
        AND Model_ID = @TargetModel_ID;  
    SET @TargetVersion_ID = @Found_ID;  
  
    -- Lookup target entity ID. Note: not using udpInformationLookupEntity to avoid needlessly querying the model security view again. If the user isn't a model admin, the sproc would have returned with an error already.  
    SET @Found_ID = NULL;  
    DECLARE @TargetEntitySupportsNonLeafMembers BIT = 0;  
    SELECT   
         @Found_ID = ID  
        ,@TargetEntityName = Name -- needed in case the name is aliased (i.e. is different from source)  
        ,@TargetEntity_EN_TableName = EntityTable  
        ,@TargetEntitySupportsNonLeafMembers = CASE WHEN COALESCE(HierarchyParentTable, CollectionTable) IS NULL THEN 0 ELSE 1 END  
        ,@TargetEntityDataCompression = DataCompression  
        ,@TargetEntityStagingLeafName = StagingLeafName  
    FROM mdm.tblEntity e  
    WHERE  
            (@TargetEntity_MUID IS NOT NULL OR @TargetEntityName IS NOT NULL OR @TargetEntity_ID IS NOT NULL)   
        AND (@TargetEntity_MUID IS NULL OR MUID = @TargetEntity_MUID)   
        AND (@TargetEntityName IS NULL OR Name = @TargetEntityName)  
        AND (@TargetEntity_ID IS NULL OR ID = @TargetEntity_ID)  
        AND Model_ID = @TargetModel_ID;  
    SET @TargetEntity_ID = @Found_ID;  
  
    DECLARE   
         @TargetEntityNameIsAliased     BIT  
        ,@LastSyncTimestamp             VARBINARY(8)  
        ,@LastSyncAttemptStatus         TINYINT  
        ,@SourceEntity_ID               INT  
        ,@SourceEntity_EN_TableName     SYSNAME  
        ,@SourceVersion_ID              INT  
        ,@SourceEntityName              NVARCHAR(50)  
        ,@SourceEntityDescription       NVARCHAR(500)  
        ,@SourceEntityTimestamp         VARBINARY(8)  
        ,@SourceEntityDataCompression   TINYINT  
        ,@SourceEntityIsBase            BIT  
        ;  
  
    SELECT  
         @TargetEntityNameIsAliased = sr.TargetEntityNameIsAliased  
        ,@LastSyncTimestamp         = sr.LastSuccessfulSyncTimestamp  
        ,@LastSyncAttemptStatus     = sr.LastSyncAttemptStatus  
        ,@SourceEntity_ID           = sr.SourceEntity_ID  
        ,@SourceEntity_EN_TableName = se.EntityTable  
        ,@SourceVersion_ID          = sr.SourceVersion_ID  
        ,@SourceEntityName          = se.Name  
        ,@SourceEntityDescription   = se.[Description]  
        ,@SourceEntityTimestamp     = CONVERT(VARBINARY(8), se.LastChgTS)  
        ,@SourceEntityDataCompression   = se.DataCompression  
        ,@SourceEntityIsBase        = se.IsBase  
    FROM mdm.tblSyncRelationship sr  
    INNER JOIN mdm.tblEntity se  
    ON sr.SourceEntity_ID = se.ID  
    WHERE   sr.TargetEntity_ID = @TargetEntity_ID  
        AND sr.TargetVersion_ID = @TargetVersion_ID  
    ;  
  
    DECLARE @IsFirstSyncAttempt BIT = CASE WHEN @LastSyncTimestamp IS NULL THEN 1 ELSE 0 END;  
    DECLARE @NeedToRefreshStagingSproc BIT = @IsFirstSyncAttempt;  
    IF @LastSyncAttemptStatus = @SyncStatus_InProgress  
    BEGIN  
PRINT CONCAT(SYSDATETIME(), N': The target entity version is already being sync''ed. Aborting...')  
        RETURN;  
    END  
  
    -- update the status and timestamp in the sync table  
    UPDATE mdm.tblSyncRelationship  
    SET    
         LastSyncAttemptDTM = GETUTCDATE()  
        ,LastSyncAttemptStatus = @SyncStatus_InProgress  
        ,LastSyncAttemptErrorInfo = NULL  
    WHERE   TargetEntity_ID = @TargetEntity_ID  
        AND TargetVersion_ID = @TargetVersion_ID  
  
    --Start transaction, being careful to check if we are nested  
    DECLARE @TranCounter INT = @@TRANCOUNT;  
    IF @TranCounter > 0 SAVE TRANSACTION TX;  
    ELSE BEGIN TRANSACTION;  
  
    BEGIN TRY -- Note: the TRY block begins near the top of the sproc so that any raised error will be written to the sync relationship table.  
  
        -- Ensure the user has Sys Admin functional permissions (can modify metadata)  
        IF mdm.udfSecurityUserFunctionIsAllowed(@User_ID, @FunctionalPrivilege_SysAdmin) = 0  
        BEGIN   
            RAISERROR('MDSERR120002|The user does not have permission to perform this operation.', 16, 1);  
            RETURN;  
        END  
  
        -- Verify user is model admin  
        IF @TargetModel_ID IS NULL OR COALESCE(@TargetModelPrivilege_ID, @PermissionType_Deny) <> @PermissionType_Admin  
        BEGIN  
            -- Either the model doesn't exist, or the user doesn't have permission to see it.  
            RAISERROR('MDSERR200204|Sync target model ID is not valid or the user does not have sufficient permission.', 16, 1);  
            RETURN;  
        END;  
  
        IF @TargetVersion_ID IS NULL  
        BEGIN  
            RAISERROR('MDSERR200205|Sync target version ID is not valid.', 16, 1);  
            RETURN;  
        END;  
  
        IF @TargetVersion_Status_ID = @VersionStatus_Committed  
        BEGIN  
            RAISERROR('MDSERR200208|Cannot sync to the target entity. The target version is committed.', 16, 1);  
            RETURN;  
        END;  
  
        IF @TargetEntity_ID IS NULL  
        BEGIN  
            RAISERROR('MDSERR200209|Sync target entity ID is not valid.', 16, 1);  
            RETURN;  
        END;  
  
        IF EXISTS (SELECT 1 FROM mdm.tblBRBusinessRule WHERE Entity_ID = @TargetEntity_ID)  
        BEGIN  
            RAISERROR('MDSERR200218|The sync relationship is not valid. A target entity may not contain business rules.', 16, 1);  
            RETURN;  
        END;  
  
        IF @TargetEntitySupportsNonLeafMembers = 1  
        BEGIN  
            RAISERROR('MDSERR200222|The sync relationship is not valid. A target entity may only contain Leaf members.', 16, 1);  
            RETURN;  
        END;  
  
        IF EXISTS (SELECT 1 FROM mdm.tblIndex WHERE Entity_ID = @TargetEntity_ID)  
        BEGIN  
            RAISERROR('MDSERR200224|The sync relationship is not valid. A target entity may not contain Indexes.', 16, 1);  
            RETURN;  
        END;  
  
        -- Verify the user has permission to see all members and attributes within the source entity. Note: lack of attribute group permission does not prevent creation of a sync relationship.  
        DECLARE @UseMemberSecurity BIT;  
        SET @UseMemberSecurity = mdm.udfUseMemberSecurity(@User_ID, @SourceEntity_ID, @SourceVersion_ID, @MemberType_Leaf)  
        IF @UseMemberSecurity <> 0  
           OR EXISTS(SELECT 1  
                  FROM mdm.tblAttribute a  
                  LEFT JOIN mdm.viw_SYSTEM_SECURITY_USER_ATTRIBUTE sa  
                  ON    a.ID = sa.ID  
                    AND sa.User_ID = @User_ID  
                  WHERE  
                        a.Entity_ID = @SourceEntity_ID  
                    AND a.MemberType_ID = @MemberType_Leaf  
                    AND (a.IsSystem = 0 OR a.IsCode = 1 OR a.IsName = 1)  
                    AND sa.Privilege_ID IS NULL)  
        BEGIN  
            RAISERROR('MDSERR200210|Insufficient permission on source entity.', 16, 1);  
            RETURN;  
        END;  
  
        -- Sync entity metadata  
        IF  @IsFirstSyncAttempt = 1 OR  
            @SourceEntityTimestamp <> @LastSyncTimestamp   
        BEGIN  
            -- The source entity has changed since the last sync. Update it  
            SET @NeedToRefreshStagingSproc = 1  
  
            IF @TargetEntityNameIsAliased = 0  
            BEGIN  
                SET @TargetEntityName = @SourceEntityName;  
            END  
  
PRINT CONCAT(SYSDATETIME(), N': Updating target entity ''', @TargetEntityName,''' (ID = ', @TargetEntity_ID, N')')  
            EXEC mdm.udpEntitySave   
                 @User_ID = @User_ID  
                ,@Model_ID = @TargetModel_ID  
                ,@Entity_ID = @TargetEntity_ID  
                ,@EntityName = @TargetEntityName  
                ,@Description = @SourceEntityDescription  
                ,@IsBase = @SourceEntityIsBase  
                ,@EditMode = @EditMode_Update -- The entity must have already been created at this point, so always doing update  
                ,@DataCompression = @SourceEntityDataCompression  
                ,@TransactionLogType = @TransactionLogType_None  
                ,@IsSync = 1  
                ,@RecreateStagingProc = 0 -- For efficiency, will update the sproc only after all entity and attribute metadata changes have been made  
  
            -- update the target entity audit info to match the source  
            UPDATE te  
            SET    
                 EnterDTM = se.EnterDTM  
                ,EnterUserID = se.EnterUserID  
                ,LastChgDTM = se.LastChgDTM  
                ,LastChgUserID = se.LastChgUserID  
            FROM mdm.tblEntity te  
            INNER JOIN mdm.tblEntity se  
            ON      se.ID = @SourceEntity_ID  
                AND te.ID = @TargetEntity_ID;  
        END;  
  
  
  
        -- Sync attribute metadata  
  
        DECLARE @SourceAttributes TABLE  
        (  
             ID                     INT PRIMARY KEY  
            ,Name                   NVARCHAR(100) NULL  
            ,DataType_ID            TINYINT NULL  
            ,AttributeType_ID       TINYINT NULL  
            ,ChangeTrackingGroup    INT NULL  
            ,DataTypeInformation    INT NULL  
            ,Description            NVARCHAR(500) NULL  
            ,DisplayName            NVARCHAR(250) NULL  
            ,DisplayWidth           INT NULL  
            ,DomainEntity_ID        INT NULL -- TODO: Add support for reflexive DBAs  
            ,InputMask_ID           INT NULL  
            ,SortOrder              INT NULL  
            ,TableColumn            SYSNAME  
            ,EnterDTM               DATETIME2(3)  
            ,EnterUserID            INT  
            ,LastChgDTM             DATETIME2(3)  
            ,LastChgUserID          INT  
            ,LastChgTS              VARBINARY(8) NULL  
        )  
  
        INSERT INTO @SourceAttributes  
        SELECT  
             ID  
            ,Name  
            ,DataType_ID  
            ,AttributeType_ID  
            ,ChangeTrackingGroup  
            ,DataTypeInformation  
            ,Description  
            ,DisplayName  
            ,DisplayWidth  
            ,DomainEntity_ID  
            ,InputMask_ID  
            ,SortOrder  
            ,TableColumn  
            ,EnterDTM  
            ,EnterUserID  
            ,LastChgDTM  
            ,LastChgUserID  
            ,CAST(LastChgTS AS VARBINARY(8))  
        FROM mdm.tblAttribute  
        WHERE   Entity_ID = @SourceEntity_ID  
            AND MemberType_ID = @MemberType_Leaf  
            AND (IsSystem = 0 OR IsName = 1 OR IsCode = 1)  
            AND (DomainEntity_ID IS NULL   
                --OR DomainEntity_ID = @SourceEntity_ID -- TODO: Add support for reflexive DBAs  
                )  
  
        DECLARE @AttributeChanges TABLE  
        (  
             RowID                  INT IDENTITY(1, 1) PRIMARY KEY  
            ,SourceAttribute_ID     INT NULL  
            ,TargetAttribute_ID     INT NULL  
            ,TargetAttributeName    NVARCHAR(100) NULL  
            ,TargetAttributeDataType_ID TINYINT  
  
            -- source attribute values  
            ,AttributeType_ID       TINYINT NULL  
            ,ChangeTrackingGroup    INT NULL  
            ,DataType_ID            TINYINT NULL  
            ,DataTypeInformation    INT NULL  
            ,Description            NVARCHAR(500) NULL  
            ,DisplayName            NVARCHAR(250) NULL  
            ,DisplayWidth           INT NULL  
            ,DomainEntity_ID        INT NULL -- TODO: Add support for reflexive-DBAs  
            ,InputMask_ID           INT NULL  
            ,Name                   NVARCHAR(100) NULL  
            ,SortOrder              INT NULL  
            ,EnterDTM               DATETIME2(3)  
            ,EnterUserID            INT  
            ,LastChgDTM             DATETIME2(3)  
            ,LastChgUserID          INT  
            ,LastChgTS              VARBINARY(8) NULL  
        );  
  
        IF @IsFirstSyncAttempt = 1  
        BEGIN  
            -- This is the first sync attempt. Attributes are matched by name (subsequent syncs will use Source_ID). Attributes that  
            -- already exist in the target Entity must *exactly* match those in the source Entity, or sync will fail. Because initial sync   
            -- must not cause data loss on the target Entity. It can add, but not modify or delete existing data.  
PRINT CONCAT(SYSDATETIME(), N': Matching source and target attributes for initial sync')  
  
            UPDATE tgt   
            SET  
                 Source_ID = src.ID  
                ,Source_LastChgTS = src.LastChgTS  
                ,EnterDTM = src.EnterDTM  
                ,EnterUserID = src.EnterUserID  
                ,LastChgDTM = src.LastChgDTM  
                ,LastChgUserID = src.LastChgUserID  
            FROM mdm.tblAttribute tgt  
            INNER JOIN @SourceAttributes src  
            ON      src.AttributeType_ID = tgt.AttributeType_ID -- not nullable  
                AND src.ChangeTrackingGroup = tgt.ChangeTrackingGroup -- not nullable  
                AND src.DataType_ID = tgt.DataType_ID -- not nullable  
                AND ((src.DataTypeInformation IS NULL AND tgt.DataTypeInformation IS NULL) OR src.DataTypeInformation = tgt.DataTypeInformation)  
                AND ((src.DisplayName IS NULL AND tgt.DisplayName IS NULL) OR src.DisplayName = tgt.DisplayName)  
                AND ((src.Description IS NULL AND tgt.Description IS NULL) OR src.Description = tgt.Description)  
                AND src.DisplayWidth = tgt.DisplayWidth -- not nullable  
                AND (  (src.DomainEntity_ID IS NULL AND tgt.DomainEntity_ID IS NULL) -- not a DBA  
                    OR (src.DomainEntity_ID = @SourceEntity_ID AND tgt.DomainEntity_ID = @TargetEntity_ID)) -- reflexive DBA  
                AND src.InputMask_ID = src.InputMask_ID -- not nullable  
                AND src.Name = tgt.Name -- not nullable  
                AND src.SortOrder = tgt.SortOrder -- not nullable  
            WHERE   tgt.Entity_ID = @TargetEntity_ID  
                AND tgt.MemberType_ID = @MemberType_Leaf  
                AND (tgt.IsSystem = 0 OR tgt.IsName = 1 OR tgt.IsCode = 1)  
  
  
            DECLARE @FirstNonMatchedAttributeName NVARCHAR(100)  
            SELECT TOP 1  
                @FirstNonMatchedAttributeName = Name  
            FROM mdm.tblAttribute  
            WHERE   Entity_ID = @TargetEntity_ID  
                AND MemberType_ID = @MemberType_Leaf  
                AND (IsSystem = 0 OR IsName = 1 OR IsCode = 1)  
                AND Source_ID IS NULL;  
  
            IF @FirstNonMatchedAttributeName IS NOT NULL  
            BEGIN  
                DECLARE @ErrorMsg NVARCHAR(MAX) = CONCAT('MDSERR200211|Initial sync of entity has failed. Target entity contains at least one attribute that does not match a source entity attribute. First attribute name: "{0}"|', @FirstNonMatchedAttributeName, N'|') -- Adding a trailing "|" char to separate the attribute name from any error context info added to the error message by the catch block.  
                SET @ErrorMsg = REPLACE(@ErrorMsg, '%', '%%')-- escape out format specifier  
                RAISERROR (@ErrorMsg, 16, 1);   
                RETURN;  
            END  
  
        END -- initial sync  
  
PRINT CONCAT(SYSDATETIME(), N': Getting attribute changes')  
        ;WITH targetAttributesCte AS  
        (  
            SELECT  
                 ID  
                ,Name  
                ,DataType_ID  
                ,Source_ID  
                ,Source_LastChgTS  
            FROM mdm.tblAttribute  
            WHERE   
                    Entity_ID = @TargetEntity_ID  
                AND MemberType_ID = @MemberType_Leaf  
                AND (IsSystem = 0 OR IsName = 1 OR IsCode = 1)  
        )              
        INSERT INTO @AttributeChanges  
        SELECT  
             src.ID SourceAttribute_ID  
            ,tgt.ID TargetAttribute_ID  
            ,tgt.Name TargetAttributeName  
            ,tgt.DataType_ID TargetAttributeDataType_ID  
            ,src.AttributeType_ID  
            ,src.ChangeTrackingGroup  
            ,src.DataType_ID  
            ,src.DataTypeInformation  
            ,src.Description  
            ,src.DisplayName  
            ,src.DisplayWidth  
            ,CASE WHEN src.DomainEntity_ID IS NULL THEN NULL ELSE @TargetEntity_ID END DomainEntity_ID  
            ,src.InputMask_ID  
            ,src.Name  
            ,src.SortOrder  
            ,src.EnterDTM  
            ,src.EnterUserID  
            ,src.LastChgDTM  
            ,src.LastChgUserID  
            ,src.LastChgTS  
        FROM @SourceAttributes src  
        FULL JOIN targetAttributesCte tgt  
        ON src.ID = tgt.Source_ID  
        WHERE  src.ID IS NULL -- attribute was deleted from source and needs to be deleted from target entity  
            OR tgt.ID IS NULL -- attribute was added to source entity since last sync and needs to be added to target entity  
            OR (src.LastChgTS IS NULL OR tgt.Source_LastChgTS IS NULL OR src.LastChgTS <> tgt.Source_LastChgTS) -- attribute has changed in source and needs to be updated in target entity  
  
  
        DECLARE   
             @RowID                 INT = 0  
            ,@SourceAttribute_ID    INT  
            ,@TargetAttribute_ID    INT  
            ,@TargetAttributeName   NVARCHAR(100)  
            ,@TargetAttributeDataType_ID TINYINT  
            ,@AttributeType_ID      TINYINT  
            ,@ChangeTrackingGroup   INT  
            ,@DataType_ID           TINYINT  
            ,@DataTypeInformation   INT  
            ,@Description           NVARCHAR(500)  
            ,@DisplayName           NVARCHAR(250)  
            ,@DisplayWidth          INT  
            ,@DomainEntity_ID       INT  
            ,@InputMask_ID          INT  
            ,@AttributeName         NVARCHAR(100)  
            ,@SortOrder             INT  
            ,@EnterDTM              DATETIME2(3)  
            ,@EnterUserID           INT  
            ,@LastChgDTM            DATETIME2(3)  
            ,@LastChgUserID         INT  
            ,@LastChgTS             VARBINARY(8)  
            ;  
  
        SET @NeedToRefreshStagingSproc = CASE WHEN EXISTS (SELECT 1 FROM @AttributeChanges)   
            THEN 1   
            ELSE @NeedToRefreshStagingSproc -- leave original value   
            END  
  
        WHILE EXISTS (SELECT 1 FROM @AttributeChanges WHERE RowID > @RowID)  
        BEGIN  
            SELECT TOP 1  
                 @RowID = RowID  
                ,@SourceAttribute_ID = SourceAttribute_ID  
                ,@TargetAttribute_ID = TargetAttribute_ID   
                ,@TargetAttributeName = TargetAttributeName  
                ,@TargetAttributeDataType_ID = TargetAttributeDataType_ID  
  
                -- source attribute values  
                ,@AttributeType_ID = AttributeType_ID  
                ,@ChangeTrackingGroup = ChangeTrackingGroup  
                ,@DataType_ID = DataType_ID  
                ,@DataTypeInformation = DataTypeInformation  
                ,@Description = Description   
                ,@DisplayName = DisplayName  
                ,@DisplayWidth = DisplayWidth  
                ,@DomainEntity_ID = DomainEntity_ID   
                ,@InputMask_ID = InputMask_ID  
                ,@AttributeName = Name  
                ,@SortOrder = SortOrder  
                ,@EnterDTM = EnterDTM  
                ,@EnterUserID = EnterUserID  
                ,@LastChgDTM = LastChgDTM  
                ,@LastChgUserID = LastChgUserID  
                ,@LastChgTS = LastChgTS  
            FROM @AttributeChanges  
            WHERE RowID > @RowID  
            ORDER BY RowID;  
            IF @SourceAttribute_ID IS NULL  
            BEGIN  
PRINT CONCAT(SYSDATETIME(), N': Deleting target attribute ''', @TargetAttributeName, N''' (ID = ', @TargetAttribute_ID, N')');  
                -- Delete the attribute  
                EXEC mdm.udpAttributeDelete   
                     @Attribute_ID = @TargetAttribute_ID  
                    ,@IsSync = 1  
            END   
            ELSE BEGIN  
                DECLARE @EditMode TINYINT = CASE WHEN @TargetAttribute_ID IS NULL THEN @EditMode_Create ELSE @EditMode_Update END  
  
                IF @EditMode = @EditMode_Create  
                BEGIN  
PRINT CONCAT(SYSDATETIME(), N': Creating new target attribute, copy of source attribute ''', @AttributeName, N''' (ID = ', @SourceAttribute_ID, N')');  
                END ELSE  
                BEGIN  
PRINT CONCAT(SYSDATETIME(), N': Updating target attribute ''', @TargetAttributeName,N''' (ID = ', @TargetAttribute_ID, N'), copy of source attribute ID = ', @SourceAttribute_ID);  
                END  
  
                IF @EditMode = @EditMode_Update AND COALESCE(@TargetAttributeDataType_ID, -1) <> COALESCE(@DataType_ID, -1)  
                BEGIN  
                    -- The attribute's type has changed.  
  
PRINT CONCAT(SYSDATETIME(), N': Changing attribute data type')              
                    -- TODO: add special handling for failure cases. Like should attribute values be changed before changing the type? Or simply delete and re-add the attribute?  
                    DECLARE   
                         @TargetAttribute_MUID UNIQUEIDENTIFIER = (SELECT MUID FROM mdm.tblAttribute WHERE ID = @TargetAttribute_ID)  
                        ,@DomainEntity_MUID UNIQUEIDENTIFIER = (SELECT MUID FROM mdm.tblEntity WHERE ID = @DomainEntity_ID);  
  
                    EXEC mdm.udpAttributeChange  
                         @User_ID = @User_ID  
                        ,@Attribute_MUID = @TargetAttribute_MUID  
                        ,@AttributeNewName = @AttributeName  
                        ,@AttributeType_ID = @AttributeType_ID  
                        ,@ChangeTrackingGroup = ChangeTrackingGroup  
                        ,@DataType_ID = DataType_ID  
                        ,@DataTypeInformation = DataTypeInformation  
                        ,@Description = @Description  
                        ,@DisplayName = @DisplayName  
                        ,@DisplayWidth = @DisplayWidth  
                        ,@DomainEntity_MUID = @DomainEntity_MUID   
                        ,@IsSync = 1  
                END   
  
                -- Add/update the attribute  
                EXEC mdm.udpAttributeSave   
                     @User_ID = @User_ID  
                    ,@Model_ID = @TargetModel_ID  
                    ,@Entity_ID = @TargetEntity_ID  
                    ,@IsHierarchyEnabled = 0  
                    ,@IsCollectionEnabled = 0  
                    ,@DataCompression = @TargetEntityDataCompression  
                    ,@TableName = @TargetEntity_EN_TableName  
                    ,@StagingTableName = @TargetEntityStagingLeafName  
                    ,@MemberType_ID = @MemberType_Leaf  
                    ,@Attribute_ID = @TargetAttribute_ID  
                    ,@AttributeName = @AttributeName  
                    ,@AttributeType_ID = @AttributeType_ID  
                    ,@ChangeTrackingGroup = @ChangeTrackingGroup  
                    ,@DataType_ID = @DataType_ID  
                    ,@DataTypeInformation = @DataTypeInformation  
                    ,@Description = @Description  
                    ,@DisplayName = @DisplayName  
                    ,@DisplayWidth = @DisplayWidth  
                    ,@DomainEntity_ID = @DomainEntity_ID   
                    ,@InputMask_ID = @InputMask_ID  
                    ,@SortOrder = @SortOrder  
                    ,@EditMode = @EditMode  
                    ,@IsSync = 1  
                    ,@RecreateStagingProc = 0 -- For efficiency, will update the sproc only after all entity and attribute metadata changes have been made  
                    ,@Return_ID = @TargetAttribute_ID OUTPUT  
                    ;  
  
                UPDATE mdm.tblAttribute  
                SET  
                     Source_ID = @SourceAttribute_ID   
                    ,Source_LastChgTS = @LastChgTS  
                    ,EnterDTM = CASE WHEN @EditMode = @EditMode_Create OR IsSystem = 1 THEN @EnterDTM ELSE EnterDTM END  
                    ,EnterUserID = CASE WHEN @EditMode = @EditMode_Create OR IsSystem = 1 THEN @EnterUserID ELSE EnterUserID END  
                    ,LastChgDTM = @LastChgDTM  
                    ,LastChgUserID = @LastChgUserID  
                WHERE ID = @TargetAttribute_ID  
            END  
        END -- WHILE  
  
        IF @NeedToRefreshStagingSproc = 1  
        BEGIN  
            EXEC mdm.udpEntityStagingCreateLeafStoredProcedure @TargetEntity_ID  
        END  
  
  
        -- Sync master data  
        CREATE TABLE #FileAttributeValueMapping  
        (  
             TargetMember_ID    INT NOT NULL  
            ,TargetMemberCode   NVARCHAR(250) NOT NULL  
            ,TargetAttribute_ID INT NOT NULL  
            ,TargetColumnName   SYSNAME NOT NULL  
            ,TargetFile_ID      INT NULL  
            ,SourceMember_ID    INT NULL  
            ,SourceFile_ID      INT NULL  
            ,MatchedOnInitialSync BIT NOT NULL  
        );  
        CREATE INDEX #ix_FileAttributeValueMapping_TargetFile_ID ON #FileAttributeValueMapping(TargetFile_ID);  
        CREATE INDEX #ix_FileAttributeValueMapping_SourceFile_ID ON #FileAttributeValueMapping(SourceFile_ID);  
  
        CREATE TABLE #AttributeMapping  
        (  
             SourceAttribute_ID         INT NOT NULL  
            ,SourceAttribute_ColumnName SYSNAME NOT NULL  
            ,TargetAttribute_ID         INT NOT NULL  
            ,TargetAttribute_ColumnName SYSNAME NOT NULL  
            ,AttributeType_ID           INT NOT NULL  
        );  
        CREATE UNIQUE CLUSTERED INDEX #ix_AttributeMapping_SourceAttribute_ID_TargetAttribute_ID ON #AttributeMapping(SourceAttribute_ID, TargetAttribute_ID);  
  
        INSERT INTO #AttributeMapping  
        SELECT  
             src.ID             SourceAttribute_ID  
            ,src.TableColumn    SourceAttribute_ColumnName  
            ,tgt.ID             TargetAttribute_ID  
            ,tgt.TableColumn    TargetAttribute_ColumnName  
            ,src.AttributeType_ID  
        FROM @SourceAttributes src  
        INNER JOIN mdm.tblAttribute tgt  
        ON src.ID = tgt.Source_ID  
        WHERE   tgt.Entity_ID = @TargetEntity_ID  
            AND tgt.MemberType_ID = @MemberType_Leaf  
  
        DECLARE   
             @AttributeValueMatchClause     NVARCHAR(MAX) = N''  
            ,@AttributeValueSetClause       NVARCHAR(MAX) = N''  
            ,@SourceAttributesSelectClause  NVARCHAR(MAX) = N''  
            ,@TargetAttributesSelectClause  NVARCHAR(MAX) = N''  
            ,@HasFileAttribute  BIT = CASE WHEN EXISTS (SELECT 1 FROM #AttributeMapping WHERE AttributeType_ID = @AttributeType_File) THEN 1 ELSE 0 END  
            --,@SourceDBALookupFromClause NVARCHAR(MAX) = N''  
            --,@TargetDBALookupFromClause NVARCHAR(MAX) = N''  
            ;  
        SELECT   
             @AttributeValueMatchClause += CONCAT(N'  
        AND ', CASE AttributeType_ID  
              
                -- TODO: Add JOIN clauses to lookup referenced member ID  
                WHEN @AttributeType_Domain THEN N'' --CONCAT(N'srcDBA', @SourceAttribute_ID, N'.Code = tgtDBA', @TargetAttribute_ID, N'.Code') -- Compare on Code (rather than attribute value) for self-referencing DBAs  
                   
                 -- For File attributes, only need to ensure both are null or not null at this point. File content is compared later.  
                WHEN @AttributeType_File THEN CONCAT(N'(  
                   (   tgt.', QUOTENAME(TargetAttribute_ColumnName), N' IS NOT NULL   
                    AND src.', QUOTENAME(SourceAttribute_ColumnName), N' IS NOT NULL)  
                OR ISNULL(tgt.', QUOTENAME(TargetAttribute_ColumnName),', src.', QUOTENAME(SourceAttribute_ColumnName), N') IS NULL)' )  
                   
                 -- For Freeform attributes, compare values directly  
                ELSE CONCAT(N'(tgt.', QUOTENAME(TargetAttribute_ColumnName), N' = src.', QUOTENAME(SourceAttribute_ColumnName), CASE WHEN TargetAttribute_ColumnName <> N'Code' -- Code is not nullable  
                    THEN CONCAT(N' OR ISNULL(tgt.', QUOTENAME(TargetAttribute_ColumnName),', src.', QUOTENAME(SourceAttribute_ColumnName), N') IS NULL') END, N')')  
                END)  
        FROM #AttributeMapping  
  
        SELECT   
             @AttributeValueSetClause += CONCAT(N'  
            ,', QUOTENAME(TargetAttribute_ColumnName), N' = src.', QUOTENAME(SourceAttribute_ColumnName))  
  
            ,@SourceAttributesSelectClause += CONCAT(N'  
            ,', SourceAttribute_ColumnName)  
  
            ,@TargetAttributesSelectClause += CONCAT(N'  
            ,', TargetAttribute_ColumnName)  
        FROM #AttributeMapping  
        WHERE AttributeType_ID = @AttributeType_Freeform  
  
        DECLARE @SQL NVARCHAR(MAX);  
  
        IF @IsFirstSyncAttempt = 1  
        BEGIN  
            -- This is the first sync attempt. Members are matched by Code (subsequent syncs will use Source_ID). Members that  
            -- already exist in the target Entity must *exactly* match those in the source Entity, or sync will fail. Because initial sync   
            -- must not cause data loss on the target Entity. It can add, but not modify or delete, existing data.  
            SET @SQL = CONCAT(N'  
PRINT CONCAT(SYSDATETIME(), N'': Initial sync, purging soft-deleted target members'');  
    DELETE mdm.', QUOTENAME(@TargetEntity_EN_TableName), N'  
    WHERE   Version_ID = @TargetVersion_ID  
        AND Status_ID = ', @Status_Deactivated, N' -- Soft-deleted  
  
PRINT CONCAT(SYSDATETIME(), N'': Initial sync, checking for member mismatches'');  
    UPDATE tgt  
    SET  Source_ID = src.ID  
        ,ValidationStatus_ID = src.ValidationStatus_ID  
        ,EnterDTM = src.EnterDTM  
        ,EnterUserID = src.EnterUserID  
        ,LastChgDTM = src.LastChgDTM  
        ,LastChgUserID = src.LastChgUserID  
        ,Source_LastChgTS = src.LastChgTS  
    FROM mdm.', QUOTENAME(@TargetEntity_EN_TableName), N' tgt  
    INNER JOIN mdm.', QUOTENAME(@SourceEntity_EN_TableName), N' src  
    ON      src.Status_ID = ', @Status_Active, N' -- Active',  
        @AttributeValueMatchClause, N'  
    WHERE   tgt.Version_ID = @TargetVersion_ID  
        AND src.Version_ID = @SourceVersion_ID;  
  
    DECLARE @FirstNonmatchedMemberCode NVARCHAR(250) = NULL;  
    SELECT TOP 1   
        @FirstNonmatchedMemberCode = Code  
    FROM mdm.', QUOTENAME(@TargetEntity_EN_TableName), N'  
    WHERE   Version_ID = @TargetVersion_ID  
        AND Source_ID IS NULL;  
          
    IF @FirstNonmatchedMemberCode IS NOT NULL  
    BEGIN   
        DECLARE @ErrorMessage NVARCHAR(MAX) = CONCAT(N''MDSERR200212|Initial sync of entity has failed. Target entity contains at least one member that does not match a source entity member. First member code: "{0}"|'', @FirstNonmatchedMemberCode, N''|''); -- Adding a trailing "|" char to separate the member Code from any error context info added to the error message by the catch block.  
        SET @ErrorMessage = REPLACE(@ErrorMessage, ''%'', ''%%'')-- escape out format specifier  
        RAISERROR(@ErrorMessage, 16, 1);  
    END  
            ');  
  
            --PRINT @SQL  
            EXEC sp_executesql @SQL, N'@SourceVersion_ID INT, @TargetVersion_ID INT', @SourceVersion_ID, @TargetVersion_ID;  
  
            -- Compare file attribute values  
            IF @HasFileAttribute = 1  
            BEGIN  
PRINT CONCAT(SYSDATETIME(), N': Comparing file attribute values');  
  
                SET @SQL = N'';  
                SELECT @SQL += CONCAT(N'  
    ', CASE WHEN LEN(@SQL) = 0 THEN N'INSERT INTO #FileAttributeValueMapping' ELSE N'UNION ALL' END, N'  
    SELECT  
         tgt.ID     TargetMember_ID  
        ,tgt.Code   TargetMemberCode  
        ,', TargetAttribute_ID, N'     TargetAttribute_ID  
        ,', QUOTENAME(TargetAttribute_ColumnName, N''''), N' TargetColumnName  
        ,tgt.', QUOTENAME(TargetAttribute_ColumnName), N' TargetFile_ID  
        ,src.ID     SourceMember_ID  
        ,src.', QUOTENAME(SourceAttribute_ColumnName), N' SourceFile_ID  
        ,1          MatchedOnInitialSync  
    FROM mdm.', QUOTENAME(@TargetEntity_EN_TableName), N' tgt  
    INNER JOIN mdm.', QUOTENAME(@SourceEntity_EN_TableName), N' src  
    ON      tgt.Version_ID = @TargetVersion_ID  
        AND tgt.Source_ID = src.ID  
        AND src.Version_ID = @SourceVersion_ID  
    WHERE tgt.', QUOTENAME(TargetAttribute_ColumnName), N' IS NOT NULL  
                ')  
                FROM #AttributeMapping  
                WHERE AttributeType_ID = @AttributeType_File  
  
                --PRINT @SQL;  
                EXEC sp_executesql @SQL, N'@SourceVersion_ID INT, @TargetVersion_ID INT', @SourceVersion_ID, @TargetVersion_ID;  
  
PRINT CONCAT(SYSDATETIME(), N': Updating tblFile.Source_ID');  
                UPDATE tgtFile  
                SET   
                     Source_ID = srcFile.ID  
                    ,Source_LastChgTS = CAST(srcFile.LastChgTS AS VARBINARY(8))  
                    ,EnterUserID = srcFile.EnterUserID  
                    ,EnterDTM = srcFile.EnterDTM  
                    ,LastChgUserID = srcFile.LastChgUserID  
                    ,LastChgDTM = srcFile.LastChgDTM  
                FROM #FileAttributeValueMapping map  
                INNER JOIN mdm.tblFile tgtFile  
                ON map.TargetFile_ID = tgtFile.ID  
                INNER JOIN mdm.tblFile srcFile  
                ON map.SourceFile_ID = srcFile.ID  
                WHERE   tgtFile.[FileName]      = srcFile.[FileName] -- column not nullable  
                    AND tgtFile.FileContentType = srcFile.FileContentType -- column not nullable  
                    AND (tgtFile.FileContent    = srcFile.FileContent OR ISNULL(tgtFile.FileContent, srcFile.FileContent) IS NULL) -- column nullable  
  
PRINT CONCAT(SYSDATETIME(), N': Checking if a target member has a file attribute mismatch.');  
                DECLARE @FirstNonmatchedMemberCode NVARCHAR(250) = NULL;  
                SELECT TOP 1   
                    @FirstNonmatchedMemberCode = map.TargetMemberCode  
                FROM #FileAttributeValueMapping map  
                INNER JOIN mdm.tblFile tgtFile  
                ON map.TargetFile_ID = tgtFile.ID  
                WHERE tgtFile.Source_ID IS NULL;  
          
                IF @FirstNonmatchedMemberCode IS NOT NULL  
                BEGIN   
                    SET @ErrorMessage = CONCAT(N'MDSERR200212|Initial sync of entity has failed. Target entity contains at least one member that does not match a source entity member. First member code: "{0}"|', @FirstNonmatchedMemberCode, N'|');-- Adding a trailing "|" char to separate the member Code from any error context info added to the error message by the catch block.  
                    SET @ErrorMessage = REPLACE(@ErrorMessage, '%', '%%')-- escape out format specifier  
                    RAISERROR(@ErrorMessage, 16, 1);  
                END  
  
            END -- compare file attribute values  
  
        END; -- initial sync  
  
PRINT CONCAT(SYSDATETIME(), N': Updating target entity members (freeform attributes only)');  
        SET @SQL = CONCAT(N'  
    MERGE mdm.', QUOTENAME(@TargetEntity_EN_TableName), N' tgt  
    USING  
    (  
        SELECT  
             ID  
            ,ValidationStatus_ID  
            ,EnterDTM  
            ,EnterUserID  
            ,LastChgDTM  
            ,LastChgUserID  
            ,LastChgTS',  
            @SourceAttributesSelectClause, N'  
        FROM mdm.', QUOTENAME(@SourceEntity_EN_TableName), N'  
        WHERE   Version_ID = @SourceVersion_ID  
            AND Status_ID = ', @Status_Active, N' -- Active  
    ) src  
    ON      tgt.Version_ID = @TargetVersion_ID  
        AND tgt.Source_ID = src.ID  
  
    -- Update existing member   
    WHEN MATCHED AND tgt.Source_LastChgTS <> src.LastChgTS THEN  
        UPDATE SET  
             ValidationStatus_ID = src.ValidationStatus_ID  
            ,Source_LastChgTS = src.LastChgTS  
            ,EnterDTM = src.EnterDTM  
            ,EnterUserID = src.EnterUserID  
            ,LastChgDTM = src.LastChgDTM  
            ,LastChgUserID = src.LastChgUserID',  
            @AttributeValueSetClause, N'  
  
    -- Add new member  
    WHEN NOT MATCHED BY TARGET THEN  
        INSERT  
        (  
             Source_ID  
            ,Source_LastChgTS  
            ,Version_ID  
            ,Status_ID  
            ,ValidationStatus_ID  
            ,EnterDTM  
            ,EnterUserID  
            ,EnterVersionID  
            ,LastChgDTM  
            ,LastChgUserID  
            ,LastChgVersionID',  
            @TargetAttributesSelectClause, N'  
        )  
        VALUES  
        (  
             src.ID  
            ,src.LastChgTS  
            ,@TargetVersion_ID  
            ,', @Status_Active, N' -- Active  
            ,src.ValidationStatus_ID  
            ,src.EnterDTM  
            ,src.EnterUserID  
            ,@TargetVersion_ID  
            ,src.LastChgDTM  
            ,src.LastChgUserID  
            ,@TargetVersion_ID',  
            @SourceAttributesSelectClause, N'  
        )  
  
    -- Flag for hard-deletion  
    WHEN NOT MATCHED BY SOURCE AND tgt.Version_ID = @TargetVersion_ID THEN  
        UPDATE SET Source_ID = NULL -- Will hard-delete these later  
    ;  
  
PRINT CONCAT(SYSDATETIME(), N'': changed rows: '', @@ROWCOUNT);  
  
PRINT CONCAT(SYSDATETIME(), N'': Updating file attribute values'');  
  
            ');  
  
        --PRINT @SQL  
        EXEC sp_executesql @SQL, N'@SourceVersion_ID INT, @TargetVersion_ID INT', @SourceVersion_ID, @TargetVersion_ID;  
  
        IF @HasFileAttribute = 1  
        BEGIN  
PRINT CONCAT(SYSDATETIME(), N': Updating file attributes.');  
                SET @SQL = N'';  
                SELECT @SQL += CONCAT(N'  
    ', CASE WHEN LEN(@SQL) = 0 THEN N'INSERT INTO #FileAttributeValueMapping' ELSE N'UNION ALL' END, N'  
    SELECT  
         tgt.ID     TargetMember_ID  
        ,tgt.Code   TargetMemberCode  
        ,', TargetAttribute_ID, N' TargetAttribute_ID  
        ,N', QUOTENAME(TargetAttribute_ColumnName, N''''), N' TargetColumnName  
        ,tgt.', QUOTENAME(TargetAttribute_ColumnName), N' TargetFile_ID  
        ,src.ID     SourceMember_ID  
        ,src.', QUOTENAME(SourceAttribute_ColumnName), N' SourceFile_ID  
        ,0 MatchedOnInitialSync  
    FROM mdm.', QUOTENAME(@TargetEntity_EN_TableName), N' tgt  
    LEFT JOIN mdm.', QUOTENAME(@SourceEntity_EN_TableName), N' src  
    ON      tgt.Source_ID = src.ID  
        AND src.Version_ID = @SourceVersion_ID',   
                CASE WHEN @IsFirstSyncAttempt = 1 THEN CONCAT(N'  
    LEFT JOIN #FileAttributeValueMapping map  
    ON      tgt.ID = map.TargetMember_ID  
        AND map.TargetColumnName = N', QUOTENAME(TargetAttribute_ColumnName, N'''')) END, N'  
    WHERE   tgt.Version_ID = @TargetVersion_ID  
        AND (   tgt.', QUOTENAME(TargetAttribute_ColumnName), N' IS NOT NULL   
             OR src.', QUOTENAME(SourceAttribute_ColumnName), N' IS NOT NULL)',   
                CASE WHEN @IsFirstSyncAttempt = 1 THEN N'  
        AND map.TargetMember_ID IS NULL -- on initial sync, ignore attributes that have already been matched  
                ' END)  
                FROM #AttributeMapping   
                WHERE AttributeType_ID = @AttributeType_File  
            --PRINT @SQL  
            EXEC sp_executesql @SQL, N'@SourceVersion_ID INT, @TargetVersion_ID INT', @SourceVersion_ID, @TargetVersion_ID;  
  
            IF @IsFirstSyncAttempt = 1  
            BEGIN  
PRINT CONCAT(SYSDATETIME(), N': Deleting #FileAttributeValueMapping rows that were already matched.');  
                DELETE FROM #FileAttributeValueMapping  
                WHERE MatchedOnInitialSync = 1  
            END  
  
PRINT CONCAT(SYSDATETIME(), N': Checking for target entity files to delete.');  
            CREATE TABLE #FilesToDelete  
            (  
                 TargetMember_ID    INT NOT NULL  
                ,TargetAttribute_ID INT NOT NULL  
                ,TargetColumnName   SYSNAME NOT NULL  
                ,TargetFile_ID      INT NOT NULL  
            );  
            CREATE UNIQUE INDEX #ix_FilesToDelete_TargetMember_ID_TargetAttribute_ID ON #FilesToDelete(TargetMember_ID, TargetAttribute_ID);  
            CREATE INDEX #ix_FilesToDelete_TargetFile_ID ON #FilesToDelete(TargetFile_ID);  
            INSERT INTO #FilesToDelete  
            SELECT   
                 map.TargetMember_ID  
                ,map.TargetAttribute_ID  
                ,map.TargetColumnName  
                ,map.TargetFile_ID  
            FROM #FileAttributeValueMapping map  
            LEFT JOIN mdm.tblFile tgtFile  
            ON map.TargetFile_ID = tgtFile.ID  
            LEFT JOIN mdm.tblFile srcFile  
            ON map.SourceFile_ID = srcFile.ID  
            WHERE   map.TargetFile_ID IS NOT NULL   
                AND (map.SourceFile_ID IS NULL   
                    OR tgtFile.Source_ID <> srcFile.ID)  
              
            SET @TargetAttribute_ID = 0;  
            WHILE EXISTS (SELECT 1 FROM #FilesToDelete WHERE TargetAttribute_ID > @TargetAttribute_ID)  
            BEGIN  
                SET @SQL = N'';  
                SELECT TOP 1  
                    @TargetAttribute_ID = TargetAttribute_ID  
                    ,@SQL = CONCAT(N'  
        UPDATE tgt  
        SET ', QUOTENAME(TargetColumnName) ,N' = NULL  
        FROM mdm.', QUOTENAME(@TargetEntity_EN_TableName), N' tgt  
        INNER JOIN #FilesToDelete f  
        ON      tgt.ID = f.TargetMember_ID  
            AND tgt.Version_ID = @TargetVersion_ID  
            AND f.TargetAttribute_ID = @TargetAttribute_ID  
        ')  
                FROM #FilesToDelete  
                WHERE TargetAttribute_ID > @TargetAttribute_ID  
                ORDER BY TargetAttribute_ID ASC  
              
PRINT CONCAT(SYSDATETIME(), N': Setting to null values for attribute ID = ', @TargetAttribute_ID);  
                --PRINT @SQL  
                EXEC sp_executesql @SQL, N'@TargetVersion_ID INT, @TargetAttribute_ID INT', @TargetVersion_ID, @TargetAttribute_ID;  
PRINT CONCAT(SYSDATETIME(), N': ', @@ROWCOUNT, N' row(s) updated in table ', @TargetEntity_EN_TableName);  
  
            END  
  
PRINT CONCAT(SYSDATETIME(), N': Deleting rows from tblFile.');  
            DECLARE @File_ID mdm.IdList;  
            INSERT INTO @File_ID (ID)  
            SELECT TargetFile_ID  
            FROM #FilesToDelete   
  
            EXEC mdm.udpFilesDelete @File_ID = @File_ID, @CorrelationID = @CorrelationID;  
  
PRINT CONCAT(SYSDATETIME(), N': Deleting rows from #FileAttributeValueMapping for deleted file attributes.');  
            DELETE map  
            FROM #FileAttributeValueMapping map   
            INNER JOIN #FilesToDelete f  
            ON      map.TargetMember_ID = f.TargetMember_ID  
                AND map.TargetAttribute_ID = f.TargetAttribute_ID  
                AND map.SourceFile_ID IS NULL  
PRINT CONCAT(SYSDATETIME(), N': ', @@ROWCOUNT, N' rows deleted.');  
  
PRINT CONCAT(SYSDATETIME(), N': Clearing old TargetFIle_ID from #FileAttributeValueMapping for deleted file attributes (where there is a non-null source).');  
            UPDATE map  
            SET TargetFile_ID = NULL  
            FROM #FileAttributeValueMapping map   
            INNER JOIN #FilesToDelete f  
            ON      map.TargetMember_ID = f.TargetMember_ID  
                AND map.TargetAttribute_ID = f.TargetAttribute_ID  
                AND map.SourceFile_ID IS NOT NULL  
PRINT CONCAT(SYSDATETIME(), N': ', @@ROWCOUNT, N' rows updated.');  
  
PRINT CONCAT(SYSDATETIME(), N': Copying rows in mdm.tblFile.');  
            CREATE TABLE #NewFiles  
            (  
                 TargetMember_ID    INT NOT NULL  
                ,TargetAttribute_ID INT NOT NULL  
                ,TargetColumnName   SYSNAME NOT NULL  
                ,TargetFile_ID      INT NOT NULL  
            )  
            CREATE UNIQUE INDEX #ix_NewFiles_TargetMember_ID_TargetAttribute_ID ON #NewFiles(TargetMember_ID, TargetAttribute_ID);  
            -- Copy file attributes  
            MERGE mdm.tblFile tgtFile  
            USING  
            (  
                SELECT  
                     f.ID  
                    ,f.LastChgTS  
                    ,f.EnterUserID  
                    ,f.EnterDTM  
                    ,f.LastChgUserID  
                    ,f.LastChgDTM  
                    ,f.FileName  
                    ,f.FileContentType  
                    ,f.FileContent  
                    ,map.TargetMember_ID  
                    ,map.TargetAttribute_ID  
                    ,map.TargetColumnName  
                    ,map.TargetFile_ID  
                FROM mdm.tblFile f  
                INNER JOIN #FileAttributeValueMapping map  
                ON f.ID = map.SourceFile_ID  
            ) srcFile  
            ON tgtFile.ID = srcFile.TargetFile_ID  
  
            WHEN NOT MATCHED THEN  
                INSERT  
                (  
                     Source_ID  
                    ,Source_LastChgTS  
                    ,EnterUserID  
                    ,EnterDTM  
                    ,LastChgUserID  
                    ,LastChgDTM  
                    ,FileName  
                    ,FileContentType  
                    ,FileContent  
                )  
                VALUES  
                (  
                     srcFile.ID  
                    ,srcFile.LastChgTS  
                    ,srcFile.EnterUserID  
                    ,srcFile.EnterDTM  
                    ,srcFile.LastChgUserID  
                    ,srcFile.LastChgDTM  
                    ,srcFile.FileName  
                    ,srcFile.FileContentType  
                    ,srcFile.FileContent  
                )  
  
            WHEN MATCHED AND (ISNULL(tgtFile.Source_ID, 0) <> srcFile.ID OR tgtFile.Source_LastChgTS <> CAST(srcFile.LastChgTS AS VARBINARY(8))) THEN  
                UPDATE SET  
                     Source_ID = srcFile.ID  
                    ,Source_LastChgTS = srcFile.LastChgTS  
                    ,EnterUserID = srcFile.EnterUserID  
                    ,EnterDTM = srcFile.EnterDTM  
                    ,LastChgUserID = srcFile.LastChgUserID  
                    ,LastChgDTM = srcFile.LastChgDTM  
                    ,FileName = srcFile.FileName  
                    ,FileContentType = srcFile.FileContentType  
                    ,FileContent = srcFile.FileContent  
            OUTPUT srcFile.TargetMember_ID, srcFile.TargetAttribute_ID, srcFile.TargetColumnName, inserted.ID  
            INTO #NewFiles(TargetMember_ID, TargetAttribute_ID, TargetColumnName, TargetFile_ID)  
            ;  
  
PRINT CONCAT(SYSDATETIME(), N': ', @@ROWCOUNT, N' rows created.');  
  
            SET @TargetAttribute_ID = 0;  
            WHILE EXISTS (SELECT 1 FROM #NewFiles WHERE TargetAttribute_ID > @TargetAttribute_ID)  
            BEGIN  
PRINT CONCAT(SYSDATETIME(), N': Setting to new values for attribute ID = ', @TargetAttribute_ID);  
                SET @SQL = N'';  
                SELECT TOP 1  
                    @TargetAttribute_ID = TargetAttribute_ID  
                    ,@SQL = CONCAT(N'  
        UPDATE tgt  
        SET ', QUOTENAME(TargetColumnName) ,N' = f.TargetFile_ID  
        FROM mdm.', QUOTENAME(@TargetEntity_EN_TableName), N' tgt  
        INNER JOIN #NewFiles f  
        ON      tgt.ID = f.TargetMember_ID  
            AND tgt.Version_ID = @TargetVersion_ID  
            AND f.TargetAttribute_ID = @TargetAttribute_ID  
            AND ISNULL(', QUOTENAME(TargetColumnName) ,N', 0) <> f.TargetFile_ID -- ignore updates, only do new rows  
        ')  
                FROM #NewFiles  
                WHERE TargetAttribute_ID > @TargetAttribute_ID  
                ORDER BY TargetAttribute_ID ASC  
              
            --PRINT @SQL  
            EXEC sp_executesql @SQL, N'@TargetVersion_ID INT, @TargetAttribute_ID INT', @TargetVersion_ID, @TargetAttribute_ID;  
PRINT CONCAT(SYSDATETIME(), N': ', @@ROWCOUNT, N' rows updated in table ', @TargetEntity_EN_TableName);  
  
            END  
  
  
            -- Update file attributes (N/A?)  
  
  
        END -- update File attribute values  
  
PRINT CONCAT(SYSDATETIME(), N': Getting DBA dependencies on the target entity, to check for broken DBA relationships.');  
        CREATE TABLE #targetConsumers  
        (  
             DBA_ID     INT PRIMARY KEY  
            ,EntityName NVARCHAR(50)  
            ,TableName  SYSNAME NOT NULL  
            ,ColumnName SYSNAME NOT NULL  
        )  
        INSERT INTO #targetConsumers  
        SELECT  
             a.ID           AS DBA_ID  
            ,e.Name         AS EntityName  
            ,CASE a.MemberType_ID  
                WHEN @MemberType_Leaf THEN e.EntityTable  
                WHEN @MemberType_Consolidated THEN e.HierarchyParentTable  
                WHEN @MemberType_Collection THEN e.CollectionTable  
            END             AS TableName  
            ,a.TableColumn  AS ColumnName  
        FROM mdm.tblAttribute a  
        INNER JOIN mdm.tblEntity e  
        ON a.Entity_ID = e.ID  
        WHERE   a.DomainEntity_ID = @TargetEntity_ID   
            AND a.Entity_ID != @TargetEntity_ID -- ignore self-references  
  
        DECLARE   
             @DBA_ID        INT = 0  
            ,@EntityName    NVARCHAR(50)  
            ,@TableName     SYSNAME  
            ,@ColumnName    SYSNAME;  
        WHILE EXISTS (SELECT 1 FROM #targetConsumers WHERE DBA_ID > @DBA_ID)  
        BEGIN  
            SELECT TOP 1  
                 @DBA_ID =  DBA_ID  
                ,@EntityName = EntityName  
                ,@TableName = TableName  
                ,@ColumnName = ColumnName  
            FROM #targetConsumers   
            WHERE DBA_ID > @DBA_ID  
            ORDER BY DBA_ID;  
  
            SET @SQL = CONCAT(N'  
    DECLARE @ErrorMessage NVARCHAR(MAX) = NULL  
    SELECT TOP 1  
        @ErrorMessage = CONCAT(N''MDSERR300004|The member with code "{0}" cannot be deleted. It is currently used by entity "{1}", member code "{2}"|'', tgt.Code, N''|', @EntityName, '|'', ref.Code, N''|'') -- Adding a trailing "|" char to separate the member Code from any error context info added to the error message by the catch block.  
    FROM mdm.', QUOTENAME(@TableName), N' ref  
    INNER JOIN mdm.', QUOTENAME(@TargetEntity_EN_TableName), N' tgt  
    ON      ref.Version_ID = tgt.Version_ID  
        AND ref.', QUOTENAME(@ColumnName), N' = tgt.ID  
    WHERE   tgt.Version_ID = @TargetVersion_ID  
        AND tgt.Source_ID IS NULL;  
  
    IF @ErrorMessage IS NOT NULL  
    BEGIN  
        SET @ErrorMessage = REPLACE(@ErrorMessage, ''%'', ''%%'')-- escape out format specifier  
        RAISERROR (@ErrorMessage, 16, 1);  
    END  
    ');  
PRINT CONCAT(SYSDATETIME(), N': Looking for consuming members in Entity ''', @EntityName, ''', DBA_ID = ', @DBA_ID);  
            EXEC sp_executesql @SQL, N'@TargetVersion_ID INT', @TargetVersion_ID;  
  
        END  
  
  
        SET @SQL = CONCAT(N'  
    DELETE mdm.', QUOTENAME(@TargetEntity_EN_TableName), N'  
    WHERE   Version_ID = @TargetVersion_ID  
        AND Source_ID IS NULL;')  
        --PRINT @SQL  
PRINT CONCAT(SYSDATETIME(), N': Deleting target members');  
        EXEC sp_executesql @SQL, N'@TargetVersion_ID INT', @TargetVersion_ID;  
  
PRINT CONCAT(SYSDATETIME(), N': Deleted rows: ', @@ROWCOUNT);  
  
  
        PRINT CONCAT(SYSDATETIME(), N': Sync successful. Updating tblSyncRelationship.');  
  
        DECLARE @Now DATETIME2(7) = GETUTCDATE();  
  
        -- update the entity timestamp in the sync table  
        UPDATE mdm.tblSyncRelationship  
        SET  LastSuccessfulSyncTimestamp = @SourceEntityTimestamp  
            ,LastSuccessfulSyncDTM = @Now  
            ,LastSyncAttemptDTM = @Now  
            ,LastSyncAttemptStatus = @SyncStatus_Success  
            ,LastSyncAttemptErrorInfo = NULL  
        WHERE   TargetEntity_ID = @TargetEntity_ID  
            AND TargetVersion_ID = @TargetVersion_ID  
  
        --Commit only if we are not nested  
        IF @TranCounter = 0 COMMIT TRANSACTION;  
  
    END TRY  
    --Compensate as necessary  
    BEGIN CATCH  
  
        -- Get error info.  
        DECLARE  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        IF @TranCounter = 0 ROLLBACK TRANSACTION;  
        ELSE IF XACT_STATE() <> -1 ROLLBACK TRANSACTION TX;  
  
PRINT CONCAT(SYSDATETIME(), N': Sync failed. Updating tblSyncRelationship.');  
        -- update the entity timestamp in the sync table  
        UPDATE mdm.tblSyncRelationship  
        SET    
             LastSyncAttemptDTM = GETUTCDATE()  
            ,LastSyncAttemptStatus = @SyncStatus_Failed  
            ,LastSyncAttemptErrorInfo = @ErrorMessage  
        WHERE   TargetEntity_ID = @TargetEntity_ID  
            AND TargetVersion_ID = @TargetVersion_ID  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
  
    END CATCH;  
  
    SET NOCOUNT OFF;  
END -- Proc
go

