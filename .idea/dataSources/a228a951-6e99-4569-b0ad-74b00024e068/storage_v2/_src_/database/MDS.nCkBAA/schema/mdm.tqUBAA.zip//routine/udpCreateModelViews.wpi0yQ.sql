/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
EXEC mdm.udpCreateModelViews @Model_ID = 2;  
  
*/  
CREATE PROCEDURE mdm.udpCreateModelViews  
    @Model_ID       INT  
AS  
BEGIN  
    SET NOCOUNT ON;  
    DECLARE @SQL                            NVARCHAR(MAX),  
            @TransactionViewName            SYSNAME,  
            @AnnotationViewName             SYSNAME,  
            @ValidationLogViewName          SYSNAME,  
            @UserValidationViewName         SYSNAME,  
            @TransactionTableName           SYSNAME,  
            @AnnotationTableName            SYSNAME,  
            @ValidationLogTableName         SYSNAME;  
  
    SET @TransactionViewName = mdm.udfGetTransactionViewName(@Model_ID);  
    SET @AnnotationViewName = mdm.udfGetTransactionAnnotationViewName(@Model_ID);  
    SET @ValidationLogViewName = mdm.udfGetValidationLogViewName(@Model_ID);  
    SET @UserValidationViewName = mdm.udfGetUserValidationViewName(@Model_ID);  
  
    SET @TransactionTableName = mdm.udfGetTransactionTableName(@Model_ID);  
    SET @AnnotationTableName = mdm.udfGetTransactionAnnotationTableName(@Model_ID);  
    SET @ValidationLogTableName = mdm.udfGetValidationLogTableName(@Model_ID);  
  
    --Delete Model Views.  
    EXEC mdm.udpDeleteViews @Model_ID, NULL, NULL;  
  
    --Create the transaction view  
    SET @SQL = CONCAT(N'  
        CREATE VIEW [mdm].', QUOTENAME(@TransactionViewName), N'  
        AS  
        SELECT  
            T.ID,  
            M.ID as Model_ID,  
            M.Name as Model_Name,  
            M.MUID as Model_MUID,  
            T.Version_ID as Version_ID,  
            MV.Name as Version_Name,  
            MV.MUID as Version_MUID,  
            T.TransactionType_ID as TransactionType_ID,  
            CASE WHEN H.Name IS NULL THEN N'''' ELSE H.Name END [Explicit Hierarchy],  
            T.Hierarchy_ID as [ExplicitHierarchy_ID],  
            H.MUID as [ExplicitHierarchy_MUID],  
            CASE WHEN E.Name IS NULL THEN N'''' ELSE E.Name END as Entity,  
            T.Entity_ID as Entity_ID,  
            E.MUID as Entity_MUID,  
            CASE WHEN A.Name IS NULL THEN N'''' ELSE A.Name END as Attribute,  
            T.Attribute_ID as Attribute_ID,  
            A.MUID as Attribute_MUID,  
            T.Member_ID as [Member_ID],  
            T.Member_MUID as [Member_MUID],  
            CASE WHEN T.MemberCode IS NULL THEN N'''' ELSE T.MemberCode END as [Member Code],  
            T.MemberType_ID AS MemberType_ID,  
            CASE WHEN T.OldCode IS NULL THEN N'''' ELSE T.OldCode END as [Prior Value],  
            CASE WHEN T.NewCode IS NULL THEN N'''' ELSE T.NewCode END as [New Value],  
            CASE WHEN T.EnterDTM IS NULL THEN N'''' ELSE T.EnterDTM END as [Date Time],  
            U.UserName as [User Name],  
            T.EnterUserID AS [User ID],  
            U.MUID as [User_MUID]  
        FROM  
                        mdm.', QUOTENAME(@TransactionTableName), N' T  
            LEFT JOIN   mdm.tblModelVersion MV ON T.Version_ID = MV.ID  
            LEFT JOIN   mdm.tblModel M ON M.ID = MV.Model_ID  
            LEFT JOIN   mdm.tblHierarchy H ON T.Hierarchy_ID = H.ID  
            LEFT JOIN   mdm.tblEntity E ON T.Entity_ID = E.ID  
            LEFT JOIN   mdm.tblAttribute A ON T.Attribute_ID = A.ID  
            LEFT JOIN   mdm.tblUser U ON T.EnterUserID = U.ID  
        ');  
    EXEC sp_executesql @SQL;  
  
    --Create the annotation view  
    SET @SQL = CONCAT(N'  
        CREATE VIEW [mdm].', QUOTENAME(@AnnotationViewName), N'  
        AS  
        SELECT  
            TA.ID,  
            T.ID AS [Transaction ID],  
            CASE WHEN TA.Comment IS NULL THEN N'''' ELSE TA.Comment END AS [User Comment],  
            CASE WHEN TA.EnterDTM IS NULL THEN N'''' ELSE TA.EnterDTM END as [Date Time],  
            U.UserName as [User Name],  
            U.ID AS [User ID],  
            U.MUID as [User_MUID],  
            CASE WHEN TA.LastChgDTM IS NULL THEN N'''' ELSE TA.LastChgDTM END as [LastChgDateTime],  
            U2.UserName as [LastChgUserName],  
            U2.ID AS [LastChgUserID],  
            U2.MUID as [LastChgUserMUID]  
        FROM  
            [mdm].', QUOTENAME(@AnnotationTableName), N' TA  
                INNER JOIN [mdm].', QUOTENAME(@TransactionTableName), N' T ON TA.Transaction_ID = T.ID  
                LEFT JOIN [mdm].[tblUser] U ON TA.EnterUserID = U.ID  
                LEFT JOIN [mdm].[tblUser] U2 ON TA.LastChgUserID = U2.ID  
        ');  
    EXEC sp_executesql @SQL;  
  
    --Create the validation log view  
    SET @SQL = CONCAT(N'  
        CREATE VIEW [mdm].', QUOTENAME(@ValidationLogViewName), N'  
        AS  
        SELECT  
             tAll.ID,    
            M.ID [Model_ID],    
            M.MUID [Model_MUID],    
            M.Name [Model_Name],    
            tAll.Version_ID,    
            V.MUID [Version_MUID],    
            V.Name [Version_Name],    
            tAll.Hierarchy_ID,    
            H.MUID [Hierarchy_MUID],    
            H.Name [Hierarchy_Name],    
            tAll.Entity_ID,    
            E.MUID [Entity_MUID],    
            E.Name [Entity_Name],    
            tAll.MemberType_ID,    
            tAll.Member_ID,    
            tAll.Member_MUID,    
            tAll.MemberCode,    
            BR.RuleConditionText [Description],    
            tAll.BRBusinessRule_ID,    
            BR.MUID [BRBusinessRule_MUID],    
            BR.Name [BRBusinessRule_Name],    
            tAll.BRItem_ID,    
            BRI.MUID [BRItem_MUID],    
            BRI.ItemText [BRItem_Name],    
            LR.Parent_ID [BRItem_Category],  
            tAll.EnterDTM,    
            U1.ID [EnterUserID],    
            U1.MUID [EnterUserMUID] ,    
            U1.UserName [EnterUserName],    
            tAll.LastChgDTM    [LastChgDTM],    
            U2.ID [LastChgUserID],    
            U2.MUID [LastChgUse_MUID],    
            U2.UserName [LastChgUserName],    
            tAll.NotificationStatus_ID  
        FROM  
            [mdm].', QUOTENAME(@ValidationLogTableName), N' tAll  
            INNER JOIN  
            (  
                SELECT  
                    Version_ID,  
                    Hierarchy_ID,  
                    Entity_ID,  
                    Member_ID,  
                    MemberType_ID,  
                    BRBusinessRule_ID,  
                    BRItem_ID,  
                    MAX(LastChgDTM) LastUpdated  
                FROM  
                    [mdm].', QUOTENAME(@ValidationLogTableName), N'  
                GROUP BY  
                    Version_ID,  
                    Hierarchy_ID,  
                    Entity_ID,  
                    Member_ID,  
                    MemberType_ID,  
                    BRBusinessRule_ID,  
                    BRItem_ID  
            ) tDistinct ON  
                    tAll.Version_ID = tDistinct.Version_ID AND  
                    tAll.Hierarchy_ID = tDistinct.Hierarchy_ID AND  
                    tAll.Entity_ID = tDistinct.Entity_ID AND  
                    tAll.Member_ID = tDistinct.Member_ID AND  
                    tAll.MemberType_ID = tDistinct.MemberType_ID AND  
                    tAll.BRBusinessRule_ID = tDistinct.BRBusinessRule_ID AND  
                    tAll.BRItem_ID = tDistinct.BRItem_ID AND  
                    tAll.LastChgDTM = tDistinct.LastUpdated AND  
                tAll.Status_ID = 1  
            LEFT JOIN mdm.tblBRBusinessRule BR ON BR.ID = tAll.BRBusinessRule_ID    
            LEFT JOIN mdm.tblBRItem BRI ON BRI.ID = tAll.BRItem_ID    
            LEFT JOIN mdm.tblBRItemTypeAppliesTo BRIAT ON BRI.BRItemAppliesTo_ID = BRIAT.ID  
            LEFT JOIN mdm.tblListRelationship LR ON BRIAT.ApplyTo_ID = LR.ID  
            LEFT JOIN mdm.tblModelVersion V ON V.ID = tAll.Version_ID    
            LEFT JOIN mdm.tblModel M ON M.ID = V.Model_ID    
            LEFT JOIN mdm.tblUser U1 ON U1.ID =  tAll.EnterUserID    
            LEFT JOIN mdm.tblUser U2 ON U2.ID =  tAll.LastChgUserID    
            LEFT JOIN mdm.tblEntity E ON E.ID = tAll.Entity_ID    
            LEFT JOIN mdm.tblHierarchy H ON H.ID = tAll.Hierarchy_ID;    
        ');  
    EXEC sp_executesql @SQL;  
  
    --Create the validation log view by user  
    SET @SQL = CONCAT(N'  
        CREATE VIEW [mdm].', QUOTENAME(@UserValidationViewName), N'  
        AS  
        SELECT  
            tLog.ID                                 ValidationIssue_ID,  
            tLog.Version_ID                         Version_ID,  
            tLog.Version_Name                       VersionName,  
            tLog.Model_ID                           Model_ID,  
            tLog.Model_Name                         ModelName,  
            tLog.Entity_ID                          Entity_ID,  
            tLog.Entity_Name                        EntityName,  
            tLog.Hierarchy_ID                       Hierarchy_ID,  
            ISNULL(tLog.Hierarchy_Name, N'''')        HierarchyName,  
            tLog.Member_ID                          Member_ID,  
            tLog.MemberCode                         MemberCode,  
            tLog.MemberType_ID                      MemberType_ID,  
            tLog.Description                        ConditionText,  
            tLog.BRItem_Name                        ActionText,  
            tLog.BRBusinessRule_ID                  BusinessRuleID,  
            tLog.BRBusinessRule_Name                BusinessRuleName,  
            N''''                                   PriorityRank,  
            CASE WHEN vBR.BusinessRule_NotificationGroupID IS NULL THEN vBR.BusinessRule_NotificationUserID ELSE ugu.[User_ID] END [User_ID],  
            CASE WHEN vBR.BusinessRule_NotificationGroupID IS NULL THEN vBR.BusinessRule_NotificationUserName ELSE ugu.[User_Name] END [UserName],  
            tLog.LastChgUserID                      LastChgUserID,  
            tLog.LastChgDTM                         DateCreated,  
            CAST(NULL AS DATETIME2(3))              DateDue,  
            tLog.NotificationStatus_ID              NotificationStatus_ID,  
            tNotify.Name                            NotificationStatus,  
            tRule.Property_Value                    Property_Value,  
            LR.Parent_ID                            BRItem_Category  
        FROM  
            [mdm].', QUOTENAME(@ValidationLogViewName), N' tLog  
            LEFT JOIN mdm.viw_SYSTEM_SCHEMA_BUSINESSRULE_PROPERTIES tRule  
                ON    tLog.BRBusinessRule_ID = tRule.BusinessRule_ID  
                AND   tLog.BRItem_ID = tRule.Item_ID  
            LEFT JOIN mdm.tblBRItemTypeAppliesTo BRIAT ON tRule.Item_AppliesTo_ID = BRIAT.ID  
            LEFT JOIN mdm.tblListRelationship LR ON BRIAT.ApplyTo_ID = LR.ID  
            LEFT JOIN mdm.viw_SYSTEM_SCHEMA_BUSINESSRULES vBR  
                ON vBR.BusinessRule_ID = tRule.BusinessRule_ID  
            LEFT JOIN (SELECT OptionID ID, ListOption Name FROM mdm.tblList WHERE ListName = N''NotificationStatus'') tNotify  
                ON tLog.NotificationStatus_ID = tNotify.ID  
            LEFT JOIN mdm.viw_SYSTEM_USERGROUP_USERS ugu  
                ON vBR.BusinessRule_NotificationGroupID = ugu.UserGroup_ID;  
        ');  
    EXEC sp_executesql @SQL;  
END
go

