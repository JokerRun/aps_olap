/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Gets all user info.  
  
EXEC mdm.udpUserListGet  
  
*/  
CREATE PROCEDURE mdm.udpUserListGet  
(  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
    SELECT   
        u.ID,  
        u.MUID,  
        u.Status_ID,  
        u.SID,  
        u.UserName,  
        u.DisplayName,  
        u.Description,  
        u.EmailAddress,  
        u.LastLoginDTM,  
        COALESCE(u.EnterUserID,0) AS EnterUserID,  
        eu.MUID AS EnterUserMUID,  
        COALESCE(eu.UserName,N'') AS EnterUserName,  
        COALESCE(eu.DisplayName,N'') AS EnterUserDisplayName,  
        u.EnterDTM,  
        COALESCE(u.LastChgUserID,0) AS LastChgUserID,  
        lcu.MUID AS LastChgUserMUID,  
        COALESCE(lcu.UserName,N'') AS LastChgUserName,  
        COALESCE(lcu.DisplayName,N'') AS LastChgUserDisplayName,  
        u.LastChgDTM,  
        pref.PreferenceValue AS EmailType   
    FROM mdm.tblUser u  
    LEFT JOIN mdm.tblUser eu   
    ON u.EnterUserID = eu.ID   
    LEFT JOIN mdm.tblUser lcu   
    ON u.LastChgUserID = lcu.ID  
    LEFT JOIN mdm.tblUserPreference pref   
    ON      u.ID = pref.User_ID   
        AND PreferenceName=N'lstEmail'  
    WHERE u.Status_ID = 1  
    ORDER BY u.ID  
  
    SET NOCOUNT OFF  
END --proc
go

