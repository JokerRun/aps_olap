/*  
	SELECT mdm.udfGetTransactionAnnotationTableName(7)  
*/  
/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE FUNCTION mdm.udfGetTransactionAnnotationTableName  
(  
	@Model_ID   INT  
)   
RETURNS sysname  
/*WITH SCHEMABINDING*/  
AS BEGIN  
  
	RETURN CONCAT(N'tbl_', @Model_ID, N'_AN');  
  
END; --fn
go

