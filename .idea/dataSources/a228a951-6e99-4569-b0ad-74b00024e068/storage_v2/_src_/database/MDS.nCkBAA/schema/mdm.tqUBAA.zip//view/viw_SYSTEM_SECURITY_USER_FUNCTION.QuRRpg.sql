/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE VIEW [mdm].[viw_SYSTEM_SECURITY_USER_FUNCTION]  
/*WITH SCHEMABINDING*/  
AS  
SELECT  
     RoleAccess_ID  
    ,RoleAccess_MUID  
  
    ,Principal_ID   [User_ID]  
    ,Principal_MUID User_MUID  
    ,Principal_Name UserName  
  
    ,Principal_ID  
    ,Principal_MUID  
    ,PrincipalType_ID  
    ,Principal_Name  
  
    ,Function_ID  
    ,Function_Name  
  
    --Auditing  
    ,EnterDTM  
    ,EnterUserID  
    ,EnterUserMUID  
    ,EnterUserName  
    ,LastChgDTM  
    ,LastChgUserID  
    ,LastChgUserMUID  
    ,LastChgUserName  
FROM mdm.viw_SYSTEM_SECURITY_ROLE_ACCESSCONTROL_FUNCTIONAL  
WHERE PrincipalType_ID = 1 -- User  
  
UNION ALL  
SELECT  
     f.RoleAccess_ID  
    ,f.RoleAccess_MUID  
  
    ,u.ID   [User_ID]  
    ,u.MUID User_MUID  
    ,u.UserName  
  
    ,f.Principal_ID  
    ,f.Principal_MUID  
    ,f.PrincipalType_ID  
    ,f.Principal_Name  
  
    ,f.Function_ID  
    ,f.Function_Name  
  
    --Auditing  
    ,f.EnterDTM  
    ,f.EnterUserID  
    ,f.EnterUserMUID  
    ,f.EnterUserName  
    ,f.LastChgDTM  
    ,f.LastChgUserID  
    ,f.LastChgUserMUID  
    ,f.LastChgUserName  
FROM mdm.viw_SYSTEM_SECURITY_ROLE_ACCESSCONTROL_FUNCTIONAL f  
INNER JOIN mdm.tblUserGroup AS ug   
ON f.Principal_ID = ug.ID AND ug.Status_ID = 1 -- Active  
INNER JOIN mdm.tblUserGroupAssignment AS uga  
ON ug.ID = uga.UserGroup_ID  
INNER JOIN mdm.tblUser AS u   
ON uga.[User_ID] = u.ID   AND u.Status_ID = 1 -- Active  
WHERE f.PrincipalType_ID = 2 -- Group
go

