/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    Drops all the entity staging views to view an error  
    EXEC mdm.udpDeleteEntityStagingErrorDetailViews 21  
*/  
CREATE PROCEDURE mdm.udpEntityStagingDeleteErrorDetailViews  
    @Entity_ID  INT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
AS  
BEGIN  
    DECLARE  
        @StagingBase            sysname,  
        @SQLDropView            NVARCHAR(MAX),  
        @MemberErrorViewName    NVARCHAR(MAX),  
        @RelationErrorViewName  NVARCHAR(MAX);  
  
    SELECT  
        @StagingBase = StagingBase  
        FROM  
            mdm.tblEntity  
        WHERE  
            ID = @Entity_ID;  
      
    SET @MemberErrorViewName = N'stg.' + QUOTENAME('viw_' + @StagingBase + '_MemberErrorDetails');  
    SET @RelationErrorViewName = N'stg.' + QUOTENAME('viw_' + @StagingBase + '_RelationshipErrorDetails');  
  
    SET @SQLDropView = N'  
        IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(' + QUOTENAME(@MemberErrorViewName, N'''') + N'))  
          DROP VIEW ' + @MemberErrorViewName + N'  
        IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(' + QUOTENAME(@RelationErrorViewName, N'''') + N'))  
          DROP VIEW ' + @RelationErrorViewName;  
  
    EXEC(@SQLDropView);  
  
  
END;
go

