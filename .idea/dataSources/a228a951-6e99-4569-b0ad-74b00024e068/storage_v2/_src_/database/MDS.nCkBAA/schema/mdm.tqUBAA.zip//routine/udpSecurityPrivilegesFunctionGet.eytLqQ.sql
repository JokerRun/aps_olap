/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
    Returns function privileges.  
      
    DECLARE @PrivilegeTable mdm.Identifier  
    EXEC mdm.udpSecurityPrivilegesFunctionGet   
         @PrincipalType_ID = NULL  
        ,@Principal_MUID = NULL  
        ,@Principal_ID = NULL  
        ,@Principal_Name = NULL  
        ,@PrivilegeTable = @PrivilegeTable  
*/  
CREATE PROCEDURE mdm.udpSecurityPrivilegesFunctionGet  
(  
     @PrincipalType_ID      INT = NULL  
    ,@Principal_MUID        UNIQUEIDENTIFIER = NULL  
    ,@Principal_ID          INT = NULL  
    ,@Principal_Name        NVARCHAR(355) = NULL  
    ,@PrivilegeTable        mdm.Identifier READONLY -- caller should ensure table does not include rows where both MUID and Name are blank  
    ,@CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    SET @Principal_Name = UPPER(@Principal_Name);  
    IF EXISTS(SELECT 1 FROM @PrivilegeTable)  
    BEGIN  
        SELECT   
             p.RoleAccess_ID  
            ,p.RoleAccess_MUID  
  
            ,p.Principal_ID  
            ,p.Principal_MUID  
            ,p.PrincipalType_ID  
            ,p.Principal_Name  
  
            ,p.Function_ID  
            ,p.Function_Name  
  
            --Auditing  
            ,p.EnterDTM  
            ,p.EnterUserID  
            ,p.EnterUserMUID  
            ,p.EnterUserName  
            ,p.LastChgDTM  
            ,p.LastChgUserID  
            ,p.LastChgUserMUID  
            ,p.LastChgUserName  
        FROM mdm.viw_SYSTEM_SECURITY_ROLE_ACCESSCONTROL_FUNCTIONAL p  
        INNER JOIN @PrivilegeTable crit  
        ON      (@PrincipalType_ID IS NULL OR p.PrincipalType_ID = @PrincipalType_ID)   
            AND (@Principal_MUID IS NULL   OR p.Principal_MUID = @Principal_MUID)   
            AND (@Principal_ID IS NULL     OR p.Principal_ID = @Principal_ID)   
            AND (@Principal_Name IS NULL   OR UPPER(p.Principal_Name) = @Principal_Name)   
            AND (crit.MUID IS NULL OR crit.MUID = p.RoleAccess_MUID)   
            AND (crit.Name IS NULL OR UPPER(crit.Name) = UPPER(p.Function_Name))   
            AND (crit.ID IS NULL OR crit.ID = p.Function_ID)  
    END ELSE  
    BEGIN  
        SELECT   
             p.RoleAccess_ID  
            ,p.RoleAccess_MUID  
  
            ,p.Principal_ID  
            ,p.Principal_MUID  
            ,p.PrincipalType_ID  
            ,p.Principal_Name  
  
            ,p.Function_ID  
            ,p.Function_Name  
  
            --Auditing  
            ,p.EnterDTM  
            ,p.EnterUserID  
            ,p.EnterUserMUID  
            ,p.EnterUserName  
            ,p.LastChgDTM  
            ,p.LastChgUserID  
            ,p.LastChgUserMUID  
            ,p.LastChgUserName  
        FROM mdm.viw_SYSTEM_SECURITY_ROLE_ACCESSCONTROL_FUNCTIONAL p  
        WHERE   (@PrincipalType_ID IS NULL OR p.PrincipalType_ID = @PrincipalType_ID)   
            AND (@Principal_MUID IS NULL   OR p.Principal_MUID = @Principal_MUID)   
            AND (@Principal_ID IS NULL     OR p.Principal_ID = @Principal_ID)   
            AND (@Principal_Name IS NULL   OR UPPER(p.Principal_Name) = @Principal_Name)   
    END  
  
              
    SET NOCOUNT OFF;  
END; --proc
go

