/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
--TEST SCRIPT  
    EXEC mdm.udpSystemSettingSave 1,'CopyOnlyCommittedVersion', '0'  --don't require committed versions to copy  
    DECLARE @P1 int, @P2 UNIQUEIDENTIFIER;  
    DECLARE @x NVARCHAR(50) = NEWID();  
  
  
    --Recursively copy versions N times. If you want to copy the same version  
    -- each time just replace the second @v OUTPUT param below with null.  
    DECLARE @v INT = 23;  
    DECLARE @i INT = 0;  
    WHILE (@i < 1) BEGIN  
        SELECT @x = NEWID();  
        EXEC mdm.udpVersionCopy 1, @v, @x, @x, @v OUTPUT,null,1;  
        PRINT @v;  
        SET @i += 1;  
    END; --while  
  
    SELECT * FROM mdm.tblModelVersion  
  
    EXEC mdm.udpSystemSettingSave 1,'CopyOnlyCommittedVersion', '1'  --reset required committed versions to copy  
*/  
CREATE PROCEDURE mdm.udpVersionCopy  
(  
    @User_ID            INT,  
    @Version_ID         INT,  
    @VersionName        NVARCHAR(50),  
    @VersionDescription NVARCHAR(250),  
    @Return_ID          INT = NULL OUTPUT,  
    @Return_MUID        UNIQUEIDENTIFIER = NULL OUTPUT,  
    @Debug              BIT = 0,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE @Model_ID                   INT,  
            @NewVersion_ID              INT,  
            @NewVersion_MUID            UNIQUEIDENTIFIER,  
            @Entity_ID                  INT,  
            @MemberType_ID              INT,  
            @TableName                  SYSNAME,  
            @TableNameEN                SYSNAME,  
            @TableNameHP                SYSNAME,  
            @TableNameCN                SYSNAME,  
            @SQL                        NVARCHAR(MAX),  
            @From                       NVARCHAR(MAX),  
            @Insert                     NVARCHAR(MAX),  
            @StartTime                  DATETIME2(7),  
  
            @MemberType_Leaf                TINYINT = 1,  
            @MemberType_Consolidated        TINYINT = 2,  
            @MemberType_Collection          TINYINT = 3,  
            @MemberType_Hierarchy           TINYINT = 4,  
            @MemberType_CollectionMember    TINYINT = 5,  
  
            -- This pseudo-constant is for use in string concatenation operations to prevent string truncation. When concatenating two or more strings,  
            -- if none of the strings is an NVARCHAR(MAX) or an NVARCHAR constant that is longer than 4,000 characters, then the resulting string   
            -- will be silently truncated to 4,000 characters. Concatenating with this empty NVARCHAR(MAX), is sufficient to prevent truncation.  
            -- See http://connect.microsoft.com/SQLServer/feedback/details/283368/nvarchar-max-concatenation-yields-silent-truncation.  
            @TruncationGuard        NVARCHAR(MAX) = N'',  
  
            @CopyNbr                    INT,  
            @CopyOnlyCommittedVersion   NVARCHAR(250),  
            @SourceVersionStatusID      TINYINT,  
            @SourceVersionName          NVARCHAR(50),  
            @SourceVersionDesc          NVARCHAR(500),  
            @UpdateDbaValuesScript      NVARCHAR(MAX);  
  
    SELECT  
        @SourceVersionStatusID = Status_ID,  
        @SourceVersionName = [Name],  
        @SourceVersionDesc = [Description]  
    FROM mdm.tblModelVersion  
    WHERE ID = @Version_ID;  
  
    --If CopyOnlyCommittedVersion is turned on then verify that the version is committed.  
    EXEC mdm.udpSystemSettingGet N'CopyOnlyCommittedVersion', @CopyOnlyCommittedVersion OUTPUT;  
    IF CONVERT(INT, @CopyOnlyCommittedVersion) = 1 AND @SourceVersionStatusID <> 3   
    BEGIN  
        --On error, return NULL results  
        SELECT @Return_ID = NULL, @Return_MUID = NULL;  
        RAISERROR('MDSERR200062|The version cannot be copied. Only committed versions can be copied.', 16, 1);  
        RETURN;  
    END; --if  
  
    IF NULLIF(@VersionName, N'') IS NULL   
    BEGIN  
        SELECT @CopyNbr = ISNULL(Count(AsOfVersion_ID), 0) + 1 FROM mdm.tblModelVersion WHERE AsOfVersion_ID = @Version_ID;  
        SET @VersionName = CONCAT(N'Copy (', @CopyNbr, N') of ',  @SourceVersionName);  
    END; --if  
  
    SET @VersionDescription = ISNULL(NULLIF(@VersionDescription, N''), @SourceVersionDesc);  
  
    --Start transaction, being careful to check if we are nested  
    DECLARE @TranCounter INT;  
    SET @TranCounter = @@TRANCOUNT;  
    IF @TranCounter > 0 SAVE TRANSACTION TX;  
    ELSE BEGIN TRANSACTION;  
  
    BEGIN TRY  
  
        SELECT @Model_ID = Model_ID FROM mdm.tblModelVersion WHERE ID = @Version_ID;  
  
        --Create new version record and get new Version_ID  
        --Make the new version private  
        EXEC mdm.udpVersionSave   
            @User_ID = @User_ID,   
            @Model_ID = @Model_ID,  
            @Version_ID = NULL,  
            @CurrentVersion_ID = @Version_ID,   
            @Status_ID = 1/*Open*/,   
            @Name = @VersionName,   
            @Description = @VersionDescription,   
            @Return_ID = @NewVersion_ID OUTPUT,   
            @Return_MUID = @NewVersion_MUID OUTPUT;  
  
        --Initialize the return parameters  
        SELECT @Return_ID = @NewVersion_ID, @Return_MUID = @NewVersion_MUID;  
  
        --Temporary table to hold all the entity table names  
        DECLARE @EntityTable TABLE  
        (  
            Entity_ID INT,   
            MemberType_ID INT,   
            TableName SYSNAME,   
            [Level] INT,  
            EntityTable SYSNAME,  
            HierarchyParentTable SYSNAME NULL,  
            CollectionTable SYSNAME NULL  
        );  
  
        --Need to copy data in the right order so as to not violate FKs  
        INSERT INTO @EntityTable  
        SELECT edt.Entity_ID, edt.MemberType_ID, edt.TableName, edt.[Level], e.EntityTable, e.HierarchyParentTable, e.CollectionTable  
        FROM mdm.udfEntityDependencyTree(@Model_ID) edt  
        INNER JOIN mdm.tblEntity e  
        ON edt.Entity_ID = e.ID;  
  
        --Loop through the member tables  
        WHILE EXISTS(SELECT 1 FROM @EntityTable)   
        BEGIN  
  
            SET @SQL = N'';  
  
            SELECT TOP 1  
                @Entity_ID = Entity_ID,  
                @MemberType_ID = MemberType_ID,  
                @TableName = TableName,  
                @TableNameEN = EntityTable,             --EN (1)  
                @TableNameHP = HierarchyParentTable,    --HP (2)  
                @TableNameCN = CollectionTable          --CN (3)  
            FROM @EntityTable  
            ORDER BY [Level] ASC; --Copy tables in correct dependency order  
  
            --Mapping foreign keys seems faster via (stage + UPDATE + INSERT) than (JOIN + direct INSERT)  
            --This is likely due to the large number of constraints (especially FKs) in the member tables  
            --Note that SELECT INTO also uses the source collations in the destination temporary table  
            IF @MemberType_ID IN (@MemberType_Leaf, @MemberType_Consolidated, @MemberType_Collection)   
            BEGIN --EN, HP, CN  
                SELECT @Insert = N'', @From = N'';  
  
                --Get the list of Attributes in the current Entity  
                SELECT  
                     @Insert = CONCAT(@TruncationGuard, @Insert, CASE WHEN a.DomainEntity_ID IS NULL THEN CONCAT(CASE WHEN @Insert = N'' THEN N' ' ELSE N',' END, QUOTENAME(a.TableColumn), N' -- ', a.Name, N'  
    ') END)  
  
                    ,@From =   CONCAT(@TruncationGuard, @From,   CASE WHEN a.DomainEntity_ID IS NULL THEN CONCAT(CASE WHEN @From = N''   THEN N' ' ELSE N'  
    ,' END,       
                        CASE a.TableColumn  
                            WHEN N'ValidationStatus_ID' THEN N'CASE WHEN ValidationStatus_ID = 2 THEN 4 ELSE ValidationStatus_ID END AS '  
                            WHEN N'AsOf_ID' THEN N'ID AS ' --Copy old ID value into AsOf_ID column  
                            WHEN N'Version_ID' THEN N'@NewVersion_ID AS ' --Hard-code new version  
                            WHEN N'LastChgUserID' THEN N'@User_ID AS ' --Hard code user  
                            WHEN N'LastChgVersionID' THEN N'@NewVersion_ID AS ' --Hard code new version  
                            ELSE N'' --Use old value for all other columns  
                        END,  
                        QUOTENAME(a.TableColumn), N' -- ', a.Name) END)  
  
                    ,@UpdateDbaValuesScript = CONCAT(@TruncationGuard, @UpdateDbaValuesScript, CASE WHEN a.DomainEntity_ID IS NOT NULL THEN CONCAT(CASE WHEN @Debug = 1 THEN CONCAT(N'  
SET @StartTime = SYSDATETIME();  
PRINT CONCAT(@StartTime, N'': Copy DBA ', QUOTENAME(a.Name), N' Start'');') END, N'  
UPDATE new   
SET ', QUOTENAME(a.TableColumn), N' = dba.ID -- ', a.Name, N'  
FROM mdm.', QUOTENAME(@TableName), N' AS old  
INNER JOIN mdm.', QUOTENAME(@TableName), N' AS new   
ON      old.Version_ID = @Version_ID   
    AND old.ID = new.AsOf_ID  
INNER JOIN mdm.', QUOTENAME(d.EntityTable), N' AS dba   
ON      new.Version_ID = dba.Version_ID   
    AND old.', QUOTENAME(a.TableColumn), N' = dba.AsOf_ID  
WHERE   new.Version_ID = @NewVersion_ID   
    AND old.', QUOTENAME(a.TableColumn), N' IS NOT NULL   
    AND new.Status_ID = 1  
OPTION(OPTIMIZE FOR (@Version_ID UNKNOWN, @NewVersion_ID UNKNOWN)); -- Avoid parameter sniffing  
', CASE WHEN @Debug = 1 THEN CONCAT(N'PRINT CONCAT(SYSDATETIME(), N'': Copy DBA ', QUOTENAME(a.Name), N' end in '', DATEDIFF(MS, @StartTime, SYSDATETIME()), N'' ms'');  
') END) END)  
                FROM mdm.tblAttribute AS a  
                LEFT JOIN mdm.tblEntity AS d   
                ON a.DomainEntity_ID = d.ID  
                WHERE   a.Entity_ID = @Entity_ID   
                    AND a.MemberType_ID = @MemberType_ID  
                    --Cannot insert into system and/or computed columns  
                    AND (a.IsSystem = 0 OR a.TableColumn NOT IN (N'ID', N'Status_ID', N'EnterDTM', N'LastChgDTM', N'LastChgTS', N'MUID'));  
  
                SET @SQL = CONCAT(@TruncationGuard, N'  
--Copy mapped data into destination  
INSERT INTO mdm.', QUOTENAME(@TableName), N'  
(  
    ', @Insert, N'  
)  
SELECT  
    ', @From, N'  
FROM mdm.', QUOTENAME(@TableName), N'  
WHERE   Version_ID = @Version_ID  
    AND Status_ID = 1  
;');  
  
            --Since the HR table is much simpler, a direct insert still has good performance  
            END ELSE IF @MemberType_ID = @MemberType_Hierarchy   
            BEGIN --HR  
                SET @SQL = CONCAT(@TruncationGuard, CASE WHEN @Debug = 1 THEN N'  
PRINT CONCAT(SYSDATETIME(), '': Start copy HR table '')  
DECLARE @StartTime DATETIME2(7) = SYSDATETIME();  
' END, N'  
INSERT INTO mdm.', QUOTENAME(@TableName), N'  
(  
     Version_ID  
    ,Hierarchy_ID  
    ,Parent_HP_ID  
    ,ChildType_ID  
    ,Child_EN_ID  
    ,Child_HP_ID  
    ,SortOrder  
    ,LevelNumber  
    ,EnterUserID  
    ,EnterVersionID  
    ,LastChgUserID  
    ,LastChgVersionID  
    ,AsOf_ID  
)  
SELECT   
     @NewVersion_ID AS Version_ID  
    ,hr.Hierarchy_ID  
    ,hp.ID AS Parent_HP_ID  
    ,hr.ChildType_ID  
    ,leafChild.ID AS Child_EN_ID  
    ,conChild.ID AS Child_HP_ID  
    ,hr.SortOrder  
    ,hr.LevelNumber  
    ,hr.EnterUserID  
    ,hr.EnterVersionID  
    ,@User_ID AS LastChgUserID  
    ,@NewVersion_ID AS LastChgVersionID  
    ,hr.ID AS AsOf_ID  
FROM mdm.', QUOTENAME(@TableName), N' AS hr  
LEFT JOIN mdm.', QUOTENAME(@TableNameHP), N' AS hp -- new parents  
ON      hp.Version_ID = @NewVersion_ID  
    AND hr.Parent_HP_ID = hp.AsOf_ID  
LEFT JOIN mdm.', QUOTENAME(@TableNameHP), N' conChild -- new consolidated children  
ON      conChild.Version_ID = @NewVersion_ID  
    AND hr.Child_HP_ID = conChild.AsOf_ID  
LEFT JOIN mdm.', QUOTENAME(@TableNameEN), N' leafChild -- new leaf children  
ON      leafChild.Version_ID = @NewVersion_ID  
    AND hr.Child_EN_ID = leafChild.AsOf_ID  
WHERE   hr.Version_ID = @Version_ID  
    AND hr.Status_ID = 1;', CASE WHEN @Debug = 1 THEN N'  
  
PRINT CONCAT(SYSDATETIME(), '': Initial copy to HR table end in '', DATEDIFF(MS, @StartTime, SYSDATETIME()), '' ms'')  
SET @StartTime = SYSDATETIME();' END, N'  
  
--seed HR table with leaf entities on the root for hierarchies that did not exist in the original version  
WITH h AS  
(  
    SELECT h.ID   
    FROM mdm.tblHierarchy AS h  
    LEFT JOIN mdm.', QUOTENAME(@TableName), ' AS hr   
    ON      h.ID = hr.Hierarchy_ID  
        AND hr.Version_ID = @NewVersion_ID  
    WHERE   hr.ID IS NULL  
        AND h.Entity_ID = @Entity_ID  
        AND h.IsMandatory = 1  
)  
INSERT INTO mdm.', QUOTENAME(@TableName), N'  
(  
     Version_ID  
    ,Hierarchy_ID  
    ,Parent_HP_ID  
    ,ChildType_ID  
    ,Child_EN_ID  
    ,Child_HP_ID  
    ,SortOrder  
    ,LevelNumber  
    ,EnterUserID  
    ,EnterVersionID  
    ,LastChgUserID  
    ,LastChgVersionID  
    ,AsOf_ID  
)  
SELECT  
     @NewVersion_ID AS Version_ID  
    ,h.ID  
    ,NULL  
    ,1  
    ,e.ID  
    ,NULL  
    ,e.ID  
    ,-1  
    ,e.EnterUserID  
    ,e.EnterVersionID  
    ,e.LastChgUserID  
    ,e.LastChgVersionID  
    ,NULL  
FROM mdm.', QUOTENAME(@TableNameEN), N' AS e   
CROSS JOIN h  
WHERE e.Version_ID = @NewVersion_ID', CASE WHEN @Debug = 1 THEN N'  
  
PRINT CONCAT(SYSDATETIME(), '': Create ROOT rows for mandatory hierarchies end in '', DATEDIFF(MS, @StartTime, SYSDATETIME()), '' ms'')  
' END);  
  
            --Since the CM table is much simpler, a direct insert still has good performance  
            END ELSE IF @MemberType_ID = @MemberType_CollectionMember   
            BEGIN --CM  
  
                SET @SQL = CONCAT(@TruncationGuard, N'  
WITH cte AS  
(  
    SELECT  
         @NewVersion_ID AS Version_ID  
        ,pr.ID AS Parent_CN_ID  
        ,cm.ChildType_ID  
        ,en.ID AS Child_EN_ID', CASE WHEN @TableNameHP IS NOT NULL THEN N'  
        ,hp.ID AS Child_HP_ID' END, N'   
        ,cn.ID AS Child_CN_ID  
        ,cm.SortOrder  
        ,cm.Weight  
        ,cm.EnterUserID  
        ,cm.EnterVersionID  
        ,@User_ID AS LastChgUserID  
        ,@NewVersion_ID AS LastChgVersionID  
        ,cm.ID AS AsOf_ID  
    FROM mdm.', QUOTENAME(@TableName), N' AS cm  
    INNER JOIN mdm.', QUOTENAME(@TableNameCN), N' AS pr  
    ON      pr.Version_ID = @NewVersion_ID  
        AND cm.Parent_CN_ID = pr.AsOf_ID  
        AND pr.Status_ID = 1  
    LEFT JOIN mdm.', QUOTENAME(@TableNameEN), N' AS en  
    ON      en.Version_ID = pr.Version_ID  
        AND cm.ChildType_ID = 1  
        AND cm.Child_EN_ID = en.AsOf_ID  
        AND en.Status_ID = 1', CASE WHEN @TableNameHP IS NOT NULL THEN CONCAT(N'  
    LEFT JOIN mdm.', QUOTENAME(@TableNameHP), N' AS hp  
    ON      hp.Version_ID = pr.Version_ID  
        AND cm.ChildType_ID = 2  
        AND cm.Child_HP_ID = hp.AsOf_ID  
        AND hp.Status_ID = 1') END, N'  
    LEFT JOIN mdm.', QUOTENAME(@TableNameCN), N' AS cn  
    ON      cn.Version_ID = pr.Version_ID  
        AND cm.ChildType_ID = 3  
        AND cm.Child_CN_ID = cn.AsOf_ID  
        AND cn.Status_ID = 1  
    WHERE   cm.Version_ID = @Version_ID  
        AND cm.Status_ID = 1  
)  
INSERT INTO mdm.', QUOTENAME(@TableName), N'  
(  
     Version_ID  
    ,Parent_CN_ID  
    ,ChildType_ID  
    ,Child_EN_ID', CASE WHEN @TableNameHP IS NOT NULL THEN N'  
    ,Child_HP_ID' END, N'  
    ,Child_CN_ID  
    ,SortOrder  
    ,Weight  
    ,EnterUserID  
    ,EnterVersionID  
    ,LastChgUserID  
    ,LastChgVersionID  
    ,AsOf_ID  
)  
SELECT * FROM cte  
WHERE --FKs may be NULL if original row was soft-deleted  
        Parent_CN_ID IS NOT NULL  
    AND ISNULL(Child_EN_ID, ', CASE WHEN @TableNameHP IS NOT NULL THEN N'ISNULL(Child_HP_ID, Child_CN_ID)' ELSE N'Child_CN_ID' END, N') IS NOT NULL  
;');  
  
            END; --if  
            IF @Debug = 1   
            BEGIN  
                SET @StartTime = SYSDATETIME();  
                PRINT CONCAT(@StartTime, N': ', @TableName, N' start ');  
                --PRINT @SQL;  
            END --if debug  
  
            EXEC sp_executesql @SQL,  
                N'@User_ID INT, @Version_ID INT, @NewVersion_ID INT, @Entity_ID INT',  
                @User_ID, @Version_ID, @NewVersion_ID, @Entity_ID;  
  
            IF @Debug = 1   
            BEGIN  
                PRINT CONCAT(SYSDATETIME(), N': ', @TableName, N' end in ', DATEDIFF(MS, @StartTime, SYSDATETIME()), N' ms');  
            END --if debug  
  
  
            DELETE FROM @EntityTable WHERE Entity_ID = @Entity_ID AND MemberType_ID = @MemberType_ID;  
  
        END; --while  
  
        --Finally, map all the DBAs only after all new PK values are populated  
        --We need to do this at the very end to cater for recursive derived hierarchies (self-referencing DBAs)  
        IF NULLIF(@UpdateDbaValuesScript, N'') IS NOT NULL  
        BEGIN  
            If @Debug = 1   
            BEGIN  
                SET @UpdateDbaValuesScript = N'DECLARE @StartTime DATETIME2(7);  
'  
                    + @UpdateDbaValuesScript;  
                --PRINT @UpdateDbaValuesScript;  
            END  
  
            EXEC sp_executesql @UpdateDbaValuesScript,  
                N'@User_ID INT, @Version_ID INT, @NewVersion_ID INT, @Entity_ID INT',  
                @User_ID, @Version_ID, @NewVersion_ID, @Entity_ID;  
  
        END  
  
        --Copy the security records across  
        EXEC mdm.udpSecurityRoleAccessMemberCopy @User_ID = @User_ID, @SourceVersion_ID = @Version_ID, @TargetVersion_ID = @NewVersion_ID, @MapMembersByID = 1;  
  
        --(Re)build the member security (MS) records for the new versions via the queue  
        EXEC mdm.udpSecurityMemberProcessRebuildModelVersion @Version_ID = @NewVersion_ID, @ProcessNow = 1;  
  
  
        -- Copy sync relationships for which the copied version is a target. The copied sync relationship will instead target the new version.  
        -- Any failure in the sync process should not cause version copy to fail, but instead sync errors should be logged in the sync table.  
        DECLARE @TargetEntity TABLE  
        (  
             TargetEntity_ID    INT PRIMARY KEY  
            ,TargetEntity_MUID  UNIQUEIDENTIFIER  
            ,TargetModel_MUID   UNIQUEIDENTIFIER  
            ,User_ID            INT  
        );  
        INSERT INTO tblSyncRelationship  
        (  
             SourceVersion_ID  
            ,SourceEntity_ID  
            ,TargetVersion_ID  
            ,TargetEntity_ID  
            ,TargetEntityNameIsAliased  
            ,RefreshFrequencyInHours  
            ,EnterUserID  
            ,LastChgUserID  
        )  
        OUTPUT inserted.TargetEntity_ID, inserted.LastChgUserID INTO @TargetEntity(TargetEntity_ID, User_ID)  
        SELECT  
             sr.SourceVersion_ID  
            ,sr.SourceEntity_ID  
            ,@NewVersion_ID  
            ,sr.TargetEntity_ID  
            ,sr.TargetEntityNameIsAliased  
            ,sr.RefreshFrequencyInHours  
            ,sr.EnterUserID  
            ,sr.LastChgUserID  
        FROM mdm.tblSyncRelationship sr  
        WHERE sr.TargetVersion_ID = @Version_ID;  
  
        -- Get MUIDs  
        UPDATE tgt  
        SET  
             TargetEntity_MUID =  e.MUID  
            ,TargetModel_MUID = m.MUID  
        FROM @TargetEntity tgt  
        INNER JOIN mdm.tblEntity e  
        ON tgt.TargetEntity_ID = e.ID  
        INNER JOIN mdm.tblModel m  
        ON e.Model_ID = m.ID  
  
        DECLARE   
             @TargetEntity_ID   INT = 0  
            ,@TargetEntity_MUID UNIQUEIDENTIFIER  
            ,@TargetModel_MUID  UNIQUEIDENTIFIER  
            ,@SyncUser_ID       INT;  
        WHILE EXISTS(SELECT 1 FROM @TargetEntity WHERE TargetEntity_ID > @TargetEntity_ID)  
        BEGIN  
            SELECT TOP 1   
                 @TargetEntity_ID   = TargetEntity_ID   
                ,@TargetEntity_MUID = TargetEntity_MUID  
                ,@TargetModel_MUID  = TargetModel_MUID  
                ,@SyncUser_ID       = User_ID  
            FROM @TargetEntity   
            WHERE TargetEntity_ID > @TargetEntity_ID  
            ORDER BY TargetEntity_ID;  
  
            BEGIN TRY  
                EXEC mdm.udpSyncRefresh   
                     @User_ID = @SyncUser_ID  
                    ,@TargetModel_MUID = @TargetModel_MUID  
                    ,@TargetVersion_MUID = @NewVersion_MUID  
                    ,@TargetEntity_MUID = @TargetEntity_MUID  
            END TRY  
            BEGIN CATCH  
                -- Add the error message to the sync table  
                DECLARE @ErrorMsg NVARCHAR(4000)  
                EXEC mdm.udpGetErrorInfo @ErrorMessage = @ErrorMsg OUTPUT  
  
                DECLARE @SyncStatus_Failed TINYINT = 3;  
                UPDATE mdm.tblSyncRelationship  
                SET  
                     LastSyncAttemptDTM         = GETUTCDATE()  
                    ,LastSyncAttemptStatus      = @SyncStatus_Failed  
                    ,LastSyncAttemptErrorInfo   = @ErrorMsg  
                WHERE   TargetVersion_ID = @NewVersion_ID  
                    AND TargetEntity_ID = @TargetEntity_ID  
            END CATCH  
        END  
  
        --Commit only if we are not nested  
        IF @TranCounter = 0 COMMIT TRANSACTION;  
        RETURN(0);  
  
    END TRY  
    --Compensate as necessary  
    BEGIN CATCH  
  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        IF @TranCounter = 0 ROLLBACK TRANSACTION;  
        ELSE IF XACT_STATE() <> -1 ROLLBACK TRANSACTION TX;  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
  
        --On error, return NULL results  
        --SELECT @Return_ID = NULL;  
        RETURN(1);  
  
    END CATCH;  
  
    SET NOCOUNT OFF;  
END; --proc
go

