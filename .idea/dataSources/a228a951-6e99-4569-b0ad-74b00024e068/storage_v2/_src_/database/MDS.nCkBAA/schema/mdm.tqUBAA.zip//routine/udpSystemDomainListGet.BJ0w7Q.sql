/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
    EXEC mdm.udpSystemDomainListGet NULL, NULL, NULL  
    EXEC mdm.udpSystemDomainListGet 'lstBRItemTypeSubCategory'  
    EXEC mdm.udpSystemDomainListGet 'lstInputMask', null  
    EXEC mdm.udpSystemDomainListGet 'lstInputMask', 1  
    EXEC mdm.udpSystemDomainListGet '',null  
  
   SELECT * FROM mdm.tblList  
*/  
CREATE PROCEDURE mdm.udpSystemDomainListGet   
(  
    @ListCode       NVARCHAR(50) = NULL,  
    @ListGroup_ID   INT = NULL,  
    @ListOption     NVARCHAR(250) = NULL,  
    @ListItem       mdm.MemberCodes READONLY,  
    @CorrelationID  UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
  
    SET NOCOUNT ON  
  
    SELECT   
         @ListCode = NULLIF(@ListCode, N'')  
        ,@ListOption = NULLIF(@ListOption, N'')  
  
    -- If the temp table is already defined, then the caller has specified in a temp table which items to return (and @ListCode will be ignored)  
    -- Otherwise, create the table and use @ListCode to populate it.  
  
    DECLARE @ListItem2 TABLE   
    (  
        Code   NVARCHAR(50) COLLATE DATABASE_DEFAULT PRIMARY KEY  
        ,Name   NVARCHAR(50) COLLATE DATABASE_DEFAULT  
    )  
  
    IF NOT EXISTS (SELECT 1 FROM @ListItem)  
    BEGIN  
        INSERT INTO @ListItem2  
        SELECT DISTINCT  
             ListCode AS Code  
            ,ListName AS Name  
        FROM mdm.tblList  
        WHERE ListCode = ISNULL(@ListCode, ListCode)  
    END  
    ELSE  
    BEGIN  
        INSERT INTO @ListItem2  
        SELECT DISTINCT  
             CONVERT(NVARCHAR(50), MemberCode) AS Code  
            ,CONVERT(NVARCHAR(50),MemberName) AS Name  
        FROM @ListItem  
    END  
  
    -- Return Code and Name  
    SELECT  
         Code  
        ,Name  
    FROM @ListItem2  
  
    -- Return item values  
    SELECT  
         sl.Code -- maps to the parent row of the previous result set  
        ,l.Group_ID     AS ListGroup  
        ,l.ListOption   AS Name  
        ,l.OptionID     AS Value  
    FROM @ListItem2 sl  
    INNER JOIN mdm.tblList l  
    ON sl.Code = l.ListCode  
    WHERE   l.Group_ID = ISNULL(@ListGroup_ID, l.Group_ID)  
        AND l.ListOption = ISNULL(@ListOption, l.ListOption)  
        AND IsVisible = 1  
    ORDER BY sl.Code, l.Seq  
  
    SET NOCOUNT OFF  
END --proc
go

