/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    EXEC mdm.udpCreateDerivedHierarchyViews 3;  
    EXEC mdm.udpCreateDerivedHierarchyViews 4;  
    EXEC mdm.udpCreateDerivedHierarchyViews 5;  
    SELECT * FROM mdm.tblModel;  
*/  
CREATE PROCEDURE mdm.udpCreateDerivedHierarchyViews  
(  
    @Model_ID       INT,  
    @CorrelationID  UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON;  
  
    --Defer view generation if we are in the middle of an upgrade or demo-rebuild  
    IF APPLOCK_MODE(N'public', N'DeferViewGeneration', N'Session') = N'NoLock' BEGIN  
  
        DECLARE @TempID INT;  
        DECLARE @TempTable TABLE (RowNumber INT IDENTITY (1, 1) PRIMARY KEY CLUSTERED NOT NULL, ID INT NOT NULL);  
  
        INSERT INTO @TempTable(ID)  
        SELECT ID FROM mdm.tblDerivedHierarchy WHERE Model_ID = @Model_ID;  
  
        DECLARE @Counter INT = 1;  
        DECLARE @MaxCounter INT = (SELECT MAX(RowNumber) FROM @TempTable);  
  
        WHILE @Counter <= @MaxCounter  
        BEGIN  
            SELECT @TempID = ID FROM @TempTable WHERE [RowNumber] = @Counter;  
            EXEC mdm.udpCreateSystemDerivedHierarchyParentChildView @TempID;  
            SET @Counter += 1;  
        END; --while  
  
    END; --if  
  
    SET NOCOUNT OFF;  
END; --proc
go

