/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    DECLARE @Attribute_ID INT;  
    SET @Attribute_ID = 891;  
    EXEC mdm.udpAttributeDelete @Attribute_ID, 1;  
    SELECT * FROM mdm.tblAttribute WHERE ID = @Attribute_ID;  
  
MDM Errors that this proc may throw:  
100022 - when an attempt is made to delete a system attribute.  
*/  
CREATE PROCEDURE mdm.udpAttributeDelete  
(  
    @Attribute_ID       INTEGER,  
    @CreateViewsInd     BIT = NULL, --1=Create, 0=DoNot Create  
    @IsSync             BIT = 0,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    DECLARE @IsValidParam       INT = 1,  
            @SQL                NVARCHAR(MAX) = N'',  
  
            @MemberType_Leaf            TINYINT = 1,  
            @MemberType_Consolidated    TINYINT = 2,  
  
            @AttributeType_Freeform    TINYINT = 1,  
            @AttributeType_Domain      TINYINT = 2,  
            @AttributeType_System      TINYINT = 3,  
            @AttributeType_File        TINYINT = 4,  
  
            @TableName          SYSNAME,  
            @TransactionTableName       SYSNAME,  
            @AttributeName      NVARCHAR(250),  
            @TableColumn        SYSNAME,  
            @ForeignTableName   SYSNAME,  
            @Model_ID           INT,  
            @Entity_ID          INT,  
            @MemberType_ID      TINYINT,  
            @AttributeType_ID   INT,  
            @DomainEntity_ID    INT,  
            @IsSystem           BIT,  
            @AttributeMUID      UNIQUEIDENTIFIER,  
            @idx                SYSNAME,  
            @UniqueIndexPrefix  SYSNAME,  
            @NonUniqueIndexPrefix  SYSNAME,  
            @uniqueidx          SYSNAME,  
            @nonuniqueidx       SYSNAME,  
            @fk                 SYSNAME,  
            @StagingBase        NVARCHAR(60),  
            @StagingTableName   SYSNAME,  
            @TranCommitted      INT = 0; -- 0: Not committed, 1: Committed.  
  
    --Start transaction, being careful to check if we are nested  
    DECLARE @TranCounter INT;  
    SET @TranCounter = @@TRANCOUNT;  
    IF @TranCounter > 0 SAVE TRANSACTION TX;  
    ELSE BEGIN TRANSACTION;  
  
    BEGIN TRY  
  
        SET @CreateViewsInd = ISNULL(@CreateViewsInd, 1);  
  
        SELECT  
            @Model_ID = e.Model_ID,  
            @Entity_ID = e.ID,  
            @MemberType_ID = a.MemberType_ID,  
            @AttributeName = a.[Name],  
            @DomainEntity_ID = a.DomainEntity_ID,  
            @TableColumn = a.TableColumn,  
            @AttributeType_ID = a.AttributeType_ID,  
            @AttributeMUID = a.MUID,  
            @IsSystem = a.IsSystem  
        FROM mdm.tblEntity AS e  
        INNER JOIN mdm.tblAttribute AS a ON (e.ID = a.Entity_ID)  
        WHERE a.ID = @Attribute_ID;  
  
        IF @IsSystem = 1  
        BEGIN  
            RAISERROR('MDSERR100022|A system attribute cannot be deleted.', 16, 1);  
            RETURN;  
         END; --if  
  
        -- Verify the entity is not a sync target.  
        IF @IsSync = 0  
        BEGIN  
            IF EXISTS(SELECT 1 FROM mdm.tblSyncRelationship WHERE TargetEntity_ID = @Entity_ID)-- This query is in a nested IF statement, rather than in the parent IF statement, for efficiency because SQL does not guarantee Boolean short circuiting.  
            BEGIN  
                RAISERROR('MDSERR200216|The attribute cannot be deleted. The entity is the target of a sync relationship.', 16, 1);  
                RETURN;  
            END  
        END  
  
        --Get the Table Name.  
        SET @TableName = mdm.udfTableNameGetByID(@Entity_ID, @MemberType_ID);  
        SET @TransactionTableName = mdm.udfGetTransactionTableName(@Model_ID);  
  
        --Delete the transaction table. The transaction annotation table will be cascade deleted.  
        SET @SQL = CONCAT(N'  
            DELETE [mdm].', QUOTENAME(@TransactionTableName), N'  
            WHERE Attribute_ID = @Attribute_ID;');  
        EXEC sp_executesql @SQL, N'@Attribute_ID INT', @Attribute_ID;  
  
        --Get the Staging Table Name and Staging Base.  
        SELECT  
             @StagingTableName = CASE a.MemberType_ID  
                WHEN @MemberType_Leaf           THEN e.StagingLeafName  
                WHEN @MemberType_Consolidated   THEN e.StagingConsolidatedName  
                END  
            ,@StagingBase = e.StagingBase  
        FROM mdm.tblAttribute a  
        INNER JOIN mdm.tblEntity e  
        ON a.Entity_ID = e.ID  
        WHERE a.ID = @Attribute_ID  
  
        DECLARE @table_ID INT = OBJECT_ID(N'[mdm].' + QUOTENAME(@TableName));  
        IF EXISTS(SELECT 1 FROM sys.columns WHERE object_id = @table_ID AND [name] = @TableColumn)  
        BEGIN  
  
  
           -- Verify the attribute is not included in the composite keys indexing.IF there are only single indexing the attribute is good to be deleted after dropping the indexes.  
            SET @UniqueIndexPrefix = CONCAT(N'uixud_', @TableName, N'_Version_ID_');  
            SET @NonUniqueIndexPrefix = CONCAT(N'ixud_', @TableName, N'_Version_ID_');  
            DECLARE @cnt INT = 0;  
            SELECT @cnt = Count (*) FROM sys.indexes  WHERE object_id = @table_ID AND (name like @UniqueIndexPrefix + '%' + CAST(@Attribute_ID AS VARCHAR)  + '%') OR (name like @NonUniqueIndexPrefix + '%' + CAST(@Attribute_ID AS VARCHAR) + '%')  
            --IF there are more than 2 indexes on an attribute, it means that the attribute is included in at least  
            -- one composite type indexing and can not be deleted, if it's less or equal to 2, we need to check if these are single indexing or not.  
            IF @cnt IS NOT NULL AND ( @cnt > 0 AND @cnt <= 2)  
            BEGIN  
                DECLARE @UniqueExists BIT = 0;  
                DECLARE @NonUniqueExists BIT = 0;  
                --Check for unique single key user defined indexing  
                SET @uniqueidx = CONCAT(@UniqueIndexPrefix, @Attribute_ID);  
                DECLARE @uidx_ID INT;  
                --Drop index  
                IF @uniqueidx IS NOT NULL AND EXISTS(SELECT 1 FROM sys.indexes  WHERE object_id = @table_ID AND name = @uniqueidx) BEGIN  
                    SET @cnt = @cnt - 1;  
                    SET @UniqueExists = 1;  
  
                END; --if  
                --Check for non-unique single key user defined indexing  
                SET @nonuniqueidx = CONCAT(@NonUniqueIndexPrefix, @Attribute_ID);  
                --Drop index  
                IF @nonuniqueidx IS NOT NULL AND EXISTS(SELECT 1 FROM sys.indexes WHERE object_id = @table_ID AND name = @nonuniqueidx) BEGIN  
                    SET @cnt = @cnt - 1;  
                    SET @NonUniqueExists = 1;  
  
                END; --if  
                IF @cnt = 0 BEGIN  
                    IF @UniqueExists = 1 BEGIN  
                        SET @SQL = CONCAT( N'  
                        DROP INDEX ' , QUOTENAME(@uniqueidx) , N' ON mdm.' , QUOTENAME(@TableName) , N';');  
                        DELETE FROM mdm.tblIndex WHERE SysIndex_ID = (SELECT index_id from  sys.indexes  WHERE object_id = @table_ID AND name = @uniqueidx);  
                        EXEC sp_executesql @SQL;  
                    END  
                    IF @NonUniqueExists = 1 BEGIN  
                        SET @SQL = CONCAT( N'  
                        DROP INDEX ' , QUOTENAME(@nonuniqueidx) , N' ON mdm.' , QUOTENAME(@TableName) , N';');  
                        DELETE FROM mdm.tblIndex WHERE SysIndex_ID = (SELECT index_id from  sys.indexes  WHERE object_id = @table_ID AND name = @nonuniqueidx);  
                        EXEC sp_executesql @SQL;  
                    END  
                END  
            END  
             --when we're here all single indexing are excluded from the @cnt and if it's not zero means there are some composite indexing on the attribute  
            IF @cnt IS NOT NULL AND @cnt <> 0  
            BEGIN  
                RAISERROR('MDSERR200301|The attribute cannot be deleted because it is included in at least one composite index.', 16, 1);  
                RETURN;  
            END  
  
            SET @SQL = N'';  
            --Check for an attribute type of DBA  
            IF (@AttributeType_ID = @AttributeType_Domain)  
            BEGIN  
  
                --Get The Table Name of the table this attribute is a domain-based list for  
                SET @ForeignTableName = mdm.udfTableNameGetByID(@DomainEntity_ID, @MemberType_Leaf);  
  
                --Create the index and constraints for this attribute column  
                SET @idx = CONCAT(N'ix_', @TableName, N'_Version_ID_', @TableColumn);  
                SET @fk = CONCAT(N'fk_', @TableName, N'_' + @ForeignTableName, N'_Version_ID_', @TableColumn);  
  
            --Check for a file link  attribute  
            END ELSE IF (@AttributeType_ID = @AttributeType_File)  
            BEGIN  
  
                SET @ForeignTableName = N'tblFile';  
                SET @idx = CONCAT(N'ix_', @TableName, N'_Version_ID_', @TableColumn);  
                SET @fk = CONCAT(N'fk_', @TableName, N'_', @ForeignTableName, N'_', @TableColumn);  
  
                -- Get list of File IDs that are about to be orphaned.  
                CREATE TABLE #FileIDsToDelete  
                (  
                    ID  INT  
                );  
                DECLARE @GetFileIdsSQL NVARCHAR(MAX) = mdm.udfFileIDReferencesGetSQL(@Entity_ID, NULL, @Attribute_ID, 0)  
  
                IF LEN(@GetFileIdsSQL) > 0  
                BEGIN  
                    SET @GetFileIdsSQL = CONCAT(N'INSERT INTO #FileIDsToDelete(ID)  
', @GetFileIdsSQL);  
                    EXEC sp_executesql @GetFileIdsSQL;  
                END;  
            END; --if  
  
            --Drop FK index  
            IF @idx IS NOT NULL AND EXISTS(SELECT 1 FROM sys.indexes WHERE object_id = @table_ID AND name = @idx) BEGIN  
                --AZURE: Sql Azure does not support DROP INDEX with twp part name  
                --SET @SQL = @SQL + N'  
                --DROP INDEX [mdm].' + QUOTENAME(@TableName) + N'.' + QUOTENAME(@idx) + N';';  
                SET @SQL = @SQL + N'  
                DROP INDEX ' + QUOTENAME(@idx) + N' ON mdm.' + QUOTENAME(@TableName) + N';';  
            END; --if  
  
            --Drop FK constraint  
            IF @fk IS NOT NULL AND EXISTS(SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[mdm].' + @fk) AND parent_object_id = @table_ID)  
            BEGIN  
                SET @SQL = @SQL + N'  
                ALTER TABLE [mdm].' + QUOTENAME(@TableName) + N' DROP CONSTRAINT ' + QUOTENAME(@fk) + N';';  
            END; --if  
  
            --Drop column  
            SET @SQL = @SQL + N'  
                ALTER TABLE mdm.' + QUOTENAME(@TableName) + N' DROP COLUMN ' + QUOTENAME(@TableColumn) + N';';  
  
            --PRINT(@SQL);  
            EXEC sp_executesql @SQL;  
  
  
            IF @AttributeType_ID = @AttributeType_File  
            BEGIN  
                -- Delete orphaned files.  
                IF EXISTS(SELECT 1 FROM #FileIDsToDelete)  
                BEGIN  
                    DECLARE @File_ID mdm.IdList;  
                    INSERT INTO @File_ID  
                    SELECT ID  
                    FROM #FileIDsToDelete;  
  
                    EXEC mdm.udpFilesDelete @File_ID = @File_ID  
                END  
            END  
  
        END; --if  
  
        --Remove attribute group detail entry  
        DELETE FROM mdm.tblAttributeGroupDetail WHERE Attribute_ID = @Attribute_ID;  
  
        --Delete the security around the attribute  
        DECLARE    @Object_ID INT = mdm.udfSecurityObjectIDGetByCode(N'DIMATT');  
        EXEC mdm.udpSecurityPrivilegesDelete NULL, NULL, @Object_ID, @Attribute_ID;  
  
        -- Remove any sync source attribute mappings  
        UPDATE mdm.tblAttribute  
        SET  Source_ID = NULL  
            ,Source_LastChgTS = NULL  
        WHERE Source_ID = @Attribute_ID;  
  
        -- Remove any attribute filters that reference the attribute  
        IF @AttributeType_ID = @AttributeType_Domain -- Only DBAs can be filter parents  
        BEGIN  
            UPDATE mdm.tblAttribute  
            SET  FilterParentAttribute_ID = NULL  
                ,FilterHierarchyDetail_ID = NULL  
            WHERE FilterParentAttribute_ID = @Attribute_ID  
        END  
  
        --Delete the attribute record  
        DELETE FROM mdm.tblAttribute WHERE ID = @Attribute_ID;  
  
        --Recreate the views  
        IF @CreateViewsInd = 1  
        BEGIN  
            EXEC mdm.udpCreateViews @Model_ID, @Entity_ID;  
        END  
  
        --Recreate the subscription views of entity  
        EXEC mdm.udpCreateAllSubscriptionViews NULL, @Entity_ID;  
  
        --Delete the column from the staging table.  
        SET @table_ID = OBJECT_ID(N'stg.' + QUOTENAME(@StagingTableName));  
        IF LEN(COALESCE(@StagingTableName, N'')) > 0 AND EXISTS (SELECT * FROM sys.objects WHERE object_id = @table_ID AND type in (N'U'))  
        BEGIN  
            SET @SQL = N'ALTER TABLE stg.' + QUOTENAME(@StagingTableName) + N' DROP COLUMN ' + QUOTENAME(@AttributeName);  
            --Execute the dynamic SQL  
            EXEC sp_executesql @SQL;  
        END; -- IF  
  
        --Commit only if we are not nested  
        IF @TranCounter = 0  
        BEGIN  
            COMMIT TRANSACTION;  
            SET @TranCommitted = 1;  
        END; -- IF  
  
        -- Recreate the staging stored procedure.  
        IF @MemberType_ID = @MemberType_Leaf  
        BEGIN  
            EXEC mdm.udpEntityStagingCreateLeafStoredProcedure @Entity_ID  
        END -- IF  
        ELSE IF @MemberType_ID = @MemberType_Consolidated  
        BEGIN  
            EXEC mdm.udpEntityStagingCreateConsolidatedStoredProcedure @Entity_ID  
        END -- IF  
  
        RETURN(0);  
  
    END TRY  
    --Compensate as necessary  
    BEGIN CATCH  
  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        IF @TranCommitted = 0 -- Don't rollback when the transaction has been committed.  
        BEGIN  
            IF @TranCounter = 0 ROLLBACK TRANSACTION;  
            ELSE IF XACT_STATE() <> -1 ROLLBACK TRANSACTION TX;  
        END; -- IF  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
  
        --On error, return NULL results  
        --SELECT @Return_ID = NULL;  
        RETURN(1);  
  
    END CATCH;  
  
    SET NOCOUNT OFF;  
END; --proc
go

