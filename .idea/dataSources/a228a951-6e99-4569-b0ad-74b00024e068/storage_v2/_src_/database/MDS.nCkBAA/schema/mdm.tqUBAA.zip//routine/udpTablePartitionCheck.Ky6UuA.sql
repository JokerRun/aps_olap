/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
/*  
EXEC udpTablePartitionCheck  
*/  
CREATE PROCEDURE mdm.udpTablePartitionCheck  
/*WITH*/  
AS BEGIN  
    IF mdm.udfIsEnterpriseEdition() = 1  
    BEGIN  
        DECLARE @ModelID INT,  
                @VersionID INT;  
        DECLARE versionID_cursor CURSOR  
        FOR SELECT ID, Model_ID  
            FROM [mdm].[tblModelVersion];  
  
        OPEN versionID_cursor  
        FETCH NEXT FROM versionID_cursor INTO @VersionID, @ModelID  
  
        WHILE @@FETCH_STATUS = 0  
        BEGIN  
            EXEC mdm.udpTablePartitionSplit @ModelID, @VersionID;  
            FETCH NEXT FROM versionID_cursor INTO @VersionID, @ModelID  
        END  
  
        CLOSE versionID_cursor;  
        DEALLOCATE versionID_cursor;  
    END  
END --proc
go

