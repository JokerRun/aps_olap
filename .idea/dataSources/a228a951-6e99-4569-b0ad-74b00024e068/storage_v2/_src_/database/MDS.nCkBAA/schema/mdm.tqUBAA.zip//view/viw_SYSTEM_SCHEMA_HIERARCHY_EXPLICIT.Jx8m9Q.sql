/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
SELECT * FROM  mdm.viw_SYSTEM_SCHEMA_HIERARCHY_EXPLICIT  
  
*/  
CREATE VIEW mdm.viw_SYSTEM_SCHEMA_HIERARCHY_EXPLICIT  
/*WITH SCHEMABINDING*/  
AS  
SELECT  
    tEnt.Model_ID     Model_ID,   
    tMod.MUID         Model_MUID,   
    tMod.Name         Model_Name,    
    tHir.Entity_ID    Entity_ID,  
    tEnt.MUID         Entity_MUID,  
    tEnt.Name         Entity_Name,  
    tHir.ID           Hierarchy_ID,   
    tHir.MUID         Hierarchy_MUID,   
    tHir.Name         Hierarchy_Name,  
    tHir.IsMandatory  Hierarchy_IsMandatory,   
    Hierarchy_Label  = N'Explicit: ' + tMod.Name + N': ' + tHir.Name,   
    --  
    COALESCE(tHir.EnterUserID, 0) EnteredUser_ID,  
    COALESCE(usrE.MUID, CAST(0x0 AS UNIQUEIDENTIFIER)) EnteredUser_MUID,  
    usrE.UserName EnteredUser_UserName,  
    tHir.EnterDTM EnteredUser_DTM,  
    COALESCE(tHir.LastChgUserID, 0) LastChgUser_ID,  
    COALESCE(usrL.MUID, CAST(0x0 AS UNIQUEIDENTIFIER)) LastChgUser_MUID,  
    usrL.UserName LastChgUser_UserName,  
    tHir.LastChgDTM LastChgUser_DTM  
FROM  
    mdm.tblHierarchy tHir  
    INNER JOIN mdm.tblEntity tEnt ON tEnt.ID = tHir.Entity_ID  
    INNER JOIN mdm.tblModel tMod ON tMod.ID = tEnt.Model_ID  
    LEFT JOIN mdm.tblUser usrE ON tHir.EnterUserID = usrE.ID  
    LEFT JOIN mdm.tblUser usrL ON tHir.LastChgUserID = usrL.ID
go

