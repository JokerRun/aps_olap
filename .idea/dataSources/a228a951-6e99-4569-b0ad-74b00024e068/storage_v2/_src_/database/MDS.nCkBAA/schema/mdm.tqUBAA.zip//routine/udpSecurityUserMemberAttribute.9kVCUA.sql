/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE [mdm].[udpSecurityUserMemberAttribute]  
(  
    @User_ID            INT,  
    @Attribute_ID       INT,  
    @Privilege_ID       INT OUTPUT,  
    @AccessPermission   TINYINT OUTPUT,  
    @CorrelationID      UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
AS  
BEGIN  
    SELECT @Privilege_ID = Privilege_ID, @AccessPermission = AccessPermission  
    FROM mdm.viw_SYSTEM_SECURITY_USER_ATTRIBUTE  
    WHERE User_ID = @User_ID AND ID = @Attribute_ID  
  
    SET @Privilege_ID = ISNULL(@Privilege_ID, 1 /*Deny*/);  
END
go

