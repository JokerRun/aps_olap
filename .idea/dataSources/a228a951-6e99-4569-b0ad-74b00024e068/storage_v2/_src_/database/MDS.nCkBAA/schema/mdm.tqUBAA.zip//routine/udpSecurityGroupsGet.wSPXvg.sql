/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    Returns the specified groups.  
      
    DECLARE @GroupTable mdm.Identifier  
    EXEC mdm.udpSecurityGroupsGet   
        @GroupTable = @GroupTable  
*/  
CREATE PROCEDURE mdm.udpSecurityGroupsGet  
(  
    @GroupTable mdm.Identifier READONLY,-- caller should ensure table does not include rows where both MUID and Name are blank  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    IF EXISTS(SELECT 1 FROM @GroupTable)  
    BEGIN  
        SELECT   
            g.ID,  
            g.MUID,  
            g.SID,  
            g.UserGroupType_ID,  
            g.Name,  
            g.Description,  
            COALESCE(g.EnterUserID, 0) AS EnterUserID,  
            eu.MUID AS EnterUserMUID,  
            COALESCE(eu.UserName, N'') AS EnterUserName,  
            COALESCE(eu.DisplayName, N'') AS EnterUserDisplayName,  
            g.EnterDTM,  
            COALESCE(g.LastChgUserID, 0) AS LastChgUserID,  
            lcu.MUID AS LastChgUserMUID,  
            COALESCE(lcu.UserName, N'') AS LastChgUserName,  
            COALESCE(lcu.DisplayName, N'') AS LastChgUserDisplayName,  
            g.LastChgDTM  
        FROM mdm.tblUserGroup g  
        INNER JOIN @GroupTable crit  
        ON   
            g.Status_ID = 1 AND   
            (crit.MUID IS NOT NULL OR crit.Name IS NOT NULL OR crit.ID IS NOT NULL) AND  
            (crit.MUID IS NULL OR crit.MUID = g.MUID) AND  
            (crit.Name IS NULL OR UPPER(crit.Name) = UPPER(g.Name)) AND  
            (crit.ID IS NULL OR crit.ID = g.ID)  
        LEFT JOIN mdm.tblUser eu   
        ON g.EnterUserID = eu.ID   
        LEFT JOIN mdm.tblUser lcu   
        ON g.LastChgUserID = lcu.ID  
        ORDER BY g.ID;  
    END ELSE  
    BEGIN  
        SELECT   
            g.ID,  
            g.MUID,  
            g.SID,  
            g.UserGroupType_ID,  
            g.Name,  
            g.Description,  
            COALESCE(g.EnterUserID, 0) AS EnterUserID,  
            eu.MUID AS EnterUserMUID,  
            COALESCE(eu.UserName, N'') AS EnterUserName,  
            COALESCE(eu.DisplayName, N'') AS EnterUserDisplayName,  
            g.EnterDTM,  
            COALESCE(g.LastChgUserID, 0) AS LastChgUserID,  
            lcu.MUID AS LastChgUserMUID,  
            COALESCE(lcu.UserName, N'') AS LastChgUserName,  
            COALESCE(lcu.DisplayName, N'') AS LastChgUserDisplayName,  
            g.LastChgDTM  
        FROM mdm.tblUserGroup g  
        LEFT JOIN mdm.tblUser eu   
        ON g.EnterUserID = eu.ID   
        LEFT JOIN mdm.tblUser lcu   
        ON g.LastChgUserID = lcu.ID  
        WHERE g.Status_ID = 1  
        ORDER BY g.ID;  
    END  
  
    SET NOCOUNT OFF;  
END; --proc
go

