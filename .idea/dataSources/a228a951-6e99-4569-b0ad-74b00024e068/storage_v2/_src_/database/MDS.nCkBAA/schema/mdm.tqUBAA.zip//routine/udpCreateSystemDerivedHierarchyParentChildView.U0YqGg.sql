/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    EXEC mdm.udpCreateSystemDerivedHierarchyParentChildView 1;  
    EXEC mdm.udpCreateSystemDerivedHierarchyParentChildView 2;  
    EXEC mdm.udpCreateSystemDerivedHierarchyParentChildView 5;  
    EXEC mdm.udpCreateSystemDerivedHierarchyParentChildView 10;  
    EXEC mdm.udpCreateAllViews;  
*/  
CREATE PROCEDURE [mdm].[udpCreateSystemDerivedHierarchyParentChildView]  
(  
    @DerivedHierarchy_ID    INT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    --Defer view generation if we are in the middle of an upgrade or demo-rebuild  
    IF NOT APPLOCK_MODE(N'public', N'DeferViewGeneration', N'Session') = N'NoLock'   
    BEGIN  
        RETURN;  
    END  
  
    DECLARE   
         @ViewName                      SYSNAME  
        ,@ViewExists                    BIT  
        ,@AnchorNullRecursions          BIT  
  
        -- tblDerivedHierarchyDetail.ForeignType_ID  
        ,@HierarchyItemType_Entity      TINYINT = 0  
        ,@HierarchyItemType_DBA         TINYINT = 1  
        ,@HierarchyItemType_Hierarchy   TINYINT = 2  
        ,@HierarchyItemType_ManyToMany  TINYINT = 5  
  
        ,@MemberType_Leaf               TINYINT = 1  
        ,@MemberType_Consolidated       TINYINT = 2  
        ;  
  
    SELECT  
        @ViewName = CONCAT(N'viw_SYSTEM_', Model_ID, N'_', ID, N'_PARENTCHILD_DERIVED'),  
        @AnchorNullRecursions =  AnchorNullRecursions  
    FROM mdm.tblDerivedHierarchy  
    WHERE ID = @DerivedHierarchy_ID;  
  
    IF @ViewName IS NULL --Ensure hierarchy row actually exists  
    BEGIN   
        RETURN;  
    END  
  
    SET @ViewExists = CASE WHEN EXISTS(SELECT 1 FROM sys.views WHERE [name] = @ViewName AND [schema_id] = SCHEMA_ID('mdm')) THEN 1 ELSE 0 END;  
  
    -- Get all of the hierarchy's levels  
    CREATE TABLE #Levels   
    (  
         Level_ID       INT PRIMARY KEY  
        ,Item_ID        INT NOT NULL  
        ,Item_MUID      UNIQUEIDENTIFIER NOT NULL  
        ,Item_Name      NVARCHAR(100) NOT NULL  
        ,ItemType_ID    TINYINT NOT NULL  
        ,IsVisible      BIT NOT NULL  
        ,IsRecursive    BIT NOT NULL  
        ,Entity_ID      INT NOT NULL  
        ,Entity_MUID    UNIQUEIDENTIFIER NOT NULL  
        ,EntityViewName SYSNAME NOT NULL  
        ,ManyToManyMappingEntityViewName SYSNAME NULL  
        ,ManyToManyChildAttribute_Name NVARCHAR(100) NULL  
    );  
    CREATE INDEX #ix_Levels_IsVisible ON #Levels(IsVisible);  
  
    INSERT INTO #Levels  
    SELECT   
         Level_ID  
        ,Foreign_ID  
        ,Foreign_MUID  
        ,Foreign_Name  
        ,ForeignType_ID  
        ,IsLevelVisible  
        ,IsRecursive  
        ,Entity_ID  
        ,Entity_MUID  
        ,mdm.udfViewNameGetByID(Entity_ID,  
            CASE ForeignType_ID   
                WHEN @HierarchyItemType_Hierarchy THEN 4 -- viw_SYSTEM_<MID>_<EID>_PARENTCHILD  
                ELSE 1                                   -- viw_SYSTEM_<MID>_<EID>_CHILDATTRIBUTES  
                END, 0, 0)  
        ,CASE WHEN ForeignType_ID = @HierarchyItemType_ManyToMany THEN mdm.udfViewNameGetByID(ForeignEntity_ID, 1, 0, 0) END ManyToManyMappingEntityViewName  
        ,ManyToManyChildAttribute_Name  
    FROM mdm.viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED_LEVELS d  
    WHERE Hierarchy_ID = @DerivedHierarchy_ID  
  
    DECLARE  
         @SQL                 NVARCHAR(MAX)  
  
        ,@Level_ID               INT  
        ,@Item_ID                INT  
        ,@Item_MUID              UNIQUEIDENTIFIER  
        ,@Item_Name              NVARCHAR(100)  
        ,@ItemType_ID            TINYINT  
        ,@Entity_ID              INT  
        ,@Entity_MUID            UNIQUEIDENTIFIER  
        ,@IsRecursive            BIT  
        ,@EntityViewName         SYSNAME  
        ,@ManyToManyMappingEntityViewName   SYSNAME  
        ,@ManyToManyChildAttribute_Name     NVARCHAR(100)  
  
        ,@PriorVisibleLevel_ID          INT  
        ,@PriorItem_ID                  INT  
        ,@PriorItemType_ID              TINYINT  
        ,@PriorEntity_ID                INT  
        ,@PriorEntity_MUID              UNIQUEIDENTIFIER  
        ,@PriorIsRecursive              BIT  
        ,@PriorVisibleEntityViewName    SYSNAME  
        ,@PriorManyToManyMappingEntityViewName  SYSNAME  
        ,@PriorManyToManyChildAttribute_Name    NVARCHAR(100)  
  
        ,@NextLevel_ID              INT  
        ,@NextItem_ID               INT  
        ,@NextItem_ID_Clause        NVARCHAR(MAX)  --injection safe.  Only INT values appended into CASE statement  
        ,@NextItemType_ID           TINYINT  
        ,@NextItemType_ID_Clause    NVARCHAR(MAX)  --injection safe.  Only INT values appended into CASE statement  
        ,@NextEntity_ID             INT  
        ,@NextEntity_ID_Clause      NVARCHAR(MAX)  
        ,@NextEntity_MUID           UNIQUEIDENTIFIER  
        ,@NextEntity_MUID_Clause    NVARCHAR(MAX)  
  
        ,@DomainAttributeName       NVARCHAR(100)  
        ,@PriorDomainAttributeName  NVARCHAR(100)  
  
        ,@MaxLevel_ID               INT  
        ,@ChildTypeID_Clause        NVARCHAR(MAX) = N''  
        ,@ParentType_ID             INT  
        ,@DomainAttribute_ID_Clause NVARCHAR(1000)  
        ;  
  
    SELECT @MaxLevel_ID = MAX(Level_ID)  
    FROM #Levels  
  
    IF @MaxLevel_ID IS NULL  
    BEGIN  
        -- The hierarchy has no levels. Delete the view if it already exists.  
        IF @ViewExists = 1  
        BEGIN  
            SET @SQL = CONCAT(N'DROP VIEW mdm.', QUOTENAME(@ViewName), N';');  
            EXEC sp_executesql @SQL;  
        END;  
  
        RETURN;  
    END;  
  
    SET @SQL = CONCAT(CASE WHEN @ViewExists = 1 THEN N'ALTER' ELSE N'CREATE' END, N' VIEW mdm.' + QUOTENAME(@ViewName), N' AS');  
  
    SET @Level_ID = @MaxLevel_ID + 1;  
  
    -- Loop through all levels, from top to bottom, and create Union statements for each level.  
    WHILE EXISTS(SELECT 1 FROM #Levels WHERE Level_ID < @Level_ID AND IsVisible = 1)   
    BEGIN  
        SET @IsRecursive = 0;  
  
        --Get ID's  
        SELECT TOP 1  
             @Level_ID          = Level_ID  
            ,@Item_ID           = Item_ID  
            ,@Item_MUID         = Item_MUID  
            ,@Item_Name         = Item_Name  
            ,@ItemType_ID       = ItemType_ID  
            ,@IsRecursive       = IsRecursive  
            ,@Entity_ID         = Entity_ID  
            ,@Entity_MUID       = Entity_MUID  
            ,@EntityViewName    = EntityViewName  
            ,@ManyToManyMappingEntityViewName = ManyToManyMappingEntityViewName  
            ,@ManyToManyChildAttribute_Name = ManyToManyChildAttribute_Name  
        FROM #Levels   
        WHERE   Level_ID < @Level_ID  
            AND IsVisible = 1  
        ORDER BY Level_ID DESC;  
  
        -- Always use an ORDER BY when selecting TOP  
        SELECT TOP 1   
             @NextLevel_ID = Level_ID  
            ,@NextItem_ID = Item_ID  
            ,@NextItemType_ID = ItemType_ID  
            ,@NextEntity_ID   = Entity_ID  
            ,@NextEntity_MUID = Entity_MUID  
        FROM #Levels  
        WHERE   Level_ID < @Level_ID   
            AND IsVisible = 1  
        ORDER BY Level_ID DESC;  
  
        SET @NextLevel_ID = COALESCE(@NextLevel_ID, -1);  
  
        IF @ItemType_ID = @HierarchyItemType_Hierarchy   
        BEGIN  
            -- Get the next item type\id from the next visible level.  
            SELECT TOP 1  
                 @NextItem_ID = Item_ID  
                ,@NextItemType_ID = ItemType_ID  
                ,@NextEntity_ID   = Entity_ID  
                ,@NextEntity_MUID = Entity_MUID  
            FROM #Levels  
            WHERE   Level_ID < @NextLevel_ID   
                AND IsVisible = 1  
            ORDER BY Level_ID DESC  
        END  
  
        SET @NextItem_ID = ISNULL(@NextItem_ID, -1);  
        --SET @NextItemType_ID = ISNULL(@NextItemType_ID, -1);  
  
  
        --Get Attribute DBA Column Name  
        IF @ItemType_ID IN (@HierarchyItemType_DBA, @HierarchyItemType_ManyToMany)  
        BEGIN  
            SET @DomainAttributeName = @Item_Name;  
        END ELSE  
        BEGIN  
            SET @DomainAttributeName = N'Code';  
        END  
  
        --Get NextEntity_ID  
        IF @ItemType_ID = @HierarchyItemType_Hierarchy  
        BEGIN  
            SET @NextEntity_ID_Clause = CONCAT(  
   N'CASE ChildType_ID  
        WHEN ', @MemberType_Leaf, N'/*Leaf*/ THEN ', @NextEntity_ID, N'  
        WHEN ', @MemberType_Consolidated, N'/*Consolidated*/ THEN ', @Entity_ID, N'  
     END');  
            SET @NextEntity_MUID_Clause = CONCAT(  
   N'CASE ChildType_ID  
        WHEN ', @MemberType_Leaf, N'/*Leaf*/ THEN ''', @NextEntity_MUID, N'''  
        WHEN ', @MemberType_Consolidated, N'/*Consolidated*/ THEN ''', @Entity_MUID, N'''  
     END');  
        END ELSE   
        BEGIN  
            SET @NextEntity_ID_Clause = COALESCE(CAST(@NextEntity_ID AS NVARCHAR(100)), N'NULL');  
            SET @NextEntity_MUID_Clause = CONCAT(N'''', @NextEntity_MUID, N'''')  
        END; --if  
  
        SET @DomainAttribute_ID_Clause =  
            CASE  
                WHEN @ItemType_ID = @HierarchyItemType_Entity THEN N'-1'  
                WHEN @ItemType_ID IN (@HierarchyItemType_DBA, @HierarchyItemType_ManyToMany) THEN CAST(@Item_ID AS NVARCHAR(1000))  
                WHEN @ItemType_ID = @HierarchyItemType_Hierarchy THEN CONCAT(  
   N'CASE  
        WHEN ChildType_ID = ', @MemberType_Leaf, N'/*Leaf*/ THEN ', @NextItem_ID, N'  
        WHEN ChildType_ID = ', @MemberType_Consolidated, N'/*Consolidated*/ THEN ''''  
     END')  
            END;  
        SET @ChildTypeID_Clause =   
            CASE  
                WHEN @ItemType_ID = @HierarchyItemType_Hierarchy THEN N'ChildType_ID'  
                ELSE CONCAT(@HierarchyItemType_DBA, N'/*DBA*/')  
            END; --case  
        SET @ParentType_ID =   
            CASE  
                WHEN @ItemType_ID = @HierarchyItemType_Hierarchy THEN @HierarchyItemType_Hierarchy  
                ELSE @HierarchyItemType_DBA  
            END; --case  
        SET @NextItem_ID_Clause =   
            CASE  
                WHEN @ItemType_ID = @HierarchyItemType_Hierarchy THEN CONCAT(  
   N'CASE  
        WHEN ChildType_ID = ', @MemberType_Leaf, N'/*Leaf*/ THEN ', @NextItem_ID, N'  
        WHEN ChildType_ID = ', @MemberType_Consolidated, N'/*Consolidated*/ THEN ', @Item_ID, N'  
     END')  
                ELSE CAST(@NextItem_ID AS NVARCHAR(100))  
            END; --case  
        SET @NextItemType_ID_Clause =   
            CASE  
                WHEN @ItemType_ID = @HierarchyItemType_Hierarchy THEN CONCAT(  
   N'CASE  
        WHEN ChildType_ID = ', @MemberType_Leaf, N'/*Leaf*/ THEN ', @NextItemType_ID, N'  
        WHEN ChildType_ID = ', @MemberType_Consolidated, N'/*Consolidated*/ THEN ', @HierarchyItemType_Hierarchy, N'/*Hierarchy*/   
     END')  
                ELSE COALESCE(CAST(@NextItemType_ID AS NVARCHAR(10)), N'NULL')  
            END; --case  
  
        -- Topmost Level  
        IF @Level_ID = @MaxLevel_ID   
        BEGIN  
            SET @SQL += CONCAT(N'  
SELECT   
     ', CASE WHEN @ItemType_ID = @HierarchyItemType_Hierarchy THEN N'Parent_ID' ELSE '0' END, N' AS Parent_ID  
    ,', CASE WHEN @ItemType_ID = @HierarchyItemType_Hierarchy THEN CONCAT(N'CASE ChildType_ID WHEN ', @MemberType_Leaf, N'/*Leaf*/ THEN Child_EN_ID WHEN ', @MemberType_Consolidated, N'/*Consolidated*/ THEN Child_HP_ID END') ELSE N'ID' END + N' AS Child_ID  
    ,Version_ID AS Version_ID  
    ,', @DomainAttribute_ID_Clause, N' AS DomainAttribute_ID  
    ,1 AS ParentVisible  
    ,', @Entity_ID, N' AS Entity_ID  
    ,''', @Entity_MUID, N''' AS Entity_MUID  
    ,', @NextEntity_ID_Clause, N' AS NextEntity_ID  
    ,', @NextEntity_MUID_Clause, N' AS NextEntity_MUID  
    ,', @Item_ID, N' AS Item_ID  
    ,''', @Item_MUID, N''' AS Item_MUID  
    ,', @ItemType_ID, N' AS ItemType_ID  
    ,', CASE WHEN @ItemType_ID = @HierarchyItemType_Hierarchy THEN CONCAT(N'CASE WHEN T.Parent_ID <> 0 THEN ', @Item_ID, N' ELSE 0 END') ELSE N'0' END, N' AS ParentItem_ID  
    ,', CASE WHEN @ItemType_ID = @HierarchyItemType_Hierarchy THEN CONCAT(N'CASE WHEN T.Parent_ID <> 0 THEN ', @ItemType_ID, N' ELSE ', @HierarchyItemType_Entity, N'/*Entity*/ END') ELSE CONCAT(@HierarchyItemType_Entity, N'/*Entity*/') END, N' AS ParentItemType_ID  
    ,', CASE WHEN @ItemType_ID = @HierarchyItemType_Hierarchy THEN CONCAT(N'', @Entity_ID) ELSE N'NULL' END, N' AS ParentEntity_ID  
    ,', CASE WHEN @ItemType_ID = @HierarchyItemType_Hierarchy THEN CONCAT(N'''', @Entity_MUID, N'''') ELSE N'NULL' END, N' AS ParentEntity_MUID  
    ,', @NextItem_ID_Clause, N' AS NextItem_ID  
    ,', @NextItemType_ID_Clause, N' AS NextItemType_ID  
    ,', CASE WHEN @ItemType_ID = @HierarchyItemType_Hierarchy THEN N'Child_Code' ELSE N'Code' END, N' AS ChildCode  
    ,', CASE WHEN @ItemType_ID = @HierarchyItemType_Hierarchy THEN N'Child_Name' ELSE N'Name' END, N' AS ChildName  
    ,', CASE WHEN @ItemType_ID = @HierarchyItemType_Hierarchy THEN N'Parent_Code' ELSE N'N''ROOT''' END, N' AS ParentCode  
    ,', CASE WHEN @ItemType_ID = @HierarchyItemType_Hierarchy THEN N'Parent_Name' ELSE N'N''''' END, N' AS ParentName  
    ,', @ChildTypeID_Clause, N' AS ChildType_ID  
    ,', CASE WHEN @ItemType_ID = @HierarchyItemType_Hierarchy THEN CONVERT(NVARCHAR(10), @ParentType_ID) ELSE CONCAT(@HierarchyItemType_Hierarchy, N'/*Hierarchy*/') END, N' AS ParentType_ID  
    ,', @Level_ID, N' AS Level  
    ,', CASE WHEN @ItemType_ID = @HierarchyItemType_Hierarchy THEN N'CONVERT(SQL_VARIANT, T.Child_SortOrder)' ELSE N'T.Code' END, N' AS SortItem  
FROM mdm.', QUOTENAME(@EntityViewName), N' AS T ');  
  
            IF @ItemType_ID = @HierarchyItemType_Hierarchy   
            BEGIN  
                SET @SQL += CONCAT(N'  
WHERE T.Hierarchy_ID = ', @Item_ID);  
            END   
            ELSE IF @ItemType_ID = @HierarchyItemType_DBA AND @IsRecursive = 1 AND @AnchorNullRecursions = 1  
            BEGIN  
            --Rendering for anchored recursive hierarchies.  
                SET @SQL += CONCAT(N'  
WHERE T.', QUOTENAME(@DomainAttributeName),N' IS NULL');  
            END  
        END   
        ELSE BEGIN  
  
        -- All other levels below the top level  
            DECLARE   
                 @ParentVisible     BIT = CASE WHEN @Level_ID <> @PriorVisibleLevel_ID - 1 THEN 0 ELSE 1 END  
                ,@ViewAlias         NVARCHAR(50) = N'T'  
                ,@PriorViewAlias    NVARCHAR(50);   
  
            SET @SQL += CONCAT(N'  
UNION ALL  
SELECT  
    ', CASE WHEN @PriorItemType_ID = @HierarchyItemType_Hierarchy THEN CONCAT(N'CASE priorLevel.ChildType_ID WHEN ', @MemberType_Leaf, N'/*Leaf*/ THEN priorLevel.Child_EN_ID WHEN ', @MemberType_Consolidated, N'/*Consolidated*/ THEN priorLevel.Child_HP_ID END') ELSE N'priorLevel.ID' END, N' AS Parent_ID  
    ,T.ID AS Child_ID  
    ,T.Version_ID AS Version_ID  
    ,', CASE WHEN @PriorIsRecursive = 1 AND @ParentVisible = 1 THEN CONVERT(NVARCHAR(30), @PriorItem_ID) ELSE @DomainAttribute_ID_Clause END, N' AS DomainAttribute_ID  
    ,', @ParentVisible, N' AS ParentVisible  
    ,', @Entity_ID, N' AS Entity_ID  
    ,''', @Entity_MUID, N''' AS Entity_MUID  
    ,', @NextEntity_ID_Clause, N' AS NextEntity_ID  
    ,', @NextEntity_MUID_Clause, N' AS NextEntity_MUID  
    ,', @Item_ID, N' AS Item_ID  
    ,''', @Item_MUID, N''' AS Item_MUID  
    ,', @ItemType_ID, N' AS ItemType_ID  
    ,', @PriorItem_ID, N' AS ParentItem_ID  
    ,', @PriorItemType_ID, N' AS ParentItemType_ID  
    ,''', @PriorEntity_ID, N''' AS ParentEntity_ID  
    ,''', @PriorEntity_MUID, N''' AS ParentEntity_MUID  
    ,', @NextItem_ID_Clause, N' AS NextItem_ID  
    ,', @NextItemType_ID_Clause, N' AS NextItemType_ID  
    ,T.Code AS ChildCode  
    ,T.Name AS ChildName  
    ,priorLevel.', QUOTENAME(CASE WHEN @PriorItemType_ID = @HierarchyItemType_Hierarchy THEN N'Child_Code' ELSE N'Code' END), N' AS ParentCode  
    ,priorLevel.', QUOTENAME(CASE WHEN @PriorItemType_ID = @HierarchyItemType_Hierarchy THEN N'Child_Name' ELSE N'Name' END), N' AS ParentName  
    ,', @ChildTypeID_Clause, N' AS ChildType_ID  
    ,', @ParentType_ID, N' AS ParentType_ID  
    ,', @Level_ID, N' AS Level  
    ,', CASE WHEN @ItemType_ID = @HierarchyItemType_Hierarchy THEN N'CONVERT(SQL_VARIANT, T.Child_SortOrder)' ELSE N'T.Code' END, N' AS SortItem  
FROM mdm.', QUOTENAME(@EntityViewName), N' AS T'  
            );  
  
            --Check to see if Levels are skipped----------------  
            IF @ParentVisible = 0   
            BEGIN  
                ---Loop through all NonVisible Levels  
                --Get List of tables to join to if skipping levels  
                DECLARE   
                     @SkippedLevel_ID        INT = @Level_ID  
                    ,@PriorSkippedLevel_ID   INT  
                    ,@PriorSkippedLevelItemType_ID  TINYINT = NULL  
                    ,@MaxSkippedLevel_ID     INT = @PriorVisibleLevel_ID - 1  
                    ,@SkippedItem_ID         INT  
                    ,@SkippedItemType_ID     TINYINT  
                    ,@SkippedLevelsCount     INT = 0  
                    ,@SkippedEntityViewName  SYSNAME  
                    ,@SkippedDomainAttributeName NVARCHAR(100)  
                    ,@SkippedManyToManyMappingEntityViewName NVARCHAR(128)  
                    ,@SkippedManyToManyChildAttribute_Name NVARCHAR(100)  
                    ;  
  
                WHILE EXISTS(SELECT 1   
                             FROM #Levels  
                             WHERE Level_ID > @SkippedLevel_ID  
                                AND Level_ID <= @MaxSkippedLevel_ID)   
                BEGIN  
  
                    SELECT TOP 1  
                         @SkippedLevel_ID = Level_ID  
                        ,@SkippedItem_ID = Item_ID  
                        ,@SkippedItemType_ID = ItemType_ID  
                        ,@SkippedEntityViewName = EntityViewName  
                        ,@SkippedDomainAttributeName = Item_Name -- Note: No need to check item type. Hierarchy and Entity levels can only be on the top or bottom, which are always visible.  
                        ,@SkippedManyToManyMappingEntityViewName = ManyToManyMappingEntityViewName  
                        ,@SkippedManyToManyChildAttribute_Name = ManyToManyChildAttribute_Name  
                    FROM #Levels  
                    WHERE   Level_ID > @SkippedLevel_ID  
                        AND Level_ID <= @MaxSkippedLevel_ID  
                    ORDER BY Level_ID ASC;  
  
                    IF @SkippedItemType_ID = @HierarchyItemType_ManyToMany  
                    BEGIN  
                        SET @PriorViewAlias = @ViewAlias;  
                        SET @ViewAlias = CONCAT(N'hiddenLvl_', @SkippedLevel_ID, 'map');  
                        -- Note: Joining on Member ID (not Code) for faster perf by making use of the table primary key  
                        SET @SQL += CONCAT(N'  
INNER JOIN mdm.', QUOTENAME(@SkippedManyToManyMappingEntityViewName), N' AS ', QUOTENAME(@ViewAlias), N'  
ON      ', QUOTENAME(@PriorViewAlias), N'.ID = ', QUOTENAME(@ViewAlias), N'.', QUOTENAME(CONCAT(@SkippedManyToManyChildAttribute_Name, N'.ID')), N'  
    AND ', QUOTENAME(@PriorViewAlias), N'.Version_ID = ', QUOTENAME(@ViewAlias), N'.Version_ID')  
                    END  
  
                    SET @PriorViewAlias = @ViewAlias;  
                    SET @ViewAlias = CONCAT(N'hiddenLvl_', @SkippedLevel_ID);  
                    --Build Join Table List  
                    SET @SQL += CONCAT(N'  
INNER JOIN mdm.', QUOTENAME(@SkippedEntityViewName), N' AS ', QUOTENAME(@ViewAlias), N'  
ON      ', QUOTENAME(@PriorViewAlias), N'.', QUOTENAME(CONCAT(@SkippedDomainAttributeName, N'.ID')), N' = ', QUOTENAME(@ViewAlias), N'.ID  
    AND ', QUOTENAME(@PriorViewAlias), N'.Version_ID = ', QUOTENAME(@ViewAlias), N'.Version_ID');  
  
                    --If Last Table to Join then and the final table to join back to base  
                    IF @SkippedLevel_ID = @MaxSkippedLevel_ID   
                    BEGIN  
                        IF      COALESCE(@PriorSkippedLevelItemType_ID, @PriorItemType_ID) = @HierarchyItemType_ManyToMany   
                            AND (@PriorSkippedLevel_ID IS NULL OR @PriorSkippedLevel_ID <> @SkippedLevel_ID - 1) -- only add the mapping table here if the prior (M2M) level is not hidden  
                        BEGIN  
                            SET @PriorViewAlias = @ViewAlias;  
                            SET @ViewAlias = CONCAT(N'hiddenLvl_', @SkippedLevel_ID, 'map');  
                            SET @SQL += CONCAT(N'  
INNER JOIN mdm.', QUOTENAME(@PriorManyToManyMappingEntityViewName), N' AS ', QUOTENAME(@ViewAlias), N'  
ON      ', QUOTENAME(@PriorViewAlias), N'.ID = ', QUOTENAME(@ViewAlias), N'.', QUOTENAME(CONCAT(@PriorManyToManyChildAttribute_Name, N'.ID')), N'  
    AND ', QUOTENAME(@PriorViewAlias), N'.Version_ID = ', QUOTENAME(@ViewAlias), N'.Version_ID');  
                          
                        END  
  
                        SET @PriorViewAlias = @ViewAlias;  
                        SET @ViewAlias = N'priorLevel';  
                        SET @SQL += CONCAT(N'  
INNER JOIN mdm.', QUOTENAME(@PriorVisibleEntityViewName), N' AS ', QUOTENAME(@ViewAlias), N'  
ON      ', QUOTENAME(@PriorViewAlias), N'.', QUOTENAME(CONCAT(@PriorDomainAttributeName, N'.ID')), N' = ', QUOTENAME(@ViewAlias), N'.', QUOTENAME(CASE WHEN @PriorItemType_ID = @HierarchyItemType_Hierarchy THEN N'Child_ID' ELSE N'ID' END), N'  
    AND ', QUOTENAME(@PriorViewAlias), N'.Version_ID = ', QUOTENAME(@ViewAlias), N'.Version_ID',  
                        CASE WHEN @PriorItemType_ID = @HierarchyItemType_Hierarchy THEN CONCAT(N'  
    AND ', QUOTENAME(@ViewAlias), N'.ChildType_ID = ', @MemberType_Leaf, N'/*Leaf*/') END);  
                    END  
  
                    SET @PriorManyToManyMappingEntityViewName = @SkippedManyToManyMappingEntityViewName;  
                    SET @PriorManyToManyChildAttribute_Name = @SkippedManyToManyChildAttribute_Name;  
                    SET @PriorSkippedLevelItemType_ID = @SkippedItemType_ID;  
                    SET @PriorSkippedLevel_ID = @SkippedLevel_ID  
                END; --while  
                --End of Sub Loop of NonVisible Levels  
  
            END  
            ELSE BEGIN  
                --Visible Levels  
  
                IF @PriorItemType_ID = @HierarchyItemType_ManyToMany  
                BEGIN  
                    SET @PriorViewAlias = @ViewAlias;  
                    SET @ViewAlias = N'map';  
  
                    SET @SQL += CONCAT(N'  
INNER JOIN mdm.', QUOTENAME(@PriorManyToManyMappingEntityViewName), N' AS ', QUOTENAME(@ViewAlias), N'  
ON      ', QUOTENAME(@PriorViewAlias), N'.ID = ', QUOTENAME(@ViewAlias), N'.', QUOTENAME(CONCAT(@PriorManyToManyChildAttribute_Name, N'.ID')), N'  
    AND ', QUOTENAME(@PriorViewAlias), N'.Version_ID = ', QUOTENAME(@ViewAlias), N'.Version_ID')  
                  
                END  
  
                SET @PriorViewAlias = @ViewAlias;  
                SET @ViewAlias = N'priorLevel';  
  
                SET @SQL += CONCAT(N'  
INNER JOIN mdm.', QUOTENAME(@PriorVisibleEntityViewName), N' AS ', QUOTENAME(@ViewAlias), N'  
ON      ', QUOTENAME(@PriorViewAlias), N'.', QUOTENAME(CONCAT(@PriorDomainAttributeName, N'.ID')), N' = ', QUOTENAME(@ViewAlias), N'.', QUOTENAME(CASE WHEN @PriorItemType_ID = @HierarchyItemType_Hierarchy THEN N'Child_ID' ELSE N'ID' END), N'  
    AND ', QUOTENAME(@PriorViewAlias), N'.Version_ID = ', QUOTENAME(@ViewAlias), N'.Version_ID');  
  
                IF @PriorItemType_ID = @HierarchyItemType_Hierarchy   
                BEGIN  
                    SET @SQL += CONCAT(N'  
    AND ', QUOTENAME(@ViewAlias), N'.ChildType_ID = ', @MemberType_Leaf, N'/*Leaf*/  
WHERE ', QUOTENAME(@ViewAlias), N'.Hierarchy_ID = ', @PriorItem_ID);  
                END; --if  
            END; --if  
        END; --if  
  
        SELECT  
             @PriorVisibleLevel_ID = @Level_ID  
            ,@PriorItem_ID = @Item_ID  
            ,@PriorItemType_ID = @ItemType_ID  
            ,@PriorVisibleEntityViewName = @EntityViewName  
            ,@PriorDomainAttributeName = @DomainAttributeName  
            ,@PriorEntity_ID = @Entity_ID  
            ,@PriorEntity_MUID = @Entity_MUID  
            ,@PriorIsRecursive = @IsRecursive  
            ,@PriorManyToManyMappingEntityViewName = @ManyToManyMappingEntityViewName  
            ,@PriorManyToManyChildAttribute_Name = @ManyToManyChildAttribute_Name  
  
        IF @ItemType_ID = @HierarchyItemType_Hierarchy   
        BEGIN --Skip next Level after Hierarchy  
            -- Always use an ORDER BY when selecting TOP  
            SELECT TOP 1   
                 @Level_ID = Level_ID  
                ,@Item_ID = Item_ID  
                ,@PriorDomainAttributeName = Item_Name  
            FROM #Levels  
            WHERE   Level_ID < @Level_ID  
                AND IsVisible = 1  
            ORDER BY Level_ID DESC;  
  
            SET @PriorVisibleLevel_ID -= 1 -- Adjust the prior visible level var, so that the skipped level isn't treated as a hidden level.  
        END; --if  
  
    END; --while  
  
    --PRINT @SQL;  
    --PRINT SUBSTRING(@SQL,4001,8000)  
    EXEC sp_executesql @SQL;  
  
    SET NOCOUNT OFF;  
END; --proc
go

