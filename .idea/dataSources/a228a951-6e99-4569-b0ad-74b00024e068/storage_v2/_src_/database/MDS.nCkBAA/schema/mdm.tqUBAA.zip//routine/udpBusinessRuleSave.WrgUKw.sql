/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpBusinessRuleSave  
(  
    @User_ID                INT = NULL,  
    @SaveMode               TINYINT = 0, -- 0 = Create, 1 = Clone, 2 = Update  
    @Name                   NVARCHAR(50) = NULL,  
    @Description            NVARCHAR(255) = NULL,  
    @RuleConditionText      NVARCHAR(MAX) = NULL,  
    @RuleActionText         NVARCHAR(MAX) = NULL,  
    @RuleElseActionText     NVARCHAR(MAX) = NULL,  
    @Priority               INT = NULL,  
    @NotificationGroupMuid  UNIQUEIDENTIFIER = NULL,  
    @NotificationUserMuid   UNIQUEIDENTIFIER = NULL,  
    @RevisionID             BIGINT = NULL,  
    @Status_ID              INT = NULL,  
    @MemberType_ID          TINYINT,  
    @ClearDefinition        BIT = 0,  
    @Entity_MUID            UNIQUEIDENTIFIER = NULL OUTPUT,  
    @Entity_Name            NVARCHAR(MAX) = NULL OUTPUT,  
    @Model_MUID             UNIQUEIDENTIFIER = NULL OUTPUT,  
    @Model_Name             NVARCHAR(50) = NULL OUTPUT,  
    @MUID                   UNIQUEIDENTIFIER = NULL OUTPUT, /*Input (Clone or Update only) and output*/  
    @ID                     INT = NULL OUTPUT, /*Output only*/  
    @CorrelationID          UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    DECLARE @Model_ID                       INT,  
            @Entity_ID                      INT,  
            @NotificationGroup_ID           INT,  
            @NotificationUser_ID            INT,  
  
            @Model_Permission               INT,  
  
            @Permission_Deny                INT = 1,  
            @Permission_Admin               INT = 5,  
  
            @GuidEmpty                      UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER),  
  
            @FunctionalPrivilege_Explorer   TINYINT = 1,  
  
            @SaveMode_Create                TINYINT = 0,  
            @SaveMode_Clone                 TINYINT = 1,  
            @SaveMode_Update                TINYINT = 2,  
  
            @MemberType_Leaf                TINYINT = 1,  
            @MemberType_Consolidated        TINYINT = 2;  
  
  
    SELECT  
        @RevisionID = NULLIF(@RevisionID, 0),  
        @Name = NULLIF(LTRIM(RTRIM(@Name)), N''),  
        @Description = NULLIF(LTRIM(RTRIM(@Description)), N''),  
        @RuleConditionText = NULLIF(LTRIM(RTRIM(@RuleConditionText)), N''),  
        @RuleActionText = NULLIF(LTRIM(RTRIM(@RuleActionText)), N''),  
        @RuleElseActionText = NULLIF(LTRIM(RTRIM(@RuleElseActionText)), N''),  
        @Entity_MUID = NULLIF(@Entity_MUID, @GuidEmpty),  
        @Entity_Name = NULLIF(LTRIM(RTRIM(@Entity_Name)), N''),  
        @Model_MUID = NULLIF(@Model_MUID, @GuidEmpty),  
        @Model_Name = NULLIF(LTRIM(RTRIM(@Model_Name)), N''),  
        @NotificationGroupMuid = NULLIF(@NotificationGroupMuid, @GuidEmpty),  
        @NotificationUserMuid = NULLIF(@NotificationUserMuid, @GuidEmpty),  
        @MUID = NULLIF(@MUID, @GuidEmpty),  
        @ID = NULL;  
  
    IF @SaveMode = @SaveMode_Clone  
    BEGIN  
        IF @MUID IS NOT NULL AND EXISTS (SELECT 1 FROM mdm.tblBRBusinessRule WHERE MUID = @MUID)  
        BEGIN  
            SET @SaveMode = @SaveMode_Update;  
        END  
        ELSE  
        BEGIN  
            SET @SaveMode = @SaveMode_Create;  
        END  
    END  
  
    IF @SaveMode = @SaveMode_Create  
    BEGIN  
        SET @MUID = COALESCE(@MUID, NEWID());  
    END  
  
    IF @SaveMode = @SaveMode_Update  
    BEGIN  
        -- made sure a MUID of an existing row was given  
        IF @MUID IS NULL OR NOT EXISTS (SELECT 1 FROM mdm.tblBRBusinessRule WHERE MUID = @MUID)  
        BEGIN  
            RAISERROR('MDSERR400001|The Update operation failed. The MUID was not found.', 16, 1);  
            RETURN;  
        END  
  
        -- make sure the rule has not changed since the LastChanged date (if given)  
        IF (@RevisionID IS NOT NULL AND @RevisionID <> (SELECT LastChgTS FROM mdm.tblBRBusinessRule WHERE MUID = @MUID))  
        BEGIN  
            RAISERROR('MDSERR400014|The business rule cannot be updated. It has been changed by another user.', 16, 1);  
            RETURN;  
        END  
  
        SELECT @Entity_ID = [Entity_ID] FROM mdm.tblBRBusinessRule WHERE MUID = @MUID;  
  
        SELECT @Model_Permission = m.Privilege_ID  
        FROM mdm.viw_SYSTEM_SECURITY_USER_MODEL m  
        INNER JOIN mdm.tblEntity en ON m.ID = en.Model_ID  
        WHERE [User_ID] = @User_ID AND en.ID = @Entity_ID;  
    END  
    ELSE  
    BEGIN  
        IF @MemberType_ID NOT IN (@MemberType_Leaf, @MemberType_Consolidated)  
        BEGIN  
            RAISERROR('MDSERR400008|The MemberType is not valid for the rule.', 16, 1);  
            RETURN;  
        END  
  
        EXEC mdm.udpInformationLookupModel  
            @User_ID = @User_ID,  
            @Model_MUID = @Model_MUID,  
            @Model_Name = @Model_Name,  
            @ID = @Model_ID OUTPUT,  
            @Name = @Model_Name OUTPUT,  
            @MUID = @Model_MUID OUTPUT,  
            @Privilege_ID = @Model_Permission OUTPUT;  
  
        IF @Model_ID IS NULL  
        BEGIN  
            RAISERROR('MDSERR300005|The supplied model is not valid.', 16, 1);  
            RETURN;  
        END;  
  
        EXEC mdm.udpInformationLookupEntity  
            @User_ID = @User_ID,  
            @Model_ID = @Model_ID,  
            @Entity_MUID = @Entity_MUID,  
            @Entity_Name = @Entity_Name,  
            @ID = @Entity_ID OUTPUT,  
            @Name = @Entity_Name OUTPUT,  
            @MUID = @Entity_MUID OUTPUT;  
  
        IF @Entity_ID IS NULL  
        BEGIN  
            RAISERROR('MDSERR300008|The supplied entity is not valid.', 16, 1);  
            RETURN;  
        END;  
    END  
  
    IF @Model_Permission <> @Permission_Admin  
    BEGIN  
        RAISERROR('MDSERR120003|The user does not have permission or the object ID is not valid.', 16, 1);  
        RETURN;  
    END  
  
    -- Verify the entity is not a sync target.  
    IF EXISTS(SELECT 1 FROM mdm.tblSyncRelationship WHERE TargetEntity_ID = @Entity_ID)  
    BEGIN  
        RAISERROR('MDSERR200217|The business rule cannot be saved. The entity is the target of a sync relationship.', 16, 1);  
        RETURN;  
    END  
  
    IF @Name IS NULL  
    BEGIN  
        RAISERROR('MDSERR400010|Business rule name is required.', 16, 1);  
        RETURN;  
    END  
  
    IF EXISTS(  
        SELECT 1  
        FROM mdm.tblBRBusinessRule  
        WHERE [Name] = @Name  
            AND MUID <> @MUID  
            AND [Entity_ID] = @Entity_ID  
            and MemberType_ID = @MemberType_ID)  
    BEGIN  
        RAISERROR('MDSERR400011|A business rule with that name already exists for the entity and member type.', 16, 1);  
        RETURN;  
    END  
  
    -- get notification id  
    IF @NotificationGroupMuid IS NOT NULL AND @NotificationUserMuid IS NOT NULL  
    BEGIN  
        RAISERROR('MDSERR400036|Specify either a user, a group, or neither, but not both', 16, 1);  
        RETURN;  
    END  
  
    IF @NotificationGroupMuid IS NOT NULL  
    BEGIN  
        SELECT @NotificationGroup_ID = ID  
        FROM mdm.tblUserGroup  
        WHERE MUID = @NotificationGroupMuid  
  
        IF @NotificationGroup_ID IS NULL  
        BEGIN  
            RAISERROR('MDSERR500025|The principal ID for the user or group is not valid.', 16, 1);  
            RETURN;  
        END  
    END  
  
    IF @NotificationUserMuid IS NOT NULL  
    BEGIN  
        SELECT @NotificationUser_ID = ID  
        FROM mdm.tblUser  
        WHERE MUID = @NotificationUserMuid  
  
        IF @NotificationUser_ID IS NULL                                                                        -- Ensure the user exists and can see members subject to the business rule by checking:  
            OR NOT EXISTS (  
                SELECT ID  
                FROM mdm.viw_SYSTEM_SECURITY_USER_MEMBERTYPE  
                WHERE User_ID = @NotificationUser_ID  
                    AND ID = @MemberType_ID  
                    AND @Entity_ID = @Entity_ID  
                    AND Privilege_ID <> @Permission_Deny)                                                       -- Entity Member Type permission, and  
            OR mdm.udfSecurityUserFunctionIsAllowed(@NotificationUser_ID, @FunctionalPrivilege_Explorer) = 0    -- Explorer function  
        BEGIN  
            RAISERROR('MDSERR120000|The user is not valid or has insufficient permissions.', 16, 1);  
            RETURN;  
        END  
    END  
  
    IF @SaveMode = @SaveMode_Create  
    BEGIN  
        -- add row  
        INSERT INTO mdm.tblBRBusinessRule (  
            MUID,  
            [Name],  
            [Description],  
            RuleConditionText,  
            RuleActionText,  
            RuleElseActionText,  
            Entity_ID,  
            MemberType_ID,  
            Status_ID,  
            Priority,  
            NotificationGroupID,  
            NotificationUserID,  
            EnterDTM,  
            EnterUserID,  
            LastChgDTM,  
            LastChgUserID  
        )  
        VALUES (  
            @MUID,  
            @Name,  
            @Description,  
            @RuleConditionText,  
            @RuleActionText,  
            @RuleElseActionText,  
            @Entity_ID,  
            @MemberType_ID,  
            COALESCE(@Status_ID, mdm.udfBusinessRuleGetNewStatusID(1, 0)), -- 1 = enum ActionType.Create  
            @Priority,  
            @NotificationGroup_ID,  
            @NotificationUser_ID,  
            GETUTCDATE(),  
            @User_ID,  
            GETUTCDATE(),  
            @User_ID  
        );  
  
        IF @@ERROR = 0  
        BEGIN  
            SET @ID = SCOPE_IDENTITY();  
        END  
    END  
    ELSE  
    BEGIN  
        -- find Action_ID  
        DECLARE @Action_ID INT SET @Action_ID = 3 -- 3 = Change  
        IF @Status_ID IS NOT NULL  
        BEGIN  
            DECLARE @CurrentStatus_ID INT = (SELECT Status_ID FROM mdm.tblBRBusinessRule WHERE MUID = @MUID)  
            IF (@CurrentStatus_ID NOT IN (2,5) AND @Status_ID IN (2,5)) SET @Action_ID = 5 -- 5 = Exclude  
            ELSE IF (@CurrentStatus_ID IN (2,5) AND @Status_ID IN (1,3)) SET @Action_ID = 2 -- 2 = Activate  
        END  
  
        -- update row  
        UPDATE mdm.tblBRBusinessRule  
        SET [Name] = @Name,  
            [Description] = @Description,  
            RuleConditionText = @RuleConditionText,  
            RuleActionText = @RuleActionText,  
            RuleElseActionText = @RuleElseActionText,  
            Status_ID = mdm.udfBusinessRuleGetNewStatusID(@Action_ID, Status_ID),  
            Priority = @Priority,  
            NotificationGroupID = @NotificationGroup_ID,  
            NotificationUserID = @NotificationUser_ID,  
            LastChgDTM = GETUTCDATE(),  
            LastChgUserID = @User_ID  
        WHERE MUID = @MUID  
  
        IF @@ERROR = 0  
        BEGIN  
            SELECT @ID = ID FROM mdm.tblBRBusinessRule WHERE MUID = @MUID;  
  
            IF @ClearDefinition = 1  
            BEGIN  
                DELETE brip  
                FROM mdm.tblBRItemProperties brip  
                INNER JOIN mdm.tblBRItem bri ON bri.ID = brip.BRItem_ID  
                INNER JOIN mdm.tblBRLogicalOperatorGroup brlog ON brlog.ID = bri.BRLogicalOperatorGroup_ID  
                WHERE brlog.BusinessRule_ID = @ID;  
  
                DELETE bri  
                FROM mdm.tblBRItem bri  
                INNER JOIN mdm.tblBRLogicalOperatorGroup brlog ON brlog.ID = bri.BRLogicalOperatorGroup_ID  
                WHERE brlog.BusinessRule_ID = @ID  
  
                DELETE brlog  
                FROM mdm.tblBRLogicalOperatorGroup brlog  
                WHERE brlog.BusinessRule_ID = @ID  
            END  
        END  
    END  
  
    SET NOCOUNT OFF  
END
go

