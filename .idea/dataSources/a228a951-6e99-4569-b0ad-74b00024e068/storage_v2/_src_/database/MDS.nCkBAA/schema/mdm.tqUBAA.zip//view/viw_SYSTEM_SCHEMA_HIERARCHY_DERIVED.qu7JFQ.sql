/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE VIEW mdm.viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED  
/*WITH SCHEMABINDING*/  
AS  
  
SELECT  
    tHir.Model_ID               Model_ID,   
    tMod.MUID                   Model_MUID,   
    tMod.Name                   Model_Name,    
    tHir.ID                     Hierarchy_ID,   
    tHir.MUID                   Hierarchy_MUID,   
    tHir.Name                   Hierarchy_Name,  
    tHir.AnchorNullRecursions   Hierarchy_AnchorNullRecursions,         
    Hierarchy_Label  = N'Derived: ' + tMod.Name + ': ' + tHir.Name,   
  
    COALESCE(tHir.EnterUserID, 0) EnteredUser_ID,  
    COALESCE(usrE.MUID, CAST(0x0 AS UNIQUEIDENTIFIER)) EnteredUser_MUID,  
    usrE.UserName EnteredUser_UserName,  
    tHir.EnterDTM EnteredUser_DTM,  
    COALESCE(tHir.LastChgUserID, 0) LastChgUser_ID,  
    COALESCE(usrL.MUID, CAST(0x0 AS UNIQUEIDENTIFIER)) LastChgUser_MUID,  
    usrL.UserName LastChgUser_UserName,  
    tHir.LastChgDTM LastChgUser_DTM  
FROM  
    mdm.tblModel tMod   
    INNER JOIN mdm.tblDerivedHierarchy tHir ON tMod.ID = tHir.Model_ID   
    LEFT JOIN mdm.tblUser usrE ON tHir.EnterUserID = usrE.ID  
    LEFT JOIN mdm.tblUser usrL ON tHir.LastChgUserID = usrL.ID
go

