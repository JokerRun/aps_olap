/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE FUNCTION mdm.udfIsEnterpriseEdition()  
RETURNS BIT  
/*WITH SCHEMABINDING*/  
AS BEGIN  
    DECLARE @Ret BIT;  
    SELECT @Ret = CASE CHARINDEX(N'Business',CONVERT(NVARCHAR(128), SERVERPROPERTY ('Edition'))) WHEN 0 THEN 1 ELSE 0 END;  
    RETURN @Ret;  
END; --fn
go

