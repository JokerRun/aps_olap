/*  
    SELECT * FROM mdm.viw_SYSTEM_VERSION  
*/  
/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE VIEW mdm.viw_SYSTEM_VERSION  
/*WITH SCHEMABINDING*/  
AS  
    SELECT [SchemaVersion]  
    FROM [mdm].[tblSystem]
go

