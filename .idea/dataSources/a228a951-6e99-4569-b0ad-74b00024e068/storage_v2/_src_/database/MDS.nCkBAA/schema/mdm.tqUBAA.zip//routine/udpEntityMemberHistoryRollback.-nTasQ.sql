/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
EXEC mdm.udpEntityMemberHistoryRollback @User_ID = 1, @Model_Name = N'Product', @Entity_Name = N'Product', @Version_Name = N'Version 4', @MemberType_ID= 1, @Revision_ID = 248390, @LogFlag = 1;  
EXEC mdm.udpEntityMemberHistoryRollback @User_ID = 1, @Model_Name = N'Product', @Entity_Name = N'Product', @Version_Name = N'Version 4', @MemberType_ID= 2, @Revision_ID = 248862, @LogFlag = 1;  
EXEC mdm.udpEntityMemberHistoryRollback @User_ID = 1, @Model_Name = N'Product', @Entity_Name = N'Product', @Version_Name = N'Version 4', @MemberType_ID= 3, @Revision_ID = 248850, @LogFlag = 1;  
EXEC mdm.udpEntityMemberHistoryRollback @User_ID = 1, @Model_Name = N'Product', @Entity_Name = N'Product', @Version_Name = N'Version 4', @MemberType_ID= 4, @Revision_ID = 248625, @LogFlag = 1;  
EXEC mdm.udpEntityMemberHistoryRollback @User_ID = 1, @Model_Name = N'Product', @Entity_Name = N'Product', @Version_Name = N'Version 4', @MemberType_ID= 5, @Revision_ID = 248850, @LogFlag = 1;  
*/  
CREATE PROCEDURE mdm.udpEntityMemberHistoryRollback  
(  
    @User_ID                INT,  
    @Model_Name             NVARCHAR(50) = NULL,  
    @Model_MUID             UNIQUEIDENTIFIER = NULL,  
    @Entity_Name            NVARCHAR(50) = NULL,  
    @Entity_MUID            UNIQUEIDENTIFIER= NULL,  
    @Version_Name           NVARCHAR(50) = NULL,  
    @Version_MUID           UNIQUEIDENTIFIER = NULL,  
    @MemberType_ID          TINYINT,  
    @Revision_ID            BIGINT,  
    @CorrelationID          UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    DECLARE @GuidEmpty                      UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER),  
            @Model_ID                       INT,  
            @Entity_ID                      INT,  
            @Version_ID                     INT,  
            @Member_ID                      INT,  
  
            @EntityMemberTableName          SYSNAME,  
            @EntityHistoryTableName         SYSNAME,  
            @MemberIDColumn                 SYSNAME,  
            @EntityParentMemberTableName    SYSNAME,  
            @EntityChildMemberTableName     SYSNAME,  
            @ChildTypeMemberType_ID         TINYINT,  
            @ChildMemberIDColumn            SYSNAME,  
            @AnnotationTableName            SYSNAME,  
  
            @Model_Permission               INT,  
            @Member_Permission              INT,  
            @Member_AccessPermission        TINYINT,  
            @Permission_Admin               INT = 5,  
            @Permission_Access              INT = 4,  
            @Permission_Deny                INT = 1,  
            @AccessPermission_All           TINYINT = 7,  
            @AccessPermission_Create        TINYINT = 1,  
            @AccessPermission_Update        TINYINT = 2,  
            @AccessPermission_Delete        TINYINT = 4,  
  
            @MemberType_Leaf                TINYINT = 1,  
            @MemberType_Consolidated        TINYINT = 2,  
            @MemberType_Collection          TINYINT = 3,  
            @MemberType_Hierarchy           TINYINT = 4,  
            @MemberType_CollectionMember    TINYINT = 5,  
  
            @AttributeType_Domain           TINYINT = 2,  
            @AttributeType_System           TINYINT = 3,  
  
            @CurrentStatus                  TINYINT,  
            @HistoryStatus                  TINYINT,  
            @Status_Active                  TINYINT = 1,  
  
            @ColumnString                   NVARCHAR(MAX),  
            @DBAInnerJoinString             NVARCHAR(MAX),  
            @GetMemeberHistoryOutputQuery   NVARCHAR(MAX),  
            @SQL                            NVARCHAR(MAX);  
  
    SELECT  
        @User_ID = NULLIF(@User_ID, 0),  
        @Model_MUID = NULLIF(@Model_MUID, @GuidEmpty),  
        @Model_Name = NULLIF(LTRIM(RTRIM(@Model_Name)), N''),  
        @Entity_MUID = NULLIF(@Entity_MUID, @GuidEmpty),  
        @Entity_Name = NULLIF(LTRIM(RTRIM(@Entity_Name)), N''),  
        @Version_MUID = NULLIF(@Version_MUID, @GuidEmpty),  
        @Version_Name = NULLIF(LTRIM(RTRIM(@Version_Name)), N''),  
        @Revision_ID = NULLIF(@Revision_ID, 0)  
  
    IF @User_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR100009|The User ID is not valid.', 16, 1);  
        RETURN;  
    END  
  
    IF @MemberType_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR210021|MemberType ID is not valid.', 16, 1);  
        RETURN;  
    END  
  
    IF @Revision_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR200223|Revision ID is not valid.', 16, 1);  
        RETURN;  
    END  
  
    EXEC mdm.udpInformationLookupModel @User_ID = @User_ID, @Model_MUID = @Model_MUID, @Model_Name = @Model_Name, @ID = @Model_ID OUTPUT, @Privilege_ID = @Model_Permission OUTPUT;  
    IF @Model_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300005|The supplied model is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    SELECT @Version_ID = ID  
    FROM mdm.tblModelVersion   
    WHERE  
            (@Version_MUID IS NOT NULL OR @Version_Name IS NOT NULL)   
        AND (@Version_MUID IS NULL OR MUID = @Version_MUID)   
        AND (@Version_Name IS NULL OR Name = @Version_Name)  
        AND Model_ID = @Model_ID;  
    IF @Version_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300006|The supplied version is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    EXEC mdm.udpInformationLookupEntity @User_ID = @User_ID, @Model_ID = @Model_ID, @Entity_MUID = @Entity_MUID, @Entity_Name = @Entity_Name, @ID = @Entity_ID OUTPUT;  
    IF @Entity_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300008|The supplied entity is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    SET @EntityMemberTableName = mdm.udfTableNameGetByID(@Entity_ID, @MemberType_ID);  
    SET @EntityHistoryTableName = CONCAT(mdm.udfTableNameGetByID(@Entity_ID, @MemberType_ID), N'_HS');  
  
    SET @MemberIDColumn =  
        CASE @MemberType_ID  
            WHEN @MemberType_Leaf THEN N'EN_ID'  
            WHEN @MemberType_Consolidated THEN N'HP_ID'  
            WHEN @MemberType_Collection THEN N'CN_ID'  
            WHEN @MemberType_Hierarchy THEN N'HR_ID'  
            WHEN @MemberType_CollectionMember THEN N'CM_ID'  
        END;  
  
    SET @SQL = CONCAT(N'  
        DECLARE @HistoryMember_ID INT;  
        SELECT @HistoryMember_ID = ', @MemberIDColumn, ', @HistoryStatus = Status_ID',  
            CASE WHEN @MemberType_ID = @MemberType_Hierarchy OR @MemberType_ID = @MemberType_CollectionMember THEN N', @ChildTypeMemberType_ID = ChildType_ID' END  
         , N'  
        FROM [mdm].', QUOTENAME(@EntityHistoryTableName), N'  
        WHERE Version_ID = @Version_ID AND ID = @Revision_ID;  
  
        IF @HistoryMember_ID IS NOT NULL  
        BEGIN  
            SELECT @Member_ID = ID, @CurrentStatus = Status_ID  
            FROM [mdm].', QUOTENAME(@EntityMemberTableName), N'  
            WHERE Version_ID = @Version_ID AND ID = @HistoryMember_ID;  
        END;  
        ');  
  
    EXEC sp_executesql @SQL, N'@Version_ID INT, @Revision_ID BIGINT, @Member_ID INT OUTPUT, @HistoryStatus TINYINT OUT, @CurrentStatus TINYINT OUT, @ChildTypeMemberType_ID TINYINT OUT',  
                               @Version_ID,     @Revision_ID,        @Member_ID OUTPUT,     @HistoryStatus OUT,         @CurrentStatus OUT,         @ChildTypeMemberType_ID OUT;  
  
    IF @Member_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR200223|Revision ID is not valid or Member does not exist.', 16, 1);  
        RETURN;  
    END  
  
    SET @ChildMemberIDColumn =  
        CASE @ChildTypeMemberType_ID  
            WHEN @MemberType_Leaf THEN N'Child_EN_ID'  
            WHEN @MemberType_Consolidated THEN N'Child_HP_ID'  
            WHEN @MemberType_Collection THEN N'Child_CN_ID'  
        END;  
  
    IF @Model_Permission = @Permission_Admin  
    BEGIN  
        SET @Member_Permission = @Permission_Access;  
        SET @Member_AccessPermission = @AccessPermission_All;  
    END  
    ELSE  
    BEGIN  
        DECLARE @Member_Permission_TINYINT TINYINT;  
        EXEC mdm.udpSecurityMemberResolverGet @User_ID, @Version_ID, NULL,NULL, @Entity_ID, @Member_ID, @MemberType_ID, @Member_Permission_TINYINT OUTPUT, @Member_AccessPermission OUTPUT;  
  
        SET @Member_Permission = @Member_Permission_TINYINT;  
        IF @Member_Permission = @Permission_Deny  
        BEGIN  
            RAISERROR('MDSERR120002|The user does not have permission to perform this operation.', 16, 1);  
            RETURN;  
        END  
    END  
  
    IF @CurrentStatus != @HistoryStatus  
    BEGIN  
          
        IF @CurrentStatus = @Status_Active AND (@Member_AccessPermission & @AccessPermission_Delete != @AccessPermission_Delete)  
        -- Rollback to inactive  
        BEGIN  
            RAISERROR('MDSERR120002|The user does not have permission to perform this operation.', 16, 1);  
            RETURN;  
        END  
        ELSE IF @Member_AccessPermission & @AccessPermission_Create != @AccessPermission_Create  
        -- Rollback to active  
        BEGIN  
            RAISERROR('MDSERR120002|The user does not have permission to perform this operation.', 16, 1);  
            RETURN;  
        END  
    END  
  
    SET @GetMemeberHistoryOutputQuery = mdm.udfGetHistoryOutputQuery(@Entity_ID, @MemberType_ID, NULL, NULL);  
  
    IF (@MemberType_ID = @MemberType_Leaf OR @MemberType_ID = @MemberType_Consolidated OR @MemberType_ID = @MemberType_Collection)  
    BEGIN  
        --Working set to look up MUID/Name and confirm that provided pairs match  
        CREATE TABLE #AttributesWorkingSet  
        (  
            MUID UNIQUEIDENTIFIER NULL,  
            Name NVARCHAR(250) COLLATE DATABASE_DEFAULT NULL,  
            TableColumn SYSNAME,  
            DBAEntityTable SYSNAME NULL,  
            ID INT NULL,  
            AttributeType_ID TINYINT NULL,  
            DataType_ID TINYINT NULL,  
            AccessPermission TINYINT  
        );  
        CREATE INDEX #ix_AttributesWorkingSet_Name ON #AttributesWorkingSet(Name);  
  
        INSERT INTO #AttributesWorkingSet  
        (  
            MUID,  
            Name,  
            TableColumn,  
            DBAEntityTable,  
            ID,  
            AttributeType_ID,  
            DataType_ID,  
            AccessPermission  
        )  
        SELECT  
            att.MUID,  
            att.Name,  
            att.TableColumn,  
            en.EntityTable,  
            att.ID,  
            att.AttributeType_ID,  
            att.DataType_ID,  
            sec.AccessPermission  
        FROM mdm.tblAttribute att  
        INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ATTRIBUTE sec ON att.ID = sec.ID  
        LEFT JOIN mdm.tblEntity en ON att.DomainEntity_ID = en.ID AND att.AttributeType_ID = @AttributeType_Domain  
        WHERE sec.User_ID = @User_ID  
            AND att.Entity_ID = @Entity_ID  
            AND att.MemberType_ID = @MemberType_ID  
            AND att.AttributeType_ID <> @AttributeType_System  
            AND (AccessPermission & @AccessPermission_Update) = @AccessPermission_Update  
  
        IF NOT EXISTS(SELECT ID FROM #AttributesWorkingSet)  
        BEGIN  
            RAISERROR('MDSERR120002|The user does not have permission to perform this operation.', 16, 1);  
            RETURN;  
        END  
  
        SET @ColumnString = N'  
                LastChgDTM = @Now,  
                LastChgUserID = @User_ID,  
                Status_ID = hs.Status_ID';  
        SET @DBAInnerJoinString = N'';  
  
        SELECT  
            @DBAInnerJoinString += CONCAT(N'  
            LEFT JOIN mdm.', QUOTENAME(DBAEntityTable), N' ', TableColumn, N'_EN' ,' ON hs.', QUOTENAME(TableColumn), N' = ', TableColumn, N'_EN.[ID] AND ', TableColumn,'_EN.Version_ID = @Version_ID')  
        FROM #AttributesWorkingSet  
        WHERE AttributeType_ID = @AttributeType_Domain;  
  
        IF @MemberType_ID = @MemberType_Collection  
        BEGIN  
            SET @DBAInnerJoinString += N'  
            LEFT JOIN [mdm].[tblUser] owner on owner.ID = hs.Owner_ID';  
        END  
  
        SELECT  
            @ColumnString += N',  
                ' + CASE  
                    WHEN @MemberType_ID = @MemberType_Collection AND Name = N'Owner_ID' THEN N'Owner_ID = owner.ID'  
                    WHEN AttributeType_ID = @AttributeType_Domain THEN CONCAT(QUOTENAME(TableColumn), N' = ', QUOTENAME(TableColumn + '_EN'), N'.ID')  
                    ELSE CONCAT(QUOTENAME(TableColumn), N'= hs.', QUOTENAME(TableColumn)) END  
        FROM #AttributesWorkingSet  
  
        SET @SQL = CONCAT(N'  
            DECLARE @Now DATETIME2 = GETUTCDATE();  
            UPDATE m  
            SET',  
            @ColumnString, @GetMemeberHistoryOutputQuery, N'  
            FROM [mdm].', QUOTENAME(@EntityMemberTableName), ' m  
            INNER JOIN [mdm].', QUOTENAME(@EntityHistoryTableName), ' hs ON hs.', @MemberIDColumn, ' = m.ID AND m.Version_ID = @Version_ID', @DBAInnerJoinString, N'  
            WHERE hs.Version_ID = @Version_ID  
                AND hs.ID = @Revision_ID;  
            ');  
        EXEC sp_executesql @SQL, N'@Version_ID INT, @Revision_ID BIGINT, @User_ID INT',  
                                   @Version_ID,     @Revision_ID,        @User_ID;  
    END  
    ELSE IF @MemberType_ID = @MemberType_Hierarchy  
    BEGIN  
        SET @EntityParentMemberTableName = mdm.udfTableNameGetByID(@Entity_ID, @MemberType_Consolidated);  
        SET @EntityChildMemberTableName = mdm.udfTableNameGetByID(@Entity_ID, @ChildTypeMemberType_ID);  
        SET @SQL = CONCAT(N'  
        DECLARE @Now DATETIME2 = GETUTCDATE();  
        UPDATE hr  
        SET  
            LastChgDTM = @Now,  
            LastChgUserID = @User_ID,  
            Status_ID = hs.Status_ID,  
            Parent_HP_ID = hs.Parent_HP_ID,  
            ChildType_ID = hs.ChildType_ID,  
            ',  
            CASE @ChildTypeMemberType_ID  
               WHEN @MemberType_Leaf THEN N'Child_EN_ID = hs.Child_EN_ID,'  
               WHEN @MemberType_Consolidated THEN N'Child_HP_ID = hs.Child_HP_ID,'  
            END, N'  
            SortOrder = hs.SortOrder,  
            LevelNumber = hs.LevelNumber', @GetMemeberHistoryOutputQuery, N'  
        FROM [mdm].', QUOTENAME(@EntityMemberTableName), ' hr  
        INNER JOIN [mdm].', QUOTENAME(@EntityHistoryTableName), ' hs ON hs.', @MemberIDColumn ,N' = hr.ID AND hr.Version_ID = @Version_ID  
        INNER JOIN [mdm].', QUOTENAME(@EntityChildMemberTableName), ' child ON hs.', @ChildMemberIDColumn ,N' = child.ID AND child.Version_ID = @Version_ID  
        LEFT JOIN [mdm].', QUOTENAME(@EntityParentMemberTableName), ' parent ON hs.Parent_HP_ID = parent.ID AND parent.Version_ID = @Version_ID  
        WHERE hs.Version_ID = @Version_ID  
            AND hs.ID = @Revision_ID  
            AND (hs.Parent_HP_ID IS NULL OR parent.ID IS NOT NULL)');  
        EXEC sp_executesql @SQL, N'@Version_ID INT, @Revision_ID BIGINT, @User_ID INT',  
                                   @Version_ID,     @Revision_ID,        @User_ID;  
    END  
    ELSE IF @MemberType_ID = @MemberType_CollectionMember  
    BEGIN  
        SET @EntityParentMemberTableName = mdm.udfTableNameGetByID(@Entity_ID, @MemberType_Collection);  
        SET @EntityChildMemberTableName = mdm.udfTableNameGetByID(@Entity_ID, @ChildTypeMemberType_ID);  
        SET @SQL = CONCAT(N'  
        DECLARE @Now DATETIME2 = GETUTCDATE();  
        UPDATE cm  
        SET  
            LastChgDTM = @Now,  
            LastChgUserID = @User_ID,  
            Status_ID = hs.Status_ID,  
            Parent_CN_ID = hs.Parent_CN_ID,  
            ChildType_ID = hs.ChildType_ID,  
            ',  
            CASE @ChildTypeMemberType_ID  
               WHEN @MemberType_Leaf THEN N'Child_EN_ID = hs.Child_EN_ID,'  
               WHEN @MemberType_Consolidated THEN N'Child_HP_ID = hs.Child_HP_ID,'  
               WHEN @MemberType_Collection THEN N'Child_CN_ID = hs.Child_CN_ID,'  
            END, N'  
            SortOrder = hs.SortOrder,  
            Weight = hs.Weight', @GetMemeberHistoryOutputQuery, N'  
        FROM [mdm].', QUOTENAME(@EntityMemberTableName), ' cm  
        INNER JOIN [mdm].', QUOTENAME(@EntityHistoryTableName), ' hs ON hs.', @MemberIDColumn ,N' = cm.ID AND cm.Version_ID = @Version_ID  
        INNER JOIN [mdm].', QUOTENAME(@EntityChildMemberTableName), ' child ON hs.', @ChildMemberIDColumn ,N' = child.ID AND child.Version_ID = @Version_ID  
        INNER JOIN [mdm].', QUOTENAME(@EntityParentMemberTableName), ' parent on hs.Parent_CN_ID = parent.ID AND parent.Version_ID = @Version_ID  
        WHERE hs.Version_ID =  @Version_ID  
            AND hs.ID = @Revision_ID');  
        EXEC sp_executesql @SQL, N'@Version_ID INT, @Revision_ID BIGINT, @User_ID INT',  
                                   @Version_ID,    @Revision_ID,        @User_ID;  
    END  
END
go

