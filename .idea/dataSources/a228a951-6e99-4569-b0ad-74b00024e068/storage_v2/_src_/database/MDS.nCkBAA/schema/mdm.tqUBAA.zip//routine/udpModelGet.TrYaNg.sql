/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpModelGet  
(  
     @User_ID       INT  
  
    ,@Model_MUID    UNIQUEIDENTIFIER = NULL  
    ,@Model_Name    NVARCHAR(50) = NULL  
   
    -- Only used when getting details  
  
    ,@Version_MUID      UNIQUEIDENTIFIER = NULL  
    ,@Version_Name      NVARCHAR(50) = NULL  
  
    ,@VersionFlag_MUID  UNIQUEIDENTIFIER = NULL  
    ,@VersionFlag_Name  NVARCHAR(50) = NULL  
  
    ,@Entity_MUID   UNIQUEIDENTIFIER = NULL  
    ,@Entity_Name   NVARCHAR(50) = NULL  
  
    ,@Index_MUID   UNIQUEIDENTIFIER = NULL  
    ,@Index_Name   NVARCHAR(50) = NULL  
  
    ,@MemberType_ID TINYINT = NULL  
  
    ,@AttributeGroup_MUID   UNIQUEIDENTIFIER = NULL  
    ,@AttributeGroup_Name   NVARCHAR(50) = NULL  
  
    ,@Attribute_MUID   UNIQUEIDENTIFIER = NULL  
    ,@Attribute_Name   NVARCHAR(100) = NULL  
  
    ,@ResultOption  TINYINT -- None = 0, Identifiers = 1, Details = 2.   
    ,@Debug         BIT = 0  
   
    ,@CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
  
    SET NOCOUNT ON  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': begin udpModelGet')  
  
    DECLARE   
         @ResultOption_Identifiers  TINYINT = 1  
        ,@ResultOption_Details      TINYINT = 2  
  
    -- Get model ID  
    DECLARE @Model_ID INT;  
    IF @Model_Name IS NOT NULL OR @Model_MUID IS NOT NULL  
    BEGIN  
        SELECT   
             @Model_ID = ID  
            ,@Model_MUID = MUID  
            ,@Model_Name = Name  
        FROM mdm.tblModel  
        WHERE   MUID = ISNULL(@Model_MUID, MUID)  
            AND Name = ISNULL(@Model_Name, Name)  
  
        SET @Model_ID = COALESCE(@Model_ID, 0)  
    END  
  
  
    DECLARE @SelectedModel TABLE   
    (  
         ID                 INT PRIMARY KEY  
        ,MUID               UNIQUEIDENTIFIER  
        ,Name               NVARCHAR(50)  
        ,Privilege_ID       TINYINT  
        ,AccessPermission   TINYINT  
    )  
  
    INSERT INTO @SelectedModel  
    SELECT  
         m.ID  
        ,m.MUID  
        ,m.Name  
        ,acl.Privilege_ID  
        ,acl.AccessPermission  
    FROM mdm.tblModel m  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_MODEL acl  
    ON m.ID = acl.ID  
    WHERE   acl.User_ID = @User_ID  
        AND m.MUID = ISNULL(@Model_MUID, m.MUID)  
        AND m.Name = ISNULL(@Model_Name, m.Name)  
        AND acl.Privilege_ID <> 1 -- Deny  
  
    IF (SELECT COUNT(1) FROM @SelectedModel) = 1  
    BEGIN  
        SELECT  
             @Model_MUID = MUID  
            ,@Model_Name = Name  
            ,@Model_ID = ID  
        FROM @SelectedModel  
    END ELSE  
    BEGIN  
        SELECT  
             @Model_MUID = NULL  
            ,@Model_Name = NULL  
            ,@Model_ID = NULL  
    END  
  
  
  
    SELECT  
         m.MUID AS Model_MUID  
        ,m.Name AS Model_Name  
        ,m.ID   AS Model_ID  
        ,sm.Privilege_ID  
        ,sm.AccessPermission  
  
        ,m.Description  
        ,CONVERT(SMALLINT, m.LogRetentionDays) AS LogRetentionDays  
  
        ,m.EnteredUser_DTM  
        ,m.EnteredUser_MUID  
        ,m.EnteredUser_UserName  
        ,m.EnteredUser_ID  
        ,m.LastChgUser_DTM  
        ,m.LastChgUser_MUID  
        ,m.LastChgUser_UserName  
        ,m.LastChgUser_ID  
    FROM @SelectedModel sm  
    INNER JOIN mdm.viw_SYSTEM_SCHEMA_MODEL m  
    ON sm.ID = m.ID  
    ORDER BY m.Name   
  
    IF @ResultOption = @ResultOption_Details  
    BEGIN  
        EXEC mdm.udpVersionFlagGet  
             @User_ID = @User_ID  
            ,@Model_ID = @Model_ID  
            ,@Model_MUID = @Model_MUID  
            ,@Model_Name = @Model_Name  
            ,@VersionFlag_MUID = @VersionFlag_MUID  
            ,@VersionFlag_Name = @VersionFlag_Name  
            ,@IncludeParentIdentifiers = 0 -- parent Ids already returned  
            ,@Debug = @Debug  
            ,@CorrelationID = @CorrelationID  
  
        EXEC mdm.udpVersionGet  
             @User_ID = @User_ID  
            ,@Model_ID = @Model_ID  
            ,@Model_MUID = @Model_MUID  
            ,@Model_Name = @Model_Name  
            ,@Version_MUID = @Version_MUID  
            ,@Version_Name = @Version_Name  
            ,@IncludeParentIdentifiers = 0 -- parent Ids already returned  
            ,@Debug = @Debug  
            ,@CorrelationID = @CorrelationID  
  
        DECLARE @HierarchyTable mdm.Identifier;  
        EXEC mdm.udpDerivedHierarchyGet  
             @User_ID = @User_ID  
            ,@Model_ID = @Model_ID  
            ,@Model_MUID = @Model_MUID  
            ,@Model_Name = @Model_Name  
            ,@HierarchyTable = @HierarchyTable  
            ,@ResultOption = @ResultOption_Details  
            ,@IncludeParentIdentifiers = 0 -- parent Ids already returned  
            ,@Debug = @Debug  
            ,@CorrelationID = @CorrelationID  
  
        EXEC mdm.udpEntityGet  
             @User_ID = @User_ID  
            ,@Model_MUID = @Model_MUID  
            ,@Model_Name = @Model_Name  
            ,@Model_ID = @Model_ID  
            ,@Entity_MUID = @Entity_MUID  
            ,@Entity_Name = @Entity_Name  
            ,@HierarchyTable = @HierarchyTable  
            ,@MemberType_ID = @MemberType_ID  
            ,@AttributeGroup_MUID = @AttributeGroup_MUID  
            ,@AttributeGroup_Name = @AttributeGroup_Name  
            ,@Attribute_MUID = @Attribute_MUID  
            ,@Attribute_Name = @Attribute_Name  
            ,@ResultOption = @ResultOption_Details  
            ,@IncludeParentIdentifiers = 0 -- parent Ids already returned  
            ,@Debug = @Debug  
            ,@CorrelationID = @CorrelationID  
    END   
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': end udpModelGet')  
  
    SET NOCOUNT OFF  
END --proc
go

