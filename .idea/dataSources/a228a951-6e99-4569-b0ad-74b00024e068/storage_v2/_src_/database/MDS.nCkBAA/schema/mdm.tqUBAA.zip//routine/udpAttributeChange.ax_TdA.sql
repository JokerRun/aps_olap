/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Description:  
This SProc takes an existing attribute and changes its name and/or its data type. If a datatype is changed, a new attribute is created and all  
previous attribute values are copied into it  
Example:  
declare @p16 bit  
set @p16=0  
declare @p17 bit  
set @p17=0  
exec mdm.udpAttributeChange  
@Attribute_MUID='D0D9A3BD-239F-4F18-9A71-FD40832459F1',  
@AttributeNewName=N'May15',  
@AttributeType_ID=1,  
@DisplayName=N'May15',  
@DisplayWidth=100,@DomainEntity_MUID='00000000-0000-0000-0000-000000000000',@DomainEntity_Name=default,  
@DataType_ID=1, --1 text, 2 number, 3 datetime , 6 link  
@DataTypeInformation=5,  
@InputMask_Name=N'None',@ChangeTrackingGroup=0,  
@User_ID=1  
  
This takes the attribute with MUID : D0D9A3BD-239F-4F18-9A71-FD40832459F1  
and changes its type  
*/  
CREATE PROCEDURE mdm.udpAttributeChange  
(  
    @User_ID                        INT,    
    @Attribute_MUID                 UNIQUEIDENTIFIER,    
    @AttributeNewName               NVARCHAR(100),    
    @AttributeType_ID               TINYINT,    
    @Description                    NVARCHAR(500) = NULL,    
    @DisplayName                    NVARCHAR(250) = NULL,    
    @DisplayWidth                   INT,    
    @DomainEntity_MUID              UNIQUEIDENTIFIER = NULL,    
    @DomainEntity_Name              NVARCHAR(MAX) = NULL,    
    @FilterParentAttribute_MUID     UNIQUEIDENTIFIER = NULL,    
    @FilterParentAttribute_Name     NVARCHAR(100) = NULL,    
    @FilterHierarchy_MUID           UNIQUEIDENTIFIER = NULL,    
    @FilterHierarchyName            NVARCHAR(50) = NULL,    
    @FilterHierarchyLevelNumber     INT = NULL,    
    @DataType_ID                    TINYINT = NULL,    
    @DataTypeInformation            INT = NULL,    
    @InputMask_Name                 NVARCHAR(250) = NULL,    
    @ChangeTrackingGroup            INT = 0,    
    @IsSync                         BIT = 0,    
    @Return_DeprecatedAttributeName NVARCHAR(100) = NULL OUTPUT,    
    @Return_NewAttribute_MUID       UNIQUEIDENTIFIER = NULL OUTPUT,    
    @Return_NewAttribute_ID         INT = NULL OUTPUT,    
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability    
)    
WITH EXECUTE AS 'mds_schema_user'    
AS BEGIN    
    SET NOCOUNT ON;    
    
    SET @Return_NewAttribute_MUID = NULL;    
    SET @Return_NewAttribute_ID = NULL;    
    
    -- Constants    
    -- AttributeDataType constants    
    DECLARE    
        @DataTypeText           TINYINT = 1,    
        @DataTypeNumber         TINYINT = 2,    
        @DataTypeDateTime       TINYINT = 3,    
        @DataTypeLink           TINYINT = 6,    
    
        -- AttributeType constants    
        @AttributeTypeFreeform  TINYINT = 1,    
        @AttributeTypeDomain    TINYINT = 2,    
        @AttributeTypeSystem    TINYINT = 3,    
        @AttributeTypeFile      TINYINT = 4,    
    
        -- MemberType constants    
        @MemberType_Leaf         TINYINT = 1,    
        @MemberType_Consolidated TINYINT = 2,    
        @MemberType_Collection   TINYINT = 3,    
    
        @FunctionalPrivilege_SysAdmin  TINYINT = 5,    
    
        @MaxLength_Name         INT = 100,    
        @MaxLength_DisplayName  INT = 250;    
    
    
    IF mdm.udfSecurityUserFunctionIsAllowed(@User_ID, @FunctionalPrivilege_SysAdmin) = 0    
    BEGIN    
        RAISERROR('MDSERR120002|The user does not have permission to perform this operation.', 16, 1);    
        RETURN;    
    END    
    -- Get current attribute type information    
   DECLARE    
       -- IDs of input parameters (i.e. convert attribute MUID to ID)    
        @Attribute_ID               INT,    
        @Model_ID                   INT,    
        @Model_Privilege            INT,    
        @Entity_ID                  INT,    
        @IsHierarchyEnabled         BIT = NULL,    
        @IsCollectionEnabled        BIT = NULL,    
        @DataCompression            TINYINT = NULL,    
        @TableName                  SYSNAME = NULL,    
        @StagingTableName           SYSNAME = NULL,    
        @MemberType_ID              TINYINT,    
        @DomainEntity_ID            INT,    
        @FilterParentAttribute_ID   INT = NULL,    
        @FilterHierarchyDetail_ID   INT = NULL,    
        @InputMask_ID               INT,    
        -- IDs/Names of the current values stored for the given attribute    
        @InputMask_ID_Current       INT ,    
        @DomainEntity_ID_Current    INT,    
        @FilterParentAttribute_ID_Current   INT = NULL,    
        @FilterHierarchyDetail_ID_Current   INT = NULL,    
        @AttributeType_ID_Current   TINYINT,    
        @AttributeName_Current      NVARCHAR(100),    
        @AttributeDisplayName_Current   NVARCHAR(250),    
        @Description_Current        NVARCHAR(500),    
        @DataType_ID_Current        TINYINT,    
        @DataTypeInformation_Current    INT ,    
        @DisplayName_Current        NVARCHAR(250),    
        @DisplayWidth_Current       INT ,    
        @ChangeTrackingGroup_Current    INT,    
        @LastVersion                INT,    
        @IsSystem                   BIT,    
        @IsName                     BIT,    
        @IsCode                     BIT,    
        @MembersWithErrors          XML = NULL, -- If any errors occurred, will hold the codes of the members that failed    
        @OriginalSortOrder          INT,    
        -- Booleans to figure out what kind of change we encountered    
        @HasTypeChange              BIT,    
        @HasNameChange              BIT,    
        @HasDescriptionChange       BIT,    
        @HasDisplayWidthChange      BIT,    
        @HasChangeTrackingChange    BIT,    
        @HasDisplayNameChange       BIT,    
        @HasFilterChange            BIT,    
        @TranCommitted              INT = 0, -- 0: Not committed, 1: Committed.    
        @EditMode_Create            TINYINT = 0,    
        @EditMode_Update            TINYINT = 1,    
        @EditMode_Clone             TINYINT = 4;    
    
    
    -- Get the currently stored values for the original attribute given in the parameter    
    SELECT    
        @Attribute_ID = a.ID,    
        @AttributeName_Current = a.Name,    
        @AttributeDisplayName_Current = a.DisplayName,    
        @Description_Current = a.[Description],    
        @AttributeType_ID_Current = a.AttributeType_ID,    
        @Entity_ID = e.ID,    
        @IsHierarchyEnabled = CASE WHEN e.HierarchyParentTable IS NULL THEN 0 ELSE 1 END,    
        @IsCollectionEnabled = CASE WHEN e.CollectionTable IS NULL THEN 0 ELSE 1 END,    
        @DataCompression = e.DataCompression,    
        @TableName = CASE a.MemberType_ID    
                    WHEN @MemberType_Leaf           THEN e.EntityTable    
                    WHEN @MemberType_Consolidated   THEN e.HierarchyParentTable    
                    WHEN @MemberType_Collection     THEN e.CollectionTable    
                    END, --TableName    
        @StagingTableName = CASE a.MemberType_ID    
                    WHEN @MemberType_Leaf           THEN e.StagingLeafName    
                    WHEN @MemberType_Consolidated   THEN e.StagingConsolidatedName    
                    WHEN @MemberType_Collection     THEN NULL    
                    END, -- StagingTableName    
        @Model_ID = e.Model_ID,    
        @Model_Privilege = sec.Privilege_ID,    
        @MemberType_ID = a.MemberType_ID,    
        @DataType_ID_Current = a.DataType_ID,    
        @DataTypeInformation_Current = a.DataTypeInformation,    
        @InputMask_ID_Current = a.InputMask_ID,    
        @DomainEntity_ID_Current = a.DomainEntity_ID,    
        @FilterParentAttribute_ID_Current = a.FilterParentAttribute_ID,    
        @FilterHierarchyDetail_ID_Current = a.FilterHierarchyDetail_ID,    
        @DisplayWidth_Current = a.DisplayWidth,    
        @DisplayName_Current = a.DisplayName,    
        @OriginalSortOrder = a.SortOrder,    
        @ChangeTrackingGroup_Current = a.ChangeTrackingGroup,    
        @IsSystem = a.IsSystem,    
        @IsCode = a.IsCode,    
        @IsName = a.IsName    
    FROM mdm.tblAttribute a    
    INNER JOIN mdm.tblEntity e    
    ON a.Entity_ID = e.ID    
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_MODEL sec    
    ON sec.ID = e.Model_ID    
        AND sec.User_ID = @User_ID     
        AND sec.Privilege_ID <> 1 /*Deny*/    
    WHERE a.MUID = @Attribute_MUID    
    
    --If the user is not a model admin, raise an error now    
    IF @Model_Privilege != 5 /*Admin*/    
    BEGIN    
        RAISERROR('MDSERR120003|The user does not have permission or the object ID is not valid.', 16, 1);    
        RETURN;    
    END;    
    
    SET @DisplayName = NULLIF(LTRIM(RTRIM(@DisplayName)), N'')    
    SET @DisplayName = ISNULL(@DisplayName,@DisplayName_Current)    
    
    
    -- If supplied, find the Domain Entity *ID* from the given Domain entity MUID OR the Domain entity NAME (we already know the model/entity IDs)    
    SELECT @DomainEntity_ID = ID    
    FROM mdm.tblEntity    
    WHERE (MUID = @DomainEntity_MUID)    
        OR (Model_ID = @Model_ID    
            AND Name = @DomainEntity_Name);    
    
    DECLARE @GetVersionSql NVARCHAR(MAX)    
    SET @GetVersionSql = N'    
                        SELECT @LastVersion = MAX(m.ID)    
                        FROM mdm.tblModelVersion as m where Model_ID =' + CONVERT(NVARCHAR, @Model_ID);    
    EXEC sp_executesql @GetVersionSql, N'@LastVersion INT OUTPUT ', @LastVersion OUTPUT;    
    
    -- Validate input    
    -- A valid attribute is required    
    IF @Attribute_ID IS NULL    
    BEGIN    
        RAISERROR('MDSERR200016|The attribute cannot be saved. The attribute ID is not valid.', 16, 1);    
        RETURN;    
    END;    
    
    -- We don't support System attributes    
    IF @IsSystem = 1 AND @IsCode = 0 AND @IsName = 0    
    BEGIN    
        RAISERROR('MDSERR100041|A system attribute cannot be updated.', 16, 1);    
        RETURN;    
    END;    
    
    -- Verify the entity is not a sync target.    
    IF @IsSync = 0    
    BEGIN    
        IF EXISTS(SELECT 1 FROM mdm.tblSyncRelationship WHERE TargetEntity_ID = @Entity_ID)-- This query is in a nested IF statement, rather than in the parent IF statement, for efficiency because SQL does not guarantee Boolean short circuiting.    
        BEGIN    
            RAISERROR('MDSERR200215|The attribute cannot be saved. The entity is the target of a sync relationship.', 16, 1);    
            RETURN;    
        END    
    END    
    
    -- Verify and lookup the InputMask_ID (from the InputMask_Name)    
    IF (@InputMask_Name IS NULL)    
    BEGIN    
        -- If input mask wasn't given, that is OK, continue with the ID as NULL    
        SET @InputMask_ID = NULL    
    END ELSE    
    BEGIN    
        -- If the input mask was given, make sure it exists    
        SET @InputMask_ID = ISNULL((SELECT OptionID FROM mdm.tblList WHERE ListCode = CAST(N'lstInputMask' AS NVARCHAR(50)) AND ListOption = @InputMask_Name), -1);    
    
        IF (@InputMask_ID < 0)    
        BEGIN    
            RAISERROR('MDSERR200085|The attribute cannot be saved. The input mask is not valid.', 16, 1);    
            RETURN;    
        END    
    END    
    
    
    IF @FilterParentAttribute_MUID IS NOT NULL OR NULLIF(@FilterParentAttribute_Name, N'') IS NOT NULL    
    BEGIN    
        -- Lookup attribute filter info    
    
        DECLARE @AttributeFilters mdm.AttributeFilter;    
        INSERT INTO @AttributeFilters    
        (    
             AttributeRow_ID    
            ,ParentAttribute_MUID    
            ,ParentAttributeName    
            ,Hierarchy_MUID    
            ,HierarchyName    
            ,HierarchyLevelNumber    
        )    
        VALUES    
        (    
             1    
            ,@FilterParentAttribute_MUID    
            ,@FilterParentAttribute_Name    
            ,@FilterHierarchy_MUID    
            ,@FilterHierarchyName    
            ,@FilterHierarchyLevelNumber    
        );    
    
        -- The schema of this table should match that defined in udpMetadataSave    
        CREATE TABLE #AttributesToProcess    
        (    
            Row_ID              INT NOT NULL PRIMARY KEY,    
            Model_ID            INT NULL,    
            Model_MUID          UNIQUEIDENTIFIER NULL,    
            ModelName           NVARCHAR(50) COLLATE DATABASE_DEFAULT NULL,    
            Version_ID          INT NULL,    
            Entity_ID           INT NULL,    
            Entity_MUID         UNIQUEIDENTIFIER NULL,    
            EntityName          NVARCHAR(50) COLLATE DATABASE_DEFAULT NULL,    
            IsHierarchyEnabled  BIT NULL,    
            IsCollectionEnabled BIT NULL,    
            DataCompression     TINYINT NULL,    
            TableName           SYSNAME NULL,    
            StagingTableName    SYSNAME NULL,    
            MemberType_ID       TINYINT NOT NULL,    
            ID                  INT NULL,    
            MUID                UNIQUEIDENTIFIER NULL,    
            Name                NVARCHAR(100) COLLATE DATABASE_DEFAULT NOT NULL,    
            [Description]       NVARCHAR(500) COLLATE DATABASE_DEFAULT NULL,    
            AttributeType_ID    TINYINT NULL,    
            DisplayName         NVARCHAR(250) COLLATE DATABASE_DEFAULT NULL,    
            DisplayWidth        INT NOT NULL,    
            DomainEntity_ID     INT NULL,    
            FilterParentAttribute_ID    INT NULL,    
            FilterHierarchyDetail_ID    INT NULL,    
            DataType_ID         TINYINT NULL,    
            DataTypeInformation INT NULL,    
            InputMask_ID        INT NULL,    
            ChangeTrackingGroup INT DEFAULT 0,    
            SortOrder           INT NULL,    
            DidNameChange       BIT NULL,    
            Error               NVARCHAR(MAX) COLLATE DATABASE_DEFAULT NULL    
        );    
    
        INSERT INTO #AttributesToProcess    
        (    
             Row_ID    
            ,Model_ID    
            ,Entity_ID    
            ,MemberType_ID    
            ,ID    
            ,Name    
            ,DisplayWidth    
            ,DomainEntity_ID    
        )    
        VALUES    
        (    
             1    
            ,@Model_ID    
            ,@Entity_ID    
            ,@MemberType_ID    
            ,@Attribute_ID    
            ,@AttributeNewName    
            ,@DisplayWidth    
            ,@DomainEntity_ID    
        )    
    
        EXEC mdm.udpMetadataSaveHelper_LookupAttributeFilterIds @AttributeFilters    
    
        DECLARE @Error NVARCHAR(MAX) = NULL    
    
        SELECT TOP 1    
             @FilterParentAttribute_ID = FilterParentAttribute_ID    
            ,@FilterHierarchyDetail_ID = FilterHierarchyDetail_ID    
            ,@Error = Error    
        FROM #AttributesToProcess    
    
        IF @Error IS NOT NULL    
        BEGIN    
            SET @Error = REPLACE(@Error, '%', '%%')-- escape out format specifier  
            RAISERROR(@Error, 16, 1);    
        END    
    END    
    
    --    
    -- Now that was have all the information on the current state of the attribute and the intended state,    
    -- check the type and/or the name have changed    
    SELECT @HasTypeChange =    
    CASE    
        WHEN    
        (    
        @AttributeType_ID_Current != @AttributeType_ID OR    
        @DataType_ID_Current != @DataType_ID OR    
        @DataTypeInformation_Current != @DataTypeInformation OR    
        @InputMask_ID_Current != @InputMask_ID OR    
        @DomainEntity_ID_Current != @DomainEntity_ID    
        )    
        THEN 1    
        ELSE 0    
    END    
    
    SELECT @HasFilterChange =     
    CASE WHEN    
        (    
         COALESCE(@FilterParentAttribute_ID_Current, 0) != COALESCE(@FilterParentAttribute_ID, 0) OR    
         COALESCE(@FilterHierarchyDetail_ID_Current, 0) != COALESCE(@FilterHierarchyDetail_ID, 0)    
        )    
        THEN 1    
        ELSE 0    
    END    
    
    SELECT @HasNameChange =    
    CASE    
        WHEN (@AttributeName_Current != @AttributeNewName)    
        THEN 1    
        ELSE 0    
    END    
    
    SELECT @HasDescriptionChange =    
    CASE    
        WHEN (ISNULL(@Description_Current, N'') != ISNULL(LTRIM(RTRIM(@Description)), N''))    
        THEN 1    
        ELSE 0    
    END    
    
    
    SELECT @HasDisplayNameChange =    
    CASE    
        WHEN (@DisplayName_Current != @DisplayName)    
        THEN 1    
        ELSE 0    
    END    
    
    
    SELECT @HasDisplayWidthChange =    
    CASE    
    WHEN (@DisplayWidth_Current != @DisplayWidth)    
        THEN 1    
        ELSE 0    
    END    
    
    
    SELECT @HasChangeTrackingChange =    
    CASE    
    WHEN(@ChangeTrackingGroup_Current != @ChangeTrackingGroup)    
        THEN 1    
        ELSE 0    
    END    
    
    IF (@HasNameChange = 1 OR @HasTypeChange = 1) AND ( @IsCode = 1 OR @IsName = 1 )    
    BEGIN    
        RAISERROR(N'MDSERR110019|Only Display Name can be changed for attribute Name and Code.', 16, 1);    
            RETURN;    
    END    
    
    -- Check the new attribute name, to make sure it isn't duplicate    
    IF @HasNameChange = 1    
    BEGIN    
        IF EXISTS (SELECT * FROM mdm.tblAttribute WHERE Name=@AttributeNewName AND Entity_ID=@Entity_ID AND MemberType_ID=@MemberType_ID)    
        BEGIN    
            RAISERROR(N'MDSERR110003|The name already exists. Type a different name.', 16, 1);    
            RETURN;    
        END    
    END    
    
    IF @HasDisplayNameChange = 1    
    BEGIN-- DisplayName validation    
        -- make sure it is not duplicated    
        IF EXISTS (SELECT * FROM mdm.tblAttribute WHERE DisplayName = @DisplayName AND Entity_ID=@Entity_ID AND MemberType_ID=@MemberType_ID)    
        BEGIN    
            RAISERROR(N'MDSERR110018|The display name already exists. Type a different name.', 16, 1);    
            RETURN;    
        END    
    END    
    
    --Check dependencies on this attribute: if there is any related business rule or derived hierarchy then attribute type change is not allowed.    
    IF @HasTypeChange = 1    
    BEGIN    
        BEGIN TRY    
            EXEC mdm.udpObjectDeleteCheckByMUID @Object_MUID = @Attribute_MUID, @ObjectType_ID = 7/*Attribute*/;    
        END TRY    
        BEGIN CATCH    
    
            -- Get error info.    
            DECLARE @ReturnErrorMessage NVARCHAR(4000)    
            EXEC mdm.udpGetErrorInfo @ErrorMessage = @ReturnErrorMessage OUTPUT    
    
            SET @ReturnErrorMessage =    
                CASE    
                WHEN @ReturnErrorMessage LIKE N'MDSERR200028%' THEN 'MDSERR200108|The attribute cannot be edited because it is referenced by a derived hierarchy.'    
                WHEN @ReturnErrorMessage LIKE N'MDSERR200027%' THEN 'MDSERR200109|The attribute cannot be edited because it is referenced by a business rule.'    
                ELSE @ReturnErrorMessage    
                END;    
            RAISERROR(@ReturnErrorMessage, 16, 1);    
            RETURN;    
        END CATCH    
    
        --check for user defined indexes on the attribute    
        IF @MemberType_ID = @MemberType_Leaf    
        BEGIN    
            DECLARE @UniqueIndexPrefix SYSNAME, @NonUniqueIndexPrefix SYSNAME    
            SET @UniqueIndexPrefix = CONCAT(N'uixud_', @TableName, N'_Version_ID_');    
            SET @NonUniqueIndexPrefix = CONCAT(N'ixud_', @TableName, N'_Version_ID_');    
            DECLARE @table_ID INT = OBJECT_ID(N'[mdm].' + QUOTENAME(@TableName));    
            DECLARE @cnt INT;    
            IF EXISTS(SELECT * FROM sys.indexes  WHERE object_id = @table_ID AND (name like @UniqueIndexPrefix + '%' + CAST(@Attribute_ID AS VARCHAR)  + '%') OR (name like @NonUniqueIndexPrefix + '%' + CAST(@Attribute_ID AS VARCHAR) + '%'))    
            BEGIN    
                RAISERROR('MDSERR200300|The attribute cannot be edited because it is included in at least one custom index.', 16, 1);    
                RETURN;    
            END    
        END    
    END    
    
    --    
    -- Start the process of attribute updates    
    --    
    
    IF @HasNameChange = 0 AND @HasTypeChange = 0 AND @HasFilterChange = 0 AND @HasDisplayNameChange = 0 AND @HasDescriptionChange = 0 AND @HasDisplayWidthChange = 0 AND @HasChangeTrackingChange = 0    
    BEGIN    
        -- Nothing has changed, leave    
        RETURN;    
    END;    
    
    DECLARE @TemporaryNewName NVARCHAR(100)    
    DECLARE @TemporaryNewDisplayName NVARCHAR(250)    
    
    IF @HasTypeChange = 0    
    BEGIN    
        SET @TemporaryNewName = ISNULL(@AttributeNewName,@AttributeName_Current)    
        SET @TemporaryNewDisplayName = ISNULL(@DisplayName, @AttributeDisplayName_Current)    
        SET @Return_DeprecatedAttributeName = @AttributeName_Current    
    END    
    ELSE -- There is also a change in the type    
    BEGIN    
        DECLARE @RenamingCounter INT = 0    
        DECLARE @Suffix NVARCHAR(10) = N'_old';    
        SET @TemporaryNewName = CONCAT(SUBSTRING(@AttributeName_Current, 0, @MaxLength_Name - LEN(@Suffix)), @Suffix)    
        SET @TemporaryNewDisplayName = CONCAT(SUBSTRING(@AttributeDisplayName_Current, 0, @MaxLength_DisplayName - LEN(@Suffix)), @Suffix)    
        -- Get temporary attribute name    
        WHILE (EXISTS(SELECT 1 FROM mdm.tblAttribute WHERE Name=@TemporaryNewName))    
        BEGIN    
            SET @RenamingCounter += 1    
            SET @TemporaryNewName = CONCAT(SUBSTRING(@AttributeName_Current, 0, @MaxLength_Name - LEN(@Suffix) - 4), @Suffix, @RenamingCounter)    
        END    
        -- Get temporary display name    
        SET @RenamingCounter = 0    
        WHILE (EXISTS(SELECT 1 FROM mdm.tblAttribute WHERE DisplayName=@TemporaryNewDisplayName))    
        BEGIN    
            SET @RenamingCounter += 1    
            SET @TemporaryNewDisplayName = CONCAT(SUBSTRING(@AttributeDisplayName_Current, 0, @MaxLength_DisplayName - LEN(@Suffix) - 4), @Suffix, @RenamingCounter)    
        END    
        SET @Return_DeprecatedAttributeName = @TemporaryNewName    
    END    
    
    --Start transaction, being careful to check if we are nested    
    DECLARE @TranCounter INT;    
    SET @TranCounter = @@TRANCOUNT;    
    IF @TranCounter > 0 SAVE TRANSACTION TX;    
    ELSE BEGIN TRANSACTION;    
    
    BEGIN TRY    
        --If we're changing just the description, display width, display name, or change tracking group don't make a new attribute    
        IF (@HasDescriptionChange = 1 OR @HasDisplayWidthChange = 1 OR @HasDisplayNameChange = 1 OR @HasChangeTrackingChange = 1 OR @HasFilterChange = 1) AND @HasNameChange = 0 AND @HasTypeChange = 0    
        BEGIN    
            EXECUTE  [mdm].[udpAttributeSave]    
                     @User_ID = @User_ID    
                    ,@Model_ID = @Model_ID    
                    ,@Entity_ID = @Entity_ID    
                    ,@IsHierarchyEnabled = @IsHierarchyEnabled    
                    ,@IsCollectionEnabled = @IsCollectionEnabled    
                    ,@DataCompression = @DataCompression    
                    ,@TableName = @TableName    
                    ,@StagingTableName = @StagingTableName    
                    ,@MemberType_ID = @MemberType_ID    
                    ,@Attribute_MUID = @Attribute_MUID    
                    ,@AttributeName = @AttributeName_Current    
                    ,@Description = @Description    
                    ,@DisplayName = @DisplayName    
                    ,@AttributeType_ID = @AttributeType_ID    
                    ,@DisplayWidth = @DisplayWidth    
                    ,@DomainEntity_ID = @DomainEntity_ID_Current    
                    ,@FilterParentAttribute_ID = @FilterParentAttribute_ID    
                    ,@FilterHierarchyDetail_ID = @FilterHierarchyDetail_ID    
                    ,@DataType_ID = @DataType_ID_Current    
                    ,@DataTypeInformation = @DataTypeInformation_Current    
                    ,@InputMask_ID = @InputMask_ID_Current     
                    ,@ChangeTrackingGroup = @ChangeTrackingGroup    
                    ,@SortOrder = @OriginalSortOrder    
                    ,@EditMode = @EditMode_Update    
                    ,@Return_ID = @Return_NewAttribute_ID OUTPUT    
                    ,@Return_MUID = @Return_NewAttribute_MUID OUTPUT;    
        END    
    
        -- Change the name of the attribute, preserving the sortOrder    
        IF @HasNameChange = 1    
        BEGIN    
            DECLARE @OldAttributeID INT    
            EXECUTE  [mdm].[udpAttributeSave]    
                         @User_ID = @User_ID    
                        ,@Model_ID = @Model_ID    
                        ,@Entity_ID = @Entity_ID    
                        ,@IsHierarchyEnabled = @IsHierarchyEnabled    
                        ,@IsCollectionEnabled = @IsCollectionEnabled    
                        ,@DataCompression = @DataCompression    
                        ,@TableName = @TableName    
                        ,@StagingTableName = @StagingTableName    
                        ,@MemberType_ID = @MemberType_ID    
                        ,@Attribute_MUID = @Attribute_MUID    
                        ,@AttributeName = @TemporaryNewName    
                        ,@Description = @Description    
                        ,@DisplayName = @TemporaryNewDisplayName    
                        ,@AttributeType_ID = @AttributeType_ID_Current    
                        ,@DisplayWidth = @DisplayWidth_Current    
                        ,@DomainEntity_ID = @DomainEntity_ID_Current    
                        ,@FilterParentAttribute_ID = @FilterParentAttribute_ID    
                        ,@FilterHierarchyDetail_ID = @FilterHierarchyDetail_ID    
                        ,@DataType_ID = @DataType_ID_Current    
                        ,@DataTypeInformation = @DataTypeInformation_Current    
                        ,@InputMask_ID = @InputMask_ID_Current    
                        ,@ChangeTrackingGroup = @ChangeTrackingGroup    
                        ,@SortOrder = @OriginalSortOrder    
                        ,@EditMode = @EditMode_Update    
                        ,@Return_ID = @OldAttributeID OUTPUT    
        END    
    
        IF @HasTypeChange = 1    
        BEGIN    
            --Change the name of the attribute, because it is the first phase of an attribute type change    
            EXECUTE  [mdm].[udpAttributeSave]    
                         @User_ID = @User_ID    
                        ,@Model_ID = @Model_ID    
                        ,@Entity_ID = @Entity_ID    
                        ,@IsHierarchyEnabled = @IsHierarchyEnabled    
                        ,@IsCollectionEnabled = @IsCollectionEnabled    
                        ,@DataCompression = @DataCompression    
                        ,@TableName = @TableName    
                        ,@StagingTableName = @StagingTableName    
                        ,@MemberType_ID = @MemberType_ID    
                        ,@Attribute_MUID = @Attribute_MUID    
                        ,@AttributeName = @TemporaryNewName    
                        ,@Description = @Description    
                        ,@DisplayName = @TemporaryNewDisplayName    
                        ,@AttributeType_ID = @AttributeType_ID_Current    
                        ,@DisplayWidth = @DisplayWidth_Current    
                        ,@DomainEntity_ID = @DomainEntity_ID_Current    
                        ,@FilterParentAttribute_ID = @FilterParentAttribute_ID    
                        ,@FilterHierarchyDetail_ID = @FilterHierarchyDetail_ID    
                        ,@DataType_ID = @DataType_ID_Current    
                        ,@DataTypeInformation = @DataTypeInformation_Current    
                        ,@InputMask_ID = @InputMask_ID_Current    
                        ,@ChangeTrackingGroup = @ChangeTrackingGroup    
                        ,@EditMode = @EditMode_Update    
                        ,@Return_ID = @OldAttributeID OUTPUT    
    
            -- Create the new attribute using the original attribute name, but with the new type definition    
            EXECUTE  [mdm].[udpAttributeSave]    
                         @User_ID = @User_ID    
                        ,@Model_ID = @Model_ID    
                        ,@Entity_ID = @Entity_ID    
                        ,@IsHierarchyEnabled = @IsHierarchyEnabled    
                        ,@IsCollectionEnabled = @IsCollectionEnabled    
                        ,@DataCompression = @DataCompression    
                        ,@TableName = @TableName    
                        ,@StagingTableName = @StagingTableName    
                        ,@MemberType_ID = @MemberType_ID    
                        ,@Attribute_MUID = NULL    
                        ,@AttributeName = @AttributeNewName    
                        ,@Description = @Description    
                        ,@DisplayName = @DisplayName    
                        ,@AttributeType_ID = @AttributeType_ID    
                        ,@DisplayWidth = @DisplayWidth    
                        ,@DomainEntity_ID = @DomainEntity_ID    
                        ,@FilterParentAttribute_ID = @FilterParentAttribute_ID    
                        ,@FilterHierarchyDetail_ID = @FilterHierarchyDetail_ID    
                        ,@DataType_ID = @DataType_ID    
                        ,@DataTypeInformation = @DataTypeInformation    
                        ,@InputMask_ID = @InputMask_ID    
                        ,@ChangeTrackingGroup = @ChangeTrackingGroup    
                        ,@SortOrder = @OriginalSortOrder    
                        ,@EditMode = @EditMode_Create    
                        ,@Return_ID = @Return_NewAttribute_ID OUTPUT    
                        ,@Return_MUID = @Return_NewAttribute_MUID OUTPUT;    
    
            DECLARE @SQL NVARCHAR(MAX)    
            SET @SQL = N'    
                DECLARE @AttributeValues TABLE    
                (    
                     RowID         INT IDENTITY(1, 1)    
                    ,MemberCode     NVARCHAR(250)    
                    ,MemberMUID     UNIQUEIDENTIFIER    
                    ,AttributeValue NVARCHAR(MAX)    
                )    
                INSERT INTO @AttributeValues (MemberCode, MemberMUID, AttributeValue)    
                SELECT    
                     Code    
                     ,MUID    
                    '    
    
            -- We treat a previously date time attribute differently - as we don't want to take it as is to the new one,    
            -- we first convert it to string using the input mask    
            IF ((@DataType_ID_Current = @DataTypeDateTime) AND (@AttributeType_ID_Current = @AttributeTypeFreeform))    
            BEGIN    
                -- Get the name of the current input mask (i.e. mm/dd/yyyy)    
                DECLARE @InputMask_Name_Current NVARCHAR(250) = (    
                    SELECT ListOption    
                    FROM mdm.tblList    
                    WHERE ListCode = N'lstInputMask'    
                        AND OptionID = @InputMask_ID_Current    
                        AND Group_ID = @DataType_ID_Current)    
    
                -- Convert date to string using the input mask    
                SET @SQL +=    
                    N',mdq.DateToString(' + QUOTENAME(@Return_DeprecatedAttributeName) + N', ''' +  @InputMask_Name_Current + N''')'    
            END    
            ELSE    
            BEGIN    
                -- Just trim whitespace    
                SET @SQL +=    
                    N',LTRIM(RTRIM(CONVERT(NVARCHAR(MAX),' + QUOTENAME(@Return_DeprecatedAttributeName) + N')))'    
            END    
    
            DECLARE @ViewName SYSNAME = mdm.udfViewNameGet(@Model_ID, @Entity_ID, @MemberType_ID, 0, 0);    
            SET @SQL +=  N'    
                FROM mdm.' + CONVERT(NVARCHAR(MAX), @ViewName) + N' AS m    
                WHERE    
                    m.Version_ID = @LastVersion AND    
                    ' + QUOTENAME(@Return_DeprecatedAttributeName) + N' IS NOT NULL    
                DECLARE @Members mdm.MemberSaveList;    
                INSERT INTO @Members    
                (    
                     RowID    
                    ,MemberCode    
                )    
                SELECT    
                     RowID    
                    ,MemberCode    
                FROM @AttributeValues;    
    
                DECLARE @MemberAttributes mdm.MemberAttributeValues;    
                INSERT INTO @MemberAttributes    
                (    
                     MemberRowID    
                    ,AttributeID    
                    ,AttributeValue    
                )    
                SELECT    
                     RowID    
                    ,@NewAttribute_ID    
                    ,AttributeValue    
                FROM @AttributeValues;    
    
                IF (@MemberType_ID = 2)  --Consolidated Attribute values are updating in different sproc    
                BEGIN    
                    DECLARE @MyMemberAttributes mdm.MemberAttributes;    
                    INSERT INTO @MyMemberAttributes    
                    (    
                         MemberCode    
                        ,MemberMUID    
                        ,AttributeName    
                        ,AttributeValue    
                    )    
                    SELECT    
                         MemberCode    
                        ,MemberMUID    
                        ,@NewAttributeName    
                        ,AttributeValue    
                    FROM @AttributeValues;    
                    EXEC mdm.udpEntityMembersUpdate @User_ID = @User_ID , @Version_ID = @LastVersion, @Entity_ID = @Entity_ID, @MemberType_ID = @MemberType_ID, @MemberAttributes = @MyMemberAttributes, @IgnorePriorValues = 0, @ValidateDataTypes = 1, @ShouldReturnMembersWithErrorsAsXml = 1, @Return_MembersWithErrors = @MembersWithErrors OUTPUT;    
                END    
                ELSE    
                BEGIN    
                EXEC mdm.udpEntityMembersSave    
                      @User_ID = @User_ID    
                     ,@Model_ID = @Model_ID    
                     ,@Version_ID = @LastVersion    
                     ,@Entity_ID = @Entity_ID    
                     ,@MemberType_ID = @MemberType_ID    
                     ,@Members = @Members    
                     ,@MemberAttributes = @MemberAttributes    
                     ,@SaveMode = 3 -- Update    
                     ,@LogFlag = 1    
                     ,@ValidateDataTypes = 1    
                     ,@DoInheritanceRuleCheck = 0    
                     ,@ErrorReportingType = 2 -- Put errors in XML out param    
                     ,@Errors = @MembersWithErrors OUTPUT;    
                END    
            ';    
            -- Copy the old attribute values to the new attribute. This is a best effort insertion. NULLs will be placed where it fails.    
            DECLARE @MemberAttributes            mdm.MemberAttributes    
            EXEC sp_executesql @SQL,    
                N'@User_ID INT, @LastVersion INT, @Model_ID INT, @Entity_ID INT, @MemberType_ID INT, @NewAttribute_ID INT,    @NewAttributeName NVARCHAR(MAX), @MembersWithErrors XML OUTPUT',    
                  @User_ID,     @LastVersion,     @Model_ID,     @Entity_ID,     @MemberType_ID,     @Return_NewAttribute_ID, @AttributeNewName, @MembersWithErrors OUTPUT;    
    
            -- Get all the IDs of the attribute groups the old attribute belonged to    
            DECLARE @AttributeGroups AS TABLE (    
                     RowNumber INT IDENTITY(1,1) NOT NULL,    
                     AttributeGroup_ID INT NOT NULL    
                     );    
    
            INSERT INTO @AttributeGroups(AttributeGroup_ID) SELECT AttributeGroup_ID FROM mdm.tblAttributeGroupDetail WHERE Attribute_ID=@OldAttributeID    
    
            IF EXISTS(SELECT 1 FROM @AttributeGroups)    
            BEGIN    
                DECLARE    
                    @Counter INT,    
                    @MaxCounter INT,    
                    @AttributeGroup_ID INT    
    
                SELECT    
                    @Counter=1,    
                    @MaxCounter = MAX(RowNumber)    
                FROM @AttributeGroups    
    
                --Loop through each attribute group this attribute belongs to, and associate the new attribute to it.    
                WHILE @Counter <= @MaxCounter    
                BEGIN    
                    SELECT    
                        @AttributeGroup_ID = AttributeGroup_ID    
                    FROM @AttributeGroups WHERE [RowNumber] = @Counter ;    
    
                     exec mdm.udpAttributeGroupDetailSave    
                                 @User_ID=@User_ID    
                                ,@AttributeGroup_ID=@AttributeGroup_ID    
                                ,@Attribute_ID=@Return_NewAttribute_ID    
                    SET @Counter += 1    
                END    
    
            END    
    
            -- Decide if we should delete or not the old attribute    
            -- If there are no errors on this old attribute, delete it    
            IF (@MembersWithErrors IS NULL)    
            BEGIN    
                EXEC mdm.udpAttributeDelete @Attribute_ID = @Attribute_ID, @CreateViewsInd = 1    
            END    
    
    
            IF @MembersWithErrors IS NOT NULL    
            BEGIN    
                -- Return to user all the member codes that had an error converting.    
                SELECT    
                    node.value('MemberCode[1]', 'NVARCHAR(MAX)') AS MemberCodeWithError,    
                    node.value('MemberMUID[1]', 'UNIQUEIDENTIFIER') AS MemberMuidWithError    
                FROM    
                    @MembersWithErrors.nodes('//Error') T(node)    
            END    
    
        END;    
    
        --Commit only if we are not nested    
        IF @TranCounter = 0    
        BEGIN    
            COMMIT TRANSACTION;    
            SET @TranCommitted = 1;    
        END; -- IF    
    
    END TRY    
    --Compensate as necessary    
    BEGIN CATCH    
    
        -- Get error info.    
        DECLARE    
            @ErrorMessage NVARCHAR(4000),    
            @ErrorSeverity INT,    
            @ErrorState INT,    
            @ErrorNumber INT,    
            @ErrorLine INT,    
            @ErrorProcedure NVARCHAR(126);    
        EXEC mdm.udpGetErrorInfo    
            @ErrorMessage = @ErrorMessage OUTPUT,    
            @ErrorSeverity = @ErrorSeverity OUTPUT,    
            @ErrorState = @ErrorState OUTPUT,    
            @ErrorNumber = @ErrorNumber OUTPUT,    
            @ErrorLine = @ErrorLine OUTPUT,    
            @ErrorProcedure = @ErrorProcedure OUTPUT    
    
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);    
    
        IF @TranCommitted = 0 -- Don't rollback when the transaction has been committed.    
        BEGIN    
            IF @TranCounter = 0 ROLLBACK TRANSACTION;    
            ELSE IF XACT_STATE() <> -1 ROLLBACK TRANSACTION TX;    
        END; -- IF    
    
        --Throw the error again so the calling procedure can use it    
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);    
    
        RETURN;    
    
    END CATCH;    
    
    SET NOCOUNT OFF;    
END; --proc
go

