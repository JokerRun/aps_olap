/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
--This can be called to get Annotations for a transaction OR for a member.  
  
--via Transaction  
EXEC mdm.udpAnnotationGet null,null,null,null,31  
  
--via Member Account/Version 3/Account/1110  
exec mdm.udpAnnotationGet 7,4,7,41,1,null  
  
--invalid  
EXEC mdm.udpAnnotationGet null,null,null,null,null,null  
*/  
CREATE PROCEDURE mdm.udpAnnotationGet  
(  
    @Model_ID       INT = NULL,  
    @Version_ID		INT = NULL,  
    @EntityID		INT = NULL,  
    @MemberID		INT = NULL,  
    @MemberTypeID	TINYINT = NULL,  
    @TransactionID	INT = NULL,  
    @AnnotationID	INT = NULL,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
  
    DECLARE @AnnotationType         INT, --Either 1(ByTransaction) or 2(ByMember) or 3(ByAnnotation)  
            @SQL                    NVARCHAR(MAX),  
            @AnnotationViewName     sysname,  
            @TransactionTableName   sysname,  
            -- This pseudo-constant is for use in string concatenation operations to prevent string truncation. When concatenating two or more strings,  
            -- if none of the strings is an NVARCHAR(MAX) or an NVARCHAR constant that is longer than 4,000 characters, then the resulting string   
            -- will be silently truncated to 4,000 characters. Concatenating with this empty NVARCHAR(MAX), is sufficient to prevent truncation.  
            -- See http://connect.microsoft.com/SQLServer/feedback/details/283368/nvarchar-max-concatenation-yields-silent-truncation.  
            @TruncationGuard        NVARCHAR(MAX) = N'';  
  
    --Validate Input  
    IF @Model_ID IS NULL OR (@AnnotationID IS NULL AND @TransactionID IS NULL AND (@Version_ID IS NULL OR @EntityID IS NULL OR @MemberID IS NULL OR @MemberTypeID IS NULL))  
    BEGIN  
        RAISERROR('MDSERR100010|The Parameters are not valid.', 16, 1);  
        RETURN(1);  
    END  
  
    --Get the name of the annotation and transaction objects  
    SET @AnnotationViewName = mdm.udfGetTransactionAnnotationViewName(@Model_ID);  
    SELECT @TransactionTableName = mdm.udfGetTransactionTableName(@Model_ID);  
      
    --Figure out Annotation Type  
    IF @AnnotationID IS NOT NULL  
        BEGIN  
            SET @AnnotationType = 3;  
        END  
    ELSE IF @TransactionID IS NOT NULL  
    BEGIN  
        SET @AnnotationType = 2;  
    END  
    ELSE  
    BEGIN  
        SET @AnnotationType = 1;  
    END  
  
  
    IF @AnnotationType = 1  
    BEGIN  
        SET @SQL = @TruncationGuard + N'  
        SELECT   
            A.ID  
            ,A.[Transaction ID]  
            ,A.[User Comment]  
            ,A.[Date Time]  
            ,A.[User Name]  
            ,A.[User ID]  
            ,A.User_MUID  
            ,A.LastChgDateTime  
            ,A.LastChgUserName  
            ,A.LastChgUserID  
            ,A.LastChgUserMUID  
            ,Version_ID    
            ,TransactionType_ID   
            ,OriginalTransaction_ID   
            ,Hierarchy_ID   
            ,Entity_ID     
            ,Attribute_ID   
            ,Member_ID     
            ,MemberType_ID   
            ,MemberCode                                                                                                                                                                                                                                                   
            ,OldValue                                                                                                                                                                                                                                                           
            ,OldCode                                                                                                                                                                                                                                                            
            ,NewValue                                                                                                                                                                                                                                                           
            ,NewCode                                                                                                                                                                                                                                                            
            ,Batch_ID      
            ,EnterDTM                  
            ,EnterUserID   
            ,LastChgDTM                
            ,Code                                                 
            ,Description  
        FROM [mdm].' + QUOTENAME(@AnnotationViewName) + N' A  
            INNER JOIN [mdm].' + QUOTENAME(@TransactionTableName) + N' T  
                ON T.ID = A.[Transaction ID]  
        WHERE   
            T.Version_ID = @Version_ID  
            AND T.Entity_ID = @EntityID  
            AND T.Member_ID = @MemberID  
            AND T.MemberType_ID = @MemberTypeID  
            AND T.TransactionType_ID = 6 /*MEMBER_ANNOTATE*/  
        ';  
        EXEC sp_executesql @SQL, N'@Version_ID INT, @EntityID INT, @MemberID INT, @MemberTypeID TINYINT',  
                                   @Version_ID,     @EntityID,     @MemberID,     @MemberTypeID;  
  
    END  
    ELSE IF @AnnotationType=2  
    BEGIN  
        SET @SQL = @TruncationGuard + N'  
        SELECT 			  
            ID  
            ,[Transaction ID]  
            ,[User Comment]  
            ,[Date Time]  
            ,[User Name]  
            ,[User ID]  
            ,User_MUID  
            ,LastChgDateTime  
            ,LastChgUserName  
            ,LastChgUserID  
            ,LastChgUserMUID   
            FROM [mdm].' + QUOTENAME(@AnnotationViewName) + N'  
            WHERE [Transaction ID] = @TransactionID  
        ';  
        EXEC sp_executesql @SQL, N'@TransactionID INT', @TransactionID;  
    END  
    ELSE IF @AnnotationType = 3  
    BEGIN  
        SET @SQL = @TruncationGuard + N'  
        SELECT   
        ID  
        ,[Transaction ID]  
        ,[User Comment]  
        ,[Date Time]  
        ,[User Name]  
        ,[User ID]       
        ,[User_MUID]  
        ,[LastChgDateTime]  
        ,[LastChgUserName]  
        ,[LastChgUserID]  
        ,[LastChgUserMUID]  
        FROM [mdm].' + QUOTENAME(@AnnotationViewName) + N'  
        WHERE ID = @AnnotationID;		  
        ';  
        EXEC sp_executesql @SQL, N'@AnnotationID INT', @AnnotationID;  
    END  
  
END --proc
go

