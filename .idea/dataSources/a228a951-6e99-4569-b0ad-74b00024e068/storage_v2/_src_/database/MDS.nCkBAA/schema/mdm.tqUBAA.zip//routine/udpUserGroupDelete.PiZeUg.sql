/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
mdm.udpUserGroupDelete 1,1  
select * from mdm.tblUserGroup  
*/  
CREATE PROCEDURE mdm.udpUserGroupDelete  
(  
    @SystemUser_ID  INT,  
    @UserGroup_MUID UNIQUEIDENTIFIER,  
    @SID            NVARCHAR(250) = NULL OUTPUT,  
    @CorrelationID  UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    DECLARE @GuidEmpty      UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER),  
            @UserGroup_ID   INT;  
  
    SET @UserGroup_MUID = NULLIF(@UserGroup_MUID, @GuidEmpty);  
  
    SELECT @UserGroup_ID = ID , @SID = [SID] FROM mdm.tblUserGroup WHERE MUID = @UserGroup_MUID  
    IF @UserGroup_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR500044|The group cannot be deleted. The ID is not valid.', 16, 1);  
        RETURN;  
    END  
  
    --Start transaction, being careful to check if we are nested  
    DECLARE @TranCounter INT = @@TRANCOUNT;  
    IF @TranCounter > 0   
    BEGIN  
        SAVE TRANSACTION TX;  
    END ELSE   
    BEGIN  
        BEGIN TRANSACTION;  
    END;  
  
    BEGIN TRY  
        DECLARE @PrincipalType_Group    TINYINT = 2,  
                @Status_Inactive        TINYINT = 2;  
  
        -- Save all the users we need renbuild the member security  
        DECLARE @securityMemberEvent mdm.SecurityMemberProcessEvent  
  
        INSERT @securityMemberEvent ([User_ID], [Entity_ID], Version_ID)  
        SELECT DISTINCT [User_ID], [Entity_ID], Version_ID  
        FROM [mdm].[viw_SYSTEM_SECURITY_ROLE_MEMBER] rm  
        INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ROLE ur  
        ON rm.Role_ID = ur.Role_ID  
        INNER JOIN [mdm].[tblSecurityAccessControl] sa  
        ON  rm.Role_ID = sa.Role_ID  
        WHERE PrincipalType_ID = @PrincipalType_Group  
        AND Principal_ID = @UserGroup_ID  
  
        EXEC mdm.udpSecurityPrivilegesDeleteByPrincipalID @SystemUser_ID, @UserGroup_ID, @PrincipalType_Group  
  
        UPDATE  
            tblUserGroup  
        SET  
            Status_ID = @Status_Inactive,  
            LastChgUserID = @SystemUser_ID,  
            LastChgDTM = GETUTCDATE()  
        FROM  
            mdm.tblUserGroup  
        WHERE  
            ID = @UserGroup_ID  
  
        EXEC mdm.udpUserGroupAssignmentDelete @SystemUser_ID, NULL, @UserGroup_ID, 0;  
  
        -- Queue a event to immediate recompute affected user  
        EXEC mdm.udpSecurityMemberProcessRebuildEvent @securityMemberEvent, 1;  
  
        -- Commit transaction only if not nested.  
        IF @TranCounter = 0  
        BEGIN  
            COMMIT TRANSACTION;  
        END;  
    END TRY  
    BEGIN CATCH  
  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        -- Roll back the transaction.  
        IF @TranCounter = 0 ROLLBACK TRANSACTION;  
        ELSE IF XACT_STATE() <> -1 ROLLBACK TRANSACTION TX;  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
  
    END CATCH;  
  
    SET NOCOUNT OFF  
END --proc
go

