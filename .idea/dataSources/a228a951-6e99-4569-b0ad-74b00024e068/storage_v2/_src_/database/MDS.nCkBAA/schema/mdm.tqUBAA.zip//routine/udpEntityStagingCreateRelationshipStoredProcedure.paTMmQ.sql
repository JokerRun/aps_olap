/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE [mdm].[udpEntityStagingCreateRelationshipStoredProcedure]  
(  
    @Entity_ID      INT,  
    @CorrelationID  UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE @MainSQL                        NVARCHAR(MAX) = N'',  
            @EntityTable                    SYSNAME = N'',  
            @HierarchyRelationshipTable     SYSNAME = N'',  
            @HRHistoryOutputQuery           NVARCHAR(MAX) = N'',  
            @HierarchyParentTable           SYSNAME = N'',  
            @SQLInsertTemp                  NVARCHAR(MAX) = N'',  
            @Model_ID                       INT,  
            @EntityName                     NVARCHAR(50) = N'',  
            @StagingBase                    NVARCHAR(60),  
  
            @StagingRelationshipTable       SYSNAME,  
  
            --Entity member status  
            @MemberStatus_Active            NVARCHAR(1) = N'1',  
            @MemberStatus_Deactivated       NVARCHAR(1) = N'2',  
  
            @MemberType_Hierarchy           TINYINT = 4,  
  
            -- Transaction log type constants  
            @TransactionLogType            TINYINT,  
            @TransactionLogType_Attribute  TINYINT = 1,  
            @TransactionLogType_Member     TINYINT = 2,  
            @TransactionLogType_None       TINYINT = 3,  
  
            --Transaction and annotation table names  
            @TransactionTableName          SYSNAME;  
  
    --Initialize the variables  
  
    SELECT  @EntityTable = QUOTENAME(EntityTable),  
            @HierarchyRelationshipTable = QUOTENAME(HierarchyTable),  
            @HierarchyParentTable = QUOTENAME(HierarchyParentTable),  
            @Model_ID = Model_ID,  
            @EntityName = Name,  
            @StagingBase = StagingBase,  
            @StagingRelationshipTable = QUOTENAME(IsNULL(StagingRelationshipTable, N'')),  
            @TransactionLogType = TransactionLogType  
    FROM mdm.viw_SYSTEM_SCHEMA_ENTITY  
    WHERE ID = @Entity_ID;  
  
    IF @TransactionLogType = @TransactionLogType_Member  
    BEGIN  
        SET @HRHistoryOutputQuery = mdm.udfGetHistoryOutputQuery(@Entity_ID, @MemberType_Hierarchy, N'@User_ID', N'@Now');  
    END  
    ELSE IF @TransactionLogType = @TransactionLogType_Attribute  
    BEGIN  
         --Load the transaction and annotation table names  
        SET @TransactionTableName = mdm.udfGetTransactionTableName(@Model_ID);  
    END  
  
    -- In case when the entity is a system entity (StagingBase is not specified)  
    -- simply don't create the staging SProc (don't raise an error).  
    IF COALESCE(@StagingBase, N'') = N''  
    BEGIN  
        RETURN;  
    END;  
  
    --If the Relationship staging SProc exists drop it.  
    EXEC mdm.udpEntityStagingDeleteStoredProcedures @Entity_ID, 4  
  
    SET @MainSQL = N'CREATE PROCEDURE [stg].' + QUOTENAME(N'udp_' + @StagingBase + N'_Relationship') + N'  
@VersionName NVARCHAR(50), @LogFlag INT=0, @BatchTag NVARCHAR(50)=N'''', @Batch_ID INT=NULL, @UserName NVARCHAR(100) = NULL, @User_ID INT = 0  
WITH EXECUTE AS ''mds_schema_user''  
AS  
BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE @Model_ID                   INT,  
            @Entity_ID                  INT,  
            @Hierarchy_ID               INT,  
            @TargetType_ID              INT,  
            @Meta_ID                    INT,  
            @Hierarchy_IsMandatory      INT,  
            @MaxSortOrderRelationship   INT,  
            @MaxSortOrderStaging        INT,  
            @Version_ID                 INT,  
            @HierarchyParent_ID         INT,  
            @IsMandatory                BIT,  
            @VersionStatus_ID           INT,  
            @VersionStatus_Committed    INT = 3,  
            @Now                        DATETIME2,  
  
            @MemberCount                INT = 0,  
            @ErrorCount                 INT = 0,  
            @NewBatch_ID                INT = 0,  
            @GetNewBatch_ID             INT = 0,  
  
            -- member type constants  
            @LeafMemberTypeID           INT = 1,  
            @ConsolidatedMemberTypeID   INT = 2,  
            @HierarchyMemberTypeID      INT = 4,  
  
            -- staging datastatus constants  
            @StatusDefault              INT = 0,  
            @StatusOK                   INT = 1,  
            @StatusError                INT = 2,  
            @StatusProcessing           INT = 3,  
  
            -- error return code constants  
            @UserIDError                INT = 1,  
            @VersionNameError           INT = 3,  
            @UserPermissionError        INT = 4,  
            @VersionStatusError         INT = 5,  
            @NoRecordToProcessError     INT = 6,  
            @BatchIDAndBatchTagSpecifiedError   INT = 7,  
            @BatchStatusError           INT = 8,  
            @OtherRuntimeError          INT = 9,  
            '  
    SET @MainSQL = @MainSQL + N'  
            -- bacth status constants  
            @QueuedToRun                INT = 1,  
            @NotRunning                 INT = 2,  
            @Running                    INT = 3,  
            @QueueToClear               INT = 4,  
            @Cleared                    INT = 5,  
            @AllExceptCleared           INT = 6,  
            @Completed                  INT = 7,  
  
            -- GetNewBatch_ID constants  
            @BatchIDFound               INT = 0,  
            @BatchIDNotFound            INT = 1,  
            @BatchIDForBatchTagNotFound INT = 2,  
  
            --Import Type Constans  
            @IT_MergeOptimistic         INT = 0,  
            @IT_Insert                  INT = 1,  
            @IT_MergeOverwrite          INT = 2,  
            @IT_Delete                  INT = 3,  
            @IT_Purge                   INT = 4,  
            @IT_Max                     INT = 4,  
  
            --Validation status  
            @NewAwaitingValidation      INT = 0,  
            @AwaitingRevalidation       INT = 4,  
  
            --XACT_STATE() constancts  
            @UncommittableTransaction   INT = -1,  
            @MemberStatus_Deactivated   INT = 2  
            ;  
  
            DECLARE @tblMeta TABLE  
            (  
                ID                      INT IDENTITY (1, 1) NOT NULL,  
                Hierarchy_ID            INT,  
                Hierarchy_IsMandatory   BIT,  
                TargetType_ID           INT  
            );  
  
            DECLARE @tblHierarchy TABLE  
            (  
                Hierarchy_ID            INT  
            );  
  
            DECLARE @tblDuplicatedCodeInHierarchy TABLE  
            (  
                ChildCode               NVARCHAR(250) COLLATE DATABASE_DEFAULT,  
                HierarchyName           NVARCHAR(250) COLLATE DATABASE_DEFAULT  
            );  
  
    SET @Model_ID = ' + CONVERT(NVARCHAR(25),@Model_ID) + N'  
    SET @Entity_ID = ' + CONVERT(NVARCHAR(25),@Entity_ID);  
  
    SET @MainSQL = @MainSQL + N'  
  
    -- @UserName overwrites @User_ID  
    IF @UserName IS NOT NULL  
    BEGIN  
        SET @User_ID = mdm.udfUserIDGetByUserName(@UserName)  
        IF @User_ID IS NULL  
        BEGIN  
            RAISERROR(''MDSERR500041|The UserName is unknown.'', 16, 1);  
            RETURN @UserIDError;  
        END  
    END  
  
    -- Check for invalid Version Name.  
    IF @VersionName IS NULL RETURN @VersionNameError;  
  
    IF LEN(@BatchTag) > 0 AND @Batch_ID IS NOT NULL BEGIN  
        RAISERROR(''MDSERR310043|The Batch Tag and the Batch ID cannot be specified at the same time.'', 16, 1);  
        RETURN @BatchIDAndBatchTagSpecifiedError;  
    END; --IF  
  
    SELECT @Version_ID = ID, @VersionStatus_ID = Status_ID FROM mdm.tblModelVersion WHERE Model_ID = @Model_ID AND [Name] = @VersionName;  
  
    IF @Version_ID IS NULL BEGIN  
        RAISERROR(''MDSERR100036|The version name is not valid.'', 16, 1);  
        RETURN @VersionNameError;  
    END; --IF  
  
     --Ensure that Version is not committed  
    IF (@VersionStatus_ID = @VersionStatus_Committed) BEGIN  
        RAISERROR(''MDSERR310040|Data cannot be loaded into a committed version.'', 16, 1);  
        RETURN @VersionStatusError;  
    END;  
  
    --Check if there is any record to process.  
    IF LEN(@BatchTag) > 0 BEGIN  
        SELECT @MemberCount = COUNT(ID) FROM [stg].' + @StagingRelationshipTable + N'  
            WHERE BatchTag = @BatchTag AND ImportStatus_ID = @StatusDefault;  
        IF @MemberCount = 0 BEGIN  
            RETURN @NoRecordToProcessError;  
        END; -- IF  
    END; -- IF  
    ELSE BEGIN  
        IF @Batch_ID IS NOT NULL BEGIN  
            SELECT @MemberCount = COUNT(ID) FROM [stg].' + @StagingRelationshipTable + N'  
                WHERE Batch_ID = @Batch_ID AND ImportStatus_ID = @StatusDefault;  
            IF @MemberCount = 0 BEGIN  
                RETURN @NoRecordToProcessError;  
            END; -- IF  
        END; -- IF  
    END; -- IF  
  
    -- If neither @BatchTag nor @Batch_ID is specified assume that a blank @BatchTag is specified.  
  
    IF @Batch_ID IS NULL AND LEN(@BatchTag) = 0 BEGIN  
        SELECT @MemberCount = COUNT(ID) FROM [stg].' + @StagingRelationshipTable + N'  
            WHERE (BatchTag IS NULL OR BatchTag = N'''') AND ImportStatus_ID = @StatusDefault;  
        IF @MemberCount = 0 BEGIN  
            RETURN @NoRecordToProcessError;  
        END; -- IF  
    END; -- IF  
  
    --Check if there is any record with an invalid status.  
    IF LEN(@BatchTag) > 0 BEGIN  
        IF EXISTS (SELECT stgr.ID FROM [stg].' + @StagingRelationshipTable + N' stgr  
            INNER JOIN mdm.tblStgBatch stgb  
            ON stgr.BatchTag = stgb.BatchTag AND stgb.Status_ID = @Running  
            WHERE stgr.BatchTag = @BatchTag AND stgr.ImportStatus_ID = @StatusDefault) BEGIN  
  
            RAISERROR(''MDSERR310029|The status of the specified batch is not valid.'', 16, 1);  
            RETURN @BatchStatusError;  
        END; -- IF  
    END; -- IF  
  
    IF @Batch_ID IS NOT NULL  BEGIN  
        IF EXISTS (SELECT stgr.ID FROM [stg].' + @StagingRelationshipTable + N' stgr  
            INNER JOIN mdm.tblStgBatch stgb  
            ON stgr.Batch_ID = stgb.ID AND stgb.Status_ID IN (@Running, @QueueToClear, @Cleared)  
            WHERE stgr.Batch_ID = @Batch_ID AND stgr.ImportStatus_ID = @StatusDefault) BEGIN  
  
            RAISERROR(''MDSERR310029|The status of the specified batch is not valid.'', 16, 1);  
            RETURN @BatchStatusError;  
        END; -- IF  
    END; -- IF  
  
    --Start transaction, being careful to check if we are nested  
    DECLARE @TranCounter INT;  
    SET @TranCounter = @@TRANCOUNT;  
    IF @TranCounter > 0 SAVE TRANSACTION TX;  
    ELSE BEGIN TRANSACTION;  
  
    BEGIN TRY  
  
        --Create relationship staging temporary table  
        CREATE TABLE #tblStage  
        (  
            ID                    BIGINT IDENTITY (1, 1) NOT NULL,  
            Stage_ID            INT NOT NULL,  
            Relationship_ID        INT NOT NULL DEFAULT -1,    --ID from the hierarchy relationship table  
            Member_ID            INT NOT NULL,  
            Member_MUID          UNIQUEIDENTIFIER NULL,  
            Member_Code            NVARCHAR(250) COLLATE database_default NOT NULL,  
            ChildType_ID        INT NOT NULL DEFAULT 0,        --Source member type: 1=EN and 2=HP  
            MemberStatus_ID        TINYINT NOT NULL DEFAULT 1,    --Defaults to active  
            TargetType_ID        INT NOT NULL,                --Type of relationship: 1=parent; 2=sibling (move behind sibling)  
            Target_ID            INT NULL,  
            Target_Code            NVARCHAR(250) COLLATE database_default NULL,  
            TargetMemberType_ID    INT NOT NULL DEFAULT 0,        --Target member type: 1=leaf member, 2=consolidated member, 3=collection (derived)  
            TargetStatus_ID        TINYINT NOT NULL DEFAULT 1,    --Defaults to active  
            SortOrder            INT NOT NULL DEFAULT 0,  
            PrevTarget_ID        INT NULL,                    --For transaction logging  
            PrevTarget_Code        NVARCHAR(250) COLLATE database_default, --For transaction logging  
            Status_ID            INT NOT NULL DEFAULT 1,  
            Status_ErrorCode    NVARCHAR(10) COLLATE database_default NOT NULL DEFAULT N''210000''  
        );  
  
        --Create relationship temporary table - contains the list of new relationships  
        CREATE TABLE #tblRelation  
        (  
            ID                BIGINT IDENTITY (1, 1) NOT NULL,  
            Version_ID        INT NOT NULL,  
            Status_ID        INT NOT NULL DEFAULT 1,  
            Hierarchy_ID    INT NULL,  
            Parent_ID        INT NULL DEFAULT -2,  
            Child_ID        INT NOT NULL DEFAULT -2,  
            ChildType_ID    INT NOT NULL DEFAULT 0,  
            SortOrder        INT NOT NULL DEFAULT 0,  
            LevelNumber        SMALLINT NOT NULL DEFAULT (-1)  
        );  
  
        IF @Batch_ID IS NOT NULL  BEGIN  
            IF NOT EXISTS (SELECT ID FROM mdm.tblStgBatch WHERE ID = @Batch_ID AND Status_ID NOT IN (@Running, @QueueToClear, @Cleared)  
                AND Version_ID = @Version_ID AND Entity_ID = @Entity_ID AND MemberType_ID = @HierarchyMemberTypeID) BEGIN  
                SET @GetNewBatch_ID = @BatchIDNotFound  
            END; --IF  
        END; --IF  
        ELSE BEGIN  
        -- Check if udpEntityStagingFlagForProcessing already assigned a new batch ID (in this case the status is QueuedToRun).  
            SELECT TOP 1 @Batch_ID = ID FROM mdm.tblStgBatch  
                WHERE BatchTag = @BatchTag AND Status_ID = @QueuedToRun  
                AND Version_ID = @Version_ID AND Entity_ID = @Entity_ID AND MemberType_ID = @HierarchyMemberTypeID ORDER BY ID DESC  
  
            IF @Batch_ID IS NULL BEGIN  
                SET @GetNewBatch_ID = @BatchIDForBatchTagNotFound  
            END; --IF  
            ELSE BEGIN  
            -- Set the member count  
                UPDATE mdm.tblStgBatch  
                SET TotalMemberCount = @MemberCount  
                WHERE BatchTag = @BatchTag AND Status_ID = @QueuedToRun  
                            AND Version_ID = @Version_ID AND Entity_ID = @Entity_ID AND MemberType_ID = @HierarchyMemberTypeID  
            END; --IF  
        END; --IF  
  
  
        IF @GetNewBatch_ID IN (@BatchIDNotFound, @BatchIDForBatchTagNotFound) BEGIN  
        -- Create a new batch ID.  
            INSERT INTO mdm.tblStgBatch  
            (MUID  
            ,Version_ID  
            ,Status_ID  
            ,BatchTag  
            ,Entity_ID  
            ,MemberType_ID  
            ,TotalMemberCount  
            ,ErrorMemberCount  
            ,TotalMemberAttributeCount  
            ,ErrorMemberAttributeCount  
            ,TotalMemberRelationshipCount  
            ,ErrorMemberRelationshipCount  
            ,LastRunStartDTM  
            ,LastRunStartUserID  
            ,LastRunEndDTM  
            ,LastRunEndUserID  
            ,LastClearedDTM  
            ,LastClearedUserID  
            ,EnterDTM  
            ,EnterUserID)  
            SELECT  
                NEWID(),  
                @Version_ID,  
                @Running,  
                @BatchTag,  
                @Entity_ID,  
                @HierarchyMemberTypeID,  
                @MemberCount,  
                NULL,  
                NULL,  
                NULL,  
                NULL,  
                NULL,  
                GETUTCDATE(),  
                @User_ID,  
                NULL,  
                NULL,  
                NULL,  
                NULL,  
                GETUTCDATE(),  
                @User_ID  
  
            SELECT @NewBatch_ID = SCOPE_IDENTITY();  
  
            -- Update batch ID.  
  
            IF @GetNewBatch_ID = @BatchIDNotFound BEGIN  
                UPDATE [stg].' + @StagingRelationshipTable + N'  
                SET Batch_ID = @NewBatch_ID  
                WHERE Batch_ID = @Batch_ID AND ImportStatus_ID = @StatusDefault  
            END; --IF  
            ELSE BEGIN  
                UPDATE [stg].' + @StagingRelationshipTable + N'  
                SET Batch_ID = @NewBatch_ID  
                WHERE BatchTag = @BatchTag AND ImportStatus_ID = @StatusDefault  
            END; --IF  
  
            SET @Batch_ID = @NewBatch_ID;  
        END; --IF  
        ELSE BEGIN  
            -- Set the status of the batch as Running.  
            UPDATE mdm.tblStgBatch  
                SET Status_ID = @Running,  
                    TotalMemberCount = @MemberCount,  
                    LastRunStartDTM = GETUTCDATE(),  
                    LastRunStartUserID = @User_ID  
                WHERE ID = @Batch_ID  
        END; --  
    '  
  
    SET @MainSQL = @MainSQL + N'  
        --Error Check all staged members  
  
        --Error 300002 Binary Location 2^8: Child Code does not exist in Entity Table nor Parent Table.  
        UPDATE [stg].' + @StagingRelationshipTable + N'  
            SET ErrorCode = ErrorCode | 256  
            WHERE ChildCode NOT IN  
                (SELECT DISTINCT stgr.ChildCode FROM [stg].' + @StagingRelationshipTable + N' stgr  
                INNER JOIN mdm.' + @EntityTable + N' en ON stgr.ChildCode = en.Code AND en.Status_ID = ' + @MemberStatus_Active/*DO NOT replace this hardcoded value with a var. It would be bad for perf*/ + N' /*Active*/  
                WHERE en.Version_ID = @Version_ID)  
                AND ChildCode NOT IN  
                (SELECT DISTINCT stgr.ChildCode FROM [stg].' + @StagingRelationshipTable + N' stgr  
                 INNER JOIN mdm.' + @HierarchyParentTable + N' hp  
                    ON      stgr.ChildCode = hp.Code  
                        AND hp.Status_ID = ' + @MemberStatus_Active/*DO NOT replace this hardcoded value with a var. It would be bad for perf*/ + N' -- Active  
                 INNER JOIN mdm.tblHierarchy h -- join with the hierarchy table to validate the hierarchy name  
                    ON      stgr.HierarchyName = h.Name  
                        AND hp.Hierarchy_ID = h.ID  
                 WHERE  
                        hp.Version_ID = @Version_ID  
                    AND h.Entity_ID = @Entity_ID  
                )  
                AND ImportStatus_ID = @StatusDefault AND Batch_ID = @Batch_ID;  
  
        --Error 300002 Binary Location 2^8: Parent Code does not exist in Parent Table when RelationshipType is 1 (parent).  
        UPDATE [stg].' + @StagingRelationshipTable + N'  
            SET ErrorCode = ErrorCode | 256  
            WHERE ParentCode <> N''ROOT'' AND ParentCode NOT IN  
                (SELECT DISTINCT stgr.ParentCode FROM [stg].' + @StagingRelationshipTable + N' stgr  
                 INNER JOIN mdm.' + @HierarchyParentTable + N' hp  
                    ON      stgr.ParentCode = hp.Code  
                        AND hp.Status_ID = ' + @MemberStatus_Active/*DO NOT replace this hardcoded value with a var. It would be bad for perf*/ + N' -- Active  
                 INNER JOIN mdm.tblHierarchy h -- join with the hierarchy table to validate the hierarchy name  
                    ON      stgr.HierarchyName = h.Name  
                        AND hp.Hierarchy_ID = h.ID  
                 WHERE  
                        hp.Version_ID = @Version_ID  
                    AND h.Entity_ID = @Entity_ID  
                )  
                AND ImportStatus_ID = @StatusDefault AND Batch_ID = @Batch_ID AND RelationshipType = 1;  
  
        --Error 210011 Binary Location 2^11: When RelationshipType is 1 (parent) the ParentCode cannot be a leaf member.  
        UPDATE [stg].' + @StagingRelationshipTable + N'  
            SET ErrorCode = ErrorCode | 2048  
            WHERE ParentCode IN  
                (SELECT DISTINCT stgr.ParentCode FROM [stg].' + @StagingRelationshipTable + N' stgr  
                INNER JOIN mdm.' + @EntityTable + N' en ON stgr.ParentCode = en.Code AND en.Status_ID = ' + @MemberStatus_Active/*DO NOT replace this hardcoded value with a var. It would be bad for perf*/ + N'/*Active*/  
                WHERE en.Version_ID = @Version_ID)  
                AND ImportStatus_ID = @StatusDefault AND Batch_ID = @Batch_ID AND RelationshipType = 1;  
  
        --Error 210015 Binary Location 2^12: The MemberCode exists multiple times in the staging table for a hierarchy and a batch.  
        INSERT INTO @tblDuplicatedCodeInHierarchy (ChildCode, HierarchyName)  
        SELECT ChildCode, HierarchyName  
            FROM [stg].' + @StagingRelationshipTable + N'  
            WHERE ImportStatus_ID = @StatusDefault AND Batch_ID = @Batch_ID  
            GROUP BY ChildCode, HierarchyName having COUNT(*) > 1;  
  
        UPDATE stgr  
            SET ErrorCode = ErrorCode | 4096  
            FROM [stg].' + @StagingRelationshipTable + N' stgr  
            INNER JOIN @tblDuplicatedCodeInHierarchy dup  
            ON stgr.ChildCode = dup.ChildCode  
            AND stgr.HierarchyName = dup.HierarchyName  
            WHERE stgr.ImportStatus_ID = @StatusDefault AND stgr.Batch_ID = @Batch_ID;  
  
        --Error 210032 Binary Location 2^4: The HierarchyName is missing or invalid.  
        UPDATE [stg].' + @StagingRelationshipTable + N'  
            SET ErrorCode = ErrorCode | 16  
            Where LEN(COALESCE(HierarchyName, N'''')) = 0  
                AND ImportStatus_ID = @StatusDefault AND Batch_ID = @Batch_ID;  
  
        UPDATE [stg].' + @StagingRelationshipTable + N'  
            SET ErrorCode = ErrorCode | 16  
            WHERE LEN(COALESCE(HierarchyName, N'''')) > 0 AND HierarchyName NOT IN  
                (SELECT DISTINCT [Name] FROM mdm.tblHierarchy  
                WHERE Entity_ID = @Entity_ID)  
                AND ImportStatus_ID = @StatusDefault AND Batch_ID = @Batch_ID;  
  
        --Error 210035 Binary Location 2^5: Child Code is required.  
        UPDATE [stg].' + @StagingRelationshipTable + N'  
            SET ErrorCode = ErrorCode | 32  
            WHERE LEN(COALESCE(ChildCode, N'''')) = 0  
                AND ImportStatus_ID = @StatusDefault AND Batch_ID = @Batch_ID;  
  
        --Error 210041 Binary Location 2^6: ROOT is not a valid Child Code  
        UPDATE [stg].' + @StagingRelationshipTable + N'  
            SET ErrorCode = ErrorCode | 64  
            WHERE ChildCode = N''ROOT'' AND ImportStatus_ID = @StatusDefault AND Batch_ID = @Batch_ID;  
  
        --Error 210042 Binary Location 2^7: MDMUnused is not a valid Child Code  
        UPDATE [stg].' + @StagingRelationshipTable + N'  
            SET ErrorCode = ErrorCode | 128  
            WHERE ChildCode = ''MDMUnused'' AND ImportStatus_ID = @StatusDefault AND Batch_ID = @Batch_ID;  
  
        --Error 210043 Binary Location 2^14: The RelationshipType must be 1 (parent) or 2 (sibling)  
        UPDATE [stg].' + @StagingRelationshipTable + N'  
            SET ErrorCode = ErrorCode | 16384  
            WHERE RelationshipType <> 1 AND RelationshipType <> 2 AND ImportStatus_ID = @StatusDefault AND Batch_ID = @Batch_ID;  
  
        --Error 210035 Binary Location 2^5: Parent Code is required.  
        UPDATE [stg].' + @StagingRelationshipTable + N'  
            SET ErrorCode = ErrorCode | 32  
            WHERE LEN(COALESCE(ParentCode, N'''')) = 0 AND ImportStatus_ID = @StatusDefault AND Batch_ID = @Batch_ID;  
  
        --Error 210046 Binary Location 2^15: The member cannot be a sibling of ROOT.  
        UPDATE [stg].' + @StagingRelationshipTable + N'  
            SET ErrorCode = ErrorCode | 32768  
            WHERE ParentCode = N''ROOT'' AND RelationshipType = 2 AND ImportStatus_ID = @StatusDefault AND Batch_ID = @Batch_ID;  
  
        --Error 210047 Binary Location 2^16: The member cannot be a sibling of Unused.  
        UPDATE [stg].' + @StagingRelationshipTable + N'  
            SET ErrorCode = ErrorCode | 65536  
            WHERE ParentCode = ''MDMUnused'' AND RelationshipType = 2 AND ImportStatus_ID = @StatusDefault AND Batch_ID = @Batch_ID;  
  
        --Error 210048 Binary Location 2^17: Parent Code and Child Code cannot be the same.  
        UPDATE [stg].' + @StagingRelationshipTable + N'  
            SET ErrorCode = ErrorCode | 131072  
            WHERE Upper(ParentCode) = Upper(ChildCode) AND ImportStatus_ID = @StatusDefault AND Batch_ID = @Batch_ID;'  
  
    SET @MainSQL = @MainSQL + N'  
        --Set ImportStatus on all records with at least one error  
        UPDATE [stg].' + @StagingRelationshipTable + N'  
            SET ImportStatus_ID = @StatusError  
            WHERE ErrorCode > 0 AND ImportStatus_ID = @StatusDefault AND Batch_ID = @Batch_ID;  
  
        --Process Insert all new error free records into MDS internal table  
        UPDATE [stg].' + @StagingRelationshipTable + N'  
            SET ImportStatus_ID = @StatusProcessing  
            WHERE ImportStatus_ID = @StatusDefault AND Batch_ID = @Batch_ID;  
  
  
        --Identify entities and hierarchies (for recalculating level numbers and sort orders)  
        INSERT INTO @tblHierarchy  
        SELECT DISTINCT hr.ID  
        FROM [stg].' + @StagingRelationshipTable + N' stgr  
        LEFT OUTER JOIN mdm.tblHierarchy hr ON stgr.HierarchyName = hr.Name AND hr.Entity_ID = @Entity_ID  
        WHERE hr.ID IS NOT NULL AND hr.ID > 0  
        AND stgr.ImportStatus_ID = @StatusProcessing AND stgr.Batch_ID = @Batch_ID;  
  
        --Identify entities and hierarchies  
        INSERT INTO @tblMeta  
        (  
            Hierarchy_ID, Hierarchy_IsMandatory, TargetType_ID  
        )  
        SELECT DISTINCT  
            hr.ID,  
            hr.IsMandatory,  
            stgr.RelationshipType  
        FROM [stg].' + @StagingRelationshipTable + N' stgr  
        INNER JOIN mdm.tblHierarchy hr  
        ON stgr.HierarchyName = hr.Name AND hr.Entity_ID = @Entity_ID  
        WHERE hr.ID IS NOT NULL AND hr.ID > 0  
        AND stgr.ImportStatus_ID = @StatusProcessing AND stgr.Batch_ID = @Batch_ID;  
  
        --Iterate through the meta table  
        WHILE EXISTS(SELECT 1 FROM @tblMeta) BEGIN  
  
            SELECT TOP 1  
                @Meta_ID = ID,  
                @Hierarchy_ID = Hierarchy_ID,  
                @Hierarchy_IsMandatory = Hierarchy_IsMandatory,  
                @TargetType_ID = TargetType_ID  
            FROM @tblMeta;  
    '  
    SET @MainSQL = @MainSQL + N'  
            --Populate temporary staging table  
            INSERT INTO #tblStage  
            (  
                Stage_ID, Member_ID, Member_Code, TargetType_ID, Target_ID, Target_Code, SortOrder  
            )  
            SELECT  
                stgr.ID,  
                -2,  
                stgr.ChildCode,  
                stgr.RelationshipType,  
                CASE  
                    WHEN stgr.ParentCode = N''ROOT'' THEN 0  
                    WHEN stgr.ParentCode = N''MDMUNUSED'' AND hr.IsMandatory = 0 THEN -1  
                    ELSE -2  
                END,  
                stgr.ParentCode,  
                CASE  
                    WHEN stgr.SortOrder IS NULL THEN 0  
                    ELSE stgr.SortOrder  
                END  
            FROM [stg].' + @StagingRelationshipTable + N' stgr  
            INNER JOIN mdm.tblHierarchy hr  
            ON stgr.HierarchyName = hr.Name AND hr.Entity_ID = @Entity_ID  
            WHERE  
                hr.ID = @Hierarchy_ID  
                AND stgr.RelationshipType = @TargetType_ID  
                AND stgr.ImportStatus_ID = @StatusProcessing  
                AND stgr.Batch_ID = @Batch_ID  
            ORDER BY  
                stgr.ID DESC; --To accommodate multiple moves for the same member load the most recent data first.  
            /*  
            ------------------------  
            FETCH SOURCE MEMBER DATA  
            ------------------------  
            */  
  
            --Update temporary table with Member_ID, Member_MUID, MemberStatus_ID, and ChildType_ID = 1 (EN)  
            UPDATE tStage SET  
                Member_ID = tSource.ID,  
                Member_MUID = tSource.MUID,  
                MemberStatus_ID = tSource.Status_ID,  
                ChildType_ID = 1 -- Leaf  
            FROM #tblStage AS tStage  
            INNER JOIN mdm.' + @EntityTable + N' AS tSource  
                ON tStage.Member_Code = tSource.Code  
            WHERE tSource.Version_ID = @Version_ID;  
  
            --Update temporary table with Member_ID, Member_MUID, MemberStatus_ID, and ChildType_ID = 2 (HP)  
            UPDATE tStage SET  
                Member_ID = tSource.ID,  
                Member_MUID = tSource.MUID,  
                MemberStatus_ID = tSource.Status_ID,  
                ChildType_ID = 2 -- Parent  
            FROM #tblStage AS tStage  
            INNER JOIN mdm.' + @HierarchyParentTable + N' AS tSource  
                ON tStage.Member_Code = tSource.Code  
            WHERE tSource.Version_ID = @Version_ID  
            AND tSource.Hierarchy_ID = @Hierarchy_ID;  
  
            --Delete soft-deleted records for children that need to be staged  
            --We would rather insert new records than ressurect existing ones to  
            --avoid issues with SortOrder  
            --Leaf members  
            DELETE FROM mdm.' + @HierarchyRelationshipTable + N'  
            WHERE Hierarchy_ID = @Hierarchy_ID AND  
                  Version_ID = @Version_ID AND  
                  Status_ID = @MemberStatus_Deactivated AND  
                  Child_EN_ID IN (SELECT Member_ID FROM #tblStage WHERE ChildType_ID = @LeafMemberTypeID);  
  
            --Consolidated members  
            DELETE FROM mdm.' + @HierarchyRelationshipTable + N'  
            WHERE Hierarchy_ID = @Hierarchy_ID AND  
                  Version_ID = @Version_ID AND  
                  Status_ID = @MemberStatus_Deactivated AND  
                  Child_EN_ID IN (SELECT Member_ID FROM #tblStage WHERE ChildType_ID = @ConsolidatedMemberTypeID);  
    '  
    SET @MainSQL = @MainSQL + N'  
            /*  
            ------------------------  
            FETCH TARGET MEMBER DATA  
            ------------------------  
            */  
  
            --Process hierarchy; target may be a leaf (if a sibling) or a consolidation  
  
            --Update temporary table with Target_ID, TargetStatus_ID, and TargetMemberType_ID = 1 (leaf)  
            UPDATE tStage SET  
                Target_ID = tSource.ID,  
                TargetStatus_ID = tSource.Status_ID,  
                TargetMemberType_ID = 1  
            FROM #tblStage AS tStage  
            INNER JOIN mdm.' + @EntityTable + N' AS tSource  
                ON tStage.Target_Code = tSource.Code  
            WHERE tSource.Version_ID = @Version_ID;  
  
            --Update temporary table with Target_ID, TargetStatus_ID, and TargetMemberType_ID = 2 (consolidated)  
            UPDATE tStage SET  
                Target_ID = tSource.ID,  
                TargetStatus_ID = tSource.Status_ID,  
                TargetMemberType_ID = 2  
            FROM #tblStage AS tStage  
            INNER JOIN mdm.' + @HierarchyParentTable + N' AS tSource  
                ON tStage.Target_Code = tSource.Code  
            WHERE tSource.Version_ID = @Version_ID  
                AND tSource.Hierarchy_ID = @Hierarchy_ID;  
  
            --If the target is a sibling (@TargetType_ID is 2) then reassign the target ID (fetch the parent ID of the target) and assign the sort order of the sibling  
            IF @TargetType_ID = 2 BEGIN  
  
                UPDATE tStage SET  
                     Target_ID = tRel.Parent_HP_ID  
                    ,SortOrder = tRel.SortOrder  
                FROM #tblStage AS tStage  
                INNER JOIN mdm.' + @HierarchyRelationshipTable + N' AS tRel  
                    ON tStage.TargetMemberType_ID = tRel.ChildType_ID  
                    AND tStage.Target_ID = CASE tStage.TargetMemberType_ID  
                        WHEN 1 THEN tRel.Child_EN_ID -- Leaf  
                        WHEN 2 THEN tRel.Child_HP_ID -- Consolidated  
                    END --case  
                WHERE tRel.Version_ID = @Version_ID  
                    AND tRel.Hierarchy_ID = @Hierarchy_ID;  
  
            END; --if  
    '  
    SET @MainSQL = @MainSQL + N'  
            --EN  
            UPDATE tStage SET  
                Relationship_ID = tSource.ID  
            FROM #tblStage AS tStage  
            INNER JOIN mdm.' + @HierarchyRelationshipTable + N' AS tSource  
                ON tStage.ChildType_ID = tSource.ChildType_ID  
                AND tStage.Member_ID = tSource.Child_EN_ID  
            WHERE tSource.Version_ID = @Version_ID  
                AND tStage.ChildType_ID = 1 -- Leaf  
                AND tSource.Hierarchy_ID = @Hierarchy_ID;  
  
            --HP  
            UPDATE tStage SET  
                Relationship_ID = tSource.ID  
            FROM #tblStage AS tStage  
            INNER JOIN mdm.' + @HierarchyRelationshipTable + N' AS tSource  
                ON tStage.ChildType_ID = tSource.ChildType_ID  
                AND tStage.Member_ID = tSource.Child_HP_ID  
            WHERE tSource.Version_ID = @Version_ID  
                AND tStage.ChildType_ID = 2 -- Consolidated  
                AND tSource.Hierarchy_ID = @Hierarchy_ID;  
  
            IF @TargetType_ID = 1 BEGIN  
                --EN  
                --Warning - redundant assignment; transaction will not be logged  
                UPDATE tStage SET  
                    Status_ID = 3  
                FROM #tblStage AS tStage  
                INNER JOIN mdm.' + @HierarchyRelationshipTable + N' AS tSource  
                    ON tStage.ChildType_ID = tSource.ChildType_ID  
                    AND tStage.Member_ID = tSource.Child_EN_ID  
                    AND tStage.Target_ID = tSource.Parent_HP_ID  
                WHERE tSource.Version_ID = @Version_ID  
                    AND tStage.ChildType_ID = 1 -- Leaf  
                    AND tStage.Status_ID = 1  
                    AND tSource.Hierarchy_ID = @Hierarchy_ID;  
                --HP  
                --Warning - redundant assignment; transaction will not be logged  
                UPDATE tStage SET  
                    Status_ID = 3  
                FROM #tblStage AS tStage  
                INNER JOIN mdm.' + @HierarchyRelationshipTable + N' AS tSource  
                    ON tStage.ChildType_ID = tSource.ChildType_ID  
                    AND tStage.Member_ID = tSource.Child_HP_ID  
                    AND tStage.Target_ID = tSource.Parent_HP_ID  
                WHERE tSource.Version_ID = @Version_ID  
                    AND tStage.ChildType_ID = 2 --- Consolidated  
                    AND tStage.Status_ID = 1  
                    AND tSource.Hierarchy_ID = @Hierarchy_ID;  
  
            END; --if  
  
            --Mark new records  
            UPDATE #tblStage SET  
                Status_ID = 4  
            WHERE Status_ID = 1 AND Relationship_ID = -1;  
  
            --Mark records to be removed (moving to Unused for non-mandatory hierarchies)  
            UPDATE #tblStage SET  
                Status_ID = 5  
            WHERE Target_ID = -1 AND Status_ID = 1;  
  
    '  
    IF @TransactionLogType = @TransactionLogType_Attribute  
    BEGIN  
        SET @MainSQL = @MainSQL + N'  
  
            /*  
            --------------------------------------------  
            FETCH PRIOR VALUES (FOR TRANSACTION LOGGING)  
            --------------------------------------------  
            If logging is requested then insert into the transaction log  
            */  
  
            IF @LogFlag = 1 BEGIN  
  
                --Fetch previous target ID from relationship table  
                UPDATE tStage SET  
                    PrevTarget_ID = tSource.Parent_HP_ID  
                FROM #tblStage AS tStage  
                INNER JOIN mdm.' + @HierarchyRelationshipTable + N' AS tSource  
                    ON tStage.Relationship_ID = tSource.ID  
                WHERE tSource.Version_ID = @Version_ID  
                    AND tStage.Status_ID = 1  
                    AND tSource.Hierarchy_ID = @Hierarchy_ID;  
  
                --Fetch previous target code from hierarchy parent table  
                UPDATE tStage SET  
                    PrevTarget_Code = tSource.Code  
                FROM #tblStage AS tStage  
                INNER JOIN mdm.' + @HierarchyParentTable + N' AS tSource  
                    ON tStage.PrevTarget_ID = tSource.ID  
                WHERE tSource.Version_ID = @Version_ID  
                    AND tStage.Status_ID = 1;  
  
            END; --if'  
    END  
  
    SET @MainSQL = @MainSQL + N'  
            SET @Now = GETUTCDATE();  
  
            /*  
              ---------------------------  
              UPDATE RELATIONSHIP RECORDS  
              ---------------------------  
              Update mdm.tblHR with the new relationship records.  
              Assign the SortOrder = Stage_ID for parent assignments (to force ordering of relationships by data entry).  
              Assign the SortOrder = sibling sort order for sibling assignments.  
              This step is only pertinent for hierarchies; collection relationships support redundancy (i.e., more than one of the same member).  
            */'  
  
    IF @TransactionLogType != @TransactionLogType_Member  
    BEGIN  
        SET @MainSQL = @MainSQL + N'  
            --EN  
            UPDATE tSource SET  
                 Parent_HP_ID = NULLIF(tStage.Target_ID, 0)  
                ,ValidationStatus_ID = @AwaitingRevalidation  
                ,LastChgDTM = @Now  
                ,LevelNumber = -1  
                ,LastChgUserID = @User_ID  
                ,LastChgVersionID = @Version_ID  
            FROM #tblStage AS tStage  
            INNER JOIN mdm.' + @HierarchyRelationshipTable + N' AS tSource  
                ON tStage.ChildType_ID = tSource.ChildType_ID  
                AND tStage.Member_ID = tSource.Child_EN_ID  
            WHERE tSource.Version_ID = @Version_ID  
                AND tStage.ChildType_ID = 1 -- Leaf  
                AND tStage.Status_ID = 1  
                AND tSource.Hierarchy_ID = @Hierarchy_ID;  
  
            --HP  
            UPDATE tSource SET  
                 Parent_HP_ID = NULLIF(tStage.Target_ID, 0)  
                ,ValidationStatus_ID = @AwaitingRevalidation  
                ,LastChgDTM = @Now  
                ,LevelNumber = -1  
                ,LastChgUserID = @User_ID  
                ,LastChgVersionID = @Version_ID  
            FROM #tblStage AS tStage  
            INNER JOIN mdm.' + @HierarchyRelationshipTable + N' AS tSource  
                ON tStage.ChildType_ID = tSource.ChildType_ID  
                AND tStage.Member_ID = tSource.Child_HP_ID  
            WHERE tSource.Version_ID = @Version_ID  
                AND tStage.ChildType_ID = 2 --Parent  
                AND tStage.Status_ID = 1  
                AND tSource.Hierarchy_ID = @Hierarchy_ID;';  
    END  
    ELSE  
    BEGIN  
        SET @MainSQL = @MainSQL + N'  
            IF @LogFlag != 1  
            BEGIN  
                --EN  
                UPDATE tSource SET  
                     Parent_HP_ID = NULLIF(tStage.Target_ID, 0)  
                    ,ValidationStatus_ID = @AwaitingRevalidation  
                    ,LastChgDTM = @Now  
                    ,LevelNumber = -1  
                    ,LastChgUserID = @User_ID  
                    ,LastChgVersionID = @Version_ID  
                FROM #tblStage AS tStage  
                INNER JOIN mdm.' + @HierarchyRelationshipTable + N' AS tSource  
                    ON tStage.ChildType_ID = tSource.ChildType_ID  
                    AND tStage.Member_ID = tSource.Child_EN_ID  
                WHERE tSource.Version_ID = @Version_ID  
                    AND tStage.ChildType_ID = 1 -- Leaf  
                    AND tStage.Status_ID = 1  
                    AND tSource.Hierarchy_ID = @Hierarchy_ID;  
  
                --HP  
                UPDATE tSource SET  
                     Parent_HP_ID = NULLIF(tStage.Target_ID, 0)  
                    ,ValidationStatus_ID = @AwaitingRevalidation  
                    ,LastChgDTM = @Now  
                    ,LevelNumber = -1  
                    ,LastChgUserID = @User_ID  
                    ,LastChgVersionID = @Version_ID  
                FROM #tblStage AS tStage  
                INNER JOIN mdm.' + @HierarchyRelationshipTable + N' AS tSource  
                    ON tStage.ChildType_ID = tSource.ChildType_ID  
                    AND tStage.Member_ID = tSource.Child_HP_ID  
                WHERE tSource.Version_ID = @Version_ID  
                    AND tStage.ChildType_ID = 2 --Parent  
                    AND tStage.Status_ID = 1  
                    AND tSource.Hierarchy_ID = @Hierarchy_ID;  
            END  
            ELSE  
            BEGIN  
                --EN  
                UPDATE tSource SET  
                        Parent_HP_ID = NULLIF(tStage.Target_ID, 0)  
                    ,ValidationStatus_ID = @AwaitingRevalidation  
                    ,LastChgDTM = @Now  
                    ,LevelNumber = -1  
                    ,LastChgUserID = @User_ID  
                    ,LastChgVersionID = @Version_ID ' + @HRHistoryOutputQuery + N'  
                FROM #tblStage AS tStage  
                INNER JOIN mdm.' + @HierarchyRelationshipTable + N' AS tSource  
                    ON tStage.ChildType_ID = tSource.ChildType_ID  
                    AND tStage.Member_ID = tSource.Child_EN_ID  
                WHERE tSource.Version_ID = @Version_ID  
                    AND tStage.ChildType_ID = 1 -- Leaf  
                    AND tStage.Status_ID = 1  
                    AND tSource.Hierarchy_ID = @Hierarchy_ID;  
  
                --HP  
                UPDATE tSource SET  
                        Parent_HP_ID = NULLIF(tStage.Target_ID, 0)  
                    ,ValidationStatus_ID = @AwaitingRevalidation  
                    ,LastChgDTM = @Now  
                    ,LevelNumber = -1  
                    ,LastChgUserID = @User_ID  
                    ,LastChgVersionID = @Version_ID ' + @HRHistoryOutputQuery + N'  
                FROM #tblStage AS tStage  
                INNER JOIN mdm.' + @HierarchyRelationshipTable + N' AS tSource  
                    ON tStage.ChildType_ID = tSource.ChildType_ID  
                    AND tStage.Member_ID = tSource.Child_HP_ID  
                WHERE tSource.Version_ID = @Version_ID  
                    AND tStage.ChildType_ID = 2 --Parent  
                    AND tStage.Status_ID = 1  
                    AND tSource.Hierarchy_ID = @Hierarchy_ID;  
            END';  
    END  
    SET @MainSQL = @MainSQL + N'  
            /*  
            ---------------------------  
            DELETE RELATIONSHIP RECORDS  
            ---------------------------  
            Update mdm.tblHR - remove records where the target is unused  
            */'  
      
    IF @TransactionLogType != @TransactionLogType_Member  
    BEGIN  
        SET @MainSQL = @MainSQL + N'  
            UPDATE mdm.' + @HierarchyRelationshipTable + N'  
            SET Status_ID = @MemberStatus_Deactivated  
               ,LastChgDTM = @Now  
               ,LastChgUserID = @User_ID  
               ,LastChgVersionID = @Version_ID  
            WHERE ID IN (SELECT Relationship_ID FROM #tblStage WHERE Status_ID = 5)  
                AND Version_ID = @Version_ID;'  
    END  
    ELSE  
    BEGIN  
        SET @MainSQL = @MainSQL + N'  
            IF @LogFlag != 1  
            BEGIN  
                UPDATE mdm.' + @HierarchyRelationshipTable + N'  
                SET Status_ID = @MemberStatus_Deactivated  
                   ,LastChgDTM = @Now  
                   ,LastChgUserID = @User_ID  
                   ,LastChgVersionID = @Version_ID  
                WHERE ID IN (SELECT Relationship_ID FROM #tblStage WHERE Status_ID = 5)  
                    AND Version_ID = @Version_ID;  
            END  
            ELSE  
            BEGIN  
                UPDATE mdm.' + @HierarchyRelationshipTable + N'  
                SET Status_ID = @MemberStatus_Deactivated  
                   ,LastChgDTM = @Now  
                   ,LastChgUserID = @User_ID  
                   ,LastChgVersionID = @Version_ID ' + @HRHistoryOutputQuery + N'  
                WHERE ID IN (SELECT Relationship_ID FROM #tblStage WHERE Status_ID = 5)  
                    AND Version_ID = @Version_ID;  
            END'  
    END  
    SET @MainSQL = @MainSQL + N'  
            /*  
            ----------------------------------------------------------  
            UPDATE SortOrder previously inserted from udpStgMemberSave  
            ----------------------------------------------------------  
            */  
            SET @MaxSortOrderRelationship = 0;  
            SET @MaxSortOrderStaging = 0;  
  
            -- Get the maximum Sort Order for the existing records in the HR table  
            SELECT @MaxSortOrderRelationship = MAX(tSource.SortOrder)  
                    FROM mdm.' + @HierarchyRelationshipTable + N' AS tSource  
                        INNER JOIN #tblStage tStage1  
                        ON tStage1.ChildType_ID = tSource.ChildType_ID  
                    WHERE NOT EXISTS (SELECT tStage.Member_ID  
                        FROM #tblStage AS tStage  
                            WHERE tStage.Member_ID = tSource.Child_EN_ID  )  
                            AND tSource.Hierarchy_ID = @Hierarchy_ID  
                            AND tSource.Status_ID = 1;  
  
            -- Get the maximum Sort Order for the records to be inserted in the staging table  
            SELECT @MaxSortOrderStaging = MAX(tStage.SortOrder)  
                     FROM #tblStage AS tStage  
                        INNER JOIN mdm.' + @HierarchyRelationshipTable + N' AS tSource  
                        ON tStage.Relationship_ID = tSource.ID  
                    WHERE tSource.Hierarchy_ID = @Hierarchy_ID;'  
  
    IF @TransactionLogType != @TransactionLogType_Member  
    BEGIN  
        SET @MainSQL = @MainSQL + N'  
            UPDATE tSource  
            SET tSource.SortOrder =  
                CASE WHEN @MaxSortOrderStaging <= @MaxSortOrderRelationship THEN tStage.SortOrder + @MaxSortOrderRelationship  
                ELSE tStage.SortOrder  
                END,  
                ValidationStatus_ID = @AwaitingRevalidation  
            FROM mdm.' + @HierarchyRelationshipTable + N' AS tSource  
                INNER JOIN #tblStage AS tStage ON  
                tStage.Relationship_ID = tSource.ID;'  
    END  
    ELSE  
    BEGIN  
        SET @MainSQL = @MainSQL + N'  
            IF @LogFlag != 1  
            BEGIN  
                UPDATE tSource  
                SET tSource.SortOrder =  
                    CASE WHEN @MaxSortOrderStaging <= @MaxSortOrderRelationship THEN tStage.SortOrder + @MaxSortOrderRelationship  
                    ELSE tStage.SortOrder  
                    END,  
                    ValidationStatus_ID = @AwaitingRevalidation  
                FROM mdm.' + @HierarchyRelationshipTable + N' AS tSource  
                    INNER JOIN #tblStage AS tStage ON  
                    tStage.Relationship_ID = tSource.ID;  
            END  
            ELSE  
            BEGIN  
                UPDATE tSource  
                SET tSource.SortOrder =  
                    CASE WHEN @MaxSortOrderStaging <= @MaxSortOrderRelationship THEN tStage.SortOrder + @MaxSortOrderRelationship  
                    ELSE tStage.SortOrder  
                    END,  
                    ValidationStatus_ID = @AwaitingRevalidation ' + @HRHistoryOutputQuery + N'  
                FROM mdm.' + @HierarchyRelationshipTable + N' AS tSource  
                    INNER JOIN #tblStage AS tStage ON  
                    tStage.Relationship_ID = tSource.ID;  
            END'  
    END  
    SET @MainSQL = @MainSQL + N'  
  
            /*  
            -------------------------------  
            INSERT NEW RELATIONSHIP RECORDS  
            -------------------------------  
            */  
  
            --Insert into the hierarchy temporary table (necessary to generate key values)  
            --Added a DISTINCT to eliminate potential duplicate records for collections  
  
            INSERT INTO #tblRelation  
            (  
                Version_ID,  
                Hierarchy_ID,  
                Parent_ID,  
                Child_ID,  
                ChildType_ID,  
                SortOrder  
            ) SELECT DISTINCT  
                @Version_ID,  
                @Hierarchy_ID,  
                Target_ID, --Parent_ID  
                Member_ID,  
                ChildType_ID,  
                SortOrder  
            FROM #tblStage  
            WHERE Status_ID = 4;  
  
            --Insert into hierarchy relationship table  
  
            INSERT INTO mdm.' + @HierarchyRelationshipTable + N'  
            (  
                Version_ID,  
                Status_ID,  
                ValidationStatus_ID,  
                Parent_HP_ID,  
                Child_EN_ID,  
                Child_HP_ID,  
                ChildType_ID,  
                SortOrder,  
                EnterDTM,  
                EnterUserID,  
                EnterVersionID,  
                LastChgDTM,  
                LastChgUserID,  
                LastChgVersionID,  
                Hierarchy_ID,  
                LevelNumber)  
    '  
    SET @MainSQL = @MainSQL + N'  
            --Assign the SortOrder = SortOrder from the staging table  
            SELECT  
                Version_ID,  
                Status_ID,  
                @NewAwaitingValidation,  
                NULLIF(Parent_ID, 0), --Parent_HP_ID / Parent_CN_ID  
                CASE WHEN ChildType_ID = 1 THEN Child_ID ELSE NULL END, --EN  
                CASE WHEN ChildType_ID = 2 THEN Child_ID ELSE NULL END, --HP  
                ChildType_ID,  
                SortOrder,  
                @Now,  
                @User_ID ,  
                @Version_ID,  
                @Now,  
                @User_ID ,  
                @Version_ID,  
                Hierarchy_ID,  
                LevelNumber  
            FROM #tblRelation;  
  
            /*  
            --------------------------------------------------------------------------------------------  
            VERIFY THAT RECURSIVE ASSINGMENTS HAVE NOT BEEN ENTERED  
            This can be accomplished by calculating the level number.  
            Any levels that can not be calculated are deemed recursive and will be moved to the Root.  
            --------------------------------------------------------------------------------------------  
            */  
  
            --Calculate level numbers for the current hierarchy  
            EXEC mdm.udpHierarchyMemberLevelSave @Version_ID, @Hierarchy_ID, 0, 2;  
  
            --For those relationships where the LevelNumber = -1 (i.e., can not be calculated) move to Root  
            UPDATE tStage SET  
                Target_ID = PrevTarget_ID,  
                Target_Code = PrevTarget_Code,  
                Status_ID = 6  
            FROM #tblStage AS tStage  
            INNER JOIN mdm.' + @HierarchyRelationshipTable + N' AS tSource  
                ON tStage.Relationship_ID = tSource.ID  
            WHERE tSource.LevelNumber = -1  
                AND tSource.Version_ID = @Version_ID  
                AND tSource.Hierarchy_ID = @Hierarchy_ID  AND tStage.Status_ID = 1;  
  
            -- Set the error code when circular reference is detected.  
            --Error 210016 Binary Location 2^13:  
            UPDATE stgr SET  
                ErrorCode = ErrorCode | 8192,  
                ImportStatus_ID = @StatusError  
            FROM [stg].' + @StagingRelationshipTable + N' AS stgr  
            INNER JOIN #tblStage AS tStage  
                ON stgr.ID = tStage.Stage_ID  
            WHERE tStage.Status_ID = 6;'  
  
    IF @TransactionLogType != @TransactionLogType_Member  
    BEGIN  
        SET @MainSQL = @MainSQL + N'  
            --Reset the source table  
            --EN  
            UPDATE tSource SET  
                 Parent_HP_ID = NULLIF(tStage.PrevTarget_ID, 0),  
                 ValidationStatus_ID = @AwaitingRevalidation  
            FROM #tblStage AS tStage  
            INNER JOIN mdm.' + @HierarchyRelationshipTable + N' AS tSource  
                ON tStage.ChildType_ID = tSource.ChildType_ID  
                AND tStage.Member_ID = tSource.Child_EN_ID  
            WHERE tSource.LevelNumber = -1  
                AND tStage.ChildType_ID = 1  
                AND tSource.Version_ID = @Version_ID  
                AND tSource.Hierarchy_ID = @Hierarchy_ID;  
  
             --Reset the source table  
             --HP  
            UPDATE tSource SET  
                    Parent_HP_ID = NULLIF(tStage.PrevTarget_ID, 0),  
                    ValidationStatus_ID = @AwaitingRevalidation  
            FROM #tblStage AS tStage  
            INNER JOIN mdm.' + @HierarchyRelationshipTable + N' AS tSource  
                ON tStage.ChildType_ID = tSource.ChildType_ID  
                AND tStage.Member_ID = tSource.Child_HP_ID  
            WHERE tSource.LevelNumber = -1  
                AND tStage.ChildType_ID = 2 -- Parent  
                AND tSource.Version_ID = @Version_ID  
                AND tSource.Hierarchy_ID = @Hierarchy_ID;';  
    END  
    ELSE  
    BEGIN  
        SET @MainSQL = @MainSQL + N'  
            IF @LogFlag != 1  
            BEGIN  
                --Reset the source table  
                --EN  
                UPDATE tSource SET  
                     Parent_HP_ID = NULLIF(tStage.PrevTarget_ID, 0),  
                     ValidationStatus_ID = @AwaitingRevalidation  
                FROM #tblStage AS tStage  
                INNER JOIN mdm.' + @HierarchyRelationshipTable + N' AS tSource  
                    ON tStage.ChildType_ID = tSource.ChildType_ID  
                    AND tStage.Member_ID = tSource.Child_EN_ID  
                WHERE tSource.LevelNumber = -1  
                    AND tStage.ChildType_ID = 1  
                    AND tSource.Version_ID = @Version_ID  
                    AND tSource.Hierarchy_ID = @Hierarchy_ID;  
  
                 --Reset the source table  
                 --HP  
                UPDATE tSource SET  
                        Parent_HP_ID = NULLIF(tStage.PrevTarget_ID, 0),  
                        ValidationStatus_ID = @AwaitingRevalidation  
                FROM #tblStage AS tStage  
                INNER JOIN mdm.' + @HierarchyRelationshipTable + N' AS tSource  
                    ON tStage.ChildType_ID = tSource.ChildType_ID  
                    AND tStage.Member_ID = tSource.Child_HP_ID  
                WHERE tSource.LevelNumber = -1  
                    AND tStage.ChildType_ID = 2 -- Parent  
                    AND tSource.Version_ID = @Version_ID  
                    AND tSource.Hierarchy_ID = @Hierarchy_ID;  
            END  
            ELSE  
            BEGIN  
                --Reset the source table  
                --EN  
                UPDATE tSource SET  
                     Parent_HP_ID = NULLIF(tStage.PrevTarget_ID, 0),  
                     ValidationStatus_ID = @AwaitingRevalidation' + @HRHistoryOutputQuery + N'  
                FROM #tblStage AS tStage  
                INNER JOIN mdm.' + @HierarchyRelationshipTable + N' AS tSource  
                    ON tStage.ChildType_ID = tSource.ChildType_ID  
                    AND tStage.Member_ID = tSource.Child_EN_ID  
                WHERE tSource.LevelNumber = -1  
                    AND tStage.ChildType_ID = 1  
                    AND tSource.Version_ID = @Version_ID  
                    AND tSource.Hierarchy_ID = @Hierarchy_ID;  
  
                 --Reset the source table  
                 --HP  
                UPDATE tSource SET  
                        Parent_HP_ID = NULLIF(tStage.PrevTarget_ID, 0),  
                        ValidationStatus_ID = @AwaitingRevalidation' + @HRHistoryOutputQuery + N'  
                FROM #tblStage AS tStage  
                INNER JOIN mdm.' + @HierarchyRelationshipTable + N' AS tSource  
                    ON tStage.ChildType_ID = tSource.ChildType_ID  
                    AND tStage.Member_ID = tSource.Child_HP_ID  
                WHERE tSource.LevelNumber = -1  
                    AND tStage.ChildType_ID = 2 -- Parent  
                    AND tSource.Version_ID = @Version_ID  
                    AND tSource.Hierarchy_ID = @Hierarchy_ID;   
            END'  
    END  
  
    IF @TransactionLogType = @TransactionLogType_Attribute  
    BEGIN  
        SET @MainSQL = @MainSQL + N'  
            /*  
            ---------------------------  
            PROCESS TRANSACTION LOGGING  
            ---------------------------  
            If logging is requested then insert into the transaction log  
            */  
  
            IF @LogFlag = 1 BEGIN  
                --Log relationship transactions  
                INSERT INTO [mdm].' + QUOTENAME(@TransactionTableName) + N'  
                (  
                    Version_ID,  
                    TransactionType_ID,  
                    OriginalTransaction_ID,  
                    Hierarchy_ID,  
                    Entity_ID,  
                    Member_ID,  
                    Member_MUID,  
                    MemberType_ID,  
                    MemberCode,  
                    OldValue,  
                    OldCode,  
                    NewValue,  
                    NewCode,  
                    Batch_ID,  
                    EnterDTM,  
                    EnterUserID,  
                    LastChgDTM,  
                    LastChgUserID  
                )  
                SELECT  
                    @Version_ID,  
                    CASE TargetType_ID WHEN 1 THEN 4 WHEN 2 THEN 5 ELSE 0 END,  
                    0,  
                    @Hierarchy_ID,  
                    @Entity_ID,  
                    Member_ID,  
                    Member_MUID,  
                    ChildType_ID,  
                    Member_Code,  
                    CASE PrevTarget_ID WHEN NULL THEN -1 ELSE PrevTarget_ID END,  
                    CASE PrevTarget_ID WHEN NULL THEN N''MDMUNUSED'' WHEN -1 THEN N''MDMUNUSED'' WHEN 0 THEN N''ROOT'' ELSE PrevTarget_Code END,  
                    Target_ID,  
                    Target_Code,  
                    @Batch_ID,  
                    GETUTCDATE(),  
                    @User_ID ,  
                    GETUTCDATE(),  
                    @User_ID  
                FROM #tblStage  
                WHERE Status_ID IN (1, 4, 5);  
  
            END; --if  
    '  
    END  
    SET @MainSQL = @MainSQL + N'  
  
            TRUNCATE TABLE #tblStage;  
            TRUNCATE TABLE #tblRelation;  
  
            DELETE FROM @tblMeta WHERE ID = @Meta_ID;  
  
        END; --while  
  
        DROP TABLE #tblStage;  
        DROP TABLE #tblRelation;  
  
        /*  
        ---------------------------------------  
        RECALCULATE HIERARCHY SYSTEM ATTRIBUTES  
        ---------------------------------------  
        */  
        --Iterate through the meta table  
        WHILE EXISTS(SELECT 1 FROM @tblHierarchy) BEGIN  
  
           SELECT TOP 1 @Hierarchy_ID = Hierarchy_ID FROM @tblHierarchy;  
  
           --Recalculate system hierarchy attributes (level number, sort order, and index code)  
           EXEC mdm.udpHierarchySystemAttributesSave @Version_ID, @Hierarchy_ID;  
           DELETE FROM @tblHierarchy WHERE Hierarchy_ID = @Hierarchy_ID;  
  
        END; --while  
  
    '  
        SET @MainSQL = @MainSQL + N'  
        UPDATE [stg].' + @StagingRelationshipTable + '  
        SET ImportStatus_ID = @StatusOK  
        FROM [stg].' + @StagingRelationshipTable + '  
        WHERE ImportStatus_ID = @StatusProcessing;  
  
        --Get the number of errors for the batch ID  
        SELECT @ErrorCount = COUNT(ID) FROM [stg].' + @StagingRelationshipTable + N'  
            WHERE Batch_ID = @Batch_ID AND ImportStatus_ID = @StatusError;  
  
        -- Set the status of the batch as Completed.  
        UPDATE mdm.tblStgBatch  
            SET Status_ID = @Completed,  
                LastRunEndDTM = GETUTCDATE(),  
                LastRunEndUserID = @User_ID,  
                ErrorMemberCount = @ErrorCount  
            WHERE ID = @Batch_ID  
  
        IF @TranCounter = 0 COMMIT TRANSACTION; --Commit only if we are not nested  
  
        RETURN 0;  
  
    END TRY  
    BEGIN CATCH  
        SET NOCOUNT OFF;  
  
        -- Get error info  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N'', @ErrorNumber = '', @ErrorNumber, N'', @ErrorProcedure = "'', @ErrorProcedure, N''", line '', @ErrorLine);  
  
        IF @TranCounter = 0 ROLLBACK TRANSACTION;  
        ELSE IF XACT_STATE() <> -1 ROLLBACK TRANSACTION TX;  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
        RETURN @OtherRuntimeError;  
  
    END CATCH  
        SET NOCOUNT OFF;  
    END;'  
  
    --SELECT @MainSQL AS [processing-instruction(x)] FOR XML PATH('');  
    EXEC sp_executesql @MainSQL;  
  
    SET NOCOUNT OFF;  
END; --proc
go

