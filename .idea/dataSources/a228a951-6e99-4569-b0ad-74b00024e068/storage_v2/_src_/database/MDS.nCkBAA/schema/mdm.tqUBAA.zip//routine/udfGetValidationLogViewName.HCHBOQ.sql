/*  
 SELECT mdm.udfGetValidationLogViewName(7)  
*/  
/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE FUNCTION mdm.udfGetValidationLogViewName  
(  
 @Model_ID   INT  
)   
RETURNS sysname  
/*WITH SCHEMABINDING*/  
AS BEGIN  
  
    RETURN CONCAT(N'viw_SYSTEM_', @Model_ID, N'_ISSUE_VALIDATION');  
  
END; --fn
go

