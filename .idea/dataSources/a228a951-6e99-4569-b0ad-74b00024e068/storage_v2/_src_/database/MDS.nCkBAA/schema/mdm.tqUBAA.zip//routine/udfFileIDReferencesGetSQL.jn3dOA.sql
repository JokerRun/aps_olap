/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Gets a dynamic SQL query string that when executed gets the IDs of all File attribute values (tblFile.ID) that are referenced by the given entity.   
*/  
CREATE FUNCTION mdm.udfFileIDReferencesGetSQL  
(  
     @Entity_ID              INT  
    ,@MemberType_ID          TINYINT = NULL -- When null, all member types in entity will be included  
    ,@FileAttribute_ID       INT = NULL -- When null, all File attributes in the entity will be included  
    ,@SoftDeletedMembersOnly BIT = 0 -- Set to 1 to only look at soft-deleted members.  
)  
RETURNS NVARCHAR(MAX)  
/*WITH SCHEMABINDING*/  
AS  
BEGIN  
  
    DECLARE   
         @AttributeType_File        TINYINT = 4  
  
        ,@MemberType_Leaf           TINYINT = 1  
        ,@MemberType_Consolidated   TINYINT = 2  
        ,@MemberType_Collection     TINYINT = 3  
  
        ,@Status_Deactivated        TINYINT = 2  
  
        ,@SQL                       NVARCHAR(MAX) = N'';  
  
    WITH attributeInfoCte AS  
    (  
        SELECT  
             a.ID  
            ,a.TableColumn  
            ,CASE a.MemberType_ID  
                WHEN @MemberType_Leaf THEN e.EntityTable  
                WHEN @MemberType_Consolidated THEN e.HierarchyParentTable  
                WHEN @MemberType_Collection THEN e.CollectionTable   
                END AS TableName  
        FROM mdm.tblAttribute a  
        INNER JOIN mdm.tblEntity e  
        ON a.Entity_ID = e.ID  
        WHERE a.Entity_ID           = @Entity_ID  
            AND a.ID                = ISNULL(@FileAttribute_ID, a.ID)  
            AND a.AttributeType_ID  = @AttributeType_File  
    )  
    SELECT @SQL += CONCAT(CASE WHEN LEN(@SQL) > 0 THEN N'  
UNION ALL' END, N'  
SELECT ', QUOTENAME(TableColumn), N' ID  
FROM mdm.', QUOTENAME(TableName), N'  
WHERE   ', QUOTENAME(TableColumn), N' IS NOT NULL',   
    CASE WHEN @SoftDeletedMembersOnly = 1 THEN CONCAT(N'  
    AND Status_ID = ', @Status_Deactivated) END)  
    FROM attributeInfoCte;  
  
    RETURN @SQL  
END
go

