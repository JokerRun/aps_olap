/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    SELECT mdm.udfDerivedHierarchyLevelAddCheck(1, 1515, 1);  
*/  
CREATE PROCEDURE mdm.udpDerivedHierarchyLevelAddCheck  
(  
    @DerivedHierarchy_ID  INT,  
    @Foreign_ID  INT,  
    @ForeignType_ID  INT,  
    @ManyToManyChildAttribute_ID  INT,  
    @NextLevelNumber INT OUTPUT,    -- 0 = Incompatible level info; >0 = The new top most level.  
    @TopLevelForeign_ID INT OUTPUT,  -- The top-level foreign Id that will be used to set the foreign parent Id.  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)   
/*WITH*/  
AS BEGIN  
    DECLARE   
         @TopLevel_ID                           INT  
        ,@TopLevelForeignType_ID                TINYINT  
        ,@TopLevelManyToManyChildAttribute_ID   INT  
        ,@TopLevelEntity_ID                     INT  
  
        /************************************************/  
        /*@ForeignType_ID is Common.HierarchyItemType   */  
        /************************************************/  
        ,@HierarchyItemType_Entity              TINYINT = 0  
        ,@HierarchyItemType_DBA                 TINYINT = 1  
        ,@HierarchyItemType_Hierarchy           TINYINT = 2  
        --,@HierarchyItemType_ConsolidatedDBA     TINYINT = 3 -- Not used  
        ,@HierarchyItemType_ManyToMany          TINYINT = 5  
          
        ,@MemberType_Leaf                       TINYINT = 1;  
      
    -- Get the current top level so we can validate it against the requested Foreign_ID and ForeignType_ID.  
    SELECT TOP 1   
         @TopLevelForeign_ID = Foreign_ID  
        ,@TopLevelForeignType_ID = ForeignType_ID  
        ,@TopLevelManyToManyChildAttribute_ID = ManyToManyChildAttribute_ID  
        ,@TopLevelEntity_ID = Entity_ID  
        ,@TopLevel_ID = Level_ID  
    FROM mdm.viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED_LEVELS  
    WHERE Hierarchy_ID = @DerivedHierarchy_ID  
    ORDER BY Level_ID DESC  
  
    --Initialize next level to 0, the error state.  
    SET @NextLevelNumber = 0;  
  
    IF @TopLevelForeignType_ID IS NULL -- No levels added yet  
    BEGIN  
        -- The first level must be an entity and must be in the model of the derived hierarchy.  
        IF EXISTS(SELECT 1 FROM mdm.tblEntity e   
                INNER JOIN mdm.tblDerivedHierarchy dh   
                ON      e.ID = @Foreign_ID   
                    AND dh.ID = @DerivedHierarchy_ID   
                    AND e.Model_ID = dh.Model_ID)  
        BEGIN  
            SET @NextLevelNumber = 1;  
        END;  
    END  
  
    ELSE IF @TopLevelForeignType_ID IN (@HierarchyItemType_Entity, @HierarchyItemType_DBA, @HierarchyItemType_ManyToMany)  
    BEGIN  
        -- The next level can be either a DBA, Hierarchy, or ManyToMany  
        IF     (@ForeignType_ID = @HierarchyItemType_DBA   
                AND EXISTS(SELECT 1   
                            FROM mdm.tblAttribute   
                            WHERE   ID = @Foreign_ID   
                                AND Entity_ID = @TopLevelEntity_ID   
                                AND MemberType_ID = @MemberType_Leaf   
                                AND DomainEntity_ID IS NOT NULL  
                        ))  
            OR (@ForeignType_ID = @HierarchyItemType_Hierarchy   
                AND EXISTS(SELECT 1   
                            FROM mdm.tblHierarchy   
                            WHERE   ID = @Foreign_ID   
                                AND Entity_ID = @TopLevelEntity_ID  
                        ))  
            OR (@ForeignType_ID = @HierarchyItemType_ManyToMany  
                AND EXISTS(SELECT 1   
                            FROM mdm.tblAttribute  
                            WHERE   ID = @ManyToManyChildAttribute_ID  
                                AND DomainEntity_ID = @TopLevelEntity_ID -- The @ManyToManyChildAttribute_ID must be a DBA on a mapping entity that references the top level entity  
                                AND MemberType_ID = @MemberType_Leaf  
                        ))  
        BEGIN  
            SET @NextLevelNumber = @TopLevel_ID + 1;  
        END;  
    END  
  
    ELSE IF @TopLevelForeignType_ID = @HierarchyItemType_Hierarchy  
    BEGIN  
        -- If the current top level is a Hierarchy then no other levels can be added.  
        SET @NextLevelNumber = 0;  
    END  
  
END; --fn
go

