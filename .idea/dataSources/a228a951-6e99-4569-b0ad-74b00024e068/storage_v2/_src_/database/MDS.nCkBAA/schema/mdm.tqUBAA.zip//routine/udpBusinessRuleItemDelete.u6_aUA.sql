/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpBusinessRuleItemDelete  
(  
    @User_ID        INT,  
    @MUID           UNIQUEIDENTIFIER,  
    @RuleMUID       UNIQUEIDENTIFIER = NULL OUTPUT,  
    @CorrelationID  UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    DECLARE  
        @GuidEmpty                  UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER),  
        @ID                         INT,  
        @LogicalOperatorGroupId     INT,  
        @LogicalOperatorGroupMUID   UNIQUEIDENTIFIER,  
        @ItemType                   INT, -- condition or action  
  
        @ActionTypeId               INT = 2,  
        @Permission_Admin           TINYINT = 5;  
  
    SET @RuleMUID = NULL;  
    SET @MUID = NULLIF(@MUID, @GuidEmpty);  
  
    SELECT  
        @ID = it.ID,  
        @RuleMUID = br.MUID,  
        @LogicalOperatorGroupId = lg.ID,  
        @LogicalOperatorGroupMUID = lg.MUID,  
        @ItemType = lr.Parent_ID  
    FROM mdm.tblBRItem it  
    INNER JOIN mdm.tblBRLogicalOperatorGroup lg  
    ON it.BRLogicalOperatorGroup_ID = lg.ID  
    INNER JOIN mdm.tblBRBusinessRule br  
    ON lg.BusinessRule_ID = br.ID  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ENTITY se  
    ON br.Entity_ID = se.ID AND se.User_ID = @User_ID  
    LEFT JOIN mdm.tblBRItemTypeAppliesTo itat  
    ON it.BRItemAppliesTo_ID = itat.ID  
    LEFT JOIN mdm.tblListRelationship lr  
    ON itat.ApplyTo_ID = lr.ID  
    WHERE @MUID IS NOT NULL  
        AND it.MUID = @MUID  
        AND se.Privilege_ID = @Permission_Admin;  
  
    IF @ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR400027|The rule item MUID is not valid.', 16, 1);  
        RETURN;  
    END  
  
    -- delete all item properties  
    DELETE FROM mdm.tblBRItemProperties WHERE BRItem_ID = @ID  
          
    -- delete the item  
    DELETE FROM mdm.tblBRItem WHERE ID = @ID  
  
    -- delete the owning logical operator group *if* the deleted BRItem was the rule's last Action item  
    IF @ItemType = @ActionTypeId AND NOT EXISTS (SELECT 1 FROM mdm.tblBRItem WHERE BRLogicalOperatorGroup_ID = @LogicalOperatorGroupId)  
    BEGIN  
        EXEC mdm.udpBusinessRuleLogicalOperatorGroupDelete @User_ID, @LogicalOperatorGroupMUID  
    END  
  
    SET NOCOUNT OFF  
END
go

