/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
Cleans up logfs for all models based on the LogRetention policy for each model.  
If model has LogRetentionDays as default(0) then inherits the value from System Setting  
If model has LogRetentionDays as -1 then no cleanup will be done for this model ignoring system setting.  
    EXEC mdm.udpLogCLeanup ;  
*/  
CREATE PROCEDURE mdm.udpLogCleanup  
(  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS N'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    BEGIN TRY  
  
    DECLARE @TempTable 	TABLE (RowNumber INT IDENTITY (1, 1) PRIMARY KEY CLUSTERED NOT NULL , ID INT NOT NULL, LogRetentionDays SMALLINT NULL);  
  
    DECLARE @CleanupOlderThanDate   DATE,  
            @TempModelID            INT,  
            @TempLogRetention       SMALLINT;  
  
    INSERT INTO @TempTable SELECT ID, LogRetentionDays FROM mdm.viw_SYSTEM_SCHEMA_MODEL ORDER BY ID DESC;  
  
    DECLARE @Counter INT = 1;  
    DECLARE @MaxCounter INT = (SELECT MAX(RowNumber) FROM @TempTable);  
  
    WHILE @Counter <= @MaxCounter  
    BEGIN  
        SELECT @TempModelID = ID, @TempLogRetention = LogRetentionDays FROM @TempTable WHERE [RowNumber] = @Counter;  
  
        SET @TempLogRetention =  COALESCE(@TempLogRetention, mdm.udfSystemSettingGet('LogRetentionDays'));  
        --if system level setting  OR Model level is -1 then skip the cleanup for this model.  
        IF(@TempLogRetention >= 0)  
        BEGIN  
            SET @CleanupOlderThanDate = CONVERT(DATE, GETDATE() - CONVERT(DATETIME, @TempLogRetention));  
  
            --Cleanup Transaction Logs  
            EXEC mdm.udpTransactionsCleanup @TempModelID, @CleanupOlderThanDate;  
  
            --Claenup EBS tables  
            EXEC mdm.udpEntityStagingBatchTableCleanup @TempModelID, @CleanupOlderThanDate;  
        END  
        SET @Counter = @Counter +1;  
    END -- while  
    RETURN(0);  
    END TRY  
    --Compensate as necessary  
    BEGIN CATCH  
  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
  
        RETURN(1);  
  
    END CATCH;  
    SET NOCOUNT OFF  
END --proc
go

