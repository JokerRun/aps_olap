/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    Returns the tblBRItemTypeAppliesTo.ID value that applies to the given item criteria  
*/  
CREATE FUNCTION mdm.udfBusinessRuleGetBRItemAppliesToID  
(  
    @BRItemType_ID INT,     
    @BRItemCategory_ID INT, /* 1 = Condition, 2 = Then Action 3 = Else Action*/    
    @MemberType_ID TINYINT /* 1 = Leaf, 2 = Consolidated*/    
)     
RETURNS INT    
/*WITH SCHEMABINDING*/    
AS BEGIN    
    DECLARE @Result INT     
    SET @Result =     
       (SELECT TOP 1 AppliesTo_ID     
        FROM mdm.viw_SYSTEM_SCHEMA_BUSINESSRULE_ITEMTYPES     
        WHERE    
            ApplyToCategoryID = 2 AND /* 2 = "BRItemTypeCategory" */    
            BRSubTypeIsVisible = 1 AND    
            BRTypeID = @BRItemCategory_ID AND -- condition or action    
            BRItemType_ID = @BRItemType_ID AND	-- operation    
            BRItemType_ID IN    
            (    
                SELECT BRItemType_ID     
                FROM mdm.viw_SYSTEM_SCHEMA_BUSINESSRULE_ITEMTYPES     
                WHERE    
                    ApplyToCategoryID = 1 AND /*1 = "BRType"*/	    
                    BRSubTypeID = @MemberType_ID     
            )    
         ORDER BY AppliesTo_ID ASC    
       )    
    RETURN @Result    
END --fn
go

