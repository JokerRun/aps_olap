/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
EXEC mdm.udpSecurityPrivilegesMemberSummaryGet 1,27,1,1,0  
EXEC mdm.udpSecurityPrivilegesMemberSummaryGet 1,11,1,1,0,6,10,0  
EXEC mdm.udpSecurityPrivilegesMemberSummaryGet 1,18,1,1,0,Null,Null,Null  
EXEC mdm.udpSecurityPrivilegesMemberSummaryGet 1,118,1,1,0,Null,Null,Null  
*/  
CREATE PROCEDURE mdm.udpSecurityPrivilegesMemberSummaryGet  
(  
     @SystemUser_ID             INT -- The user requesting the permissions  
    ,@Principal_ID              INT  
    ,@PrincipalType_ID          TINYINT  
    ,@ResolutionType            TINYINT  
    ,@Model_ID                  INT = NULL  
    ,@Hierarchy_ID              INT = NULL  
    ,@HierarchyType_ID          INT = NULL  
    ,@CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    DECLARE   
         @PrincipalType_Group           TINYINT = 2  
  
        ,@ResolutionType_UserAndGroup   TINYINT = 0  
        ,@ResolutionType_User           TINYINT = 1  
        ,@ResolutionType_Effective      TINYINT = 2;  
  
    IF (@PrincipalType_ID = @PrincipalType_Group AND @ResolutionType = @ResolutionType_Effective)  
    BEGIN  
        SET @ResolutionType = @ResolutionType_User;  
    END;  
  
    DECLARE   
         @IncludeGroupAssignments   BIT = (CASE @ResolutionType WHEN @ResolutionType_User THEN 0 ELSE 1 END)  
        ,@ID                        INT  
        ,@Entity_ID                 INT  
        ,@Version_ID                INT  
        ,@MemberType_ID             INT  
        ,@RootMember_ID             INT = 0  
        ,@TableName                 NVARCHAR(100)  
        ,@SQL                       NVARCHAR(MAX);  
  
  
    CREATE TABLE #tblPrivileges  
    (  
         RoleAccess_ID          INT  
        ,RoleAccess_MUID        UNIQUEIDENTIFIER  
        ,Privilege_ID           TINYINT  
        ,AccessPermission       TINYINT  
        ,Model_ID               INT  
        ,Model_MUID             UNIQUEIDENTIFIER  
        ,Model_Name             NVARCHAR(50) COLLATE DATABASE_DEFAULT  
        ,IsModelAdministrator   BIT  
        ,Version_ID             INT  
        ,Version_MUID           UNIQUEIDENTIFIER  
        ,Version_Name           NVARCHAR(50) COLLATE DATABASE_DEFAULT  
        ,HierarchyType_ID       TINYINT  
        ,Hierarchy_ID           INT  
        ,Hierarchy_MUID         UNIQUEIDENTIFIER  
        ,Hierarchy_Name         NVARCHAR(50) COLLATE DATABASE_DEFAULT  
        ,Entity_ID              INT  
        ,Entity_MUID            UNIQUEIDENTIFIER  
        ,Entity_Name            NVARCHAR(MAX) COLLATE DATABASE_DEFAULT  
        ,MemberType_ID          TINYINT  
        ,Member_ID              INT  
        ,Member_MUID            UNIQUEIDENTIFIER  
        ,Member_Name            NVARCHAR(250) COLLATE DATABASE_DEFAULT NULL  
        ,Member_Code            NVARCHAR(250) COLLATE DATABASE_DEFAULT NULL  
        ,PrincipalType_ID       TINYINT  
        ,Principal_ID           INT  
        ,Principal_MUID         UNIQUEIDENTIFIER  
        ,Principal_Name         NVARCHAR(355) COLLATE DATABASE_DEFAULT  
        ,EnterUserID            INT  
        ,EnterUserMUID          UNIQUEIDENTIFIER  
        ,EnterUser              NVARCHAR(256) COLLATE DATABASE_DEFAULT NULL  
        ,EnterDTM               DATETIME2(3)  
        ,LastChgUserID          INT  
        ,LastChgUserMUID        UNIQUEIDENTIFIER  
        ,LastChgUser            NVARCHAR(256) COLLATE DATABASE_DEFAULT NULL  
        ,LastChgDTM             DATETIME2(3)  
    );  
  
    INSERT INTO #tblPrivileges  
    SELECT   
         xp.RoleAccess_ID  
        ,xp.RoleAccess_MUID  
        ,xp.Privilege_ID  
        ,xp.AccessPermission  
        ,xp.Model_ID  
        ,xp.Model_MUID  
        ,xp.Model_Name  
        ,xp.IsModelAdministrator  
        ,xp.Version_ID  
        ,xp.Version_MUID  
        ,xp.Version_Name  
        ,xp.HierarchyType_ID  
        ,xp.Hierarchy_ID  
        ,xp.Hierarchy_MUID  
        ,xp.Hierarchy_Name  
        ,xp.Entity_ID  
        ,xp.Entity_MUID  
        ,xp.Entity_Name  
        ,xp.MemberType_ID  
        ,xp.Member_ID  
        ,NULL Member_MUID  
        ,NULL Member_Name  
        ,NULL Member_Code  
        ,xp.PrincipalType_ID  
        ,xp.Principal_ID  
        ,xp.Principal_MUID  
        ,xp.Principal_Name  
        ,xp.EnterUserID  
        ,xp.EnterUserMUID  
        ,xp.EnterUser  
        ,xp.EnterDTM  
        ,xp.LastChgUserID  
        ,xp.LastChgUserMUID  
        ,xp.LastChgUser  
        ,xp.LastChgDTM  
    FROM mdm.udfSecurityUserExplicitMemberPermissions(@SystemUser_ID, @Principal_ID, @PrincipalType_ID, @IncludeGroupAssignments) xp  
    WHERE   (@Model_ID IS NULL OR xp.Model_ID = @Model_ID)  
        AND (@Hierarchy_ID IS NULL OR xp.Hierarchy_ID = @Hierarchy_ID)  
        AND (@HierarchyType_ID IS NULL OR xp.HierarchyType_ID = @HierarchyType_ID)  
  
    IF (@ResolutionType = @ResolutionType_Effective)  
    BEGIN  
        DECLARE @MemberPermissions AS TABLE (ID INT PRIMARY KEY, MemberType_ID TINYINT, Privilege_ID TINYINT, AccessPermission TINYINT);  
  
        -- Get a list of distinct entity member types.  
        DECLARE @EntityVersions TABLE  
        (  
             ID         INT IDENTITY (1, 1) NOT NULL  
            ,Entity_ID  INT  
            ,Version_ID INT  
        );  
        INSERT INTO @EntityVersions (Entity_ID, Version_ID)  
        SELECT DISTINCT   
             Entity_ID  
            ,Version_ID  
        FROM #tblPrivileges  
  
        DECLARE @MemberIds  mdm.MemberId;  
  
        -- Get effective permissions for each member, grouped by Entity-Version  
        WHILE EXISTS(SELECT 1 FROM @EntityVersions)  
        BEGIN  
            -- Get the next Entity-Version pair.  
            SELECT TOP 1  
                 @ID = ID  
                ,@Entity_ID = Entity_ID  
                ,@Version_ID = Version_ID  
            FROM @EntityVersions  
            ORDER BY ID;  
  
            DELETE FROM @EntityVersions WHERE ID = @ID;  
  
            -- Get the member ids for the Entity and Version.  
            DELETE FROM @MemberIds  
            INSERT INTO @MemberIds (ID, MemberType_ID)  
            SELECT DISTINCT  
                 Member_ID  
                ,MemberType_ID  
            FROM #tblPrivileges  
            WHERE   Entity_ID = @Entity_ID  
                AND Version_ID = @Version_ID  
                AND Member_ID != @RootMember_ID; -- Omit the ROOT node pseudo-member from the effective permission check. Instead, use it's explicit permission (if any)  
  
            -- Get the member permissions.  
            DELETE FROM @MemberPermissions;  
            INSERT INTO @MemberPermissions  
            EXEC mdm.udpSecurityMembersResolverGet @Principal_ID, @Version_ID, @Entity_ID, @MemberIds;  
  
            -- Since we are getting effective permissions we need to prune the list so that each member appears only once in the result set  
            -- Keep the permission that is effective  
            WITH cteOrderedPermissions AS  
            (  
                SELECT  
                     ROW_NUMBER() OVER (PARTITION BY p.Version_ID, p.Entity_ID, p.MemberType_ID, p.Member_ID  
                                        ORDER BY   
                                            CASE WHEN p.Privilege_ID = mp.Privilege_ID THEN 0 ELSE 1 END -- Permissions that match the effective permission have precedence  
                                            ,p.PrincipalType_ID) RowNumber                               -- Matching user permissions take precedence over matahing group permissions.  
                    ,p.RoleAccess_ID  
                FROM #tblPrivileges p  
                LEFT JOIN @MemberPermissions mp  
                ON      p.Member_ID = mp.ID  
                    AND p.MemberType_ID = mp.MemberType_ID  
                    AND p.Entity_ID = @Entity_ID  
                    AND p.Version_ID = @Version_ID  
                WHERE  p.Member_ID = @RootMember_ID -- Only match the ROOT node, or...  
                    OR mp.ID IS NOT NULL            -- ...members whose effective permissions were just looked up  
            )  
            DELETE p  
            FROM #tblPrivileges p  
            INNER JOIN cteOrderedPermissions op  
            ON p.RoleAccess_ID = op.RoleAccess_ID  
            WHERE op.RowNumber > 1 -- prune all but the best match.  
  
  
            -- Update the member permissions.  
            UPDATE p  
            SET p.Privilege_ID = mp.Privilege_ID, p.AccessPermission = mp.AccessPermission  
            FROM #tblPrivileges p  
            INNER JOIN @MemberPermissions mp  
            ON      p.Member_ID = mp.ID  
                AND p.MemberType_ID = mp.MemberType_ID  
                AND p.Entity_ID = @Entity_ID  
                AND p.Version_ID = @Version_ID;  
        END; -- WHILE  
  
    END; -- If getting effective permissions.  
  
    -- Update the Member name, muid, and code columns.  
  
    -- Get a list of distinct entity member types.  
    DECLARE @EntityMemberTypes TABLE  
    (  
         ID             INT IDENTITY (1, 1) NOT NULL  
        ,Entity_ID      INT  
        ,MemberType_ID  TINYINT  
    );  
    INSERT INTO @EntityMemberTypes (Entity_ID, MemberType_ID)  
    SELECT DISTINCT   
         Entity_ID  
        ,MemberType_ID  
    FROM #tblPrivileges  
    WHERE Member_ID > 0 -- Ignore ROOT and MDMUNUSED (they will be handled later)  
  
    WHILE EXISTS(SELECT 1 FROM @EntityMemberTypes)  
    BEGIN  
        SELECT TOP 1   
             @ID = ID  
            ,@Entity_ID = Entity_ID  
            ,@MemberType_ID = MemberType_ID  
            ,@TableName = mdm.udfTableNameGetByID(Entity_ID, MemberType_ID)  
        FROM @EntityMemberTypes   
        ORDER BY ID;  
         
        DELETE FROM @EntityMemberTypes WHERE ID = @ID;  
  
        SET @SQL= N'  
        UPDATE p  
        SET  Member_MUID       = MUID  
            ,Member_Name       = Name  
            ,Member_Code       = Code  
        FROM mdm.' + QUOTENAME(@TableName) + N' T  
        INNER JOIN #tblPrivileges p  
        ON      T.ID = p.Member_ID  
            AND p.Entity_ID = @Entity_ID  
            AND p.MemberType_ID = @MemberType_ID';  
  
        EXEC sp_executesql @SQL, N'@Entity_ID INT, @MemberType_ID INT', @Entity_ID, @MemberType_ID;  
    END; -- WHILE  
  
    --Update the privileges where id is 0 or less.  
    UPDATE #tblPrivileges  
    SET  Member_Name = N'ROOT'  
        ,Member_Code = N'ROOT'  
    WHERE Member_ID = 0 ;  
    UPDATE #tblPrivileges  
    SET  Member_Name = CASE   
            WHEN Member_ID = -1 THEN NULL -- Top-level unused node  
            ELSE CONVERT(NVARCHAR, ABS(Member_ID) - 10) END -- Level number for level-specific unused node.   
        ,Member_Code = N'MDMUNUSED'  
    WHERE Member_ID < 0;  
  
  
    -- Return the results.  
    SELECT * -- It is generally considered bad practice to do a "SELECT *" because of maintainability issues if the table schema changes. But in this case, it is a temp table that is defined inside of this sproc, so it is okay.  
    FROM #tblPrivileges  
    ORDER BY Model_Name, Version_Name, Member_Name  
  
    SET NOCOUNT OFF  
END
go

