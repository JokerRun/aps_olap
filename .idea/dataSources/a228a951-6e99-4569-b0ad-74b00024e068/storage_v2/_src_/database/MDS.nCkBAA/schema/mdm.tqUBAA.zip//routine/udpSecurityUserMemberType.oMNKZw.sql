/*  
Example  : mdm.[udpSecurityUserMemberType](2, 1020, 4, 1, @Privilege_ID OUT) --Returns the default privilege for User ID = 2 and Attribute ID = 1288 (leaf member)  
*/  
/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE [mdm].[udpSecurityUserMemberType]  
(  
    @User_ID INT,  
    @Entity_ID INT,  
    @MemberType_ID TINYINT,  
    @Privilege_ID INT OUTPUT,  
    @AccessPermission TINYINT OUTPUT,  
    @IsAdmin BIT = NULL OUTPUT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
AS  
BEGIN  
    SELECT  
        @Privilege_ID = Privilege_ID,  
        @AccessPermission = AccessPermission,  
        @IsAdmin = IsAdmin  
    FROM mdm.viw_SYSTEM_SECURITY_USER_MEMBERTYPE  
    WHERE User_ID = @User_ID  
        AND Entity_ID = @Entity_ID  
        AND ID = @MemberType_ID  
  
    SET @Privilege_ID = ISNULL(@Privilege_ID, 1 /*Deny*/);  
    SET @AccessPermission = ISNULL(@AccessPermission, NULL /*None*/);  
    SET @IsAdmin = ISNULL(@IsAdmin, 0);  
END
go

