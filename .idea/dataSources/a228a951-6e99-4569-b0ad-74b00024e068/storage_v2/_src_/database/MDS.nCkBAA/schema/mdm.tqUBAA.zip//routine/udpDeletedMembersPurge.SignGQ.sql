/*    
==============================================================================    
 Copyright (c) Microsoft Corporation. All Rights Reserved.    
==============================================================================    
  
Purges (hard-deletes) already deactivated (soft-deleted) members of the specified model version.  
   
EXEC mdm.udpDeletedMembersPurge @ModelName = N'Product', @VersionName = N'Version 1'     
    
*/  
CREATE PROCEDURE mdm.udpDeletedMembersPurge  
(  
    @User_ID        INT = NULL, -- Optional. If provided, an error will be thrown if the user does not have versions functional permission or is not a model admin.  
    @ModelName      NVARCHAR(50) = NULL,      -- Either Name or MUID (or both) must be provided for Model  
    @Model_MUID     UNIQUEIDENTIFIER = NULL,  
    @VersionName    NVARCHAR(50) = NULL,     -- Either Name or MUID (or both) must be provided for Version  
    @Version_MUID   UNIQUEIDENTIFIER = NULL,  
    @EntityName     NVARCHAR(50) = NULL,     -- Entity is optional. When not provided, all entities pertaining to the specified model version will be purged.  
    @Entity_MUID    UNIQUEIDENTIFIER = NULL,  
    @CorrelationID  UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)    
WITH EXECUTE AS 'mds_schema_user'    
AS     
BEGIN    
    SET NOCOUNT ON;    
  
    DECLARE  
        @Model_ID                       INT,  
        @Version_ID                     INT,  
        @Entity_ID                      INT,  
        @TranCounter                    INT,  
        @SQL                            NVARCHAR(MAX),  
        @DeletedStatus                  TINYINT = 2,  
        @CurrentEntityID                INT,  
        @CurrentEntityTable             SYSNAME,  
        @CurrentHierarchyParentTable    SYSNAME,  
        @CurrentHierarchyTable          SYSNAME,  
        @CurrentCollectionMemberTable   SYSNAME,  
        @CurrentCollectionTable         SYSNAME,  
        @IsCollectionEnabled            BIT,  
        @IsHierarchyEnabled             BIT,  
  
        @ViewFormat_Collection             TINYINT = 3,  
        @ViewFormat_CollectionMembership   TINYINT = 4,  
          
        @MemberType_Leaf            TINYINT = 1,  
        @MemberType_Consolidated    TINYINT = 2,  
        @MemberType_Collection      TINYINT = 3;  
  
    SELECT   
         @Version_MUID = NULLIF(@Version_MUID, 0x0)  
        ,@VersionName = NULLIF(LTRIM(RTRIM(@VersionName)), N'')  
        ,@Entity_MUID = NULLIF(@Entity_MUID, 0x0)  
        ,@EntityName = NULLIF(LTRIM(RTRIM(@EntityName)), N'');  
  
    -- Get @Model_ID  
    SET @Model_ID = mdm.udfModelGetIDByName(@Model_MUID, @ModelName);  
  
    -- Get @Entity_ID  
    IF @Entity_MUID IS NOT NULL OR @EntityName IS NOT NULL  
    BEGIN  
        SELECT @Entity_ID = ID  
        FROM mdm.tblEntity  
        WHERE   Model_ID = @Model_ID  
            AND (@Entity_MUID IS NULL OR @Entity_MUID = MUID)  
            AND (@EntityName IS NULL OR @EntityName = Name)  
  
        IF @Entity_ID IS NULL  
        BEGIN  
            RAISERROR('MDSERR300008|The supplied entity is not valid.', 16, 1);  
            RETURN;  
        END;  
    END  
  
    IF @User_ID IS NOT NULL  
    BEGIN  
        -- Ensure the user has the appropriate functional permission  
        DECLARE   
             @FunctionalPrivilege_Explorer  TINYINT = 1  
            ,@FunctionalPrivilege_Versions  TINYINT = 2;  
        IF mdm.udfSecurityUserFunctionIsAllowed(@User_ID,   
            CASE WHEN @Entity_ID IS NULL   
                THEN @FunctionalPrivilege_Versions -- Need Versions permission to filter an entire model version  
                ELSE @FunctionalPrivilege_Explorer -- Only need Explorer permission to filter a single entity within a model version  
                END) = 0    
        BEGIN    
            RAISERROR('MDSERR120002|The user does not have permission to perform this operation.', 16, 1);    
            RETURN;    
        END   
          
        DECLARE   
             @Permission        TINYINT = NULL  
            ,@Permission_Deny   TINYINT = 1  
            ,@Permission_Admin  TINYINT = 5  
  
        IF @Model_ID IS NOT NULL  
        BEGIN  
  
            IF @Entity_ID IS NOT NULL  
            BEGIN   
                -- Ensure the user has Admin permission on the entity  
                SELECT @Permission = Privilege_ID   
                FROM mdm.viw_SYSTEM_SECURITY_USER_ENTITY  
                WHERE   ID = @Entity_ID  
                    AND User_ID = @User_ID  
            END ELSE  
            BEGIN   
                -- Ensure the user has Admin permission on the model  
                SELECT @Permission = Privilege_ID   
                FROM mdm.viw_SYSTEM_SECURITY_USER_MODEL  
                WHERE   ID = @Model_ID  
                    AND User_ID = @User_ID  
            END  
  
            IF COALESCE(@Permission, @Permission_Deny) <> @Permission_Admin  
            BEGIN  
                SET @Model_ID = NULL;  
            END  
        END  
    END  
  
    IF @Model_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR120003|The user does not have permission or the object ID is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    -- Get @Version_ID  
    IF @VersionName IS NOT NULL OR @Version_MUID IS NOT NULL  
    BEGIN  
        SELECT @Version_ID = ID  
        FROM mdm.tblModelVersion  
        WHERE Model_ID = @Model_ID  
            AND (@Version_MUID IS NULL OR @Version_MUID = MUID)  
            AND (@VersionName IS NULL OR @VersionName = Name)  
    END  
  
    IF @Version_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300006|The supplied version is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    -- Populate Entity, Hierarchy Parent, and Hierarchy Relationship Table Names.  
    CREATE TABLE #EntityTableNames    
    (    
        ID                      INT,  
        EntityTable             SYSNAME,  
        HierarchyParentTable    SYSNAME NULL,  
        HierarchyTable          SYSNAME NULL,  
        CollectionMemberTable   SYSNAME NULL,  
        CollectionTable         SYSNAME NULL  
    );  
  
    INSERT INTO #EntityTableNames  
    (  
        ID, EntityTable, HierarchyParentTable, HierarchyTable, CollectionMemberTable, CollectionTable  
    )  
    SELECT ID, EntityTable, HierarchyParentTable, HierarchyTable, CollectionMemberTable, CollectionTable  
    FROM mdm.tblEntity  
    WHERE   Model_ID = @Model_ID  
        AND (@Entity_ID IS NULL OR ID = @Entity_ID);  
  
       
    -- Verify the entity is not a sync target.  
    DECLARE @TargetEntityName NVARCHAR(50) = NULL;  
    SELECT TOP 1   
        @TargetEntityName = e.Name  
    FROM mdm.tblSyncRelationship sr  
    INNER JOIN mdm.tblEntity e  
    ON sr.TargetEntity_ID = e.ID  
    WHERE   e.Model_ID = @Model_ID  
        AND sr.TargetVersion_ID = @Version_ID  
  
    IF @TargetEntityName IS NOT NULL  
    BEGIN  
        DECLARE @ErrorMsg NVARCHAR(MAX) = CONCAT('MDSERR200221|Members cannot be purged from the model version. It contains at least one entity that is the target of a sync relationship. First: "{0}"|', @TargetEntityName);  
        SET @ErrorMsg = REPLACE(@ErrorMsg, '%', '%%')-- escape out format specifier  
        RAISERROR(@ErrorMsg, 16, 1);  
        RETURN;  
    END  
  
    --Start transaction, being careful to check if we are nested    
    SET @TranCounter = @@TRANCOUNT;  
        
    IF @TranCounter > 0 SAVE TRANSACTION TX;    
    ELSE BEGIN TRANSACTION;  
   
    BEGIN TRY   
  
        CREATE TABLE #FileIDsToDelete  
        (  
            ID  INT  
        );  
  
        DECLARE @EntitiesWithCollectionTablesToDrop mdm.IdList;  
  
        -- Purge members.  
        WHILE EXISTS(SELECT 1 FROM #EntityTableNames)   
        BEGIN        
            SELECT TOP 1         
                @CurrentEntityID = ID,  
                @CurrentEntityTable = EntityTable,  
                @CurrentHierarchyParentTable = HierarchyParentTable,  
                @CurrentHierarchyTable = HierarchyTable,  
                @CurrentCollectionMemberTable = CollectionMemberTable,  
                @CurrentCollectionTable = CollectionTable,  
                @IsCollectionEnabled = CASE WHEN CollectionTable IS NULL THEN 0 ELSE 1 END,  
                @IsHierarchyEnabled  = CASE WHEN HierarchyTable  IS NULL THEN 0 ELSE 1 END  
            FROM #EntityTableNames        
            ORDER BY ID;    
       
            -- Get the IDs of the Files referenced by the members being purged  
            SET @SQL = mdm.udfFileIDReferencesGetSQL(@CurrentEntityID, NULL, NULL, 1);  
            IF LEN(@SQL) > 0  
            BEGIN  
                SET @SQL = CONCAT(N'INSERT INTO #FileIDsToDelete(ID)  
', @SQL)  
                --PRINT @SQL  
                EXEC sp_executesql @SQL;  
            END  
                          
            IF @IsCollectionEnabled = 1   
            BEGIN   
                -- Purge members from collection tables.  
                SET @SQL = CONCAT(N'  
DECLARE @MemberIds TABLE(ID INT PRIMARY KEY, Revision_ID BIGINT);  
DECLARE @RevisionIds TABLE(ID BIGINT PRIMARY KEY)  
  
-- Collection membership table  
DELETE mdm.', QUOTENAME(@CurrentCollectionMemberTable), N'  
OUTPUT deleted.ID, CONVERT(BIGINT, deleted.LastChgTS) INTO @MemberIds(ID, Revision_ID)  
WHERE   Version_ID = @Version_ID  
    AND Status_ID = ', @DeletedStatus, N';  
  
INSERT INTO @RevisionIds(ID)   
SELECT Revision_ID FROM @MemberIds  
  
-- Collection membership history table  
DELETE hs  
OUTPUT deleted.ID INTO @RevisionIds(ID)  
FROM mdm.', QUOTENAME(@CurrentCollectionMemberTable + N'_HS'), N' hs  
INNER JOIN @MemberIds m  
ON      hs.Version_ID = @Version_ID   
    AND hs.CM_ID = m.ID  
  
  
-- Collection membership annotation table  
DELETE an  
FROM mdm.', QUOTENAME(@CurrentCollectionMemberTable + N'_AN'), N' an  
INNER JOIN @RevisionIds r  
ON      an.Version_ID = @Version_ID  
    AND an.Revision_ID = r.ID  
  
DELETE @MemberIds  
DELETE @RevisionIds;  
  
-- Collection table  
DELETE mdm.', QUOTENAME(@CurrentCollectionTable), N'  
OUTPUT deleted.ID, CONVERT(BIGINT, deleted.LastChgTS) INTO @MemberIds(ID, Revision_ID)  
WHERE   Version_ID = @Version_ID  
    AND Status_ID = ', @DeletedStatus, N'  
  
INSERT INTO @RevisionIds(ID)   
SELECT Revision_ID FROM @MemberIds  
  
-- Collection history table  
DELETE hs  
OUTPUT deleted.ID INTO @RevisionIds(ID)  
FROM mdm.', QUOTENAME(@CurrentCollectionTable + N'_HS'), N' hs  
INNER JOIN @MemberIds m  
ON      hs.Version_ID = @Version_ID   
    AND hs.CN_ID = m.ID  
  
-- Collection annotation table  
DELETE an  
FROM mdm.', QUOTENAME(@CurrentCollectionTable + N'_AN'), N' an  
INNER JOIN @RevisionIds r  
ON      an.Version_ID = @Version_ID  
    AND an.Revision_ID = r.ID  
  
  
  
-- Model transaction table (will cascade delete to model annotation table)  
DELETE tr  
FROM mdm.tbl_', @Model_ID, N'_TR tr  
INNER JOIN @MemberIds m  
ON tr.Member_ID = m.ID  
WHERE   tr.Version_ID = @Version_ID  
    AND tr.Entity_ID = @CurrentEntityID  
    AND tr.MemberType_ID = ', @MemberType_Collection, N'  
  
IF      NOT EXISTS(SELECT 1 FROM mdm.', QUOTENAME(@CurrentCollectionTable), N')  
    AND NOT EXISTS(SELECT 1 FROM mdm.', QUOTENAME(@CurrentCollectionMemberTable), N')  
BEGIN  
    SET @DropTables = 1;  
END'  
                    );  
  
                DECLARE @DropTables BIT = 0;  
                EXEC sp_executesql @SQL, N'@Version_ID INT, @CurrentEntityID INT, @DropTables BIT OUTPUT', @Version_ID, @CurrentEntityID, @DropTables OUTPUT;  
                -- If the collection tables contain no members, drop them.  
                IF @DropTables = 1  
                BEGIN  
                    INSERT INTO @EntitiesWithCollectionTablesToDrop  
                    VALUES (@CurrentEntityID)  
                END  
            END; --IF    
  
            IF @IsHierarchyEnabled = 1   
            BEGIN   
                -- If there is a hierarchy, purge the Hierarchy Relationship tables.  
                SET @SQL = CONCAT(N'  
DECLARE @MemberIds TABLE(ID INT PRIMARY KEY, Revision_ID BIGINT);  
DECLARE @RevisionIds TABLE(ID BIGINT PRIMARY KEY)  
  
-- Hierarchy relationship table  
DELETE mdm.', QUOTENAME(@CurrentHierarchyTable), N'  
OUTPUT deleted.ID, CONVERT(BIGINT, deleted.LastChgTS) INTO @MemberIds(ID, Revision_ID)  
WHERE   Version_ID = @Version_ID  
    AND Status_ID = ', @DeletedStatus, N';  
  
INSERT INTO @RevisionIds(ID)   
SELECT Revision_ID FROM @MemberIds  
  
-- Hierarchy relationship history table  
DELETE hs  
OUTPUT deleted.ID INTO @RevisionIds(ID)  
FROM mdm.', QUOTENAME(@CurrentHierarchyTable + N'_HS'), N' hs  
INNER JOIN @MemberIds m  
ON      hs.Version_ID = @Version_ID   
    AND hs.HR_ID = m.ID  
  
-- Hierarchy relationship annotation table  
DELETE an  
FROM mdm.', QUOTENAME(@CurrentHierarchyTable + N'_AN'), N' an  
INNER JOIN @RevisionIds r  
ON      an.Version_ID = @Version_ID  
    AND an.Revision_ID = r.ID  
  
  
-- Consolidated member security.    
DELETE sra  
FROM mdm.tblSecurityRoleAccessMember sra    
INNER JOIN mdm.', QUOTENAME(@CurrentHierarchyParentTable), N' hp  
ON      sra.Version_ID = hp.Version_ID  
    AND sra.Member_ID = hp.ID   
    AND sra.Entity_ID = @CurrentEntityID  
    AND sra.MemberType_ID = ', @MemberType_Consolidated, N'  
WHERE   hp.Version_ID = @Version_ID  
    AND hp.Status_ID = ', @DeletedStatus, N';   
  
DELETE @MemberIds;  
DELETE @RevisionIds;  
  
-- Consolidated table  
DELETE mdm.', QUOTENAME(@CurrentHierarchyParentTable), N'   
OUTPUT deleted.ID, CONVERT(BIGINT, deleted.LastChgTS) INTO @MemberIds(ID, Revision_ID)  
WHERE   Version_ID = @Version_ID   
    AND Status_ID = ', @DeletedStatus, N';  
  
INSERT INTO @RevisionIds(ID)   
SELECT Revision_ID FROM @MemberIds  
  
-- Consolidated history table  
DELETE hs  
OUTPUT deleted.ID INTO @RevisionIds(ID)  
FROM mdm.', QUOTENAME(@CurrentHierarchyParentTable + N'_HS'), N' hs  
INNER JOIN @MemberIds m  
ON      hs.Version_ID = @Version_ID   
    AND hs.HP_ID = m.ID  
  
-- Consolidated member annotation table  
DELETE an  
FROM mdm.', QUOTENAME(@CurrentHierarchyParentTable + N'_AN'), N' an  
INNER JOIN @RevisionIds r  
ON      an.Version_ID = @Version_ID  
    AND an.Revision_ID = r.ID  
  
  
-- Model transaction table (will cascade delete to model annotation table)  
DELETE tr  
FROM mdm.tbl_', @Model_ID, N'_TR tr  
INNER JOIN @MemberIds m  
ON tr.Member_ID = m.ID  
WHERE   tr.Version_ID = @Version_ID  
    AND tr.Entity_ID = @CurrentEntityID  
    AND tr.MemberType_ID = ', @MemberType_Consolidated);  
  
                EXEC sp_executesql @SQL, N'@Version_ID INT, @CurrentEntityID INT', @Version_ID, @CurrentEntityID;  
            END;  
  
            SET @SQL = CONCAT(N'   
-- Leaf member security  
DELETE sra   
FROM mdm.tblSecurityRoleAccessMember sra    
INNER JOIN mdm.', QUOTENAME(@CurrentEntityTable), N' en   
ON      sra.Member_ID = en.ID   
    AND sra.Entity_ID = @CurrentEntityID  
    AND sra.MemberType_ID = ', @MemberType_Leaf, N'  
    AND en.Version_ID = @Version_ID  
WHERE en.Status_ID = ', @DeletedStatus, N';  
  
DECLARE @MemberIds TABLE(ID INT PRIMARY KEY, Revision_ID BIGINT);  
DECLARE @RevisionIds TABLE(ID BIGINT PRIMARY KEY)  
  
-- Leaf table (will cascade delete to PD table and MS table)  
DELETE mdm.', QUOTENAME(@CurrentEntityTable), N'   
OUTPUT deleted.ID, CONVERT(BIGINT, deleted.LastChgTS) INTO @MemberIds(ID, Revision_ID)  
WHERE   Version_ID = @Version_ID   
    AND Status_ID = ', @DeletedStatus, N';  
  
INSERT INTO @RevisionIds(ID)   
SELECT Revision_ID FROM @MemberIds  
  
-- Leaf history table  
DELETE hs  
OUTPUT deleted.ID INTO @RevisionIds(ID)  
FROM mdm.', QUOTENAME(@CurrentEntityTable + N'_HS'), N' hs  
INNER JOIN @MemberIds m  
ON      hs.Version_ID = @Version_ID   
    AND hs.EN_ID = m.ID  
  
-- Leaf member annotation table  
DELETE an  
FROM mdm.', QUOTENAME(@CurrentEntityTable + N'_AN'), N' an  
INNER JOIN @RevisionIds r  
ON      an.Version_ID = @Version_ID  
    AND an.Revision_ID = r.ID  
  
-- Model transaction table (will cascade delete to model annotation table)  
DELETE tr  
FROM mdm.tbl_', @Model_ID, N'_TR tr  
INNER JOIN @MemberIds m  
ON tr.Member_ID = m.ID  
WHERE   tr.Version_ID = @Version_ID  
    AND tr.Entity_ID = @CurrentEntityID  
    AND tr.MemberType_ID = ', @MemberType_Leaf);   
  
            EXEC sp_executesql @SQL, N'@Version_ID INT, @CurrentEntityID INT', @Version_ID, @CurrentEntityID;  
  
  
            DELETE FROM #EntityTableNames  
            WHERE ID = @CurrentEntityID;  
        END; -- WHILE  
  
        -- Don't remove empty collection tables if a collections subscription view exists  
        DELETE ei   
        FROM @EntitiesWithCollectionTablesToDrop ei  
        INNER JOIN mdm.tblSubscriptionView sv  
        ON ei.ID = sv.Entity_ID  
        WHERE sv.ViewFormat_ID IN (@ViewFormat_Collection, @ViewFormat_CollectionMembership)  
          
        IF EXISTS (SELECT 1 FROM @EntitiesWithCollectionTablesToDrop)  
        BEGIN  
            EXEC mdm.udpCollectionTablesDrop @EntitiesWithCollectionTablesToDrop  
        END;  
  
        -- Delete orphaned rows from tblFile  
        IF EXISTS (SELECT 1 FROM #FileIDsToDelete)  
        BEGIN  
            DECLARE @File_ID mdm.IdList;  
            INSERT INTO @File_ID  
            SELECT ID FROM #FileIDsToDelete  
  
            EXEC mdm.udpFilesDelete @File_ID = @File_ID, @CorrelationID = @CorrelationID  
        END  
  
        --Commit only if we are not nested    
        IF @TranCounter = 0 COMMIT TRANSACTION;   
    END TRY  
        
    BEGIN CATCH    
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
    
        IF @TranCounter = 0     
            ROLLBACK TRANSACTION;    
        ELSE IF XACT_STATE() <> -1     
            ROLLBACK TRANSACTION TX;    
                
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);    
        RETURN(1);    
            
    END CATCH    
  
    SET NOCOUNT OFF;    
END; --proc
go

