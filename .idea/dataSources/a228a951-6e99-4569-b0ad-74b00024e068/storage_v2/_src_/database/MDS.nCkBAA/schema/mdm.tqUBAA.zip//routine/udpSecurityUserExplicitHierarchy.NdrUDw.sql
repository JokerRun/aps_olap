/*  
Example  : mdm.[udpSecurityUserExplicitHierarchy](2, 1, 6, 1, , @Privilege_ID OUT) --Returns the default privilege for User ID = 2 and Hierarchy ID = 6  
*/  
/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE [mdm].[udpSecurityUserExplicitHierarchy]  
(  
    @User_ID            INT,  
    @Hierarchy_ID       INT,  
    @Privilege_ID       INT OUTPUT,  
    @AccessPermission   TINYINT OUTPUT,  
    @CorrelationID      UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
AS  
BEGIN  
    SELECT @Privilege_ID = ssuh.Privilege_ID, @AccessPermission = ssuh.AccessPermission  
    FROM mdm.viw_SYSTEM_SECURITY_USER_HIERARCHY ssuh  
    WHERE ssuh.User_ID = @User_ID  
        AND ssuh.ID = @Hierarchy_ID;  
  
    SET @Privilege_ID = ISNULL(@Privilege_ID, 1 /*Deny*/);  
END
go

