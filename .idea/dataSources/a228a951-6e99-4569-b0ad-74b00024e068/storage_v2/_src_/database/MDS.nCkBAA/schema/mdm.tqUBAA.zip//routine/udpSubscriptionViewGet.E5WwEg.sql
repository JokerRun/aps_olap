/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
select * from mdm.tblSubscriptionView  
EXEC [mdm].[udpSubscriptionViewGet] @User_ID = 1  
*/  
  
CREATE PROCEDURE [mdm].[udpSubscriptionViewGet]  
(  
    @User_ID        INT,  
    @CorrelationID  UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    SET @User_ID = NULLIF(@User_ID, 0);  
  
    SELECT  
        S.ID                AS View_ID  
        ,S.MUID             AS View_Muid  
        ,S.Name             AS View_Name  
        ,S.Levels           AS View_Levels  
        ,S.ViewFormat_ID    AS View_Format  
        ,S.IncludeSoftDeletedMembers    AS View_IncludeSoftDeletedMembers  
        ,M.ID               AS Model_ID  
        ,M.MUID             AS Model_Muid  
        ,M.Name             AS Model_Name  
        ,E.ID               AS [Entity_ID]  
        ,E.MUID             AS Entity_Muid  
        ,E.Name             AS [Entity_Name]  
        ,MV.ID              AS Version_ID  
        ,MV.MUID            AS Version_Muid  
        ,MV.Name            AS Version_Name  
        ,D.ID               AS DerivedHierarchy_ID  
        ,D.MUID             AS DerivedHierarchy_Muid  
        ,D.Name             AS DerivedHierarchy_Name  
        ,S.[Description]    AS [Description]  
        ,UE.DisplayName     AS CreatedBy  
        ,S.EnterDTM         AS DateCreated  
        ,UC.DisplayName     AS UpdatedBy  
        ,S.LastChgDTM       AS DateUpdated  
  
        ,MVF.ID             AS VersionFlag_ID  
        ,MVF.MUID           AS VersionFlag_Muid  
        ,MVF.Name           AS VersionFlag_Name  
    FROM mdm.tblSubscriptionView S  
        INNER JOIN mdm.tblModel M ON S.Model_ID = M.ID  
        LEFT JOIN mdm.viw_SYSTEM_SECURITY_USER_MODEL SSUM ON S.Model_ID = SSUM.ID AND SSUM.[User_ID] = @User_ID  
        LEFT OUTER JOIN mdm.tblEntity E ON S.[Entity_ID] = E.ID  
        LEFT JOIN mdm.tblModelVersion MV ON S.ModelVersion_ID = MV.ID  
        LEFT OUTER JOIN mdm.tblModelVersionFlag MVF ON S.ModelVersionFlag_ID = MVF.ID  
        LEFT OUTER JOIN mdm.tblDerivedHierarchy D ON S.DerivedHierarchy_ID = D.ID  
        LEFT OUTER JOIN mdm.tblUser UE ON S.EnterUserID = UE.ID  
        LEFT OUTER JOIN mdm.tblUser UC ON S.LastChgUserID = UC.ID  
    WHERE @User_ID IS NULL OR SSUM.Privilege_ID = 5 /*Admin*/  
  
    SET NOCOUNT OFF;  
END;
go

