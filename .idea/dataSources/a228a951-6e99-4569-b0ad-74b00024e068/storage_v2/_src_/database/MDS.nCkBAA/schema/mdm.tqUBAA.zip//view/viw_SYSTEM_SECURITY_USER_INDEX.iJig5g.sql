/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE VIEW [mdm].[viw_SYSTEM_SECURITY_USER_INDEX]  
/*WITH SCHEMABINDING*/  
AS  
WITH allPermissions AS (  
    SELECT  
        User_ID,  
        ID,  
        MIN(Privilege_ID) Privilege_ID,  
        SUM(Distinct(AccessPermission & 0x1)) +  
        SUM(Distinct(AccessPermission & 0x2)) +  
        SUM(Distinct(AccessPermission & 0x4)) AS AccessPermission  
    FROM  
        (  
        SELECT  
            entSec.User_ID,  
            tIdx.ID,  
            Privilege_ID =  
                CASE  
                    WHEN entSec.Privilege_ID = 5 THEN 4 /*Access*/  
                    WHEN entSec.Privilege_ID = 1 /*Deny*/ THEN 1 /*Deny*/  
                END,  
            AccessPermission =  
                CASE  
                    WHEN entSec.Privilege_ID = 5 THEN 7 /*All*/  
                    WHEN entSec.Privilege_ID = 1 /*Deny*/ THEN 0 /*None*/  
                END  
        FROM mdm.tblIndex tIdx  
            INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ENTITY entSec  
            ON tIdx.Entity_ID = entSec.ID  
        ) tSec  
    WHERE  
        Privilege_ID IS NOT NULL  
    GROUP BY  
        User_ID,  
        ID  
)  
SELECT  
    [User_ID],  
    ID,  
    Privilege_ID,  
    CASE Privilege_ID WHEN 4 /*Access*/ THEN AccessPermission ELSE NULL END AccessPermission  
FROM allPermissions  
WHERE Privilege_ID > 1 /*Deny*/
go

