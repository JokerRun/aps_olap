/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE [mdm].[udpUserGroupSave]  
(  
    @SystemUser_ID      INT,  
    @UserGroup_ID       INT = NULL OUTPUT,  
    @UserGroup_MUID     UNIQUEIDENTIFIER = NULL OUTPUT, -- \  
    @SID                NVARCHAR(250) = NULL OUTPUT,    -- / One of these is required  
    @Name               NVARCHAR(355) = NULL,  
    @UserGroupType_ID   TINYINT = NULL,  
    @Status_ID          TINYINT,  
    @Description        NVARCHAR(256) = NULL,  
    @CorrelationID      UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
AS  
BEGIN  
    SET NOCOUNT ON  
  
    DECLARE @GuidEmpty              UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER),  
  
            @Status_Create          INT = 0,  
            @Status_Activate        INT = 1,  
            @Status_Deactive        INT = 2,  
            @Status_Clone           INT = 3,  
  
            @GroupStatus_ID         TINYINT,  
            @GroupStatus_Active     TINYINT = 1,  
            @GroupStatus_Deactive   TINYINT = 2,  
              
            @OldUserGroup_MUID      UNIQUEIDENTIFIER,  
            @OldUserGroup_SID       NVARCHAR(250),  
            @ErrorMessage           NVARCHAR(4000);  
  
    SELECT   
        @UserGroup_MUID = NULLIF(@UserGroup_MUID, @GuidEmpty),  
        @SID = NULLIF(LTRIM(RTRIM(@SID)), N''),  
        @Name = NULLIF(LTRIM(RTRIM(@Name)), N''),  
        @UserGroupType_ID = NULLIF(@UserGroupType_ID, 0),  
        @Description = NULLIF(LTRIM(RTRIM(@Description)), N'');  
  
    SELECT @UserGroup_ID = ID, @OldUserGroup_MUID = MUID, @OldUserGroup_SID = [SID]  
    FROM mdm.tblUserGroup  
    WHERE  
        (@UserGroup_MUID IS NOT NULL OR @SID IS NOT NULL)  
        AND (@Status_ID = @Status_Clone OR @UserGroup_MUID  IS NULL OR MUID = @UserGroup_MUID)  
        AND (@SID IS NULL OR [SID] = @SID);  
  
    -- New group  
    IF @UserGroup_ID IS NULL  
    BEGIN  
        IF @Status_ID = @Status_Activate OR @Status_ID = @Status_Deactive  
        BEGIN  
            RAISERROR('MDSERR500004|The principal cannot be updated because the principal identifier is not valid. The identifier must have an existing GUID, name, or both.', 16, 1);  
            RETURN  
        END  
  
        -- For new group, the name and sid should be unique  
        IF EXISTS(  
            SELECT 1  
            FROM mdm.tblUserGroup  
            WHERE  
                (@SID IS NOT NULL OR @Name IS NOT NULL)  
                AND ((@SID IS NOT NULL AND [SID] = @SID)  
                    OR (@Name IS NOT NULL AND Name = @Name))  
        )  
        BEGIN  
            SELECT  @ErrorMessage = N'MDSERR500015|Name and Security Identifier (SID) combination must be unique for group update, create, and copy operations. Name: {0}, Security Identifier: {1}.|' + REPLACE(@Name, N'|', N'') + '|' + @SID;  
            SET @ErrorMessage = REPLACE(@ErrorMessage, '%', '%%')-- escape out format specifier  
            RAISERROR(@ErrorMessage, 16, 1, @Name, @SID);  
        END  
  
        IF @UserGroup_MUID IS NULL  
        BEGIN  
            IF @Status_ID = @Status_Clone  
            BEGIN  
                RAISERROR('MDSERR500004|The principal cannot be updated because the principal identifier is not valid. The identifier must have an existing GUID, name, or both.', 16, 1);  
                RETURN  
            END  
            ELSE  
            BEGIN  
                SET @UserGroup_MUID = NEWID();  
            END  
        END  
  
        INSERT INTO mdm.tblUserGroup  
        (  
            [UserGroupType_ID],  
            [Status_ID],  
            [Name],  
            [SID],  
            [Description],  
            [EnterUserID],  
            [LastChgUserID],  
            [MUID]  
        )  
        SELECT  
            @UserGroupType_ID,  
            @GroupStatus_Active,  
            @Name,  
            @SID,  
            @Description,  
            @SystemUser_ID,  
            @SystemUser_ID,  
            @UserGroup_MUID  
  
        SET @UserGroup_ID = SCOPE_IDENTITY();  
    END  
    ELSE  
    BEGIN  
        SET @GroupStatus_ID = CASE @Status_ID WHEN @Status_Deactive THEN @GroupStatus_Deactive ELSE @GroupStatus_Active END;  
  
        IF @Status_ID != @Status_Clone OR @UserGroup_MUID IS NULL  
        BEGIN  
            UPDATE tblUserGroup  
            SET Status_ID = @GroupStatus_ID,  
                Name = COALESCE(@Name, Name),  
                UserGroupType_ID = COALESCE(@UserGroupType_ID, UserGroupType_ID),  
                [Description] = COALESCE(@Description,[Description]),  
                LastChgUserID = @SystemUser_ID,  
                LastChgDTM = GETUTCDATE()  
            WHERE ID = @UserGroup_ID  
            SET @UserGroup_MUID = @OldUserGroup_MUID;  
        END  
        ELSE  
        BEGIN  
            UPDATE tblUserGroup  
            SET MUID = @UserGroup_MUID,  
                Status_ID = @GroupStatus_ID,  
                Name = COALESCE(@Name, Name),  
                UserGroupType_ID = COALESCE(@UserGroupType_ID, UserGroupType_ID),  
                [Description] = COALESCE(@Description,[Description]),  
                LastChgUserID = @SystemUser_ID,  
                LastChgDTM = GETUTCDATE()  
            WHERE ID = @UserGroup_ID  
        END  
  
        SET @SID = @OldUserGroup_SID;  
    END  
  
    SET NOCOUNT OFF  
END;
go

