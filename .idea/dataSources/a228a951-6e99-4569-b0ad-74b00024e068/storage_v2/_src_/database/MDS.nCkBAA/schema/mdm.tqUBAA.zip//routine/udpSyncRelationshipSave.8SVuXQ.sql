/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Creates or updates a sync relationship between the given source and target entity versions.  
  
Required user permissions:  
- Sys Admin functional permission  
- Source entity version:  
    -- At least Read permission on the entity and all attributes  
    -- No member permissions (i.e. udfUseMemberSecurity must return 0).  
- Target entity version:   
    -- Model Admin  
    -- Version status must not be Committed.   
  
*/  
CREATE PROCEDURE mdm.udpSyncRelationshipSave  
(  
     @User_ID               INT -- Must have permission to create an entity on the target model and at least read permission on all source entity objects (metadata and master data)  
    ,@SourceModel_MUID      UNIQUEIDENTIFIER = NULL -- Source Model name and/or muid is required.  
    ,@SourceModelName       NVARCHAR(50) = NULL  
    ,@SourceVersion_MUID    UNIQUEIDENTIFIER = NULL -- Source Version name and/or muid is required.  
    ,@SourceVersionName     NVARCHAR(50) = NULL  
    ,@SourceEntity_MUID     UNIQUEIDENTIFIER = NULL -- Source Entity name and/or muid is required.  
    ,@SourceEntityName      NVARCHAR(50) = NULL  
    ,@TargetModel_MUID      UNIQUEIDENTIFIER = NULL -- Target Model name and/or muid is required.  
    ,@TargetModelName       NVARCHAR(50) = NULL  
    ,@TargetVersion_MUID    UNIQUEIDENTIFIER = NULL -- Target Version name and/or muid is required.  
    ,@TargetVersionName     NVARCHAR(50) = NULL  
    ,@TargetEntity_MUID     UNIQUEIDENTIFIER = NULL -- when NULL, a random MUID will be generated  
    ,@TargetEntityName      NVARCHAR(50) = NULL -- when NULL, the target entity will have the same name as the source entity.  
    ,@FrequencyInHours      INT = NULL -- If NULL, syncs will only happen on-demand rather than automatically on at a regular interval.  
    ,@CorrelationID         UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS N'mds_schema_user'      
AS  
BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE   
         @SourceModel_ID    INT  
        ,@SourceVersion_ID  INT  
        ,@SourceEntity_ID   INT  
        ,@TargetModel_ID    INT  
        ,@TargetVersion_ID  INT  
        ,@TargetEntity_ID   INT  
  
        ,@MemberType_Leaf   TINYINT  = 1  
  
        ,@PermissionType_Deny           TINYINT = 1  
        ,@PermissionType_Admin          TINYINT = 5  
  
        ,@FunctionalPrivilege_SysAdmin  TINYINT = 5  
  
        ,@TransactionLogType_None       TINYINT = 3  
  
    ;  
  
    SET @TargetEntity_MUID = NULLIF(@TargetEntity_MUID, 0x0);  
    IF @FrequencyInHours <= 0  
    BEGIN  
        SET @FrequencyInHours = NULL;  
    END  
  
    -- Lookup source model ID  
    EXEC mdm.udpInformationLookupModel @User_ID = @User_ID, @Model_MUID = @SourceModel_MUID, @Model_Name = @SourceModelName, @ID = @SourceModel_ID OUTPUT ;  
    IF @SourceModel_ID IS NULL  
    BEGIN  
        -- Either the model doesn't exist, or the user doesn't have permission to see it.  
        RAISERROR('MDSERR200200|Sync source model ID is not valid', 16, 1);  
        RETURN;  
    END;  
  
    -- Lookup source version ID. Note: not using udpInformationLookupVersion to avoid needlessly querying the model security view again.  
    SELECT @SourceVersion_ID = ID  
    FROM mdm.tblModelVersion   
    WHERE  
            (@SourceVersion_MUID IS NOT NULL OR @SourceVersionName IS NOT NULL)   
        AND (@SourceVersion_MUID IS NULL OR MUID = @SourceVersion_MUID)   
        AND (@SourceVersionName IS NULL OR Name = @SourceVersionName)  
        AND Model_ID = @SourceModel_ID;  
    IF @SourceVersion_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR200201|Sync source version ID is not valid', 16, 1);  
        RETURN;  
    END;  
  
    -- Lookup source entity ID  
    EXEC mdm.udpInformationLookupEntity @User_ID = @User_ID, @Model_ID = @SourceModel_ID, @Entity_MUID = @SourceEntity_MUID, @Entity_Name = @SourceEntityName, @ID = @SourceEntity_ID OUTPUT, @Name = @SourceEntityName OUTPUT, @MUID = @SourceEntity_MUID OUTPUT;  
    IF @SourceEntity_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR200202|Sync source entity ID is not valid', 16, 1);  
        RETURN;  
    END;  
  
    -- Ensure the source entity version is not the target of another sync relationship (the user should copy the original source entity, not try to copy the copy).   
    IF EXISTS(SELECT 1  
              FROM mdm.tblSyncRelationship  
              WHERE TargetEntity_ID = @SourceEntity_ID  
                AND TargetVersion_ID = @SourceVersion_ID)  
    BEGIN  
        RAISERROR('MDSERR200203|Sync source entity is not valid. It is a target entity in another sync relationship.', 16, 1);  
        RETURN;  
    END  
  
    -- Lookup target model ID and verify user is model admin  
    DECLARE @TargetModelPrivilege_ID TINYINT  
    EXEC mdm.udpInformationLookupModel @User_ID = @User_ID, @Model_MUID = @TargetModel_MUID, @Model_Name = @TargetModelName, @ID = @TargetModel_ID OUTPUT, @Privilege_ID = @TargetModelPrivilege_ID OUTPUT;  
    IF @TargetModel_ID IS NULL OR COALESCE(@TargetModelPrivilege_ID, @PermissionType_Deny) <> @PermissionType_Admin  
    BEGIN  
        -- Either the model doesn't exist, or the user doesn't have permission to see it.  
        RAISERROR('MDSERR200204|Sync target model ID is not valid or the user does not have sufficient permission.', 16, 1);  
        RETURN;  
    END;  
  
    -- Lookup target version ID. Note: not using udpInformationLookupVersion to avoid needlessly querying the model security view again.  
    SELECT @TargetVersion_ID = ID  
    FROM mdm.tblModelVersion   
    WHERE  
            (@TargetVersion_MUID IS NOT NULL OR @TargetVersionName IS NOT NULL)   
        AND (@TargetVersion_MUID IS NULL OR MUID = @TargetVersion_MUID)   
        AND (@TargetVersionName IS NULL OR Name = @TargetVersionName)  
        AND Model_ID = @TargetModel_ID;  
    IF @TargetVersion_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR200205|Sync target version ID is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    -- Ensure source and target models are different.  
    IF @SourceModel_ID = @TargetModel_ID  
    BEGIN  
        RAISERROR('MDSERR200206|Sync source and target models must be different.', 16, 1);  
        RETURN;  
    END  
  
    -- Lookup target entity ID, if provided  
    IF (@TargetEntity_MUID IS NOT NULL OR @TargetEntityName IS NOT NULL)  
    BEGIN  
        EXEC mdm.udpInformationLookupEntity @User_ID = @User_ID, @Model_ID = @TargetModel_ID, @Entity_MUID = @TargetEntity_MUID, @Entity_Name = @TargetEntityName, @ID = @TargetEntity_ID OUTPUT--, @Name = @TargetEntityName OUTPUT, @MUID = @TargetEntity_MUID OUTPUT;  
        IF @TargetEntity_ID IS NULL  
        BEGIN  
            IF (@TargetEntityName IS NULL)  
            BEGIN  
                -- Create new entity with specified MUID and source's name  
                SET @TargetEntityName = @SourceEntityName;  
            END ELSE  
            BEGIN  
                -- Create new entity with specified Name and random MUID  
                SET @TargetEntity_MUID = NEWID();  
            END  
        END;  
    END ELSE  
    BEGIN  
        -- No target entity id or name provided. Use the source entity's name.  
  
        -- See if the target model already has an entity with that name  
        SET @TargetEntityName = @SourceEntityName;  
        EXEC mdm.udpInformationLookupEntity @User_ID = @User_ID, @Model_ID = @TargetModel_ID, @Entity_Name = @TargetEntityName, @ID = @TargetEntity_ID OUTPUT, @MUID = @TargetEntity_MUID OUTPUT;  
        IF @TargetEntity_ID IS NULL  
        BEGIN  
            -- Create new entity with random MUID  
            SET @TargetEntity_MUID = NEWID();  
        END;  
    END;  
  
    -- If other version(s) of the target entity is/are the target(s) other sync relationship(s), verify the new source entity is the same as the other source entities (can be same or different versions of the source entities)  
    IF @TargetEntity_ID IS NOT NULL AND  
        EXISTS (SELECT 1   
                FROM mdm.tblSyncRelationship  
                WHERE   TargetEntity_ID = @TargetEntity_ID  
                    AND SourceEntity_ID <> @SourceEntity_ID  
               )  
    BEGIN  
        RAISERROR('MDSERR200207|The target entity already has a sync relationship with a different source entity.', 16, 1);  
        RETURN;  
    END;  
  
    DECLARE @TargetEntityNameIsAliased BIT = CASE WHEN @SourceEntityName = @TargetEntityName THEN 0 ELSE 1 END;  
  
    --Start transaction, being careful to check if we are nested  
    DECLARE @TranCounter INT = @@TRANCOUNT;  
    IF @TranCounter > 0 SAVE TRANSACTION TX;  
    ELSE BEGIN TRANSACTION;  
  
    BEGIN TRY  
  
        DECLARE   
             @OldSourceEntity_ID INT  
            ,@OldSourceVersion_ID INT;  
  
        -- Create the entity, if it doesn't already exist. Note: the sync process will ensure the target entity matches the source (including creating attributes). But the entity  
        -- must be added here because of the FK relationship (tblSyncRelationship.TargetEntity_ID => tblEntity.ID)  
        IF @TargetEntity_ID IS NULL  
        BEGIN  
            -- Get source entity properties to be copied  
            DECLARE   
                 @Description       NVARCHAR(500)  
                ,@IsBase            BIT  
                ,@DataCompression   TINYINT  
                ,@EditMode_Create   TINYINT = 0  
                ,@EnterDTM          DATETIME2(3)  
                ,@EnterUserID       INT  
                ;  
  
            SELECT  
                 @Description = [Description]  
                ,@IsBase = IsBase  
                ,@DataCompression = DataCompression  
                ,@EnterDTM = EnterDTM  
                ,@EnterUserID  = EnterUserID  
            FROM mdm.tblEntity  
            WHERE ID = @SourceEntity_ID  
  
PRINT CONCAT(SYSDATETIME(), N': Creating TargetEntity ''', @TargetEntityName, N'''');  
            EXEC mdm.udpEntitySave   
                 @User_ID = @User_ID  
                ,@Model_ID = @TargetModel_ID  
                ,@Entity_MUID = @TargetEntity_MUID  
                ,@EntityName = @TargetEntityName  
                ,@Description = @Description  
                ,@IsBase = @IsBase  
                ,@StagingBase = NULL -- Let a unique StagingBase be auto-generated  
                ,@CodeGenSeed = NULL -- Do not copy source entity CodeGenSeed. Only sync will be adding members to this entity, so automatic member code generation is N/A  
                ,@EditMode = @EditMode_Create  
                ,@DataCompression = @DataCompression  
                ,@TransactionLogType = @TransactionLogType_None  
                ,@IsSync = 1  
                ,@RecreateStagingProc = 0 -- For efficiency, will update the sproc only after all entity and attribute metadata changes have been made  
                ,@Return_ID = @TargetEntity_ID OUTPUT  
                ;  
PRINT CONCAT(SYSDATETIME(), N': Created TargetEntity ''', @TargetEntityName, N''' (ID = ', @TargetEntity_ID, N')');  
  
            -- Update created entity's audit info to match source entity  
            UPDATE mdm.tblEntity  
            SET  EnterDTM = @EnterDTM  
                ,EnterUserID  = @EnterUserID  
            WHERE ID = @TargetEntity_ID  
  
			-- Update the system Attributes properties  
			UPDATE tgt  
			SET ChangeTrackingGroup = src.ChangeTrackingGroup  
			,DisplayName = src.DisplayName  
			,Description = src.Description  
			,SortOrder = src.SortOrder  
			FROM mdm.tblAttribute src  
			INNER JOIN mdm.tblAttribute tgt  
			ON src.Entity_ID = @SourceEntity_ID  
			AND tgt.Entity_ID = @TargetEntity_ID  
			AND src.MemberType_ID = tgt.MemberType_ID  
			AND src.Name = tgt.Name  
			AND src.Name IN (N'Name', N'Code')  
  
        END ELSE -- create entity  
        BEGIN  
  
            -- The target entity already exists. It may-or-may-not be a target in an existing relationship. If so, update the sync table.  
            DECLARE @OldSource TABLE  
            (  
                 SourceEntity_ID INT  
                ,SourceVersion_ID INT  
            );  
  
            -- update the sync table  
            UPDATE mdm.tblSyncRelationship  
            SET  
                 SourceEntity_ID = @SourceEntity_ID  
                ,SourceVersion_ID = @SourceVersion_ID  
                ,TargetEntityNameIsAliased = @TargetEntityNameIsAliased  
                ,RefreshFrequencyInHours = @FrequencyInHours  
                ,LastChgDTM = GETUTCDATE()  
                ,LastChgUserID = @User_ID  
  
                -- If changing the target's source, clear out the last sync columns, otherwise leave unchanged.  
                ,LastSuccessfulSyncTimestamp = CASE WHEN SourceVersion_ID <> @SourceVersion_ID OR SourceEntity_ID <> @SourceEntity_ID THEN NULL ELSE LastSuccessfulSyncTimestamp END  
                ,LastSuccessfulSyncDTM = CASE WHEN SourceVersion_ID <> @SourceVersion_ID OR SourceEntity_ID <> @SourceEntity_ID THEN NULL ELSE LastSuccessfulSyncDTM END  
            OUTPUT   
                 deleted.SourceEntity_ID, deleted.SourceVersion_ID INTO @OldSource  
            WHERE   TargetEntity_ID = @TargetEntity_ID  
                AND TargetVersion_ID = @TargetVersion_ID  
  
            SELECT TOP 1 -- there should never be more than one row in the table  
                 @OldSourceEntity_ID = SourceEntity_ID  
                ,@OldSourceVersion_ID = SourceVersion_ID  
            FROM @OldSource;  
  
        END; -- update sync table  
  
        IF @OldSourceEntity_ID IS NULL  
        BEGIN  
            -- Existing row wasn't found, insert new row  
            INSERT INTO mdm.tblSyncRelationship  
            (  
                 SourceEntity_ID  
                ,SourceVersion_ID  
                ,TargetEntity_ID  
                ,TargetVersion_ID  
                ,TargetEntityNameIsAliased  
                ,RefreshFrequencyInHours  
                ,EnterUserID  
                ,LastChgUserID  
            )  
            VALUES  
            (  
                 @SourceEntity_ID  
                ,@SourceVersion_ID  
                ,@TargetEntity_ID  
                ,@TargetVersion_ID  
                ,@TargetEntityNameIsAliased  
                ,@FrequencyInHours  
                ,@User_ID  
                ,@User_ID  
            );  
        END;  
  
        IF     @OldSourceEntity_ID IS NULL   
            OR @OldSourceEntity_ID <> @SourceEntity_ID   
            OR @OldSourceVersion_ID <> @SourceVersion_ID  
        BEGIN  
            -- A new source was added (either changing an existing sync relationship or adding a new one). The EN table needs to be changed  
            -- Add/clear Source_ID column  
            DECLARE   
                 @TargetEntity_EN_TableName SYSNAME  
                ,@TargetEntity_DataCompression TINYINT  
                ,@Source_IDColumnName SYSNAME = N'Source_ID'  
                ,@Source_LastChgTSColumnName sysname = N'Source_LastChgTS'  
                ,@SQL NVARCHAR(MAX);  
  
            SELECT   
                 @TargetEntity_EN_TableName = EntityTable  
                ,@TargetEntity_DataCompression = DataCompression  
            FROM mdm.tblEntity   
            WHERE ID = @TargetEntity_ID;  
  
            DECLARE @Table_ID INT = (SELECT object_id FROM sys.tables WHERE name = @TargetEntity_EN_TableName and schema_id = schema_id('mdm'));  
            IF EXISTS(SELECT 1 FROM sys.columns c  
                          WHERE name = @Source_IDColumnName  
                            AND c.object_id = @Table_ID)  
            BEGIN  
                -- The Source_ID column already exists, so just clear it out (but only for the specified target version).  
PRINT CONCAT(SYSDATETIME(), N': Clearing sync columns in table ', @TargetEntity_EN_TableName)  
                SET @SQL = CONCAT(N'  
UPDATE mdm.', QUOTENAME(@TargetEntity_EN_TableName), N'  
SET ', QUOTENAME(@Source_IDColumnName), N' = NULL  
    ,', QUOTENAME(@Source_LastChgTSColumnName), N' = NULL  
WHERE Version_ID = @TargetVersion_ID');  
            END ELSE  
            BEGIN  
                -- The Source_ID column does not exist, so create it.  
PRINT CONCAT(SYSDATETIME(), N': Adding sync columns to table mdm.', @TargetEntity_EN_TableName)  
                DECLARE   
                     @Source_IDIndexName sysname = CONCAT('ix_', @TargetEntity_EN_TableName, N'_Version_ID_', @Source_IDColumnName, N'_', @Source_LastChgTSColumnName)  
                    ,@IndexOptions NVARCHAR(MAX) = mdm.udfGetIndexOptions(@TargetEntity_DataCompression, @TargetModel_ID);  
  
                SET @SQL = CONCAT(N'  
ALTER TABLE mdm.', QUOTENAME(@TargetEntity_EN_TableName), N' ADD ', QUOTENAME(@Source_IDColumnName), N' INT NULL;  
ALTER TABLE mdm.', QUOTENAME(@TargetEntity_EN_TableName), N' ADD ', QUOTENAME(@Source_LastChgTSColumnName), N' VARBINARY(8) NULL;  
CREATE NONCLUSTERED INDEX ', QUOTENAME(@Source_IDIndexName), N' ON mdm.', QUOTENAME(@TargetEntity_EN_TableName), N'(Version_ID, ', QUOTENAME(@Source_IDColumnName), N', ', QUOTENAME(@Source_LastChgTSColumnName), N')  
' + @IndexOptions + N';');  
            END;  
            EXEC sp_executesql @SQL, N'@TargetVersion_ID INT', @TargetVersion_ID;  
PRINT CONCAT(SYSDATETIME(), N': Done altering table mdm.', @TargetEntity_EN_TableName)  
  
            -- Copy from source to target entity version. This is inside the IF block because merely updating the sync interval of an existing sync relationship shouldn't trigger a new sync.  
            EXEC mdm.udpSyncRefresh @User_ID = @User_ID, @TargetModel_ID = @TargetModel_ID, @TargetVersion_ID = @TargetVersion_ID, @TargetEntity_ID = @TargetEntity_ID, @CorrelationID = @CorrelationID;  
        END;  
  
  
        --Commit only if we are not nested  
        IF @TranCounter = 0 COMMIT TRANSACTION;  
  
    END TRY  
    --Compensate as necessary  
    BEGIN CATCH  
  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        IF @TranCounter = 0 ROLLBACK TRANSACTION;  
        ELSE IF XACT_STATE() <> -1 ROLLBACK TRANSACTION TX;  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
    END CATCH;  
  
    SET NOCOUNT OFF;  
END -- Proc
go

