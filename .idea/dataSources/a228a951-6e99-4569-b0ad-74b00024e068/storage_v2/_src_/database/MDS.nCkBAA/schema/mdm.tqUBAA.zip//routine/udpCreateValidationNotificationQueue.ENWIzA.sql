/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpCreateValidationNotificationQueue  
(  
    @Notifications [mdm].[NotificationQueue] READONLY  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE @Notif_ID               UNIQUEIDENTIFIER,  
            @NotificationType_ID    INT,  
            @Validation_ID          INT,  
            @VersionName            NVARCHAR(100),  
            @Version_MUID           UNIQUEIDENTIFIER,  
            @Version_ID             INT,  
            @ModelName              NVARCHAR(100),  
            @Model_MUID             UNIQUEIDENTIFIER,  
            @Model_ID               INT,  
            @EntityName             NVARCHAR(100),  
            @Entity_MUID            UNIQUEIDENTIFIER,  
            @Entity_ID              INT,  
            @Member_ID              INT,  
            @MemberCode             NVARCHAR(250),  
            @MemberType_ID          TINYINT,  
            @RuleConditionText      NVARCHAR(MAX),  
            @RuleActionText         NVARCHAR(MAX),  
            @RuleElseActionText     NVARCHAR(MAX),  
            @BRBusinessRule_ID      INT,  
            @PriorityRank           NVARCHAR(250),  
            @EnterDTM               DATETIME2(3),  
            @EnterUserID            INT,  
            @DueDTM                 DATETIME2(3),  
            @SentDTM                DATETIME2(3),  
            @Message                NVARCHAR(MAX);  
  
    DECLARE @NotificationIds TABLE(Notification_ID INT, NotificationUserID INT, NotificationGroupID INT);  
    DECLARE @tempNotifs mdm.[NotificationQueue];  
    INSERT INTO @tempNotifs  
    SELECT * -- Using "SELECT *" is usually a bad idea, but in this case it is more robust because both the source and destination table are of the same table type. If/when the type schema changes, this code will continue to work as-is. But if instead it were to specify the columns, this code could be broken.  
    FROM @Notifications;  
  
    WHILE EXISTS(SELECT TOP 1 ID FROM @tempNotifs)  
    BEGIN  
        SELECT TOP 1 @Notif_ID = ID, @NotificationType_ID = NotificationType_ID, @Validation_ID = NotificationSourceID, @Model_ID = Model_ID, @Version_ID = Version_ID, @Entity_ID = Entity_ID,  
            @Member_ID = Member_ID, @MemberCode = MemberCode, @MemberType_ID = MemberType_ID, @RuleConditionText = RuleConditionText, @RuleActionText = RuleActionText, @RuleElseActionText = RuleElseActionText,  
            @BRBusinessRule_ID = BRBusinessRule_ID, @PriorityRank = PriorityRank, @EnterDTM = EnterDTM, @EnterUserID = EnterUserID,  
            @DueDTM = DueDTM, @SentDTM = SentDTM FROM @tempNotifs;  
  
        DECLARE @NotificationUserID INT = (SELECT NotificationUserID FROM mdm.tblBRBusinessRule WHERE ID = @BRBusinessRule_ID);  
        DECLARE @NotificationGroupID INT = (SELECT NotificationGroupID FROM mdm.tblBRBusinessRule WHERE ID = @BRBusinessRule_ID);  
  
        SELECT @ModelName = Name, @Model_MUID = MUID FROM mdm.tblModel WHERE ID = @Model_ID  
        SELECT @VersionName = Name, @Version_MUID = MUID FROM mdm.tblModelVersion WHERE ID = @Version_ID;  
        SELECT @EntityName = Name, @Entity_MUID = MUID FROM mdm.tblEntity WHERE ID = @Entity_ID;  
  
        DECLARE @toUTCMinutes INT = DATEDIFF(MINUTE,GETDATE(),GETUTCDATE());  
        DECLARE @sign CHAR(1) = NULL;  
        IF (@toUTCMinutes > 0) SET @sign = '+';  
        DECLARE @toUTC NVARCHAR(20) = CONCAT('UTC',@sign,@toUTCMinutes/60,':', @toUTCMinutes%60);  
  
        SET @Message = CONCAT(N'  
            <notification>  
              <id>', @Validation_ID, N'</id>  
              <model>', (SELECT @ModelName FOR XML PATH('')), N'</model>  
              <model_muid>', @Model_MUID, N'</model_muid>  
              <version>', (SELECT @VersionName FOR XML PATH('')), N'</version>  
              <version_muid>' , @Version_MUID, N'</version_muid>  
              <entity>', (SELECT @EntityName FOR XML PATH('')), N'</entity>  
              <entity_muid>', @Entity_MUID, N'</entity_muid>  
              <member_code>', (SELECT @MemberCode FOR XML PATH('')), N'</member_code>                
              <member_type_id>', @MemberType_ID, N'</member_type_id>  
              <condition_text>', (SELECT @RuleConditionText FOR XML PATH('')), N'</condition_text>  
              <action_text>', (SELECT @RuleActionText FOR XML PATH('')), N'</action_text>  
              <elseaction_text>', (SELECT @RuleElseActionText FOR XML PATH('')), N'</elseaction_text>  
              <priority>', @PriorityRank, N'</priority>  
              <issued>', (SELECT CONVERT(NVARCHAR,GETDATE()) FOR XML PATH('')), N'</issued>  
            </notification>');  
  
        INSERT INTO mdm.tblNotificationQueue(  
            [NotificationType_ID],  
            [Version_ID],  
            [Model_ID],  
            [Entity_ID],  
            [Member_ID],  
            [MemberType_ID],  
            [Message],  
            [BRBusinessRule_ID],  
            [PriorityRank],  
            [EnterDTM],  
            [EnterUserID],  
            [DueDTM],  
            [SentDTM]  
        ) VALUES (  
            @NotificationType_ID,  
            @Version_ID,  
            @Model_ID,  
            @Entity_ID,  
            @Member_ID,  
            @MemberType_ID,  
            @Message,  
            @BRBusinessRule_ID,  
            @PriorityRank,  
            @EnterDTM,  
            @EnterUserID,  
            @DueDTM,  
            @SentDTM);  
  
        DECLARE @insertedID INT = @@IDENTITY;  
        INSERT INTO @NotificationIds VALUES(@insertedID, @NotificationUserID, @NotificationGroupID);  
  
    DELETE FROM @tempNotifs WHERE ID = @Notif_ID;  
    END  
  
    -- Write rows to tblNotificationUser, one row per validation issue per user that will be notified.  
    INSERT INTO mdm.tblNotificationUsers  
    (  
        Notification_ID  
        ,User_ID  
    )  
    SELECT  
        n.Notification_ID  
        ,COALESCE(u.ID, ug.User_ID)  
    FROM @NotificationIds n  
        LEFT JOIN mdm.tblUser u ON n.NotificationUserID = u.ID  
        LEFT JOIN mdm.viw_SYSTEM_USERGROUP_USERS ug ON n.NotificationGroupID = ug.UserGroup_ID;  
  
    SET NOCOUNT OFF;  
END; --proc
go

