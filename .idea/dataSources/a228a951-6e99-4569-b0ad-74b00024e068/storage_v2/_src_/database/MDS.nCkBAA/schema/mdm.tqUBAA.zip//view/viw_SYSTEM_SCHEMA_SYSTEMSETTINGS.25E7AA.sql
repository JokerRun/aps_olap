/*  
	SELECT * FROM mdm.viw_SYSTEM_SCHEMA_SYSTEMSETTINGS  
*/  
/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE VIEW mdm.viw_SYSTEM_SCHEMA_SYSTEMSETTINGS  
/*WITH SCHEMABINDING*/  
AS  
SELECT  
    sys.ID  
    ,sys.MUID  
    ,sys.SettingName  
    ,sys.DisplayName  
    ,sys.Description  
    ,sys.SettingType_ID  
    ,[SettingType_Name] =   
        CASE sys.SettingType_ID  
        WHEN 1 THEN N'Freeform'  
        WHEN 2 THEN N'Domain'  
        WHEN 3 THEN N'System'  
        WHEN 4 THEN N'File'  
        END  
  
    ,sys.DataType_ID  
    ,[DataType_Name] =     CASE sys.DataType_ID  
        WHEN 1  THEN N'Text'  
        WHEN 2  THEN N'Number'  
        WHEN 3  THEN N'DateTime'  
        WHEN 6  THEN N'Link'  
        END  
    ,[SettingValue] = sys.SettingValue  
    ,[SettingValueDomainName] = sys.ListCode  
    ,[MinValue] = sys.MinValue  
    ,[MaxValue] = sys.MaxValue  
    ,sys.IsVisible  
    ,sys.DisplaySequence  
    ,sys.SystemSettingGroup_ID  
  
FROM mdm.tblSystemSetting sys
go

