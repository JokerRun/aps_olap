/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Converts deprecated collection members and consolidated members to leaf members. Also converts their corresponding deprecated explicit hierarchies (EH)   
to recursive derived hierarchies (RDH).  
  
Conversion process:  
  
Converting Consolidated members and EHs  
----------------------------------------  
Suppose there is an entity named Product that contains the following EHs:  
   EH Name          Mandatory EH?  
  *********        ***************  
   Bundle               Yes  
   NonMandatory         No  
  
- Create one new entity per EH. The name of the new entity is "<Leaf entity name>_<EH name>". In the above example, two new entities will be created, "Product_Bundle" and "Product_NonMandatory".  
    -- Copy consolidated attributes from original EH's entity to leaf attributes on each new entity.  
    -- Copy all consolidated members of the EH to leaf members on the corresponding new entity. For mandatory hierarchies that have leaf members directly under ROOT, add a "Pseudo Root" member. For  
       non-mandatory EHs that have unassigned leaf members, leave them as-is.  
    -- Add a new self-referencing DBA, named "Parent", to the new entity and set its value to reflect the original consolidated member's parent in the EH.  
- Create new DBAs on the original entity, one per EH on the entity. The name of each DBA will be the EH name. In the above example, two DBAs will be added to the Product entity: Bundle (which   
  references Product_Bundle as its domain entity) and NonMandatory (which references Product_NonMandatory). The value of these DBAs is set to reflect each leaf member's parent  
  in the EH being copied.  
- Copy transactions. EH parent/sibling move transactions are converted to attribute value change transactions. If the @DeleteOriginals flag is set, the original  
  transaction rows will be updated, rather than copied, for efficiency. Otherwise, transaction annotations are also copied.  
- Create one new RDH per EH. Each RDH will have a single non-recursive level beneath the recursive levels. The name of the RDH will be the same as the EH, if that name is  
  not already being used by another DH in the same model. Otherwise, it will follow the same pattern as the new entity names, i.e. "<Leaf entity name>_<EH name>", or   
  "Product_Bundle" and "Product_NonMandatory" in the above example.  
- For each existing DH with an EH cap, create a new RDH with (potentially) multiple levels below. The name of the new hierarchy will be "<EH cap DH name>_NoCap".  
- Copy business rules (BR), both rules that applied to the consolidated members being copied and leaf rules that were referencing consolidated parent attributes. In both cases, the consolidated parent  
  attribute references are converted to instead apply to the attributes of the new entities.  
  
Converting Collections.   
For each entity with collection member(s):  
----------------------------------------  
- Create a new entity "<entity name>_Col". This corresponds to the deprecated "%_CN" table.  
    -- Copy collection attributes from original entity to leaf attributes on the new entity  
    -- Copy collection members from original entity to leaf members on then new entity  
- Create new entity "<entity name>_ColMem" to track collection membership info. This corresponds to the deprecated "%_CM" table.  
    -- Add parent DBA, "Parent_<entity name>_Col", that will reference the parent "collection"  
    -- Add child DBAs, that correspond to collection members (exactly one will have a non-null value, per member):  
        -- "Child_<entity name>" for leaf members of the collection. References the original entity.  
        -- "Child_<entity name>_Col" for collection members of the collection  
        -- "Child_<EH name>", one per EH on the original entity, for consolidated members of the collection  
    -- Add attributes for "%_CM" table columns Weight and SortOrder  
    -- Create new members, one for each "%_CM" table row  
- Copy collection member transactions. If the @DeleteOriginals flag is set, the original transaction rows will be updated,   
  rather than copied, for efficiency. Otherwise, transaction annotations are also copied.  
- Create one DH per child type (Leaf, Collection, and one per EH). Each DH has two levels. The bottom level is the child entity. The top is a   
  Many-To-Many level that maps collection parents to children. There has to be one DH per child type because each child type is copied to its   
  own entity.  
  
Additional steps  
----------------------------------------  
- Copy consolidated and collection attribute groups to leaf attribute groups on their corresponding new entities.  
- Copy consolidated and collection subscription views (SV)  
        Old ViewFormat_ID            Deprecated?    New ViewFormat_ID  
       *******************          *************  *******************  
        1 (Leaf members)                No          unchanged  
        2 (Consolidated members)       Yes          1 (Leaf members)   
        3 (Collection members)         Yes          1 (Leaf members)  
        4 (Collection membership)      Yes          1 (Leaf members, on the mapping entity)  
        5 (Explicit Parent-Child)      Yes          7 (Derived Parent-Child)  
        6 (Explicit levels)            Yes          8 (Derived levels)  
        7 (Derived Parent-Child)        No          unchanged  
        8 (Derived levels)              No          unchanged  
        9 (Leaf history)                No          unchanged  
       10 (Consolidated history)       Yes          9 (Leaf history)  
       11 (Collection history)         Yes          9 (Leaf history)  
       12 (Leaf Type2)                  No          unchanged  
       13 (Consolidated Type2)         Yes          12 (Leaf Type2)  
       14 (Collection Type2)           Yes          12 (Leaf Type2)  
    For the consolidated-related SVs (ViewFormat_ID 2, 5, and 6) there is a one-to-many mapping. One new SV is created per EH. To disambiguate them, the EH   
    name is appended to the SV name.  
- Security permissions  
    -- Copy model object permissions from old entity and its consolidated and collection member types, attributes, and attribute groups, to their corresponding new entity objects.  
    -- Copy member permissions from old EHs to new RDHs (collections and DHs with an EH cap cannot be used for member security, so they will have no permissions to copy).  
- If the @DeleteOriginals flag is set, delete the originals of the copied items.  
- Kick off the service broker to process member security.  
  
Additional notes:  
1. EH child sort order info, as stored in the "%_HR" table's SortOrder column, is lost. Derived Hierarchies do not support child sort order.  
2. All copied/converted BRs are left in an unpublished state. The user must manually publish these rules, if desired, after running this script (the publish process can only be executed from the web service API, not from SQL)  
3. Validation issues (as stored in tables tbl_{MID}_VL, tbl_{MID}_VLH)) are not copied. They can be regenerated after BRs are published.  
4. The copy process checks for and handles any naming conflicts that would violate uniqueness constraints. For example, if the script tries to create a new entity named "Product_Bundle", but that   
   name is already used by another entity within the model, then it will try to use "Product_Bundle1" for the new entity name. If that name is already taken, then it will try   
   "Product_Bundle2", and so on.  
5. The copy process preserves original audit info (i.e. created/lastChanged userID/dateTime, etc) for copied items (i.e. master data, DH levels, security permissions, transactions, business rules, etc).  
*/  
CREATE PROCEDURE mdm.udpConvertCollectionAndConsolidatedMembersToLeaf  
(  
     @Model_ID          INT = NULL -- Optional filter. When provided, only EHs and Collections within the specified model will be operated on.  
    ,@Entity_ID         INT = NULL -- Optional filter. When provided, only EHs and Collections within the specified entity will be operated on.  
    ,@DeleteOriginals   BIT = 1 -- When 0, the sproc is non-destructive. When 1, the sproc deletes the original collections, consolidated members, EHs, etc that are converted.  
    ,@CorrelationID     UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE   
         @User_ID               INT  
  
        ,@EntityTableName_EN                SYSNAME  
        ,@EntityTableName_EN_HS             SYSNAME  
        ,@EntityTableName_EN_AN             SYSNAME  
        ,@EntityTableName_HP                SYSNAME  
        ,@EntityTableName_HP_HS             SYSNAME  
        ,@EntityTableName_HP_AN             SYSNAME  
        ,@EntityTableName_HR                SYSNAME  
        ,@EntityTableName_HR_HS             SYSNAME  
        ,@EntityTableName_HR_AN             SYSNAME  
        ,@NewEntityTableName_EN_HS          SYSNAME  
        ,@NewEntityTableName_EN_AN          SYSNAME  
        ,@EntityTableName_CN                SYSNAME  
        ,@EntityTableName_CN_HS             SYSNAME  
        ,@EntityTableName_CN_AN             SYSNAME  
        ,@EntityTableName_CM                SYSNAME  
        ,@EntityTableName_CM_HS             SYSNAME  
        ,@EntityTableName_CM_AN             SYSNAME  
        ,@TransactionTableName              SYSNAME  
        ,@TransactionAnnotationTableName    SYSNAME  
  
        ,@EntityName            NVARCHAR(50)  
        ,@DataCompression       TINYINT  
        ,@TransactionLogType    TINYINT  
          
        ,@TransactionLogType_Attribute  TINYINT = 1  
        ,@TransactionLogType_Member     TINYINT = 2  
        ,@TransactionLogType_None       TINYINT = 3  
  
        ,@StagingLeafName       SYSNAME  
        ,@ExplicitHierarchy_ID  INT  
        ,@ExplicitHierarchyName NVARCHAR(50)  
        ,@IsMandatory           BIT  
  
        ,@Attribute_ID          INT  
        ,@DisplayName           NVARCHAR(250)  
        ,@Name                  NVARCHAR(100)  
        ,@Description           NVARCHAR(500)  
        ,@AttributeType_ID      TINYINT  
        ,@DataType_ID           TINYINT  
        ,@DataTypeInformation   INT  
        ,@InputMask_ID          INT  
        ,@DisplayWidth          INT  
        ,@SortOrder             INT  
        ,@DomainEntity_ID       INT  
        ,@ChangeTrackingGroup   INT  
  
        ,@EnterDTM              DATETIME2(3)  
        ,@EnterUserID           INT  
        ,@EnterVersionID        INT  
        ,@LastChgDTM            DATETIME2(3)  
        ,@LastChgUserID         INT  
        ,@LastChgVersionID      INT  
  
        ,@NewEntity_ID                  INT  
        ,@NewEntityName                 NVARCHAR(50)  
        ,@NewEntityTableName_EN         SYSNAME  
        ,@NewEntityStagingLeafName      SYSNAME  
        ,@NewEntityDescription          NVARCHAR(500)  
        ,@NewDerivedHierarchy_ID        INT  
        ,@NewDerivedHierarchyName       NVARCHAR(50)  
        ,@NewLevel_ID                   INT  
        ,@counter                       INT  
        ,@suffix                        NVARCHAR(MAX)  
        ,@NewAttribute_ID               INT  
  
        ,@MaxMetadataObjectNameLength   INT = 50 -- except for attributes and DH levels  
        ,@MaxAttributeNameLength        INT = 100  
        ,@MaxHierarchyLevelNameLength   INT = 100  
  
        ,@NewRecursiveAttribute_ID          INT  
        ,@NewRecursiveAttributeName         NVARCHAR(100)  
        ,@NewRecursiveAttribute_ColumnName  SYSNAME  
        ,@NewLeafDba_ID                     INT  
        ,@NewLeafDbaName                    NVARCHAR(100)  
        ,@NewLeafDba_ColumnName             SYSNAME  
        ,@NewLevelName                      NVARCHAR(100)  
        ,@NewAttributeColumnNames           NVARCHAR(MAX) = N''  
        ,@OldAttributeColumnNames           NVARCHAR(MAX) = N''  
  
        ,@FunctionalPrivilege_SuperUser   TINYINT = 6  
  
        ,@HierarchyType_Explicit    TINYINT = 0   
        ,@HierarchyType_Derived     TINYINT = 1  
  
        ,@HierarchyItemType_Entity            TINYINT = 0  
        ,@HierarchyItemType_DBA               TINYINT = 1  
        ,@HierarchyItemType_ExplicitHierarchy TINYINT = 2  
        --,@HierarchyItemType_ConsolidatedDBA   INT = 3 -- Unused.  
        ,@HierarchyItemType_ManyToMany        TINYINT = 5  
  
        ,@MemberType_Leaf                   TINYINT = 1  
        ,@MemberType_Consolidated           TINYINT = 2  
        ,@MemberType_Collection             TINYINT = 3  
        ,@MemberType_ParentChild            TINYINT = 4  
        ,@MemberType_CollectionParentChild  TINYINT = 5  
  
        ,@DataType_Text           TINYINT = 1  
        ,@DataType_Number         TINYINT = 2  
        ,@DataType_DateTime       TINYINT = 3  
        ,@DataType_Link           TINYINT = 6  
  
        ,@AttributeType_Freeform  TINYINT = 1  
        ,@AttributeType_Domain    TINYINT = 2  
        ,@AttributeType_System    TINYINT = 3  
        ,@AttributeType_File      TINYINT = 4  
  
        ,@BRStatus_New                  INT = 0  
        ,@BRStatus_Active               INT = 1  
        ,@BRStatus_Excluded             INT = 2  
        ,@BRStatus_ActivationPending    INT = 3  
        ,@BRStatus_ChangesPending       INT = 4  
        ,@BRStatus_ExcludePending       INT = 5  
        ,@BRStatus_DeletePending        INT = 6  
  
        ,@BRPropertyType_Constant           TINYINT = 1  
        ,@BRPropertyType_Attribute          TINYINT = 2  
        ,@BRPropertyType_ParentAttribute    TINYINT = 3  
        ,@BRPropertyType_DBA                TINYINT = 4  
        ,@BRPropertyType_AttributeValue     TINYINT = 5  
        ,@BRPropertyType_Blank              TINYINT = 6  
  
        ,@ObjectType_Entity             INT = 3  
        ,@ObjectType_Attribute          INT = 4  
        ,@ObjectType_AttributeGroup     INT = 5  
        ,@ObjectType_LeafType           INT = 8  
        ,@ObjectType_ConsolidatedType   INT = 9  
        ,@ObjectType_CollectionType     INT = 10  
  
        ,@TransactionType_CreateMember          TINYINT = 1  
        ,@TransactionType_ChangeMemberStatus    TINYINT = 2  
        ,@TransactionType_SetAttributeValue     TINYINT = 3  
        ,@TransactionType_MoveMemberToParent    TINYINT = 4  
        ,@TransactionType_MoveMemberToSibling   TINYINT = 5  
        ,@TransactionType_AnnotateMember        TINYINT = 6  
  
        ,@ViewFormat_Leaf                   TINYINT = 1  
        ,@ViewFormat_Consolidated           TINYINT = 2  
        ,@ViewFormat_Collection             TINYINT = 3  
        ,@ViewFormat_CollectionMembership   TINYINT = 4  
        ,@ViewFormat_ExplicitParentChild    TINYINT = 5  
        ,@ViewFormat_ExplicitLevels         TINYINT = 6  
        ,@ViewFormat_DerivedParentChild     TINYINT = 7  
        ,@ViewFormat_DerivedLevels          TINYINT = 8  
        ,@ViewFormat_LeafHistory            TINYINT = 9  
        ,@ViewFormat_ConsolidatedHistory    TINYINT = 10  
        ,@ViewFormat_CollectionHistory      TINYINT = 11  
        ,@ViewFormat_LeafType2              TINYINT = 12  
        ,@ViewFormat_ConsolidatedType2      TINYINT = 13  
        ,@ViewFormat_CollectionType2        TINYINT = 14  
  
  
        ,@SQL                           NVARCHAR(MAX)  
  
        -- This pseudo-constant is for use in string concatenation operations to prevent string truncation. When concatenating two or more strings,  
        -- if none of the strings is an NVARCHAR(MAX) or an NVARCHAR constant that is longer than 4,000 characters, then the resulting string   
        -- will be silently truncated to 4,000 characters. Concatenating with this empty NVARCHAR(MAX), is sufficient to prevent truncation.  
        -- See http://connect.microsoft.com/SQLServer/feedback/details/283368/nvarchar-max-concatenation-yields-silent-truncation.  
        ,@TruncationGuard        NVARCHAR(MAX) = N''  
        ;  
  
    DECLARE @HalfMaxLen INT = @MaxMetadataObjectNameLength / 2 - 2;  
  
    -- Get the ID of the first user with super user functional permission. This may seem arbitrary, but that is okay because the resulting audit info  
    -- will be overwritten to match that of the EH being converted.  
    SELECT TOP 1  
        @User_ID = ID  
    FROM mdm.udfSecurityGetUsersByFunction(@FunctionalPrivilege_SuperUser)  
    ORDER BY ID;  
  
  
    BEGIN TRY  
  
        --Start transaction, being careful to check if we are nested.  
        DECLARE @TranCounter INT = @@TRANCOUNT;  
        IF @TranCounter > 0  
        BEGIN  
            SAVE TRANSACTION TX;  
        END ELSE  
        BEGIN  
            BEGIN TRANSACTION;  
        END;  
  
PRINT CONCAT(SYSDATETIME(), N': Getting filtered list of entities to convert.');  
        DECLARE @EntityInfo TABLE  
        (  
             Entity_ID                  INT PRIMARY KEY  
            ,EntityName                 NVARCHAR(50) COLLATE DATABASE_DEFAULT NOT NULL  
            ,Model_ID                   INT NOT NULL  
            ,DataCompression            TINYINT  
            ,TransactionLogType         TINYINT  
            --,RequireApproval            BIT -- Not needed. Only supported for Leaf members  
            ,StagingLeafName            SYSNAME COLLATE DATABASE_DEFAULT  
            ,EntityTableName_EN         SYSNAME COLLATE DATABASE_DEFAULT  
            ,EntityTableName_CN         SYSNAME COLLATE DATABASE_DEFAULT NULL  
            ,EntityTableName_CM         SYSNAME COLLATE DATABASE_DEFAULT NULL   
            ,EntityTableName_HP         SYSNAME COLLATE DATABASE_DEFAULT NULL  
            ,EntityTableName_HR         SYSNAME COLLATE DATABASE_DEFAULT NULL  
            ,New_CN_Entity_ID           INT NULL  
            ,New_CM_Entity_ID           INT NULL  
            ,HasCustomCollectionMetadata BIT NOT NULL DEFAULT 0 -- Zero when there no other user-defined collection metadata (attributes, subscription views).   
            ,HasExplicitHierarchy        BIT NOT NULL DEFAULT 0  
        )  
        INSERT INTO @EntityInfo  
        (  
             Entity_ID  
            ,EntityName  
            ,Model_ID  
            ,DataCompression  
            ,TransactionLogType  
            ,StagingLeafName  
            ,EntityTableName_EN  
            ,EntityTableName_CN  
            ,EntityTableName_CM  
            ,EntityTableName_HP  
            ,EntityTableName_HR  
        )  
        SELECT   
             ID  
            ,Name  
            ,Model_ID  
            ,DataCompression  
            ,TransactionLogType  
            ,StagingLeafName  
            ,EntityTable  
            ,CollectionTable  
            ,CollectionMemberTable  
            ,HierarchyParentTable  
            ,HierarchyTable  
        FROM mdm.tblEntity  
        WHERE   (@Model_ID  IS NULL OR @Model_ID  = Model_ID)  
            AND (@Entity_ID IS NULL OR @Entity_ID = ID)  
        DECLARE @EntityCount INT = COALESCE((SELECT COUNT(1) FROM @EntityInfo), 0);  
PRINT CONCAT(SYSDATETIME(), N': ', @EntityCount, ' entities found.');  
  
  
PRINT CONCAT(SYSDATETIME(), N': Determining whether entities with collection tables have user-defined collection metadata.');  
        UPDATE ei  
        SET HasCustomCollectionMetadata = CASE WHEN COALESCE(a.ID, sv.ID) IS NOT NULL THEN 1 ELSE ei.HasCustomCollectionMetadata END  
        FROM @EntityInfo ei  
        LEFT JOIN mdm.tblAttribute a  
        ON      ei.Entity_ID = a.Entity_ID  
            AND a.IsSystem = 0  
            AND a.MemberType_ID = @MemberType_Collection -- Note: ignoring @MemberType_CollectionParentChild because it cannot have user-defined attributes  
        LEFT JOIN mdm.tblSubscriptionView sv  
        ON      ei.Entity_ID = sv.Entity_ID  
            AND sv.ViewFormat_ID IN (@ViewFormat_Collection, @ViewFormat_CollectionMembership, @ViewFormat_CollectionHistory, @ViewFormat_CollectionType2)  
        WHERE ei.EntityTableName_CN IS NOT NULL  
  
        -- Contains info about the consolidated and collection attributes that will be copied.  
        DECLARE @AttributeInfo TABLE  
        (  
             Attribute_ID           INT PRIMARY KEY  
            ,DisplayName            NVARCHAR(250) COLLATE DATABASE_DEFAULT  
            ,Name                   NVARCHAR(100) COLLATE DATABASE_DEFAULT  
            ,Description            NVARCHAR(500) COLLATE DATABASE_DEFAULT  
            ,ColumnName             SYSNAME COLLATE DATABASE_DEFAULT  
            ,AttributeType_ID       TINYINT  
            ,DataType_ID            TINYINT  
            ,DataTypeInformation    INT  
            ,InputMask_ID           INT  
            ,DisplayWidth           INT  
            ,SortOrder              INT  
            ,DomainEntity_ID        INT  
            ,ChangeTrackingGroup    INT  
        );  
  
        -- Contains a list of derived hierarchies with an explicit cap.  
        DECLARE @ExplicitCapHierarchies TABLE  
        (     
             DerivedHierarchy_ID     INT PRIMARY KEY  
            ,DerivedHierarchyName    NVARCHAR(50) COLLATE DATABASE_DEFAULT  
        );  
  
        CREATE TABLE #EH_ConversionLog  
        (  
             ExplicitHierarchy_ID       INT PRIMARY KEY  
            ,ExplicitHierarchyName      NVARCHAR(50) COLLATE DATABASE_DEFAULT  
            ,Entity_ID                  INT NOT NULL DEFAULT 0  
            ,LeafParentDba_ID           INT -- The ID of the new DBA in the old leaf entity that references the new entity.  
            ,LeafParentDbaName          NVARCHAR(100) COLLATE DATABASE_DEFAULT  
            ,NewEntity_ID               INT -- The ID of the new Entity created to take the place of the EH's consolidated members  
            ,NewDerivedHierarchy_ID     INT -- The ID of the new Derived Hierarchy created to take the place of the EH  
            ,NewEntityRecursiveDba_ID   INT -- The ID of the self-referencing DBA in the new Entity.  
            ,NewEntityRecursiveDbaName  NVARCHAR(100) COLLATE DATABASE_DEFAULT  
        );  
        CREATE INDEX #ix_EH_ConversionLog_Entity_ID ON #EH_ConversionLog(Entity_ID);  
  
        CREATE TABLE #AttributeMapping  
        (  
             OldAttribute_ID    INT --PRIMARY KEY -- Consolidated attribute could be copied to multiple entities, so may not be unique.  
            ,OldMemberType      TINYINT   
            ,OldEntity_ID       INT  
  
            ,NewAttribute_ID    INT  
            ,NewEntity_ID       INT  
        );  
        CREATE CLUSTERED INDEX #ix_AttributeMapping_OldAttribute_ID ON #AttributeMapping(OldAttribute_ID);  
  
        CREATE TABLE #AttributeGroupMapping  
        (  
             OldAttributeGroup_ID   INT --PRIMARY KEY -- Attribute Group could be copied to multiple entities, so may not be unique.  
            ,Entity_ID              INT  
            ,NewAttributeGroup_ID   INT  
            ,NewEntity_ID           INT  
        );  
        CREATE CLUSTERED INDEX #ix_AttributeGroupMapping_OldAttributeGroup_ID ON #AttributeGroupMapping(OldAttributeGroup_ID);  
  
        DECLARE @CollectionMembershipAttributes TABLE  
        (  
             RowID                  INT IDENTITY(1, 1) PRIMARY KEY   
            ,Name                   NVARCHAR(100) COLLATE DATABASE_DEFAULT  
            ,DomainEntity_ID        INT     NULL  
            ,DomainEntityName       NVARCHAR(50) COLLATE DATABASE_DEFAULT  
            ,DomainEntityTableName  SYSNAME COLLATE DATABASE_DEFAULT NULL  
            ,DataTypeInformation    TINYINT NULL  
            ,OldColumnName          SYSNAME COLLATE DATABASE_DEFAULT NULL  
            ,NewAttribute_ID        INT     NULL  
            ,NewColumnName          SYSNAME COLLATE DATABASE_DEFAULT NULL  
        );  
  
  
PRINT CONCAT(SYSDATETIME(), N': Getting Explicit Hierarchies.');  
        -- Get a list of explicit hierarchies that match the given criteria.  
        DECLARE @ExplicitHierarchies TABLE  
        (  
             ExplicitHierarchy_ID   INT PRIMARY KEY  
            ,ExplicitHierarchyName  NVARCHAR(50) COLLATE DATABASE_DEFAULT  
            ,IsMandatory            BIT  
            ,Entity_ID              INT  
            ,EnterDTM               DATETIME2(3)  
            ,EnterUserID            INT  
            ,EnterVersionID         INT  
            ,LastChgDTM             DATETIME2(3)  
            ,LastChgUserID          INT  
            ,LastChgVersionID       INT  
        );  
        INSERT INTO @ExplicitHierarchies  
        SELECT   
             h.ID  
            ,h.Name  
            ,h.IsMandatory  
            ,e.Entity_ID  
            ,h.EnterDTM  
            ,h.EnterUserID  
            ,h.EnterVersionID  
            ,h.LastChgDTM  
            ,h.LastChgUserID  
            ,h.LastChgVersionID  
        FROM mdm.tblHierarchy h  
        INNER JOIN @EntityInfo e  
        ON h.Entity_ID = e.Entity_ID  
  
        UPDATE e  
        SET HasExplicitHierarchy = CASE WHEN eh.ExplicitHierarchy_ID IS NULL THEN 0 ELSE 1 END  
        FROM @EntityInfo e  
        LEFT JOIN @ExplicitHierarchies eh  
        ON e.Entity_ID = eh.Entity_ID  
  
        -- Loop through each entity, and copy its hierarchies  
        DECLARE @TempTimestampColumnName NVARCHAR(50) = N'LastChgTS_Old';  
  
        SET @Entity_ID = 0  
        WHILE EXISTS (SELECT 1 FROM @EntityInfo WHERE Entity_ID > @Entity_ID AND HasExplicitHierarchy = 1)  
        BEGIN  
            SELECT TOP 1  
                 @Entity_ID  = Entity_ID  
                ,@Model_ID = Model_ID  
                ,@DataCompression = DataCompression  
                ,@TransactionLogType = TransactionLogType  
                ,@StagingLeafName = StagingLeafName  
                ,@EntityName = EntityName  
                ,@EntityTableName_EN = EntityTableName_EN  
                ,@EntityTableName_EN_HS = CONCAT(EntityTableName_EN, N'_HS')  
                ,@EntityTableName_EN_AN = CONCAT(EntityTableName_EN, N'_AN')  
                ,@EntityTableName_HP = EntityTableName_HP  
                ,@EntityTableName_HP_HS = CONCAT(EntityTableName_HP, N'_HS')  
                ,@EntityTableName_HP_AN = CONCAT(EntityTableName_HP, N'_AN')  
                ,@EntityTableName_HR = EntityTableName_HR  
                ,@EntityTableName_HR_HS = CONCAT(EntityTableName_HR, N'_HS')  
                ,@EntityTableName_HR_AN = CONCAT(EntityTableName_HR, N'_AN')  
            FROM @EntityInfo  
            WHERE   Entity_ID > @Entity_ID  
                AND HasExplicitHierarchy = 1  
            ORDER BY Entity_ID  
  
            IF @TransactionLogType = @TransactionLogType_Member  
            BEGIN  
                PRINT CONCAT(SYSDATETIME(), N': Adding temporary LastChgTS column to table ', @EntityTableName_EN);  
                -- Before modifying the original EN table, add a column to track the current LastChgDTM. Needed for copying member history from TR_HS to EN_HS table.  
                SET @SQL = CONCAT(N'ALTER TABLE mdm.', QUOTENAME(@EntityTableName_EN), N' ADD ', QUOTENAME(@TempTimestampColumnName), N' BIGINT;');  
                --PRINT @SQL  
                EXEC sp_executesql @SQL;  
                SET @SQL = CONCAT(N'CREATE INDEX ', QUOTENAME(CONCAT(N'ix_', @EntityTableName_EN, N'_Version_ID_', @TempTimestampColumnName)), N' ON mdm.', QUOTENAME(@EntityTableName_EN), N' (Version_ID, ', QUOTENAME(@TempTimestampColumnName), N');');  
                --PRINT @SQL  
                EXEC sp_executesql @SQL;  
            END  
      
            -- Loop through each explicit hierarchy and copy it.  
            SET @ExplicitHierarchy_ID = 0;  
            WHILE EXISTS (SELECT 1 FROM @ExplicitHierarchies WHERE ExplicitHierarchy_ID > @ExplicitHierarchy_ID AND Entity_ID = @Entity_ID)  
            BEGIN  
                -- Get the next EH in the list.  
                SELECT TOP 1  
                     @ExplicitHierarchy_ID = ExplicitHierarchy_ID  
                    ,@ExplicitHierarchyName = ExplicitHierarchyName  
                    ,@IsMandatory = IsMandatory  
                    ,@EnterDTM = EnterDTM  
                    ,@EnterUserID = EnterUserID  
                    ,@EnterVersionID = EnterVersionID  
                    ,@LastChgDTM = LastChgDTM  
                    ,@LastChgUserID = LastChgUserID  
                    ,@LastChgVersionID = LastChgVersionID  
                FROM @ExplicitHierarchies  
                WHERE   ExplicitHierarchy_ID > @ExplicitHierarchy_ID  
                    AND Entity_ID = @Entity_ID  
                ORDER BY ExplicitHierarchy_ID;  
  
    PRINT ''  
    PRINT CONCAT(SYSDATETIME(), N': Begin converting EH: "', @ExplicitHierarchyName, N'" (ID = ', @ExplicitHierarchy_ID, N') in entity "', @EntityName, N'"');  
                DECLARE @EntityNameLength INT = LEN(@EntityName);  
                DECLARE @HierarchyNameLength INT = LEN(@ExplicitHierarchyName);  
   
    PRINT CONCAT(SYSDATETIME(), N': Get a name for the new entity');  
                -- Get a name for the new entity. It must be unique within the model.  
                SET @counter = 0;  
                WHILE (1=1) -- TSQL doesn't support a DO-WHILE loop, so use a tautology as this WHILE condition to simulate a post-test loop.  
                BEGIN  
                    -- Ideally, the new entity name should reference both the leaf entity name and the explicit hierarchy name. However, there is a risk  
                    -- that this could exceed the max name length, in which case we need to be smart about where to do the truncation.  
  
                    IF (@EntityNameLength + @HierarchyNameLength + 4/*allow room for the underscore and the counter*/ <= @MaxMetadataObjectNameLength)  
                    BEGIN  
                        -- The entity and hierarchy names are short enough that they can be concatenated together without exceeding the max length  
                        SET @NewEntityName = CONCAT(@EntityName, N'_', @ExplicitHierarchyName, CASE @counter WHEN 0 THEN N'' ELSE CONVERT(NVARCHAR, @counter) END);  
                    END  
                    ELSE  
                    BEGIN  
                        -- The entity and hierarchy names are together too long, so use truncation. Each name is limited to slightly less than half of the max length. Note  
                        -- that this approach may not be the most sophisticated way of doing it (it could result in overly-aggressive truncation in the case where one name  
                        -- is significantly longer than the other), but it is cheap to implement and should be sufficient since this is an edge case, anyways.  
                        SET @NewEntityName = CONCAT(SUBSTRING(@EntityName, 0, @HalfMaxLen), N'_', SUBSTRING(@ExplicitHierarchyName, 0, @HalfMaxLen), CASE @counter WHEN 0 THEN N'' ELSE CONVERT(NVARCHAR, @counter) END);  
                    END;  
  
                    -- If the new entity name is unique within the model, then exit the loop.  
                    IF NOT EXISTS (SELECT 1 FROM mdm.tblEntity WHERE Model_ID = @Model_ID AND Name = @NewEntityName)  
                    BEGIN  
                        BREAK;  
                    END;  
  
                    -- The name wasn't unique, so increment the counter for the next loop iteration.  
                    SET @counter += 1;  
                END; -- WHILE (get unique entity name)  
  
                SET @NewEntityDescription = CONCAT(N'Replaces consolidated members in the "', @EntityName, N'" entity''s "', @ExplicitHierarchyName, N'" explicit hierarchy');  
  
                -- Create a pseudo-consolidated, self-referencing, entity to take the place of the consolidated members.  
                SET @NewEntity_ID = 0;  
                EXEC mdm.udpEntitySave   
                     @User_ID = @User_ID  
                    ,@Model_ID = @Model_ID  
                    ,@EntityName = @NewEntityName  
                    ,@DataCompression = @DataCompression  
                    ,@TransactionLogType = @TransactionLogType  
                    ,@RequireApproval = 0 -- Consolidated and Collection members don't support the Approval Flow feature, so the new entity created doesn't either. Users may manually change this later, if desired.  
                    ,@Description = @NewEntityDescription  
                    ,@RecreateStagingProc = 0 -- for efficiency, staging sprocs will be recreated only after all attributes have been created (rather than once for each attribute)  
                    ,@Return_ID = @NewEntity_ID OUTPUT  
  
                -- Update the new entity's audit info to match the EH's audit info.  
                UPDATE mdm.tblEntity  
                SET  EnterDTM = @EnterDTM  
                    ,EnterUserID = @EnterUserID  
                    ,EnterVersionID = @EnterVersionID  
                    ,LastChgDTM = @LastChgDTM  
                    ,LastChgUserID = @LastChgUserID  
                    ,LastChgVersionID = @LastChgVersionID  
                WHERE ID = @NewEntity_ID;  
  
  
    PRINT CONCAT(SYSDATETIME(), N': Created new entity "', @NewEntityName, N'" (ID = ', @NewEntity_ID, N') that is a copy of entity "', @EntityName, N'" (ID = ', @Entity_ID, N')''s consolidated members.');  
      
                -- Get the name of the new entity's EN table.  
                SELECT   
                     @NewEntityTableName_EN = EntityTable  
                    ,@NewEntityTableName_EN_HS  = CONCAT(EntityTable, N'_HS')  
                    ,@NewEntityTableName_EN_AN  = CONCAT(EntityTable, N'_AN')  
                    ,@NewEntityStagingLeafName = StagingLeafName  
                FROM mdm.tblEntity  
                WHERE ID = @NewEntity_ID;  
  
  
                -- Create attributes in the new entity that match the consolidated attributes in the old entity.  
    PRINT CONCAT(SYSDATETIME(), N': Copying consolidated attribute metadata from old entity to new entity');  
      
                -- Add the consolidated system attributes to the mapping table (needed for converting transactions, object security, and BRs)  
                INSERT INTO #AttributeMapping  
                (  
                     OldAttribute_ID  
                    ,OldMemberType  
                    ,OldEntity_ID  
                    ,NewAttribute_ID  
                    ,NewEntity_ID  
                )  
                SELECT  
                     oldA.ID  
                    ,oldA.MemberType_ID  
                    ,oldA.Entity_ID  
                    ,newA.ID  
                    ,newA.Entity_ID  
                FROM mdm.tblAttribute oldA  
                INNER JOIN mdm.tblAttribute newA  
                ON oldA.Name = newA.Name  
                WHERE   oldA.Entity_ID = @Entity_ID  
                    AND oldA.MemberType_ID = @MemberType_Consolidated  
                    AND oldA.IsSystem = 1  
                    AND newA.Entity_ID = @NewEntity_ID  
                    AND newA.IsSystem = 1  
  
                -- Get a list of all non-system consolidated attributes in the entity.  
                DELETE FROM @AttributeInfo;  
                INSERT INTO @AttributeInfo  
                SELECT  
                     ID  
                    ,DisplayName  
                    ,Name  
                    ,Description  
                    ,TableColumn  
                    ,AttributeType_ID  
                    ,DataType_ID  
                    ,DataTypeInformation  
                    ,InputMask_ID  
                    ,DisplayWidth  
                    ,SortOrder  
                    ,DomainEntity_ID  
                    ,ChangeTrackingGroup  
                FROM mdm.tblAttribute   
                WHERE   Entity_ID = @Entity_ID  
                    AND MemberType_ID = @MemberType_Consolidated  
                    AND IsSystem = 0  
                SET @Attribute_ID = 0;  
  
                -- Loop through each non-system consolidated attribute, copying it to the new entity as a leaf attribute.  
                SET @NewAttributeColumnNames = N'';  
                SET @OldAttributeColumnNames = N'';  
                WHILE EXISTS (SELECT 1 FROM @AttributeInfo WHERE Attribute_ID > @Attribute_ID)  
                BEGIN  
                    -- Get the next attribute's info.  
                    SELECT TOP 1   
                         @Attribute_ID = Attribute_ID  
                        ,@DisplayName = DisplayName  
                        ,@Name = Name  
                        ,@Description = Description  
                        ,@OldAttributeColumnNames += @TruncationGuard + N'  
                    ,hp.' + ColumnName  
                        ,@AttributeType_ID = AttributeType_ID  
                        ,@DataType_ID = DataType_ID  
                        ,@DataTypeInformation = DataTypeInformation  
                        ,@InputMask_ID = InputMask_ID  
                        ,@DisplayWidth = DisplayWidth  
                        ,@SortOrder = SortOrder  
                        ,@DomainEntity_ID = DomainEntity_ID  
                        ,@ChangeTrackingGroup = ChangeTrackingGroup  
                    FROM @AttributeInfo   
                    WHERE Attribute_ID > @Attribute_ID  
                    ORDER BY Attribute_ID  
  
                    -- Add an attribute to the new entity that is a leaf copy of the consolidated attribute.  
                    SET @NewAttribute_ID = NULL;  
                    EXEC mdm.udpAttributeSave  
                         @User_ID = @User_ID  
                        ,@Model_ID = @Model_ID  
                        ,@Entity_ID = @NewEntity_ID  
                        ,@IsHierarchyEnabled = 0  
                        ,@IsCollectionEnabled = 0  
                        ,@DataCompression = @DataCompression  
                        ,@TableName = @NewEntityTableName_EN  
                        ,@StagingTableName = @NewEntityStagingLeafName  
                        ,@MemberType_ID = @MemberType_Leaf  
                        ,@AttributeType_ID = @AttributeType_ID  
                        ,@AttributeName = @Name  
                        ,@Description = @Description  
                        ,@DisplayName = @DisplayName  
                        ,@DisplayWidth = @DisplayWidth  
                        ,@DomainEntity_ID = @DomainEntity_ID  
                        ,@DataType_ID = @DataType_ID  
                        ,@DataTypeInformation = @DataTypeInformation  
                        ,@InputMask_ID = @InputMask_ID  
                        ,@ChangeTrackingGroup = @ChangeTrackingGroup  
                        ,@SortOrder = @SortOrder  
                        ,@RecreateStagingProc = 0 -- for efficiency, staging sprocs will be recreated only after all attributes have been created (rather than once for each attribute)  
                        ,@Return_ID = @NewAttribute_ID OUTPUT;    
  
                    -- Update the new attribute's audit info to match the EH's audit info.  
                    UPDATE mdm.tblAttribute  
                    SET  EnterDTM = @EnterDTM  
                        ,EnterUserID = @EnterUserID  
                        ,EnterVersionID = @EnterVersionID  
                        ,LastChgDTM = @LastChgDTM  
                        ,LastChgUserID = @LastChgUserID  
                        ,LastChgVersionID = @LastChgVersionID  
                    WHERE ID = @NewAttribute_ID;  
          
                    SELECT @NewAttributeColumnNames += @TruncationGuard + N'  
                    ,' + TableColumn  
                    FROM mdm.tblAttribute WHERE ID = @NewAttribute_ID;  
  
    PRINT CONCAT(SYSDATETIME(), N': Copied attribute "', @Name, N'" (ID = ', @Attribute_ID, N') to new entity. New attribute ID = ', @NewAttribute_ID);  
                    -- Keep track of the mapping between the old and new attributes.  
                    INSERT INTO #AttributeMapping  
                    (  
                         OldAttribute_ID  
                        ,OldMemberType  
                        ,OldEntity_ID  
                        ,NewAttribute_ID  
                        ,NewEntity_ID  
                    )  
                    SELECT  
                         @Attribute_ID  
                        ,@MemberType_Consolidated  
                        ,@Entity_ID  
                        ,@NewAttribute_ID  
                        ,@NewEntity_ID  
                END -- WHILE (loop through entity's consolidated attributes)  
  
                -- Add a self-referencing DBA to the new entity, to represent the consolidated parent-child relationships defined in the HR table.  
  
                -- Get a unique name for the new DBA  
                SET @counter = 0;  
                WHILE (1=1) -- TSQL doesn't support a DO-WHILE loop, so use a tautology as this WHILE condition to simulate a post-test loop.  
                BEGIN  
                    SET @NewRecursiveAttributeName = CONCAT(N'Parent', CASE @counter WHEN 0 THEN N'' ELSE CONVERT(NVARCHAR, @counter) END);  
  
                    -- If the new attribute name is unique within the entity, then exit the loop.  
                    IF NOT EXISTS (SELECT 1 FROM mdm.tblAttribute WHERE Entity_ID = @NewEntity_ID AND Name = @NewRecursiveAttributeName) -- No need to check MemberType_ID here, since all attributes in the new Entity are leaf attributes.  
                    BEGIN  
                        BREAK;  
                    END;  
  
                    -- The name wasn't unique, so increment the counter for the next loop iteration.  
                    SET @counter += 1;  
                END; -- WHILE (get unique attribute name)  
  
                -- Save the new self-referencing DBA.  
                EXEC mdm.udpAttributeSave   
                     @User_ID = @User_ID  
                    ,@Model_ID = @Model_ID  
                    ,@Entity_ID = @NewEntity_ID  
                    ,@IsHierarchyEnabled = 0  
                    ,@IsCollectionEnabled = 0  
                    ,@DataCompression = @DataCompression  
                    ,@TableName = @NewEntityTableName_EN  
                    ,@StagingTableName = @NewEntityStagingLeafName  
                    ,@MemberType_ID = @MemberType_Leaf  
                    ,@AttributeName = @NewRecursiveAttributeName  
                    ,@Description = N''  
                    ,@AttributeType_ID = @AttributeType_Domain  
                    ,@DisplayName = @NewRecursiveAttributeName  
                    ,@DisplayWidth = 175  
                    ,@DomainEntity_ID = @NewEntity_ID -- Self-referencing DBA  
                    ,@DataType_ID = @DataType_Text  
                    ,@DataTypeInformation = 100  
                    ,@InputMask_ID = 1  
                    ,@ChangeTrackingGroup = 0  
                    ,@SortOrder = NULL -- let the sproc determine the sort order (it will set it to MAX(SortOrder) + 1)  
                    ,@RecreateStagingProc = 0 -- for efficiency, staging sprocs will be recreated only after all attributes have been created (rather than once for each attribute)  
                    ,@Return_ID = @NewRecursiveAttribute_ID OUTPUT;    
  
                -- Update the new attribute's audit info to match the EH's audit info.  
                UPDATE mdm.tblAttribute  
                SET  EnterDTM = @EnterDTM  
                    ,EnterUserID = @EnterUserID  
                    ,EnterVersionID = @EnterVersionID  
                    ,LastChgDTM = @LastChgDTM  
                    ,LastChgUserID = @LastChgUserID  
                    ,LastChgVersionID = @LastChgVersionID  
                WHERE ID = @NewRecursiveAttribute_ID;  
  
    PRINT CONCAT(SYSDATETIME(), N': Added a self-referencing DBA "', @NewRecursiveAttributeName, N'" (ID = ', @NewRecursiveAttribute_ID, N') to the new entity.');  
  
                -- Get the column name in the new EN table for the new attribute  
                SELECT @NewRecursiveAttribute_ColumnName = TableColumn  
                FROM mdm.tblAttribute   
                WHERE ID = @NewRecursiveAttribute_ID  
  
    PRINT CONCAT(SYSDATETIME(), N': Copy the member master data, from consolidated members in the old entity to leaf members in the new entity.');  
                SET @SQL = @TruncationGuard + N'  
                --SELECT * FROM mdm.' + QUOTENAME(@EntityTableName_HP) + N' WHERE Hierarchy_ID = @ExplicitHierarchy_ID;  
  
                SET IDENTITY_INSERT mdm.' + QUOTENAME(@NewEntityTableName_EN) + N' ON; -- This allows the query to specify the ID column, which will be set to match the ID in the old HP table, so that the parent values can be directly copied from the HR table to the new self-referencing DBA  
  
                INSERT INTO mdm.' + QUOTENAME(@NewEntityTableName_EN) + N'  
                (  
                    -- System attributes  
                     Version_ID  
                    ,ID  
                    ,Status_ID  
                    ,ValidationStatus_ID  
                    ,Name  
                    ,Code  
                    ,ChangeTrackingMask  
                    ,EnterDTM  
                    ,EnterUserID  
                    ,EnterVersionID  
                    ,LastChgDTM  
                    ,LastChgUserID  
                    ,LastChgVersionID  
                    ,AsOf_ID'   
                    + CASE @DeleteOriginals WHEN 1 THEN N'  
                    ,MUID' ELSE N'' END -- Use the original MUID when the original will be deleted  
                    + N'  
  
                    -- User-defined attributes  
                    ' + @NewAttributeColumnNames + N'  
  
                    -- The new self-referencing DBA  
                    ,' + QUOTENAME(@NewRecursiveAttribute_ColumnName) + N'   
                )  
                SELECT  
                    -- System attributes  
                     hp.Version_ID  
                    ,hp.ID  
                    ,hp.Status_ID  
                    ,hp.ValidationStatus_ID  
                    ,hp.Name  
                    ,hp.Code  
                    ,hp.ChangeTrackingMask  
                    ,hp.EnterDTM  
                    ,hp.EnterUserID  
                    ,hp.EnterVersionID  
                    ,hp.LastChgDTM  
                    ,hp.LastChgUserID  
                    ,hp.LastChgVersionID   
                    ,hp.AsOf_ID'  
                    + CASE @DeleteOriginals WHEN 1 THEN N'  
                    ,hp.MUID' ELSE N'' END -- Use the original MUID when the original will be deleted  
                    + N'  
  
                    -- User-defined attributes  
                    ' + @OldAttributeColumnNames + N'  
  
                    -- The new self-referencing DBA (pulled from the HR table)  
                    ,hr.Parent_HP_ID   
                FROM mdm.' + QUOTENAME(@EntityTableName_HP) + N' hp  
                LEFT JOIN mdm.' + QUOTENAME(@EntityTableName_HR) + N' hr  
                ON      hp.ID = hr.Child_HP_ID  
                    AND hp.ID <> hr.Parent_HP_ID -- This fixes the data in the unlikely event that the data has been corrupted by a consolidated member somehow having been made its own parent.  
                WHERE hp.Hierarchy_ID = @ExplicitHierarchy_ID; -- Only copy consolidated members that pertain to the current explicit hierarchy  
  
                SET IDENTITY_INSERT mdm.' + QUOTENAME(@NewEntityTableName_EN) + N' OFF;   
  
                --SELECT * FROM mdm.' + QUOTENAME(@NewEntityTableName_EN) + N';  
                ';  
                --PRINT @SQL  
                EXEC sp_executesql @SQL, N'@ExplicitHierarchy_ID INT', @ExplicitHierarchy_ID;  
  
  
  
  
  
                -- Add a new DBA to the original entity, that references the new parent entity.  
  
                -- Get a unique name for the new DBA  
                SET @counter = 0;  
                WHILE (1=1) -- TSQL doesn't support a DO-WHILE loop, so use a tautology as this WHILE condition to simulate a post-test loop.  
                BEGIN  
                    SET @NewLeafDbaName = CONCAT(@ExplicitHierarchyName, CASE WHEN @counter > 0 THEN @counter END);  
  
                    -- If the new attribute name is unique within the entity-member type, then exit the loop.  
                    IF NOT EXISTS (SELECT 1 FROM mdm.tblAttribute WHERE Entity_ID = @Entity_ID AND MemberType_ID = @MemberType_Leaf AND Name = @NewLeafDbaName)  
                    BEGIN  
                        BREAK;  
                    END;  
  
                    -- The name wasn't unique, so increment the counter for the next loop iteration.  
                    SET @counter += 1;  
                END; -- WHILE (get unique attribute name)  
  
                EXEC mdm.udpAttributeSave    
                     @User_ID = @User_ID  
                    ,@Model_ID = @Model_ID  
                    ,@Entity_ID = @Entity_ID  
                    ,@IsHierarchyEnabled = 0  
                    ,@IsCollectionEnabled = 0  
                    ,@DataCompression = @DataCompression  
                    ,@TableName = @EntityTableName_EN  
                    ,@StagingTableName = @StagingLeafName  
                    ,@MemberType_ID = @MemberType_Leaf  
                    ,@AttributeType_ID = @AttributeType_Domain  
                    ,@AttributeName = @NewLeafDbaName  
                    ,@Description = N''  
                    ,@DisplayName = @NewLeafDbaName  
                    ,@DisplayWidth = 175  
                    ,@DomainEntity_ID = @NewEntity_ID -- Self-referencing DBA  
                    ,@DataType_ID = @DataType_Text  
                    ,@DataTypeInformation = 100  
                    ,@InputMask_ID = 1  
                    ,@ChangeTrackingGroup = 0  
                    ,@RecreateStagingProc = 0 -- for efficiency, staging sprocs will be recreated only after all attributes have been created (rather than once for each attribute)  
                    ,@Return_ID = @NewLeafDba_ID OUTPUT;    
  
                -- Update the new attribute's audit info to match the EH's audit info.  
                UPDATE mdm.tblAttribute  
                SET  EnterDTM = @EnterDTM  
                    ,EnterUserID = @EnterUserID  
                    ,EnterVersionID = @EnterVersionID  
                    ,LastChgDTM = @LastChgDTM  
                    ,LastChgUserID = @LastChgUserID  
                    ,LastChgVersionID = @LastChgVersionID  
                WHERE ID = @NewLeafDba_ID;  
    PRINT CONCAT(SYSDATETIME(), N': Added a DBA "', @NewLeafDbaName, N'" (ID = ', @NewLeafDba_ID, N') to the old leaf entity, that references the new entity.');  
  
                -- Get the column name in the new EN table for the new attribute  
                SELECT @NewLeafDba_ColumnName = TableColumn  
                FROM mdm.tblAttribute   
                WHERE ID = @NewLeafDba_ID  
  
    PRINT CONCAT(SYSDATETIME(), N': Updating the new DBA to point to the newly-copied Leaf member, corresponding to its old consolidated parent.');  
                SET @SQL = CONCAT(@TruncationGuard, N'  
                UPDATE en  
                SET  en.', QUOTENAME(@NewLeafDba_ColumnName), N' = hr.Parent_HP_ID',   
                CASE WHEN @TransactionLogType = @TransactionLogType_Member THEN CONCAT(N'  
                    ,en.', QUOTENAME(@TempTimestampColumnName), N' = COALESCE(en.', QUOTENAME(@TempTimestampColumnName), N', en.LastChgTS)-- keep track of the original timestamp, to facilitate copying member history from HR_HS table') END, N'  
                FROM mdm.', QUOTENAME(@EntityTableName_EN), N' en  
                INNER JOIN mdm.', QUOTENAME(@EntityTableName_HR), N' hr  
                ON      en.Version_ID = hr.Version_ID  
                    AND en.ID = hr.Child_EN_ID  
                WHERE hr.Hierarchy_ID = @ExplicitHierarchy_ID  
              
                IF @IsMandatory = 1  
                BEGIN  
                    -- Get a list of leaf members with no consolidated parents. In a mandatory EH these members would be displayed directly under Root. But this  
                    -- is not allowed in a DH. So create a pseudo-"Root" member of the new parent entity, which will server as the parent of these leaf members  
                    DECLARE @MembersWithNoParent TABLE  
                    (   
                        Member_ID  INT PRIMARY KEY  
                    );      
                    INSERT INTO @MembersWithNoParent  
                    SELECT ID  
                    FROM mdm.', QUOTENAME(@EntityTableName_EN), N'  
                    WHERE ', QUOTENAME(@NewLeafDba_ColumnName), N' IS NULL;  
  
                    IF EXISTS (SELECT 1 FROM @MembersWithNoParent)  
                    BEGIN  
                        -- Get a unique member Code for the new root pseudo parent member.  
                        DECLARE   
                             @MemberCode NVARCHAR(250)  
                            ,@counter INT = 0;  
                        WHILE (1=1) -- post-test loop  
                        BEGIN   
                            SET @MemberCode = CONCAT(N''Pseudo Root'', CASE @counter WHEN 0 THEN N'''' ELSE CONVERT(NVARCHAR, @counter) END);  
                PRINT CONCAT(SYSDATETIME(), N'': Getting new member Code, @counter = '', @counter, N'', @MemberCode = "'', @MemberCode, ''"'');  
                            IF NOT EXISTS (SELECT 1 FROM mdm.', QUOTENAME(@NewEntityTableName_EN), N' WHERE Code = @MemberCode)  
                            BEGIN  
                                BREAK; -- The code is unique, so exit the loop.  
                            END;  
                            SET @counter += 1;  
                        END;  
  
                PRINT CONCAT(SYSDATETIME(), N'': Adding pseudo-members to new entity table'');  
                        WITH versions AS  
                        (  
                            SELECT DISTINCT ID AS Version_ID  
                            FROM mdm.tblModelVersion   
                            WHERE Model_ID = @Model_ID  
                        )  
                        INSERT INTO  mdm.', QUOTENAME(@NewEntityTableName_EN), N'  
                        (  
                            -- System attributes  
                             Version_ID  
                            ,Name  
                            ,Code  
                            ,EnterUserID  
                            ,EnterVersionID  
                            ,LastChgUserID  
                            ,LastChgVersionID  
                        )  
                        SELECT  
                            -- System attributes  
                             Version_ID  
                            ,@MemberCode  
                            ,@MemberCode  
                            ,@User_ID  
                            ,Version_ID  
                            ,@User_ID  
                            ,Version_ID  
                        FROM versions;   
  
                PRINT CONCAT(SYSDATETIME(), N'': Updating old leaf table members to point to pseudo-members'');  
                        WITH pseudoMembersCTE AS  
                        (  
                            SELECT   
                                ID  
                                ,Version_ID  
                            FROM mdm.', QUOTENAME(@NewEntityTableName_EN), N'  
                            WHERE Code = @MemberCode  
                        )  
                        UPDATE en   
                        SET ', QUOTENAME(@NewLeafDba_ColumnName), N' = cte.ID',   
                        CASE WHEN @TransactionLogType = @TransactionLogType_Member THEN CONCAT(N'  
                            ,', QUOTENAME(@TempTimestampColumnName), N' = COALESCE(en.', QUOTENAME(@TempTimestampColumnName), N', en.LastChgTS)-- keep track of the original timestamp, to facilitate copying member history from HR_HS table') END, N'  
                        FROM mdm.', QUOTENAME(@EntityTableName_EN), N' en  
                        INNER JOIN @MembersWithNoParent m  
                        ON en.ID = m.Member_ID  
                        INNER JOIN pseudoMembersCTE cte -- CROSS JOIN pseudoMembersCTE cte  
                        ON en.Version_ID = cte.Version_ID  
  
                PRINT CONCAT(SYSDATETIME(), N'': Done updating old leaf table members to point to pseudo-members'');  
                        --SELECT * FROM mdm.', QUOTENAME(@NewEntityTableName_EN), N';  
                        --SELECT * FROM mdm.', QUOTENAME(@EntityTableName_EN), N';  
  
                    END -- IF there are unparented LEAF members.   
                END -- IF the hierarchy is mandatory  
                ');  
                --PRINT @SQL  
                EXEC sp_executesql @SQL, N'@User_ID INT, @Model_ID INT, @ExplicitHierarchy_ID INT, @IsMandatory BIT', @LastChgUserID, @Model_ID, @ExplicitHierarchy_ID, @IsMandatory;  
  
  
  
  
  
                IF @TransactionLogType = @TransactionLogType_Attribute  
                BEGIN  
                    SET @TransactionTableName = mdm.udfGetTransactionTableName(@Model_ID);  
                    IF @DeleteOriginals = 1  
                    BEGIN  
                        -- If the originals should be deleted, then merely update the existing transaction rows, rather than copying and then (later) deleting the originals. More efficient, and allows us to skip modifying the transaction annotations table.  
                        PRINT CONCAT(SYSDATETIME(), N': Updating consolidated member transaction rows (deprecated Attribute transaction type) to reference the new Leaf entities.');  
                        SET @SQL = CONCAT(@TruncationGuard, N'  
                        --SELECT * FROM mdm.', QUOTENAME(@TransactionTableName), N' WHERE Entity_ID = @Entity_ID AND (MemberType_ID = ', @MemberType_Consolidated, N' OR Hierarchy_ID = @ExplicitHierarchy_ID)  
  
                        DECLARE @RootID NVARCHAR = N''0'';  
                        UPDATE tr  
                        SET  
                             TransactionType_ID = CASE WHEN tr.TransactionType_ID IN (', @TransactionType_MoveMemberToParent, N', ', @TransactionType_MoveMemberToSibling, N')   
                                THEN ', @TransactionType_SetAttributeValue, N' -- Change EH move transactions to attribute change transaction  
                                ELSE tr.TransactionType_ID END   
                            ,Hierarchy_ID = NULL  
                            ,Entity_ID = CASE tr.MemberType_ID   
                                WHEN ', @MemberType_Consolidated, N' THEN @NewEntity_ID -- Use the new entity for consolidated member transactions ....  
                                ELSE tr.Entity_ID END                                   -- ... but keep the old entity for other member types (probably always leaf)  
                            ,Attribute_ID = COALESCE(  
                                 a.NewAttribute_ID -- Changing the value of a consolidated attribute.  
                                ,CASE tr.MemberType_ID  
                                    WHEN ', @MemberType_Leaf, N' THEN @NewLeafDba_ID -- Moving a leaf member to a new parent  
                                    WHEN ', @MemberType_Consolidated, N' THEN @NewRecursiveAttribute_ID -- Moving a consolidated member to a new parent  
                                    ELSE NULL END)  
                            ,MemberType_ID = ', @MemberType_Leaf, N'  
  
                            ,OldValue = CASE WHEN tr.OldValue = @RootID AND tr.TransactionType_ID IN (', @TransactionType_MoveMemberToParent, N', ', @TransactionType_MoveMemberToSibling, N')   
                                THEN NULL  
                                ELSE tr.OldValue  
                                END  
                            ,OldCode = CASE WHEN tr.OldValue = @RootID AND tr.TransactionType_ID IN (', @TransactionType_MoveMemberToParent, N', ', @TransactionType_MoveMemberToSibling, N')   
                                THEN NULL  
                                ELSE tr.OldCode  
                                END  
                            ,NewValue = CASE WHEN tr.NewValue = @RootID AND tr.TransactionType_ID IN (', @TransactionType_MoveMemberToParent, N', ', @TransactionType_MoveMemberToSibling, N')   
                                THEN NULL  
                                ELSE tr.NewValue  
                                END  
                            ,NewCode = CASE WHEN tr.NewValue = @RootID AND tr.TransactionType_ID IN (', @TransactionType_MoveMemberToParent, N', ', @TransactionType_MoveMemberToSibling, N')   
                                THEN NULL  
                                ELSE tr.NewCode  
                                END  
  
                        FROM mdm.', QUOTENAME(@TransactionTableName), N' tr  
  
                        -- Get new attribute ID for consolidated members  
                        LEFT JOIN #AttributeMapping a  
                        ON      tr.Attribute_ID = a.OldAttribute_ID  
                            AND a.NewEntity_ID = @NewEntity_ID -- The attribute may have multiple copies (if the original entity has more than one EH) so filter on the new Entity_ID to get the right attribute ID.  
  
                        WHERE   tr.Entity_ID = @Entity_ID  
                            AND (   tr.MemberType_ID = ', @MemberType_Consolidated, N'     -- Copy all consolidated transactions...  
                                    OR tr.Hierarchy_ID = @ExplicitHierarchy_ID)        -- ... and all leaf member transactions that involve movement within the EH  
  
                        --SELECT * FROM mdm.', QUOTENAME(@TransactionTableName), N' WHERE Entity_ID IN (@Entity_ID, @NewEntity_ID)  
                            ');  
                        -- Note: No need to copy or update the transaction annotations, since we merely modified existing transaction rows.  
                    END ELSE  
                    BEGIN  
                        -- We're not deleting originals, so copy (rather than update) transaction rows. The transaction annotations will also need to be copied.  
                        SET @TransactionAnnotationTableName = mdm.udfGetTransactionAnnotationTableName(@Model_ID);  
                        -- Copy transactions pertaining to the EH being copied: Leaf transactions that move members in the EH, and all Consolidated transactions  
        PRINT CONCAT(SYSDATETIME(), N': Copying consolidated member transactions.');  
                        SET @SQL = CONCAT(@TruncationGuard, N'  
                        DECLARE @RootID NVARCHAR = N''0'';  
  
                        DECLARE @TransactionMappings TABLE  
                        (  
                             Old_ID INT PRIMARY KEY  
                            ,New_ID INT  
                        )  
  
                        MERGE mdm.', QUOTENAME(@TransactionTableName), N'  
                        USING  
                        (  
                            SELECT  
                                 tr.ID  
                                ,tr.Version_ID  
                                ,CASE WHEN tr.TransactionType_ID IN (', @TransactionType_MoveMemberToParent, N', ', @TransactionType_MoveMemberToSibling, N')   
                                    THEN ', @TransactionType_SetAttributeValue, N' -- Change EH move transactions to attribute change transaction  
                                    ELSE tr.TransactionType_ID END AS TransactionType_ID  
                                ,tr.OriginalTransaction_ID -- This references the old ID and will need to be updated after the MERGE  
                                ,NULL AS Hierarchy_ID  
                                ,CASE tr.MemberType_ID   
                                    WHEN ', @MemberType_Consolidated, N' THEN @NewEntity_ID -- Use the new entity for consolidated member transactions ....  
                                    ELSE tr.Entity_ID END                            -- ... but keep the old entity for other member types (probably always leaf)  
                                    AS Entity_ID  
                                ,COALESCE(a.NewAttribute_ID -- Changing the value of a consolidated attribute.  
                                    ,CASE tr.MemberType_ID  
                                        WHEN ', @MemberType_Leaf, N' THEN @NewLeafDba_ID -- Moving a leaf member to a new parent  
                                        WHEN ', @MemberType_Consolidated, N' THEN @NewRecursiveAttribute_ID -- Moving a consolidated member to a new parent  
                                        ELSE NULL END)  
                                    AS Attribute_ID  
                                ,tr.Member_ID                                        -- The old member ID will always be the same ...  
                                ,COALESCE(newEn.MUID, tr.Member_MUID) AS Member_MUID -- ... but the member MUID will be different for consolidated member transactions (not for leaf member EH move transactions)  
                                ,', @MemberType_Leaf, N' AS MemberType_ID  
                                ,tr.MemberCode  
  
                                ,CASE WHEN tr.OldValue = @RootID AND tr.TransactionType_ID IN (', @TransactionType_MoveMemberToParent, N', ', @TransactionType_MoveMemberToSibling, N')   
                                    THEN NULL  
                                    ELSE tr.OldValue  
                                    END AS OldValue  
                                ,CASE WHEN tr.OldValue = @RootID AND tr.TransactionType_ID IN (', @TransactionType_MoveMemberToParent, N', ', @TransactionType_MoveMemberToSibling, N')   
                                    THEN NULL  
                                    ELSE tr.OldCode  
                                    END AS OldCode  
                                ,CASE WHEN tr.NewValue = @RootID AND tr.TransactionType_ID IN (', @TransactionType_MoveMemberToParent, N', ', @TransactionType_MoveMemberToSibling, N')   
                                    THEN NULL  
                                    ELSE tr.NewValue  
                                    END AS NewValue  
                                ,CASE WHEN tr.NewValue = @RootID AND tr.TransactionType_ID IN (', @TransactionType_MoveMemberToParent, N', ', @TransactionType_MoveMemberToSibling, N')   
                                    THEN NULL  
                                    ELSE tr.NewCode  
                                    END AS NewCode  
  
                                ,tr.Batch_ID  
                                ,tr.EnterDTM  
                                ,tr.EnterUserID  
                                ,tr.LastChgDTM  
                                ,tr.LastChgUserID  
                            FROM mdm.', QUOTENAME(@TransactionTableName), ' tr  
  
                            -- Get new member MUID for copied consolidated members (note that this is a left join because some of the transactions that need to be copied may be for Leaf members being moved in the EH)  
                            LEFT JOIN mdm.', QUOTENAME(@NewEntityTableName_EN), N' newEn  
                            ON      tr.MemberType_ID = ', @MemberType_Consolidated, N'  
                                AND tr.Version_ID = newEn.Version_ID  
                                AND tr.Member_ID = newEn.ID  
  
                            -- Get new attribute ID for consolidated members  
                            LEFT JOIN #AttributeMapping a  
                            ON      tr.Attribute_ID = a.OldAttribute_ID  
                                AND a.NewEntity_ID = @NewEntity_ID -- The attribute may have multiple copies (if the original entity has more than one EH) so filter on the new Entity_ID to get the right attribute ID.  
  
                            WHERE   tr.Entity_ID = @Entity_ID  
                                AND (   tr.MemberType_ID = ', @MemberType_Consolidated, N'     -- Copy all consolidated transactions...  
                                     OR tr.Hierarchy_ID = @ExplicitHierarchy_ID)        -- ... and all leaf member transactions that involve movement within the EH  
                        ) t  
                        ON (1 = 0) -- An arbitrary condition that is always false, so that the NOT MATCHED block will always be hit.  
                        WHEN NOT MATCHED THEN  
                        INSERT  
                        (  
                             Version_ID  
                            ,TransactionType_ID  
                            ,OriginalTransaction_ID  
                            ,Hierarchy_ID  
                            ,Entity_ID  
                            ,Attribute_ID  
                            ,Member_ID  
                            ,Member_MUID  
                            ,MemberType_ID  
                            ,MemberCode  
                            ,OldValue  
                            ,OldCode  
                            ,NewValue  
                            ,NewCode  
                            ,Batch_ID  
                            ,EnterDTM  
                            ,EnterUserID  
                            ,LastChgDTM  
                            ,LastChgUserID  
                        )  
                        VALUES  
                        (  
                             Version_ID  
                            ,TransactionType_ID  
                            ,OriginalTransaction_ID  
                            ,Hierarchy_ID  
                            ,Entity_ID  
                            ,Attribute_ID  
                            ,Member_ID  
                            ,Member_MUID  
                            ,MemberType_ID  
                            ,MemberCode  
                            ,OldValue  
                            ,OldCode  
                            ,NewValue  
                            ,NewCode  
                            ,Batch_ID  
                            ,EnterDTM  
                            ,EnterUserID  
                            ,LastChgDTM  
                            ,LastChgUserID  
                        )  
                        OUTPUT t.ID, inserted.ID  
                        INTO @TransactionMappings(Old_ID, New_ID);  
  
                        -- Update original transaction ID columns  
                        UPDATE tr  
                        SET OriginalTransaction_ID = newParent.New_ID  
                        FROM mdm.', QUOTENAME(@TransactionTableName), N' tr  
                        INNER JOIN @TransactionMappings newRow  
                        ON tr.ID = newRow.New_ID  
                        INNER JOIN @TransactionMappings newParent  
                        ON tr.OriginalTransaction_ID = newParent.Old_ID;  
  
                        -- Copy transaction annotations  
        PRINT CONCAT(SYSDATETIME(), N'': Copying consolidated transaction annotations.'');  
                        INSERT INTO mdm.', QUOTENAME(@TransactionAnnotationTableName), N'  
                        (  
                             Version_ID  
                            ,Transaction_ID  
                            ,Comment  
                            ,EnterUserID  
                            ,EnterDTM  
                            ,LastChgDTM  
                            ,LastChgUserID  
                        )  
                        SELECT  
                             ta.Version_ID   
                            ,newRow.New_ID  
                            ,ta.Comment  
                            ,ta.EnterUserID  
                            ,ta.EnterDTM  
                            ,ta.LastChgDTM  
                            ,ta.LastChgUserID  
                        FROM mdm.', QUOTENAME(@TransactionAnnotationTableName), N' ta  
                        INNER JOIN @TransactionMappings newRow  
                        ON ta.Transaction_ID = newRow.Old_ID  
                        ');  
                        END  
                    --PRINT @SQL  
                    EXEC sp_executesql @SQL  
                        ,N'@ExplicitHierarchy_ID INT, @Entity_ID INT, @NewEntity_ID INT, @NewRecursiveAttribute_ID INT, @NewLeafDba_ID INT'  
                          ,@ExplicitHierarchy_ID,     @Entity_ID,     @NewEntity_ID,     @NewRecursiveAttribute_ID,     @NewLeafDba_ID;  
                END   
                ELSE IF @TransactionLogType = @TransactionLogType_Member  
                BEGIN  
  
PRINT CONCAT(SYSDATETIME(), N': Copying consolidated member history to the new entity.');  
  
                    SET @SQL = CONCAT(@TruncationGuard, N'  
                    -- Combine the old HP_HS and HR_HS tables into the new EN_HS table for hierarchy ', @ExplicitHierarchyName, N', entity ', @EntityName, N', to new entity ', @NewEntityName, N'  
                    ;WITH combinedHPCte AS -- Combine current HP values with history  
                    (  
                        -- current values  
                        SELECT  
                             hp.Version_ID  
                            ,CONVERT(BIGINT, hp.LastChgTS) AS ID  
                            ,hp.ID AS HP_ID  
                            ,hp.Status_ID  
                            ,hp.Name  
                            ,hp.Code  
                            ,hp.EnterDTM  
                            ,hp.EnterUserID  
                            ,hp.LastChgDTM  
                            ,hp.LastChgUserID  
                            ,hp.MUID  
                            -- User-defined attributes  
                            ', @OldAttributeColumnNames, N'  
                        FROM mdm.', QUOTENAME(@EntityTableName_HP), N' hp  
                        WHERE hp.Hierarchy_ID = @ExplicitHierarchy_ID  
  
                        UNION ALL -- deduplication not needed  
  
                        -- historical values  
                        SELECT  
                             hp.Version_ID  
                            ,hp.ID  
                            ,hp.HP_ID  
                            ,hp.Status_ID  
                            ,hp.Name  
                            ,hp.Code  
                            ,hp.EnterDTM  
                            ,hp.EnterUserID  
                            ,hp.LastChgDTM  
                            ,hp.LastChgUserID  
                            ,hp.MUID  
                            -- User-defined attributes  
                            ', @OldAttributeColumnNames, N'  
                        FROM mdm.', QUOTENAME(@EntityTableName_HP_HS), N' hp  
                        WHERE hp.Hierarchy_ID = @ExplicitHierarchy_ID  
                    )  
                    ,combinedHRCte AS -- Combine current HR values with history  
                    (  
                        -- current values  
                        SELECT  
                             hr.Version_ID  
                            ,CONVERT(BIGINT, hr.LastChgTS) AS ID  
                            ,hr.ID AS HR_ID  
                            ,hr.Status_ID  
                            ,hr.Parent_HP_ID  
                            ,hr.Child_HP_ID  
                            ,hr.EnterDTM  
                            ,hr.EnterUserID  
                            ,hr.LastChgDTM  
                            ,hr.LastChgUserID  
                        FROM mdm.', QUOTENAME(@EntityTableName_HR), N' hr  
                        WHERE   hr.Hierarchy_ID = @ExplicitHierarchy_ID  
                            AND hr.Child_HP_ID IS NOT NULL -- only include rows that assign a consolidated member to a parent  
  
                        UNION ALL -- deduplication not needed  
  
                        -- historical values  
                        SELECT  
                             hr.Version_ID  
                            ,hr.ID  
                            ,hr.HR_ID  
                            ,hr.Status_ID  
                            ,hr.Parent_HP_ID  
                            ,hr.Child_HP_ID  
                            ,hr.EnterDTM  
                            ,hr.EnterUserID  
                            ,hr.LastChgDTM  
                            ,hr.LastChgUserID  
                        FROM mdm.', QUOTENAME(@EntityTableName_HR_HS), N' hr  
                        WHERE   hr.Hierarchy_ID = @ExplicitHierarchy_ID  
                            AND hr.Child_HP_ID IS NOT NULL -- only include rows that assign a consolidated member to a parent  
                    )  
                    ,HPtoPreviousHRmapCte AS -- Link each HP_HS row with the previous HR_HS row, that assigned the consolidated member to a parent  
                    (  
                        SELECT   
                             hp.Version_ID  
                            ,hp.ID  
                            ,MAX(hr.ID) Prev_HR  
                        FROM mdm.', QUOTENAME(@EntityTableName_HP_HS), N' hp  
                        INNER JOIN combinedHRCte hr  
                        ON      hp.Version_ID = hr.Version_ID  
                            AND hp.HP_ID = hr.Child_HP_ID  
                            AND hp.ID >= hr.ID  
                        WHERE hp.Hierarchy_ID = @ExplicitHierarchy_ID  
                        GROUP BY hp.Version_ID, hp.ID  
                    )  
                    ,HRtoPreviousHPmapCte AS -- Link each HR_HS row with the previous HP_HS row, that set the member attribute values  
                    (  
                        SELECT   
                             hr.Version_ID  
                            ,hr.ID  
                            ,MAX(hr.Child_HP_ID) Child_HP_ID  
                            ,MAX(hp.ID) Prev_HP  
                        FROM mdm.', QUOTENAME(@EntityTableName_HR_HS), N' hr  
                        INNER JOIN combinedHPCte hp  
                        ON      hr.Version_ID = hp.Version_ID  
                            AND hr.Child_HP_ID = hp.HP_ID  
                            AND hr.ID >= hp.ID  
                        WHERE hr.Hierarchy_ID = @ExplicitHierarchy_ID  
                        GROUP BY hr.Version_ID, hr.ID  
                    )  
                    INSERT INTO mdm.', QUOTENAME(@NewEntityTableName_EN_HS), N'  
                    (  
                         Version_ID  
                        ,ID  
                        ,EN_ID  
                        ,Status_ID  
                        ,Name  
                        ,Code  
                        ,EnterDTM  
                        ,EnterUserID  
                        ,LastChgDTM  
                        ,LastChgUserID  
                        ,MUID  
                        -- User-defined attributes  
                        ', @NewAttributeColumnNames, N'  
                        -- The new self-referencing DBA  
                        ,', QUOTENAME(@NewRecursiveAttribute_ColumnName), N'   
                    )  
                    SELECT  
                         hp.Version_ID  
                        ,hp.ID  
                        ,hp.HP_ID  
                        ,hp.Status_ID  
                        ,hp.Name  
                        ,hp.Code  
                        ,hp.EnterDTM  
                        ,hp.EnterUserID  
                        ,hp.LastChgDTM  
                        ,hp.LastChgUserID  
                        ,COALESCE(newEn.MUID, hp.MUID) -- actual member MUID. Same when deleting originals, different when copying.  
                        -- User-defined attributes  
                        ', @OldAttributeColumnNames, N'  
                        -- The new self-referencing DBA (pulled from the HR_HS table)  
                        ,hrhs.Parent_HP_ID   
                    FROM mdm.', QUOTENAME(@EntityTableName_HP_HS), N' hp  
                    LEFT JOIN mdm.', QUOTENAME(@NewEntityTableName_EN), N' newEn  
                    ON      hp.Version_ID = newEn.Version_ID  
                        AND hp.HP_ID = newEn.ID  
                    LEFT JOIN HPtoPreviousHRmapCte hpMap  
                    ON      hp.Version_ID = hpMap.Version_ID  
                        AND hp.ID = hpMap.ID  
                    LEFT JOIN combinedHRCte hrhs  
                    ON      hp.Version_ID = hrhs.Version_ID  
                        AND hpMap.Prev_HR = hrhs.ID  
                    WHERE hp.Hierarchy_ID = @ExplicitHierarchy_ID  
  
                    UNION ALL -- deduplication not needed  
  
                    SELECT  
                         hp.Version_ID  
                        ,hrhs.ID  
                        ,hp.HP_ID  
                        ,hp.Status_ID  
                        ,hp.Name  
                        ,hp.Code  
                        ,hp.EnterDTM  
                        ,hp.EnterUserID  
                        ,hp.LastChgDTM  
                        ,hp.LastChgUserID  
                        ,COALESCE(newEn.MUID, hp.MUID) -- actual member MUID. Same when deleting originals, different when copying.  
                        -- User-defined attributes  
                        ', @OldAttributeColumnNames, N'  
                        -- The new self-referencing DBA (pulled from the HR_HS table)  
                        ,hrhs.Parent_HP_ID   
                    FROM mdm.', QUOTENAME(@EntityTableName_HR_HS), N' hrhs   
                    INNER JOIN HRtoPreviousHPmapCte hrMap    
                    ON      hrhs.Version_ID = hrMap.Version_ID  
                        AND hrhs.ID = hrMap.ID  
                    INNER JOIN combinedHPCte hp  
                    ON      hrhs.Version_ID = hp.Version_ID  
                        AND hrMap.Prev_HP = hp.ID  
                    LEFT JOIN mdm.', QUOTENAME(@NewEntityTableName_EN), N' newEn  
                    ON      hp.Version_ID = newEn.Version_ID  
                        AND hp.HP_ID = newEn.ID  
                    WHERE   hrhs.Child_HP_ID IS NOT NULL -- only copy rows that assign a consolidated member to a parent  
                        --AND hp.Hierarchy_ID = @ExplicitHierarchy_ID  
                    ')  
  
                    --PRINT CONCAT('DECLARE @ExplicitHierarchy_ID INT = ', @ExplicitHierarchy_ID)  
                    --PRINT SUBSTRING(@SQL, 0, 4000)  
                    --PRINT SUBSTRING(@SQL, 4000, 4000)  
                    --PRINT SUBSTRING(@SQL, 8000, 4000)  
                    EXEC sp_executesql @SQL ,N'@ExplicitHierarchy_ID INT' ,@ExplicitHierarchy_ID;  
  
PRINT CONCAT(SYSDATETIME(), N': Updating old leaf member history with the HR history info.');  
                    DECLARE @OldLeafAttributeColumnNames NVARCHAR(MAX) = N'';  
                    SELECT  
                        -- Note that this will include new Parent DBAs for other EHs, that have already been converted by a previous loop iteration  
                        @OldLeafAttributeColumnNames = CONCAT(@TruncationGuard, @OldLeafAttributeColumnNames, N'  
                        ,en.', QUOTENAME(TableColumn))  
                    FROM mdm.tblAttribute  
                    WHERE   Entity_ID = @Entity_ID  
                        AND MemberType_ID = @MemberType_Leaf  
                        AND IsSystem = 0  
                        AND ID <> @NewLeafDba_ID; -- Don't include the new DBA here. It will be added separately  
                  
PRINT CONCAT(SYSDATETIME(), N': Update the EN_HS table, setting values for the new DBA column, which come from the old HR and HR_HS tables, for hierarchy ', @ExplicitHierarchyName, N', entity ', @EntityName, N', to new entity ', @NewEntityName);  
                    SET @SQL = CONCAT(@TruncationGuard, N'  
                    -- Update the EN_HS table, setting values for the new DBA column, which come from the old HR and HR_HS tables, for hierarchy ', @ExplicitHierarchyName, N', entity ', @EntityName, N', to new entity ', @NewEntityName, N'  
                    ;WITH combinedENCte AS -- Combine current EN values with history  
                    (  
                        -- current values  
                        SELECT  
                             en.Version_ID  
                            ,COALESCE(en.', QUOTENAME(@TempTimestampColumnName), N', CONVERT(BIGINT, en.LastChgTS)) AS ID -- Use the original Timestamp. The current one may have been modified by setting the new DBA Parent value  
                            ,en.ID AS EN_ID  
                            ,en.Status_ID  
                            ,en.Name  
                            ,en.Code  
                            ,en.EnterDTM  
                            ,en.EnterUserID  
                            ,en.LastChgDTM  
                            ,en.LastChgUserID  
                            ,en.MUID',   
                            @OldLeafAttributeColumnNames, N'  
                            ,en.', QUOTENAME(@NewLeafDba_ColumnName), N' -- New DBA that references the new HP entity  
                        FROM mdm.', QUOTENAME(@EntityTableName_EN), N' en  
                        -- Previous iterations for other EHs on this same entity might have already copied the EN row to the EN_HS table. If so, do not re-add it  
                        LEFT JOIN mdm.', QUOTENAME(@EntityTableName_EN_HS), N' enhs  
                        ON      en.Version_ID = enhs.Version_ID  
                            AND ISNULL(en.', QUOTENAME(@TempTimestampColumnName), N', CONVERT(BIGINT, en.LastChgTS)) = enhs.ID  
                        WHERE enhs.ID IS NULL  
  
                        UNION ALL -- deduplication not needed  
  
                        -- historical values  
                        SELECT  
                             en.Version_ID  
                            ,en.ID  
                            ,en.EN_ID  
                            ,en.Status_ID  
                            ,en.Name  
                            ,en.Code  
                            ,en.EnterDTM  
                            ,en.EnterUserID  
                            ,en.LastChgDTM  
                            ,en.LastChgUserID  
                            ,en.MUID',   
                            @OldLeafAttributeColumnNames, N'  
                            ,en.', QUOTENAME(@NewLeafDba_ColumnName), N' -- New DBA that references the new HP entity  
                        FROM mdm.', QUOTENAME(@EntityTableName_EN_HS), N' en  
                    )  
                    ,combinedHRCte AS -- Combine current HR values with history  
                    (  
                        -- current values  
                        SELECT  
                             hr.Version_ID  
                            ,CONVERT(BIGINT, hr.LastChgTS) AS ID  
                            ,hr.ID AS HR_ID  
                            ,hr.Status_ID  
                            ,hr.Parent_HP_ID  
                            ,hr.Child_EN_ID  
                            ,hr.EnterDTM  
                            ,hr.EnterUserID  
                            ,hr.LastChgDTM  
                            ,hr.LastChgUserID  
                        FROM mdm.', QUOTENAME(@EntityTableName_HR), N' hr  
                        WHERE   hr.Hierarchy_ID = @ExplicitHierarchy_ID  
                            AND hr.Child_EN_ID IS NOT NULL -- only include rows that assign a leaf member to a parent  
  
                        UNION ALL -- deduplication not needed  
  
                        -- historical values. Note: some rows only differ by sort order. But we do not filter those out because they may have their own annotations.  
                        SELECT   
                             hr.Version_ID  
                            ,hr.ID  
                            ,hr.HR_ID  
                            ,hr.Status_ID  
                            ,hr.Parent_HP_ID  
                            ,hr.Child_EN_ID  
                            ,hr.EnterDTM  
                            ,hr.EnterUserID  
                            ,hr.LastChgDTM  
                            ,hr.LastChgUserID  
                        FROM mdm.', QUOTENAME(@EntityTableName_HR_HS), N' hr  
                        WHERE   hr.Hierarchy_ID = @ExplicitHierarchy_ID  
                            AND hr.Child_EN_ID IS NOT NULL -- only include rows that assign a leaf member to a parent  
                    )  
                    ,ENtoPreviousHRmapCte AS -- Link each EN_HS row with the previous HR_HS row, that assigned the leaf member to a parent  
                    (  
                        SELECT   
                             en.Version_ID  
                            ,en.ID  
                            ,MAX(hr.ID) Prev_HR  
                        FROM combinedENCte en  
                        INNER JOIN combinedHRCte hr  
                        ON      en.Version_ID = hr.Version_ID  
                            AND en.EN_ID = hr.Child_EN_ID  
                            AND en.ID >= hr.ID  
                        GROUP BY en.Version_ID, en.ID  
                    )  
                    ,HRtoPreviousENmapCte AS -- Link each HR_HS row with the previous EN_HS row, that set the member attribute values  
                    (  
                        SELECT   
                             hr.Version_ID  
                            ,hr.ID  
                            ,MAX(en.ID) Prev_EN  
                        FROM combinedHRCte hr  
                        INNER JOIN combinedENCte en  
                        ON      hr.Version_ID = en.Version_ID  
                            AND hr.Child_EN_ID = en.EN_ID  
                            AND hr.ID >= en.ID  
                        GROUP BY hr.Version_ID, hr.ID  
                    )  
                    ,combinedRowsCte AS  
                    (  
                        SELECT  
                             en.Version_ID  
                            ,en.ID  
                            ,en.EN_ID  
                            ,en.Status_ID  
                            ,en.Name  
                            ,en.Code  
                            ,en.EnterDTM  
                            ,en.EnterUserID  
                            ,en.LastChgDTM  
                            ,en.LastChgUserID  
                            ,en.MUID  
                            -- User-defined attributes  
                            ', @OldLeafAttributeColumnNames, N'  
                            -- The new leaf parent DBA (value pulled from the HR_HS table)  
                            ,hrhs.Parent_HP_ID ', QUOTENAME(@NewLeafDba_ColumnName), N' -- Alias the parent as its new column name  
                        FROM combinedENCte en  
                        INNER JOIN ENtoPreviousHRmapCte enMap  
                        ON      en.Version_ID = enMap.Version_ID  
                            AND en.ID = enMap.ID  
                        INNER JOIN combinedHRCte hrhs  
                        ON      en.Version_ID = hrhs.Version_ID  
                            AND enMap.Prev_HR = hrhs.ID  
  
                        UNION ALL -- deduplication not needed  
  
                        SELECT  
                             en.Version_ID  
                            ,hrhs.ID  
                            ,en.EN_ID  
                            ,en.Status_ID  
                            ,en.Name  
                            ,en.Code  
                            ,hrhs.EnterDTM  
                            ,hrhs.EnterUserID  
                            ,hrhs.LastChgDTM  
                            ,hrhs.LastChgUserID  
                            ,en.MUID  
                            -- User-defined attributes  
                            ', @OldLeafAttributeColumnNames, N'  
                            -- The new leaf parent DBA (value pulled from the HR_HS table)  
                            ,hrhs.Parent_HP_ID ', QUOTENAME(@NewLeafDba_ColumnName), N' -- Alias the parent as its new column name  
                        FROM combinedHRCte hrhs  
                        INNER JOIN HRtoPreviousENmapCte hrMap    
                        ON      hrhs.Version_ID = hrMap.Version_ID  
                            AND hrhs.ID = hrMap.ID  
                        INNER JOIN combinedENCte en  
                        ON      hrhs.Version_ID = en.Version_ID  
                            AND hrMap.Prev_EN = en.ID  
                    )  
                    MERGE mdm.', QUOTENAME(@EntityTableName_EN_HS), N' enhs  
                    USING combinedRowsCte en  
                    ON      enhs.Version_ID = en.Version_ID  
                        AND enhs.ID = en.ID  
                    WHEN MATCHED THEN  
                        -- The row already exists in the EN_HS table. Simply update the attribute value of the new DBA that references the new HP entity  
                        UPDATE SET enhs.', QUOTENAME(@NewLeafDba_ColumnName), N' = en.', QUOTENAME(@NewLeafDba_ColumnName), N'  
              
                    WHEN NOT MATCHED THEN  
                        -- The row pertains to a row in the HR_HS table. Add a corresponding row to the EN_HS table  
                        INSERT  
                        (  
                             Version_ID  
                            ,ID  
                            ,EN_ID  
                            ,Status_ID  
                            ,Name  
                            ,Code  
                            ,EnterDTM  
                            ,EnterUserID  
                            ,LastChgDTM  
                            ,LastChgUserID  
                            ,MUID  
                            -- User-defined attributes  
                            ', REPLACE(@OldLeafAttributeColumnNames, N'en.', N''), N'  
                            -- The new leaf parent DBA  
                            ,', QUOTENAME(@NewLeafDba_ColumnName), N'   
                        )  
                        VALUES  
                        (  
                             en.Version_ID  
                            ,en.ID  
                            ,en.EN_ID  
                            ,en.Status_ID  
                            ,en.Name  
                            ,en.Code  
                            ,en.EnterDTM  
                            ,en.EnterUserID  
                            ,en.LastChgDTM  
                            ,en.LastChgUserID  
                            ,en.MUID  
                            -- User-defined attributes  
                            ', @OldLeafAttributeColumnNames, N'  
                            -- The new leaf parent DBA  
                            ,en.', QUOTENAME(@NewLeafDba_ColumnName), N'  
                        );')  
  
                    --PRINT CONCAT('DECLARE @ExplicitHierarchy_ID INT = ', @ExplicitHierarchy_ID)  
                    --PRINT SUBSTRING(@SQL, 0, 4000)  
                    --PRINT SUBSTRING(@SQL, 4000, 4000)  
                    --PRINT SUBSTRING(@SQL, 8000, 4000)  
                    --PRINT SUBSTRING(@SQL, 12000, 4000)  
                    EXEC sp_executesql @SQL ,N'@ExplicitHierarchy_ID INT' ,@ExplicitHierarchy_ID;  
  
  
PRINT CONCAT(SYSDATETIME(), N': Copying consolidated member revision annotations from table ', @EntityTableName_HP_AN, N' to ', @NewEntityTableName_EN_AN);  
                    SET @SQL = CONCAT(N'  
                    INSERT INTO mdm.', QUOTENAME(@NewEntityTableName_EN_AN), N'  
                    (  
                         Version_ID  
                        ,Revision_ID  
                        ,Comment  
                        ,EnterDTM  
                        ,EnterUserID  
                        ,LastChgDTM  
                        ,LastChgUserID  
                    )  
                    -- member current revision, need to map old to new revision (LastChgTS)  
                    SELECT   
                         hpAn.Version_ID  
                        ,newEn.LastChgTS AS Revision_ID-- map to the current timestamp in the new leaf entity  
                        ,hpAn.Comment  
                        ,hpAn.EnterDTM  
                        ,hpAn.EnterUserID  
                        ,hpAn.LastChgDTM  
                        ,hpAn.LastChgUserID  
                    FROM mdm.', QUOTENAME(@EntityTableName_HP_AN), N' hpAn  
                    INNER JOIN mdm.', QUOTENAME(@EntityTableName_HP), N' hp  
                    ON      hpAn.Version_ID = hp.Version_ID  
                        AND hpAn.Revision_ID = hp.LastChgTS  
                    INNER JOIN mdm.', QUOTENAME(@NewEntityTableName_EN), N' newEn  
                    ON      hp.Version_ID = newEn.Version_ID  
                        AND hp.ID = newEn.ID  
                    WHERE hp.Hierarchy_ID = @ExplicitHierarchy_ID  
  
                    UNION ALL -- deduplication not needed  
  
                    -- member history  
                    SELECT   
                         hpAn.Version_ID  
                        ,hpAn.Revision_ID  
                        ,hpAn.Comment  
                        ,hpAn.EnterDTM  
                        ,hpAn.EnterUserID  
                        ,hpAn.LastChgDTM  
                        ,hpAn.LastChgUserID  
                    FROM mdm.', QUOTENAME(@EntityTableName_HP_AN), N' hpAn  
                    INNER JOIN mdm.', QUOTENAME(@NewEntityTableName_EN_HS), N' enHs  
                    ON      hpAn.Version_ID = enHs.Version_ID  
                        AND hpAn.Revision_ID = enHs.ID');  
                    --PRINT @SQL  
                    EXEC sp_executesql @SQL, N'@ExplicitHierarchy_ID INT' ,@ExplicitHierarchy_ID;  
  
PRINT CONCAT(SYSDATETIME(), N': Copying member history annotations from table ', @EntityTableName_HR_AN, N' to ', @EntityTableName_EN_AN);  
                    SET @SQL = CONCAT(N'  
                    INSERT INTO mdm.', QUOTENAME(@EntityTableName_EN_AN), N'  
                    (  
                         Version_ID  
                        ,Revision_ID  
                        ,Comment  
                        ,EnterDTM  
                        ,EnterUserID  
                        ,LastChgDTM  
                        ,LastChgUserID  
                    )  
                    -- hierarchy move current revision, need to map old to new revision (LastChgTS)  
                    SELECT   
                         hrAn.Version_ID  
                        ,newEn.LastChgTS AS Revision_ID-- map to the current timestamp in the new leaf entity  
                        ,hrAn.Comment  
                        ,hrAn.EnterDTM  
                        ,hrAn.EnterUserID  
                        ,hrAn.LastChgDTM  
                        ,hrAn.LastChgUserID  
                    FROM mdm.', QUOTENAME(@EntityTableName_HR_AN), N' hrAn  
                    INNER JOIN mdm.', QUOTENAME(@EntityTableName_HR), N' hr  
                    ON      hrAn.Version_ID = hr.Version_ID  
                        AND hrAn.Revision_ID = hr.LastChgTS  
                    INNER JOIN mdm.', QUOTENAME(@NewEntityTableName_EN), N' newEn  
                    ON      hr.Version_ID = newEn.Version_ID  
                        AND hr.Child_HP_ID = newEn.ID  
                    LEFT JOIN mdm.', QUOTENAME(@EntityTableName_EN_HS), N' enHs  
                    ON      hrAn.Version_ID = enHs.Version_ID  
                        AND hrAn.Revision_ID = enHs.ID  
                    WHERE   hr.Hierarchy_ID = @ExplicitHierarchy_ID  
                        AND enHs.ID IS NULL -- do not include revisions that are already in the new EN_HS table. They will be covered by the below query  
  
                    UNION ALL -- deduplication not needed  
  
                    -- historical hierarchy moves  
                    SELECT   
                         hrAn.Version_ID  
                        ,hrAn.Revision_ID  
                        ,hrAn.Comment  
                        ,hrAn.EnterDTM  
                        ,hrAn.EnterUserID  
                        ,hrAn.LastChgDTM  
                        ,hrAn.LastChgUserID  
                    FROM mdm.', QUOTENAME(@EntityTableName_HR_AN), N' hrAn  
                    INNER JOIN mdm.', QUOTENAME(@EntityTableName_EN_HS), N' enHs  
                    ON      hrAn.Version_ID = enHs.Version_ID  
                        AND hrAn.Revision_ID = enHs.ID  
                        ');  
                    --PRINT @SQL  
                    EXEC sp_executesql @SQL, N'@ExplicitHierarchy_ID INT' ,@ExplicitHierarchy_ID;  
                END -- Copy Member history for consolidated members  
  
                -- Create new Derived Hierarchy.  
  
                -- Get a unique Derived Hierarchy name. First, try to use the same name as the EH (if the name isn't already being used by an existing DH, then this would be more user-friendly. Otherwise, generate a unique name)  
                SET @NewDerivedHierarchyName = @ExplicitHierarchyName;  
                SET @counter = -1;  
                WHILE (1=1) -- TSQL doesn't support a DO-WHILE loop, so use a tautology as this WHILE condition to simulate a post-test loop.  
                BEGIN  
                    -- If the new entity name is unique within the model, then exit the loop.  
                    IF NOT EXISTS (SELECT 1 FROM mdm.tblDerivedHierarchy WHERE Model_ID = @Model_ID AND Name = @NewDerivedHierarchyName)  
                    BEGIN  
                        BREAK;  
                    END;  
  
                    -- The name wasn't unique, so increment the counter.  
                    SET @counter += 1;  
  
                    -- Ideally, the new entity name should reference both the leaf entity name and the explicit hierarchy name. However, there is a risk  
                    -- that this could exceed the max name length, in which case we need to be smart about where to do the truncation.  
                    IF (@EntityNameLength + @HierarchyNameLength + 4/*allow room for the underscore and the counter*/ <= @MaxMetadataObjectNameLength)  
                    BEGIN  
                        -- The entity and hierarchy names are short enough that they can be concatenated together without exceeding the max length  
                        SET @NewDerivedHierarchyName = CONCAT(@EntityName, N'_', @ExplicitHierarchyName, CASE @counter WHEN 0 THEN N'' ELSE CONVERT(NVARCHAR, @counter) END);  
                    END  
                    ELSE  
                    BEGIN  
                        -- The entity and hierarchy names are together too long, so use truncation. Each name is limited to slightly less than half of the max length. Note  
                        -- that this approach may not be the most sophisticated way of doing it (it could result in overly-aggressive truncation in the case where one name  
                        -- is significantly longer than the other), but it is cheap to implement and should be sufficient since this is an edge case, anyways.  
                        SET @NewDerivedHierarchyName = CONCAT(SUBSTRING(@EntityName, 0, @HalfMaxLen), N'_', SUBSTRING(@ExplicitHierarchyName, 0, @HalfMaxLen), CASE @counter WHEN 0 THEN N'' ELSE CONVERT(NVARCHAR, @counter) END);  
                    END;  
  
                END; -- WHILE (get unique derived hierarchy name)  
  
                -- Create the new derived hierarchy.  
PRINT CONCAT(SYSDATETIME(), N': Creating a new recursive derived hierarchy "', @NewDerivedHierarchyName, N'"');  
                SET @NewDerivedHierarchy_ID = 0;  
                EXEC mdm.udpDerivedHierarchySave   
                     @User_ID = @User_ID  
                    ,@Model_ID = @Model_ID  
                    ,@Name = @NewDerivedHierarchyName  
                    ,@AnchorNullRecursions = 1  
                    ,@Return_ID = @NewDerivedHierarchy_ID OUTPUT  
  
                -- Save conversion info to facilitate BR and security permission copying later in the script.  
                INSERT INTO #EH_ConversionLog  
                SELECT   
                     @ExplicitHierarchy_ID  
                    ,@ExplicitHierarchyName  
                    ,@Entity_ID  
                    ,@NewLeafDba_ID  
                    ,@NewLeafDbaName  
                    ,@NewEntity_ID  
                    ,@NewDerivedHierarchy_ID  
                    ,@NewRecursiveAttribute_ID  
                    ,@NewRecursiveAttributeName  
  
  
                -- Update the new DH's audit info to match the EH's audit info.  
                UPDATE mdm.tblDerivedHierarchy  
                SET  EnterDTM = @EnterDTM  
                    ,EnterUserID = @EnterUserID  
                    ,EnterVersionID = @EnterVersionID  
                    ,LastChgDTM = @LastChgDTM  
                    ,LastChgUserID = @LastChgUserID  
                    ,LastChgVersionID = @LastChgVersionID  
                WHERE ID = @NewDerivedHierarchy_ID;  
  
                -- Add the leaf member level.  
PRINT CONCAT(SYSDATETIME(), N': Adding leaf level "', @EntityName, '" to hierarchy "', @NewDerivedHierarchyName, N'"');  
                EXEC mdm.udpDerivedHierarchyDetailSave  
                  @User_ID = @User_ID  
                 ,@Model_ID = @Model_ID  
                 ,@DerivedHierarchy_ID = @NewDerivedHierarchy_ID  
                 ,@Foreign_ID = @Entity_ID  
                 ,@ForeignType_ID = @HierarchyItemType_Entity  
                 ,@Name = @EntityName  
                 ,@DisplayName = @EntityName  
                 ,@IsVisible = 1  
                 ,@Return_ID = @NewLevel_ID OUTPUT  
  
                -- Add the two recursive levels.  
                 SET @NewLevelName = SUBSTRING(@NewLeafDbaName, 0, @MaxHierarchyLevelNameLength)  
                 IF @NewLevelName = @EntityName  
                 BEGIN  
                    SET @NewLevelName = CONCAT(SUBSTRING(@NewLevelName, 0, @MaxHierarchyLevelNameLength - 1), N'1');  
                 END  
PRINT CONCAT(SYSDATETIME(), N': Adding recursive level "', @NewLevelName, '" to hierarchy "', @NewDerivedHierarchyName, N'"');  
                EXEC mdm.udpDerivedHierarchyDetailSave  
                  @User_ID = @User_ID  
                 ,@Model_ID = @Model_ID  
                 ,@DerivedHierarchy_ID = @NewDerivedHierarchy_ID  
                 ,@Foreign_ID = @NewLeafDba_ID  
                 ,@ForeignType_ID = @HierarchyItemType_DBA  
                 ,@Name = @NewLevelName  
                 ,@DisplayName = @NewLevelName  
                 ,@IsVisible = 1  
                 ,@Return_ID = @NewLevel_ID OUTPUT  
              
                -- Update the new DH level's audit info to match the EH's audit info.  
                UPDATE mdm.tblDerivedHierarchyDetail  
                SET  EnterDTM = @EnterDTM  
                    ,EnterUserID = @EnterUserID  
                    ,EnterVersionID = @EnterVersionID  
                    ,LastChgDTM = @LastChgDTM  
                    ,LastChgUserID = @LastChgUserID  
                    ,LastChgVersionID = @LastChgVersionID  
                WHERE ID = @NewLevel_ID;  
  
  
                 SET @NewLevelName = SUBSTRING(@NewRecursiveAttributeName, 0, @MaxHierarchyLevelNameLength)  
                 SET @counter = 0;  
                 WHILE EXISTS (SELECT 1 FROM mdm.tblDerivedHierarchyDetail WHERE DerivedHierarchy_ID = @NewDerivedHierarchy_ID AND Name = @NewLevelName)  
                 BEGIN  
                    SET @counter += 1;  
                    SET @NewLevelName += CONCAT(@NewRecursiveAttributeName, @counter);  
                 END  
PRINT CONCAT(SYSDATETIME(), N': Adding recursive level "', @NewLevelName, '" to hierarchy "', @NewDerivedHierarchyName, N'"');  
                EXEC mdm.udpDerivedHierarchyDetailSave  
                  @User_ID = @User_ID  
                 ,@Model_ID = @Model_ID  
                 ,@DerivedHierarchy_ID = @NewDerivedHierarchy_ID  
                 ,@Foreign_ID = @NewRecursiveAttribute_ID  
                 ,@ForeignType_ID = @HierarchyItemType_DBA  
                 ,@Name = @NewLevelName  
                 ,@DisplayName = @NewRecursiveAttributeName  
                 ,@IsVisible = 1  
                 ,@Return_ID = @NewLevel_ID OUTPUT  
  
                -- Update the new DH level's audit info to match the EH's audit info.  
                UPDATE mdm.tblDerivedHierarchyDetail  
                SET  EnterDTM = @EnterDTM  
                    ,EnterUserID = @EnterUserID  
                    ,EnterVersionID = @EnterVersionID  
                    ,LastChgDTM = @LastChgDTM  
                    ,LastChgUserID = @LastChgUserID  
                    ,LastChgVersionID = @LastChgVersionID  
                WHERE ID = @NewLevel_ID;  
  
  
                -- Determine if the explicit hierarchy was being used as an explicit cap of any DHs. If so, create a copy of each DH with the explicit cap replaced by a recursive level.  
PRINT CONCAT(SYSDATETIME(), N': Getting list of derived hierarchies that use EH "', @ExplicitHierarchyName, N'" as an explicit cap');  
                DELETE FROM @ExplicitCapHierarchies;  
                INSERT INTO @ExplicitCapHierarchies  
                SELECT DISTINCT   
                     dh.ID  
                    ,dh.Name  
                FROM mdm.tblDerivedHierarchy dh  
                INNER JOIN mdm.tblDerivedHierarchyDetail dhd  
                ON dh.ID = dhd.DerivedHierarchy_ID  
                WHERE   dhd.ForeignType_ID = @HierarchyItemType_ExplicitHierarchy  
                    AND dhd.Foreign_ID = @ExplicitHierarchy_ID;  
  
                -- Loop through each DH that the current explicit hierarchy caps.  
                DECLARE   
                     @DerivedHierarchy_ID INT = 0  
                    ,@DerivedHierarchyName NVARCHAR(50) = NULL;  
                WHILE EXISTS (SELECT 1 FROM @ExplicitCapHierarchies WHERE DerivedHierarchy_ID > @DerivedHierarchy_ID)  
                BEGIN  
                    -- Get the next explicit cap hierarchy id.  
                    SELECT TOP 1   
                         @DerivedHierarchy_ID = DerivedHierarchy_ID  
                        ,@DerivedHierarchyName = DerivedHierarchyName  
                    FROM @ExplicitCapHierarchies   
                    WHERE DerivedHierarchy_ID > @DerivedHierarchy_ID  
                    ORDER BY DerivedHierarchy_ID;  
  
                    -- Get a unique Derived Hierarchy name.  
                    SET @counter = 0;  
                    DECLARE @NoCap NVARCHAR(10) = N'_NoCap';  
                    WHILE (1=1) -- TSQL doesn't support a DO-WHILE loop, so use a tautology as this WHILE condition to simulate a post-test loop.  
                    BEGIN  
                        SET @NewDerivedHierarchyName = CONCAT(SUBSTRING(@DerivedHierarchyName, 0, @MaxMetadataObjectNameLength - LEN(@NoCap) - 3), @NoCap, CASE @counter WHEN 0 THEN N'' ELSE CONVERT(NVARCHAR, @counter) END);  
  
                        -- If the new entity name is unique within the model, then exit the loop.  
                        IF NOT EXISTS (SELECT 1 FROM mdm.tblDerivedHierarchy WHERE Model_ID = @Model_ID AND Name = @NewDerivedHierarchyName)  
                        BEGIN  
                            BREAK;  
                        END;  
  
                        -- The name wasn't unique, so increment the counter for the next loop iteration.  
                        SET @counter += 1;  
                    END; -- WHILE (get unique derived hierarchy name)  
  
                    -- Create a new derived hierarchy.  
PRINT CONCAT(SYSDATETIME(), N': Created new hierarchy, "', @NewDerivedHierarchyName, N'", as a copy of explicit cap hierarchy "', @DerivedHierarchyName, N'".');  
                    SET @NewDerivedHierarchy_ID = 0;  
                    EXEC mdm.udpDerivedHierarchySave  
                         @User_ID = @User_ID  
                        ,@Model_ID = @Model_ID  
                        ,@Name = @NewDerivedHierarchyName  
                        ,@AnchorNullRecursions = 1  
                        ,@Return_ID = @NewDerivedHierarchy_ID OUTPUT;  
  
                    -- Update the new DH's audit info to match the EH's audit info.  
                    UPDATE mdm.tblDerivedHierarchy  
                    SET  EnterDTM = @EnterDTM  
                        ,EnterUserID = @EnterUserID  
                        ,EnterVersionID = @EnterVersionID  
                        ,LastChgDTM = @LastChgDTM  
                        ,LastChgUserID = @LastChgUserID  
                        ,LastChgVersionID = @LastChgVersionID  
                    WHERE ID = @NewDerivedHierarchy_ID;  
          
                    -- Copy the existing DH levels, minus the explicit cap.  
PRINT CONCAT(SYSDATETIME(), N': Copying non-explicit levels.');  
                    INSERT INTO mdm.tblDerivedHierarchyDetail  
                    (  
                         DerivedHierarchy_ID  
                        ,Name  
                        ,DisplayName  
                        ,ForeignParent_ID  
                        ,Foreign_ID  
                        ,ForeignType_ID  
                        ,Level_ID  
                        ,IsVisible  
                        ,EnterDTM  
                        ,EnterUserID  
                        ,EnterVersionID  
                        ,LastChgDTM  
                        ,LastChgUserID  
                        ,LastChgVersionID  
                    )  
                    SELECT  
                         @NewDerivedHierarchy_ID  
                        ,Name  
                        ,DisplayName  
                        ,ForeignParent_ID  
                        ,Foreign_ID  
                        ,ForeignType_ID  
                        ,Level_ID  
                        ,IsVisible  
                        ,EnterDTM  
                        ,EnterUserID  
                        ,EnterVersionID  
                        ,LastChgDTM  
                        ,LastChgUserID  
                        ,LastChgVersionID  
                    FROM mdm.tblDerivedHierarchyDetail  
                    WHERE   DerivedHierarchy_ID = @DerivedHierarchy_ID  
                        AND ForeignType_ID <> @HierarchyItemType_ExplicitHierarchy -- Exclude the explicit cap level  
          
                    -- Add two levels for the new recursive cap that takes the place of the explicit cap.  
                 SET @NewLevelName = SUBSTRING(@NewLeafDbaName, 0, @MaxHierarchyLevelNameLength)  
                 SET @counter = 0;  
                 WHILE EXISTS (SELECT 1 FROM mdm.tblDerivedHierarchyDetail WHERE DerivedHierarchy_ID = @NewDerivedHierarchy_ID AND Name = @NewLevelName)  
                 BEGIN  
                    SET @counter += 1;  
                    SET @NewLevelName += CONCAT(@NewRecursiveAttributeName, @counter);  
                 END  
PRINT CONCAT(SYSDATETIME(), N': Adding recursive level "', @NewLevelName, '" to hierarchy "', @NewDerivedHierarchyName, N'" to take the place of the explicit cap.');  
                    EXEC mdm.udpDerivedHierarchyDetailSave  
                      @User_ID = @User_ID  
                     ,@Model_ID = @Model_ID  
                     ,@DerivedHierarchy_ID = @NewDerivedHierarchy_ID  
                     ,@Foreign_ID = @NewLeafDba_ID  
                     ,@ForeignType_ID = @HierarchyItemType_DBA  
                     ,@Name = @NewLevelName  
                     ,@DisplayName = @NewLevelName  
                     ,@IsVisible = 1  
                     ,@Return_ID = @NewLevel_ID OUTPUT;  
                  
                    -- Update the new DH level's audit info to match the EH's audit info.  
                    UPDATE mdm.tblDerivedHierarchyDetail  
                    SET  EnterDTM = @EnterDTM  
                        ,EnterUserID = @EnterUserID  
                        ,EnterVersionID = @EnterVersionID  
                        ,LastChgDTM = @LastChgDTM  
                        ,LastChgUserID = @LastChgUserID  
                        ,LastChgVersionID = @LastChgVersionID  
                    WHERE ID = @NewLevel_ID;  
  
                 SET @NewLevelName = SUBSTRING(@NewRecursiveAttributeName, 0, @MaxHierarchyLevelNameLength)  
                 SET @counter = 0;  
                 WHILE EXISTS (SELECT 1 FROM mdm.tblDerivedHierarchyDetail WHERE DerivedHierarchy_ID = @NewDerivedHierarchy_ID AND Name = @NewLevelName)  
                 BEGIN  
                    SET @counter += 1;  
                    SET @NewLevelName += CONCAT(@NewRecursiveAttributeName, @counter);  
                 END  
PRINT CONCAT(SYSDATETIME(), N': Adding recursive level "', @NewLevelName, '" to hierarchy "', @NewDerivedHierarchyName, N'" to take the place of the explicit cap.');  
                    EXEC mdm.udpDerivedHierarchyDetailSave  
                      @User_ID = @User_ID  
                     ,@Model_ID = @Model_ID  
                     ,@DerivedHierarchy_ID = @NewDerivedHierarchy_ID  
                     ,@Foreign_ID = @NewRecursiveAttribute_ID  
                     ,@ForeignType_ID = @HierarchyItemType_DBA  
                     ,@Name = @NewLevelName  
                     ,@DisplayName = @NewLevelName  
                     ,@IsVisible = 1  
                     ,@Return_ID = @NewLevel_ID OUTPUT;  
  
                    -- Update the new DH level's audit info to match the EH's audit info.  
                    UPDATE mdm.tblDerivedHierarchyDetail  
                    SET  EnterDTM = @EnterDTM  
                        ,EnterUserID = @EnterUserID  
                        ,EnterVersionID = @EnterVersionID  
                        ,LastChgDTM = @LastChgDTM  
                        ,LastChgUserID = @LastChgUserID  
                        ,LastChgVersionID = @LastChgVersionID  
                    WHERE ID = @NewLevel_ID;  
                END -- WHILE (loop through explicit cap DHs)  
            END; -- WHILE (loop through explicit hierarchies)  
  
            IF @TransactionLogType = @TransactionLogType_Member  
            BEGIN  
PRINT CONCAT(SYSDATETIME(), N': Deleting temporary LastChgTS column from table ', @EntityTableName_EN);  
                -- Remove the temporary LastChgTS column that was added to the EN table (it is not needed for Collection processing below, because the process does not change the original EN table)  
                SET @SQL = CONCAT(N'  
                DROP INDEX ', QUOTENAME(CONCAT(N'ix_', @EntityTableName_EN, N'_Version_ID_', @TempTimestampColumnName)), N' ON mdm.', QUOTENAME(@EntityTableName_EN), N';  
                ALTER TABLE mdm.', QUOTENAME(@EntityTableName_EN), N' DROP COLUMN ', QUOTENAME(@TempTimestampColumnName));  
                --PRINT @SQL  
  
                EXEC sp_executesql @SQL;  
            END  
  
  
        END -- Loop through entities, converting their EHs  
  
        -- Copy business rules. This is done after all of the EHs are copied (rather than for each hierarchy, within the above loop  
        -- because a rule could reference more than one EH parent.)  
PRINT CONCAT(SYSDATETIME(), N': Copying business rules.');  
  
  
        -- Get a list of all rules that need to be copied, including  
        -- 1. Consolidated BRs  
        -- 2. Leaf BRs that reference any of the explicit hierarchies that were converted to derived hierarchies.  
        CREATE TABLE #BusinessRule_IDs   
        (     
              BusinessRule_ID   INT --PRIMARY KEY -- Consolidated members could be copied to multiple entities, so may not be unique.  
             ,Entity_ID         INT NOT NULL DEFAULT 0  
             ,NewEntity_ID      INT -- N/A for leaf BRs  
             ,MemberType_ID     TINYINT   
        );  
        CREATE INDEX #ix_BusinessRule_IDs_BusinessRule_ID ON #BusinessRule_IDs(BusinessRule_ID);  
        WITH convertedEntities AS  
        (  
            SELECT DISTINCT Entity_ID  
            FROM @ExplicitHierarchies  
        )  
        ,brsToCopyCte AS -- get list of all BRs that need to be copied  
        (  
            SELECT DISTINCT   
                 b.ID  
                ,b.Entity_ID  
                --,cl2.NewEntity_ID  
                ,b.MemberType_ID  
            FROM mdm.tblBRBusinessRule b  
            INNER JOIN mdm.viw_SYSTEM_SCHEMA_BUSINESSRULE_PROPERTIES bp  
            ON b.ID = bp.BusinessRule_ID  
            LEFT JOIN #EH_ConversionLog cl  
            ON      bp.PropertyType_ID = @BRPropertyType_ParentAttribute  
                AND bp.Property_Value = CONVERT(NVARCHAR, cl.ExplicitHierarchy_ID)  
            LEFT JOIN convertedEntities en  
            ON      b.MemberType_ID = @MemberType_Consolidated  
                AND b.Entity_ID = en.Entity_ID  
            WHERE  cl.ExplicitHierarchy_ID IS NOT NULL  -- Get only rules that either reference a copied consolidated parent, or...  
                OR en.Entity_ID IS NOT NULL             -- ... apply to copied consolidated members.  
        )  
        INSERT INTO #BusinessRule_IDs  
        SELECT DISTINCT   
             b.ID AS BusinessRule_ID  
            ,b.Entity_ID  
            ,cl.NewEntity_ID  
            ,b.MemberType_ID  
        FROM brsToCopyCte b  
        LEFT JOIN #EH_ConversionLog cl -- for each Consolidated BR, make one copy per EH. Make only a single copy of each Leaf BR that references consolidated members  
        ON      b.MemberType_ID = @MemberType_Consolidated  
            AND b.Entity_ID = cl.Entity_ID  
  
        -- Create temp tables to map between old (original) and new (copied) table rows.  
        CREATE TABLE #BRBusinessRuleRowMappings   
        (  
             OldRow_ID      INT --PRIMARY KEY -- Consolidated members could be copied to multiple entities, so may not be unique.  
            ,NewRow_ID      INT  
            ,MemberType_ID  TINYINT  
            ,NewEntity_ID   INT -- N/A for leaf BRs  
        );  
        CREATE INDEX #ix_BRBusinessRuleRowMappings_OldRow_ID ON #BRBusinessRuleRowMappings(OldRow_ID);  
        CREATE TABLE #BRLogicalOperatorRowMappings  
        (  
             OldRow_ID      INT --PRIMARY KEY -- Consolidated members could be copied to multiple entities, so may not be unique.  
            ,NewRow_ID      INT  
            ,MemberType_ID  TINYINT  
        );  
        CREATE INDEX #ix_BRLogicalOperatorRowMappings_OldRow_ID ON #BRLogicalOperatorRowMappings(OldRow_ID);  
        CREATE TABLE #BRItemRowMappings  
        (  
             OldRow_ID      INT --PRIMARY KEY -- Consolidated members could be copied to multiple entities, so may not be unique.  
            ,NewRow_ID      INT  
        );  
        CREATE INDEX #ix_BRItemRowMappings_OldRow_ID ON #BRItemRowMappings(OldRow_ID);  
        CREATE TABLE #BRItemPropertiesRowMappings  
        (  
             OldRow_ID      INT --PRIMARY KEY -- Consolidated members could be copied to multiple entities, so may not be unique.  
            ,NewRow_ID      INT  
            ,NewBRItem_ID   INT  
        );  
        CREATE INDEX #ix_BRItemPropertiesRowMappings_OldRow_ID ON #BRItemPropertiesRowMappings(OldRow_ID);  
  
        DECLARE @RuleIDs        mdm.IdList;  
  
        SET @Entity_ID = 0;  
        DECLARE @ReplaceSQL NVARCHAR(MAX);  
        WHILE EXISTS (SELECT 1 FROM #BusinessRule_IDs WHERE Entity_ID > @Entity_ID)  
        BEGIN  
            -- Get the next entity ID.  
            SELECT TOP 1   
                @Entity_ID = Entity_ID  
            FROM #BusinessRule_IDs   
            WHERE Entity_ID > @Entity_ID   
            ORDER BY Entity_ID  
PRINT CONCAT(SYSDATETIME(), N': Copying Leaf Business Rules for @Entity_ID = ', @Entity_ID);  
  
            -- Ensure the row mapping tables are empty.  
            DELETE FROM #BRBusinessRuleRowMappings;  
            DELETE FROM #BRLogicalOperatorRowMappings;  
            DELETE FROM #BRItemRowMappings;  
            DELETE FROM #BRItemPropertiesRowMappings;  
  
            -- Create a dynamic SQL string that will replace all EH attribute references with new domain entity attribute references. This requires one REPLACE statement per EH in the entity.  
            SET @ReplaceSQL = NULL;  
            SELECT @ReplaceSQL = @TruncationGuard + CONCAT(N'REPLACE( ' + COALESCE(@ReplaceSQL, N'{0}') + N', N''Parent.', c.ExplicitHierarchyName, N'.'', CONCAT(N''DBA.'', CASE id.MemberType_ID WHEN ', @MemberType_Leaf, N' THEN N''', c.LeafParentDbaName, N''' ELSE N''', c.NewEntityRecursiveDbaName, N''' END, N''.''))')  
            FROM #EH_ConversionLog c  
            WHERE Entity_ID = @Entity_ID;  
PRINT CONCAT(SYSDATETIME(), N': @ReplaceSQL = "',   @ReplaceSQL, N'"');  
  
            -- Copy  mdm.tblBRBusinessRule rows.  
PRINT CONCAT(SYSDATETIME(), N': Copying mdm.tblBRBusinessRule rows.');  
            SET @SQL = CONCAT(@TruncationGuard, N'  
            MERGE mdm.tblBRBusinessRule  
            USING  
            (  
                SELECT    
                     b.ID  
                    ,SUBSTRING(CONCAT(b.Name, N''_NoEH''), 0, 50) AS Name -- Name is not constrained to be unique  
                    ,b.Description  
                    ,', REPLACE(@ReplaceSQL, N'{0}', N'b.RuleConditionText' ), N' AS RuleConditionText  
                    ,', REPLACE(@ReplaceSQL, N'{0}', N'b.RuleActionText' ), N' AS RuleActionText  
                    ,', REPLACE(@ReplaceSQL, N'{0}', N'b.RuleElseActionText' ), N' AS RuleElseActionText  
                    ,b.MemberType_ID  
                    ,b.Entity_ID  
                    ,id.NewEntity_ID  
                    ,CASE b.Status_ID  
                        WHEN ', @BRStatus_Active, N'           THEN ', @BRStatus_ActivationPending, N'  
                        WHEN ', @BRStatus_ChangesPending, N'   THEN ', @BRStatus_ActivationPending, N'  
                        WHEN ', @BRStatus_ExcludePending, N'   THEN ', @BRStatus_Excluded, N'  
                        ELSE b.Status_ID END AS Status_ID  
                    ,b.Priority  
                    ,b.NotificationGroupID  
                    ,b.NotificationUserID  
                    ,b.EnterDTM  
                    ,b.EnterUserID  
                    ,b.LastChgDTM  
                    ,b.LastChgUserID  
                FROM mdm.tblBRBusinessRule b  
                INNER JOIN #BusinessRule_IDs id  
                ON b.ID = id.BusinessRule_ID  
                WHERE id.Entity_ID = @Entity_ID  
            ) r  
            ON (1 = 0) -- An arbitrary condition that is always false, so that the NOT MATCHED block will always be hit.  
            WHEN NOT MATCHED THEN  
            INSERT  
            (  
                 Name  
                ,Description  
                ,RuleConditionText  
                ,RuleActionText  
                ,RuleElseActionText  
                ,MemberType_ID  
                ,Entity_ID  
                ,Status_ID  
                ,Priority  
                ,NotificationGroupID  
                ,NotificationUserID  
                ,EnterDTM  
                ,EnterUserID  
                ,LastChgDTM  
                ,LastChgUserID  
            )  
            VALUES  
            (  
                 r.Name  
                ,r.Description  
                ,r.RuleConditionText  
                ,r.RuleActionText  
                ,r.RuleElseActionText  
                ,', @MemberType_Leaf, N' -- The BR copy is always leaf  
                ,CASE r.MemberType_ID WHEN ', @MemberType_Consolidated, N' THEN r.NewEntity_ID ELSE r.Entity_ID END  
                ,r.Status_ID  
                ,r.Priority  
                ,r.NotificationGroupID  
                ,r.NotificationUserID  
                ,r.EnterDTM  
                ,r.EnterUserID  
                ,r.LastChgDTM  
                ,r.LastChgUserID  
            )  
            OUTPUT   
                 r.ID  
                ,inserted.ID  
                ,r.MemberType_ID  
                ,r.NewEntity_ID  
            --INTO @RuleMappings(OldRule_ID, NewRule_ID);  
            INTO #BRBusinessRuleRowMappings  
            (  
                 OldRow_ID  
                ,NewRow_ID  
                ,MemberType_ID  
                ,NewEntity_ID  
            );  
');  
            --PRINT @SQL;  
            EXEC sp_executesql @SQL, N'@Entity_ID INT', @Entity_ID;  
  
            -- Copy  mdm.tblBRLogicalOperatorGroup rows. No special processing needed here.  
PRINT CONCAT(SYSDATETIME(), N': Copying mdm.tblBRLogicalOperatorGroup rows.');  
            MERGE mdm.tblBRLogicalOperatorGroup  
            USING  
            (  
                SELECT  
                     brlog.ID  
                    ,brlog.LogicalOperator_ID  
                    ,br.NewRow_ID AS NewBusinessRule_ID  
                    ,brlog.Parent_ID   
                    ,brlog.Sequence  
                    ,br.MemberType_ID  
                FROM mdm.tblBRLogicalOperatorGroup brlog  
                INNER JOIN #BRBusinessRuleRowMappings br  
                ON brlog.BusinessRule_ID = br.OldRow_ID  
            ) lg  
            ON (1 = 0) -- An arbitrary condition that is always false, so that the NOT MATCHED block will always be hit.  
            WHEN NOT MATCHED THEN  
            INSERT  
            (  
                 LogicalOperator_ID  
                ,BusinessRule_ID  
                ,Parent_ID  
                ,Sequence  
            )  
            VALUES  
            (  
                 lg.LogicalOperator_ID  
                ,lg.NewBusinessRule_ID  
                ,lg.Parent_ID -- This is the old parent. It will need to be updated to reference the copy of the original parent.  
                ,lg.Sequence  
            )  
            OUTPUT lg.ID, inserted.ID, lg.MemberType_ID  
            INTO #BRLogicalOperatorRowMappings (OldRow_ID, NewRow_ID, MemberType_ID);  
  
  
PRINT CONCAT(SYSDATETIME(), N': Updating tblBRLogicalOperatorGroup.Parent_ID');  
            -- Update the Parent_ID column to point to the copied row.  
            UPDATE new  
            SET Parent_ID = newParent.NewRow_ID  
            FROM mdm.tblBRLogicalOperatorGroup new  
            INNER JOIN #BRLogicalOperatorRowMappings newChild  
            ON new.ID = newChild.NewRow_ID  
            INNER JOIN #BRLogicalOperatorRowMappings newParent  
            ON new.Parent_ID = newParent.OldRow_ID  
  
            -- Copy mdm.tblBRItem rows  
PRINT CONCAT(SYSDATETIME(), N': Copying mdm.tblBRItem rows');  
            SET @SQL = @TruncationGuard + N'  
            MERGE mdm.tblBRItem  
            USING  
            (  
                SELECT  
                     i.ID    
                    ,id.NewRow_ID AS NewBRLogicalOperatorGroup_ID  
                    ,i.BRItemAppliesTo_ID  
                    ,i.Sequence  
                    ,' + REPLACE(@ReplaceSQL, N'{0}', N'i.ItemText' ) + N' AS ItemText  
                    ,' + REPLACE(@ReplaceSQL, N'{0}', N'i.AnchorName' ) + N' AS AnchorName  
                    ,i.AnchorAttributeType  
                FROM mdm.tblBRItem i  
                INNER JOIN #BRLogicalOperatorRowMappings id  
                ON i.BRLogicalOperatorGroup_ID = id.OldRow_ID  
            ) i  
            ON (1 = 0) -- An arbitrary condition that is always false, so that the NOT MATCHED block will always be hit.  
            WHEN NOT MATCHED THEN  
            INSERT  
            (  
                 BRLogicalOperatorGroup_ID  
                ,BRItemAppliesTo_ID  
                ,Sequence  
                ,ItemText  
                ,AnchorName  
                ,AnchorAttributeType  
            )  
            VALUES  
            (  
                 i.NewBRLogicalOperatorGroup_ID  
                ,i.BRItemAppliesTo_ID  
                ,i.Sequence  
                ,i.ItemText  
                ,i.AnchorName   
                ,i.AnchorAttributeType  
            )  
            OUTPUT i.ID, inserted.ID  
            INTO #BRItemRowMappings(OldRow_ID, NewRow_ID);  
            ';  
            --PRINT @SQL;  
            EXEC sp_executesql @SQL;  
  
PRINT CONCAT(SYSDATETIME(), N': Copying mdm.tblBRItemProperties rows');  
            MERGE mdm.tblBRItemProperties  
            USING  
            (  
                SELECT  
                     bip.ID  
                    ,bi.NewRow_ID AS NewBRItem_ID  
                    ,CASE bip.PropertyType_ID WHEN @BRPropertyType_ParentAttribute THEN @BRPropertyType_DBA ELSE bip.PropertyType_ID END AS PropertyType_ID  
                    ,bip.PropertyName_ID  
                    ,COALESCE(CONVERT(NVARCHAR(999), eh.LeafParentDba_ID), CONVERT(NVARCHAR(999), ca.NewAttribute_ID), bip.Value) AS Value  
                    ,bip.Sequence  
                    ,bip.IsLeftHandSide  
                    ,bip.Parent_ID  
                    ,bip.SuppressText  
                FROM mdm.tblBRItemProperties bip  
                INNER JOIN #BRItemRowMappings bi  
                ON bip.BRItem_ID = bi.OldRow_ID  
  
                -- Match rows whose Value is an EH ID  
                LEFT JOIN #EH_ConversionLog eh --   
                ON      bip.PropertyType_ID = @BRPropertyType_ParentAttribute  
                    AND bip.Value = CONVERT(NVARCHAR(999), eh.ExplicitHierarchy_ID)  
  
                -- Match rows whose Value is a consolidated attribute ID.  
                LEFT JOIN #AttributeMapping ca   
                ON      ca.OldMemberType = @MemberType_Consolidated  
                    AND bip.PropertyType_ID = @BRPropertyType_Attribute  
                    AND bip.Value = CONVERT(NVARCHAR(999), ca.OldAttribute_ID)  
            ) p  
            ON (1 = 0) -- An arbitrary condition that is always false, so that the NOT MATCHED block will always be hit.  
            WHEN NOT MATCHED THEN  
            INSERT  
            (  
                 BRItem_ID  
                ,PropertyType_ID  
                ,PropertyName_ID  
                ,Value  
                ,Sequence  
                ,IsLeftHandSide  
                ,Parent_ID  
                ,SuppressText  
            )  
            VALUES  
            (  
                 p.NewBRItem_ID  
                ,p.PropertyType_ID  
                ,p.PropertyName_ID  
                ,p.Value  
                ,p.Sequence  
                ,p.IsLeftHandSide  
                ,p.Parent_ID -- This is the old parent. It will need to be updated to reference the copy of the original parent.  
                ,p.SuppressText  
            )  
            OUTPUT p.ID, inserted.ID, inserted.BRItem_ID  
            INTO #BRItemPropertiesRowMappings (OldRow_ID, NewRow_ID, NewBRItem_ID);  
  
            -- Update the Parent_ID column to point to the copied row.  
PRINT CONCAT(SYSDATETIME(), N': Updating the Parent_ID column to point to the copied row');  
            UPDATE new  
            SET Parent_ID = newParent.NewRow_ID  
            FROM mdm.tblBRItemProperties new  
            INNER JOIN #BRItemPropertiesRowMappings newChild  
            ON new.ID = newChild.NewRow_ID  
            INNER JOIN #BRItemPropertiesRowMappings newParent  
            ON      new.Parent_ID = newParent.OldRow_ID  
                AND new.BRItem_ID = newParent.NewBRItem_ID  
  
            IF @DeleteOriginals = 1  
            BEGIN  
PRINT CONCAT(SYSDATETIME(), N': Looking for old BR sprocs to delete');  
                SET @SQL = N'';  
                ;WITH brSprocsCte AS  
                (  
                    SELECT DISTINCT  
                        mdm.udfBusinessRuleAttributeMemberControllerNameGetByID(@Entity_ID, br.MemberType_ID) AS SprocName  
                    FROM #BRBusinessRuleRowMappings br  
                )  
                SELECT  
                    @SQL += CONCAT(N'DROP PROCEDURE mdm.', QUOTENAME(SprocName), N'  
')  
                FROM brSprocsCte br  
                INNER JOIN sys.procedures p  
                ON OBJECT_ID(br.SprocName) = p.object_id  
  
                IF LEN(@SQL) > 0  
                BEGIN   
PRINT CONCAT(SYSDATETIME(), N': Deleting entity''s old BR sprocs');  
                    PRINT @SQL;  
                    EXEC sp_executesql @SQL;  
                END  
  
PRINT CONCAT(SYSDATETIME(), N': Deleting entity''s old BRs from BR tables');  
                DELETE @RuleIDs  
                INSERT INTO @RuleIDs(ID)  
                SELECT DISTINCT OldRow_ID  
                FROM #BRBusinessRuleRowMappings;  
  
                EXEC mdm.udpBusinessRulesDelete @RuleIDs = @RuleIDs  
  
PRINT CONCAT(SYSDATETIME(), N': Updating status of entity''s remaining BRs');  
                UPDATE br  
                SET   
                    br.Status_ID = CASE br.Status_ID  
                        WHEN @BRStatus_Active           THEN @BRStatus_ActivationPending  
                        WHEN @BRStatus_ChangesPending   THEN @BRStatus_ActivationPending  
                        WHEN @BRStatus_ExcludePending   THEN @BRStatus_Excluded  
                        ELSE br.Status_ID END  
                FROM mdm.tblBRBusinessRule br  
                INNER JOIN #BRBusinessRuleRowMappings newbr  
                ON br.MemberType_ID = newbr.MemberType_ID  
                    AND br.Entity_ID = @Entity_ID  
            END  
        END; -- WHILE (loop through each entity's leaf business rules)  
  
  
  
  
  
        -- Loop through each entity with collections and copy the collections.  
        SET @Entity_ID = 0;  
        DECLARE @HasCustomCollectionMetadata BIT;  
        WHILE EXISTS (SELECT 1 FROM @EntityInfo WHERE Entity_ID > @Entity_ID AND EntityTableName_CN IS NOT NULL)  
        BEGIN  
            -- Get the next entity with collections in the list.  
            SELECT TOP 1  
                 @Entity_ID = Entity_ID  
                ,@EntityName = EntityName  
                ,@DataCompression = DataCompression  
                ,@TransactionLogType = TransactionLogType  
                ,@Model_ID = Model_ID  
                ,@EntityTableName_CN = EntityTableName_CN  
                ,@EntityTableName_CN_HS = CONCAT(EntityTableName_CN, N'_HS')  
                ,@EntityTableName_CN_AN = CONCAT(EntityTableName_CN, N'_AN')  
                ,@EntityTableName_CM = EntityTableName_CM  
                ,@EntityTableName_CM_HS = CONCAT(EntityTableName_CM, N'_HS')  
                ,@EntityTableName_CM_AN = CONCAT(EntityTableName_CM, N'_AN')  
                ,@EntityTableName_HP = EntityTableName_HP  
                ,@HasCustomCollectionMetadata = HasCustomCollectionMetadata  
            FROM @EntityInfo  
            WHERE   Entity_ID > @Entity_ID   
                AND EntityTableName_CN IS NOT NULL  
            ORDER BY Entity_ID;  
  
PRINT ''  
            IF @HasCustomCollectionMetadata = 0  
            BEGIN  
                -- There is no custom collection metadata. See if the collection table has members. If there is no user-defined metadata or master data, then we don't need to bother creating new entities, etc, for it.  
                DECLARE @HasCollections BIT;  
                SET @SQL = CONCAT(N'SET @HasCollections = CASE WHEN EXISTS(SELECT 1 FROM mdm.', QUOTENAME(@EntityTableName_CN), N') THEN 1 ELSE 0 END;' )  
                EXEC sp_executesql @SQL, N'@HasCollections BIT OUTPUT', @HasCollections OUTPUT  
                IF @HasCollections = 0   
                BEGIN  
PRINT CONCAT(SYSDATETIME(), N': Entity "', @EntityName, N'" has collection tables but contains no collection metadata or members to convert. Skipping...');  
                    CONTINUE;  
                END  
            END  
  
PRINT CONCAT(SYSDATETIME(), N': Create new entity for entity "', @EntityName, N'"''s collection members.');  
            SET @counter = 0;  
            WHILE (1=1) -- TSQL doesn't support a DO-WHILE loop, so use a tautology as this WHILE condition to simulate a post-test loop.  
            BEGIN  
                SET @suffix = '_Col';  
                SET @NewEntityName = CONCAT(SUBSTRING(@EntityName, 0, @MaxMetadataObjectNameLength - LEN(@suffix) - 4), @suffix, CASE @counter WHEN 0 THEN N'' ELSE CONVERT(NVARCHAR, @counter) END);  
  
                -- If the new attribute name is unique within the entity-member type, then exit the loop.  
                IF NOT EXISTS (SELECT 1 FROM mdm.tblEntity WHERE Model_ID = @Model_ID AND Name = @NewEntityName)  
                BEGIN  
                    BREAK;  
                END;  
  
                -- The name wasn't unique, so increment the counter for the next loop iteration.  
                SET @counter += 1;  
            END; -- WHILE (get unique attribute name)  
  
            SET @NewEntityDescription = CONCAT(N'Contains collection members, converted to leaf members, copied from the "', @EntityName, N'" entity.');  
              
            SET @NewEntity_ID = 0;  
            EXEC mdm.udpEntitySave   
                 @User_ID = @User_ID  
                ,@Model_ID = @Model_ID  
                ,@EntityName = @NewEntityName  
                ,@DataCompression = @DataCompression  
                ,@TransactionLogType = @TransactionLogType  
                ,@RequireApproval = 0 -- Consolidated and Collection members don't support the Approval Flow feature, so the new entity created doesn't either. Users may manually change this later, if desired.  
                ,@Description = @NewEntityDescription  
                ,@RecreateStagingProc = 0 -- for efficiency, staging sprocs will be recreated only after all attributes have been created (rather than once for each attribute)  
                ,@Return_ID = @NewEntity_ID OUTPUT  
  
PRINT CONCAT(SYSDATETIME(), N': Created new entity "', @NewEntityName, N'" (ID = ', @NewEntity_ID, N') that is a copy of entity "', @EntityName, N'" (ID = ', @Entity_ID, N').''s collection members.');  
              
            UPDATE @EntityInfo  
            SET New_CN_Entity_ID = @NewEntity_ID  
            WHERE Entity_ID = @Entity_ID  
  
            -- Get the name of the new entity's EN table.  
            DECLARE   
                 @NewEntityTableName_CN     SYSNAME  
                ,@NewEntityTableName_CN_HS  SYSNAME  
                ,@NewEntityTableName_CN_AN  SYSNAME  
            SELECT   
                 @NewEntityTableName_CN = EntityTable  
                ,@NewEntityTableName_CN_HS  = CONCAT(EntityTable, N'_HS')  
                ,@NewEntityTableName_CN_AN  = CONCAT(EntityTable, N'_AN')  
                ,@NewEntityStagingLeafName = StagingLeafName  
            FROM mdm.tblEntity  
            WHERE ID = @NewEntity_ID;  
  
            -- Add the collection system attributes (CN table only, not CM table) to the mapping table (needed for converting transactions, object security, and BRs)  
            INSERT INTO #AttributeMapping  
            (  
                 OldAttribute_ID  
                ,OldMemberType  
                ,OldEntity_ID  
                ,NewAttribute_ID  
                ,NewEntity_ID  
            )  
            SELECT  
                 oldA.ID  
                ,oldA.MemberType_ID  
                ,oldA.Entity_ID  
                ,newA.ID  
                ,newA.Entity_ID  
            FROM mdm.tblAttribute oldA  
            INNER JOIN mdm.tblAttribute newA  
            ON oldA.Name = newA.Name  
            WHERE   oldA.Entity_ID = @Entity_ID  
                AND oldA.MemberType_ID = @MemberType_Collection  
                AND oldA.IsSystem = 1  
                AND oldA.Name NOT IN (N'Owner_ID', N'Description') -- These collection system attributes will be added later  
                AND newA.Entity_ID = @NewEntity_ID  
                AND newA.IsSystem = 1  
  
            -- Get a list of all non-system collection attributes in the entity.  
            DELETE FROM @AttributeInfo;  
            INSERT INTO @AttributeInfo  
            SELECT  
                 ID  
                ,DisplayName  
                ,Name  
                ,Description  
                ,TableColumn  
                ,AttributeType_ID  
                ,DataType_ID  
                ,DataTypeInformation  
                ,InputMask_ID  
                ,DisplayWidth  
                ,SortOrder  
                ,DomainEntity_ID  
                ,ChangeTrackingGroup  
            FROM mdm.tblAttribute   
            WHERE   Entity_ID = @Entity_ID  
                AND MemberType_ID = @MemberType_Collection  
                AND (IsSystem = 0 OR Name IN (N'Owner_ID', N'Description'))  
            SET @Attribute_ID = 0;  
  
            -- Loop through each collection attribute, copying it to the new entity as a leaf attribute.  
            SET @NewAttributeColumnNames = N'';  
            SET @OldAttributeColumnNames = N'';  
            WHILE EXISTS (SELECT 1 FROM @AttributeInfo WHERE Attribute_ID > @Attribute_ID)  
            BEGIN  
                -- Get the next attribute's info.  
                SELECT TOP 1   
                     @Attribute_ID = Attribute_ID  
                    ,@DisplayName = DisplayName  
                    ,@Name = Name  
                    ,@Description = Description  
                    ,@OldAttributeColumnNames += @TruncationGuard + N'  
                ,' + CASE Name WHEN 'Owner_ID'   
                        THEN 'u.UserName' -- User the owner's user name, rather than its INT id (cn.Owner_ID)  
                        ELSE 'cn.' + ColumnName END  
                    ,@AttributeType_ID = AttributeType_ID  
                    ,@DataType_ID = DataType_ID  
                    ,@DataTypeInformation = DataTypeInformation  
                    ,@InputMask_ID = InputMask_ID  
                    ,@DisplayWidth = DisplayWidth  
                    ,@SortOrder = SortOrder  
                    ,@DomainEntity_ID = DomainEntity_ID  
                    ,@ChangeTrackingGroup = ChangeTrackingGroup  
                FROM @AttributeInfo   
                WHERE Attribute_ID > @Attribute_ID  
                ORDER BY Attribute_ID  
  
                -- Add an attribute to the new entity that is a leaf copy of the collection attribute.  
                SET @NewAttribute_ID = NULL;  
                EXEC mdm.udpAttributeSave  
                     @User_ID = @User_ID  
                    ,@Model_ID = @Model_ID  
                    ,@Entity_ID = @NewEntity_ID  
                    ,@IsHierarchyEnabled = 0  
                    ,@IsCollectionEnabled = 0  
                    ,@DataCompression = @DataCompression  
                    ,@TableName = @NewEntityTableName_CN  
                    ,@StagingTableName = @NewEntityStagingLeafName  
                    ,@MemberType_ID = @MemberType_Leaf  
                    ,@AttributeType_ID = @AttributeType_ID  
                    ,@AttributeName = @Name  
                    ,@Description = @Description  
                    ,@DisplayName = @DisplayName  
                    ,@DisplayWidth = @DisplayWidth  
                    ,@DomainEntity_ID = @DomainEntity_ID  
                    ,@DataType_ID = @DataType_ID  
                    ,@DataTypeInformation = @DataTypeInformation  
                    ,@InputMask_ID = @InputMask_ID  
                    ,@ChangeTrackingGroup = @ChangeTrackingGroup  
                    ,@SortOrder = @SortOrder  
                    ,@RecreateStagingProc = 0 -- for efficiency, staging sprocs will be recreated only after all attributes have been created (rather than once for each attribute)  
                    ,@Return_ID = @NewAttribute_ID OUTPUT;    
  
                SELECT @NewAttributeColumnNames += @TruncationGuard + N'  
                ,' + TableColumn  
                FROM mdm.tblAttribute WHERE ID = @NewAttribute_ID;  
  
PRINT CONCAT(SYSDATETIME(), N': Copied attribute "', @Name, N'" (ID = ', @Attribute_ID, N') to new entity. New attribute ID = ', @NewAttribute_ID);  
                -- Keep track of the mapping between the old and new attributes.  
                INSERT INTO #AttributeMapping  
                (  
                     OldAttribute_ID  
                    ,OldMemberType  
                    ,OldEntity_ID  
                    ,NewAttribute_ID  
                    ,NewEntity_ID  
                )  
                SELECT  
                     @Attribute_ID  
                    ,@MemberType_Collection  
                    ,@Entity_ID  
                    ,@NewAttribute_ID  
                    ,@NewEntity_ID  
            END -- WHILE (loop through entity's collection attributes)  
  
PRINT CONCAT(SYSDATETIME(), N': Copy the member master data, from collection members in the old entity to leaf members in the new entity.');  
            SET @SQL = @TruncationGuard + N'  
            SET IDENTITY_INSERT mdm.' + QUOTENAME(@NewEntityTableName_CN) + N' ON; -- This allows the query to specify the ID column, which will be set to match the ID in the old CN table, so that the parent-child values can be directly copied from the CM table to the new collection membership mapping entity  
  
            INSERT INTO mdm.' + QUOTENAME(@NewEntityTableName_CN) + N'  
            (  
                -- System attributes  
                 Version_ID  
                ,ID  
                ,Status_ID  
                ,ValidationStatus_ID  
                ,Name  
                ,Code  
                ,EnterDTM  
                ,EnterUserID  
                ,EnterVersionID  
                ,LastChgDTM  
                ,LastChgUserID  
                ,LastChgVersionID  
                ,AsOf_ID'   
                + CASE @DeleteOriginals WHEN 1 THEN N'  
                ,MUID' ELSE N'' END -- Use the original MUID when the original will be deleted  
                + N'  
  
                -- User-defined attributes  
                ' + @NewAttributeColumnNames + N'  
            )  
            SELECT  
                -- System attributes  
                 cn.Version_ID  
                ,cn.ID  
                ,cn.Status_ID  
                ,cn.ValidationStatus_ID  
                ,cn.Name  
                ,cn.Code  
                ,cn.EnterDTM  
                ,cn.EnterUserID  
                ,cn.EnterVersionID  
                ,cn.LastChgDTM  
                ,cn.LastChgUserID  
                ,cn.LastChgVersionID   
                ,cn.AsOf_ID'  
                + CASE @DeleteOriginals WHEN 1 THEN N'  
                ,cn.MUID' ELSE N'' END -- Use the original MUID when the original will be deleted  
                + N'  
  
                -- User-defined attributes  
                ' + @OldAttributeColumnNames + N'  
            FROM mdm.' + QUOTENAME(@EntityTableName_CN) + N' cn  
            LEFT JOIN mdm.tblUser u -- used to get the user name for the Owner_ID attribute  
            ON cn.Owner_ID = u.ID  
  
            SET IDENTITY_INSERT mdm.' + QUOTENAME(@NewEntityTableName_CN) + N' OFF;   
            ';  
            --PRINT @SQL  
            EXEC sp_executesql @SQL;  
  
            IF @TransactionLogType = @TransactionLogType_Member  
            BEGIN  
PRINT CONCAT(SYSDATETIME(), N': Copying collection history from ', @EntityTableName_CN_HS, N' to ', @NewEntityTableName_CN_HS);  
  
                SET @SQL = CONCAT(@TruncationGuard, N'  
                INSERT INTO mdm.', QUOTENAME(@NewEntityTableName_CN_HS), N'  
                (  
                     Version_ID  
                    ,ID  
                    ,EN_ID  
                    ,Status_ID  
                    ,Name  
                    ,Code  
                    ,EnterDTM  
                    ,EnterUserID  
                    ,LastChgDTM  
                    ,LastChgUserID  
                    ,MUID  
                    -- User-defined attributes  
                    ',@NewAttributeColumnNames, N'  
                )  
                SELECT  
                     cn.Version_ID  
                    ,cn.ID  
                    ,cn.CN_ID  
                    ,cn.Status_ID  
                    ,cn.Name  
                    ,cn.Code  
                    ,cn.EnterDTM  
                    ,cn.EnterUserID  
                    ,cn.LastChgDTM  
                    ,cn.LastChgUserID  
                    ,COALESCE(newEn.MUID, cn.MUID) -- actual member MUID. Same when deleting originals, different when copying.  
                    -- User-defined attributes  
                    ', @OldAttributeColumnNames, N'  
                FROM mdm.', QUOTENAME(@EntityTableName_CN_HS), N' cn  
                LEFT JOIN mdm.', QUOTENAME(@NewEntityTableName_CN), N' newEn  
                ON      cn.Version_ID = newEn.Version_ID  
                    AND cn.CN_ID = newEn.ID  
                LEFT JOIN mdm.tblUser u -- used to get the user name for the Owner_ID attribute  
                ON cn.Owner_ID = u.ID  
                ')  
  
                --PRINT @SQL  
                EXEC sp_executesql @SQL;  
  
PRINT CONCAT(SYSDATETIME(), N': Copying collection annotations from table ', @EntityTableName_CN_AN, N' to ', @NewEntityTableName_CN_AN);  
                SET @SQL = CONCAT(N'  
                INSERT INTO mdm.', QUOTENAME(@NewEntityTableName_CN_AN), N'  
                (  
                        Version_ID  
                    ,Revision_ID  
                    ,Comment  
                    ,EnterDTM  
                    ,EnterUserID  
                    ,LastChgDTM  
                    ,LastChgUserID  
                )  
                -- collection current revision, need to map old to new revision (LastChgTS)  
                SELECT   
                     cnAn.Version_ID  
                    ,newEn.LastChgTS AS Revision_ID-- map to the current timestamp in the new leaf entity  
                    ,cnAn.Comment  
                    ,cnAn.EnterDTM  
                    ,cnAn.EnterUserID  
                    ,cnAn.LastChgDTM  
                    ,cnAn.LastChgUserID  
                FROM mdm.', QUOTENAME(@EntityTableName_CN_AN), N' cnAn  
                INNER JOIN mdm.', QUOTENAME(@EntityTableName_CN), N' cn  
                ON      cnAn.Version_ID = cn.Version_ID  
                    AND cnAn.Revision_ID = cn.LastChgTS  
                INNER JOIN mdm.', QUOTENAME(@NewEntityTableName_CN), N' newEn  
                ON      cn.Version_ID = newEn.Version_ID  
                    AND cn.ID = newEn.ID  
                LEFT JOIN mdm.', QUOTENAME(@EntityTableName_CN_HS), N' cnHs  
                ON      cnAn.Version_ID = cnHs.Version_ID  
                    AND cnAn.Revision_ID = cnHs.ID  
                WHERE cnHs.ID IS NULL -- do not include revisions that are already in the new EN_HS table. They will be covered by the below query  
  
                UNION ALL -- deduplication not needed  
  
                -- collection history  
                SELECT   
                     cnAn.Version_ID  
                    ,cnAn.Revision_ID  
                    ,cnAn.Comment  
                    ,cnAn.EnterDTM  
                    ,cnAn.EnterUserID  
                    ,cnAn.LastChgDTM  
                    ,cnAn.LastChgUserID  
                FROM mdm.', QUOTENAME(@EntityTableName_CN_AN), N' cnAn  
                INNER JOIN mdm.', QUOTENAME(@EntityTableName_CN_HS), N' cnHs  
                ON      cnAn.Version_ID = cnHs.Version_ID  
                    AND cnAn.Revision_ID = cnHs.ID  
                    ');  
                --PRINT @SQL  
                EXEC sp_executesql @SQL;  
  
            END -- copy CN member history and annotations  
  
  
  
  
  
PRINT CONCAT(SYSDATETIME(), N': Create new entity for collection membership info');  
            DECLARE @NewEntity_ID_CN INT = @NewEntity_ID; -- save the ID of the new CN-table-equivalent entity  
            DECLARE @NewEntityName_CN NVARCHAR(50) = @NewEntityName; -- save the name of the new CN-table-equivalent entity  
            SET @counter = 0;  
            WHILE (1=1) -- TSQL doesn't support a DO-WHILE loop, so use a tautology as this WHILE condition to simulate a post-test loop.  
            BEGIN  
                SET @suffix = '_ColMem';  
                SET @NewEntityName = CONCAT(SUBSTRING(@EntityName, 0, @MaxMetadataObjectNameLength - LEN(@suffix) - 4), @suffix, CASE @counter WHEN 0 THEN N'' ELSE CONVERT(NVARCHAR, @counter) END);  
  
                -- If the new attribute name is unique within the entity-member type, then exit the loop.  
                IF NOT EXISTS (SELECT 1 FROM mdm.tblEntity WHERE Model_ID = @Model_ID AND Name = @NewEntityName)  
                BEGIN  
                    BREAK;  
                END;  
  
                -- The name wasn't unique, so increment the counter for the next loop iteration.  
                SET @counter += 1;  
            END; -- WHILE (get unique entity name)  
  
            SET @NewEntityDescription = CONCAT(N'Contains collection membership info, copied from the "', @EntityName, N'" entity.');  
              
            SET @NewEntity_ID = 0;  
            EXEC mdm.udpEntitySave   
                 @User_ID = @User_ID  
                ,@Model_ID = @Model_ID  
                ,@EntityName = @NewEntityName  
                ,@DataCompression = @DataCompression  
                ,@TransactionLogType = @TransactionLogType  
                ,@RequireApproval = 0 -- Consolidated and Collection members don't support the Approval Flow feature, so the new entity created doesn't either. Users may manually change this later, if desired.  
                ,@Description = @NewEntityDescription  
                ,@RecreateStagingProc = 0 -- for efficiency, staging sprocs will be recreated only after all attributes have been created (rather than once for each attribute)  
                ,@Return_ID = @NewEntity_ID OUTPUT  
  
PRINT CONCAT(SYSDATETIME(), N': Created new entity "', @NewEntityName, N'" (ID = ', @NewEntity_ID, N') that is a copy of entity "', @EntityName, N'" (ID = ', @Entity_ID, N').''s collection membership info.');  
            UPDATE @EntityInfo  
            SET New_CM_Entity_ID = @NewEntity_ID  
            WHERE Entity_ID = @Entity_ID  
  
            -- Get the name of the new entity's EN table.  
            DECLARE   
                 @NewEntityTableName_CM     SYSNAME  
                ,@NewEntityTableName_CM_HS  SYSNAME  
                ,@NewEntityTableName_CM_AN  SYSNAME  
            SELECT   
                 @NewEntityTableName_CM = EntityTable  
                ,@NewEntityTableName_CM_HS  = CONCAT(EntityTable, N'_HS')  
                ,@NewEntityTableName_CM_AN  = CONCAT(EntityTable, N'_AN')  
                ,@NewEntityStagingLeafName = StagingLeafName  
            FROM mdm.tblEntity  
            WHERE ID = @NewEntity_ID;  
  
  
PRINT CONCAT(SYSDATETIME(), N': Creating collection membership entity attributes.');  
            DELETE FROM @CollectionMembershipAttributes  
            DECLARE   
                 @CollectionHasChildren     BIT  
                ,@RowID                     INT  
                ,@ChildAttributeNamePrefix  NVARCHAR(50) = N'Child_'  
  
  
            IF @EntityTableName_HP IS NOT NULL -- Check for consolidated children, if the entity being copied support consolidated members   
            BEGIN  
                -- See if the CM table references any HP members  
                SET @SQL = CONCAT(N'SET @CollectionHasConsolidatedChildren = CASE WHEN EXISTS (SELECT 1 FROM mdm.', QUOTENAME(@EntityTableName_CM), N' WHERE Child_HP_ID IS NOT NULL AND Status_ID = 1/*Active*/) THEN 1 ELSE 0 END')  
                --PRINT @SQL  
                EXEC sp_executesql @SQL, N'@CollectionHasConsolidatedChildren BIT OUTPUT', @CollectionHasChildren OUTPUT;  
                IF @CollectionHasChildren = 1  
                BEGIN  
                    -- Check each converted EH's entity tables, to see if its members are referenced by the CM table  
  
                    INSERT INTO @CollectionMembershipAttributes -- consolidated children DBAs  
                    (  
                         Name  
                        ,DomainEntity_ID  
                        ,DomainEntityName  
                        ,DomainEntityTableName  
                    )  
                    SELECT  
                         CONCAT(@ChildAttributeNamePrefix, e.Name)  
                        ,e.ID  
                        ,e.Name  
                        ,e.EntityTable  
                    FROM #EH_ConversionLog eh  
                    INNER JOIN mdm.tblEntity e  
                    ON eh.NewEntity_ID = e.ID  
                    WHERE eh.Entity_ID = @Entity_ID;  
  
                    -- Prune out rows for new consolidated entities that are not referenced by the CM table  
                    SET @RowID = 0  
                    WHILE EXISTS (SELECT 1 FROM @CollectionMembershipAttributes WHERE RowID > @RowID)  
                    BEGIN   
                        SELECT TOP 1   
                              @RowID = RowID  
                             ,@SQL = CONCAT(N'SET @CollectionHasConsolidatedChildren = CASE WHEN EXISTS   
                                                    (SELECT 1   
                                                    FROM mdm.', QUOTENAME(@EntityTableName_CM), N' cm  
                                                    INNER JOIN mdm.', QUOTENAME(DomainEntityTableName), N' en  
                                                    ON cm.Child_HP_ID = en.ID  
                                                    WHERE cm.Status_ID = 1/*Active*/)   
                                                THEN 1 ELSE 0 END')  
                        FROM @CollectionMembershipAttributes  
                        WHERE RowID > @RowID  
                        ORDER BY RowID  
  
                        --PRINT @SQL  
                        EXEC sp_executesql @SQL, N'@CollectionHasConsolidatedChildren BIT OUTPUT', @CollectionHasChildren OUTPUT;  
                        IF @CollectionHasChildren = 0  
                        BEGIN  
                            -- The old EH doesn't have any consolidated members referenced by the CM table. So we don't need to add to the new CM entity a DBA that references the new consolidated entity.  
                            DELETE @CollectionMembershipAttributes WHERE RowID = @RowID;  
                        END  
  
                    END -- while  
  
                END  
            END -- if the copied entity supports consolidated members  
  
            DECLARE   
                 @ManyToManyParentAttribute_ID  INT  
                ,@ManyToManyParentAttributeName NVARCHAR(100) = CONCAT(N'Parent_', @NewEntityName_CN)  
            INSERT INTO @CollectionMembershipAttributes  
            (  
                 Name  
                ,DomainEntity_ID  
                ,DomainEntityName  
                ,OldColumnName  
            )  
            SELECT   
                  @ManyToManyParentAttributeName  
                 ,@NewEntity_ID_CN  
                 ,@NewEntityName_CN  
                 ,N'Parent_CN_ID' -- parent DBA  
  
            -- Don't add a DBA for leaf children unless the CM table actually references some  
            --PRINT @SQL  
            SET @SQL = CONCAT(N'SET @CollectionHasLeafChildren = CASE WHEN EXISTS (SELECT 1 FROM mdm.', QUOTENAME(@EntityTableName_CM), N' WHERE Child_EN_ID IS NOT NULL AND Status_ID = 1/*Active*/) THEN 1 ELSE 0 END')  
            --PRINT @SQL  
            EXEC sp_executesql @SQL, N'@CollectionHasLeafChildren BIT OUTPUT', @CollectionHasChildren OUTPUT;  
            IF @CollectionHasChildren = 1  
            BEGIN   
                INSERT INTO @CollectionMembershipAttributes  
                (  
                     Name  
                    ,DomainEntity_ID  
                    ,DomainEntityName  
                    ,OldColumnName  
                )  
                SELECT   
                     CONCAT(@ChildAttributeNamePrefix, @EntityName)  
                    ,@Entity_ID  
                    ,@EntityName  
                    ,N'Child_EN_ID' -- leaf children DBA  
            END  
  
            -- Don't add a DBA for collection children unless the CM table actually references some  
            SET @SQL = CONCAT(N'SET @CollectionHasCollectionChildren = CASE WHEN EXISTS (SELECT 1 FROM mdm.', QUOTENAME(@EntityTableName_CM), N' WHERE Child_CN_ID IS NOT NULL AND Status_ID = 1/*Active*/) THEN 1 ELSE 0 END')  
              
            --PRINT @SQL  
            EXEC sp_executesql @SQL, N'@CollectionHasCollectionChildren BIT OUTPUT', @CollectionHasChildren OUTPUT;  
            IF @CollectionHasChildren = 1  
            BEGIN   
                INSERT INTO @CollectionMembershipAttributes  
                (  
                     Name  
                    ,DomainEntity_ID  
                    ,DomainEntityName  
                    ,OldColumnName  
                )  
                SELECT   
                     CONCAT(@ChildAttributeNamePrefix, @NewEntityName_CN)  
                    ,@NewEntity_ID_CN  
                    ,@NewEntityName_CN  
                    ,N'Child_CN_ID' -- collection children DBA  
            END  
  
            INSERT INTO @CollectionMembershipAttributes  
            (  
                  Name  
                 ,DataTypeInformation  
            )  
            VALUES   
                 (N'Weight', 3)  
                ,(N'SortOrder', 0)   
  
            DECLARE   
                 @JoinSQL               NVARCHAR(MAX) = N''  
            SET @NewAttributeColumnNames = N'';  
            SET @OldAttributeColumnNames = N'';  
            SET @RowID = 0  
            WHILE EXISTS (SELECT 1 FROM @CollectionMembershipAttributes WHERE RowID > @RowID)  
            BEGIN   
                -- Get the next attribute's info.  
                SELECT TOP 1   
                     @RowID = RowID  
                    ,@Name = Name  
                    ,@AttributeType_ID = CASE WHEN DomainEntity_ID IS NULL THEN @AttributeType_Freeform ELSE @AttributeType_Domain END  
                    ,@DataType_ID = CASE WHEN DomainEntity_ID IS NULL THEN @DataType_Number ELSE @DataType_Text END  
                    ,@DataTypeInformation = COALESCE(DataTypeInformation, 100)  
                    ,@DomainEntity_ID = DomainEntity_ID  
  
                    ,@OldAttributeColumnNames += CONCAT(@TruncationGuard, N'  
                ,cm', CASE   
                        WHEN OldColumnName IS NOT NULL THEN CONCAT(N'.', QUOTENAME(OldColumnName))  
                        WHEN DomainEntity_ID IS NOT NULL THEN CONCAT(DomainEntity_ID, N'.ID ', QUOTENAME(Name))  
                        ELSE CONCAT(N'.', QUOTENAME(Name)) END)  
  
                    ,@JoinSQL += CONCAT(@TruncationGuard, CASE WHEN DomainEntityTableName IS NOT NULL THEN CONCAT(N'  
            LEFT JOIN mdm.', QUOTENAME(DomainEntityTableName), N' cm', DomainEntity_ID, N'  
            ON cm.Child_HP_ID = cm', DomainEntity_ID, N'.ID  
                AND cm.Version_ID = cm', DomainEntity_ID, N'.Version_ID')  
                        END)  
                FROM @CollectionMembershipAttributes   
                WHERE RowID > @RowID  
                ORDER BY RowID  
  
PRINT CONCAT(SYSDATETIME(), N': Creating attribute "', @Name, N'", DomainEntityID = ', @DomainEntity_ID, N') in collection membership entity "', @NewEntityName, N'" (ID = ', @NewEntity_ID, N').');  
                SET @NewAttribute_ID = NULL;  
                EXEC mdm.udpAttributeSave  
                     @User_ID = @User_ID  
                    ,@Model_ID = @Model_ID  
                    ,@Entity_ID = @NewEntity_ID  
                    ,@IsHierarchyEnabled = 0  
                    ,@IsCollectionEnabled = 0  
                    ,@DataCompression = @DataCompression  
                    ,@TableName = @NewEntityTableName_CM  
                    ,@StagingTableName = @NewEntityStagingLeafName  
                    ,@MemberType_ID = @MemberType_Leaf  
                    ,@AttributeType_ID = @AttributeType_ID  
                    ,@AttributeName = @Name  
                    ,@Description = NULL  
                    ,@DisplayName = @Name  
                    ,@DisplayWidth = 100  
                    ,@DomainEntity_ID = @DomainEntity_ID  
                    ,@DataType_ID = @DataType_ID  
                    ,@DataTypeInformation = @DataTypeInformation  
                    ,@InputMask_ID = 1  
                    ,@ChangeTrackingGroup = 0  
                    ,@SortOrder = NULL  
                    ,@RecreateStagingProc = 0 -- for efficiency, staging sprocs will be recreated only after all attributes have been created (rather than once for each attribute)  
                    ,@Return_ID = @NewAttribute_ID OUTPUT;    
PRINT CONCAT(SYSDATETIME(), N': Created attribute "', @Name, N'" (ID = ', @NewAttribute_ID, N').');  
                  
                UPDATE @CollectionMembershipAttributes  
                SET  
                     NewAttribute_ID = @NewAttribute_ID  
                    ,NewColumnName = (SELECT TableColumn FROM mdm.tblAttribute WHERE ID = @NewAttribute_ID)  
                WHERE RowID = @RowID  
  
                IF @Name = @ManyToManyParentAttributeName  
                BEGIN  
                    SET @ManyToManyParentAttribute_ID = @NewAttribute_ID;  
                END  
            END -- WHILE (create collection membership DBAs)  
  
            SELECT @NewAttributeColumnNames += CONCAT(@TruncationGuard, N'  
                ,', NewColumnName)  
            FROM @CollectionMembershipAttributes  
            ORDER BY RowID  
  
            -- Create new members for CM table rows  
  
PRINT CONCAT(SYSDATETIME(), N': Adding collection membership info members to entity "', @NewEntityName, N'" (ID = ', @NewEntity_ID, N').');  
            SET @SQL = CONCAT(@TruncationGuard, N'  
            --SELECT * FROM mdm.', QUOTENAME(@EntityTableName_CM), N'  
  
            SET IDENTITY_INSERT mdm.', QUOTENAME(@NewEntityTableName_CM), N' ON; -- This allows the query to specify the ID column, which will be set to match the ID in the old CM table  
              
            INSERT INTO mdm.', QUOTENAME(@NewEntityTableName_CM), N'  
            (  
                 Version_ID  
                ,ID  
                ,Status_ID  
                ,Code  
  
                ,EnterDTM  
                ,EnterUserID  
                ,EnterVersionID  
                ,LastChgDTM  
                ,LastChgUserID  
                ,LastChgVersionID  
                ,AsOf_ID'   
                ,CASE @DeleteOriginals WHEN 1 THEN N'  
                ,MUID' END -- Use the original MUID when the original will be deleted  
                ,@NewAttributeColumnNames, N'  
  
            )  
            SELECT  
                 cm.Version_ID  
                ,cm.ID  
                ,cm.Status_ID  
                ,CONVERT(NVARCHAR(250), cm.ID) -- Code  
  
                ,cm.EnterDTM  
                ,cm.EnterUserID  
                ,cm.EnterVersionID  
                ,cm.LastChgDTM  
                ,cm.LastChgUserID  
                ,cm.LastChgVersionID  
                ,cm.AsOf_ID'   
                ,CASE @DeleteOriginals WHEN 1 THEN N'  
                ,cm.MUID' END -- Use the original MUID when the original will be deleted  
                ,@OldAttributeColumnNames, N'  
  
  
            FROM mdm.', QUOTENAME(@EntityTableName_CM), N' cm  
            ', @JoinSQL, N'  
  
            SET IDENTITY_INSERT mdm.', QUOTENAME(@NewEntityTableName_CM), N' OFF;   
  
            --SELECT * FROM mdm.', QUOTENAME(@NewEntityTableName_CM), N'  
            ');  
            --PRINT @SQL  
            EXEC sp_executesql @SQL;  
  
            IF @TransactionLogType = @TransactionLogType_Member  
            BEGIN  
PRINT CONCAT(SYSDATETIME(), N': Copying collection membership history from ', @EntityTableName_CM_HS, N' to ', @NewEntityTableName_CM_HS);  
  
                SET @SQL = CONCAT(@TruncationGuard, N'  
                INSERT INTO mdm.', QUOTENAME(@NewEntityTableName_CM_HS), N'  
                (  
                     Version_ID  
                    ,ID  
                    ,EN_ID  
                    ,Status_ID  
                    ,Code  
                    ,EnterDTM  
                    ,EnterUserID  
                    ,LastChgDTM  
                    ,LastChgUserID  
                    ,MUID  
                    ',@NewAttributeColumnNames, N'  
                )  
                SELECT  
                     cm.Version_ID  
                    ,cm.ID  
                    ,cm.CM_ID  
                    ,cm.Status_ID  
                    ,CONVERT(NVARCHAR(250), cm.CM_ID) -- Code  
                    ,cm.EnterDTM  
                    ,cm.EnterUserID  
                    ,cm.LastChgDTM  
                    ,cm.LastChgUserID  
                    ,COALESCE(newEn.MUID, cm.MUID) -- actual member MUID. Same when deleting originals, different when copying.  
                    ', @OldAttributeColumnNames, N'  
                FROM mdm.', QUOTENAME(@EntityTableName_CM_HS), N' cm  
                ', @JoinSQL, N'  
                LEFT JOIN mdm.', QUOTENAME(@NewEntityTableName_CM), N' newEn  
                ON      cm.Version_ID = newEn.Version_ID  
                    AND cm.CM_ID = newEn.ID  
                ')  
  
                --PRINT @SQL  
                EXEC sp_executesql @SQL;  
  
PRINT CONCAT(SYSDATETIME(), N': Copying collection membership annotations from table ', @EntityTableName_CM_AN, N' to ', @NewEntityTableName_CM_AN);  
                SET @SQL = CONCAT(N'  
                INSERT INTO mdm.', QUOTENAME(@NewEntityTableName_CM_AN), N'  
                (  
                     Version_ID  
                    ,Revision_ID  
                    ,Comment  
                    ,EnterDTM  
                    ,EnterUserID  
                    ,LastChgDTM  
                    ,LastChgUserID  
                )  
                -- collection current revision, need to map old to new revision (LastChgTS)  
                SELECT   
                     cmAn.Version_ID  
                    ,newEn.LastChgTS AS Revision_ID-- map to the current timestamp in the new leaf entity  
                    ,cmAn.Comment  
                    ,cmAn.EnterDTM  
                    ,cmAn.EnterUserID  
                    ,cmAn.LastChgDTM  
                    ,cmAn.LastChgUserID  
                FROM mdm.', QUOTENAME(@EntityTableName_CM_AN), N' cmAn  
                INNER JOIN mdm.', QUOTENAME(@EntityTableName_CM), N' cm  
                ON      cmAn.Version_ID = cm.Version_ID  
                    AND cmAn.Revision_ID = cm.LastChgTS  
                INNER JOIN mdm.', QUOTENAME(@NewEntityTableName_CM), N' newEn  
                ON      cm.Version_ID = newEn.Version_ID  
                    AND cm.ID = newEn.ID  
                LEFT JOIN mdm.', QUOTENAME(@EntityTableName_CM_HS), N' cmHs  
                ON      cmAn.Version_ID = cmHs.Version_ID  
                    AND cmAn.Revision_ID = cmHs.ID  
                WHERE cmHs.ID IS NULL -- do not include revisions that are already in the new EN_HS table. They will be covered by the below query  
  
                UNION ALL -- deduplication not needed  
  
                -- collection history  
                SELECT   
                     cmAn.Version_ID  
                    ,cmAn.Revision_ID  
                    ,cmAn.Comment  
                    ,cmAn.EnterDTM  
                    ,cmAn.EnterUserID  
                    ,cmAn.LastChgDTM  
                    ,cmAn.LastChgUserID  
                FROM mdm.', QUOTENAME(@EntityTableName_CM_AN), N' cmAn  
                INNER JOIN mdm.', QUOTENAME(@EntityTableName_CN_HS), N' cmHs  
                ON      cmAn.Version_ID = cmHs.Version_ID  
                    AND cmAn.Revision_ID = cmHs.ID  
                    ');  
                --PRINT @SQL  
                EXEC sp_executesql @SQL;  
  
            END -- copy collection membership history  
            ELSE IF @TransactionLogType = @TransactionLogType_Attribute  
            BEGIN  
  
                -- Copy transactions pertaining to the collections being copied. Note: collection membership changes do not produce transactions  
                SET @TransactionTableName = mdm.udfGetTransactionTableName(@Model_ID);  
  
                IF @DeleteOriginals = 1  
                BEGIN  
    PRINT CONCAT(SYSDATETIME(), N': Changing collection member transactions to reference the new Leaf entity.');  
                    SET @SQL = CONCAT(@TruncationGuard, N'  
                    --SELECT * FROM mdm.', QUOTENAME(@TransactionTableName), N' WHERE Entity_ID = @Entity_ID AND MemberType_ID = ', @MemberType_Collection, N'  
  
                    UPDATE tr  
                    SET  
                         Entity_ID = @NewEntity_ID_CN  
                        ,Attribute_ID = a.NewAttribute_ID  
                        ,MemberType_ID = ', @MemberType_Leaf, N'  
                    FROM mdm.', QUOTENAME(@TransactionTableName), N' tr  
  
                    -- Get new attribute ID for consolidated members  
                    LEFT JOIN #AttributeMapping a  
                    ON      tr.Attribute_ID = a.OldAttribute_ID  
                        -- AND a.NewEntity_ID = @NewEntity_ID_CN -- For collections, there is a one-to-one mapping from old-to-new attribute (unlike consolidated attributes, which can have one-to-many), so no need to also join on entity ID  
  
                    WHERE   tr.Entity_ID = @Entity_ID  
                        AND tr.MemberType_ID = ', @MemberType_Collection, N'  
  
                    --SELECT * FROM mdm.', QUOTENAME(@TransactionTableName), N' WHERE Entity_ID = @NewEntity_ID_CN  
                        ');  
                    -- Note: No need to copy or update the transaction annotations, since we merely modified existing transaction rows.  
                END ELSE  
                BEGIN  
                    -- We're not deleting originals, so copy (rather than update) transaction rows  
PRINT CONCAT(SYSDATETIME(), N': Copying collection transactions.');  
                    SET @TransactionAnnotationTableName = mdm.udfGetTransactionAnnotationTableName(@Model_ID);  
                    SET @SQL = CONCAT(@TruncationGuard, N'  
                    DECLARE @TransactionMappings TABLE  
                    (  
                         Old_ID INT PRIMARY KEY  
                        ,New_ID INT  
                    )  
  
                    MERGE mdm.', QUOTENAME(@TransactionTableName), N'  
                    USING  
                    (  
                        SELECT  
                             tr.ID  
                            ,tr.Version_ID  
                            ,tr.TransactionType_ID   
                            ,tr.OriginalTransaction_ID -- This references the old ID and will need to be updated after the MERGE  
                            ,tr.Hierarchy_ID -- should always be null for collection transactions  
                            ,@NewEntity_ID_CN AS Entity_ID -- Use the new entity for collection member transactions ....  
                            ,a.NewAttribute_ID AS Attribute_ID -- Changing the value of a collection attribute.  
                            ,tr.Member_ID            -- The old member ID will always be the same ...  
                            ,newEn.MUID Member_MUID  -- ... but the member MUID may be different for collection member transactions  
                            ,', @MemberType_Leaf, N' AS MemberType_ID  
                            ,tr.MemberCode  
  
                            ,tr.OldValue  
                            ,tr.OldCode  
                            ,tr.NewValue  
                            ,tr.NewCode  
  
                            ,tr.Batch_ID  
                            ,tr.EnterDTM  
                            ,tr.EnterUserID  
                            ,tr.LastChgDTM  
                            ,tr.LastChgUserID  
                        FROM mdm.', QUOTENAME(@TransactionTableName), ' tr  
  
                        -- Get new member MUID for copied collection members (note that this is a left join because some of the transactions that need to be copied may be for Leaf members being moved in the EH)  
                        LEFT JOIN mdm.', QUOTENAME(@NewEntityTableName_CN), N' newEn  
                        ON      tr.Version_ID = newEn.Version_ID  
                            AND tr.Member_ID = newEn.ID  
  
                        -- Get new attribute ID for consolidated members  
                        LEFT JOIN #AttributeMapping a  
                        ON      tr.Attribute_ID = a.OldAttribute_ID  
                            -- AND a.NewEntity_ID = @NewEntity_ID_CN -- For collections, there is a one-to-one mapping from old-to-new attribute (unlike consolidated attributes, which can have one-to-many), so no need to also join on entity ID  
  
                        WHERE   tr.Entity_ID = @Entity_ID  
                            AND tr.MemberType_ID = ', @MemberType_Collection, N'  
  
                    ) t  
                    ON (1 = 0) -- An arbitrary condition that is always false, so that the NOT MATCHED block will always be hit.  
                    WHEN NOT MATCHED THEN  
                    INSERT  
                    (  
                         Version_ID  
                        ,TransactionType_ID  
                        ,OriginalTransaction_ID  
                        ,Hierarchy_ID  
                        ,Entity_ID  
                        ,Attribute_ID  
                        ,Member_ID  
                        ,Member_MUID  
                        ,MemberType_ID  
                        ,MemberCode  
                        ,OldValue  
                        ,OldCode  
                        ,NewValue  
                        ,NewCode  
                        ,Batch_ID  
                        ,EnterDTM  
                        ,EnterUserID  
                        ,LastChgDTM  
                        ,LastChgUserID  
                    )  
                    VALUES  
                    (  
                         Version_ID  
                        ,TransactionType_ID  
                        ,OriginalTransaction_ID  
                        ,Hierarchy_ID  
                        ,Entity_ID  
                        ,Attribute_ID  
                        ,Member_ID  
                        ,Member_MUID  
                        ,MemberType_ID  
                        ,MemberCode  
                        ,OldValue  
                        ,OldCode  
                        ,NewValue  
                        ,NewCode  
                        ,Batch_ID  
                        ,EnterDTM  
                        ,EnterUserID  
                        ,LastChgDTM  
                        ,LastChgUserID  
                    )  
                    OUTPUT t.ID, inserted.ID  
                    INTO @TransactionMappings(Old_ID, New_ID);  
  
                    -- Update original transaction ID columns  
                    UPDATE tr  
                    SET OriginalTransaction_ID = newParent.New_ID  
                    FROM mdm.', QUOTENAME(@TransactionTableName), N' tr  
                    INNER JOIN @TransactionMappings newRow  
                    ON tr.ID = newRow.New_ID  
                    INNER JOIN @TransactionMappings newParent  
                    ON tr.OriginalTransaction_ID = newParent.Old_ID;  
  
  
                    -- Copy transaction annotations  
    PRINT CONCAT(SYSDATETIME(), N'': Copying collection transaction annotations.'');  
                    INSERT INTO mdm.', QUOTENAME(@TransactionAnnotationTableName), N'  
                    (  
                         Version_ID  
                        ,Transaction_ID  
                        ,Comment  
                        ,EnterUserID  
                        ,EnterDTM  
                        ,LastChgDTM  
                        ,LastChgUserID  
                    )  
                    SELECT  
                         ta.Version_ID  
                        ,newRow.New_ID  
                        ,ta.Comment  
                        ,ta.EnterUserID  
                        ,ta.EnterDTM  
                        ,ta.LastChgDTM  
                        ,ta.LastChgUserID  
                    FROM mdm.', QUOTENAME(@TransactionAnnotationTableName), N' ta  
                    INNER JOIN @TransactionMappings newRow  
                    ON ta.Transaction_ID = newRow.Old_ID  
  
                    --SELECT * FROM mdm.', QUOTENAME(@TransactionTableName), N' WHERE Entity_ID = @Entity_ID AND MemberType_ID = ', @MemberType_Collection, N'  
                    --SELECT * FROM mdm.', QUOTENAME(@TransactionAnnotationTableName), N' ta INNER JOIN mdm.', QUOTENAME(@TransactionTableName), N' tr ON ta.Transaction_ID = tr.ID WHERE tr.Entity_ID = @Entity_ID AND tr.MemberType_ID = ', @MemberType_Collection, N'  
                    --SELECT * FROM mdm.', QUOTENAME(@TransactionTableName), N' WHERE Entity_ID = @NewEntity_ID_CN    
                    --SELECT * FROM mdm.', QUOTENAME(@TransactionAnnotationTableName), N' ta INNER JOIN mdm.', QUOTENAME(@TransactionTableName), N' tr ON ta.Transaction_ID = tr.ID WHERE tr.Entity_ID = @NewEntity_ID_CN   
                    ');  
                END -- IF not @DeleteOriginals, copy transactions  
  
                --PRINT @SQL  
                EXEC sp_executesql @SQL  
                    ,N'@Entity_ID INT, @NewEntity_ID_CN INT'  
                      ,@Entity_ID,     @NewEntity_ID_CN;  
                END -- Copy Attribute (deprecated) transactions  
            ELSE   
PRINT N''  
PRINT CONCAT(SYSDATETIME(), N': Adding Many-To-Many hierarchies for collection membership info');  
            -- Create new Derived Hierarchy (one per child DBA) with a Many-To-Many level.  
            DECLARE   
                 @prefix                        NVARCHAR(50) = N'Collection_'  
                ,@MappingEntityName             NVARCHAR(50) = @NewEntityName  
                ,@ManyToManyChildDomainEntity_ID    INT  
                ,@ManyToManyChildDomainEntityName   NVARCHAR(50)  
                ,@ManyToManyChildAttribute_ID   INT  
                ,@ManyToManyChildAttributeName  NVARCHAR(100)  
  
            SET @RowID = 0  
            WHILE EXISTS (SELECT 1 FROM @CollectionMembershipAttributes WHERE RowID > @RowID)  
            BEGIN   
                SELECT TOP 1  
                     @RowID = RowID  
                    ,@ManyToManyChildAttributeName = Name  
                    ,@ManyToManyChildAttribute_ID = NewAttribute_ID  
  
                    ,@ManyToManyChildDomainEntity_ID = DomainEntity_ID  
                    ,@ManyToManyChildDomainEntityName = DomainEntityName  
                FROM @CollectionMembershipAttributes  
                WHERE RowID > @RowID  
                ORDER BY RowID  
  
                IF @ManyToManyChildAttributeName NOT LIKE @ChildAttributeNamePrefix + N'%'  
                BEGIN  
                    CONTINUE;  
                END  
  
                SET @counter = 0;  
                WHILE (1=1) -- TSQL doesn't support a DO-WHILE loop, so use a tautology as this WHILE condition to simulate a post-test loop.  
                BEGIN  
                    SET @NewDerivedHierarchyName = CONCAT(@prefix,   
                            SUBSTRING(@ManyToManyChildAttributeName, LEN(@ChildAttributeNamePrefix) + 1, @MaxMetadataObjectNameLength - LEN(@prefix) - 4),   
                            CASE WHEN @counter > 0 THEN @counter END);  
  
                    -- If the new DH name is unique within the model, then exit the loop.  
                    IF NOT EXISTS (SELECT 1 FROM mdm.tblDerivedHierarchy WHERE Model_ID = @Model_ID AND Name = @NewDerivedHierarchyName)  
                    BEGIN  
                        BREAK;  
                    END;  
  
                    -- The name wasn't unique, so increment the counter for the next loop iteration.  
                    SET @counter += 1;  
                END; -- WHILE (get unique DH name)  
  
PRINT CONCAT(SYSDATETIME(), N': Creating a new derived hierarchy "', @NewDerivedHierarchyName, N'"');  
                SET @NewDerivedHierarchy_ID = 0;  
                EXEC mdm.udpDerivedHierarchySave   
                     @User_ID = @User_ID  
                    ,@Model_ID = @Model_ID  
                    ,@Name = @NewDerivedHierarchyName  
                    ,@AnchorNullRecursions = 1  
                    ,@Return_ID = @NewDerivedHierarchy_ID OUTPUT  
  
                -- Add the leaf member level.  
PRINT CONCAT(SYSDATETIME(), N': Adding leaf level "', @ManyToManyChildDomainEntityName, '" to hierarchy "', @NewDerivedHierarchyName, N'"');  
                EXEC mdm.udpDerivedHierarchyDetailSave  
                  @User_ID = @User_ID  
                 ,@Model_ID = @Model_ID  
                 ,@DerivedHierarchy_ID = @NewDerivedHierarchy_ID  
                 ,@Foreign_ID = @ManyToManyChildDomainEntity_ID  
                 ,@ForeignType_ID = @HierarchyItemType_Entity  
                 ,@Name = @ManyToManyChildDomainEntityName  
                 ,@DisplayName = @ManyToManyChildDomainEntityName  
                 ,@IsVisible = 1  
                 ,@Return_ID = @NewLevel_ID OUTPUT  
  
            -- Add the Many-To-Many level.  
                SET @NewLevelName = SUBSTRING(CONCAT(@ManyToManyParentAttributeName, N' (via ', @MappingEntityName, N'.', @ManyToManyChildAttributeName, N')'), 0, @MaxHierarchyLevelNameLength);  
PRINT CONCAT(SYSDATETIME(), N': Adding Many-To-Many level "', @NewLevelName, '" to hierarchy "', @NewDerivedHierarchyName, N'"');  
                EXEC mdm.udpDerivedHierarchyDetailSave  
                  @User_ID = @User_ID  
                 ,@Model_ID = @Model_ID  
                 ,@DerivedHierarchy_ID = @NewDerivedHierarchy_ID  
                 ,@Foreign_ID = @ManyToManyParentAttribute_ID  
                 ,@ForeignType_ID = @HierarchyItemType_ManyToMany  
                 ,@Name = @NewLevelName  
                 ,@DisplayName = @NewLevelName  
                 ,@ManyToManyChildAttribute_ID = @ManyToManyChildAttribute_ID  
                 ,@IsVisible = 1  
                 ,@Return_ID = @NewLevel_ID OUTPUT  
  
            END  
  
  
        END -- WHILE (copy collections)  
  
  
  
PRINT N''  
PRINT CONCAT(SYSDATETIME(), N': Recreate leaf staging sprocs.');  
    DECLARE @EntitiesToRefresh TABLE  
    (  
         ID     INT PRIMARY KEY  
        ,Name   NVARCHAR(50) NOT NULL  
    );  
    ;WITH entityIdCte AS  
    (  
        SELECT Entity_ID AS ID FROM #EH_ConversionLog -- old entity had new DBA added to reference the new "consolidated" parent  
        UNION  
        SELECT NewEntity_ID FROM #EH_ConversionLog   
        UNION   
        SELECT New_CN_Entity_ID FROM @EntityInfo WHERE New_CN_Entity_ID IS NOT NULL  
        UNION   
        SELECT New_CM_Entity_ID FROM @EntityInfo WHERE New_CM_Entity_ID IS NOT NULL  
    )  
    INSERT INTO @EntitiesToRefresh(ID, Name)  
    SELECT   
         e.ID  
        ,e.Name  
    FROM entityIdCte id  
    INNER JOIN mdm.tblEntity e  
    ON id.ID = e.ID  
          
    SET @Entity_ID = 0  
    WHILE EXISTS (SELECT 1 FROM @EntitiesToRefresh WHERE ID > @Entity_ID)  
    BEGIN  
        SELECT TOP 1  
             @Entity_ID = ID  
            ,@EntityName = Name  
        FROM @EntitiesToRefresh  
        WHERE ID > @Entity_ID  
        ORDER BY ID  
  
PRINT CONCAT(SYSDATETIME(), N': Recreating leaf staging sproc for entity ', @EntityName, N' (ID = ', @Entity_ID, N')');  
        EXEC mdm.udpEntityStagingCreateLeafStoredProcedure @Entity_ID  
  
    END  
  
PRINT CONCAT(SYSDATETIME(), N': Copying all attribute groups from old entities to new entities.');  
  
        MERGE mdm.tblAttributeGroup  
        USING  
        (  
            -- Consolidated AGs  
            SELECT  
                 ag.ID  
                ,ag.Name  
                ,ag.SortOrder  
                ,ag.FreezeNameCode  
                ,ag.IsSystem  
                ,ag.EnterDTM  
                ,ag.EnterUserID  
                ,ag.EnterVersionID  
                ,ag.LastChgDTM  
                ,ag.LastChgUserID  
                ,ag.LastChgVersionID  
                ,eh.NewEntity_ID  
                ,ag.Entity_ID OldEntitiy_ID  
            FROM mdm.tblAttributeGroup ag  
            INNER JOIN #EH_ConversionLog eh  
            ON ag.Entity_ID = eh.Entity_ID  
            WHERE ag.MemberType_ID = @MemberType_Consolidated  
            UNION  
            -- Collection AGs  
            SELECT  
                 ag.ID  
                ,ag.Name  
                ,ag.SortOrder  
                ,ag.FreezeNameCode  
                ,ag.IsSystem  
                ,ag.EnterDTM  
                ,ag.EnterUserID  
                ,ag.EnterVersionID  
                ,ag.LastChgDTM  
                ,ag.LastChgUserID  
                ,ag.LastChgVersionID  
                ,e.New_CN_Entity_ID AS NewEntity_ID  
                ,ag.Entity_ID OldEntitiy_ID  
            FROM mdm.tblAttributeGroup ag  
            INNER JOIN @EntityInfo e  
            ON ag.Entity_ID = e.  Entity_ID  
            WHERE ag.MemberType_ID = @MemberType_Collection  
        ) ag  
        ON (1 = 0) -- An arbitrary condition that is always false, so that the NOT MATCHED block will always be hit.    
        WHEN NOT MATCHED THEN    
        INSERT    
        (    
             Entity_ID  
            ,MemberType_ID  
            ,Name  
            ,SortOrder  
            ,FreezeNameCode  
            ,IsSystem  
            ,EnterDTM  
            ,EnterUserID  
            ,EnterVersionID  
            ,LastChgDTM  
            ,LastChgUserID  
            ,LastChgVersionID  
        )  
        VALUES  
        (  
             ag.NewEntity_ID  
            ,@MemberType_Leaf  
            ,ag.Name  
            ,ag.SortOrder  
            ,ag.FreezeNameCode  
            ,ag.IsSystem  
            ,ag.EnterDTM  
            ,ag.EnterUserID  
            ,ag.EnterVersionID  
            ,ag.LastChgDTM  
            ,ag.LastChgUserID  
            ,ag.LastChgVersionID  
        )  
        OUTPUT   
             ag.ID  
            ,ag.OldEntitiy_ID  
            ,inserted.ID  
            ,inserted.Entity_ID  
        INTO #AttributeGroupMapping  
        (  
             OldAttributeGroup_ID  
            ,Entity_ID  
            ,NewAttributeGroup_ID  
            ,NewEntity_ID  
        );  
  
  
PRINT CONCAT(SYSDATETIME(), N': Copying all AttributeGroup details.');  
        INSERT INTO mdm.tblAttributeGroupDetail  
        (  
             AttributeGroup_ID  
            ,Attribute_ID  
            ,SortOrder  
            ,EnterDTM  
            ,EnterUserID  
            ,EnterVersionID  
            ,LastChgDTM  
            ,LastChgUserID  
            ,LastChgVersionID  
        )  
        SELECT  
             agm.NewAttributeGroup_ID  
            ,am.NewAttribute_ID  
            ,agd.SortOrder  
            ,agd.EnterDTM  
            ,agd.EnterUserID  
            ,agd.EnterVersionID  
            ,agd.LastChgDTM  
            ,agd.LastChgUserID  
            ,agd.LastChgVersionID  
        FROM mdm.tblAttributeGroupDetail agd  
        INNER JOIN #AttributeGroupMapping agm  
        ON agd.AttributeGroup_ID = agm.OldAttributeGroup_ID  
        INNER JOIN #AttributeMapping am  
        ON agd.Attribute_ID = am.OldAttribute_ID  
  
  
PRINT CONCAT(N'  
', SYSDATETIME(), N': Copying subscription views.');  
        DECLARE @SubscriptionViews TABLE  
        (  
             RowID                      INT IDENTITY(1,1) PRIMARY KEY  
            ,ID                         INT NOT NULL  
            ,Entity_ID                  INT NULL  
            ,NewEntity_ID               INT NULL  
            ,Model_ID                   INT NOT NULL  
            ,DerivedHierarchy_ID        INT NULL  
            ,ViewFormat_ID              INT NOT NULL  
            ,OldViewFormat_ID           INT NOT NULL  
            ,ModelVersion_ID            INT NULL  
            ,ModelVersionFlag_ID        INT NULL  
            ,Name                       SYSNAME COLLATE DATABASE_DEFAULT NOT NULL  
            ,NewNamePrefix              SYSNAME COLLATE DATABASE_DEFAULT NOT NULL  
            ,Levels                     SMALLINT NULL  
            ,Description                NVARCHAR(500) COLLATE DATABASE_DEFAULT NULL   
            ,IncludeSoftDeletedMembers  BIT NOT NULL  
            ,EnterDTM                   DATETIME2(3) NOT NULL  
            ,EnterUserID                INT NULL  
            ,EnterVersionID             INT NOT NULL  
            ,LastChgDTM                 DATETIME2(3) NOT NULL  
            ,LastChgUserID              INT NULL  
            ,LastChgVersionID           INT NOT NULL  
        );  
        INSERT INTO @SubscriptionViews  
        (  
             ID  
            ,Entity_ID  
            ,NewEntity_ID  
            ,Model_ID  
            ,DerivedHierarchy_ID  
            ,ViewFormat_ID  
            ,OldViewFormat_ID  
            ,ModelVersion_ID  
            ,ModelVersionFlag_ID  
            ,Name  
            ,NewNamePrefix  
            ,Levels  
            ,Description  
            ,IncludeSoftDeletedMembers  
            ,EnterDTM  
            ,EnterUserID  
            ,EnterVersionID  
            ,LastChgDTM  
            ,LastChgUserID  
            ,LastChgVersionID  
        )  
        -- Consolidated views  
        SELECT   
             sv.ID  
            ,sv.Entity_ID  
            ,CASE sv.ViewFormat_ID  
                WHEN @ViewFormat_Consolidated           THEN eh.NewEntity_ID  
                WHEN @ViewFormat_ExplicitParentChild    THEN NULL  
                WHEN @ViewFormat_ExplicitLevels         THEN NULL  
                WHEN @ViewFormat_ConsolidatedHistory    THEN eh.NewEntity_ID  
                WHEN @ViewFormat_ConsolidatedType2      THEN eh.NewEntity_ID  
                END AS NewEntity_ID  
            ,sv.Model_ID  
            ,CASE sv.ViewFormat_ID  
                WHEN @ViewFormat_Consolidated           THEN NULL  
                WHEN @ViewFormat_ExplicitParentChild    THEN eh.NewDerivedHierarchy_ID  
                WHEN @ViewFormat_ExplicitLevels         THEN eh.NewDerivedHierarchy_ID  
                WHEN @ViewFormat_ConsolidatedHistory    THEN NULL  
                WHEN @ViewFormat_ConsolidatedType2      THEN NULL  
                END AS DerivedHierarchy_ID  
            ,CASE sv.ViewFormat_ID  
                WHEN @ViewFormat_Consolidated           THEN @ViewFormat_Leaf  
                WHEN @ViewFormat_ExplicitParentChild    THEN @ViewFormat_DerivedParentChild  
                WHEN @ViewFormat_ExplicitLevels         THEN @ViewFormat_DerivedLevels  
                WHEN @ViewFormat_ConsolidatedHistory    THEN @ViewFormat_LeafHistory  
                WHEN @ViewFormat_ConsolidatedType2      THEN @ViewFormat_LeafType2  
                END AS ViewFormat_ID  
            ,sv.ViewFormat_ID AS OldViewFormat_ID  
            ,sv.ModelVersion_ID  
            ,sv.ModelVersionFlag_ID  
            ,sv.Name  
            ,CONCAT(sv.Name, N'_', eh.ExplicitHierarchyName) AS NewNamePrefix  
            ,COALESCE(CONVERT(SMALLINT, sv.Levels), levels.LevelCount)  
            ,sv.Description  
            ,sv.IncludeSoftDeletedMembers  
            ,sv.EnterDTM  
            ,sv.EnterUserID  
            ,sv.EnterVersionID  
            ,sv.LastChgDTM  
            ,sv.LastChgUserID  
            ,sv.LastChgVersionID  
        FROM mdm.tblSubscriptionView sv  
        INNER JOIN #EH_ConversionLog eh  
        ON sv.Entity_ID = eh.Entity_ID  
        -- Get the total number of levels in the new RDH, needed for ExplicitLevels views that use NULL for level count (which means show all levels)  
        LEFT JOIN  
        (  
            SELECT   
                 DerivedHierarchy_ID  
                ,CONVERT(SMALLINT, COUNT(*)) LevelCount  
            FROM mdm.tblDerivedHierarchyDetail  
            GROUP BY DerivedHierarchy_ID  
        ) levels  
        ON      sv.ViewFormat_ID = @ViewFormat_ExplicitLevels  
            AND eh.NewDerivedHierarchy_ID = levels.DerivedHierarchy_ID  
        WHERE sv.ViewFormat_ID IN (@ViewFormat_Consolidated, @ViewFormat_ExplicitParentChild, @ViewFormat_ExplicitLevels, @ViewFormat_ConsolidatedHistory, @ViewFormat_ConsolidatedType2)  
        UNION  
        -- Collection views  
        SELECT  
             sv.ID  
            ,sv.Entity_ID  
            ,CASE sv.ViewFormat_ID  
                WHEN @ViewFormat_Collection             THEN ei.New_CN_Entity_ID  
                WHEN @ViewFormat_CollectionMembership   THEN ei.New_CM_Entity_ID  
                WHEN @ViewFormat_CollectionHistory      THEN ei.New_CN_Entity_ID  
                WHEN @ViewFormat_CollectionType2        THEN ei.New_CN_Entity_ID  
                END AS NewEntity_ID  
            ,sv.Model_ID  
            ,sv.DerivedHierarchy_ID -- should always be null  
            ,CASE sv.ViewFormat_ID  
                WHEN @ViewFormat_Collection             THEN @ViewFormat_Leaf  
                WHEN @ViewFormat_CollectionMembership   THEN @ViewFormat_Leaf  
                WHEN @ViewFormat_CollectionHistory      THEN @ViewFormat_LeafHistory  
                WHEN @ViewFormat_CollectionType2        THEN @ViewFormat_LeafType2  
                END AS ViewFormat_ID  
            ,sv.ViewFormat_ID AS OldViewFormat_ID  
            ,sv.ModelVersion_ID  
            ,sv.ModelVersionFlag_ID  
            ,sv.Name  
            ,sv.Name AS NewNamePrefix  
            ,CONVERT(SMALLINT, sv.Levels)  
            ,sv.Description  
            ,sv.IncludeSoftDeletedMembers  
            ,sv.EnterDTM  
            ,sv.EnterUserID  
            ,sv.EnterVersionID  
            ,sv.LastChgDTM  
            ,sv.LastChgUserID  
            ,sv.LastChgVersionID  
        FROM mdm.tblSubscriptionView sv  
        INNER JOIN @EntityInfo ei  
        ON sv.Entity_ID = ei.Entity_ID  
        WHERE sv.ViewFormat_ID IN (@ViewFormat_Collection, @ViewFormat_CollectionMembership, @ViewFormat_CollectionHistory, @ViewFormat_CollectionType2)  
  
        SET @RowID = 0;  
        DECLARE  
             @OldSubscriptionView_ID    INT = 0  
            ,@NewSubscriptionView_ID    INT  
            ,@OldSubscriptionView_Name  SYSNAME  
            ,@NewSubscriptionView_Name  SYSNAME  
            ,@NewNamePrefix             SYSNAME  
            ,@OldEntity_ID              INT = 0  
            ,@ViewFormat_ID             INT  
            ,@OldViewFormat_ID           INT  
            ,@ModelVersion_ID           INT  
            ,@ModelVersionFlag_ID       INT  
            ,@Levels                    SMALLINT  
            ,@IncludeSoftDeletedMembers BIT  
  
        WHILE EXISTS(SELECT 1 FROM @SubscriptionViews WHERE RowID > @RowID)  
        BEGIN  
            SELECT TOP 1  
                 @RowID = RowID  
                ,@OldSubscriptionView_ID = ID  
                ,@OldEntity_ID = Entity_ID  
                ,@Entity_ID = NewEntity_ID  
                ,@Model_ID = Model_ID  
                ,@DerivedHierarchy_ID = DerivedHierarchy_ID  
                ,@ViewFormat_ID = ViewFormat_ID  
                ,@OldViewFormat_ID = OldViewFormat_ID  
                ,@ModelVersion_ID = ModelVersion_ID  
                ,@ModelVersionFlag_ID = ModelVersionFlag_ID  
                ,@OldSubscriptionView_Name = Name  
                ,@NewNamePrefix = NewNamePrefix  
                ,@Levels = Levels  
                ,@Description = Description  
                ,@IncludeSoftDeletedMembers = IncludeSoftDeletedMembers  
                ,@EnterDTM = EnterDTM  
                ,@EnterUserID = EnterUserID  
                ,@EnterVersionID = EnterVersionID  
                ,@LastChgDTM = LastChgDTM  
                ,@LastChgUserID = LastChgUserID  
                ,@LastChgVersionID = LastChgVersionID  
            FROM @SubscriptionViews  
            WHERE RowID > @RowID  
            ORDER BY RowID;  
  
            IF @DeleteOriginals = 1   
            BEGIN  
                IF EXISTS (SELECT 1 FROM mdm.tblSubscriptionView WHERE ID = @OldSubscriptionView_ID) -- A single consolidated-related SV (consolidated, explicit parent child, or explicit levels) may map to multiple new SVs (one per EH). So check to make sure the old SV hasn't already been deleted in a previous loop iteration.  
                BEGIN  
PRINT CONCAT(SYSDATETIME(), N': Deleting subscription view ', @OldSubscriptionView_Name, N' (ID = ', @OldSubscriptionView_ID, N') from Entity ID = ', @OldEntity_ID, ', @OldViewFormat_ID = ', @OldViewFormat_ID);  
  
                    EXEC mdm.udpSubscriptionViewDeleteByID  @ID	= @OldSubscriptionView_ID, @DeleteView = 1  
                END ELSE  
                BEGIN  
PRINT CONCAT(SYSDATETIME(), N': Already deleted, subscription view ', @OldSubscriptionView_Name, N' (ID = ', @OldSubscriptionView_ID, N') from Entity ID = ', @OldEntity_ID, ', @OldViewFormat_ID = ', @OldViewFormat_ID);  
                END  
            END  
  
            -- Get new subscription view name  
            SET @counter = 0  
            WHILE (1=1) -- TSQL doesn't support a DO-WHILE loop, so use a tautology as this WHILE condition to simulate a post-test loop.  
            BEGIN  
                SET @NewSubscriptionView_Name = CASE @counter WHEN 0   
                    THEN @NewNamePrefix   
                    ELSE CONCAT(SUBSTRING(@NewNamePrefix, 0, 120), N'_', @counter) END;  
  
                -- If the new name is unique, then exit the loop.  
                IF NOT EXISTS (SELECT 1 FROM mdm.tblSubscriptionView WHERE Name = @NewSubscriptionView_Name)  
                BEGIN  
                    BREAK;  
                END;  
  
                -- The name wasn't unique, so increment the counter for the next loop iteration.  
                SET @counter += 1;  
            END; -- WHILE (get unique subscription view name)  
  
PRINT CONCAT(SYSDATETIME(), N': Creating new subscription view "', @NewSubscriptionView_Name, '" in   
     @Entity ID = ', @Entity_ID, N'  
    ,@Model_ID = ', @Model_ID, N'  
    ,@DerivedHierarchy_ID = ', @DerivedHierarchy_ID, N'  
    ,@ModelVersion_ID = ', @ModelVersion_ID, N'  
    ,@ModelVersionFlag_ID = ', @ModelVersionFlag_ID, N'  
    ,@ViewFormat_ID = ', @ViewFormat_ID, N'  
    ,@Levels = ', @Levels, N'  
    ,@IncludeSoftDeletedMembers = ', @IncludeSoftDeletedMembers, N'  
    ,@NewSubscriptionView_Name = ', @NewSubscriptionView_Name, N'  
    ,@Description = ', @Description, N'  
    ');  
            EXEC mdm.udpSubscriptionViewSave   
                 @User_ID               = @User_ID  
                ,@SubscriptionView_ID   = NULL  
                ,@Entity_ID             = @Entity_ID  
                ,@Model_ID              = @Model_ID  
                ,@DerivedHierarchy_ID   = @DerivedHierarchy_ID  
                ,@ModelVersion_ID       = @ModelVersion_ID  
                ,@ModelVersionFlag_ID   = @ModelVersionFlag_ID  
                ,@ViewFormat_ID         = @ViewFormat_ID  
                ,@Levels                = @Levels  
                ,@IncludeSoftDeletedMembers = @IncludeSoftDeletedMembers  
                ,@SubscriptionViewName  = @NewSubscriptionView_Name  
                ,@Description           = @Description  
                ,@Return_ID             = @NewSubscriptionView_ID OUTPUT  
                --,@Return_MUID			UNIQUEIDENTIFIER = NULL OUTPUT, --Also an input parameter for clone operations  
          
            -- Copy audit info  
            UPDATE mdm.tblSubscriptionView  
            SET  
                 EnterDTM = @EnterDTM  
                ,EnterUserID = @EnterUserID  
                ,EnterVersionID = @EnterVersionID  
                ,LastChgDTM = @LastChgDTM  
                ,LastChgUserID = @LastChgUserID  
                ,LastChgVersionID = @LastChgVersionID  
            WHERE ID = @NewSubscriptionView_ID  
  
PRINT CONCAT(SYSDATETIME(), N': New subscription view ID = ', @NewSubscriptionView_ID);  
        END  
  
  
        -- Copy model object security permissions  
PRINT CONCAT(N'  
', SYSDATETIME(), N': Copying model object security: Entity, MemberType, Attribute Group, and Attribute permissions.');  
        CREATE TABLE #ObjectPermissionMapping  
        (  
             OldRow_ID       INT  
            ,OldObject_ID    INT NOT NULL DEFAULT 0  
            ,NewRow_ID       INT  
        )  
        ;WITH cteNewEntities AS  
        (  
            -- Consolidated members  
            SELECT DISTINCT  
                 Entity_ID AS OldEntity_ID  
                ,NewEntity_ID  
                ,@ObjectType_ConsolidatedType AS Object_ID  
            FROM #EH_ConversionLog  
            UNION ALL  
            -- Collection members  
            SELECT  
                 Entity_ID AS OldEntity_ID  
                ,New_CN_Entity_ID AS NewEntity_ID  
                ,@ObjectType_CollectionType  
            FROM @EntityInfo  
            WHERE New_CN_Entity_ID IS NOT NULL  
            UNION ALL  
            -- Collection membership info  
            SELECT  
                 Entity_ID AS OldEntity_ID  
                ,New_CM_Entity_ID AS NewEntity_ID  
                ,@ObjectType_CollectionType  
            FROM @EntityInfo  
            WHERE New_CM_Entity_ID IS NOT NULL  
        )  
        ,cteMappedPermissions AS  
        (  
            SELECT  
                 ra.ID  
                ,ne.NewEntity_ID AS NewSecurable_ID-- The Securable_ID will be the new Entity ID for both entity and member type permissions  
                ,CASE ra.Object_ID  
                    WHEN @ObjectType_ConsolidatedType THEN @ObjectType_LeafType -- Copy Consolidated permissions on the old entity to a leaf permission on the new entity  
                    WHEN @ObjectType_CollectionType THEN @ObjectType_LeafType -- Copy Collection permissions on the old entity to a leaf permission on the new entity  
                    ELSE ra.Object_ID END AS NewObject_ID  
            FROM mdm.tblSecurityRoleAccess ra  
            INNER JOIN cteNewEntities ne  
            ON      ra.Securable_ID = ne.OldEntity_ID  
                AND (ra.Object_ID = @ObjectType_Entity OR ra.Object_ID = ne.Object_ID)  
  
           -- Attribute permissions  
           UNION ALL  
           SELECT  
                 ra.ID  
                ,am.NewAttribute_ID AS NewSecurable_ID  
                ,ra.Object_ID AS NewObject_ID  
            FROM mdm.tblSecurityRoleAccess ra  
            INNER JOIN #AttributeMapping am  
            ON      ra.Securable_ID = am.OldAttribute_ID  
                AND ra.Object_ID = @ObjectType_Attribute  
  
            -- Attribute group permissions  
            UNION ALL  
            SELECT  
                 ra.ID  
                ,agm.NewAttributeGroup_ID AS NewSecurable_ID  
                ,ra.Object_ID AS NewObject_ID  
            FROM mdm.tblSecurityRoleAccess ra  
            INNER JOIN #AttributeGroupMapping agm  
            ON      ra.Securable_ID = agm.OldAttributeGroup_ID  
                AND ra.Object_ID = @ObjectType_AttributeGroup  
        )  
        MERGE mdm.tblSecurityRoleAccess  
        USING  
        (  
            SELECT  
                 ra.ID AS OldRow_ID  
                ,ra.Role_ID  
                ,ra.Privilege_ID  
                ,ra.AccessPermission  
                ,ra.Model_ID  
                ,new.NewSecurable_ID  
                ,new.NewObject_ID  
                ,ra.Object_ID AS OldObject_ID  
                ,ra.Description  
                ,ra.EnterDTM  
                ,ra.EnterUserID  
                ,ra.LastChgDTM  
                ,ra.LastChgUserID  
            FROM mdm.tblSecurityRoleAccess ra  
            INNER JOIN cteMappedPermissions new  
            ON  ra.ID = new.ID  
        ) p  
        ON (1 = 0) -- An arbitrary condition that is always false, so that the NOT MATCHED block will always be hit.  
        WHEN NOT MATCHED THEN  
        INSERT  
        (  
             Role_ID  
            ,Privilege_ID  
            ,AccessPermission  
            ,Model_ID  
            ,Securable_ID  
            ,Object_ID  
            ,Description  
            ,EnterDTM  
            ,EnterUserID  
            ,LastChgDTM  
            ,LastChgUserID  
        )  
        VALUES  
        (  
             Role_ID  
            ,Privilege_ID  
            ,AccessPermission  
            ,Model_ID  
            ,NewSecurable_ID  
            ,NewObject_ID  
            ,Description  
            ,EnterDTM  
            ,EnterUserID  
            ,LastChgDTM  
            ,LastChgUserID  
        )  
        OUTPUT p.OldRow_ID, p.OldObject_ID, inserted.ID  
        INTO #ObjectPermissionMapping(OldRow_ID, OldObject_ID, NewRow_ID);  
  
        -- Copy member security permissions from the old EHs to the new RDHs.  
PRINT CONCAT(SYSDATETIME(), N': Copying member security.');  
        INSERT INTO mdm.tblSecurityRoleAccessMember  
        (  
             Role_ID  
            ,Privilege_ID  
            ,AccessPermission  
            ,Version_ID  
            ,DerivedHierarchy_ID  
            ,HierarchyType_ID  
            ,Entity_ID  
            ,MemberType_ID  
            ,Member_ID  
            ,Description  
            ,EnterDTM  
            ,EnterUserID  
            ,LastChgDTM  
            ,LastChgUserID  
        )  
        SELECT   
             ram.Role_ID  
            ,ram.Privilege_ID  
            ,AccessPermission  
            ,ram.Version_ID  
            ,cl.NewDerivedHierarchy_ID  
            ,@HierarchyType_Derived  
            ,CASE ram.MemberType_ID WHEN @MemberType_Leaf THEN cl.Entity_ID ELSE cl.NewEntity_ID END -- If the permission applied to one of the consolidated members in the EH, then use the new entity id. Otherwise, use the old (leaf) entity.  
            ,CASE ram.Member_ID WHEN 0/*ROOT*/ THEN ram.MemberType_ID ELSE @MemberType_Leaf END -- All new permissions are for Leaf members (no consolidated members in new RDH), except for the ROOT node  
            ,ram.Member_ID  
            ,ram.Description  
            ,ram.EnterDTM  
            ,ram.EnterUserID  
            ,ram.LastChgDTM  
            ,ram.LastChgUserID  
        FROM mdm.tblSecurityRoleAccessMember ram  
        INNER JOIN #EH_ConversionLog cl  
        ON ram.ExplicitHierarchy_ID = cl.ExplicitHierarchy_ID;  
  
  
        -- Optionally delete the EH and consolidated members that were copied.  
        IF (@DeleteOriginals = 1)  
        BEGIN  
  
PRINT CONCAT(SYSDATETIME(), N': Deleting object permissions');  
            DELETE sra  
            FROM mdm.tblSecurityRoleAccess sra  
            INNER JOIN #ObjectPermissionMapping opm  
            ON sra.ID = opm.OldRow_ID  
            WHERE opm.OldObject_ID <> @ObjectType_Entity -- Leave the original entity permission(s)  
  
PRINT CONCAT(SYSDATETIME(), N': Deleting attribute groups');  
            DELETE ag  
            FROM mdm.tblAttributeGroup ag  
            INNER JOIN #AttributeGroupMapping agm  
            ON ag.ID = agm.OldAttributeGroup_ID;  
  
            -- Delete collections  
            DECLARE @EntityIds mdm.IdList;  
            INSERT INTO @EntityIds  
            SELECT Entity_ID ID  
            FROM @EntityInfo  
            EXEC mdm.udpCollectionTablesDrop @EntityIds  
  
PRINT CONCAT(SYSDATETIME(), N': Deleting explicit hierarchies (includes consolidated members and attributes)');  
  
            -- Delete any DHs that use any of the converted EHs as a cap. These DHs must be deleted before deleting the EHs.  
            DELETE FROM @ExplicitCapHierarchies;  
            INSERT INTO @ExplicitCapHierarchies  
            SELECT DISTINCT   
                 dh.ID  
                ,dh.Name  
            FROM mdm.tblDerivedHierarchy dh  
            INNER JOIN mdm.tblDerivedHierarchyDetail dhd  
            ON dh.ID = dhd.DerivedHierarchy_ID  
            INNER JOIN @ExplicitHierarchies eh  
            ON      dhd.ForeignType_ID = @HierarchyItemType_ExplicitHierarchy  
                AND dhd.Foreign_ID = eh.ExplicitHierarchy_ID;  
  
            SET @DerivedHierarchy_ID = 0;  
            WHILE EXISTS (SELECT 1 FROM @ExplicitCapHierarchies)  
            BEGIN  
                -- Get the next DH in the list.  
                SELECT TOP 1  
                    @DerivedHierarchy_ID = DerivedHierarchy_ID  
                FROM @ExplicitCapHierarchies;  
                DELETE FROM @ExplicitCapHierarchies WHERE @DerivedHierarchy_ID = DerivedHierarchy_ID;  
  
                -- Delete the DH.  
PRINT CONCAT(SYSDATETIME(), N': Deleting explicit cap DH with ID = ', @DerivedHierarchy_ID);  
                EXEC mdm.udpDerivedHierarchyDelete @ID = @DerivedHierarchy_ID;  
            END; -- WHILE (loop through each explicit cap DHs and delete it)  
  
            -- Delete the converted EHs.  
            SET @ExplicitHierarchy_ID = 0;  
            WHILE EXISTS (SELECT 1 FROM @ExplicitHierarchies WHERE ExplicitHierarchy_ID > @ExplicitHierarchy_ID)  
            BEGIN  
                SELECT TOP 1  
                     @ExplicitHierarchy_ID = ExplicitHierarchy_ID  
                    ,@Entity_ID = Entity_ID  
                FROM @ExplicitHierarchies  
                WHERE ExplicitHierarchy_ID > @ExplicitHierarchy_ID  
                ORDER BY ExplicitHierarchy_ID;  
  
PRINT CONCAT(SYSDATETIME(), N': Deleting EH with ID = ', @ExplicitHierarchy_ID, ' in Entity ID = ', @Entity_ID);  
                EXEC mdm.udpEntityHierarchyDelete @User_ID = @User_ID, @Hierarchy_ID = @ExplicitHierarchy_ID;  
            END; -- WHILE (loop through each EH and delete it)  
        END; -- IF (delete originals)  
  
        --Commit only if we are not nested  
        IF @TranCounter = 0   
        BEGIN  
            COMMIT TRANSACTION;  
        END   
  
        -- Kickoff the service broker to process member security. This is done last to avoid bogging down the script.  
PRINT CONCAT(SYSDATETIME(), N': Process members security.');  
  
        -- Get the ids of all models with EHs that were converted.  
        DECLARE @Model_IDs TABLE  
        (  
            Model_ID INT PRIMARY KEY  
        );  
        INSERT INTO @Model_IDs  
        SELECT DISTINCT e.Model_ID  
        FROM @ExplicitHierarchies eh  
        INNER JOIN @EntityInfo e  
        ON eh.Entity_ID = e.Entity_ID  
  
        SET @Model_ID = 0;  
        DECLARE @ProcessNow BIT = 0;  
        WHILE EXISTS (SELECT 1 FROM @Model_IDs)  
        BEGIN  
            -- Get the next model from the list.  
            SELECT TOP 1  
                @Model_ID = Model_ID  
            FROM @Model_IDs   
            WHERE Model_ID > @Model_ID  
            ORDER BY Model_ID;  
  
            DELETE FROM @Model_IDs WHERE Model_ID = @Model_ID;  
  
PRINT CONCAT(SYSDATETIME(), N': Put message on service broker queue to process member security for model with ID = ', @Model_ID);  
            SET @ProcessNow = CASE WHEN NOT EXISTS (SELECT 1 FROM @Model_IDs) THEN 1 ELSE 0 END;-- Set the ProcessNow flag only when processing the last model.  
            -- Have the service broker queue kick off processing model security.  
            EXEC mdm.udpSecurityMemberProcessRebuildModel @Model_ID = @Model_ID, @ProcessNow = @ProcessNow;  
        END -- WHILE (loop through model ids, to process member security)  
  
PRINT CONCAT(SYSDATETIME(), N': Done');  
    END TRY  
    BEGIN CATCH  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        -- Roll back the transaction.  
        IF @TranCounter = 0   
            ROLLBACK TRANSACTION;  
        ELSE IF XACT_STATE() <> -1   
            ROLLBACK TRANSACTION TX;  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
  
    END CATCH  
  
    SET NOCOUNT OFF;  
END; --proc
go

