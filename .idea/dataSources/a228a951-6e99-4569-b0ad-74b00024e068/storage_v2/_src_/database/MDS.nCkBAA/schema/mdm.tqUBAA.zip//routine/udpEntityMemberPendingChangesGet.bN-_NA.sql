/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
DECLARE @MemberCount INT;  
  
EXEC mdm.udpEntityMemberPendingChangesGet @User_ID = 1, @Model_Name = N'Product', @Entity_Name = N'Product', @Version_Name = N'Version 1', @MemberCount = @MemberCount OUTPUT, @MemberReturnOption = 3;  
SELECT @MemberCount  
*/  
CREATE PROCEDURE mdm.udpEntityMemberPendingChangesGet  
(  
    @User_ID                INT,  
    @Model_MUID             UNIQUEIDENTIFIER = NULL,  
    @Model_Name             NVARCHAR(MAX) = NULL,  
    @Entity_MUID            UNIQUEIDENTIFIER = NULL,  
    @Entity_Name            NVARCHAR(MAX) = NULL,  
    @Version_MUID           UNIQUEIDENTIFIER = NULL,  
    @Version_Name           NVARCHAR(MAX) = NULL,  
    @Changeset_Name         NVARCHAR(250) = NULL,  
    @Changeset_MUID         UNIQUEIDENTIFIER = NULL,  
    @Hierarchy_MUID         UNIQUEIDENTIFIER = NULL,  
    @Hierarchy_Name         NVARCHAR(MAX) = NULL,  
    @HierarchyType_ID       TINYINT = NULL,  
    @HierarchyLevelNumber   INT = NULL, -- viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED_LEVELS.LevelNumber (starts with zero at the top level)  
    @ParentEntity_MUID      UNIQUEIDENTIFIER = NULL,  
    @ParentEntity_Name      NVARCHAR(MAX) = NULL,  
    @ParentCode             NVARCHAR(250) = NULL,  
    @AttributeTable         mdm.Identifier READONLY,  
    @AttributeGroup_MUID    UNIQUEIDENTIFIER = NULL,  
    @AttributeGroup_Name    NVARCHAR(MAX) = NULL,  
    @SearchTable            mdm.MemberGetCriteria READONLY,  
    @PageNumber             INT = NULL,  
    @PageSize               INT = NULL OUTPUT,  
    @SortColumn_MUID        UNIQUEIDENTIFIER = NULL,  
    @SortColumn_Name        NVARCHAR(128) = NULL,  
    @SortDirection          NVARCHAR(4) = NULL,  
    @IncludeUnchangedValue  BIT = 0,  
    @IncludeAuditInfo       BIT = 0,  
    @MemberReturnOption     TINYINT = 3, -- Data, counts  
    @MemberCount            INT = NULL OUTPUT,  
    @CorrelationID          UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
    DECLARE @GuidEmpty                                  UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER),  
            @Owner_ID                                   INT,  
            @CurrentState                               TINYINT,  
            @Model_ID                                   INT,  
            @Entity_ID                                  INT,  
            @Version_ID                                 INT,  
            @Changeset_ID                               INT,  
            @AttributeGroup_ID                          INT,  
            @Hierarchy_ID                               INT,  
            @HierarchyLevel_ID                          INT,  
            @ParentEntity_ID                            INT,  
            @ParentAttribute_ID                         INT,  
            @ParentAttribute_Name                       SYSNAME,  
            @Parent_ID                                  INT,  
  
            @Unused_ID                                  INT = -1,  
            @Root_ID                                    INT = 0,  
  
            @UseMemberSecurity                          BIT = 0,  
            @IsDefaultOrder                             BIT = 0,  
  
            @SecurityTableName                          SYSNAME,  
            @HierarchyTable                             SYSNAME,  
            @MemberViewName                             SYSNAME,  
            @ChangesetTableName                         SYSNAME,  
            @EnViewName                                 SYSNAME,  
  
            @HierarchyType_Explicit                     TINYINT = 0,  
            @HierarchyType_Derived                      TINYINT = 1,  
  
            @MemberReturnOptionData                     TINYINT = 1,  
            @MemberReturnOptionCount                    TINYINT = 2,  
  
            @ChangesetStatus_Open                       TINYINT = 1,  
            @ChangesetStatus_Pending                    TINYINT = 2,  
            @ChangesetStatus_Approved                   TINYINT = 3,  
            @ChangesetStatus_Rejected                   TINYINT = 4,  
            @ChangesetStatus_Committed                  TINYINT = 5,  
  
            @MemberType_Leaf                            TINYINT = 1,  
  
            @AttributeType_FreeForm                     TINYINT = 1,  
            @AttributeType_Domain                       TINYINT = 2,  
            @AttributeType_System                       TINYINT = 3,  
            @AttributeType_File                         TINYINT = 4,  
  
            @ForeignType_Entity                         TINYINT = 0,  
            @ForeignType_DBA                            TINYINT = 1,  
            @ForeignType_ManyToMany                     TINYINT = 5,  
  
            @MemberStatusActive                         TINYINT = 1,  
  
            @Model_Permission                           TINYINT,  
            @Entity_Permission                          TINYINT,  
            @MemberType_Permission                      TINYINT,  
            @Permission_Deny                            TINYINT = 1,  
            @Permission_Access                          TINYINT = 4,  
            @Permission_Admin                           TINYINT = 5,  
            @Permission_Inferred                        TINYINT = 99,  
  
            @MemberType_AccessPermission                TINYINT,  
            @AccessPermission_All                       TINYINT = 7,  
            @AccessPermission_Read                      TINYINT = 0,  
            @AccessPermission_Update                    TINYINT = 2,  
            @AccessPermission_Delete                    TINYINT = 4,  
            @AccessPermission_UpdateDelete              TINYINT = 6, -- 2+4  
  
            @VersionStatus                              TINYINT,  
            @VersionStatus_Locked                       TINYINT = 2,  
            @VersionStatus_Committed                    TINYINT = 3,  
  
            @AttributeDataType_Text                     TINYINT = 1,  
            @AttributeDataType_Number                   TINYINT = 2,  
            @AttributeDataType_DateTime                 TINYINT = 3,  
            @AttributeDataType_Link                     TINYINT = 6,  
  
            @SortColumn_TableName                       SYSNAME = NULL,  
            @ColumnString                               NVARCHAR(MAX) = NULL,  
            @SortTerm                                   NVARCHAR(MAX) = NULL,  
            @PagingTerm                                 NVARCHAR(MAX) = NULL,  
            @MembersCTE                                 NVARCHAR(MAX) = NULL,  
            @PagedIdsCTE                                NVARCHAR(MAX) = NULL,  
            @MemberFrom                                 NVARCHAR(MAX) = NULL,  
            @MemberWhere                                NVARCHAR(MAX) = NULL,  
            @SQL                                        NVARCHAR(MAX);  
  
    SELECT  
        @User_ID = NULLIF(@User_ID, 0),  
        @Model_MUID = NULLIF(@Model_MUID, @GuidEmpty),  
        @Model_Name = NULLIF(LTRIM(RTRIM(@Model_Name)), N''),  
        @Entity_MUID = NULLIF(@Entity_MUID, @GuidEmpty),  
        @Entity_Name = NULLIF(LTRIM(RTRIM(@Entity_Name)), N''),  
        @Version_MUID = NULLIF(@Version_MUID, @GuidEmpty),  
        @Version_Name = NULLIF(LTRIM(RTRIM(@Version_Name)), N''),  
        @Changeset_MUID = NULLIF(@Changeset_MUID, @GuidEmpty),  
        @Changeset_Name = NULLIF(LTRIM(RTRIM(@Changeset_Name)), N''),  
        @AttributeGroup_MUID = NULLIF(@AttributeGroup_MUID, @GuidEmpty),  
        @AttributeGroup_Name = NULLIF(LTRIM(RTRIM(@AttributeGroup_Name)), N''),  
        @Hierarchy_MUID = NULLIF(@Hierarchy_MUID, @GuidEmpty),  
        @Hierarchy_Name = NULLIF(LTRIM(RTRIM(@Hierarchy_Name)), N''),  
        @ParentEntity_MUID = NULLIF(@ParentEntity_MUID, @GuidEmpty),  
        @ParentEntity_Name = NULLIF(LTRIM(RTRIM(@ParentEntity_Name)), N''),  
        @ParentCode = NULLIF(LTRIM(RTRIM(@ParentCode)), N''),  
        @SortColumn_MUID = NULLIF(@SortColumn_MUID, @GuidEmpty),  
        @SortColumn_Name = NULLIF(LTRIM(RTRIM(@SortColumn_Name)), N''),  
        @SortDirection = NULLIF(LTRIM(RTRIM(@SortDirection)), N''),  
        @MemberCount = NULL;  
  
    -- Validate parameters  
    IF @User_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR100009|The User ID is not valid.', 16, 1);  
        RETURN;  
    END  
  
    EXEC mdm.udpInformationLookupModel  
        @User_ID = @User_ID,  
        @Model_MUID = @Model_MUID,  
        @Model_Name = @Model_Name,  
        @ID = @Model_ID OUTPUT,  
        @Privilege_ID = @Model_Permission OUTPUT;  
    IF @Model_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300005|The supplied model is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    SELECT @Version_ID = ID, @VersionStatus = Status_ID  
    FROM mdm.tblModelVersion   
    WHERE  
            (@Version_MUID IS NOT NULL OR @Version_Name IS NOT NULL)   
        AND (@Version_MUID IS NULL OR MUID = @Version_MUID)   
        AND (@Version_Name IS NULL OR Name = @Version_Name)  
        AND Model_ID = @Model_ID;  
    IF @Version_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300006|The supplied version is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    SET @ChangesetTableName = CONCAT(N'tbl_', @Model_ID, N'_CS');  
  
    EXEC mdm.udpInformationLookupEntity  
        @User_ID = @User_ID,  
        @Model_ID = @Model_ID,  
        @Entity_MUID = @Entity_MUID,  
        @Entity_Name = @Entity_Name,  
        @ID = @Entity_ID OUTPUT,  
        @Privilege_ID = @Entity_Permission OUTPUT;  
    IF @Entity_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300008|The supplied entity is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    SET @HierarchyTable = CONCAT(N'tbl_', @Model_ID, N'_', @Entity_ID ,N'_HR');  
    SET @SecurityTableName = CONCAT(N'tbl_', @Model_ID, N'_', @Entity_ID ,N'_EN_MS');  
  
    IF @ParentEntity_MUID IS NOT NULL OR @ParentEntity_Name IS NOT NULL  
    BEGIN  
        EXEC mdm.udpInformationLookupEntity  
            @User_ID = @User_ID,  
            @Model_ID = @Model_ID,  
            @Entity_MUID = @ParentEntity_MUID,  
            @Entity_Name = @ParentEntity_Name,  
            @ID = @ParentEntity_ID OUTPUT  
        IF @ParentEntity_ID IS NULL  
        BEGIN  
            RAISERROR(N'MDSERR300008|Entity is Invalid', 16, 1);  
            RETURN;  
        END;  
    END  
  
    IF @Hierarchy_MUID IS NOT NULL OR @Hierarchy_Name IS NOT NULL  
    BEGIN  
  
        IF @HierarchyType_ID = @HierarchyType_Explicit  
        BEGIN  
            EXEC mdm.udpInformationLookupHierarchy  
                @User_ID = @User_ID,  
                @Entity_ID = @Entity_ID,  
                @Hierarchy_MUID = @Hierarchy_MUID,  
                @Hierarchy_Name = @Hierarchy_Name,  
                @ID = @Hierarchy_ID OUTPUT  
            IF @Hierarchy_ID IS NULL  
            BEGIN  
                RAISERROR(N'MDSERR300009|Explicit Hierarchy is Invalid', 16, 1);  
                RETURN;  
            END;  
        END  
        ELSE IF @HierarchyType_ID = @HierarchyType_Derived  
        BEGIN  
            EXEC mdm.udpInformationLookupDerivedHierarchy  
                @User_ID = @User_ID,  
                @Model_ID = @Model_ID,  
                @DerivedHierarchy_ID = @Hierarchy_ID,  
                @DerivedHierarchy_MUID = @Hierarchy_MUID,  
                @DerivedHierarchy_Name = @Hierarchy_Name,  
                @ID = @Hierarchy_ID OUTPUT  
            IF @Hierarchy_ID IS NULL  
            BEGIN  
                RAISERROR(N'MDSERR300007|DerivedHierarchy is Invalid', 16, 1);  
                RETURN;  
            END;  
        END  
    END  
  
    -- Check paging, sorting and search term.  
    SET @PageNumber = COALESCE(@PageNumber, 0);  
    SET @PageSize = COALESCE(@PageSize, (SELECT SettingValue FROM mdm.tblSystemSetting WHERE SettingName = CAST(N'RowsPerBatch' AS NVARCHAR(100))))  
    IF @PageNumber > 0 AND @PageSize > 0  
    BEGIN  
        SET @PagingTerm = N'  
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS  
    FETCH NEXT @PageSize ROWS ONLY'  
    END  
  
    IF  @SortColumn_MUID IS NOT NULL OR @SortColumn_Name IS NOT NULL  
    BEGIN  
        EXEC mdm.udpInformationLookupAttribute  
            @User_ID = @User_ID,  
            @Entity_ID = @Entity_ID,  
            @Attribute_MUID = @SortColumn_MUID,  
            @Attribute_Name = @SortColumn_Name,  
            @Name = @SortColumn_TableName OUTPUT  
        IF @SortColumn_TableName IS NULL  
        BEGIN  
            IF  @SortColumn_MUID IS NOT NULL  
            BEGIN  
                RAISERROR(N'MDSERR300010|Attribute is Invalid', 16, 1);  
                RETURN;  
            END  
            ELSE  
            BEGIN  
                SET @SortColumn_TableName = @SortColumn_Name;  
            END  
        END;  
    END  
  
    EXEC [mdm].[udpResolveMemberGetCriteria] @SearchTable, @MemberWhere OUTPUT, @SortTerm OUTPUT;  
  
    IF @SortColumn_TableName IS NOT NULL  
    BEGIN  
        SET @SortTerm += CONCAT(QUOTENAME(@SortColumn_TableName), CASE WHEN UPPER(@SortDirection) = N'ASC' THEN N' ASC' ELSE N' DESC' END);  
    END  
    ELSE IF @IncludeUnchangedValue = 1  
    BEGIN  
        SET @SortTerm += N'CS_ID DESC'  
    END  
  
    IF(@SortTerm = N'')  
    BEGIN  
        SET @SortTerm = N'ID ASC';  
        SET @IsDefaultOrder = 1;  
    END  
  
    IF @Changeset_Name IS NOT NULL OR @Changeset_MUID IS NOT NULL  
    BEGIN  
        SET @SQL = CONCAT(N'  
                    SELECT @Changeset_ID = ID, @Owner_ID = EnterUserID , @CurrentState = Status  
                    FROM [mdm].', @ChangesetTableName, N'  
                    WHERE Version_ID = @Version_ID  
                        AND Entity_ID = @Entity_ID  
                        AND (@Changeset_MUID IS NOT NULL OR @Changeset_Name IS NOT NULL)  
                        AND (@Changeset_MUID IS NULL OR MUID = @Changeset_MUID)  
                        AND (@Changeset_Name IS NULL OR Name = @Changeset_Name)');  
        EXEC sp_executesql @SQL, N'@Version_ID INT, @Entity_ID INT, @Changeset_Name NVARCHAR(250), @Changeset_MUID UNIQUEIDENTIFIER, @Owner_ID INT OUTPUT, @Changeset_ID INT OUTPUT, @CurrentState TINYINT OUT',  
                @Version_ID, @Entity_ID, @Changeset_Name, @Changeset_MUID, @Owner_ID OUTPUT, @Changeset_ID OUTPUT, @CurrentState OUTPUT;  
    END  
  
    IF @Changeset_ID IS NULL OR NOT (@Owner_ID = @User_ID OR (@Entity_Permission = @Permission_Admin AND @CurrentState = @ChangesetStatus_Pending))  
    BEGIN  
        RAISERROR(N'MDSERR300031|The changeset id is invalid or you don''t have the permission to update the changeset.', 16, 1);  
        RETURN;  
    END  
  
    -- Check member type security.  
    IF @Entity_Permission = @Permission_Admin  
    BEGIN  
        SET @MemberType_Permission = @Permission_Access;  
        SET @MemberType_AccessPermission = @AccessPermission_All;  
    END  
    ELSE  
    BEGIN  
        SELECT @MemberType_Permission = Privilege_ID,  
            @MemberType_AccessPermission = AccessPermission  
        FROM mdm.viw_SYSTEM_SECURITY_USER_MEMBERTYPE  
        WHERE [User_ID] = @User_ID  
            AND [Entity_ID] = @Entity_ID  
            AND ID = @MemberType_Leaf;  
  
        SET @MemberType_Permission = COALESCE(@MemberType_Permission, @Permission_Deny);  
  
        -- In the case of Privilege_ID is inferred, should be Interpreted as Access and ReadOnly  
        IF  @MemberType_Permission = @Permission_Inferred  
        BEGIN  
            SET @MemberType_Permission = @Permission_Access;  
            SET @MemberType_AccessPermission = @AccessPermission_Read;  
        END;  
  
        IF @MemberType_Permission = @Permission_Deny   
        BEGIN  
            RAISERROR(N'MDSERR120002|The user does not have permission to perform this operation.', 16, 1);  
            RETURN;  
        END;  
  
        SET @UseMemberSecurity = mdm.udfUseMemberSecurity (@User_ID, @Entity_ID, @Version_ID, @MemberType_Leaf);  
    END  
  
    -- Process attribtues  
    CREATE TABLE #AttributesWorkingSet  
    (  
        MUID UNIQUEIDENTIFIER NULL,  
        Name NVARCHAR(250) COLLATE DATABASE_DEFAULT NULL,  
        ID INT NULL,  
        AttributeType_ID TINYINT NULL,  
        DataType_ID TINYINT NULL,  
        SortOrder INT,  
        AccessPermission TINYINT  
    );  
    CREATE INDEX #ix_AttributesWorkingSet_Name ON #AttributesWorkingSet(Name);  
  
    IF (@AttributeGroup_MUID IS NOT NULL OR @AttributeGroup_Name IS NOT NULL)  
    BEGIN  
        EXEC mdm.udpInformationLookupAttributeGroup  
            @User_ID = @User_ID,  
            @Entity_ID = @Entity_ID,  
            @AttributeGroup_MUID = @AttributeGroup_MUID,  
            @AttributeGroup_Name = @AttributeGroup_Name,  
            @ID = @AttributeGroup_ID OUTPUT;  
        IF @AttributeGroup_ID IS NULL  
        BEGIN  
            RAISERROR(N'MDSERR300011|Attribute Group is Invalid', 16, 1);  
            RETURN;  
        END;  
  
        INSERT INTO #AttributesWorkingSet  
        (  
            MUID  
            ,Name  
            ,ID  
            ,AttributeType_ID  
            ,DataType_ID  
            ,SortOrder  
            ,AccessPermission  
        )  
        SELECT  
            att.MUID  
            ,att.Name  
            ,att.ID  
            ,att.AttributeType_ID  
            ,att.DataType_ID  
            ,COALESCE(agDetail.SortOrder, att.SortOrder)  
            ,sec.AccessPermission  
        FROM mdm.tblAttribute att  
        INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ATTRIBUTE sec -- Only return AttributeType_ID <> @AttributeType_System  
        ON att.ID = sec.ID AND sec.User_ID = @User_ID AND att.Entity_ID = @Entity_ID AND att.MemberType_ID = @MemberType_Leaf  
        LEFT JOIN mdm.tblAttributeGroupDetail agDetail  
        ON agDetail.Attribute_ID = sec.ID AND agDetail.AttributeGroup_ID = @AttributeGroup_ID  
        WHERE agDetail.Attribute_ID IS NOT NULL OR att.IsSystem = 1  
    END  
    ELSE IF EXISTS (SELECT 1 FROM @AttributeTable)  
    BEGIN  
        INSERT INTO #AttributesWorkingSet  
        (  
            MUID  
            ,Name  
            ,ID  
            ,AttributeType_ID  
            ,DataType_ID  
            ,SortOrder  
            ,AccessPermission  
        )  
        SELECT  
            att.MUID  
            ,att.Name  
            ,att.ID  
            ,att.AttributeType_ID  
            ,att.DataType_ID  
            ,att.SortOrder  
            ,sec.AccessPermission  
        FROM mdm.tblAttribute att  
        INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ATTRIBUTE sec -- Only return AttributeType_ID <> @AttributeType_System  
        ON att.ID = sec.ID AND sec.User_ID = @User_ID AND att.Entity_ID = @Entity_ID AND att.MemberType_ID = @MemberType_Leaf  
        LEFT JOIN @AttributeTable at  
        ON (at.MUID IS NULL OR at.MUID = 0x0 OR at.MUID = att.MUID) AND (at.Name IS NULL OR at.Name = N'' OR at.Name = att.Name)  
        WHERE (at.MUID IS NOT NULL AND at.MUID != 0x0) OR (at.Name IS NOT NULL AND at.Name != N'') OR att.IsSystem = 1  
    END  
    ELSE  
    BEGIN  
        INSERT INTO #AttributesWorkingSet  
        (  
            MUID  
            ,Name  
            ,ID  
            ,AttributeType_ID  
            ,DataType_ID  
            ,SortOrder  
            ,AccessPermission  
        )  
        SELECT  
            att.MUID  
            ,att.Name  
            ,att.ID  
            ,att.AttributeType_ID  
            ,att.DataType_ID  
            ,att.SortOrder  
            ,sec.AccessPermission  
        FROM mdm.tblAttribute att  
        INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ATTRIBUTE sec -- Only return AttributeType_ID <> @AttributeType_System  
        ON att.ID = sec.ID AND sec.User_ID = @User_ID AND att.Entity_ID = @Entity_ID AND att.MemberType_ID = @MemberType_Leaf  
    END  
  
    SET @MemberType_AccessPermission = @MemberType_AccessPermission & @AccessPermission_UpdateDelete;  
  
    IF EXISTS(SELECT ID FROM #AttributesWorkingSet WHERE (AccessPermission & @AccessPermission_Update) = @AccessPermission_Update)  
    BEGIN  
        SET @MemberType_AccessPermission |= @AccessPermission_Update;  
    END  
    ELSE  
    BEGIN  
        SET @MemberType_AccessPermission &= @AccessPermission_Delete;  
    END;  
  
    -- If version status is committed or locked, the member is readonly.  
    IF (@VersionStatus = @VersionStatus_Committed) OR (@VersionStatus = @VersionStatus_Locked AND @Model_Permission != @Permission_Admin)  
    BEGIN  
        SET @MemberType_AccessPermission = @AccessPermission_Read;  
    END  
  
    IF NOT (@CurrentState = @ChangesetStatus_Open OR @CurrentState = @ChangesetStatus_Rejected)  
    BEGIN  
        SET @MemberType_AccessPermission = @AccessPermission_Read;  
    END  
  
    IF @IncludeUnchangedValue = 0  
    BEGIN  
        SET @ColumnString = CONCAT(N'  
            T.CS_ID AS CS_ID  
            ,COALESCE(T.ID, 0) AS ID  
            ,CASE WHEN en.ID IS NULL THEN T.[Code] ELSE en.[Code] END AS [Code]  
            ,CASE WHEN en.ID IS NULL THEN T.[Name] ELSE en.[Name] END AS [Name]  
            ,T.MUID  
            ,T.LastChgTS',  
            CASE @IncludeAuditInfo  
                WHEN 1 THEN N'  
            ,T.EnterDTM  
            ,T.EnterUserName  
            ,T.LastChgDTM  
            ,T.LastChgUserName'  
            END, N'  
            ,T.Status_ID  
            ,T.Code AS [Code.New]  
            ,T.[Code.IsChanged] AS [Code.New.IsChanged]  
            ,T.Name AS [Name.New]  
            ,T.[Name.IsChanged] AS [Name.New.IsChanged]');  
    END  
    ELSE  
    BEGIN  
        SET @ColumnString = CONCAT(N'  
            T.CS_ID AS CS_ID  
            ,COALESCE(T.ID, en.ID, 0) AS ID  
            ,CASE WHEN T.[Code.IsChanged] = 1 THEN T.Code ELSE en.Code END AS Code  
            ,T.[Code.IsChanged] AS [Code.IsChanged]  
            ,CASE WHEN T.[Name.IsChanged] = 1 THEN T.Name ELSE en.Name END AS Name  
            ,T.[Name.IsChanged] AS [Name.IsChanged]  
            ,COALESCE(T.MUID, en.MUID) AS MUID  
            ,COALESCE(T.LastChgTS, en.LastChgTS) AS LastChgTS',  
            CASE @IncludeAuditInfo  
                WHEN 1 THEN N'  
            ,COALESCE(T.EnterUserName, en.EnterUserName) AS EnterUserName  
            ,COALESCE(T.EnterDTM, en.EnterDTM) AS EnterDTM  
            ,COALESCE(T.LastChgUserName, en.LastChgUserName) AS LastChgUserName  
            ,COALESCE(T.LastChgDTM, en.LastChgDTM) AS LastChgDTM'  
            END);  
    END  
  
    IF @IncludeUnchangedValue = 0  
    BEGIN  
        SELECT  
            @ColumnString +=  
                CASE  
                    WHEN AttributeType_ID = @AttributeType_Domain  
                    THEN CONCAT(N'  
            ,T.', QUOTENAME(Name), N'  
            ,T.', QUOTENAME(Name + '.ID'), N'  
            ,T.', QUOTENAME(Name + '.Name'), N'  
            ,T.', QUOTENAME(Name + '.MUID'), N'  
            ,T.', QUOTENAME(Name + '.IsChanged'))  
                    ELSE CONCAT(N'  
            ,T.', QUOTENAME(Name), N'  
            ,T.', QUOTENAME(Name + '.IsChanged'))  
                END  
        FROM #AttributesWorkingSet  
        WHERE Name <> N'Code'  
            AND Name <> N'Name'  
    END  
    ELSE  
    BEGIN  
        SELECT  
            @ColumnString +=  
                CASE  
                    WHEN AttributeType_ID = @AttributeType_Domain  
                    THEN CONCAT(N'  
            ,CASE WHEN T.', QUOTENAME(Name + N'.IsChanged'), N' = 1 THEN T.', QUOTENAME(Name), N' ELSE en.', QUOTENAME(Name), N' END AS ', QUOTENAME(Name), N'  
            ,CASE WHEN T.', QUOTENAME(Name + N'.IsChanged'), N' = 1 THEN T.', QUOTENAME(Name + N'.ID'), N' ELSE en.', QUOTENAME(Name + N'.ID'), N' END AS ', QUOTENAME(Name + N'.ID'), N'  
            ,CASE WHEN T.', QUOTENAME(Name + N'.IsChanged'), N' = 1 THEN T.', QUOTENAME(Name + N'.Name'), N' ELSE en.', QUOTENAME(Name + N'.Name'), N' END AS ', QUOTENAME(Name + N'.Name'), N'  
            ,CASE WHEN T.', QUOTENAME(Name + N'.IsChanged'), N' = 1 THEN T.', QUOTENAME(Name + N'.MUID'), N' ELSE en.', QUOTENAME(Name + N'.MUID'), N' END AS ', QUOTENAME(Name + N'.MUID'), N'  
            ,T.', QUOTENAME(Name + N'.IsChanged'), N' AS ', QUOTENAME(Name + '.IsChanged'))  
                    ELSE CONCAT(N'  
            ,CASE WHEN T.', QUOTENAME(Name + N'.IsChanged'), N' = 1 THEN T.', QUOTENAME(Name), N' ELSE en.', QUOTENAME(Name), N' END', N' AS ', QUOTENAME(Name), N'  
            ,T.', QUOTENAME(Name + N'.IsChanged'), N' AS ', QUOTENAME(Name + '.IsChanged'))  
                END  
        FROM #AttributesWorkingSet  
        WHERE Name <> N'Code'  
            AND Name <> N'Name'  
    END  
  
    IF @UseMemberSecurity = 0  
    BEGIN  
        SET @ColumnString = CONCAT(@ColumnString, N'  
        ,@MemberType_Permission AS Privilege_ID  
        ,@MemberType_AccessPermission AS AccessPermission');  
    END  
    ELSE  
    BEGIN  
        SET @ColumnString = CONCAT(@ColumnString, N'  
        ,@MemberType_Permission AS Privilege_ID  
        ,CONVERT(TINYINT, COALESCE(membersresolved.AccessPermission & @MemberType_AccessPermission, @MemberType_AccessPermission)) AS AccessPermission');  
    END;  
  
    SET @MemberViewName = mdm.udfViewNameGet(@Model_ID, @Entity_ID, @MemberType_Leaf, 0, 1);  
    SET @EnViewName = mdm.udfViewNameGet(@Model_ID, @Entity_ID, @MemberType_Leaf, 0, 0);  
  
    SET @MemberFrom = N'';  
    IF @MemberWhere IS NOT NULL AND @MemberWhere <> N''  
    BEGIN  
        SET @MemberWhere = N'  
            AND ' + @MemberWhere;  
    END  
    ELSE  
    BEGIN  
        SET @MemberWhere = N'';  
    END  
  
    IF @ParentCode IS NULL  
    BEGIN  
        SET @Parent_ID = NULL;  
    END  
    ELSE IF UPPER(@ParentCode) = N'MDMUNUSED'  
    BEGIN  
        SET @Parent_ID = @Unused_ID;  
    END  
    ELSE IF UPPER(@ParentCode) = N'ROOT'  
    BEGIN  
        SET @Parent_ID = @Root_ID;  
    END   
    ELSE IF @Hierarchy_ID IS NOT NULL  
    BEGIN  
        DECLARE @TempTableName SYSNAME =  
            CASE @HierarchyType_Derived  
                WHEN @HierarchyType_ID THEN  CONCAT(N'tbl_', @Model_ID, N'_', @ParentEntity_ID ,N'_EN')  
                ELSE CONCAT(N'tbl_', @Model_ID, N'_', @Entity_ID ,N'_HP')  
            END;  
  
        SET @SQL = CONCAT(N'  
            SELECT TOP 1 @Parent_ID = ID  
            FROM mdm.', QUOTENAME(@TempTableName), N'   
            WHERE Version_ID = @Version_ID AND Code = @ParentCode;');  
        EXEC sp_executesql @SQL, N'@ParentCode NVARCHAR(250), @Version_ID INT, @Parent_ID INT OUTPUT', @ParentCode, @Version_ID, @Parent_ID OUTPUT;  
  
        IF @Parent_ID IS NULL  
        BEGIN  
            RAISERROR('MDSERR100025|Either the parent code or the parent type is not valid.', 16, 1);  
            RETURN;  
        END  
    END  
  
    IF @Hierarchy_ID IS NOT NULL  
    BEGIN  
        --Derived Hierarchy  
        IF @HierarchyType_ID = @HierarchyType_Derived  
        BEGIN  
            -- Determine if it is a recursive hierarchy that anchors null recursions.  
            DECLARE @IsRecursiveAndAnchorsNullRecursions BIT = COALESCE(  
               (SELECT TOP 1 tDH.AnchorNullRecursions  
                FROM mdm.tblDerivedHierarchy tDH  
                LEFT JOIN mdm.viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED_LEVELS tDHL  
                ON tDHL.Hierarchy_ID = tDH.ID  
                WHERE   tDH.ID = @Hierarchy_ID  
                    AND tDHL.IsRecursive = 1  
                    AND tDHL.LevelNumber = 0)-- only look at top recursive level  
                , 0);  
  
            DECLARE @RootEntity_ID INT = 0;  
            IF @IsRecursiveAndAnchorsNullRecursions = 0 AND @ParentCode IS NULL --Find Entities for the root of the Derived Hierarchy  
            BEGIN  
                SELECT TOP 1  
                    @RootEntity_ID = Entity_ID  
                FROM mdm.viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED_LEVELS  
                WHERE   Hierarchy_ID = @Hierarchy_ID  
                    AND LevelNumber = 0 -- topmost level  
            END  
  
            IF @RootEntity_ID != @Entity_ID  
            BEGIN  
                -- We are looking for the foreign ID of the Derived Hierarchy. In the normal case there should be only one returned that match the hierarchy ID  
                -- and is of type DBA. If there is a hidden level, the tblAttribute.Entity_ID will NOT be the same as the given entity. But, as we only get back one result it is correct  
                -- But, .in the case of a recursive hierarchy that has level(s) beneath the recursive levels, there will be more than 1 returned result. We only want to filter out the one that has the same entity ID in the attribute  
                -- We solve this by sorting by the equality of attribute.Entity_ID to the given entity ID. if there is only one result, it doesn't matter. For multiple results we will  
                -- always get back first the one that has the ID we are looking for and choose it using a TOP 1.  
  
                IF (@HierarchyLevelNumber IS NULL)  
                BEGIN  
                    SELECT TOP 1  
                         @ParentAttribute_ID = dhd.Foreign_ID  
                        ,@HierarchyLevel_ID = dhd.Level_ID  
                    FROM mdm.tblDerivedHierarchyDetail dhd  
                    INNER JOIN mdm.tblAttribute a  
                    ON      dhd.Foreign_ID = a.ID  
                        AND dhd.ForeignType_ID IN (@ForeignType_DBA, @ForeignType_ManyToMany)  
                    WHERE   dhd.DerivedHierarchy_ID = @Hierarchy_ID  
                        AND a.DomainEntity_ID = @ParentEntity_ID  
                    ORDER BY (CASE WHEN a.Entity_ID = @Entity_ID THEN 0 ELSE dhd.Level_ID END)  ASC  
                END ELSE  
                BEGIN  
                    IF (@HierarchyLevelNumber = 0)  
                    BEGIN  
                        -- Top-level of hierarchy  
                        SELECT TOP 1  
                             @ParentAttribute_ID = CASE WHEN dhd.IsRecursive = 1 THEN Foreign_ID END  
                            ,@HierarchyLevel_ID = Level_ID  
                        FROM mdm.viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED_LEVELS dhd  
                        WHERE   dhd.Hierarchy_ID = @Hierarchy_ID  
                            AND dhd.ForeignType_ID IN (@ForeignType_DBA, @ForeignType_ManyToMany)  
                            AND dhd.LevelNumber = 0  
                    END  
                    ELSE BEGIN  
                        -- Below the top level of hierarchy  
                        DECLARE @ParentLevel_ID INT;  
                        SELECT TOP 1  
                             @ParentAttribute_ID = Foreign_ID -- The Attribute_ID is the Foreign_ID of the level above the specified level  
                            ,@ParentLevel_ID = Level_ID  
                        FROM mdm.viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED_LEVELS dhd  
                        WHERE   dhd.Hierarchy_ID = @Hierarchy_ID  
                            AND dhd.ForeignType_ID IN (@ForeignType_DBA, @ForeignType_ManyToMany)  
                            AND dhd.LevelNumber < @HierarchyLevelNumber -- Get the nearest matching parent level (make skip levels if the immediate parent is not visible)  
                            AND dhd.IsLevelVisible = 1  
                            AND dhd.Entity_ID = @ParentEntity_ID  
                        ORDER BY dhd.Level_ID  
  
                        SET @HierarchyLevel_ID = @ParentLevel_ID - 1;  
                    END  
                END  
  
                DECLARE  
                    @CurrentLevel_ID                        INT,  
                    @PriorLevel_ID                          INT,  
                    @PriorLevelForeignType_ID               TINYINT,  
                    @PriorLevelManyToManyChildAttribute_ID  INT;  
  
                --Fetch the attribute DBA column name  
                SELECT  
                    @ParentAttribute_Name = [Name]  
                FROM mdm.tblAttribute WHERE ID = @ParentAttribute_ID;  
  
                --Check to see if any levels were skipped; if so, create the proper join string------------  
                --Fetch the prior level  
                SELECT TOP 1  
                     @PriorLevel_ID = Level_ID  
                    ,@PriorLevelForeignType_ID = ForeignType_ID  
                    ,@PriorLevelManyToManyChildAttribute_ID = ManyToManyChildAttribute_ID  
                FROM mdm.tblDerivedHierarchyDetail  
                WHERE   DerivedHierarchy_ID = @Hierarchy_ID  
                    AND Foreign_ID = @ParentAttribute_ID  
                    AND ForeignType_ID IN (@ForeignType_DBA, @ForeignType_ManyToMany)  
                    AND (@HierarchyLevel_ID IS NULL OR Level_ID > @HierarchyLevel_ID)  
                ORDER BY Level_ID DESC;  
  
                --Fetch the current level  
                SELECT TOP 1 @CurrentLevel_ID = Level_ID  
                FROM mdm.tblDerivedHierarchyDetail  
                WHERE   DerivedHierarchy_ID = @Hierarchy_ID  
                    AND Level_ID < @PriorLevel_ID  
                    AND IsVisible = 1  
                ORDER BY Level_ID DESC;  
  
                --Fetch the list of tables to join (if skipping levels)  
                DECLARE @SkippedLevel TABLE  
                (  
                     Level_ID                       INT PRIMARY KEY  
                    ,ForeignType_ID                 TINYINT NOT NULL  
                    ,AttributeName                  SYSNAME NOT NULL -- Name of Foreign_ID  
                    ,EntityViewName                 SYSNAME NOT NULL  
                    ,DomainEntityViewName           SYSNAME NOT NULL  
                    ,ManyToManyChildAttribute_Name  SYSNAME NULL  
                );  
                INSERT INTO @SkippedLevel  
                SELECT  
                     l.Level_ID  
                    ,l.ForeignType_ID  
                    ,l.Foreign_Name AS AttributeName  
                    ,mdm.udfViewNameGetByID(  
                        CASE l.ForeignType_ID  
                        WHEN @ForeignType_ManyToMany THEN a.Entity_ID -- Use the mapping table for M2M levels  
                        ELSE l.Entity_ID END  
                        , @MemberType_Leaf, 0, 0) AS EntityViewName  
                    ,mdm.udfViewNameGetByID(a.DomainEntity_ID, @MemberType_Leaf, 0, 0) AS DomainEntityViewName  
                    ,l.ManyToManyChildAttribute_Name  
                FROM mdm.viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED_LEVELS l  
                LEFT JOIN mdm.tblAttribute a  
                ON      l.Foreign_ID = a.ID  
                    AND l.ForeignType_ID IN (@ForeignType_DBA, @ForeignType_ManyToMany)  
                WHERE   l.Hierarchy_ID = @Hierarchy_ID  
                    AND l.Level_ID > @CurrentLevel_ID  
                    AND l.Level_ID < @PriorLevel_ID ;  
  
                DECLARE  
                    @TempLevel_ID                   INT,  
                    @TempForeignType_ID             TINYINT,  
                    @TempEntityViewName             SYSNAME = NULL,  
                    @TempDomainEntityViewName       SYSNAME = NULL,  
                    @TempViewAlias                  SYSNAME = NULL,  
                    @TempPriorViewAlias             SYSNAME = N'T',  
                    @TempAttributeName              SYSNAME,  
                    @ManyToManyChildAttributeName   SYSNAME  
                     ;  
  
                WHILE EXISTS(SELECT 1 FROM @SkippedLevel)  
                BEGIN  
                    SELECT TOP 1  
                        @TempLevel_ID                   = Level_ID,  
                        @TempForeignType_ID             = ForeignType_ID,  
                        @TempAttributeName              = AttributeName,  
                        @TempEntityViewName             = EntityViewName,  
                        @TempDomainEntityViewName       = DomainEntityViewName,  
                        @ManyToManyChildAttributeName   = ManyToManyChildAttribute_Name  
                    FROM @SkippedLevel  
                    ORDER BY Level_ID ASC;  
  
                    IF (@TempForeignType_ID = @ForeignType_ManyToMany)  
                    BEGIN  
                        -- Join with the mapping table  
                        SET @TempViewAlias = CONCAT('skipMapLvl', @TempLevel_ID);  
                        SET @MemberFrom += CONCAT(N'  
                    LEFT JOIN mdm.', QUOTENAME(@TempEntityViewName), N' AS ', QUOTENAME(@TempViewAlias), N'  
                    ON      ', QUOTENAME(@TempPriorViewAlias), N'.ID = ', QUOTENAME(@TempViewAlias), N'.', QUOTENAME(CONCAT(@ManyToManyChildAttributeName, N'.ID')), N'  
                        AND ', QUOTENAME(@TempPriorViewAlias), N'.Version_ID = ', QUOTENAME(@TempViewAlias), N'.Version_ID');  
                        SET @TempPriorViewAlias = @TempViewAlias;  
                    END  
  
                    -- Join with the skipped level's entity view  
                    SET @TempViewAlias = CONCAT(N'skipLvl', @TempLevel_ID)  
                    SET @MemberFrom += CONCAT(N'  
                    LEFT JOIN mdm.', QUOTENAME(@TempDomainEntityViewName), N' AS ', QUOTENAME(@TempViewAlias), N'  
                    ON      ', QUOTENAME(@TempPriorViewAlias), '.', QUOTENAME(CONCAT(@TempAttributeName, N'.ID')), N' = ' + QUOTENAME(@TempViewAlias), N'.ID  
                        AND ', QUOTENAME(@TempPriorViewAlias), '.Version_ID = ', QUOTENAME(@TempViewAlias) + N'.Version_ID');  
  
                    SET @TempPriorViewAlias = @TempViewAlias;  
  
                    DELETE FROM @SkippedLevel  
                    WHERE Level_ID = @TempLevel_ID;  
                END; --while  
  
                DECLARE @MappingTableAlias SYSNAME = NULL;  
                IF @PriorLevelForeignType_ID = @ForeignType_ManyToMany  
                BEGIN  
                    SET @MappingTableAlias = CONCAT(N'mapLvl', @PriorLevel_ID);  
                    -- Join with the mapping entity  
                    DECLARE  
                         @MappingEntityViewName SYSNAME  
                        ,@ParentAttributeName   SYSNAME  
                        ,@ChildAttributeName    SYSNAME;  
  
                    SELECT  
                         @MappingEntityViewName = mdm.udfViewNameGetByID(a.Entity_ID, @MemberType_Leaf, 0, 0)  
                        ,@ParentAttributeName   = Name  
                    FROM mdm.tblAttribute a  
                    WHERE ID = @ParentAttribute_ID;  
  
                    SELECT @ChildAttributeName = Name  
                    FROM mdm.tblAttribute  
                    WHERE ID = @PriorLevelManyToManyChildAttribute_ID  
  
                    -- Note: This is a LEFT rather than INNER JOIN so that it works for MDMUNUSED (i.e. when the attribute value is null and the join condition won't have matches only for unused members)  
                    SET @MemberFrom += CONCAT(N'  
                    LEFT JOIN mdm.', QUOTENAME(@MappingEntityViewName), N' ', @MappingTableAlias, N'  
                    ON      ', COALESCE(@TempViewAlias, 'T'), N'.ID = ', @MappingTableAlias, N'.', QUOTENAME(CONCAT(@ChildAttributeName, N'.ID')), N'  
                        AND ', COALESCE(@TempViewAlias, 'T'), N'.Version_ID = ', @MappingTableAlias, N'.Version_ID  
                    ');  
                END  
  
                SET @MemberWhere += N'  
                        AND ' + COALESCE(@MappingTableAlias, @TempViewAlias, 'T') + '.' + QUOTENAME(CONCAT(@ParentAttribute_Name, N'.ID')) + CASE  
                        WHEN COALESCE(@Parent_ID, 0) <= 0 THEN N' IS NULL '  
                        ELSE N' = @Parent_ID '  
                        END;  
            END  
        END  
        -- Explicit hierarchy  
        ELSE IF @HierarchyType_ID = @HierarchyType_Explicit  
        BEGIN  
            IF @Parent_ID IS NOT NULL  
            -- Display members under a explicit hierarchy  
            BEGIN  
                -- Unused Leaf members  
                IF @Parent_ID = @Unused_ID  
                BEGIN  
                    SET @MemberFrom += CONCAT(N'  
                         LEFT JOIN [mdm].', @HierarchyTable, N' HR  
                         ON HR.ChildType_ID = ', @MemberType_Leaf, N'  
                            AND HR.Version_ID = @Version_ID  
                            AND HR.Hierarchy_ID = @Hierarchy_ID  
                            AND HR.Child_EN_ID = T.ID  
                            AND HR.Status_ID = ', @MemberStatusActive, N'  
                        ');  
  
                    SET @MemberWhere += N'  
                            AND HR.Child_EN_ID IS NULL'  
                END  
                -- Under consolidate member or root  
                ELSE  
                BEGIN  
                    SET @MemberFrom += CONCAT(N'  
                    INNER JOIN [mdm].', @HierarchyTable, N' AS HR  
                    ON HR.ChildType_ID = ', @MemberType_Leaf, N'  
                        AND HR.Version_ID = @Version_ID  
                        AND HR.Hierarchy_ID = @Hierarchy_ID  
                        AND HR.Child_EN_ID = T.ID  
                        AND HR.Status_ID = ', @MemberStatusActive, N'  
                        ');  
  
                    SET @MemberWhere += N'  
                        AND ISNULL(HR.Parent_HP_ID, 0) = @Parent_ID'  
                END  
            END  
        END  
    END  
  
    -- Create members CTE  
    SET @MembersCTE = CONCAT(N'  
    pendingChanges AS  
    (  
        SELECT ', @ColumnString, N'  
        FROM (  
            SELECT * FROM [mdm].', @MemberViewName, N'  
            WHERE CS_ID = @Changeset_ID AND Version_ID = @Version_ID  
        ) T',  
        CASE WHEN @IncludeUnchangedValue = 1 THEN N'  
        FULL OUTER '  
        ELSE N'  
        LEFT '  
        END, N'JOIN (  
            SELECT * FROM [mdm].', @EnViewName, '  
            WHERE Version_ID = @Version_ID  
        ) en ON T.ID = en.ID',  
        CASE  
            WHEN @UseMemberSecurity = 1 THEN CONCAT(N'  
        LEFT JOIN [mdm].', @SecurityTableName, N' membersresolved  
        ON membersresolved.ID = T.ID  
            AND membersresolved.User_ID = @User_ID  
            AND membersresolved.Version_ID = @Version_ID  
        WHERE (T.ID IS NULL OR membersresolved.ID IS NOT NULL)',  
                CASE   
                    WHEN @IncludeUnchangedValue = 1 THEN N' AND (T.Status_ID = 1 OR T.Status_ID IS NULL)'  
                END)  
            ELSE  
                CASE   
                    WHEN @IncludeUnchangedValue = 1 THEN N'  
        WHERE (T.Status_ID = 1 OR T.Status_ID IS NULL)'  
            END  
                END  
        , N'  
    ),  
    members AS  
    (  
        SELECT T.*  
        FROM pendingChanges T',  
        @MemberFrom,  
        CASE WHEN @MemberWhere IS NOT NULL AND @MemberWhere != N'' THEN CONCAT(N'  
        WHERE 1 = 1 ', @MemberWhere) END,  
        N'  
    )');  
  
    IF (@MemberReturnOption & @MemberReturnOptionData <> 0)  
    BEGIN  
        IF @IncludeUnchangedValue = 0  
        BEGIN  
            SELECT  
                 MUID  
                ,Name  
                ,ID  
                ,AttributeType_ID  
                ,DataType_ID  
            FROM #AttributesWorkingSet  
            ORDER BY SortOrder, ID  
        END  
        ELSE  
        BEGIN  
            SELECT  
                MUID  
                ,Name  
                ,ID  
                ,AttributeType_ID  
                ,DataType_ID  
            FROM #AttributesWorkingSet  
            WHERE Name <> N'Code'  
                AND Name <> N'Name'  
            ORDER BY SortOrder, ID  
        END  
  
        SET @SQL = CONCAT(N'  
    WITH',  
    @MembersCTE, N'  
    SELECT *  
    FROM members T',  
    CASE  
        WHEN @PagingTerm IS NOT NULL  
        THEN CONCAT (N'  
    ORDER BY ', @SortTerm,  
    @PagingTerm)  
        ELSE N''  
    END,  
    ';');  
        --SELECT CONVERT(XML, @SQL);  
        EXEC sp_executesql @SQL, N'@Version_ID INT, @User_ID INT, @Changeset_ID INT, @MemberType_Permission TINYINT, @MemberType_AccessPermission TINYINT, @PageNumber INT, @PageSize INT, @SearchTable mdm.MemberGetCriteria READONLY, @Parent_ID INT, @Hierarchy_ID INT',  
                                   @Version_ID,     @User_ID,     @Changeset_ID,     @MemberType_Permission,         @MemberType_AccessPermission,         @PageNumber,     @PageSize,     @SearchTable,                       @Parent_ID,     @Hierarchy_ID;  
    END  
  
    IF @MemberReturnOption & @MemberReturnOptionCount <> 0  
    BEGIN  
        SET @SQL = CONCAT(N'  
    WITH',  
    @MembersCTE, N'  
            SELECT @MemberCount = Count(*)  
    FROM members T');  
        EXEC sp_executesql @SQL, N'@Version_ID INT, @User_ID INT, @Changeset_ID INT, @MemberType_Permission TINYINT, @MemberType_AccessPermission TINYINT, @SearchTable mdm.MemberGetCriteria READONLY, @Parent_ID INT, @Hierarchy_ID INT, @MemberCount INT OUTPUT',  
                                   @Version_ID,     @User_ID,     @Changeset_ID,     @MemberType_Permission,         @MemberType_AccessPermission,         @SearchTable,                                @Parent_ID,     @Hierarchy_ID,     @MemberCount OUTPUT;  
    END  
END
go

