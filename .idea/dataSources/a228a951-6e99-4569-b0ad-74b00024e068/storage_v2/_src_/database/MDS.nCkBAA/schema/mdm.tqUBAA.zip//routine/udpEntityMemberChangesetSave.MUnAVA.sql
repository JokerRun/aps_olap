/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpEntityMemberChangesetSave  
(  
    @User_ID                INT,  
    @Model_Name             NVARCHAR(50) = NULL,  
    @Model_MUID             UNIQUEIDENTIFIER = NULL,  
    @Entity_Name            NVARCHAR(50) = NULL,  
    @Entity_MUID            UNIQUEIDENTIFIER= NULL,  
    @Version_Name           NVARCHAR(50) = NULL,  
    @Version_MUID           UNIQUEIDENTIFIER = NULL,  
    @ChangesetName          NVARCHAR(250) = NULL,  
    @ChangesetMUID          UNIQUEIDENTIFIER = NULL OUTPUT,  
    @Description            NVARCHAR(500) = NULL,  
    @ChangesetStatus        TINYINT,  
    @CorrelationID          UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
  
    DECLARE @GuidEmpty                  UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER),  
            @Owner_ID                   INT,  
            @Model_ID                   INT,  
            @Entity_ID                  INT,  
            @Version_ID                 INT,  
            @Changeset_ID               INT,  
  
            @RequireApproval            BIT,  
  
            @CurrentState               TINYINT,  
            @ChangesetStatus_Open       TINYINT = 1,  
            @ChangesetStatus_Pending    TINYINT = 2,  
            @ChangesetStatus_Approved   TINYINT = 3,  
            @ChangesetStatus_Rejected   TINYINT = 4,  
            @ChangesetStatus_Committed  TINYINT = 5,  
  
            @EntityPermission           TINYINT,  
            @Permission_Deny            TINYINT = 1,  
            @Permission_Admin           TINYINT = 5,  
  
            @MemberType_Leaf            TINYINT = 1,  
  
            @Status_Active              TINYINT = 1,  
            @Status_Deactivated         TINYINT = 2,  
  
            --Attribute Types  
            @AttributeType_FreeForm     TINYINT = 1,  
            @AttributeType_DBA          TINYINT = 2,  
            @AttributeType_SYSTEM       TINYINT = 3,  
            @AttributeType_File         TINYINT = 4,  
  
            --Attribute DataTypes  
            @AttributeDataType_DateTime TINYINT = 3,  
            @AttributeDataType_Link     TINYINT = 6,  
  
            @SysNull_Text               NVARCHAR(1) = NCHAR(0),  
            @CommitFailedMessage        NVARCHAR(50) = CONVERT(NVARCHAR(50),NEWID()),  
  
            @PendingView                SYSNAME,  
            @MemberTable                SYSNAME,  
  
            @ChangesetTableName         SYSNAME,  
            @TruncationGuard            NVARCHAR(MAX) = N'',  
            @SQL                        NVARCHAR(MAX),  
            @SetStatusSQL               NVARCHAR(MAX);  
  
    SELECT  
        @User_ID = NULLIF(@User_ID, 0),  
        @Model_MUID = NULLIF(@Model_MUID, @GuidEmpty),  
        @Model_Name = NULLIF(LTRIM(RTRIM(@Model_Name)), N''),  
        @Entity_MUID = NULLIF(@Entity_MUID, @GuidEmpty),  
        @Entity_Name = NULLIF(LTRIM(RTRIM(@Entity_Name)), N''),  
        @Version_MUID = NULLIF(@Version_MUID, @GuidEmpty),  
        @Version_Name = NULLIF(LTRIM(RTRIM(@Version_Name)), N''),  
        @ChangesetMUID = NULLIF(@ChangesetMUID, @GuidEmpty),  
        @ChangesetName = NULLIF(LTRIM(RTRIM(@ChangesetName)), N''),  
        @Description = NULLIF(LTRIM(RTRIM(@Description)), N'');  
  
    IF @User_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR100009|The User ID is not valid.', 16, 1);  
        RETURN;  
    END  
  
    SELECT  
         @Model_ID = m.ID,  
         @Model_MUID = m.MUID,  
         @Model_Name = m.Name  
    FROM mdm.tblModel m  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_MODEL s  
    ON      m.ID = s.ID  
        AND s.Privilege_ID <> @Permission_Deny  
        AND s.User_ID = @User_ID  
    WHERE (@Model_MUID IS NOT NULL OR @Model_Name IS NOT NULL)  
        AND (@Model_MUID IS NULL OR @Model_MUID = m.MUID)  
        AND (@Model_Name IS NULL OR @Model_Name = m.Name)  
  
    IF @Model_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300005|The supplied model is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    SELECT  
        @Version_ID = ID,  
        @Version_MUID = MUID,  
        @Version_Name = Name  
    FROM mdm.tblModelVersion  
    WHERE (@Version_MUID IS NOT NULL OR @Version_Name IS NOT NULL)  
        AND (@Version_MUID IS NULL OR MUID = @Version_MUID)  
        AND (@Version_Name IS NULL OR Name = @Version_Name)  
        AND Model_ID = @Model_ID;  
  
    IF @Version_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300006|The supplied version is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    SELECT  
        @Entity_ID = e.ID,  
        @Entity_MUID = e.MUID,  
        @Entity_Name = e.Name,  
        @EntityPermission = s.Privilege_ID,  
        @RequireApproval = e.RequireApproval  
    FROM mdm.tblEntity e  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ENTITY s  
    ON      e.ID = s.ID  
        AND s.Privilege_ID <> @Permission_Deny  
        AND s.User_ID = @User_ID  
    WHERE (@Entity_MUID IS NOT NULL OR @Entity_Name IS NOT NULL)  
        AND (@Entity_MUID IS NULL OR @Entity_MUID = e.MUID)  
        AND (@Entity_Name IS NULL OR @Entity_Name = e.Name)  
        AND e.Model_ID = @Model_ID;  
  
    IF @Entity_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300008|The supplied entity is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    -- Verify the entity version is not a sync target.  
    IF EXISTS(SELECT 1 FROM mdm.tblSyncRelationship  
              WHERE TargetEntity_ID = @Entity_ID  
                AND TargetVersion_ID = @Version_ID)  
    BEGIN  
        RAISERROR('MDSERR200220|The entity member(s) cannot be saved. The entity version is the target of a sync relationship.', 16, 1);  
        RETURN;  
    END  
    SET @ChangesetTableName = CONCAT(N'tbl_', @Model_ID, N'_CS');  
  
    IF @ChangesetMUID IS NULL  
    BEGIN  
        IF @ChangesetName IS NULL  
        BEGIN  
            RAISERROR(N'MDSERR300027|The changeset name is required.', 16, 1);  
            RETURN;  
        END;  
  
        SET @SQL = CONCAT(N'  
            IF NOT EXISTS (  
                SELECT 1  
                FROM [mdm].', @ChangesetTableName, N'  
                WHERE Version_ID = @Version_ID  
                    AND Name = @ChangesetName  
            )  
            BEGIN  
                SET @ChangesetMUID = NEWID();  
                INSERT [mdm].', @ChangesetTableName, N' (Version_ID, Entity_ID, Name, Description, MUID, Status, EnterUserID, LastChgUserID)  
                VALUES(@Version_ID, @Entity_ID, @ChangesetName, @Description, @ChangesetMUID, ', @ChangesetStatus_Open, N', @User_ID, @User_ID);  
            END');  
        EXEC sp_executesql @SQL, N'@Version_ID INT, @Entity_ID INT, @ChangesetName NVARCHAR(250), @Description NVARCHAR(500), @User_ID INT, @ChangesetMUID UNIQUEIDENTIFIER OUTPUT',  
            @Version_ID, @Entity_ID, @ChangesetName, @Description, @User_ID, @ChangesetMUID OUTPUT;  
  
        IF @ChangesetMUID IS NULL  
        BEGIN  
            RAISERROR(N'MDSERR300030|The changeset name is not unqinue.', 16, 1);  
            RETURN;  
        END;  
    END  
    ELSE  
    BEGIN  
        SET @SQL = CONCAT(N'  
            SELECT @Changeset_ID = ID, @Owner_ID = EnterUserID , @CurrentState = Status  
            FROM [mdm].', @ChangesetTableName, N'  
            WHERE Version_ID = @Version_ID  
                AND MUID = @ChangesetMUID');  
        EXEC sp_executesql @SQL, N'@Version_ID INT, @ChangesetMUID UNIQUEIDENTIFIER, @Owner_ID INT OUTPUT, @Changeset_ID INT OUTPUT, @CurrentState TINYINT OUT',  
                @Version_ID, @ChangesetMUID, @Owner_ID OUTPUT, @Changeset_ID OUTPUT, @CurrentState OUTPUT;  
  
        IF @Changeset_ID IS NOT NULL AND @Owner_ID != @User_ID AND @EntityPermission != @Permission_Admin  
        BEGIN  
            RAISERROR(N'MDSERR300031|The changeset id is invalid or you don''t have the permission to update the changeset.', 16, 1);  
            RETURN;  
        END  
  
        IF @ChangesetName IS NOT NULL OR @Description IS NOT NULL  
        BEGIN  
            DECLARE @Ret BIT = 0;  
            SET @SQL = CONCAT(N'  
                IF @ChangesetName IS NULL OR  
                    NOT EXISTS (  
                        SELECT 1  
                        FROM [mdm].', @ChangesetTableName, N'  
                        WHERE Version_ID = @Version_ID  
                            AND Name = @ChangesetName  
                            AND ID <> @Changeset_ID  
                )  
                BEGIN  
                    UPDATE [mdm].', @ChangesetTableName, N'  
                    SET Name = COALESCE(@ChangesetName, Name),  
                        Description = COALESCE(@Description, Description)  
                    WHERE Version_ID = @Version_ID  
                        AND ID = @Changeset_ID  
                    SET @Ret = 1;  
                END  
                ELSE  
                BEGIN  
                    SET @Ret = 0;  
                END');  
            EXEC sp_executesql @SQL, N'@Version_ID INT, @Changeset_ID INT, @ChangesetName NVARCHAR(250), @Description NVARCHAR(500), @Ret BIT OUTPUT',  
                @Version_ID, @Changeset_ID, @ChangesetName, @Description, @Ret OUTPUT;  
  
            IF @Ret = 0  
            BEGIN  
                RAISERROR(N'MDSERR300030|The changeset name is not unqinue.', 16, 1);  
                RETURN;  
            END  
        END  
  
        IF @ChangesetStatus = @CurrentState  
        BEGIN  
            RETURN;  
        END  
  
        SET @SQL = CONCAT(N'  
            SELECT @ChangesetName = Name  
            FROM [mdm].', @ChangesetTableName, N'  
            WHERE Version_ID = @Version_ID  
                AND ID = @Changeset_ID');  
        EXEC sp_executesql @SQL, N'@Version_ID INT, @Changeset_ID INT, @ChangesetName NVARCHAR(250) OUTPUT',  
            @Version_ID, @Changeset_ID, @ChangesetName OUTPUT;  
  
        DECLARE @StateMachineTransition TABLE  
        (  
            FromState TINYINT NOT NULL,  
            ToState TINYINT NOT NULL,  
            RequireAdmin BIT NOT NULL  
        );  
  
        IF @RequireApproval = 1  
        BEGIN  
            INSERT @StateMachineTransition (FromState, ToState, RequireAdmin)  
            VALUES (@ChangesetStatus_Open, @ChangesetStatus_Pending, 0),  
                (@ChangesetStatus_Pending, @ChangesetStatus_Open, 0),  
                (@ChangesetStatus_Pending, @ChangesetStatus_Rejected, 1),  
                (@ChangesetStatus_Pending, @ChangesetStatus_Approved, 1),  
                (@ChangesetStatus_Rejected, @ChangesetStatus_Pending, 0),  
                (@ChangesetStatus_Rejected, @ChangesetStatus_Open, 0),  
                (@ChangesetStatus_Approved, @ChangesetStatus_Open, 0),  
                (@ChangesetStatus_Approved, @ChangesetStatus_Committed, 0);  
        END  
        ELSE  
        BEGIN  
            INSERT @StateMachineTransition (FromState, ToState, RequireAdmin)  
            VALUES (@ChangesetStatus_Open, @ChangesetStatus_Committed, 0),  
                -- In case of entity is not require approve anymore, the orphan state can transit back  
                (@ChangesetStatus_Rejected, @ChangesetStatus_Committed, 0),  
                (@ChangesetStatus_Rejected, @ChangesetStatus_Open, 0),  
                (@ChangesetStatus_Pending, @ChangesetStatus_Open, 0),  
                (@ChangesetStatus_Approved, @ChangesetStatus_Open, 0);  
        END  
  
        DECLARE @RequireAdmin BIT = NULL;  
  
        SELECT @RequireAdmin = RequireAdmin  
        FROM @StateMachineTransition  
        WHERE FromState = @CurrentState  
            AND ToState = @ChangesetStatus  
  
        IF @RequireAdmin IS NULL  
        BEGIN  
            RAISERROR(N'MDSERR300029|The changeset cannot transfer to the target status.', 16, 1);  
            RETURN;  
        END  
  
        IF (@RequireAdmin = 1 AND (@EntityPermission != @Permission_Admin OR @User_ID = @Owner_ID))  
            OR (@RequireAdmin = 0 AND @User_ID != @Owner_ID)  
        BEGIN  
            RAISERROR(N'MDSERR120002|The user does not have permission to perform this operation.', 16, 1);  
            RETURN;  
        END  
  
        SET @SetStatusSQL = CONCAT(N'  
            UPDATE [mdm].', @ChangesetTableName, N'  
            SET Status = @ChangesetStatus,  
                LastChgDTM = GETUTCDATE(),  
                LastChgUserID = @User_ID  
            WHERE ID = @Changeset_ID  
                AND Version_ID = @Version_ID');  
  
        SET @PendingView = mdm.udfViewNameGet(@Model_ID, @Entity_ID, @MemberType_Leaf, 0, 1);  
        SET @MemberTable = CONCAT(N'tbl_', @Model_ID, N'_', @Entity_ID, N'_EN')  
  
        IF @ChangesetStatus = @ChangesetStatus_Committed  
        BEGIN  
            DECLARE @TranCounter INT = @@TRANCOUNT;  
            IF @TranCounter > 0  
            BEGIN  
                SAVE TRANSACTION TX;  
            END ELSE  
            BEGIN  
                BEGIN TRANSACTION;  
            END;  
  
            BEGIN TRY  
                -- Approve workflow  
                DECLARE @AttributeIDUnPivot NVARCHAR(MAX),  
                        @AttributeSelector  NVARCHAR(MAX);  
  
                SELECT  
                    @AttributeIDUnPivot = CONCAT(@AttributeIDUnPivot, N' ,', QUOTENAME(ID)),  
                    @AttributeSelector =  
                        CASE  
                            WHEN AttributeType_ID = @AttributeType_FreeForm AND DataType_ID = @AttributeDataType_DateTime  
                            THEN CONCAT(@AttributeSelector, N',  
                        CASE ', QUOTENAME(a.Name + N'.IsChanged'), N'WHEN 1 THEN COALESCE(CONVERT(NVARCHAR(MAX), ', QUOTENAME(a.Name), N', 126) /*ISO8601*/, @SysNull_Text) END AS', QUOTENAME(ID))  
                            WHEN AttributeType_ID = @AttributeType_DBA  
                            THEN CONCAT(@AttributeSelector, N',  
                        CASE ', QUOTENAME(a.Name + N'.IsChanged'), N'WHEN 1 THEN COALESCE(CONVERT(NVARCHAR(MAX), ', QUOTENAME(a.Name), N'), @SysNull_Text) END AS', QUOTENAME(ID))  
                            WHEN AttributeType_ID = @AttributeType_File  
                            THEN CONCAT(@AttributeSelector, N',  
                        CASE ', QUOTENAME(a.Name + N'.IsChanged'), N'WHEN 1 THEN COALESCE(CONVERT(NVARCHAR(MAX), ', QUOTENAME(a.Name + '.ID'), N'), @SysNull_Text) END AS', QUOTENAME(ID))  
                            ELSE CONCAT(@AttributeSelector, N',  
                        CASE ', QUOTENAME(a.Name + N'.IsChanged'), N'WHEN 1 THEN COALESCE(CONVERT(NVARCHAR(MAX), ', QUOTENAME(a.Name), N'), @SysNull_Text) END AS', QUOTENAME(ID))  
                        END  
                FROM mdm.tblAttribute a  
                WHERE Entity_ID = @Entity_ID  
                    AND AttributeType_ID <> @AttributeType_SYSTEM  
                    AND MemberType_ID = @MemberType_Leaf  
  
                SET @AttributeIDUnPivot = RIGHT(@AttributeIDUnPivot, Len(@AttributeIDUnPivot) - 2);  
  
                SET @SQL = CONCAT(@TruncationGuard, N'  
                    -- Update changeset status  
                    ', @SetStatusSQL, N'  
  
                    DECLARE @Ret INT = 0;  
                    -- Delete member  
                    DECLARE @MemberIds mdm.MemberId;  
                    INSERT @MemberIds (ID, MemberType_ID, Code, MUID)  
                    SELECT 0, ', @MemberType_Leaf, N', N'''', pd.MUID  
                    FROM mdm.', @PendingView, N' pd  
                    INNER JOIN mdm.', @MemberTable, N' en  
                        ON pd.ID = en.ID AND pd.Version_ID = en.Version_ID  
                    WHERE CS_ID = @Changeset_ID  
                        AND pd.Version_ID = @Version_ID  
                        AND pd.Status_ID = ', @Status_Deactivated, '  
                        AND pd.Status_ID != en.Status_ID  
  
                    IF EXISTS (SELECT 1 FROM @MemberIds)  
                    BEGIN  
                        EXEC @Ret = mdm.udpMembersStatusSet  
                            @User_ID = @User_ID,  
                            @Model_ID = @Model_ID,  
                            @Entity_ID = @Entity_ID,  
                            @Version_ID = @Version_ID,  
                            @MemberIds = @MemberIds,  
                            @MemberType_ID = ', @MemberType_Leaf, N',  
                            @Status_ID = ', @Status_Deactivated, N',  
                            @Approved = 1,  
                            @ResetDbaReferences = 1,  
                            @TransactionBehavior = 2, /*AllOrNothingByBatch*/  
                            @LogFlag = 1,  
                            @RaiseFirstError = 0;  
  
                        IF @Ret != 1  
                        BEGIN  
                            RAISERROR(@CommitFailedMessage, 16, 1);  
                            RETURN  
                        END  
                    END  
  
                    -- Reactive member  
                    DELETE @MemberIds  
  
                    INSERT @MemberIds (ID, MemberType_ID, Code, MUID)  
                    SELECT 0, ', @MemberType_Leaf, N', N'''', pd.MUID  
                    FROM mdm.', @PendingView, N' pd  
                    INNER JOIN mdm.', @MemberTable, N' en  
                        ON pd.ID = en.ID AND pd.Version_ID = en.Version_ID  
                    WHERE CS_ID = @Changeset_ID  
                        AND pd.Version_ID = @Version_ID  
                        AND pd.Status_ID = ', @Status_Active, '  
                        AND pd.Status_ID != en.Status_ID  
  
                    IF EXISTS (SELECT 1 FROM @MemberIds)  
                    BEGIN  
                        EXEC @Ret = mdm.udpMembersStatusSet  
                            @User_ID = @User_ID,  
                            @Model_ID = @Model_ID,  
                            @Entity_ID = @Entity_ID,  
                            @Version_ID = @Version_ID,  
                            @MemberIds = @MemberIds,  
                            @MemberType_ID = ', @MemberType_Leaf, N',  
                            @Status_ID = ', @Status_Active, N',  
                            @Approved = 1,  
                            @ResetDbaReferences = 1,  
                            @TransactionBehavior = 2, /*AllOrNothingByBatch*/  
                            @LogFlag = 1,  
                            @RaiseFirstError = 0;  
  
                        IF @Ret != 1  
                        BEGIN  
                            RAISERROR(@CommitFailedMessage, 16, 1);  
                            RETURN  
                        END  
                    END  
  
                    -- Create or update member  
                    DECLARE @Members            mdm.MemberSaveList,  
                            @MemberAttributes   mdm.MemberAttributeValues;  
  
                    INSERT @Members (RowID, MemberCode, MemberName, MemberMUID)  
                    SELECT  
                        PD_ID,  
                        CASE WHEN ID IS NULL THEN Code ELSE NULL END,  
                        CASE WHEN ID IS NULL THEN Name ELSE NULL END,  
                        MUID  
                    FROM mdm.', @PendingView, N'  
                    WHERE CS_ID = @Changeset_ID  
                        AND Version_ID = @Version_ID  
                        AND Status_ID = ', @Status_Active, ';  
  
                    INSERT @MemberAttributes (MemberRowID, AttributeID, AttributeValue)  
                    SELECT ID, AttributeID, NULLIF(AttributeValue, @SysNull_Text)  
                    FROM  
                    (  
                        SELECT PD_ID AS ID ' ,@AttributeSelector, N'  
                        FROM mdm.', @PendingView, N'  
                        WHERE CS_ID = @Changeset_ID  
                           AND Version_ID = @Version_ID  
                           AND Status_ID = ', @Status_Active, '  
                    ) p  
                    UNPIVOT(AttributeValue FOR AttributeID IN (', @AttributeIDUnPivot, N')) AS unpvt  
  
                    IF EXISTS (SELECT 1 FROM @Members)  
                    BEGIN  
                        EXEC @Ret = mdm.udpEntityMembersSave  
                            @User_ID = @User_ID,  
                            @Model_ID = @Model_ID,  
                            @Entity_ID = @Entity_ID,  
                            @Version_ID = @Version_ID,  
                            @MemberType_ID = ', @MemberType_Leaf, N',  
                            @Members = @Members,  
                            @MemberAttributes = @MemberAttributes,  
                            @SaveMode = 2, /*Merge*/  
                            @TransactionBehavior = 2, /*AllOrNothingByBatch*/  
                            @LogFlag = 1,  
                            @ReturnCreatedMembers = 0,  
                            @ValidateDataTypes = 1,  
                            @DoInheritanceRuleCheck = 1,  
                            @ErrorReportingType = 1,  
                            @Approved = 1;  
  
                        IF @Ret != 1  
                        BEGIN  
                            RAISERROR(@CommitFailedMessage, 16, 1);  
                            RETURN  
                        END  
                    END');  
  
                EXEC sp_executesql @SQL,  
                    N'@Version_ID INT, @Changeset_ID INT, @User_ID INT, @Model_ID INT, @Entity_ID INT, @ChangesetStatus TINYINT, @CommitFailedMessage NVARCHAR(50), @SysNull_Text NVARCHAR(1)',  
                      @Version_ID,     @Changeset_ID,     @User_ID,     @Model_ID,     @Entity_ID,     @ChangesetStatus,         @CommitFailedMessage,              @SysNull_Text;  
  
                IF @RequireApproval = 1  
                BEGIN  
                    EXEC mdm.udpNotificationCreateChangesetStatusChange  
                        @User_ID = @User_ID,  
                        @Model_Name = @Model_Name,  
                        @Model_MUID = @Model_MUID,  
                        @Model_ID = @Model_ID,  
                        @Entity_Name = @Entity_Name,  
                        @Entity_MUID = @Entity_MUID,  
                        @Entity_ID = @Entity_ID,  
                        @Version_Name = @Version_Name,  
                        @Version_MUID = @Version_MUID,  
                        @Version_ID = @Version_ID,  
                        @Changeset_MUID = @ChangesetMUID,  
                        @Changeset_Name = @ChangesetName,  
                        @Onwer_ID = @Owner_ID,  
                        @PriorStatus_ID = @CurrentState,  
                        @NewStatus_ID = @ChangesetStatus  
                END  
  
                IF @TranCounter = 0  
                BEGIN  
                    COMMIT TRANSACTION;  
                END  
            END TRY  
            BEGIN CATCH  
                DECLARE  
                    @ErrorSeverity INT,  
                    @ErrorState INT,  
                    @ErrorNumber INT,  
                    @ErrorLine INT,  
                    @ErrorProcedure NVARCHAR(126),  
                    @ErrorMessage NVARCHAR(4000);  
  
                EXEC mdm.udpGetErrorInfo  
                    @ErrorMessage = @ErrorMessage OUTPUT,  
                    @ErrorSeverity = @ErrorSeverity OUTPUT,  
                    @ErrorState = @ErrorState OUTPUT,  
                    @ErrorNumber = @ErrorNumber OUTPUT,  
                    @ErrorLine = @ErrorLine OUTPUT,  
                    @ErrorProcedure = @ErrorProcedure OUTPUT  
  
                IF @TranCounter = 0  
                BEGIN  
                    ROLLBACK TRANSACTION;  
                END  
                ELSE IF XACT_STATE() <> -1  
                BEGIN  
                    ROLLBACK TRANSACTION TX;  
                END  
  
                IF @ErrorMessage <> @CommitFailedMessage  
                BEGIN  
                    RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
                END  
            END CATCH  
        END  
        ELSE  
        BEGIN  
            IF @ChangesetStatus = @ChangesetStatus_Pending  
            BEGIN  
                DECLARE @HasPendingChanges BIT = 0;  
                SET @SQL = CONCAT(@TruncationGuard, N'  
                    IF EXISTS (  
                        SELECT 1  
                        FROM mdm.', @PendingView, '  
                        WHERE CS_ID = @Changeset_ID  
                            AND Version_ID = @Version_ID  
                    )  
                    BEGIN  
                        SET @HasPendingChanges = 1;  
                    END  
                ');  
  
                EXEC sp_executesql @SQL,  
                    N'@Version_ID INT, @Changeset_ID INT, @HasPendingChanges BIT OUTPUT',  
                        @Version_ID,     @Changeset_ID,     @HasPendingChanges OUTPUT;  
  
                IF(@HasPendingChanges != 1)  
                BEGIN  
                    RAISERROR(N'MDSERR300037|Can''t submit an empty changeset for approval.', 16, 1);  
                    RETURN;  
                END  
            END  
  
            EXEC sp_executesql @SetStatusSQL,  
                N'@Version_ID INT, @User_ID INT, @Changeset_ID INT, @ChangesetStatus TINYINT',  
                  @Version_ID,     @User_ID,     @Changeset_ID,     @ChangesetStatus;  
  
            IF @RequireApproval = 1  
            BEGIN  
                EXEC mdm.udpNotificationCreateChangesetStatusChange  
                    @User_ID = @User_ID,  
                    @Model_Name = @Model_Name,  
                    @Model_MUID = @Model_MUID,  
                    @Model_ID = @Model_ID,  
                    @Entity_Name = @Entity_Name,  
                    @Entity_MUID = @Entity_MUID,  
                    @Entity_ID = @Entity_ID,  
                    @Version_Name = @Version_Name,  
                    @Version_MUID = @Version_MUID,  
                    @Version_ID = @Version_ID,  
                    @Changeset_MUID = @ChangesetMUID,  
                    @Changeset_Name = @ChangesetName,  
                    @Onwer_ID = @Owner_ID,  
                    @PriorStatus_ID = @CurrentState,  
                    @NewStatus_ID = @ChangesetStatus  
            END  
  
            IF @ChangesetStatus = @ChangesetStatus_Approved  
            BEGIN  
                -- Commit the change on owner behalf  
                EXEC mdm.udpEntityMemberChangesetSave  
                    @User_ID = @Owner_ID,  
                    @Model_Name = @Model_Name,  
                    @Model_MUID = @Model_MUID,  
                    @Entity_Name = @Entity_Name,  
                    @Entity_MUID = @Entity_MUID,  
                    @Version_Name = @Version_Name,  
                    @Version_MUID = @Version_MUID,  
                    @ChangesetMUID = @ChangesetMUID,  
                    @ChangesetStatus = @ChangesetStatus_Committed;  
            END  
        END  
    END  
END
go

