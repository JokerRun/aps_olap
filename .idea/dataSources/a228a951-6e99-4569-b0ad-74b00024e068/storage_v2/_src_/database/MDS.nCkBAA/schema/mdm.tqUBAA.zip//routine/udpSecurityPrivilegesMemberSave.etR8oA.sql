/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
  
*/  
CREATE PROCEDURE mdm.udpSecurityPrivilegesMemberSave  
(  
    @SystemUser_ID      INT,  
    @Principal_ID       INT,  
    @PrincipalType_ID   TINYINT,  
    @Principal_Name     NVARCHAR(355) = NULL, -- Max group name length  
    @RoleAccess_ID      INT,  
    @Privilege_ID       TINYINT,  
    @AccessPermission   TINYINT = NULL,  
    @Version_ID         INT,  
    @Entity_ID          INT,  
    @Hierarchy_ID       INT,  
    @HierarchyType_ID   TINYINT,  
    @Member_ID          INT,  
    @MemberType_ID      TINYINT,  
    @Securable_Name     NVARCHAR(100) = NULL,  
    @Return_ID          INT = NULL OUTPUT,  
    @Return_MUID        UNIQUEIDENTIFIER = NULL OUTPUT ,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON  
  
    -- Set AccessPermission as 0 if AccessPermission is null  
    SET @AccessPermission = ISNULL(@AccessPermission, 0);  
  
    DECLARE @Role_ID            INT;  
    DECLARE @Description        NVARCHAR(250);  
  
    SELECT  @Role_ID = Role_ID  
    FROM    mdm.tblSecurityAccessControl  
    WHERE   Principal_ID = @Principal_ID  
    AND     PrincipalType_ID = @PrincipalType_ID  
  
  
    IF @Principal_Name IS NULL BEGIN  
        IF @PrincipalType_ID = 1 BEGIN  
            SELECT @Principal_Name = mdm.udfUserNameGetByUserID(@Principal_ID)  
        END ELSE BEGIN  
            SELECT @Principal_Name = Name FROM mdm.tblUserGroup WHERE ID = @Principal_ID  
        END   
    END  
  
    DECLARE @PrincipalType_Name NVARCHAR(20);  
    IF @PrincipalType_ID = 1 BEGIN  
        SELECT @PrincipalType_Name = N'User'  
    END ELSE BEGIN  
        SELECT @PrincipalType_Name = N'Group'  
    END   
  
    IF @Role_ID IS NULL BEGIN  
        --Create a new user account role for this user.  
        INSERT INTO mdm.tblSecurityRole (Name, EnterUserID, LastChgUserID) VALUES (CONCAT(N'Role for ', @PrincipalType_Name, N' ', @Principal_Name), @SystemUser_ID, @SystemUser_ID)  
        SET @Role_ID = SCOPE_IDENTITY()  
  
        INSERT INTO mdm.tblSecurityAccessControl (PrincipalType_ID, Principal_ID, Role_ID, Description, EnterUserID, LastChgUserID)   
        VALUES (@PrincipalType_ID, @Principal_ID, @Role_ID, LEFT(@Principal_Name, 89) + N' ' + @PrincipalType_Name, @SystemUser_ID, @SystemUser_ID)  
    END   
  
    SELECT    @Description = @Securable_Name + N' ' + o.Name + N' (' + p.Name + N')'  
    FROM    mdm.tblSecurityObject o   
            INNER JOIN mdm.tblSecurityPrivilege p   
                ON p.ID = @Privilege_ID  
  
    -- Ensure the specified hierarchy is valid for member permissions. Recursive derived hierarchies that   
    -- 1. Do not anchor null recursions, or  
    -- 2. Have one or more levels above the recursive level  
    -- are not securable because nodes can appear more than once, resulting in potential security permission conflicts.  
    DECLARE   
         @HierarchyType_Derived         TINYINT = 1  
        ,@HierarchyItemType_ManyToMany  TINYINT = 5  
        ,@HierarchyItemType_Hierararchy                TINYINT = 2;  
  
    IF (@HierarchyType_ID = @HierarchyType_Derived)  
    BEGIN  
        DECLARE   
            @HighestLevel INT,  
            @HasRecursiveLevel BIT = 0,  
            @HasManyToManyLevel BIT = 0,  
            @HasForeignHierarchy BIT = 0;  
        SELECT   
             @HighestLevel = MAX(Level_ID)  
            ,@HasRecursiveLevel = MAX(IsRecursive)  
            ,@HasManyToManyLevel = MAX(CASE WHEN ForeignType_ID = @HierarchyItemType_ManyToMany THEN 1 ELSE 0 END)  
            ,@HasForeignHierarchy = MAX(CASE WHEN ForeignType_ID = @HierarchyItemType_Hierararchy THEN 1 ELSE 0 END)  
        FROM mdm.viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED_LEVELS    
        WHERE Hierarchy_ID = @Hierarchy_ID  
          
        IF (@HasManyToManyLevel = 1)  
        BEGIN  
            RAISERROR('MDSERR500068|A permission cannot be saved on a derived hierarchy that has a many-to-many relationship level.', 16, 1);  
            RETURN;  
        END  
  
        IF (@HasForeignHierarchy = 1)  
        BEGIN  
            RAISERROR('MDSERR500069|A permission cannot be saved on a derived hierarchy that has an explicit hierarchy cap.', 16, 1)  
            RETURN;  
        END  
  
        IF (@HasRecursiveLevel = 1)  
        BEGIN  
  
            DECLARE @LowestRecursiveLevel INT =   
               (SELECT MIN(Level_ID)  
                FROM mdm.viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED_LEVELS    
                WHERE   Hierarchy_ID = @Hierarchy_ID  
                    AND IsRecursive = 1)  
  
            IF (@HighestLevel > @LowestRecursiveLevel)  
            BEGIN  
                RAISERROR('MDSERR500066|A permission cannot be saved on a recursive derived hierarchy that has a level above the recursive level.', 16, 1);  
                RETURN;  
            END  
  
            -- The hierarchy is recursive. Ensure it does not have a level above the recursive level and that it anchors null recursions.  
            IF (EXISTS (SELECT 1 FROM mdm.tblDerivedHierarchy WHERE ID = @Hierarchy_ID AND AnchorNullRecursions = 0))  
            BEGIN  
                RAISERROR('MDSERR500065|A permission cannot be saved on a recursive derived hierarchy that does not anchor null recursions.', 16, 1);  
                RETURN;  
            END  
        END  
    END  
  
    IF IsNull(@RoleAccess_ID, 0) > 0   
    BEGIN  
        IF EXISTS(SELECT 1 FROM mdm.tblSecurityRoleAccessMember WHERE ID = @RoleAccess_ID)   
        BEGIN  
            DECLARE @ExistingUserRoleAccess_ID INT  
            DECLARE @RoleAccessPrincipalType_ID INT  
            SELECT @RoleAccessPrincipalType_ID = PrincipalType_ID FROM mdm.viw_SYSTEM_SECURITY_ROLE_ACCESSCONTROL_MEMBER WHERE RoleAccess_ID = @RoleAccess_ID  
            IF @PrincipalType_ID = 1 AND @RoleAccessPrincipalType_ID = 2   
            BEGIN  
                -- Create a user override of a user group privilege.  First see if the user already has an existing override explicit record.  
                -- If so update it.  If not create a new one.  
                SELECT    @ExistingUserRoleAccess_ID = RoleAccess_ID   
                FROM    mdm.viw_SYSTEM_SECURITY_ROLE_ACCESSCONTROL_MEMBER rac   
                WHERE      rac.Entity_ID        = @Entity_ID  
                and        rac.Hierarchy_ID     = @Hierarchy_ID  
                and        rac.HierarchyType_ID = @HierarchyType_ID  
                and        rac.Member_ID        = @Member_ID  
                and        rac.MemberType_ID    = @MemberType_ID  
                and        rac.Principal_ID      = @Principal_ID  
                AND        rac.PrincipalType_ID  = 1   
  
                IF IsNull(@ExistingUserRoleAccess_ID, 0) = 0  
                BEGIN  
                    INSERT INTO mdm.tblSecurityRoleAccessMember (Role_ID, Privilege_ID, AccessPermission, Version_ID, Entity_ID, ExplicitHierarchy_ID,DerivedHierarchy_ID, HierarchyType_ID, Member_ID, MemberType_ID, Description, EnterUserID, LastChgUserID)  
                        SELECT @Role_ID, @Privilege_ID, @AccessPermission, Version_ID, Entity_ID, CASE @HierarchyType_ID WHEN 0 THEN @Hierarchy_ID ELSE NULL END,CASE @HierarchyType_ID WHEN 1 THEN @Hierarchy_ID ELSE NULL END, HierarchyType_ID, Member_ID, MemberType_ID, Description, @SystemUser_ID, @SystemUser_ID FROM mdm.tblSecurityRoleAccessMember WHERE ID = @RoleAccess_ID  
                END ELSE  
                BEGIN  
                    UPDATE mdm.tblSecurityRoleAccessMember SET Privilege_ID = @Privilege_ID, AccessPermission = @AccessPermission WHERE ID = @RoleAccess_ID   
                END  
            END ELSE   
            BEGIN  
                UPDATE mdm.tblSecurityRoleAccessMember SET Privilege_ID = @Privilege_ID, AccessPermission = @AccessPermission WHERE ID = @RoleAccess_ID   
            END  
        END ELSE  
        BEGIN  
            INSERT INTO mdm.tblSecurityRoleAccessMember (Role_ID, Privilege_ID, AccessPermission, Version_ID, Entity_ID, ExplicitHierarchy_ID,DerivedHierarchy_ID, HierarchyType_ID, Member_ID, MemberType_ID, Description, EnterUserID, LastChgUserID)  
            VALUES(@Role_ID, @Privilege_ID, @AccessPermission, @Version_ID, @Entity_ID, CASE @HierarchyType_ID WHEN 0 THEN @Hierarchy_ID ELSE NULL END,CASE @HierarchyType_ID WHEN 1 THEN @Hierarchy_ID ELSE NULL END, @HierarchyType_ID, @Member_ID, @MemberType_ID, @Description, @SystemUser_ID, @SystemUser_ID)  
            SELECT @RoleAccess_ID = SCOPE_IDENTITY()          
        END  
    END ELSE  
    BEGIN  
        INSERT INTO mdm.tblSecurityRoleAccessMember (Role_ID, Privilege_ID, AccessPermission, Version_ID, Entity_ID, ExplicitHierarchy_ID,DerivedHierarchy_ID, HierarchyType_ID, Member_ID, MemberType_ID, Description, EnterUserID, LastChgUserID)  
            VALUES(@Role_ID, @Privilege_ID, @AccessPermission, @Version_ID, @Entity_ID, CASE @HierarchyType_ID WHEN 0 THEN @Hierarchy_ID ELSE NULL END,CASE @HierarchyType_ID WHEN 1 THEN @Hierarchy_ID ELSE NULL END, @HierarchyType_ID, @Member_ID, @MemberType_ID, @Description, @SystemUser_ID, @SystemUser_ID)  
            SELECT @RoleAccess_ID = SCOPE_IDENTITY()          
    END  
            
    SELECT @Return_ID = @RoleAccess_ID  
    SELECT @Return_MUID = (SELECT MUID FROM mdm.tblSecurityRoleAccessMember WHERE ID = @RoleAccess_ID)  
  
    DECLARE @SecurityMemberProcessEvent mdm.SecurityMemberProcessEvent  
    INSERT @SecurityMemberProcessEvent ([User_ID], [Entity_ID], Version_ID)  
    SELECT DISTINCT [User_ID], [Entity_ID], [Version_ID]  
    FROM [mdm].[viw_SYSTEM_SECURITY_ROLE_MEMBER] rm  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ROLE ur  
    ON rm.Role_ID = ur.Role_ID  
    WHERE rm.Role_ID = @Role_ID   
        AND rm.Version_ID = @Version_ID  
        AND Hierarchy_ID = @Hierarchy_ID  
        AND HierarchyType_ID = @HierarchyType_ID  
  
    EXEC mdm.udpSecurityMemberProcessRebuildEvent @SecurityMemberProcessEvent, 1;  
  
    SET NOCOUNT OFF  
  
END --proc
go

