/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
--Puts a msg on the qureue for all entities in the version.  
Then inserts a timer msg onto the queue to effectively "kick it off"  
  
--Account/Version3  
EXEC mdm.udpSecurityMemberProcessRebuildModelVersion @Version_ID=3  
*/  
CREATE PROCEDURE mdm.udpSecurityMemberProcessRebuildModelVersion  
(  
    @Version_ID     INT, --Required  
    @ProcessNow     BIT = 0,  
    @CorrelationID  UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON;  
      
    DECLARE @SecurityMemberProcessEvent mdm.SecurityMemberProcessEvent  
  
    INSERT @SecurityMemberProcessEvent([User_ID],[Entity_ID],Version_ID)  
    SELECT NULL, e.ID, v.ID  
    FROM mdm.tblEntity AS e  
    INNER JOIN mdm.tblModelVersion AS v  
    ON v.Model_ID = e.Model_ID  
    WHERE v.ID = @Version_ID;  
  
    EXEC mdm.udpSecurityMemberProcessRebuildEvent @SecurityMemberProcessEvent, @ProcessNow  
       
    SET NOCOUNT OFF;  
END; --proc
go

