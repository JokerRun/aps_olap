/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    EXEC mdm.udpModelVersionFlagSave 1  
    EXEC mdm.udpModelVersionFlagSave '1', '7', '1', 'Version 3', 'Chuck test version', '1', @Return = ''  
*/  
CREATE PROCEDURE mdm.udpModelVersionFlagSave  
(  
    @User_ID            INT,  
    @Model_ID           INT, -- Caller should validate  
    @MUID               UNIQUEIDENTIFIER = NULL,  
    @Name               NVARCHAR(50),  
    @Description        NVARCHAR(500) = NULL,  
    @Status_ID          TINYINT = 1,  
    @CommittedOnly_ID   BIT = NULL,  
    @EditMode           TINYINT = 0, --0: Create, 1: Update, 4: Clone, defaults to Create  
    @Return_ID          INT = NULL OUTPUT,  
    @Return_MUID        UNIQUEIDENTIFIER = NULL OUTPUT, --Also an input parameter for clone operations  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE @GuidEmpty          UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER),  
            @EditMode_Create    TINYINT = 0,  
            @EditMode_Update    TINYINT = 1,  
            @EditMode_Clone     TINYINT = 4,  
            @Existing_MUID      UNIQUEIDENTIFIER = NULL,  
            @Existing_ID        INT = NULL,  
            @IsModelAdmin       INT = NULL;  
  
    SELECT   
        @Description = NULLIF(LTRIM(RTRIM(@Description)), N''),   
        @Return_ID = NULL,   
        --@CurrentDTM = GETUTCDATE(),  
        @Model_ID = NULLIF(@Model_ID, 0),  
        @MUID = NULLIF(@MUID, @GuidEmpty),  
        @Name = NULLIF(LTRIM(RTRIM(@Name)), N'')  
        ;  
  
    --Test for invalid EditMode  
    IF @EditMode IS NULL OR @EditMode NOT IN (@EditMode_Create, @EditMode_Update, @EditMode_Clone)  
    BEGIN          
        RAISERROR('MDSERR100010|The Parameters are not valid.', 16, 1);  
        RETURN;  
    END; --if  
  
    --If we are in the Update or Clone mode get the missing pieces of the identifier  
    IF @EditMode IN (@EditMode_Update, @EditMode_Clone)  
    BEGIN  
        --Only use the name if neither MUID nor ID are available. This is important because we don't want  
        --to look up by name if the name is what the user is trying to update.  
        IF @MUID IS NULL  
        BEGIN  
            SELECT TOP 1  
                @Existing_ID =  ID,  
                @Existing_MUID = MUID  
            FROM mdm.tblModelVersionFlag  
            WHERE   
                [Name] = @Name AND  
                Model_ID = @Model_ID;  
        END  
        --Use the ID and MUID to look up the full identifier  
        ELSE  
        BEGIN  
            SELECT  
                @Existing_ID =  ID,   
                @Existing_MUID = MUID  
            FROM mdm.tblModelVersionFlag   
            WHERE  
                MUID = @MUID AND  
                Model_ID = @Model_ID;  
        END  
  
        --If we are in the Clone mode we need to figure out whether we are creating or updating   
        IF @EditMode = @EditMode_Clone  
        BEGIN  
            --If there is no existing model then set the edit mode to Create  
            IF @Existing_MUID IS NULL AND @Existing_ID IS NULL  
            BEGIN  
                SET @EditMode = @EditMode_Create;  
                SET @Return_ID = NULL;  
            END  
            --If there is an existing model then set the edit mode to Update  
            ELSE  
            BEGIN  
                SET @EditMode = @EditMode_Update;  
                SET @Return_ID = @Existing_ID;  
                SET @MUID = @Existing_MUID;  
            END  
        END  
        --If we are in Update mode and could not find a matching existing item we need to raise an error and quit now  
        ELSE IF @EditMode = @EditMode_Update  
        BEGIN  
            IF @Existing_ID IS NULL OR @Existing_MUID IS NULL  
            BEGIN  
                RAISERROR('MDSERR200007|The version flag cannot be saved. The version flag ID is not valid.', 16, 1);  
                RETURN;  
            END  
            ELSE  
            BEGIN  
                SET @Return_ID = @Existing_ID;  
                SET @MUID = @Existing_MUID;  
            END  
        END  
    END  
  
   --Check the name of the version flag for duplicates  
    IF EXISTS   
    (  
        SELECT 1   
        FROM mdm.tblModelVersionFlag   
        WHERE   
            @Name = Name AND   
            (@MUID IS NULL OR MUID <> @MUID) AND  
            Model_ID = @Model_ID  
    )  
    BEGIN  
        RAISERROR('MDSERR110003|The name already exists. Type a different name.', 16, 1);  
        RETURN;  
    END  
  
  
    --Start transaction, being careful to check if we are nested  
    DECLARE @TranCounter INT;   
    SET @TranCounter = @@TRANCOUNT;  
    IF @TranCounter > 0 SAVE TRANSACTION TX;  
    ELSE BEGIN TRANSACTION;  
  
    BEGIN TRY  
  
        IF @EditMode = @EditMode_Create   
        BEGIN  
  
            --Accept an explicit MUID (for clone operations) or generate a new one  
            SET @Return_MUID =  ISNULL(@MUID, NEWID());  
  
            INSERT INTO mdm.tblModelVersionFlag   
            (  
                Model_ID,  
                Status_ID,  
                [Name],  
                [Description],  
                CommittedOnly_ID,  
                MUID,   
                EnterDTM,  
                EnterUserID,  
                LastChgDTM,  
                LastChgUserID  
            )   
            VALUES   
            (  
                @Model_ID,  
                @Status_ID,  
                @Name,  
                @Description,  
                @CommittedOnly_ID,  
                @Return_MUID,  
                GETUTCDATE(),  
                @User_ID,  
                GETUTCDATE(),  
                @User_ID  
            );  
  
            --Save the identity value  
            SET @Return_ID = SCOPE_IDENTITY();  
  
        END	ELSE   
        BEGIN  
  
            IF @CommittedOnly_ID = 1   
            BEGIN  
                DECLARE @VersionStatusCommitted TINYINT = 3;  
                -- Ensure the version flag is not already being used on an uncommitted version  
                IF EXISTS (SELECT ID FROM mdm.tblModelVersion WHERE VersionFlag_ID = @Return_ID AND Status_ID <> @VersionStatusCommitted)   
                BEGIN  
                    RAISERROR('MDSERR200084|The version flag cannot be changed to committed only. It is referenced by a non-committed version.', 16, 1);  
                    RETURN;          
                END;  
            END;   
            SET @Return_MUID = @Existing_MUID;  
  
            UPDATE mdm.tblModelVersionFlag   
            SET  
                Status_ID = ISNULL(@Status_ID, Status_ID),  
                [Name] = ISNULL(@Name, [Name]),  
                [Description] = ISNULL(@Description, [Description]),  
                CommittedOnly_ID = ISNULL(@CommittedOnly_ID,CommittedOnly_ID),  
                LastChgDTM = GETUTCDATE(),  
                LastChgUserID = @User_ID  
            WHERE  
                ID = @Return_ID;  
  
        END; --if  
  
        --Commit only if we are not nested  
        IF @TranCounter = 0   
        BEGIN  
            COMMIT TRANSACTION;  
        END -- IF  
  
    END TRY  
    --Compensate as necessary  
    BEGIN CATCH  
  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        IF @TranCounter = 0 ROLLBACK TRANSACTION;    
        ELSE IF XACT_STATE() <> -1 ROLLBACK TRANSACTION TX;    
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
  
        RETURN;  
  
    END CATCH;  
  
  
    SET NOCOUNT OFF;  
END; --proc
go

