/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Executed by SQL Agent, refreshes any sync relationships that are due.  
*/  
CREATE PROCEDURE mdm.udpSyncRefreshJob  
WITH EXECUTE AS N'mds_schema_user'      
AS  
BEGIN  
    SET NOCOUNT ON;  
  
PRINT CONCAT(SYSDATETIME(), N': Sync Job- Started.');  
  
    -- Set a MUTEX?  
  
    DECLARE   
         @TargetModel_ID    INT = 0 -- Set to non-null value to enter the below loop  
        ,@TargetVersion_ID  INT  
        ,@TargetEntity_ID   INT  
        ,@User_ID           INT  
        ,@OverdueHours      DECIMAL  
  
    -- Loop through overdue sync relationships  
    WHILE @TargetModel_ID IS NOT NULL  
    BEGIN  
  
        SET @TargetModel_ID = NULL;  
  
        ;WITH syncRelationshipsCte AS  
        (  
            SELECT   
                 LastChgUserID -- Execute the refresh using the credentials of the user who last changed the sync relationship  
                ,TargetVersion_ID  
                ,TargetEntity_ID  
                ,(DATEDIFF(MINUTE, LastSyncAttemptDTM, GETUTCDATE()) / 60.0) --HoursSinceLastRefreshAttempt  
                    - CONVERT(DECIMAL(38,1), RefreshFrequencyInHours) AS OverdueHours  
                ,RefreshFrequencyInHours   
            FROM mdm.tblSyncRelationship  
            WHERE   RefreshFrequencyInHours IS NOT NULL -- Ignore sync relationships that refresh on-demand only   
                AND RefreshFrequencyInHours > 0  
        )  
        SELECT TOP 1  
             @User_ID = sync.LastChgUserID  
            ,@TargetModel_ID = v.Model_ID  
            ,@TargetVersion_ID = sync.TargetVersion_ID  
            ,@TargetEntity_ID = sync.TargetEntity_ID  
            ,@OverdueHours = OverdueHours  
        FROM syncRelationshipsCte sync  
        INNER JOIN mdm.tblModelVersion v  
        ON sync.TargetVersion_ID = v.ID  
        WHERE sync.OverdueHours >= 0  
        ORDER BY sync.OverdueHours DESC -- prioritize the most overdue  
  
        IF @TargetModel_ID IS NOT NULL  
        BEGIN  
  
PRINT CONCAT(SYSDATETIME(), N': Sync Job- Attempting sync refresh. @User_ID = ', @User_ID, N', @TargetModel_ID = ', @TargetModel_ID, N', @TargetVersion_ID = ', @TargetVersion_ID, N', @TargetEntity_ID = ', @TargetEntity_ID, N', @OverdueHours = ', @OverdueHours);  
            BEGIN TRY  
                EXEC mdm.udpSyncRefresh @User_ID = @User_ID, @TargetModel_ID = @TargetModel_ID, @TargetVersion_ID = @TargetVersion_ID, @TargetEntity_ID = @TargetEntity_ID  
            END TRY  
            BEGIN CATCH  
  
                -- Get error info.  
                DECLARE  
                    @ErrorMessage NVARCHAR(4000),  
                    @ErrorSeverity INT,  
                    @ErrorState INT,  
                    @ErrorNumber INT,  
                    @ErrorLine INT,  
                    @ErrorProcedure NVARCHAR(126);  
                EXEC mdm.udpGetErrorInfo  
                    @ErrorMessage = @ErrorMessage OUTPUT,  
                    @ErrorSeverity = @ErrorSeverity OUTPUT,  
                    @ErrorState = @ErrorState OUTPUT,  
                    @ErrorNumber = @ErrorNumber OUTPUT,  
                    @ErrorLine = @ErrorLine OUTPUT,  
                    @ErrorProcedure = @ErrorProcedure OUTPUT  
  
PRINT CONCAT(SYSDATETIME(), N': Sync Job- Sync refresh failed with error: ', @ErrorMessage);  
  
                -- update the status and timestamp in the sync table  
                DECLARE @SyncStatus_Failed         TINYINT = 3  
                UPDATE mdm.tblSyncRelationship  
                SET    
                     LastSyncAttemptDTM = GETUTCDATE()-- Use end time, rather than start time  
                    ,LastSyncAttemptStatus = @SyncStatus_Failed  
                    ,LastSyncAttemptErrorInfo = @ErrorMessage  
                WHERE   TargetEntity_ID = @TargetEntity_ID  
                    AND TargetVersion_ID = @TargetVersion_ID  
  
            END CATCH;  
  
        END;  
  
    END; -- WHILE  
  
PRINT CONCAT(SYSDATETIME(), N': Sync Job- Finished.');  
    SET NOCOUNT OFF;  
  
END -- Proc
go

