/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
      
    SELECT mdm.udfViewNameGet(5, 42, 1, 0)  
*/  
CREATE FUNCTION mdm.udfViewNameGet  
(  
    @Model_ID       INT,  
    @Entity_ID      INT,  
    @MemberType_ID  TINYINT,  
    @IsExplodedView BIT = 0, -- When 1, adds a 'EXP' suffix to the view name, which is exploded by hierarchy parent  
    @ViewType       TINYINT = 0 -- 0 EN, 1 PD, 2 HS  
)   
RETURNS SYSNAME  
/*WITH SCHEMABINDING*/  
AS BEGIN  
    DECLARE   
         @ViewNameSuffix                    SYSNAME  
        ,@MemberType_Leaf                   TINYINT = 1  
        ,@MemberType_Consolidated           TINYINT = 2  
        ,@MemberType_Collection             TINYINT = 3  
        ,@MemberType_ParentChild            TINYINT = 4  
        ,@MemberType_CollectionParentChild  TINYINT = 5  
  
        ,@ViewType_EN                       TINYINT = 0  
        ,@ViewType_PD                       TINYINT = 1  
        ,@ViewType_HS                       TINYINT = 2;  
  
    --Suffix for view name  
    IF @IsExplodedView = 1  
    BEGIN  
        SET @ViewNameSuffix = N'_EXP'  
    END;   
      
  
    RETURN CONCAT(N'viw_SYSTEM_', @Model_ID, N'_', @Entity_ID,  
        CASE @MemberType_ID  
            WHEN @MemberType_Leaf THEN  
                CASE @ViewType  
                    WHEN @ViewType_EN THEN CONCAT(N'_CHILDATTRIBUTES', @ViewNameSuffix)  
                    WHEN @ViewType_PD THEN N'_CHILDATTRIBUTES_PENDING'  
                    WHEN @ViewType_HS THEN CONCAT(N'_CHILDATTRIBUTES_HISTORY', @ViewNameSuffix)  
                 END  
            WHEN @MemberType_Consolidated THEN  
                CASE @ViewType  
                    WHEN @ViewType_EN THEN CONCAT(N'_PARENTATTRIBUTES', @ViewNameSuffix)  
                    WHEN @ViewType_HS THEN CONCAT(N'_PARENTATTRIBUTES_HISTORY', @ViewNameSuffix)  
                END  
            WHEN @MemberType_Collection THEN  
                CASE @ViewType  
                    WHEN @ViewType_EN THEN CONCAT(N'_COLLECTIONATTRIBUTES', @ViewNameSuffix)  
                    WHEN @ViewType_HS THEN CONCAT(N'_COLLECTIONATTRIBUTES_HISTORY', @ViewNameSuffix)  
                END  
            WHEN @MemberType_ParentChild THEN  
                CASE @ViewType  
                    WHEN @ViewType_EN THEN N'_PARENTCHILD'  
                    WHEN @ViewType_HS THEN N'_PARENTCHILD_HISTORY'  
                END  
            WHEN @MemberType_CollectionParentChild THEN  
                CASE @ViewType  
                    WHEN @ViewType_EN THEN N'_COLLECTIONPARENTCHILD'  
                    WHEN @ViewType_HS THEN N'_COLLECTIONPARENTCHILD_HISTORY'  
                END  
        END --case  
        );  
END; --fn
go

