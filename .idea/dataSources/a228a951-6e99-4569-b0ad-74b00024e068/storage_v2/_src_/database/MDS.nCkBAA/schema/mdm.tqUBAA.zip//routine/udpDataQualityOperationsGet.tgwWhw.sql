/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE [mdm].[udpDataQualityOperationsGet]  
	@CreatedBefore DATETIME2 = NULL,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
AS BEGIN  
	SET NOCOUNT ON;  
	  
        SELECT CreateDTM, OperationId, SerializedOperation  
        FROM [mdm].[tblDataQualityOperationsState]  
        WHERE (@CreatedBefore IS NULL) OR (CreateDTM <= @CreatedBefore)  
  
	SET NOCOUNT OFF;  
END;
go

