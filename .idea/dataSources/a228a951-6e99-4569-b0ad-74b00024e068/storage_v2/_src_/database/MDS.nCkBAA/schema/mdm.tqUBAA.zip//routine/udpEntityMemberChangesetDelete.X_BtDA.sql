/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpEntityMemberChangesetDelete  
(  
    @User_ID                INT,  
    @Model_Name             NVARCHAR(50) = NULL,  
    @Model_MUID             UNIQUEIDENTIFIER = NULL,  
    @Version_Name           NVARCHAR(50) = NULL,  
    @Version_MUID           UNIQUEIDENTIFIER = NULL,  
    @ChangesetName          NVARCHAR(250) = NULL,  
    @ChangesetMUID          UNIQUEIDENTIFIER = NULL,  
    @Description            NVARCHAR(500) = NULL,  
    @CorrelationID          UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
  
    DECLARE @GuidEmpty                  UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER),  
            @Owner_ID                   INT,  
            @Model_ID                   INT,  
            @Entity_ID                  INT,  
            @Version_ID                 INT,  
            @Changeset_ID               INT,  
  
            @CurrentState               TINYINT,  
            @ChangesetStatus_Open       TINYINT = 1,  
            @ChangesetStatus_Pending    TINYINT = 2,  
            @ChangesetStatus_Approved   TINYINT = 3,  
            @ChangesetStatus_Rejected   TINYINT = 4,  
            @ChangesetStatus_Committed  TINYINT = 5,  
  
            @Permission_Deny            TINYINT = 1,  
  
            @ChangesetTableName         SYSNAME,  
            @PendingChangesTableName    SYSNAME,  
            @TruncationGuard            NVARCHAR(MAX) = N'',  
            @SQL                        NVARCHAR(MAX);  
  
    SELECT  
        @User_ID = NULLIF(@User_ID, 0),  
        @Model_MUID = NULLIF(@Model_MUID, @GuidEmpty),  
        @Model_Name = NULLIF(LTRIM(RTRIM(@Model_Name)), N''),  
        @Version_MUID = NULLIF(@Version_MUID, @GuidEmpty),  
        @Version_Name = NULLIF(LTRIM(RTRIM(@Version_Name)), N''),  
        @ChangesetMUID = NULLIF(@ChangesetMUID, @GuidEmpty),  
        @ChangesetName = NULLIF(LTRIM(RTRIM(@ChangesetName)), N'');  
  
    IF @User_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR100009|The User ID is not valid.', 16, 1);  
        RETURN;  
    END  
  
    SELECT  
         @Model_ID = m.ID  
    FROM mdm.tblModel m  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_MODEL s  
    ON  m.ID = s.ID  
        AND s.User_ID = @User_ID  
    WHERE (@Model_MUID IS NOT NULL OR @Model_Name IS NOT NULL)  
        AND (@Model_MUID IS NULL OR @Model_MUID = m.MUID)  
        AND (@Model_Name IS NULL OR @Model_Name = m.Name)  
        AND s.Privilege_ID <> @Permission_Deny  
  
    IF @Model_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300005|The supplied model is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    SELECT @Version_ID = ID  
    FROM mdm.tblModelVersion  
    WHERE (@Version_MUID IS NOT NULL OR @Version_Name IS NOT NULL)  
        AND (@Version_MUID IS NULL OR MUID = @Version_MUID)  
        AND (@Version_Name IS NULL OR Name = @Version_Name)  
        AND Model_ID = @Model_ID;  
  
    IF @Version_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300006|The supplied version is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    SET @ChangesetTableName = CONCAT(N'tbl_', @Model_ID, N'_CS');  
  
    SET @SQL = CONCAT(N'  
            SELECT @Changeset_ID = ID, @Owner_ID = EnterUserID , @CurrentState = Status, @Entity_ID = Entity_ID  
            FROM [mdm].', @ChangesetTableName, N'  
            WHERE Version_ID = @Version_ID  
                AND (@ChangesetMUID IS NOT NULL OR @ChangesetName IS NOT NULL)  
                AND (@ChangesetMUID IS NULL OR MUID = @ChangesetMUID)  
                AND (@ChangesetName IS NULL OR Name = @ChangesetName)');  
    EXEC sp_executesql @SQL, N'@Version_ID INT, @Entity_ID INT OUTPUT, @ChangesetName NVARCHAR(250), @ChangesetMUID UNIQUEIDENTIFIER, @Owner_ID INT OUTPUT, @Changeset_ID INT OUTPUT, @CurrentState TINYINT OUT',  
            @Version_ID, @Entity_ID OUTPUT, @ChangesetName, @ChangesetMUID, @Owner_ID OUTPUT, @Changeset_ID OUTPUT, @CurrentState OUTPUT;  
  
    IF @Changeset_ID IS NULL  
    BEGIN  
        RAISERROR(N'MDSERR300031|The changeset id is invalid or you don''t have the permission to update the changeset.', 16, 1);  
        RETURN;  
    END  
  
    IF @User_ID != @Owner_ID  
    BEGIN  
        RAISERROR(N'MDSERR120002|The user does not have permission to perform this operation.', 16, 1);    
        RETURN;  
    END;  
  
    IF @CurrentState NOT IN(@ChangesetStatus_Open, @ChangesetStatus_Committed, @ChangesetStatus_Rejected)  
    BEGIN  
        RAISERROR(N'MDSERR300029|The changeset cannot transfer to the target status.', 16, 1);  
        RETURN;  
    END  
  
    SET @PendingChangesTableName = CONCAT(N'tbl_', @Model_ID, N'_', @Entity_ID, N'_EN_PD');  
    SET @SQL = CONCAT(@TruncationGuard + N'  
        DELETE mdm.', @PendingChangesTableName, N'  
        WHERE Version_ID = @Version_ID AND CS_ID = @Changeset_ID;  
        DELETE mdm.', @ChangesetTableName, N'  
        WHERE Version_ID = @Version_ID AND ID = @Changeset_ID');  
  
    EXEC sp_executesql @SQL, N'@Version_ID INT, @Changeset_ID INT', @Version_ID, @Changeset_ID;  
END
go

