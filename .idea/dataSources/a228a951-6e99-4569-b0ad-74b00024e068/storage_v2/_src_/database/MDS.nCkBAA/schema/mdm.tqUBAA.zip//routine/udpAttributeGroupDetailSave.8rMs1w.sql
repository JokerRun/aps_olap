/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
    EXEC mdm.udpAttributeGroupDetailSave @User_ID = 1, @ModelName = N'Product', @EntityName = N'Product', @MemberType_ID = 1, @AttributeGroupName = N'System', @Name = N'SourceKey';  
    SELECT * FROM mdm.tblAttributeGroupDetail;  
*/  
CREATE PROCEDURE mdm.udpAttributeGroupDetailSave  
(  
    @User_ID            INT,  
    @Version_ID         INT = NULL, -- used for audit info. When NULL, the highest value for the model will be used  
    @AttributeGroup_ID  INT, -- Caller should validate  
    @Attribute_ID       INT, -- Caller should validate  
    @Return_ID          INT = NULL OUTPUT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON;  
  
    --Raise an error if we are missing the attribute group ID  
    IF @AttributeGroup_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR110007|The ID is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    --Raise an error if we are missing the attribute ID  
    IF @Attribute_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR110007|The ID is not valid.', 16, 1);  
        RETURN;  
    END;      
  
    IF @Version_ID IS NULL  
    BEGIN  
        SELECT @Version_ID = MAX(mv.ID)   
        FROM mdm.tblModelVersion mv  
        INNER JOIN mdm.tblEntity e  
        ON mv.Model_ID = e.Model_ID  
        INNER JOIN mdm.tblAttributeGroup ag  
        ON e.ID = ag.Entity_ID  
        WHERE ag.ID = @AttributeGroup_ID  
    END  
  
    INSERT INTO mdm.tblAttributeGroupDetail  
    (  
        AttributeGroup_ID,  
        Attribute_ID,  
        SortOrder,  
        EnterDTM,  
        EnterUserID,  
        EnterVersionID,  
        LastChgDTM,  
        LastChgUserID,  
        LastChgVersionID  
    )  
    SELECT  
        @AttributeGroup_ID,  
        @Attribute_ID,  
        ISNULL(MAX(SortOrder),0) + 1,  
        GETUTCDATE(),  
        @User_ID,  
        @Version_ID,  
        GETUTCDATE(),  
        @User_ID,  
        @Version_ID  
    FROM mdm.tblAttributeGroupDetail  
    WHERE AttributeGroup_ID = @AttributeGroup_ID;  
  
    SET @Return_ID = SCOPE_IDENTITY();  
  
    SET NOCOUNT OFF;  
END; --proc
go

