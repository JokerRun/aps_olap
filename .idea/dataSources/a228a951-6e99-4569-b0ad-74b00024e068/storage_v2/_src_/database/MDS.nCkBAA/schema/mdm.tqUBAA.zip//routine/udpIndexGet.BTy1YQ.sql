/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpIndexGet  
(  
     @User_ID       INT  
  
    ,@Model_MUID    UNIQUEIDENTIFIER = NULL  
    ,@Model_Name    NVARCHAR(50) = NULL  
    ,@Model_ID      INT = NULL -- set internally only  
  
    ,@Entity_MUID   UNIQUEIDENTIFIER = NULL  
    ,@Entity_Name   NVARCHAR(50) = NULL  
    ,@Entity_ID     INT = NULL -- set internally only  
  
    ,@Index_MUID   UNIQUEIDENTIFIER = NULL  
    ,@Index_Name   NVARCHAR(50) = NULL  
  
    ,@ResultOption TINYINT -- None = 0, Identifiers = 1, Details = 2.   
  
    ,@IncludeParentIdentifiers  BIT = 1 -- Return results sets for parent Model and Entity identifiers. Set to 0 when getting explicit hierarchies as part of a parent object (because the parent identifiers will already have been looked up).  
    ,@OmitAttributes            BIT = 0 -- When 1, a result set is not returned for attributes. This should be set to 1 when the caller will return Attributes. Ignored when @ResultOption is not Details.  
    ,@Debug                     BIT = 0  
    ,@CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
  
    SET NOCOUNT ON  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': begin udpIndexGet')  
  
    DECLARE   
         @ResultOption_Identifiers  TINYINT = 1  
        ,@ResultOption_Details      TINYINT = 2  
  
    -- Get model ID  
    IF @Model_ID IS NULL -- If the ID was already provided, don't bother looking it up again  
        AND (@Model_Name IS NOT NULL OR @Model_MUID IS NOT NULL)  
    BEGIN  
        SELECT   
             @Model_ID = ID  
            ,@Model_MUID = MUID  
            ,@Model_Name = Name  
        FROM mdm.tblModel  
        WHERE   MUID = ISNULL(@Model_MUID, MUID)  
            AND Name = ISNULL(@Model_Name, Name)  
  
        SET @Model_ID = COALESCE(@Model_ID, 0)  
    END  
  
    -- Get entity ID  
    IF @Entity_ID IS NULL -- If the ID was already provided, don't bother looking it up again  
        AND (@Entity_Name IS NOT NULL OR @Entity_MUID IS NOT NULL)  
    BEGIN  
        SELECT  
             @Model_ID = Model_ID  
            ,@Entity_ID = ID  
            ,@Entity_MUID = MUID  
            ,@Entity_Name = Name  
        FROM mdm.tblEntity  
        WHERE   MUID = ISNULL(@Entity_MUID, MUID)  
            AND Name = ISNULL(@Entity_Name, Name)  
            AND Model_ID = ISNULL(@Model_ID, Model_ID) -- If a model filter is specified, use it  
  
        SET @Entity_ID = COALESCE(@Entity_ID, 0)  
    END  
  
    -- Get index ID  
    DECLARE @Index_ID INT = NULL;  
    IF @Index_Name IS NOT NULL OR @Index_MUID IS NOT NULL  
    BEGIN  
        SELECT @Index_ID = ID  
        FROM mdm.tblIndex  
        WHERE   MUID = ISNULL(@Index_MUID, MUID)  
            AND Name = ISNULL(@Index_Name, Name)  
            AND Entity_ID = ISNULL(@Entity_ID, Entity_ID) -- If an entity filter is specified, use it  
  
        SET @Index_ID = COALESCE(@Index_ID, 0)  
    END  
  
    DECLARE @SelectedIndex TABLE   
    (  
         ID                 INT PRIMARY KEY  
        ,SysIndex_ID        INT  
        ,Entity_ID          INT  
        ,Model_ID           INT  
        ,Privilege_ID       TINYINT  
        ,AccessPermission   TINYINT  
    )  
  
    INSERT INTO @SelectedIndex  
    SELECT  
         i.Index_ID AS ID  
        ,i.SysIndex_ID  
        ,i.Entity_ID  
        ,i.Model_ID  
        ,acl.Privilege_ID  
        ,acl.AccessPermission  
    FROM mdm.viw_SYSTEM_SCHEMA_INDEXES i  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_INDEX acl  
    ON acl.ID = i.Index_ID   
    WHERE acl.User_ID = @User_ID  
        AND i.Model_ID = ISNULL(@Model_ID, i.Model_ID)  
        AND i.Entity_ID = ISNULL(@Entity_ID, i.Entity_ID)  
        AND i.Index_ID = ISNULL(@Index_ID, i.Index_ID)  
  
  
  
    IF @IncludeParentIdentifiers = 1  
    BEGIN  
        -- Return model Identifier(s)  
        IF @Model_ID IS NOT NULL  
        BEGIN  
            IF @Model_Name IS NULL OR @Model_MUID IS NULL  
            BEGIN  
                SELECT   
                     @Model_MUID = MUID  
                    ,@Model_Name = Name  
                FROM mdm.tblModel  
                WHERE ID = @Model_ID  
            END  
  
            -- A single model was specified, and its info has already been looked up, so simply return it  
            SELECT   
                 @Model_MUID    AS Model_MUID  
                ,@Model_Name    AS Model_Name  
                ,@Model_ID      AS Model_ID  
        END ELSE  
        BEGIN  
            SELECT DISTINCT  
                 m.MUID AS Model_MUID  
                ,m.Name AS Model_Name  
                ,m.ID   AS Model_ID  
            FROM @SelectedIndex i  
            INNER JOIN mdm.tblEntity e  
            ON i.Entity_ID = e.ID  
            INNER JOIN mdm.tblModel m  
            ON e.Model_ID = m.ID  
        END  
  
        -- Return entity Identifier(s)  
        IF @Entity_ID IS NOT NULL  
        BEGIN  
            -- A single entity was specified, and its info has already been looked up, so simply return it  
            SELECT   
                 @Model_ID      AS Model_ID  
                ,@Entity_MUID   AS Entity_MUID  
                ,@Entity_Name   AS Entity_Name  
                ,@Entity_ID     AS Entity_ID  
        END ELSE  
        BEGIN  
            SELECT DISTINCT  
                 e.Model_ID AS Model_ID  
                ,e.MUID AS Entity_MUID  
                ,e.Name AS Entity_Name  
                ,e.ID   AS Entity_ID  
            FROM @SelectedIndex i  
            INNER JOIN mdm.tblEntity e  
            ON i.Entity_ID = e.ID  
        END  
    END  
  
  
    SELECT  
         i.Index_MUID  
        ,i.Index_Name  
        ,i.Index_ID  
        ,si.Privilege_ID  
        ,si.AccessPermission  
  
        ,si.Entity_ID  
        ,i.Index_IsUnique AS IsUnique  
  
        ,i.EnteredUser_DTM  
        ,i.EnteredUser_MUID  
        ,i.EnteredUser_UserName  
        ,i.EnteredUser_ID  
        ,i.LastChgUser_DTM  
        ,i.LastChgUser_MUID  
        ,i.LastChgUser_UserName  
        ,i.LastChgUser_ID  
    FROM @SelectedIndex si  
    INNER JOIN mdm.viw_SYSTEM_SCHEMA_INDEXES i  
    ON si.ID = i.Index_ID  
    ORDER BY si.Model_ID, si.Entity_ID, i.SysIndex_ID  
  
    IF @ResultOption = @ResultOption_Details  
    BEGIN  
        -- return index-to-attribute mapping  
        DECLARE @IndexToAttribute TABLE  
        (   
             Index_ID       INT NOT NULL  
            ,Attribute_ID   INT NOT NULL  
        );  
  
        INSERT INTO @IndexToAttribute  
        SELECT  
             si.ID  AS Index_ID  
            ,a.ID   AS Attribute_ID  
        FROM @SelectedIndex si  
        INNER JOIN mdm.tblEntity e  
        ON si.Entity_ID = e.ID  
        INNER JOIN sys.indexes i  
        ON      OBJECT_ID(N'[mdm].' + QUOTENAME(e.EntityTable)) = i.object_id  
            AND si.SysIndex_ID = i.index_id  
        INNER JOIN sys.index_columns ic   
        ON      i.object_id = ic.object_id  
            AND i.index_id = ic.index_id  
        INNER JOIN mdm.tblAttribute a  
        ON      e.ID = a.Entity_ID -- Use index ux_tblAttribute_Entity_ID_MemberType_ID_Name  
            AND a.MemberType_ID = 1/*Leaf*/  
            AND COL_NAME(ic.object_id, ic.column_id) = a.TableColumn  
        WHERE   i.type = 2/*NONCLUSTERED*/  
            AND a.AttributeType_ID <> 3/*System*/  
  
        -- Note: this many include attributes to which the user does not have permission, because we don't want to repeat  
        -- the expensive attribute permission check here. Caller must ignore any rows that don't have a match in the   
        -- permission-checked Attributes result set  
        SELECT  
             Index_ID  
            ,Attribute_ID  
        FROM @IndexToAttribute  
        ORDER BY Index_ID  
  
  
        -- Return attributes (unless omitted)  
        IF COALESCE(@OmitAttributes, 1) = 0  
        BEGIN  
            DECLARE @AttributeIds mdm.IdList;  
            INSERT INTO @AttributeIds (ID)  
            SELECT DISTINCT Attribute_ID  
            FROM @IndexToAttribute  
  
            EXEC mdm.udpAttributeGet  
                 @User_ID = @User_ID  
                ,@Model_ID = @Model_ID  
                ,@Entity_ID = @Entity_ID  
                ,@MemberType_ID = 1/*Leaf*/  
                ,@IncludeParentIdentifiers = 0 -- parent Ids already returned  
                ,@Debug = @Debug  
                ,@AttributeIds = @AttributeIds  
                ,@CorrelationID = @CorrelationID  
        END  
  
    END   
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': end udpIndexGet')  
  
    SET NOCOUNT OFF  
END --proc
go

