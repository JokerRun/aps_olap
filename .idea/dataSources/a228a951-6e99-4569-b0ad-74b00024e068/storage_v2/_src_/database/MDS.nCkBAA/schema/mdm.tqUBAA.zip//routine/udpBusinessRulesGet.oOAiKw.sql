/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Returns business rule information using the given criteria. If no  
criteria is specified, then info for all rules is returned. For example:  
  
    DECLARE @BusinessRuleTable mdm.Identifier  
    exec mdm.udpBusinessRulesAPIGet  
        @UserId=1,  
        @AttributeMuid=NULL,  
        @AttributeName=NULL,  
        @MemberType_ID=NULL,  
        @EntityMuid=NULL,  
        @EntityName=NULL,  
        @ModelMuid=NULL,  
        @ModelName=NULL,  
        @BusinessRuleTable=@BusinessRuleTable,  
        @ActionResultType=0,  
        @ConditionResultType=0,  
        @ConditionTreeNodeResultType=0,  
        @BusinessRulesResultType=2  
  
Returned tables:  
    BR_IDs  
    AuditInfo  
    Actions  
    Conditions  
    ConditionTreeNodes  
    BusinessRules  
    Arguments  
*/  
CREATE PROCEDURE mdm.udpBusinessRulesGet  
(  
    @UserId INT,    
    @AttributeMuid UNIQUEIDENTIFIER = NULL,    
    @AttributeName NVARCHAR(128) = NULL,    
    @MemberType_ID TINYINT = NULL, /*1 = Leaf, 2 = Consolidated */    
    @EntityMuid UNIQUEIDENTIFIER = NULL,    
    @EntityName NVARCHAR(MAX) = NULL,    
    @ModelMuid UNIQUEIDENTIFIER = NULL,    
    @ModelName NVARCHAR(50) = NULL,    
    @BusinessRuleTable mdm.Identifier READONLY,-- caller should ensure table does not include rows where both MUID and Name are blank    
    
    @ActionResultType INT = 0, /*0 = None, 1 = Identifiers, 2 = Details */    
    @ConditionResultType INT = 0,    
    @ConditionTreeNodeResultType INT = 0,    
    @BusinessRulesResultType INT = 0,    
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability    
)    
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN    
    SET NOCOUNT ON    
    
    DECLARE @PermissionType_Deny TINYINT = 1;    
    DECLARE @Model_ID            INT = NULL;    
    DECLARE @Entity_ID           INT = NULL;    
    DECLARE @Attribute_ID        INT = NULL;    
    DECLARE @EmptyMuid           UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER);    
    
    SET @ModelName  = NULLIF(@ModelName, N'');    
    SET @ModelMuid = NULLIF(@ModelMuid, @EmptyMuid);    
    SET @EntityName = NULLIF(@EntityName, N'');    
    SET @EntityMuid = NULLIF(@EntityMuid, @EmptyMuid);    
    SET @AttributeName = NULLIF(@AttributeName, N'');    
    SET @AttributeMuid = NULLIF(@AttributeMuid, @EmptyMuid);    
    
    -- lookup Model identifiers, if necessary    
    IF @ModelName IS NOT NULL OR @ModelMuid IS NOT NULL    
    BEGIN    
        SELECT @Model_ID  = m.ID    
        FROM mdm.tblModel m    
        INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_MODEL acl    
        ON m.ID = acl.ID    
            AND acl.User_ID = @UserId    
            AND acl.Privilege_ID <> 1 /*Deny*/    
        WHERE    
                (@ModelMuid IS NULL OR @ModelMuid = m.MUID)    
            AND (@ModelName IS NULL OR @ModelName = m.Name)    
    
        SET @Model_ID = COALESCE(@Model_ID, 0);    
    END    
    
    -- lookup Entity identifiers, if necessary    
    IF @EntityName IS NOT NULL OR @EntityMuid IS NOT NULL    
    BEGIN    
        SELECT    
             @Entity_ID  = e.ID    
            ,@Model_ID = COALESCE(@Model_ID, e.Model_ID) -- Ensure that the model ID param is set, if an entity is specified    
        FROM mdm.tblEntity e    
        INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ENTITY acl    
        ON      e.ID = acl.ID    
        WHERE   acl.User_ID = @UserId    
            AND acl.Privilege_ID <> @PermissionType_Deny    
            AND (@Model_ID IS NULL OR @Model_ID = e.Model_ID)    
            AND (@EntityMuid IS NULL OR @EntityMuid = e.MUID)    
            AND (@EntityName IS NULL OR @EntityName = e.Name);    
    
        SET @Entity_ID = COALESCE(@Entity_ID, 0);    
    END    
    
    -- lookup Attribute identifiers, if necessary    
    IF @AttributeName IS NOT NULL OR @AttributeMuid IS NOT NULL    
    BEGIN    
        SELECT TOP 1    
             @Attribute_ID  = a.ID    
            ,@AttributeName = a.Name    
            ,@AttributeMuid = a.MUID    
        FROM mdm.tblAttribute a    
        INNER JOIN mdm.tblEntity e    
        ON a.Entity_ID = e.ID    
        INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ATTRIBUTE acl    
        ON a.ID = acl.ID    
        WHERE acl.User_ID = @UserId    
            AND (@Entity_ID IS NULL OR @Entity_ID = a.Entity_ID)    
            AND (@MemberType_ID IS NULL OR @MemberType_ID = a.MemberType_ID)    
            AND (@Model_ID IS NULL OR @Model_ID = e.Model_ID)    
            AND (@AttributeMuid IS NULL OR @AttributeMuid = a.MUID)    
            AND (@AttributeName IS NULL OR @AttributeName = a.Name)    
        ORDER BY a.MemberType_ID;    
    
        SET @Attribute_ID = COALESCE(@Attribute_ID, 0);    
    END    
    
    DECLARE @ConditionId INT SET @ConditionId = 1;    
    DECLARE @ThenActionId INT SET @ThenActionId = 2;    
    DECLARE @ElseActionId INT SET @ElseActionId = 3;    
    
    -- result type values    
    DECLARE @Details INT SET @Details = 2;    
    DECLARE @IdentifiersOnly INT SET @IdentifiersOnly = 1;    
    DECLARE @None INT SET @None = 0;    
    
    -- Use the criteria vars to find the Ids of matching business rule(s).    
    -- Place these Ids in a table var for use in subsequent queries.    
    DECLARE @BR_Ids TABLE (    
        Id INT PRIMARY KEY CLUSTERED,    
        Muid UNIQUEIDENTIFIER UNIQUE NOT NULL,    
        [Name] NVARCHAR(100),    
        ModelId INT,    
        ModelMuid UNIQUEIDENTIFIER,    
        ModelName NVARCHAR(50),    
        EntityId INT,    
        EntityMuid UNIQUEIDENTIFIER,    
        EntityName NVARCHAR(MAX),    
        MemberType INT,    
        IsCorrupted BIT    
        );    
    
    INSERT INTO @BR_Ids    
    SELECT    
        DISTINCT    
        b.BusinessRule_ID Id,    
        b.BusinessRule_MUID Muid,    
        b.BusinessRule_Name [Name],    
        COALESCE(b.Model_ID, 0) ModelId,    
        b.Model_MUID ModelMuid,    
        b.Model_Name ModelName,    
        COALESCE(b.Entity_ID, 0) EntityId,    
        b.Entity_MUID EntityMuid,    
        b.Entity_Name EntityName,    
        COALESCE(b.MemberType_ID, 0) MemberType,    
        0    
    FROM    
        mdm.viw_SYSTEM_SECURITY_USER_MODEL acl    
    INNER JOIN    
        mdm.viw_SYSTEM_SCHEMA_BUSINESSRULES b    
        ON acl.ID = b.Model_ID    
        AND acl.User_ID = @UserId    
        AND acl.Privilege_ID <> 1 /*Deny*/    
        AND (@Entity_ID IS NULL OR b.Entity_ID = @Entity_ID)    
        AND (@Model_ID IS NULL OR b.Model_ID = @Model_ID)    
        AND (@MemberType_ID IS NULL OR b.MemberType_ID = @MemberType_ID)    
        AND acl.Privilege_ID <> @PermissionType_Deny -- read only users can view BRs    
    
    IF @Attribute_ID IS NOT NULL    
    BEGIN    
        -- remove rules that don't have arguments referencing the given attribute ID    
        DELETE FROM    
            @BR_Ids    
        WHERE    
            Id NOT IN    
                (SELECT DISTINCT BusinessRule_ID    
                 FROM mdm.viw_SYSTEM_SCHEMA_BUSINESSRULE_PROPERTIES_ATTRIBUTES    
                 WHERE Attribute_ID = @Attribute_ID)    
    END    
    
    IF EXISTS(SELECT 1 FROM @BusinessRuleTable)     
    BEGIN    
        -- remove rules that were not in the given list of rule MUIDs    
        DELETE FROM    
            @BR_Ids    
        WHERE    
            Muid NOT IN    
            (SELECT br.Muid    
             FROM @BR_Ids br    
            INNER JOIN @BusinessRuleTable crit    
            ON     
                ISNULL(crit.MUID, br.Muid) = br.Muid AND    
                ISNULL(crit.Name, br.Name) = br.Name)    
    END    
    
    -- get the BR IDs containing attributes that the user does not have privileges for    
    -- and remove them    
    ;WITH cteBRWithAttributeDeny AS    
    (    
        SELECT DISTINCT    
            a.BusinessRule_ID AS ID    
        FROM mdm.viw_SYSTEM_SCHEMA_BUSINESSRULE_PROPERTIES_ATTRIBUTES a    
        LEFT JOIN mdm.viw_SYSTEM_SECURITY_USER_ATTRIBUTE acl -- All attributes referenced by the rule must be in the same model, but they might have a different entity (in the case of DBAs) or member type (in the case of a hierarchy parent).    
        ON a.Attribute_ID = acl.ID    
            AND acl.User_ID = @UserId    
        WHERE acl.ID IS NULL    
    )    
    DELETE    
        br_id    
    FROM    
        @BR_Ids AS br_id    
    INNER JOIN    
        cteBRWithAttributeDeny acl    
    ON br_id.Id = acl.ID;    
    
    -- Load BRItems (Actions and Conditions) into a table var    
    DECLARE @BR_Items TABLE    
    (    
        Id INT,    
        Muid UNIQUEIDENTIFIER,    
        [Text] NVARCHAR(MAX),    
        RuleId INT,    
        ItemTypeId INT,    
        Sequence INT,    
        [Type] INT NOT NULL,    
        LogicalOperatorGroupId INT,    
        LogicalOperatorGroupMuid UNIQUEIDENTIFIER,    
        UserScriptName NVARCHAR(128),    
        UserScriptParameterCount INT,    
        IsCorrupted BIT,    
        IsUDS BIT    
    );    
    IF  @None <> @BusinessRulesResultType OR    
        @None <> @ActionResultType OR    
        @None <> @ConditionResultType OR    
        @None <> @ConditionTreeNodeResultType    
    BEGIN    
        INSERT INTO @BR_Items    
        SELECT    
            DISTINCT    
            it.ID Id,    
            it.MUID Muid,    
            it.ItemText [Text],    
            lo.BusinessRule_ID RuleId,    
            itat.BRItemType_ID ItemTypeId, -- operator    
            it.Sequence Sequence,    
            lr.Parent_ID [Type], -- 1 = Condition, 2 = ThenAction, 3 = ElseAction    
            lo.ID LogicalOperatorGroupId,    
            lo.MUID LogicalOperatorGroupMuid,    
            (CASE WHEN itat.BRItemType_ID = 34 THEN AnchorName ELSE NULL END) AS UserScriptName,    
            (CASE WHEN itat.BRItemType_ID = 34 AND AnchorName IS NOT NULL AND  mdm.udfScriptExists(AnchorName, CASE WHEN lr.Parent_ID = 1 THEN 1 ELSE 2 END,'usr') = 1 THEN (SELECT COUNT(*)    
            FROM sys.objects AS SO    
            INNER JOIN sys.parameters AS P    
            ON SO.object_id = P.object_id    
            WHERE P.is_output = 0    
            AND SO.object_id = ( SELECT object_id    
            FROM sys.objects    
            WHERE type = (CASE WHEN lr.Parent_ID = 1 THEN 'FN'ELSE 'P'END) AND SCHEMA_ID('usr') IS NOT NULL AND schema_id = SCHEMA_ID('usr') AND name = AnchorName)) ELSE -1 END),    
            0 AS IsCorrupted,    
            (CASE itat.BRItemType_ID WHEN 34 THEN 1 ELSE 0 END ) AS IsUDS    
        FROM    
            @BR_Ids i    
            INNER JOIN mdm.tblBRLogicalOperatorGroup lo    
                ON i.Id = lo.BusinessRule_ID    
            INNER JOIN mdm.tblBRItem it    
                ON lo.ID = it.BRLogicalOperatorGroup_ID    
            INNER JOIN mdm.tblBRItemTypeAppliesTo itat    
                ON it.BRItemAppliesTo_ID = itat.ID    
            INNER JOIN mdm.tblListRelationship lr    
                ON itat.ApplyTo_ID = lr.ID AND    
                   lr.Parent_ID IN (@ThenActionId, @ElseActionId, @ConditionId)    
            LEFT JOIN mdm.tblBRItemProperties anchorArg    
                ON anchorArg.BRItem_ID = it.ID AND    
                   anchorArg.IsLeftHandSide = 1 AND    
                   anchorArg.PropertyType_ID = 2 -- 2 = Attribute    
    
        ORDER BY lo.ID, it.Sequence    
    END    
    
    -- Validate BRItems    
    DECLARE @ScriptArgument NVARCHAR(MAX),    
            @ScriptName NVARCHAR(128),    
            @UDSBRItemId INT,    
            @IsUDSBRItemValid BIT,    
            @UDSBRItemType INT,    
            @IsSproc BIT,    
            @UDSBRId INT,    
            @Arguments mdm.ScriptArgument   
    DECLARE brItemCursor CURSOR FOR    
    SELECT  Id, UserScriptName, [Type], RuleId FROM @BR_Items WHERE IsUDS = 1;    
    OPEN brItemCursor;    
    FETCH NEXT FROM brItemCursor INTO @UDSBRItemId, @ScriptName , @UDSBRItemType, @UDSBRId    
    WHILE (@@FETCH_STATUS = 0)    
    BEGIN    
       DELETE FROM @Arguments  
       SET @IsSproc = (CASE  @UDSBRItemType WHEN @ConditionId THEN 0 ELSE 1 END)    
       INSERT INTO @Arguments    
       SELECT CONVERT(NVARCHAR(128),l.Value),    
        CASE WHEN r2.Value IS NULL THEN    
            ( CASE r1.PropertyType_ID    
            WHEN 6 THEN 3 -- BLANK    
            WHEN 2 THEN 2 -- ATTRIBUTE    
            WHEN 1 THEN 1 -- VALUE    
            ELSE 0 END)    
            ELSE    
            ( CASE r2.PropertyType_ID    
            WHEN 6 THEN 3 -- BLANK    
            WHEN 2 THEN 2 -- ATTRIBUTE    
            WHEN 1 THEN 1 -- VALUE    
            ELSE 0 END) END,    
       CASE WHEN r2.Value IS NULL THEN r1.Value ELSE r2.Value END,    
       ''    
       FROM mdm.tblBRItemProperties l    
       INNER JOIN mdm.tblBRItemProperties r1 ON r1.Parent_ID = l.ID    
       LEFT JOIN mdm.tblBRItemProperties r2 ON r2.Parent_ID = r1.ID    
       WHERE l.BRItem_ID = @UDSBRItemId AND l.PropertyType_ID = 8 --User Defined Script Parameter    
         
       EXEC [mdm].[udpValidateFunctionArguments] @ScriptName = @ScriptName, @IsSproc = @IsSproc, @Arguments = @Arguments,@ThrowException = 0, @BRID = @UDSBRItemId, @IsValid = @IsUDSBRItemValid OUT , @ScriptArguments = @ScriptArgument OUT    
       IF @IsUDSBRItemValid = 0    
       BEGIN    
             UPDATE @BR_Items    
             SET IsCorrupted = 1    
             WHERE Id = @UDSBRItemId    
    
             UPDATE @BR_Ids    
             SET IsCorrupted = 1    
             WHERE Id = @UDSBRId    
       END    
       FETCH NEXT FROM brItemCursor INTO @UDSBRItemId, @ScriptName , @UDSBRItemType, @UDSBRId    
    END -- END WHILE(@@FETCH_STATUS = 0)    
    CLOSE brItemCursor;    
    DEALLOCATE brItemCursor;    
    
    -- Load Arguments into a table var    
    DECLARE @BR_ItemArguments TABLE    
    (    
        Id INT PRIMARY KEY,    
        Muid UNIQUEIDENTIFIER UNIQUE,    
        ItemId INT,    
        ParentId INT,    
        [Value] NVARCHAR(999),    
        ValueMuid UNIQUEIDENTIFIER,    
        ValueName NVARCHAR(128),    
        PropertyType INT,    
        PropertyName INT,    
        IsLeftHandSide BIT,    
        [Sequence] INT,    
        AnchorAttributeDataType INT    
    );    
    IF  @None <> @BusinessRulesResultType OR    
        @None <> @ActionResultType OR    
        @None <> @ConditionResultType OR    
        @None <> @ConditionTreeNodeResultType    
    BEGIN    
        DECLARE @GetActions BIT SET @GetActions = 0    
        DECLARE @GetConditions BIT SET @GetConditions = 0    
        IF @ActionResultType <> @None OR @BusinessRulesResultType <> @None BEGIN    
            SET @GetActions = 1    
        END    
        IF @ConditionResultType <> @None OR @ConditionTreeNodeResultType <> @None OR @BusinessRulesResultType <> @None BEGIN    
            SET @GetConditions = 1    
        END    
        INSERT INTO @BR_ItemArguments    
        SELECT    
            ip.ID Id,    
            ip.MUID Muid,    
            ip.BRItem_ID ItemId,    
            COALESCE(ip.Parent_ID, 0) ParentId,    
            ip.Value [Value], -- freeform string, attributeId, hierarchyId, or member code (for attribute value arguments)    
            COALESCE(a.MUID, h.MUID) ValueMuid, -- attribute muid or hierarchy muid    
            COALESCE(a.Name, h.Name) ValueName, -- attribute name or hierarchy name    
            ip.PropertyType_ID PropertyType,    
            ip.PropertyName_ID PropertyName,    
            ip.IsLeftHandSide IsLeftHandSide,    
            ip.[Sequence] [Sequence],    
            anchorAttribute.DataType_ID AnchorAttributeDataType    
       FROM    
            mdm.tblBRItemProperties ip    
            INNER JOIN @BR_Items i    
                ON ip.BRItem_ID = i.Id AND    
                   ip.ID > 0 AND    
                    ((@GetActions    = 1 AND (i.Type = @ThenActionId OR i.Type = @ElseActionId)) OR    
                     (@GetConditions = 1 AND i.Type = @ConditionId))    
            LEFT JOIN mdm.tblAttribute a    
                ON ip.PropertyType_ID IN (2,4) AND -- Attribute = 2, DBAAttribute = 4    
                   ip.Value = CONVERT(nvarchar(50), a.ID)    
            LEFT JOIN mdm.tblHierarchy h    
                ON ip.PropertyType_ID = 3 AND -- ParentAttribute = 3    
                   ip.Value = CONVERT(nvarchar(50), h.ID)    
            LEFT JOIN mdm.tblBRItemProperties anchorArg    
                ON anchorArg.BRItem_ID = ip.BRItem_ID AND    
                   anchorArg.IsLeftHandSide = 1 AND    
                   anchorArg.PropertyType_ID = 2 -- 2 = Attribute    
            LEFT JOIN mdm.tblAttribute anchorAttribute    
                ON TRY_PARSE(anchorArg.Value AS INT) = anchorAttribute.ID    
       ORDER BY ip.BRItem_ID, ip.Sequence    
    END    
    
    -- Output 1, BR Id info    
    SELECT Id ,    
        Muid ,    
        [Name] ,    
        ModelId ,    
        ModelMuid ,    
        ModelName ,    
        EntityId ,    
        EntityMuid ,    
        EntityName ,    
        MemberType    
    FROM @BR_Ids    
    
    -- Output 2, BR Audit Info    
    IF @Details IN (@BusinessRulesResultType, @ActionResultType, @ConditionTreeNodeResultType, @ConditionResultType)    
    BEGIN    
        -- Details    
        SELECT    
            DISTINCT    
            b.BusinessRule_ID RuleId,    
            CONVERT(BIGINT, b.BusinessRule_LastChgTS) LastChgTS,    
            COALESCE(b.BusinessRule_CreatedUserID, 0) CreatedUserId,    
            b.BusinessRule_CreatedUserMUID CreatedUserMuid,    
            b.BusinessRule_CreatedUserName CreatedUserName,    
            b.BusinessRule_DateCreated CreatedDateTime,    
            COALESCE(b.BusinessRule_UpdatedUserID, 0) UpdatedUserId,    
            b.BusinessRule_UpdatedUserMUID UpdatedUserMuid,    
            b.BusinessRule_UpdatedUserName UpdatedUserName,    
            b.BusinessRule_DateUpdated UpdatedDateTime    
        FROM    
            @BR_Ids i    
            INNER JOIN    
            mdm.viw_SYSTEM_SCHEMA_BUSINESSRULES b    
                ON i.Id = b.BusinessRule_ID    
    END    
    ELSE    
    BEGIN    
        -- IDs Only or None    
        SELECT NULL WHERE 1=0;    
    END    
    
    -- Output 3, BusinessRules    
    IF @BusinessRulesResultType = @Details BEGIN    
        -- Details    
        SELECT    
            DISTINCT    
            b.BusinessRule_ID Id,    
            b.BusinessRule_Description [Description],    
            b.BusinessRule_RuleActionText RuleActionText,    
            b.BusinessRule_RuleElseActionText RuleElseActionText,    
            b.BusinessRule_RuleConditionText RuleConditionText,    
            COALESCE(b.BusinessRule_StatusID, 0) [Status],    
            COALESCE(b.BusinessRule_Priority, 0) Priority,    
            b.BusinessRule_NotificationGroupMUID NotificationGroup,    
            b.BusinessRule_NotificationUserMUID NotificationUser,    
            i.IsCorrupted    
        FROM    
            @BR_Ids i    
            INNER JOIN    
            mdm.viw_SYSTEM_SCHEMA_BUSINESSRULES b    
                ON i.Id = b.BusinessRule_ID    
    END ELSE IF @BusinessRulesResultType = @IdentifiersOnly BEGIN    
        -- IDs only    
        SELECT i.Id    
        FROM @BR_Ids i    
    END ELSE BEGIN    
        -- Nothing    
        SELECT NULL WHERE 1=0;    
    END    
    
    -- Output 4,Condition Tree Nodes    
    IF  @None <> @BusinessRulesResultType OR    
        @None <> @ConditionTreeNodeResultType    
    BEGIN    
         -- Details or IDs only    
        SELECT    
            DISTINCT    
            lo.ID Id,    
            lo.MUID Muid,    
            lo.BusinessRule_ID RuleId,    
            lop.ID ParentId,    
            lop.MUID ParentMuid,    
            lo.LogicalOperator_ID OperatorId,    
            lo.Sequence Sequence    
        FROM    
            mdm.tblBRLogicalOperatorGroup lo    
            INNER JOIN @BR_Ids br    
                ON lo.BusinessRule_ID = br.Id    
            LEFT JOIN mdm.tblBRItem it  -- left (not inner) join, because a condition operator group can be empty    
                ON lo.ID = it.BRLogicalOperatorGroup_ID    
            LEFT JOIN mdm.tblBRItemTypeAppliesTo itat    
                ON it.BRItemAppliesTo_ID = itat.ID    
            LEFT JOIN mdm.tblListRelationship lr    
                ON itat.ApplyTo_ID = lr.ID    
            LEFT JOIN mdm.tblBRLogicalOperatorGroup lop -- self join to get the parent group's MUID    
                ON lo.Parent_ID IS NOT NULL AND    
                   lo.Parent_ID = lop.ID    
            WHERE ISNULL(lr.Parent_ID, @ConditionId) = @ConditionId -- exclude action logical operator group    
        ORDER BY RuleId, ParentId, Sequence    
    END ELSE BEGIN    
        -- None    
        SELECT NULL WHERE 1=0;    
    END    
    
    -- Output 5, Actions    
    IF @Details IN (@BusinessRulesResultType, @ActionResultType) BEGIN    
        -- Details    
        SELECT    
            Id,    
            Muid,    
            RuleId,    
            [Type],    
            [Text],    
            ItemTypeId, -- operator    
            Sequence,    
            UserScriptName,    
            UserScriptParameterCount,    
            IsCorrupted    
        FROM @BR_Items    
        WHERE [Type] <> @ConditionId    
    END ELSE IF @IdentifiersOnly IN (@BusinessRulesResultType, @ActionResultType) BEGIN    
        -- IDs only    
        SELECT    
            Id,    
            Muid,    
            RuleId,    
            [Type]    
        FROM @BR_Items    
        WHERE [Type] <> @ConditionId    
    END ELSE BEGIN    
        -- None    
        SELECT NULL WHERE 1=0;    
    END    
    
    -- Output 6, Conditions    
    IF @Details IN (@BusinessRulesResultType, @ConditionResultType, @ConditionTreeNodeResultType) BEGIN    
        -- Details    
        SELECT    
            Id,    
            Muid,    
            RuleId,    
            LogicalOperatorGroupId,    
            LogicalOperatorGroupMuid,    
            [Text],    
            ItemTypeId, -- operator    
            Sequence,    
            UserScriptName,    
            UserScriptParameterCount,    
            IsCorrupted    
        FROM @BR_Items    
        WHERE [Type] = @ConditionId    
    END ELSE IF @IdentifiersOnly IN (@BusinessRulesResultType, @ConditionResultType, @ConditionTreeNodeResultType) BEGIN    
        -- IDs only    
        SELECT    
            Id,    
            Muid,    
            RuleId,    
            LogicalOperatorGroupId,    
            LogicalOperatorGroupMuid    
        FROM @BR_Items    
        WHERE [Type] = @ConditionId    
    END ELSE BEGIN    
        -- None    
        SELECT NULL WHERE 1=0;    
    END    
    
    -- Output 7, Arguments    
    IF @Details IN (@BusinessRulesResultType, @ActionResultType, @ConditionResultType, @ConditionTreeNodeResultType) BEGIN    
        -- Details    
        SELECT    
            Id,    
            Muid,    
            ItemId,    
            ParentId,    
            PropertyType,    
            PropertyName,    
            IsLeftHandSide,    
            [Value],    
            ValueMuid,    
            ValueName,    
            [Sequence],    
            AnchorAttributeDataType    
         FROM @BR_ItemArguments; -- Note: Ignore the "Microsoft.Design#SR0001" Code Analysis warning.    
    END    
    ELSE    
    IF @IdentifiersOnly IN (@BusinessRulesResultType, @ActionResultType, @ConditionResultType, @ConditionTreeNodeResultType) BEGIN    
        -- IDs only    
        SELECT    
            Id,    
            Muid,    
            ItemId,    
            ParentId,    
            PropertyType,    
            PropertyName ,    
            IsLeftHandSide    
        FROM @BR_ItemArguments;    
    END    
    ELSE    
    BEGIN    
        -- None    
        SELECT NULL WHERE 1=0;    
    END    
    
    SET NOCOUNT OFF    
END --proc
go

