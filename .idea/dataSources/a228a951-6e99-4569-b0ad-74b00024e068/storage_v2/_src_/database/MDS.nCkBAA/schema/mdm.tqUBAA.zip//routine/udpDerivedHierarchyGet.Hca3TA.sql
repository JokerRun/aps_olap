/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpDerivedHierarchyGet  
(  
     @User_ID       INT  
  
    ,@Model_MUID    UNIQUEIDENTIFIER = NULL  
    ,@Model_Name    NVARCHAR(50) = NULL  
    ,@Model_ID      INT = NULL -- set internally only  
  
    ,@HierarchyTable mdm.Identifier READONLY-- caller should ensure table does not include rows where both MUID and Name are blank  
  
    ,@ResultOption TINYINT -- None = 0, Identifiers = 1, Details = 2.   
   
    ,@IncludeParentIdentifiers  BIT = 1 -- Return results sets for parent Model and Entity identifiers. Set to 0 when getting attributes as part of a parent object (because the parent identifiers will already have been looked up).  
    ,@Debug                     BIT = 0  
    ,@CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
  
    SET NOCOUNT ON  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': begin udpDerivedHierarchyGet')  
  
    DECLARE   
         @ResultOption_Identifiers  TINYINT = 1  
        ,@ResultOption_Details      TINYINT = 2  
  
    -- Get model ID  
    IF @Model_ID IS NULL -- If the ID was already provided, don't bother looking it up again  
        AND (@Model_Name IS NOT NULL OR @Model_MUID IS NOT NULL)  
    BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': lookup @Model_ID')  
        SELECT   
             @Model_ID = ID  
            ,@Model_MUID = MUID  
            ,@Model_Name = Name  
        FROM mdm.tblModel  
        WHERE   MUID = ISNULL(@Model_MUID, MUID)  
            AND Name = ISNULL(@Model_Name, Name)  
  
        SET @Model_ID = COALESCE(@Model_ID, 0)  
    END  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': getting selected derived hierarchies from criteria')  
    DECLARE @SelectedHierarchy TABLE   
    (  
         ID                 INT PRIMARY KEY  
        ,Model_ID           INT  
        ,Privilege_ID       TINYINT  
        ,AccessPermission   TINYINT  
    )  
  
    INSERT INTO @SelectedHierarchy  
    SELECT  
         h.ID  
        ,h.Model_ID  
        ,acl.Privilege_ID  
        ,acl.AccessPermission  
    FROM mdm.tblDerivedHierarchy h  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_HIERARCHY_DERIVED acl  
    ON h.ID = acl.ID  
    WHERE   acl.User_ID = @User_ID  
        AND h.Model_ID = ISNULL(@Model_ID, h.Model_ID)  
  
    IF EXISTS(SELECT 1 FROM @HierarchyTable)  
    BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': removing rows that do not match the table filter')  
        -- Remove rows that don't match the filter  
        DELETE sh  
        FROM @SelectedHierarchy sh  
        INNER JOIN mdm.tblDerivedHierarchy h  
        ON sh.ID = h.ID  
        LEFT JOIN @HierarchyTable ht   
        ON      h.MUID = ISNULL(ht.MUID, h.MUID)  
            AND h.Name = ISNULL(ht.Name, h.Name)  
        WHERE (ht.MUID IS NULL AND ht.Name IS NULL)  
    END  
  
    IF @IncludeParentIdentifiers = 1  
    BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': returning parent identifiers')  
        -- Return model Identifier(s)  
        IF @Model_ID IS NOT NULL  
        BEGIN  
            IF @Model_Name IS NULL OR @Model_MUID IS NULL  
            BEGIN  
                SELECT   
                     @Model_MUID = MUID  
                    ,@Model_Name = Name  
                FROM mdm.tblModel  
                WHERE ID = @Model_ID  
            END  
  
            -- A single model was specified, and its info has already been looked up, so simply return it  
            SELECT   
                 @Model_MUID    AS Model_MUID  
                ,@Model_Name    AS Model_Name  
                ,@Model_ID      AS Model_ID  
        END ELSE  
        BEGIN  
            SELECT DISTINCT  
                 m.MUID AS Model_MUID  
                ,m.Name AS Model_Name  
                ,m.ID   AS Model_ID  
            FROM @SelectedHierarchy h  
            INNER JOIN mdm.tblModel m  
            ON h.Model_ID = m.ID  
        END  
    END  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': returning derived hierarchy info')  
    SELECT  
         h.Hierarchy_MUID  
        ,h.Hierarchy_Name  
        ,h.Hierarchy_ID  
        ,sh.Privilege_ID  
        ,sh.AccessPermission  
  
        ,sh.Model_ID  
        ,h.Hierarchy_AnchorNullRecursions AS AnchorNullRecursions  
  
        ,h.EnteredUser_DTM  
        ,h.EnteredUser_MUID  
        ,h.EnteredUser_UserName  
        ,h.EnteredUser_ID  
        ,h.LastChgUser_DTM  
        ,h.LastChgUser_MUID  
        ,h.LastChgUser_UserName  
        ,h.LastChgUser_ID  
    FROM @SelectedHierarchy sh  
    INNER JOIN mdm.viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED h  
    ON sh.ID = h.Hierarchy_ID  
    ORDER BY   
         h.Model_ID  
        ,h.Hierarchy_Name  
  
    IF @ResultOption = @ResultOption_Details  
    BEGIN  
        DECLARE @HierarchyLevelTable mdm.Identifier;  
        EXEC mdm.udpDerivedHierarchyLevelGet  
             @User_ID = @User_ID  
            ,@Model_ID = @Model_ID  
            ,@Model_MUID = @Model_MUID  
            ,@Model_Name = @Model_Name  
            ,@HierarchyTable = @HierarchyTable  
            ,@HierarchyLevelTable = @HierarchyLevelTable  
            ,@IncludeParentIdentifiers = 0 -- parent Ids already returned  
            ,@Debug = @Debug  
            ,@CorrelationID = @CorrelationID  
    END   
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': end udpDerivedHierarchyGet')  
  
    SET NOCOUNT OFF  
END --proc
go

