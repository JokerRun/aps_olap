/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
    SELECT * FROM mdm.viw_SYSTEM_SCHEMA_ATTRIBUTEGROUPS  
*/  
CREATE VIEW mdm.viw_SYSTEM_SCHEMA_ATTRIBUTEGROUPS  
/*WITH SCHEMABINDING*/  
AS  
WITH attributeGroupsCte AS  
(  
    SELECT  
        ag.ID,  
        ag.Name,  
        ag.MUID,  
        e.Model_ID      Model_ID,  
        m.Name          Model_Name,  
        m.MUID          Model_MUID,  
        ag.Entity_ID    Entity_ID,   
        e.Name          Entity_Name,   
        e.MUID          Entity_MUID,  
        ag.MemberType_ID,  
        CASE ag.MemberType_ID   
            WHEN 1 THEN N'Leaf'  
            WHEN 2 THEN N'Consolidated'  
            WHEN 3 THEN N'Collection'  
            WHEN 4 THEN N'Hierarchy'  
            WHEN 5 THEN N'CollectionMember'  
            ELSE N'' END             MemberType_Name,  
        ag.SortOrder,  
        ag.FreezeNameCode IsNameCodeFrozen,   
        ag.IsSystem,  
        ag.EnterUserID EnteredUser_ID,  
        usrE.MUID EnteredUser_MUID,  
        usrE.UserName EnteredUser_UserName,  
        ag.EnterDTM EnteredUser_DTM,  
        ag.LastChgUserID LastChgUser_ID,  
        usrL.MUID LastChgUser_MUID,  
        usrL.UserName LastChgUser_UserName,  
        ag.LastChgDTM LastChgUser_DTM  
    FROM mdm.tblModel m   
    INNER JOIN mdm.tblEntity e  
    ON m.ID = e.Model_ID  
    INNER JOIN mdm.tblAttributeGroup ag   
    ON e.ID = ag.Entity_ID  
    LEFT JOIN mdm.tblUser usrE   
    ON ag.EnterUserID = usrE.ID  
    LEFT JOIN mdm.tblUser usrL   
    ON ag.LastChgUserID = usrL.ID  
)  
SELECT   
    *,-- Usually it is best to not SELECT *, but in this case it is okay because we are selecting from the CTE whose columns are defined above.  
    CONCAT(QUOTENAME(Model_Name), N':', QUOTENAME(Entity_Name), N':', QUOTENAME(MemberType_Name), N':', QUOTENAME(Name)) FullName  
FROM attributeGroupsCte
go

