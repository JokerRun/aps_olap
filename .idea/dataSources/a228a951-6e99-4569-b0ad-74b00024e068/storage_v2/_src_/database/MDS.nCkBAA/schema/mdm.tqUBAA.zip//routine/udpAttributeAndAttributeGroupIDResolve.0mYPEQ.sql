/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
/*  
Resolves Attribute and AttributeGroup MUID and Name to ID.   
If ID is already provided, it is returned with no validation.  
If ID is NULL and MUID/Name match an ID, the ID is returned.  
If no matching ID is found for the given (MUID,Name) pair, ID is set to -1  
*/  
CREATE PROCEDURE [mdm].[udpAttributeAndAttributeGroupIDResolve]  
	@EntityID		INT,  
	@MemberTypeID	TINYINT,  
	@Attribute_MUID	UNIQUEIDENTIFIER = NULL,  
	@Attribute_Name	NVARCHAR(100) = NULL,  
	@AttributeGroup_MUID	UNIQUEIDENTIFIER = NULL,  
	@AttributeGroup_Name	NVARCHAR(50) = NULL,  
	@Attribute_ID	INT OUTPUT,	  
	@AttributeGroup_ID	INT OUTPUT	,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
AS BEGIN  
	DECLARE @Invalid_ID INT = -1  
  
	IF @Attribute_ID IS NULL  
		IF @Attribute_MUID IS NOT NULL OR @Attribute_Name IS NOT NULL  
		BEGIN  
			SELECT @Attribute_ID = ID FROM mdm.tblAttribute WHERE (MUID = ISNULL(@Attribute_MUID, MUID)) AND (Name = ISNULL(@Attribute_Name, Name))   
			AND (Entity_ID = ISNULL(@EntityID, Entity_ID)) AND (MemberType_ID = ISNULL(@MemberTypeID, MemberType_ID))  
  
			IF @Attribute_ID IS NULL  
			BEGIN		  
				SELECT @Attribute_ID = @Invalid_ID  
			END  
		END  
	  
	IF @AttributeGroup_ID IS NULL  
		IF @AttributeGroup_MUID IS NOT NULL OR @AttributeGroup_Name IS NOT NULL  
		BEGIN  
			SELECT @AttributeGroup_ID = ID FROM mdm.tblAttributeGroup WHERE (MUID = ISNULL(@AttributeGroup_MUID, MUID)) AND (Name = ISNULL(@AttributeGroup_Name, Name))   
				AND (Entity_ID = ISNULL(@EntityID, Entity_ID)) AND (MemberType_ID = ISNULL(@MemberTypeID, MemberType_ID))  
			IF @AttributeGroup_ID IS NULL		  
			BEGIN  
				SELECT @AttributeGroup_ID = @Invalid_ID  
			END  
		END  
END
go

