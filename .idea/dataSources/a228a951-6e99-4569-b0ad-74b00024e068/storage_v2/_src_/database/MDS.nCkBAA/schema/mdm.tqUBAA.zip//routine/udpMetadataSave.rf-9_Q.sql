/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpMetadataSave  
(  
    @User_ID                INT,  
    @Models                 mdm.Model READONLY,  
    @VersionFlags           mdm.VersionFlag READONLY,  
    @Entities               mdm.Entity READONLY,  
    @ExplicitHierarchies    mdm.ExplicitHierarchy READONLY,  
    @Attributes             mdm.Attribute READONLY,  
    @AttributeFilters       mdm.AttributeFilter READONLY,  
    @AttributeGroups        mdm.AttributeGroup READONLY,  
    @AttributeGroupDetails  mdm.AttributeGroupDetail READONLY,  
    @DerivedHierarchies     mdm.DerivedHierarchy READONLY,  
    @DerivedHierarchyLevels mdm.DerivedHierarchyLevel READONLY,  
    @Indexes                mdm.CustomIndex READONLY,  
    @IndexDetails           mdm.CustomIndexDetail READONLY,  
    @EditMode               TINYINT, --0: Create, 1: Update, 4: Clone  
    @CorrelationID          UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE  
         @FunctionalPrivilege_Versions  TINYINT = 2  
        ,@FunctionalPrivilege_SysAdmin  TINYINT = 5  
  
        ,@EditMode_Create   TINYINT = 0  
        ,@EditMode_Update   TINYINT = 1  
        ,@EditMode_Clone    TINYINT = 4  
  
        ,@HierarchyItemType_Entity              TINYINT = 0  
        ,@HierarchyItemType_DBA                 TINYINT = 1  
        ,@HierarchyItemType_Hierarchy           TINYINT = 2  
        ,@HierarchyItemType_ManyToMany          TINYINT = 5  
  
        ,@MemberType_Leaf           TINYINT = 1  
        ,@MemberType_Consolidated   TINYINT = 2  
        ,@MemberType_Collection     TINYINT = 3  
  
        ,@GuidEmpty  UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER)  
              
        ,@Model_ID      INT  
        ,@Model_MUID    UNIQUEIDENTIFIER  
        ,@ModelName     NVARCHAR(50)  
        ,@MaxVersion_ID INT  
        ,@Entity_ID     INT  
        ,@Entity_MUID   UNIQUEIDENTIFIER  
        ,@EntityName    NVARCHAR(50)  
        ,@MemberType_ID TINYINT  
             
        ,@Error NVARCHAR(MAX)  
        ,@Row_ID     INT  
        ,@VersionFlagsOnly BIT = CASE  
            WHEN        EXISTS (SELECT 1 FROM @VersionFlags)  
                AND NOT EXISTS (SELECT 1 FROM @Models)  
                AND NOT EXISTS (SELECT 1 FROM @Entities)  
                AND NOT EXISTS (SELECT 1 FROM @ExplicitHierarchies)  
                AND NOT EXISTS (SELECT 1 FROM @Attributes)  
                --AND NOT EXISTS (SELECT 1 FROM @AttributeFilters) -- No need to check. Checking @Attributes is sufficient  
                AND NOT EXISTS (SELECT 1 FROM @AttributeGroups)  
                --AND NOT EXISTS (SELECT 1 FROM @AttributeGroupDetails) -- No need to check. Checking @AttibuteGroups is sufficient  
                AND NOT EXISTS (SELECT 1 FROM @DerivedHierarchies)  
                AND NOT EXISTS (SELECT 1 FROM @DerivedHierarchyLevels)  
                AND NOT EXISTS (SELECT 1 FROM @Indexes)  
                --AND NOT EXISTS (SELECT 1 FROM @IndexDetails) -- No need to check. Checking @Indexes is sufficient  
            THEN 1 ELSE 0 END;  
  
    --If the user doesn't have sys admin or super user permission then they do not have permission to save metadata  
    IF mdm.udfSecurityUserFunctionIsAllowed(@User_ID, @FunctionalPrivilege_SysAdmin) = 0  
        AND (@VersionFlagsOnly = 0 -- can modify version flags with Versions functional privilege  
            OR mdm.udfSecurityUserFunctionIsAllowed(@User_ID, @FunctionalPrivilege_Versions) = 0)  
    BEGIN  
        RAISERROR('MDSERR120002|The user does not have permission to perform this operation.', 16, 1);  
        RETURN;  
    END  
  
    DECLARE @CreatedModels TABLE   
    (  
        ID INT,  
        MUID UNIQUEIDENTIFIER,  
        Name NVARCHAR(50) COLLATE DATABASE_DEFAULT  
    );  
  
    DECLARE @CreatedVersionFlags TABLE   
    (  
        ModelID INT,  
        ModelMUID UNIQUEIDENTIFIER,  
        ModelName NVARCHAR(50) COLLATE DATABASE_DEFAULT,  
        ID INT,  
        MUID UNIQUEIDENTIFIER,  
        Name NVARCHAR(50) COLLATE DATABASE_DEFAULT  
    );  
  
    DECLARE @CreatedEntities TABLE   
    (  
        ModelID INT,  
        ModelMUID UNIQUEIDENTIFIER,  
        ModelName NVARCHAR(50) COLLATE DATABASE_DEFAULT,  
        ID INT,  
        MUID UNIQUEIDENTIFIER,  
        Name NVARCHAR(50) COLLATE DATABASE_DEFAULT,  
        DidNameChange BIT  
    );  
  
    DECLARE @CreatedExplicitHierarchies TABLE   
    (  
        ModelID INT,  
        ModelMUID UNIQUEIDENTIFIER,  
        ModelName NVARCHAR(50) COLLATE DATABASE_DEFAULT,  
        EntityID INT,  
        EntityMUID UNIQUEIDENTIFIER,  
        EntityName NVARCHAR(50) COLLATE DATABASE_DEFAULT,  
        ID INT,  
        MUID UNIQUEIDENTIFIER,  
        Name NVARCHAR(50) COLLATE DATABASE_DEFAULT  
    );  
  
    DECLARE @CreatedIndexes TABLE   
    (  
        ModelID INT,  
        ModelMUID UNIQUEIDENTIFIER,  
        ModelName NVARCHAR(50) COLLATE DATABASE_DEFAULT,  
        EntityID INT,  
        EntityMUID UNIQUEIDENTIFIER,  
        EntityName NVARCHAR(50) COLLATE DATABASE_DEFAULT,  
        ID INT,  
        MUID UNIQUEIDENTIFIER,  
        Name NVARCHAR(50) COLLATE DATABASE_DEFAULT  
    );  
  
    DECLARE @CreatedAttributeGroups TABLE   
    (  
        Row_ID  INT PRIMARY KEY,  
        ModelID INT,  
        ModelMUID UNIQUEIDENTIFIER,  
        ModelName NVARCHAR(50) COLLATE DATABASE_DEFAULT,  
        Version_ID  INT, -- for audit info   
        EntityID INT,  
        EntityMUID UNIQUEIDENTIFIER,  
        EntityName NVARCHAR(50) COLLATE DATABASE_DEFAULT,  
        AttributeGroupMemberType TINYINT,  
        ID INT,  
        MUID UNIQUEIDENTIFIER,  
        Name NVARCHAR(50) COLLATE DATABASE_DEFAULT  
    );  
  
    DECLARE @CreatedDerivedHierarchies TABLE   
    (  
        ModelID INT,  
        ModelMUID UNIQUEIDENTIFIER,  
        ModelName NVARCHAR(50) COLLATE DATABASE_DEFAULT,  
        ID INT,  
        MUID UNIQUEIDENTIFIER,  
        Name NVARCHAR(50) COLLATE DATABASE_DEFAULT  
    );  
  
    DECLARE @CreatedDerivedHierarchyLevels TABLE   
    (  
        ModelID INT,  
        ModelMUID UNIQUEIDENTIFIER,  
        ModelName NVARCHAR(50) COLLATE DATABASE_DEFAULT,  
        DerivedHierarchyID INT,  
        DerivedHierarchyMUID UNIQUEIDENTIFIER,  
        DerivedHierarchyName NVARCHAR(50) COLLATE DATABASE_DEFAULT,  
        ID INT,  
        MUID UNIQUEIDENTIFIER,  
        Name NVARCHAR(100) COLLATE DATABASE_DEFAULT  
    );  
  
    --Start transaction, being careful to check if we are nested  
    DECLARE @TranCounter INT = @@TRANCOUNT;  
    IF @TranCounter > 0 SAVE TRANSACTION TX;  
    ELSE BEGIN TRANSACTION;  
  
    DECLARE @Lock INT;  
    BEGIN TRY  
  
        --Get a lock to prevent views from being regenerated until we are done updating all the metadata  
        --If a lock is not available right away give it 10 seconds  
        EXEC @Lock = sp_getapplock @Resource=N'DeferViewGeneration', @LockMode='Exclusive', @LockOwner='Session', @LockTimeout=10000;  
  
        --0 and 1 are acceptable return codes from sp_getapplock  
        IF @Lock NOT IN (0, 1)  
        BEGIN  
            RAISERROR(N'Unable to acquire Lock', 16, 1);  
            RETURN;  
        END  
  
        --BEGIN Model processing  
  
        DECLARE @ModelsToProcess TABLE  
        (  
            RowID               INT IDENTITY(1, 1) NOT NULL PRIMARY KEY,  
            Model_MUID          UNIQUEIDENTIFIER NULL,  
            ModelName           NVARCHAR(50) COLLATE DATABASE_DEFAULT NULL,  
            [Description]       NVARCHAR(500) COLLATE DATABASE_DEFAULT NULL,  
            LogRetentionDays    SMALLINT NULL  
        );  
  
        INSERT INTO @ModelsToProcess  
        (  
            Model_MUID,  
            ModelName,  
            [Description],  
            LogRetentionDays  
        )  
        SELECT  
            Model_MUID,  
            ModelName,  
            [Description],  
            LogRetentionDays  
        FROM @Models;  
  
        DECLARE @ModelDescription   NVARCHAR(500),  
                @LogRetentionDays   SMALLINT  
  
        WHILE EXISTS(SELECT 1 FROM @ModelsToProcess)  
        BEGIN  
            SELECT TOP 1  
                @Row_ID = RowID,  
                @Model_MUID = Model_MUID,  
                @ModelName = ModelName,  
                @ModelDescription = [Description],  
                @LogRetentionDays = LogRetentionDays  
            FROM @ModelsToProcess  
  
            PRINT CONCAT(SYSDATETIME(), N': Saving model ', @ModelName);  
            EXEC mdm.udpModelSave         
                @User_ID = @User_ID,  
                @Model_MUID = @Model_MUID,  
                @ModelName = @ModelName,  
                @Description = @ModelDescription,  
                @LogRetentionDays = @LogRetentionDays,  
                @EditMode = @EditMode,  
                @Return_ID = @Model_ID OUTPUT,  
                @Return_MUID = @Model_MUID OUTPUT,  
                @CorrelationID = @CorrelationID;  
  
            INSERT INTO @CreatedModels  (ID,        MUID,         Name)  
            VALUES                      (@Model_ID, @Model_MUID,  @ModelName);  
  
            DELETE @ModelsToProcess  
            WHERE RowID = @Row_ID;  
        END  
  
        --Output the created/updated models  
        SELECT ID, MUID, Name FROM @CreatedModels;  
  
        --END Model processing  
  
  
  
        -- Get models to which the user has access.  
        CREATE TABLE #UserModelAccess   
        (  
             ID                 INT PRIMARY KEY  
            ,Name               NVARCHAR(50) COLLATE DATABASE_DEFAULT NOT NULL   
            ,MUID               UNIQUEIDENTIFIER NOT NULL  
            ,IsAdministrator    BIT NOT NULL  
            ,MaxVersion_ID      INT NOT NULL -- Useful for tracking audit info  
        )  
        CREATE INDEX #ix_UserModelAccess_Name_MUID ON #UserModelAccess(Name, MUID); -- facilitates matching on model name and muid  
        INSERT INTO #UserModelAccess  
        SELECT  
             m.ID  
            ,m.Name  
            ,m.MUID  
            ,CASE sec.Privilege_ID WHEN 5 /*Admin*/ THEN 1 ELSE 0 END IsAdministrator  
            ,MAX(mv.ID) MaxVersion_ID  
        FROM mdm.tblModel m  
        INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_MODEL sec  
        ON m.ID = sec.ID     
        INNER JOIN mdm.tblModelVersion mv  
        ON m.ID = mv.Model_ID  
        WHERE   sec.User_ID = @User_ID   
            AND sec.Privilege_ID > 1/*Deny*/  
        GROUP BY m.ID, m.Name, m.MUID, sec.Privilege_ID  
  
        DECLARE @SyncTargetEntities TABLE  
        (  
            Entity_ID   INT PRIMARY KEY  
        )  
        INSERT INTO @SyncTargetEntities (Entity_ID)  
        SELECT DISTINCT TargetEntity_ID   
        FROM mdm.tblSyncRelationship  
  
        --BEGIN VersionFlag processing  
  
        DECLARE @VersionFlagsToProcess TABLE  
        (  
            RowID               INT IDENTITY(1, 1) NOT NULL PRIMARY KEY,  
            Model_ID            INT NULL,  
            Model_MUID          UNIQUEIDENTIFIER,  
            ModelName           NVARCHAR(50) COLLATE DATABASE_DEFAULT NULL,  
            VersionFlag_MUID    UNIQUEIDENTIFIER NULL,  
            VersionFlagName     NVARCHAR(50) COLLATE DATABASE_DEFAULT NULL,  
            [Description]       NVARCHAR(500) COLLATE DATABASE_DEFAULT NULL,  
            CommittedOnly_ID    BIT NULL,  
            Error               NVARCHAR(MAX) COLLATE DATABASE_DEFAULT NULL  
        );  
  
        INSERT INTO @VersionFlagsToProcess  
        (  
            Model_ID,  
            Model_MUID,  
            ModelName,  
            VersionFlag_MUID,  
            VersionFlagName,  
            [Description],  
            CommittedOnly_ID,  
            Error  
        )  
        SELECT  
            m.ID,  
            m.MUID,  
            m.Name,  
            vf.VersionFlag_MUID,  
            vf.VersionFlagName,  
            vf.[Description],  
            vf.CommittedOnly_ID,  
            CASE   
                WHEN m.ID IS NULL OR m.IsAdministrator = 0 THEN 'MDSERR200006|The version flag cannot be saved. The model ID is not valid.'  
                END  
        FROM @VersionFlags vf  
        -- Note: looking up model ids in a batch here is more efficient that doing it one row at a time in udpModelVersionFlagSave  
        LEFT JOIN #UserModelAccess m  
        ON      (vf.Model_MUID IS NOT NULL OR vf.ModelName IS NOT NULL)   
            AND (vf.Model_MUID IS NULL OR vf.Model_MUID = m.MUID)   
            AND (vf.ModelName  IS NULL OR vf.ModelName  = m.Name)  
  
        SELECT TOP 1 @Error = Error  
        FROM @VersionFlagsToProcess  
        WHERE Error IS NOT NULL;  
  
        IF @Error IS NOT NULL  
        BEGIN  
            SET @Error = REPLACE(@Error, '%', '%%')-- escape out format specifier  
            RAISERROR(@Error, 16, 1);  
        END  
  
        DECLARE   
            @VersionFlag_ID           INT,  
            @VersionFlag_MUID               UNIQUEIDENTIFIER,  
            @VersionFlagName                NVARCHAR(50),  
            @VersionFlagDescription         NVARCHAR(500),  
            @VersionFlagCommittedOnly_ID    BIT = NULL  
  
        WHILE EXISTS(SELECT 1 FROM @VersionFlagsToProcess)  
        BEGIN  
            SELECT  TOP 1  
                @Row_ID = RowID,  
                @Model_ID = Model_ID,  
                @Model_MUID = Model_MUID,  
                @ModelName = ModelName,  
                @VersionFlag_MUID = VersionFlag_MUID,  
                @VersionFlagName = VersionFlagName,  
                @VersionFlagDescription = [Description],  
                @VersionFlagCommittedOnly_ID = CommittedOnly_ID  
            FROM @VersionFlagsToProcess  
  
            PRINT CONCAT(SYSDATETIME(), N': Saving version flag ', @VersionFlagName);  
            EXEC mdm.udpModelVersionFlagSave  
                @User_ID = @User_ID,  
                @Model_ID = @Model_ID,  
                @MUID = @VersionFlag_MUID,  
                @Name = @VersionFlagName,  
                @Description = @VersionFlagDescription,  
                @Status_ID = 1,  
                @CommittedOnly_ID = @VersionFlagCommittedOnly_ID,  
                @EditMode = @EditMode,  
                @Return_ID = @VersionFlag_ID OUTPUT,  
                @Return_MUID = @VersionFlag_MUID OUTPUT, --Also an input parameter for clone operations  
                @CorrelationID = @CorrelationID;  
  
            INSERT INTO @CreatedVersionFlags  
            (  
                ModelID,  
                ModelMUID,  
                ModelName,  
                ID,  
                MUID,  
                Name  
            )  
            VALUES  
            (  
                @Model_ID,  
                @Model_MUID,  
                @ModelName,  
                @VersionFlag_ID,  
                @VersionFlag_MUID,  
                @VersionFlagName  
            )  
  
            DELETE @VersionFlagsToProcess  
            WHERE RowID = @Row_ID;  
        END  
  
        --Output created/updated version flags  
        SELECT ModelID, ModelMUID, ModelName, ID, MUID, Name FROM @CreatedVersionFlags;  
  
        --END VersionFlag processing  
  
  
  
        --BEGIN Entity processing  
  
        DECLARE @EntitiesToProcess TABLE  
        (  
            RowID               INT IDENTITY(1, 1) NOT NULL PRIMARY KEY,  
            Model_ID            INT NULL,  
            Model_MUID          UNIQUEIDENTIFIER NULL,  
            ModelName           NVARCHAR(50) COLLATE DATABASE_DEFAULT NULL,  
            Version_ID          INT NULL,  
            Entity_MUID         UNIQUEIDENTIFIER NULL,  
            EntityName          NVARCHAR(50) COLLATE DATABASE_DEFAULT NULL,  
            [Description]       NVARCHAR(500) COLLATE DATABASE_DEFAULT NULL,  
            IsBase              BIT NULL,  
            StagingBase         NVARCHAR(60) COLLATE DATABASE_DEFAULT DEFAULT N'',  
            CodeGenSeed         INT NULL,  
            DataCompression     TINYINT NULL,  
            TransactionLogType  TINYINT NULL,  
            RequireApproval     BIT NULL,  
            Error               NVARCHAR(MAX) COLLATE DATABASE_DEFAULT NULL  
        );  
  
        INSERT INTO @EntitiesToProcess  
        (  
            Model_ID,  
            Model_MUID,  
            ModelName,  
            Version_ID,  
            Entity_MUID,  
            EntityName,  
            [Description],  
            IsBase,  
            StagingBase,  
            CodeGenSeed,  
            DataCompression,  
            TransactionLogType,  
            RequireApproval,  
            Error  
        )  
        SELECT  
            m.ID,  
            m.MUID,  
            m.Name,  
            m.MaxVersion_ID,  
            e.Entity_MUID,  
            e.EntityName,  
            e.[Description],  
            e.IsBase,  
            e.StagingBase,  
            e.CodeGenSeed,  
            e.DataCompression,  
            e.TransactionLogType,  
            e.RequireApproval,  
            CASE   
                WHEN m.ID IS NULL           THEN N'MDSERR200002|The entity cannot be saved. The model ID is not valid.'  
                WHEN m.IsAdministrator = 0  THEN N'MDSERR120003|The user does not have permission or the object ID is not valid.'  
                END  
        FROM @Entities e  
        -- Note: looking up model ids in a batch here is more efficient that doing it one row at a time in udpEntitySave  
        LEFT JOIN #UserModelAccess m  
        ON      (e.Model_MUID IS NOT NULL OR e.ModelName IS NOT NULL)   
            AND (e.Model_MUID IS NULL OR e.Model_MUID = m.MUID)   
            AND (e.ModelName  IS NULL OR e.ModelName  = m.Name)  
  
        SELECT TOP 1 @Error = Error  
        FROM @EntitiesToProcess  
        WHERE Error IS NOT NULL;  
  
        IF @Error IS NOT NULL  
        BEGIN  
            SET @Error = REPLACE(@Error, '%', '%%')-- escape out format specifier  
            RAISERROR(@Error, 16, 1);  
        END  
  
        DECLARE   
            @EntityDescription          NVARCHAR(500),  
            @IsBase                     BIT,  
            @StagingBase                NVARCHAR(60),  
            @CodeGenSeed                INT,  
            @DataCompression            TINYINT,  
            @TransactionLogType         TINYINT,  
            @RequireApproval            BIT,  
            @RecreateStagingProc        BIT = CASE WHEN @EditMode = @EditMode_Create THEN 0 ELSE 1 END,-- defer creating the staging sprocs when in create mode  
            @EntityReturn_DidNameChange BIT --OUTPUT  
  
        WHILE EXISTS(SELECT 1 FROM @EntitiesToProcess)  
        BEGIN  
            SELECT TOP 1  
                @Row_ID = RowID,  
                @Model_ID = Model_ID,  
                @Model_MUID = Model_MUID,  
                @ModelName = ModelName,  
                @MaxVersion_ID = Version_ID,  
                @Entity_MUID = Entity_MUID,  
                @EntityName = EntityName,  
                @EntityDescription = [Description],  
                @IsBase = IsBase,  
                @StagingBase = StagingBase,  
                @CodeGenSeed = CodeGenSeed,  
                @DataCompression = DataCompression,  
                @TransactionLogType = TransactionLogType,  
                @RequireApproval = RequireApproval  
            FROM @EntitiesToProcess  
  
            PRINT CONCAT(SYSDATETIME(), N': Saving entity ', @EntityName);  
            EXEC mdm.udpEntitySave  
                @User_ID = @User_ID,  
                @Model_ID = @Model_ID,  
                @Version_ID = @MaxVersion_ID,  
                @Entity_MUID = @Entity_MUID,  
                @EntityName = @EntityName,  
                @Description = @EntityDescription,  
                @IsBase = @IsBase,  
                @StagingBase = @StagingBase,  
                @CodeGenSeed = @CodeGenSeed,  
                @EditMode = @EditMode,  
                @DataCompression = @DataCompression,  
                @TransactionLogType = @TransactionLogType,  
                @RequireApproval = @RequireApproval,  
                @RecreateStagingProc = @RecreateStagingProc,  
                @Return_DidNameChange = @EntityReturn_DidNameChange OUTPUT,  
                @Return_ID = @Entity_ID OUTPUT,  
                @Return_MUID = @Entity_MUID OUTPUT, --Also an input parameter for clone operations  
                @CorrelationID = @CorrelationID;  
  
            INSERT INTO @CreatedEntities  
            (  
                ModelID,  
                ModelMUID,  
                ModelName,  
                ID,  
                MUID,  
                Name,  
                DidNameChange  
            )  
            VALUES  
            (  
                @Model_ID,  
                @Model_MUID,  
                @ModelName,  
                @Entity_ID,  
                @Entity_MUID,  
                @EntityName,  
                @EntityReturn_DidNameChange  
            )  
  
            DELETE @EntitiesToProcess  
            WHERE RowID = @Row_ID;  
        END  
  
        --Output created/updated entities  
        SELECT ModelID, ModelMUID, ModelName, ID, MUID, Name, DidNameChange FROM @CreatedEntities;  
  
        --END Entity processing  
  
  
        --BEGIN Explicit hierarchy processing  
  
        DECLARE @ExplicitHierarchiesToProcess TABLE  
        (  
            RowID               INT IDENTITY(1, 1) NOT NULL PRIMARY KEY,  
            Model_ID            INT NULL,  
            Model_MUID          UNIQUEIDENTIFIER NULL,  
            ModelName           NVARCHAR(50) COLLATE DATABASE_DEFAULT NULL,  
            Version_ID          INT NULL,  
            Entity_ID           INT NULL,  
            Entity_MUID         UNIQUEIDENTIFIER NULL,  
            EntityName          NVARCHAR(50) COLLATE DATABASE_DEFAULT NULL,  
            Hierarchy_MUID      UNIQUEIDENTIFIER NULL,  
            HierarchyName       NVARCHAR(50) COLLATE DATABASE_DEFAULT NULL,  
            IsMandatory         BIT NULL,  
            Error               NVARCHAR(MAX) COLLATE DATABASE_DEFAULT NULL  
        );  
  
        INSERT INTO @ExplicitHierarchiesToProcess  
        (  
            Model_ID,  
            Model_MUID,  
            ModelName,  
            Version_ID,  
            Entity_ID,  
            Entity_MUID,  
            EntityName,  
            Hierarchy_MUID,  
            HierarchyName,  
            IsMandatory,  
            Error  
        )  
        SELECT  
            m.ID,  
            m.MUID,  
            m.Name,  
            m.MaxVersion_ID,  
            e.ID,  
            e.MUID,  
            e.Name,  
            eh.Hierarchy_MUID,  
            eh.HierarchyName,  
            eh.IsMandatory,  
            CASE   
                WHEN m.ID IS NULL                       THEN N'MDSERR200010|The explicit hierarchy cannot be saved. The model ID is not valid.'  
                WHEN m.IsAdministrator = 0              THEN N'MDSERR120003|The user does not have permission or the object ID is not valid.'  
                WHEN e.ID IS NULL                       THEN N'MDSERR200011|The explicit hierarchy cannot be saved. The entity ID is not valid.'  
                WHEN syncTarget.Entity_ID IS NOT NULL   THEN N'MDSERR200219|The explicit hierarchy cannot be saved. The entity is the target of a sync relationship.'  
                END  
        FROM @ExplicitHierarchies eh  
        -- Note: looking up model and entity ids in a batch here is more efficient that doing it one row at a time in udpEntityHierarchySave  
        LEFT JOIN #UserModelAccess m  
        ON      (eh.Model_MUID IS NOT NULL OR eh.ModelName IS NOT NULL)   
            AND (eh.Model_MUID IS NULL OR eh.Model_MUID = m.MUID)   
            AND (eh.ModelName  IS NULL OR eh.ModelName  = m.Name)  
        LEFT JOIN mdm.tblEntity e  
        ON      m.ID = e.Model_ID  
            AND (eh.Entity_MUID IS NOT NULL OR eh.EntityName IS NOT NULL)   
            AND (eh.Entity_MUID IS NULL OR eh.Entity_MUID = e.MUID)   
            AND (eh.EntityName  IS NULL OR eh.EntityName  = e.Name)  
        LEFT JOIN @SyncTargetEntities syncTarget  
        ON e.ID = syncTarget.Entity_ID  
  
        SELECT TOP 1 @Error = Error  
        FROM @ExplicitHierarchiesToProcess  
        WHERE Error IS NOT NULL;  
  
        IF @Error IS NOT NULL  
        BEGIN  
            SET @Error = REPLACE(@Error, '%', '%%')-- escape out format specifier  
            RAISERROR(@Error, 16, 1);  
        END  
  
        DECLARE   
            @ExplicitHierarchy_ID   INT,  
            @ExplicitHierarchy_MUID UNIQUEIDENTIFIER,  
            @ExplicitHierarchyName  NVARCHAR(50),  
            @IsMandatory            BIT  
  
        WHILE EXISTS(SELECT 1 FROM @ExplicitHierarchiesToProcess)  
        BEGIN  
            SELECT  TOP 1  
                @Row_ID = RowID,  
                @Model_ID = Model_ID,  
                @Model_MUID = Model_MUID,  
                @ModelName = ModelName,  
                @MaxVersion_ID = Version_ID,  
                @Entity_ID = Entity_ID,  
                @Entity_MUID = Entity_MUID,  
                @EntityName = EntityName,  
                @ExplicitHierarchy_MUID = Hierarchy_MUID,  
                @ExplicitHierarchyName = HierarchyName,  
                @IsMandatory = IsMandatory  
            FROM @ExplicitHierarchiesToProcess  
  
            PRINT CONCAT(SYSDATETIME(), N': Saving explicit hierarchy ', @ExplicitHierarchyName);  
            EXEC mdm.udpEntityHierarchySave  
                    @User_ID = @User_ID,  
                    @Model_ID = @Model_ID,  
                    @Version_ID = @MaxVersion_ID,  
                    @Entity_ID = @Entity_ID,  
                    @Hierarchy_MUID = @ExplicitHierarchy_MUID,  
                    @HierarchyName = @ExplicitHierarchyName,  
                    @IsMandatory = @IsMandatory,  
                    @EditMode = @EditMode,  
                    @RecreateLeafStagingProc = @RecreateStagingProc,  
                    @Return_ID = @ExplicitHierarchy_ID OUTPUT,  
                    @Return_MUID = @ExplicitHierarchy_MUID OUTPUT, --Also an input parameter for clone operations  
                    @CorrelationID = @CorrelationID;  
  
            INSERT INTO @CreatedExplicitHierarchies  
            (  
                ModelID,  
                ModelMUID,  
                ModelName,  
                EntityID,  
                EntityMUID,  
                EntityName,  
                ID,  
                MUID,  
                Name  
            )  
            VALUES  
            (  
                @Model_ID,  
                @Model_MUID,  
                @ModelName,  
                @Entity_ID,  
                @Entity_MUID,  
                @EntityName,  
                @ExplicitHierarchy_ID,  
                @ExplicitHierarchy_MUID,  
                @ExplicitHierarchyName  
            )  
  
            DELETE @ExplicitHierarchiesToProcess  
            WHERE RowID = @Row_ID;  
        END  
  
        --Output created/updated explicit hierarchies  
        SELECT ModelID, ModelMUID, ModelName, EntityID, EntityMUID, EntityName, ID, MUID, Name FROM @CreatedExplicitHierarchies;  
  
        --END Explicit hierarchy processing  
  
  
  
        --BEGIN Attribute processing  
  
        -- The schema of this table should match that defined in udpAttributeChange  
        CREATE TABLE #AttributesToProcess  
        (  
            Row_ID              INT NOT NULL PRIMARY KEY,  
            Model_ID            INT NULL,  
            Model_MUID          UNIQUEIDENTIFIER NULL,  
            ModelName           NVARCHAR(50) COLLATE DATABASE_DEFAULT NULL,  
            Version_ID          INT NULL,  
            Entity_ID           INT NULL,  
            Entity_MUID         UNIQUEIDENTIFIER NULL,  
            EntityName          NVARCHAR(50) COLLATE DATABASE_DEFAULT NULL,  
            IsHierarchyEnabled  BIT NULL,  
            IsCollectionEnabled BIT NULL,  
            DataCompression     TINYINT NULL,  
            TableName           SYSNAME NULL,  
            StagingTableName    SYSNAME NULL,  
            MemberType_ID       TINYINT NOT NULL,  
            ID                  INT NULL,  
            MUID                UNIQUEIDENTIFIER NULL,  
            Name                NVARCHAR(100) COLLATE DATABASE_DEFAULT NOT NULL,  
            [Description]       NVARCHAR(500) COLLATE DATABASE_DEFAULT NULL,  
            AttributeType_ID    TINYINT NULL,  
            DisplayName         NVARCHAR(250) COLLATE DATABASE_DEFAULT NULL,  
            DisplayWidth        INT NOT NULL,  
            DomainEntity_ID     INT NULL,  
            FilterParentAttribute_ID    INT NULL,  
            FilterHierarchyDetail_ID    INT NULL,  
            DataType_ID         TINYINT NULL,  
            DataTypeInformation INT NULL,  
            InputMask_ID        INT NULL,  
            ChangeTrackingGroup INT DEFAULT 0,  
            SortOrder           INT NULL,  
            DidNameChange       BIT NULL,  
            Error               NVARCHAR(MAX) COLLATE DATABASE_DEFAULT NULL  
        );  
  
        INSERT INTO #AttributesToProcess  
        (  
            Row_ID,  
            Model_ID,  
            Model_MUID,  
            ModelName,  
            Version_ID,  
            Entity_ID,  
            Entity_MUID,  
            EntityName,  
            IsHierarchyEnabled,  
            IsCollectionEnabled,  
            DataCompression,  
            TableName,  
            StagingTableName,  
            MemberType_ID,  
            MUID,  
            Name,  
            [Description],  
            AttributeType_ID,  
            DisplayName,  
            DisplayWidth,  
            DomainEntity_ID,  
            DataType_ID,  
            DataTypeInformation,  
            InputMask_ID,  
            ChangeTrackingGroup,  
            SortOrder,  
            Error  
        )  
        SELECT  
            a.Row_ID,  
            m.ID,  
            m.MUID,  
            m.Name,  
            m.MaxVersion_ID,  
            e.ID,  
            e.MUID,  
            e.Name,  
            CASE WHEN e.HierarchyParentTable IS NULL THEN 0 ELSE 1 END, -- IsHierarchyEnabled  
            CASE WHEN e.CollectionTable IS NULL THEN 0 ELSE 1 END, -- IsCollectionEnabled  
            e.DataCompression,  
            CASE a.MemberType_ID  
                    WHEN @MemberType_Leaf           THEN e.EntityTable  
                    WHEN @MemberType_Consolidated   THEN e.HierarchyParentTable  
                    WHEN @MemberType_Collection     THEN e.CollectionTable  
                    END, --TableName  
           CASE a.MemberType_ID  
                    WHEN @MemberType_Leaf           THEN e.StagingLeafName  
                    WHEN @MemberType_Consolidated   THEN e.StagingConsolidatedName  
                    WHEN @MemberType_Collection     THEN NULL  
                    END, -- StagingTableName  
            a.MemberType_ID,  
            a.Attribute_MUID,  
            a.AttributeName,  
            a.[Description],  
            a.AttributeType_ID,  
            a.DisplayName,  
            a.DisplayWidth,  
            domainEntity.ID,  
            a.DataType_ID,  
            a.DataTypeInformation,  
            im.OptionID, -- InputMask_ID  
            a.ChangeTrackingGroup,  
            a.SortOrder,  
            CASE   
                WHEN m.ID IS NULL                       THEN N'MDSERR200013|The attribute cannot be saved. The model ID is not valid.'  
                WHEN m.IsAdministrator = 0              THEN N'MDSERR120003|The user does not have permission or the object ID is not valid.'  
                WHEN e.ID IS NULL                       THEN N'MDSERR200014|The attribute cannot be saved. The entity ID is not valid.'  
                WHEN syncTarget.Entity_ID IS NOT NULL   THEN N'MDSERR200215|The attribute cannot be saved. The entity is the target of a sync relationship.'  
                WHEN    a.InputMask_Name IS NOT NULL   
                    AND im.OptionID IS NULL             THEN N'MDSERR200085|The attribute cannot be saved. The input mask is not valid.'  
                END  
        FROM @Attributes a  
        -- Note: looking up model ids and entity ids in a batch here is more efficient that doing it one row at a time in updAttributeSave  
        LEFT JOIN #UserModelAccess m  
        ON      (a.Model_MUID IS NOT NULL OR a.ModelName IS NOT NULL)   
            AND (a.Model_MUID IS NULL OR a.Model_MUID = m.MUID)   
            AND (a.ModelName  IS NULL OR a.ModelName  = m.Name)  
        LEFT JOIN mdm.tblEntity e  
        ON      m.ID = e.Model_ID  
            AND (a.Entity_MUID IS NOT NULL OR a.EntityName IS NOT NULL)  
            AND (a.Entity_MUID IS NULL OR a.Entity_MUID = e.MUID)  
            AND (a.EntityName  IS NULL OR a.EntityName  = e.Name)  
        LEFT JOIN mdm.tblEntity domainEntity  
        ON      m.ID = domainEntity.Model_ID  
            AND (a.DomainEntity_MUID IS NOT NULL OR a.DomainEntityName IS NOT NULL)  
            AND (a.DomainEntity_MUID IS NULL OR a.DomainEntity_MUID = domainEntity.MUID)  
            AND (a.DomainEntityName  IS NULL OR a.DomainEntityName  = domainEntity.Name)  
        LEFT JOIN @SyncTargetEntities syncTarget  
        ON e.ID = syncTarget.Entity_ID  
        LEFT JOIN mdm.tblList im  
        ON      im.ListCode = 'lstInputMask'  
            AND im.ListOption = a.InputMask_Name  
  
  
        IF @EditMode = @EditMode_Update  
        BEGIN  
            -- When in update mode, the filter parent attribute and hierarchy level should already exist, so no need to call udpAttributeSave twice. Do the ID lookups here.  
            EXEC mdm.udpMetadataSaveHelper_LookupAttributeFilterIds @AttributeFilters  
        END  
  
        SELECT TOP 1 @Error = Error  
        FROM #AttributesToProcess  
        WHERE Error IS NOT NULL;  
  
        IF @Error IS NOT NULL  
        BEGIN  
            SET @Error = REPLACE(@Error, '%', '%%')-- escape out format specifier  
            RAISERROR(@Error, 16, 1);  
        END  
  
        DECLARE   
            @IsHierarchyEnabled             BIT,  
            @IsCollectionEnabled            BIT,  
            @IsCollectionSupportAdded       BIT,  
            @TableName                      SYSNAME,  
            @StagingTableName               SYSNAME,  
            @Attribute_ID                   INT,  
            @Attribute_MUID                 UNIQUEIDENTIFIER,  
            @AttributeName                  NVARCHAR(100),  
            @AttributeDescription           NVARCHAR(500),  
            @AttributeType_ID               TINYINT,  
            @DisplayName                    NVARCHAR(250),  
            @DisplayWidth                   INT,  
            @DomainEntity_ID                INT,  
            @FilterParentAttribute_ID       INT,  
            @FilterHierarchyDetail_ID       INT,  
            @DataType_ID                    TINYINT,  
            @DataTypeInformation            INT,  
            @InputMask_ID                   INT,  
            @ChangeTrackingGroup            INT = 0,  
            @AttributeSortOrder             INT,  
            @AttributeReturn_DidNameChange  BIT --OUTPUT  
        SET @Row_ID = 0;  
  
        WHILE EXISTS(SELECT 1 FROM #AttributesToProcess WHERE Row_ID > @Row_ID)  
        BEGIN  
            SELECT TOP 1  
                @Row_ID = Row_ID,  
                @Model_ID = Model_ID,  
                @Model_MUID = Model_MUID,  
                @ModelName = ModelName,  
                @MaxVersion_ID = Version_ID,  
                @Entity_ID = Entity_ID,  
                @Entity_MUID = Entity_MUID,  
                @EntityName = EntityName,  
                @IsHierarchyEnabled = IsHierarchyEnabled,  
                @IsCollectionEnabled = IsCollectionEnabled,  
                @DataCompression = DataCompression,  
                @TableName = TableName,  
                @StagingTableName = StagingTableName,  
                @MemberType_ID = MemberType_ID,  
                @Attribute_MUID = MUID,  
                @AttributeName = Name,  
                @AttributeDescription = [Description],  
                @AttributeType_ID = AttributeType_ID,  
                @DisplayName = DisplayName,  
                @DisplayWidth = DisplayWidth,  
                @DomainEntity_ID = DomainEntity_ID,  
                @FilterParentAttribute_ID = FilterParentAttribute_ID,  
                @FilterHierarchyDetail_ID = FilterHierarchyDetail_ID,  
                @DataType_ID = DataType_ID,  
                @DataTypeInformation = DataTypeInformation,  
                @InputMask_ID = InputMask_ID,  
                @ChangeTrackingGroup = ChangeTrackingGroup,  
                @AttributeSortOrder = SortOrder  
            FROM #AttributesToProcess  
            WHERE Row_ID > @Row_ID  
            ORDER BY Row_ID  
  
            SET @IsCollectionSupportAdded = CASE WHEN @MemberType_ID = @MemberType_Collection AND @IsCollectionEnabled = 0 -- Creating the first collection attribute will cause the collection table to be created. Need to update the temp table with this info  
                THEN 1 ELSE 0 END  
  
            PRINT CONCAT(SYSDATETIME(), N': Saving attribute ', @AttributeName, ', MemberType ', @MemberType_ID);  
            EXEC mdm.udpAttributeSave  
                    @User_ID = @User_ID,  
                    @Model_ID = @Model_ID,  
                    @Version_ID = @MaxVersion_ID,  
                    @Entity_ID = @Entity_ID,  
                    @IsHierarchyEnabled = @IsHierarchyEnabled,  
                    @IsCollectionEnabled = @IsCollectionEnabled,  
                    @DataCompression = @DataCompression,  
                    @TableName = @TableName OUTPUT,  
                    @StagingTableName = @StagingTableName,  
                    @MemberType_ID = @MemberType_ID,  
                    @Attribute_MUID = @Attribute_MUID,  
                    @AttributeName = @AttributeName,  
                    @AttributeType_ID = @AttributeType_ID,  
                    @Description = @AttributeDescription,  
                    @DisplayName = @DisplayName,  
                    @DisplayWidth = @DisplayWidth,  
                    @DomainEntity_ID = @DomainEntity_ID,  
                    @FilterParentAttribute_ID = @FilterParentAttribute_ID,  
                    @FilterHierarchyDetail_ID = @FilterHierarchyDetail_ID,  
                    @DataType_ID = @DataType_ID,  
                    @DataTypeInformation = @DataTypeInformation,  
                    @InputMask_ID = @InputMask_ID,  
                    @ChangeTrackingGroup = @ChangeTrackingGroup,  
                    @SortOrder = @AttributeSortOrder OUTPUT,  
                    @EditMode = @EditMode,  
                    @RecreateStagingProc = 0, -- will create staging sprocs later  
                    @Return_DidNameChange = @AttributeReturn_DidNameChange OUTPUT,  
                    @Return_ID = @Attribute_ID OUTPUT,  
                    @Return_MUID = @Attribute_MUID OUTPUT, --Also an input parameter for clone operations  
                    @CorrelationID = @CorrelationID;  
  
            UPDATE #AttributesToProcess  
            SET  ID = @Attribute_ID -- save the ID for later use in adding attribute filters  
                ,MUID = @Attribute_MUID  
                ,DidNameChange = @AttributeReturn_DidNameChange  
                ,SortOrder = @AttributeSortOrder  
            WHERE Row_ID = @Row_ID;  
  
            IF @IsCollectionSupportAdded = 1  
            BEGIN  
                UPDATE #AttributesToProcess  
                SET  
                     IsCollectionEnabled = 1  
                    ,TableName = CASE MemberType_ID WHEN @MemberType_Collection THEN @TableName ELSE TableName/*Leave column unchanged*/ END  
                WHERE Entity_ID = @Entity_ID  
            END  
  
        END  
  
        --Output updated/created attribute information  
        SELECT Model_ID AS ModelID, Model_MUID AS ModelMUID, ModelName, Entity_ID AS EntityID, Entity_MUID AS EntityMUID, EntityName, MemberType_ID AS AttributeMemberType, ID, MUID, Name, DidNameChange FROM #AttributesToProcess;  
  
        --END Attribute processing  
  
  
        --BEGIN AttributeGroup processing  
  
        DECLARE @AttributeGroupsToProcess TABLE  
        (  
            Row_ID              INT NOT NULL PRIMARY KEY,  
            Model_ID            INT NULL,  
            Model_MUID          UNIQUEIDENTIFIER NULL,  
            ModelName           NVARCHAR(50) COLLATE DATABASE_DEFAULT NULL,  
            Version_ID          INT NULL,  
            Entity_ID           INT NULL,  
            Entity_MUID         UNIQUEIDENTIFIER NULL,  
            EntityName          NVARCHAR(50) COLLATE DATABASE_DEFAULT NULL,  
            IsHierarchyEnabled  BIT NULL,  
            IsCollectionEnabled BIT NULL,  
            DataCompression     TINYINT NULL,  
            MemberType_ID       TINYINT NOT NULL,  
            MUID                UNIQUEIDENTIFIER NULL,  
            Name                NVARCHAR(50) COLLATE DATABASE_DEFAULT NOT NULL,  
            SortOrder           INT NULL,  
            FreezeNameCode      BIT DEFAULT 0,  
            IsSystem            BIT DEFAULT 0,  
            Error               NVARCHAR(MAX) COLLATE DATABASE_DEFAULT NULL  
        );  
  
        INSERT INTO @AttributeGroupsToProcess  
        (  
            Row_ID,  
            Model_ID,  
            Model_MUID,  
            ModelName,  
            Version_ID,  
            Entity_ID,  
            Entity_MUID,  
            EntityName,  
            IsHierarchyEnabled,  
            IsCollectionEnabled,  
            DataCompression,  
            MemberType_ID,  
            MUID,  
            Name,  
            SortOrder,  
            FreezeNameCode,  
            IsSystem,   
            Error  
        )  
        SELECT  
            ag.Row_ID,  
            m.ID,  
            m.MUID,  
            m.Name,  
            m.MaxVersion_ID,  
            e.ID,  
            e.MUID,  
            e.Name,  
            CASE WHEN e.HierarchyParentTable IS NULL THEN 0 ELSE 1 END, -- IsHierarchyEnabled  
            CASE WHEN e.CollectionTable IS NULL THEN 0 ELSE 1 END, -- IsCollectionEnabled  
            e.DataCompression,  
            ag.MemberType_ID,  
            ag.MUID,  
            ag.Name,  
            ag.SortOrder,  
            ag.FreezeNameCode,  
            ag.IsSystem,  
            CASE   
                WHEN m.ID IS NULL                       THEN N'MDSERR200017|The attribute group cannot be saved. The model ID is not valid.'  
                WHEN m.IsAdministrator = 0              THEN N'MDSERR120003|The user does not have permission or the object ID is not valid.'  
                WHEN e.ID IS NULL                       THEN N'MDSERR200018|The attribute group cannot be saved. The entity ID is not valid.'  
                WHEN syncTarget.Entity_ID IS NOT NULL   THEN N'MDSERR200214|The attribute group cannot be saved. The entity is the target of a sync relationship.'  
                WHEN ag.MemberType_ID IS NULL           THEN N'MDSERR200020|The attribute group cannot be saved. The member type is not valid.'  
                END  
        FROM @AttributeGroups ag  
        -- Note: looking up model ids and entity ids in a batch here is more efficient that doing it one row at a time in updAttributeGroupSave  
        LEFT JOIN #UserModelAccess m  
        ON      (ag.Model_MUID IS NOT NULL OR ag.ModelName IS NOT NULL)   
            AND (ag.Model_MUID IS NULL OR ag.Model_MUID = m.MUID)   
            AND (ag.ModelName  IS NULL OR ag.ModelName  = m.Name)  
        LEFT JOIN mdm.tblEntity e  
        ON      m.ID = e.Model_ID  
            AND (ag.Entity_MUID IS NOT NULL OR ag.EntityName IS NOT NULL)  
            AND (ag.Entity_MUID IS NULL OR ag.Entity_MUID = e.MUID)  
            AND (ag.EntityName  IS NULL OR ag.EntityName  = e.Name)  
        LEFT JOIN @SyncTargetEntities syncTarget  
        ON e.ID = syncTarget.Entity_ID  
  
        SELECT TOP 1 @Error = Error  
        FROM @AttributeGroupsToProcess  
        WHERE Error IS NOT NULL;  
  
        IF @Error IS NOT NULL  
        BEGIN  
            SET @Error = REPLACE(@Error, '%', '%%')-- escape out format specifier  
            RAISERROR(@Error, 16, 1);  
        END  
  
        DECLARE   
            @AttributeGroup_ID              INT,  
            @AttributeGroup_MUID            UNIQUEIDENTIFIER,  
            @AttributeGroupName             NVARCHAR(50),  
            @AttributeGroupSortOrder        INT,  
            @FreezeNameCode                 BIT = 0,  
            @AttributeGroupIsSystem         BIT = 0  
  
        WHILE EXISTS(SELECT 1 FROM @AttributeGroupsToProcess)  
        BEGIN  
            SELECT TOP 1  
                @Row_ID = Row_ID,  
                @Model_ID = Model_ID,  
                @Model_MUID = Model_MUID,  
                @ModelName = ModelName,  
                @MaxVersion_ID = Version_ID,  
                @Entity_ID = Entity_ID,  
                @Entity_MUID = Entity_MUID,  
                @EntityName = EntityName,  
                @IsHierarchyEnabled = IsHierarchyEnabled,  
                @IsCollectionEnabled = IsCollectionEnabled,  
                @DataCompression = DataCompression,  
                @MemberType_ID = MemberType_ID,  
                @AttributeGroup_MUID = MUID,  
                @AttributeGroupName = Name,  
                @AttributeGroupSortOrder = SortOrder,  
                @FreezeNameCode = FreezeNameCode,  
                @AttributeGroupIsSystem = IsSystem  
            FROM @AttributeGroupsToProcess  
  
            SET @IsCollectionSupportAdded = CASE WHEN @MemberType_ID = @MemberType_Collection AND @IsCollectionEnabled = 0 -- Creating the first collection attribute group will cause the collection tables to be created. Need to update the temp table with this info  
                THEN 1 ELSE 0 END  
  
            PRINT CONCAT(SYSDATETIME(), N': Saving attribute group ', @EntityName, N'.', @AttributeGroupName);  
            EXEC mdm.udpAttributeGroupSave  
                    @User_ID = @User_ID,  
                    @Model_ID = @Model_ID,  
                    @Version_ID = @MaxVersion_ID,  
                    @Entity_ID = @Entity_ID,  
                    @IsHierarchyEnabled = @IsHierarchyEnabled,  
                    @IsCollectionEnabled = @IsCollectionEnabled,  
                    @DataCompression = @DataCompression,  
                    @MemberType_ID = @MemberType_ID,  
                    @MUID = @AttributeGroup_MUID,  
                    @Name = @AttributeGroupName,  
                    @SortOrder = @AttributeGroupSortOrder,  
                    @FreezeNameCode = @FreezeNameCode,  
                    @IsSystem = @AttributeGroupIsSystem,  
                    @EditMode = @EditMode,  
                    @Return_ID = @AttributeGroup_ID OUTPUT,  
                    @Return_MUID = @AttributeGroup_MUID OUTPUT,  
                    @CorrelationID = @CorrelationID;  
  
            INSERT INTO @CreatedAttributeGroups  
            (  
                Row_ID,  
                ModelID,  
                ModelMUID,  
                ModelName,  
                Version_ID,  
                EntityID,  
                EntityMUID,  
                EntityName,  
                AttributeGroupMemberType,  
                ID,  
                MUID,  
                Name  
            )  
            VALUES  
            (  
                @Row_ID,  
                @Model_ID,  
                @Model_MUID,  
                @ModelName,  
                @MaxVersion_ID,  
                @Entity_ID,  
                @Entity_MUID,  
                @EntityName,  
                @MemberType_ID,  
                @AttributeGroup_ID,  
                @AttributeGroup_MUID,  
                @AttributeGroupName  
            )  
  
            DELETE @AttributeGroupsToProcess  
            WHERE Row_ID = @Row_ID;  
  
            IF @IsCollectionSupportAdded = 1  
            BEGIN  
                UPDATE @AttributeGroupsToProcess  
                SET IsCollectionEnabled = 1  
                WHERE   Entity_ID = @Entity_ID  
            END  
        END  
  
        --Output created/updated attribute groups  
        SELECT ModelID, ModelMUID, ModelName, EntityID, EntityMUID, EntityName, AttributeGroupMemberType, ID, MUID, Name FROM @CreatedAttributeGroups;  
  
        --END AttributeGroup processing  
  
  
  
        --BEGIN AttributeGroupDetail processing  
  
        DECLARE @AttributeGroupDetailsToProcess TABLE  
        (  
            RowID               INT IDENTITY(1, 1) NOT NULL PRIMARY KEY,  
            Version_ID          INT NULL,  
            AttributeGroup_ID   INT NULL,  
            Attribute_ID        INT NULL,  
            Error               NVARCHAR(MAX) COLLATE DATABASE_DEFAULT NULL  
        );  
  
        --We are going to rely on the fact that the attribute group that owns these details was also supplied to the SPROC for  
        --create/update. That is a reasonable assumption since the API wraps the details the AttributeGroup contract  
        INSERT INTO @AttributeGroupDetailsToProcess  
        (  
            Version_ID,  
            AttributeGroup_ID,  
            Attribute_ID,  
            Error  
        )  
        SELECT  
            ag.Version_ID,  
            ag.ID,  
            a.ID,  
            CASE  
                WHEN a.ID IS NULL   THEN N'MDSERR110007|The ID is not valid.'  
                END  
        FROM @AttributeGroupDetails agd  
        INNER JOIN @CreatedAttributeGroups ag  
        ON agd.AttributeGroupRow_ID = ag.Row_ID  
        INNER JOIN mdm.tblAttribute a  
        ON      ag.EntityID = a.Entity_ID  
            AND ag.AttributeGroupMemberType = a.MemberType_ID  
            AND (agd.MUID IS NOT NULL OR agd.Name IS NOT NULL)  
            AND (agd.MUID IS NULL OR agd.MUID = a.MUID)  
            AND (agd.Name IS NULL OR agd.Name = a.Name)  
  
        SELECT TOP 1 @Error = Error  
        FROM @AttributeGroupDetailsToProcess  
        WHERE Error IS NOT NULL;  
  
        IF @Error IS NOT NULL  
        BEGIN  
            SET @Error = REPLACE(@Error, '%', '%%')-- escape out format specifier  
            RAISERROR(@Error, 16, 1);  
        END  
  
        --Drop all attributes from the passed attribute groups   
        DECLARE @AttributeGroupsToClear TABLE (ID INT PRIMARY KEY);  
        INSERT INTO @AttributeGroupsToClear (ID)    
        SELECT ID FROM @CreatedAttributeGroups    
   
        IF(@EditMode <> @EditMode_Create)  
        BEGIN  
            WHILE EXISTS(SELECT 1 FROM @AttributeGroupsToClear)    
            BEGIN    
                SELECT TOP 1    
                    @AttributeGroup_ID = ID    
                FROM @AttributeGroupsToClear    
    
                EXEC mdm.udpAttributeGroupDetailDelete    
                        @User_ID = @User_ID,    
                        @AttributeGroup_ID = @AttributeGroup_ID,    
                        @Type_ID = 1,    
                        @CorrelationID = @CorrelationID;    
    
                DELETE @AttributeGroupsToClear    
                WHERE ID = @AttributeGroup_ID    
            END    
        END  
  
        -- Add the attribute group details  
        WHILE EXISTS(SELECT 1 FROM @AttributeGroupDetailsToProcess)  
        BEGIN  
            SELECT TOP 1  
                @Row_ID = RowID,  
                @MaxVersion_ID = Version_ID,  
                @AttributeGroup_ID = AttributeGroup_ID,  
                @Attribute_ID = Attribute_ID  
            FROM @AttributeGroupDetailsToProcess  
  
            PRINT CONCAT(SYSDATETIME(), N': Adding attribute to attribute group ', @AttributeGroupName);  
            EXEC mdm.udpAttributeGroupDetailSave  
                    @User_ID = @User_ID,  
                    @Version_ID = @MaxVersion_ID,  
                    @AttributeGroup_ID = @AttributeGroup_ID,  
                    @Attribute_ID = @Attribute_ID,  
                    @CorrelationID = @CorrelationID;  
  
            DELETE @AttributeGroupDetailsToProcess  
            WHERE RowID = @Row_ID;  
        END  
  
        --END AttributeGroupDetail processing  
  
  
  
        --BEGIN Derived hierarchy processing  
  
        DECLARE @DerivedHierarchiesToProcess TABLE  
        (  
            RowID                   INT IDENTITY(1, 1) NOT NULL PRIMARY KEY,  
            Model_ID                INT NULL,  
            Model_MUID              UNIQUEIDENTIFIER NULL,  
            ModelName               NVARCHAR(50) COLLATE DATABASE_DEFAULT NULL,  
            Version_ID              INT NULL,  
            MUID                    UNIQUEIDENTIFIER NULL,  
            Name                    NVARCHAR(50) COLLATE DATABASE_DEFAULT NULL,  
            AnchorNullRecursions    BIT DEFAULT 1,  
            Error                   NVARCHAR(MAX) COLLATE DATABASE_DEFAULT NULL  
        );  
  
        INSERT INTO @DerivedHierarchiesToProcess  
        (  
            Model_ID,  
            Model_MUID,  
            ModelName,  
            Version_ID,  
            MUID,  
            Name,  
            AnchorNullRecursions,  
            Error  
        )  
        SELECT  
            m.ID,  
            m.MUID,  
            m.Name,  
            m.MaxVersion_ID,  
            dh.MUID,  
            dh.Name,  
            dh.AnchorNullRecursions,  
            CASE  
                WHEN m.ID IS NULL           THEN N'MDSERR200008|The derived hierarchy cannot be saved. The model ID is not valid.'  
                WHEN m.IsAdministrator = 0  THEN N'MDSERR120003|The user does not have permission or the object ID is not valid.'  
                END  
        FROM @DerivedHierarchies dh  
        -- Note: looking up model ids in a batch here is more efficient that doing it one row at a time in udpDerivedHierarchySave  
        LEFT JOIN #UserModelAccess m  
        ON      (dh.Model_MUID IS NOT NULL OR dh.ModelName IS NOT NULL)   
            AND (dh.Model_MUID IS NULL OR dh.Model_MUID = m.MUID)   
            AND (dh.ModelName  IS NULL OR dh.ModelName  = m.Name)  
  
        SELECT TOP 1 @Error = Error  
        FROM @DerivedHierarchiesToProcess  
        WHERE Error IS NOT NULL;  
  
        IF @Error IS NOT NULL  
        BEGIN  
            SET @Error = REPLACE(@Error, '%', '%%')-- escape out format specifier  
            RAISERROR(@Error, 16, 1);  
        END  
  
        DECLARE   
            @DerivedHierarchy_ID                    INT,  
            @DerivedHierarchy_MUID                  UNIQUEIDENTIFIER,  
            @DerivedHierarchyName                   NVARCHAR(50),  
            @DerivedHierarchyAnchorNullRecursions   BIT = 1;  
  
        WHILE EXISTS(SELECT * FROM @DerivedHierarchiesToProcess)  
        BEGIN  
            SELECT TOP 1  
                @Row_ID = RowID,  
                @Model_ID = Model_ID,  
                @Model_MUID = Model_MUID,  
                @ModelName = ModelName,  
                @MaxVersion_ID = Version_ID,  
                @DerivedHierarchy_MUID = MUID,  
                @DerivedHierarchyName = Name,  
                @DerivedHierarchyAnchorNullRecursions = AnchorNullRecursions  
            FROM @DerivedHierarchiesToProcess  
  
            PRINT CONCAT(SYSDATETIME(), N': Saving derived hierarchy ', @DerivedHierarchyName);  
            EXEC mdm.udpDerivedHierarchySave  
                    @User_ID = @User_ID,  
                    @Model_ID = @Model_ID,  
                    @Version_ID = @MaxVersion_ID,  
                    @MUID = @DerivedHierarchy_MUID,  
                    @Name = @DerivedHierarchyName,  
                    @AnchorNullRecursions = @DerivedHierarchyAnchorNullRecursions,  
                    @EditMode = @EditMode,  
                    @Return_ID = @DerivedHierarchy_ID OUTPUT,  
                    @Return_MUID = @DerivedHierarchy_MUID OUTPUT,  
                    @CorrelationID = @CorrelationID;  
  
            INSERT INTO @CreatedDerivedHierarchies  
            (  
                ModelID,  
                ModelMUID,  
                ModelName,  
                ID,  
                MUID,  
                Name  
            )  
            VALUES  
            (  
                @Model_ID,  
                @Model_MUID,  
                @ModelName,  
                @DerivedHierarchy_ID,  
                @DerivedHierarchy_MUID,  
                @DerivedHierarchyName  
            )  
  
            DELETE @DerivedHierarchiesToProcess  
            WHERE RowID = @Row_ID;  
        END  
  
        --Output updated/created derived hierarchies  
        SELECT ModelID, ModelMUID, ModelName, ID, MUID, Name FROM @CreatedDerivedHierarchies;  
  
        --END Derived hierarchy processing  
  
  
  
        --BEGIN Derived hierarchy level processing  
  
        DECLARE @DerivedHierarchyLevelsToProcess TABLE  
        (  
            RowID                   INT IDENTITY(1, 1) NOT NULL PRIMARY KEY,  
            Model_ID                INT NULL,  
            Model_MUID              UNIQUEIDENTIFIER NULL,  
            ModelName               NVARCHAR(50) COLLATE DATABASE_DEFAULT NULL,  
            Version_ID              INT NULL,  
            DerivedHierarchy_ID     INT NULL,  
            DerivedHierarchy_MUID   UNIQUEIDENTIFIER NULL,  
            DerivedHierarchyName    NVARCHAR(50) COLLATE DATABASE_DEFAULT NULL,  
            MUID                    UNIQUEIDENTIFIER NULL,  
            Name                    NVARCHAR(100) COLLATE DATABASE_DEFAULT NOT NULL,  
            Foreign_ID              INT NULL,  
            ForeignType_ID          TINYINT NOT NULL,  
            ManyToManyChildAttribute_ID INT NULL,  
            DisplayName             NVARCHAR(100) COLLATE DATABASE_DEFAULT NOT NULL,  
            IsVisible               BIT NOT NULL,  
            IsMemberSecurityApplied BIT NOT NULL,  
            Error                   NVARCHAR(MAX) COLLATE DATABASE_DEFAULT NULL  
        );  
  
        ;WITH hierarchiesWithMemberSecurityCte AS  
        (  
            SELECT DISTINCT DerivedHierarchy_ID  
            FROM mdm.tblSecurityRoleAccessMember  
        )  
        INSERT INTO @DerivedHierarchyLevelsToProcess  
        (  
            Model_ID,  
            Model_MUID,  
            ModelName,  
            Version_ID,  
            DerivedHierarchy_ID,  
            DerivedHierarchy_MUID,  
            DerivedHierarchyName,  
            MUID,  
            Name,  
            Foreign_ID,  
            ForeignType_ID,  
            ManyToManyChildAttribute_ID,  
            DisplayName,  
            IsVisible,  
            IsMemberSecurityApplied,  
            Error  
        )  
        SELECT  
            m.ID,  
            m.MUID,  
            m.Name,  
            m.MaxVersion_ID,  
            dh.ID,  
            dh.MUID,  
            dh.Name,  
            dhl.MUID,  
            dhl.Name,  
            COALESCE(fid_a.ID, fid_e.ID, fid_h.ID), -- Foreign_ID  
            dhl.ForeignType_ID,  
            m2mChild.ID,  
            dhl.DisplayName,  
            dhl.IsVisible,  
            CASE WHEN memSec.DerivedHierarchy_ID IS NULL THEN 0 ELSE 1 END, -- IsMemberSecurityApplied  
            -- Do more expensive error checks here (i.e. ones that require querying tables), and leave the simple checks to udpDerivedHierarchyDetailSave  
            CASE   
                WHEN m.ID IS NULL                                           THEN N'MDSERR200053|The hierarchy level cannot be saved. The model ID is not valid.'  
                WHEN m.IsAdministrator = 0                                  THEN N'MDSERR120003|The user does not have permission or the object ID is not valid.'  
                WHEN dh.ID IS NULL                                          THEN N'MDSERR200054|The derived hierarchy level cannot be saved. The derived hierarchy ID is not valid.'  
                WHEN COALESCE(fid_a.ID, fid_e.ID, fid_h.ID) IS NULL         THEN N'MDSERR200063|The derived hierarchy level cannot be saved. The Foreign ID is not valid.'  
                WHEN dhl.ForeignType_ID = @HierarchyItemType_ManyToMany   
                    AND fid_a.DomainEntity_ID = fid_a.Entity_ID             THEN N'MDSERR100060|The ForeignId is not valid. The parent attribute on a mapping entity cannot be self-referencing.'  
                WHEN ForeignType_ID = @HierarchyItemType_ManyToMany   
                    AND (  m2mChild.ID IS NULL   
                        OR m2mChild.Entity_ID = m2mChild.DomainEntity_ID)   THEN N'MDSERR100061|The ManyToManyChildAttributeId is not valid. It must belong to the same mapping entity as ForeignId (parent attribute) and cannot be self-referencing.'  
                END  
        FROM @DerivedHierarchyLevels dhl  
        -- Note: looking up model ids in a batch here is more efficient that doing it one row at a time in udpDerivedHierarchyDetailSave  
        LEFT JOIN #UserModelAccess m  
        ON      (dhl.Model_MUID IS NOT NULL OR dhl.ModelName IS NOT NULL)   
            AND (dhl.Model_MUID IS NULL OR dhl.Model_MUID = m.MUID)   
            AND (dhl.ModelName  IS NULL OR dhl.ModelName  = m.Name)  
        LEFT JOIN mdm.tblDerivedHierarchy dh  
        ON      m.ID = dh.Model_ID  
            AND (dhl.DerivedHierarchy_MUID IS NOT NULL OR dhl.DerivedHierarchyName IS NOT NULL)   
            AND (dhl.DerivedHierarchy_MUID IS NULL OR dhl.DerivedHierarchy_MUID = dh.MUID)   
            AND (dhl.DerivedHierarchyName  IS NULL OR dhl.DerivedHierarchyName  = dh.Name)  
        LEFT JOIN mdm.tblEntity fe -- ForeignEntity (might be null)  
        ON      m.ID = fe.Model_ID  
            AND (dhl.ForeignEntity_MUID IS NOT NULL OR dhl.ForeignEntityName IS NOT NULL)   
            AND (dhl.ForeignEntity_MUID IS NULL OR dhl.ForeignEntity_MUID = fe.MUID)   
            AND (dhl.ForeignEntityName  IS NULL OR dhl.ForeignEntityName  = fe.Name)  
  
        -- Foreign_ID (could be one of several types)  
        LEFT JOIN mdm.tblEntity fid_e  
        ON      dhl.ForeignType_ID = @HierarchyItemType_Entity  
            AND m.ID = fid_e.Model_ID  
            AND (dhl.Foreign_MUID IS NOT NULL OR dhl.ForeignName IS NOT NULL)   
            AND (dhl.Foreign_MUID IS NULL OR dhl.Foreign_MUID = fid_e.MUID)   
            AND (dhl.ForeignName  IS NULL OR dhl.ForeignName  = fid_e.Name)  
        LEFT JOIN mdm.tblAttribute fid_a  
        ON      dhl.ForeignType_ID IN (@HierarchyItemType_DBA, @HierarchyItemType_ManyToMany)  
            AND fid_a.MemberType_ID = 1/*Leaf*/  
            AND (fe.ID = fid_a.Entity_ID -- Must be a Leaf DBA on the ForeignEntity.   
                OR (fe.ID IS NULL AND dhl.Foreign_MUID = fid_a.MUID)) -- If ForeignEntity isn't provided, match on the attribute MUID  
            AND (dhl.Foreign_MUID IS NOT NULL OR dhl.ForeignName IS NOT NULL)   
            AND (dhl.Foreign_MUID IS NULL OR dhl.Foreign_MUID = fid_a.MUID)   
            AND (dhl.ForeignName  IS NULL OR dhl.ForeignName  = fid_a.Name)  
        LEFT JOIN mdm.tblHierarchy fid_h  
        ON      dhl.ForeignType_ID = @HierarchyItemType_Hierarchy  
            AND (fe.ID = fid_h.Entity_ID -- Must be an Explicit Hierarchy on the ForeignEntity  
                OR (fe.ID IS NULL AND dhl.Foreign_MUID = fid_h.MUID)) -- If ForeignEntity isn't provided, match on the hierarchy MUID  
            AND (dhl.Foreign_MUID IS NOT NULL OR dhl.ForeignName IS NOT NULL)   
            AND (dhl.Foreign_MUID IS NULL OR dhl.Foreign_MUID = fid_h.MUID)   
            AND (dhl.ForeignName  IS NULL OR dhl.ForeignName  = fid_h.Name)  
  
        -- Many-to-many child attribute  
        LEFT JOIN mdm.tblAttribute m2mChild  
        ON      fid_a.Entity_ID = m2mChild.Entity_ID -- Must be a Leaf DBA on the ForeignEntity  
            AND m2mChild.MemberType_ID = 1/*Leaf*/  
            AND (dhl.ManyToManyChildAttribute_MUID IS NOT NULL OR dhl.ManyToManyChildAttributeName IS NOT NULL)   
            AND (dhl.ManyToManyChildAttribute_MUID IS NULL OR dhl.ManyToManyChildAttribute_MUID = m2mChild.MUID)   
            AND (dhl.ManyToManyChildAttributeName  IS NULL OR dhl.ManyToManyChildAttributeName  = m2mChild.Name)  
  
        -- Determine if the hierarchy is used for assigning member security permissions  
        LEFT JOIN hierarchiesWithMemberSecurityCte memSec  
        ON dh.ID = memSec.DerivedHierarchy_ID  
        ORDER BY   
             dh.ID  
            ,dhl.LevelNumber DESC   
  
        SELECT TOP 1 @Error = Error  
        FROM @DerivedHierarchyLevelsToProcess  
        WHERE Error IS NOT NULL;  
  
        IF @Error IS NOT NULL  
        BEGIN  
            SET @Error = REPLACE(@Error, '%', '%%')-- escape out format specifier  
            RAISERROR(@Error, 16, 1);  
        END  
  
        DECLARE @DerivedHierarchyLevel_ID           INT,  
                @DerivedHierarchyLevel_MUID         UNIQUEIDENTIFIER,  
                @DerivedHierarchyLevelName          NVARCHAR(100),  
                @Foreign_ID                         INT,  
                @ForeignType_ID                     TINYINT,  
                @ManyToManyChildAttribute_ID        INT,  
                @DerivedHierarchyLevelDisplayName   NVARCHAR(100),  
                @DerivedHierarchyLevelIsVisible     BIT,  
                @IsMemberSecurityApplied            BIT;  
  
        WHILE EXISTS(SELECT 1 FROM @DerivedHierarchyLevelsToProcess)  
        BEGIN  
            SELECT TOP 1  
                @Row_ID = RowID,  
                @Model_ID = Model_ID,  
                @Model_MUID = Model_MUID,  
                @ModelName = ModelName,  
                @MaxVersion_ID = Version_ID,  
                @DerivedHierarchy_ID = DerivedHierarchy_ID,  
                @DerivedHierarchy_MUID = DerivedHierarchy_MUID,  
                @DerivedHierarchyName = DerivedHierarchyName,  
                @DerivedHierarchyLevel_MUID = MUID,  
                @DerivedHierarchyLevelName = Name,  
                @Foreign_ID = Foreign_ID,  
                @ForeignType_ID = ForeignType_ID,  
                @ManyToManyChildAttribute_ID = ManyToManyChildAttribute_ID,  
                @DerivedHierarchyLevelDisplayName = DisplayName,  
                @DerivedHierarchyLevelIsVisible = IsVisible,  
                @IsMemberSecurityApplied = IsMemberSecurityApplied  
            FROM @DerivedHierarchyLevelsToProcess  
            ORDER BY RowID  
  
            PRINT CONCAT(SYSDATETIME(), N': Saving derived hierarchy level ', @DerivedHierarchyName, N'.', @DerivedHierarchyLevelName);  
            EXEC mdm.udpDerivedHierarchyDetailSave  
                    @User_ID = @User_ID,  
                    @Model_ID = @Model_ID,  
                    @Version_ID = @MaxVersion_ID,  
                    @DerivedHierarchy_ID = @DerivedHierarchy_ID,  
                    @MUID = @DerivedHierarchyLevel_MUID,  
                    @Name = @DerivedHierarchyLevelName,  
                    @Foreign_ID = @Foreign_ID,  
                    @ForeignType_ID = @ForeignType_ID,  
                    @ManyToManyChildAttribute_ID = @ManyToManyChildAttribute_ID,  
                    @DisplayName = @DerivedHierarchyLevelDisplayName,  
                    @IsVisible = @DerivedHierarchyLevelIsVisible,  
                    @EditMode = @EditMode,  
                    @IsMemberSecurityApplied = @IsMemberSecurityApplied,  
                    @Return_ID = @DerivedHierarchyLevel_ID OUTPUT,  
                    @Return_MUID = @DerivedHierarchyLevel_MUID OUTPUT,  
                    @CorrelationID = @CorrelationID;  
  
            INSERT INTO @CreatedDerivedHierarchyLevels  
            (  
                ModelID,  
                ModelMUID,  
                ModelName,  
                DerivedHierarchyID,  
                DerivedHierarchyMUID,  
                DerivedHierarchyName,  
                ID,  
                MUID,  
                Name  
            )  
            VALUES  
            (  
                @Model_ID,  
                @Model_MUID,  
                @ModelName,  
                @DerivedHierarchy_ID,  
                @DerivedHierarchy_MUID,  
                @DerivedHierarchyName,  
                @DerivedHierarchyLevel_ID,  
                @DerivedHierarchyLevel_MUID,  
                @DerivedHierarchyLevelName  
            )  
  
            DELETE @DerivedHierarchyLevelsToProcess  
            WHERE RowID = @Row_ID;  
        END  
  
        -- If levels were (potentially) created, ensure the top and bottom levels of the hierarchy are visible (udpDerivedHierarchyDetailSave will do this check for level updates).  
        IF @EditMode <> @EditMode_Update -- Clone mode could create a new level, so also do the check  
        BEGIN  
            DECLARE @InvalidHierarchy_ID INT;  
            WITH changedHierarchyCte AS  
            (  
                SELECT DISTINCT DerivedHierarchyID  
                FROM @CreatedDerivedHierarchyLevels  
            )  
            ,maxAndMinLevelsCte AS  
            (  
                SELECT   
                     dhd.DerivedHierarchy_ID  
                    ,MAX(Level_ID) MaxLevel  
                    ,MIN(Level_ID) MinLevel  
                FROM mdm.tblDerivedHierarchyDetail dhd  
                INNER JOIN changedHierarchyCte h  
                ON dhd.DerivedHierarchy_ID = h.DerivedHierarchyID  
                GROUP BY dhd.DerivedHierarchy_ID  
            )              
            SELECT TOP 1   
                @InvalidHierarchy_ID = dhd.DerivedHierarchy_ID  
            FROM mdm.tblDerivedHierarchyDetail dhd  
            INNER JOIN maxAndMinLevelsCte lvl  
            ON dhd.DerivedHierarchy_ID = lvl.DerivedHierarchy_ID  
                AND (   dhd.Level_ID = MaxLevel  
                     OR dhd.Level_ID = MinLevel)  
            WHERE dhd.IsVisible = 0;  
  
            IF @InvalidHierarchy_ID > 0  
            BEGIN  
                RAISERROR(N'MDSERR200099|The top or bottom level of a derived hierarchy cannot be hidden.', 16, 1)  
            END  
        END  
  
        --Output created/updated derived hierarchy levels  
        SELECT ModelID, ModelMUID, ModelName, DerivedHierarchyID, DerivedHierarchyMUID, DerivedHierarchyName, ID, MUID, Name FROM @CreatedDerivedHierarchyLevels;  
  
        --END Derived hierarchy level processing  
  
  
        -- BEGIN Attribute Filter processing (this must be done after creating Attributes and Derived Hierarchies, rather than as part of Attribute creation, because the filters may include dependencies on Attributes and Derived Hierarchies that are being created in this same operation)  
        IF @EditMode <> @EditMode_Update -- In update mode the filter info was already handled, so no need to re-call udpAttributeSave here.  
        BEGIN  
            EXEC mdm.udpMetadataSaveHelper_LookupAttributeFilterIds @AttributeFilters  
  
            SELECT TOP 1 @Error = Error  
            FROM #AttributesToProcess  
            WHERE Error IS NOT NULL;  
  
            IF @Error IS NOT NULL  
            BEGIN  
                SET @Error = REPLACE(@Error, '%', '%%')-- escape out format specifier  
                RAISERROR(@Error, 16, 1);  
            END  
  
            SET @Row_ID = 0  
  
            WHILE EXISTS(SELECT 1 FROM #AttributesToProcess WHERE Row_ID > @Row_ID AND FilterParentAttribute_ID IS NOT NULL)  
            BEGIN  
                SELECT TOP 1  
                    @Row_ID = Row_ID,  
                    @Attribute_ID = ID,  
                    @AttributeName = Name,  
                    @Model_ID = Model_ID,  
                    @MaxVersion_ID = Version_ID,  
                    @Entity_ID = Entity_ID,  
                    @IsHierarchyEnabled = IsHierarchyEnabled,  
                    @IsCollectionEnabled = IsCollectionEnabled,  
                    @DataCompression = DataCompression,  
                    @TableName = TableName,  
                    @StagingTableName = StagingTableName,  
                    @MemberType_ID = MemberType_ID,  
                    @AttributeDescription = [Description],  
                    @AttributeType_ID = AttributeType_ID,  
                    @DisplayName = DisplayName,  
                    @DisplayWidth = DisplayWidth,  
                    @DomainEntity_ID = DomainEntity_ID,  
                    @FilterParentAttribute_ID = FilterParentAttribute_ID,  
                    @FilterHierarchyDetail_ID = FilterHierarchyDetail_ID,  
                    @DataType_ID = DataType_ID,  
                    @DataTypeInformation = DataTypeInformation,  
                    @InputMask_ID = InputMask_ID,  
                    @ChangeTrackingGroup = ChangeTrackingGroup,  
                    @AttributeSortOrder = SortOrder  
                FROM #AttributesToProcess  
                WHERE   Row_ID > @Row_ID   
                    AND FilterParentAttribute_ID IS NOT NULL  
                ORDER BY Row_ID  
  
                PRINT CONCAT(SYSDATETIME(), N': Adding filter to attribute ', @AttributeName, ', MemberType ', @MemberType_ID, '.');  
                EXEC mdm.udpAttributeSave  
                        @User_ID = @User_ID,  
                        @Model_ID = @Model_ID,  
                        @Version_ID = @MaxVersion_ID,  
                        @Entity_ID = @Entity_ID,  
                        @IsHierarchyEnabled = @IsHierarchyEnabled,  
                        @IsCollectionEnabled = @IsCollectionEnabled,  
                        @DataCompression = @DataCompression,  
                        @TableName = @TableName OUTPUT,  
                        @StagingTableName = @StagingTableName,  
                        @MemberType_ID = @MemberType_ID,  
                        @Attribute_ID = @Attribute_ID,  
                        @AttributeName = @AttributeName,  
                        @AttributeType_ID = @AttributeType_ID,  
                        @Description = @AttributeDescription,  
                        @DisplayName = @DisplayName,  
                        @DisplayWidth = @DisplayWidth,  
                        @DomainEntity_ID = @DomainEntity_ID,  
                        @FilterParentAttribute_ID = @FilterParentAttribute_ID,  
                        @FilterHierarchyDetail_ID = @FilterHierarchyDetail_ID,  
                        @DataType_ID = @DataType_ID,  
                        @DataTypeInformation = @DataTypeInformation,  
                        @InputMask_ID = @InputMask_ID,  
                        @ChangeTrackingGroup = @ChangeTrackingGroup,  
                        @SortOrder = @AttributeSortOrder,  
                        @EditMode = @EditMode_Update,-- always updating an existing attribute at this point, even if this sproc is doing Create or Clone.  
                        @RecreateStagingProc = 0, -- will create staging sprocs later  
                        @CorrelationID = @CorrelationID;  
            END  
        END  
        -- END Attribute Filter processing  
  
  
        --BEGIN Index processing  
  
        DECLARE @IndexesToProcess TABLE  
        (  
            RowID           INT IDENTITY(1, 1) NOT NULL PRIMARY KEY,  
            Model_ID        INT NULL,  
            Model_MUID      UNIQUEIDENTIFIER NULL,  
            ModelName       NVARCHAR(50) COLLATE DATABASE_DEFAULT NULL,  
            Entity_ID       INT NULL,  
            Entity_MUID     UNIQUEIDENTIFIER NULL,  
            EntityName      NVARCHAR(50) COLLATE DATABASE_DEFAULT NULL,  
            DataCompression TINYINT NULL,  
            Index_MUID      UNIQUEIDENTIFIER NULL,  
            IndexName       NVARCHAR(50) COLLATE DATABASE_DEFAULT NULL,  
            IsUnique        BIT NULL,  
            Error           NVARCHAR(MAX) COLLATE DATABASE_DEFAULT NULL  
        );  
  
        INSERT INTO @IndexesToProcess  
        (  
            Model_ID,  
            Model_MUID,  
            ModelName,  
            Entity_ID,  
            Entity_MUID,  
            EntityName,  
            DataCompression,  
            Index_MUID,  
            IndexName,  
            IsUnique,  
            Error  
        )  
        SELECT  
            m.ID,  
            m.MUID,  
            m.Name,  
            e.ID,  
            e.MUID,  
            e.Name,  
            e.DataCompression,  
            i.MUID,  
            i.Name,  
            i.IsUnique,  
            CASE   
                WHEN m.ID IS NULL                       THEN N'MDSERR200302|The index cannot be saved. The model ID is not valid.'  
                WHEN m.IsAdministrator = 0              THEN N'MDSERR120003|The user does not have permission or the object ID is not valid.'  
                WHEN e.ID IS NULL                       THEN N'MDSERR200303|The index cannot be saved. The entity ID is not valid.'  
                WHEN syncTarget.Entity_ID IS NOT NULL   THEN N'MDSERR200225|The index cannot be saved. The entity is the target of a sync relationship.'  
                END  
        FROM @Indexes i  
        -- Note: looking up model ids and entity ids in a batch here is more efficient that doing it one row at a time in udpIndexSave  
        LEFT JOIN #UserModelAccess m  
        ON      (i.Model_MUID IS NOT NULL OR i.ModelName IS NOT NULL)   
            AND (i.Model_MUID IS NULL OR i.Model_MUID = m.MUID)   
            AND (i.ModelName  IS NULL OR i.ModelName  = m.Name)  
        LEFT JOIN mdm.tblEntity e  
        ON      m.ID = e.Model_ID  
            AND (i.Entity_MUID IS NOT NULL OR i.EntityName IS NOT NULL)  
            AND (i.Entity_MUID IS NULL OR i.Entity_MUID = e.MUID)  
            AND (i.EntityName  IS NULL OR i.EntityName  = e.Name)  
        LEFT JOIN @SyncTargetEntities syncTarget  
        ON e.ID = syncTarget.Entity_ID  
  
        SELECT TOP 1 @Error = Error  
        FROM @IndexesToProcess  
        WHERE Error IS NOT NULL;  
  
        IF @Error IS NOT NULL  
        BEGIN  
            SET @Error = REPLACE(@Error, '%', '%%')-- escape out format specifier  
            RAISERROR(@Error, 16, 1);  
        END  
  
        DECLARE @IndexDetailsToProcess mdm.CustomIndexDetail;  
        DECLARE @Index_ID       INT,  
                @Index_MUID     UNIQUEIDENTIFIER,  
                @IndexName      NVARCHAR(50),  
                @IsUnique       BIT  
  
        WHILE EXISTS(SELECT 1 FROM @IndexesToProcess)  
        BEGIN  
            SELECT TOP 1  
                @Row_ID = RowID,  
                @Model_ID = Model_ID,  
                @Model_MUID = Model_MUID,  
                @ModelName = ModelName,  
                @Entity_ID = Entity_ID,  
                @Entity_MUID = Entity_MUID,  
                @EntityName = EntityName,  
                @DataCompression = DataCompression,  
                @Index_MUID = Index_MUID,  
                @IndexName = IndexName,  
                @IsUnique = IsUnique  
            FROM @IndexesToProcess  
  
            DELETE FROM @IndexDetailsToProcess;  
            INSERT INTO @IndexDetailsToProcess  
            (  
                Model_MUID,  
                ModelName,  
                Entity_MUID,  
                EntityName,  
                CustomIndex_MUID,  
                CustomIndexName,  
                MUID,  
                Name  
            )  
            SELECT  
                Model_MUID,  
                ModelName,  
                Entity_MUID,  
                EntityName,  
                CustomIndex_MUID,  
                CustomIndexName,  
                MUID,  
                Name  
             FROM @IndexDetails details   
             WHERE  
                (details.CustomIndex_MUID IS NULL OR (@Index_MUID IS NOT NULL AND details.CustomIndex_MUID = @Index_MUID) ) AND  
                (details.CustomIndexName IS NULL OR (@IndexName IS NOT NULL AND details.CustomIndexName = @IndexName) )  
  
            PRINT CONCAT(SYSDATETIME(), N': Saving index ', @IndexName);  
            EXEC mdm.udpIndexSave  
                    @User_ID = @User_ID,  
                    @Model_ID = @Model_ID,  
                    @Entity_ID = @Entity_ID,  
                    @DataCompression = @DataCompression,  
                    @MUID = @Index_MUID,  
                    @Name = @IndexName,  
                    @IsUnique = @IsUnique,  
                    @IndexDetails = @IndexDetailsToProcess,  
                    @EditMode = @EditMode,  
                    @Return_ID = @Index_ID OUTPUT,  
                    @Return_MUID = @Index_MUID OUTPUT,  
                    @CorrelationID = @CorrelationID;  
  
            INSERT INTO @CreatedIndexes  
            (  
                ModelID,  
                ModelMUID,  
                ModelName,  
                EntityID,  
                EntityMUID,  
                EntityName,  
                ID,  
                MUID,  
                Name  
            )  
            VALUES  
            (  
                @Model_ID,  
                @Model_MUID,  
                @ModelName,  
                @Entity_ID,  
                @Entity_MUID,  
                @EntityName,  
                @Index_ID,  
                @Index_MUID,  
                @IndexName  
            )  
  
            DELETE @IndexesToProcess  
            WHERE RowID = @Row_ID;  
        END  
  
        --Output created/updated indexes  
        SELECT ModelID, ModelMUID, ModelName, EntityID, EntityMUID, EntityName, ID, MUID, Name FROM @CreatedIndexes;  
  
        --END Index processing  
  
        --Get a list of the created/updated models  
        DECLARE @ChangedModels TABLE  
        (  
             ID     INT PRIMARY KEY  
            ,Name   NVARCHAR(50) COLLATE DATABASE_DEFAULT NOT NULL  
        )  
  
        ;WITH cteModelsChanged AS  
        (  
            SELECT ID AS ModelID  
            FROM @CreatedModels  
            UNION -- not "UNION ALL" because deduplication is needed  
            SELECT ModelID  
            FROM @CreatedEntities  
            UNION -- not "UNION ALL" because deduplication is needed  
            SELECT ModelID  
            FROM @CreatedExplicitHierarchies  
            UNION -- not "UNION ALL" because deduplication is needed  
            SELECT Model_ID  
            FROM #AttributesToProcess  
            UNION -- not "UNION ALL" because deduplication is needed  
            SELECT ModelID  
            FROM @CreatedAttributeGroups  
            UNION -- not "UNION ALL" because deduplication is needed  
            SELECT ModelID  
            FROM @CreatedDerivedHierarchies  
            UNION -- not "UNION ALL" because deduplication is needed  
            SELECT ModelID  
            FROM @CreatedDerivedHierarchyLevels  
            UNION -- not "UNION ALL" because deduplication is needed  
            SELECT ModelID  
            FROM @CreatedIndexes  
        )  
        INSERT INTO @ChangedModels  
            (ID, Name)  
        SELECT  
            m.ModelID, sec.Name  
        FROM cteModelsChanged m  
        INNER JOIN #UserModelAccess sec  
        ON m.ModelID = sec.ID  
  
        SET @Lock = -1;  
        EXEC sp_releaseapplock @Resource = N'DeferViewGeneration', @LockOwner='Session';  
  
        WHILE EXISTS(SELECT 1 FROM @ChangedModels)  
        BEGIN  
            SELECT TOP 1  
                 @Model_ID = ID  
                ,@ModelName = Name  
            FROM @ChangedModels  
  
            PRINT CONCAT(SYSDATETIME(), N': Regenerating views for model ', @ModelName);  
            EXEC mdm.udpCreateViews @Model_ID = @Model_ID, @CorrelationID = @CorrelationID;  
  
            -- Regenerate subscription views if there are any.   
            PRINT CONCAT(SYSDATETIME(), N': Regenerating subscription views for model ', @ModelName);  
            EXEC mdm.udpCreateAllSubscriptionViews @Model_ID = @Model_ID, @CorrelationID = @CorrelationID;  
  
            DELETE @ChangedModels  
            WHERE ID = @Model_ID;  
        END  
  
          
        -- All Entity and Attribute changes are finished at this point, and all views have been recreated, so (re)create staging sprocs.  
          
        -- Determine which entity member types need to have their staging sprocs recreated  
        DECLARE @StaleStagingSprocs TABLE  
        (  
             RowID          INT IDENTITY(1, 1) NOT NULL PRIMARY KEY  
            ,Entity_ID      INT  
            ,EntityName     NVARCHAR(50)  
            ,MemberType_ID  TINYINT  
        )  
        INSERT INTO @StaleStagingSprocs   
        (  
             Entity_ID  
            ,EntityName  
            ,MemberType_ID  
        )  
        SELECT  
             Entity_ID  
            ,EntityName  
            ,MemberType_ID  
        FROM #AttributesToProcess  
        UNION -- not "UNION ALL" because deduplication is needed  
        SELECT  
            ID,  
            Name,  
            @MemberType_Leaf  
        FROM @CreatedEntities  
        WHERE @EditMode = @EditMode_Create  
        UNION -- not "UNION ALL" because deduplication is needed  
        SELECT  
            EntityID,  
            EntityName,  
            @MemberType_Leaf -- udpEntityHierarchySave already avoids needlessly creating consolidated-related sprocs  
        FROM @CreatedExplicitHierarchies  
  
        WHILE EXISTS (SELECT 1 FROM @StaleStagingSprocs)  
        BEGIN  
            SELECT TOP 1  
                 @Row_ID = RowID  
                ,@Entity_ID = Entity_ID  
                ,@EntityName = EntityName  
                ,@MemberType_ID = MemberType_ID  
            FROM @StaleStagingSprocs  
  
            IF @MemberType_ID = @MemberType_Leaf  
            BEGIN  
                PRINT CONCAT(SYSDATETIME(), N': Creating Leaf staging sproc for entity ', @EntityName, N' (ID = ', @Entity_ID, N')');  
                EXEC mdm.udpEntityStagingCreateLeafStoredProcedure @Entity_ID  
            END ELSE  
            IF @MemberType_ID = @MemberType_Consolidated  
            BEGIN  
                PRINT CONCAT(SYSDATETIME(), N': Creating Consolidated staging sproc for entity ', @EntityName, N' (ID = ', @Entity_ID, N')');  
                EXEC mdm.udpEntityStagingCreateConsolidatedStoredProcedure @Entity_ID  
            END  
  
            DELETE @StaleStagingSprocs  
            WHERE RowID = @Row_ID  
        END  
  
  
        --Commit only if we are not nested  
        IF @TranCounter = 0 COMMIT TRANSACTION;  
        RETURN(0);  
  
    END TRY  
    --Compensate as necessary  
    BEGIN CATCH  
  
        -- Ensure the lock is released  
        IF @Lock IN (0, 1)  
        BEGIN  
            EXEC sp_releaseapplock @Resource = N'DeferViewGeneration', @LockOwner='Session';  
        END;  
  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        IF @TranCounter = 0 ROLLBACK TRANSACTION;  
        ELSE IF XACT_STATE() <> -1 ROLLBACK TRANSACTION TX;  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
        RETURN;  
  
    END CATCH;  
  
    SET NOCOUNT OFF;  
END; --proc
go

