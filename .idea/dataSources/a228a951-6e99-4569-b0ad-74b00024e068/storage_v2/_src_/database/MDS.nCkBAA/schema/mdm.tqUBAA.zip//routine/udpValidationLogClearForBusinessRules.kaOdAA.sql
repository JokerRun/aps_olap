/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
exec mdm.udpValidationLogClearForBusinessRules 1,1,1,0  
exec mdm.udpValidationLogClearForBusinessRules 1,1,1,1 -- delete validation log entries for excluded rules only  
*/  
CREATE PROCEDURE mdm.udpValidationLogClearForBusinessRules  
(  
    @Entity_ID          INT,  
    @MemberType_ID      TINYINT,  
    @ExcludedRulesOnly  BIT = 0,  
    @CorrelationID      UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    DECLARE @Model_ID               INT,  
            @SQL                    NVARCHAR(MAX),  
            @ValidationLogTableName sysname;  
  
    SELECT @Model_ID = Model_ID  
    FROM mdm.tblEntity  
    WHERE ID = @Entity_ID;  
  
    SET @ValidationLogTableName = mdm.udfGetValidationLogTableName(@Model_ID);  
      
    SET @SQL = N'  
    DELETE vl  
    FROM [mdm].' + QUOTENAME(@ValidationLogTableName) + N' vl  
    INNER JOIN mdm.tblBRBusinessRule br  
    ON vl.BRBusinessRule_ID = br.ID  
    WHERE   br.Entity_ID = @Entity_ID  
        AND br.MemberType_ID = @MemberType_ID';  
      
    IF COALESCE(@ExcludedRulesOnly, 0) = 1  
    BEGIN  
        SET @SQL += N'  
        AND br.Status_ID =  2 -- Excluded';  
    END;  
  
    EXEC sp_executesql @SQL, N'@Entity_ID INT, @MemberType_ID TINYINT',  
                               @Entity_ID,     @MemberType_ID;  
  
    SET NOCOUNT OFF  
END --proc
go

