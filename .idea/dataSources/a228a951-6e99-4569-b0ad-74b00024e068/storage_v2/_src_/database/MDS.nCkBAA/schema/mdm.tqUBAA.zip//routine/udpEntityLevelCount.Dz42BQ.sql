/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    DECLARE @i INT;  
    EXEC mdm.udpEntityLevelCount 6, @i OUTPUT;  
    SELECT @i;  
*/  
CREATE PROCEDURE mdm.udpEntityLevelCount  
(  
    @Entity_ID      INT,  
    @Levels         SMALLINT OUTPUT,  
    @CorrelationID  UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE @SQL            NVARCHAR(MAX) ,  
            @HierarchyTable NVARCHAR(258);  
  
    SET @Levels = CAST(-1 AS SMALLINT);  
  
    SELECT @HierarchyTable = HierarchyTable  
    FROM [mdm].tblEntity WHERE ID = @Entity_ID;  
         
    IF @HierarchyTable IS NULL RETURN;  
  
    SET @SQL = N'SELECT @Levels = ISNULL((SELECT MAX(LevelNumber) FROM mdm.' + quotename(@HierarchyTable) + N'), 0);';  
    EXEC sp_executesql @SQL, N'@Levels INT OUTPUT', @Levels OUTPUT;  
  
    SET NOCOUNT OFF;  
END; --proc
go

