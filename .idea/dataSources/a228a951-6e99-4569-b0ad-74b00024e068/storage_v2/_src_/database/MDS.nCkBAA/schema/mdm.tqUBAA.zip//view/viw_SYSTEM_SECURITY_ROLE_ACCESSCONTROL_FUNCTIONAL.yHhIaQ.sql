/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE VIEW mdm.viw_SYSTEM_SECURITY_ROLE_ACCESSCONTROL_FUNCTIONAL  
/*WITH SCHEMABINDING*/  
AS  
  
SELECT   
     ra.ID                      RoleAccess_ID  
    ,ra.MUID                    RoleAccess_MUID  
    ,ra.Role_ID  
  
    ,ac.Principal_ID  
    ,CASE ac.PrincipalType_ID WHEN 1 /*User*/ THEN u.MUID ELSE ug.MUID END Principal_MUID  
    ,ac.PrincipalType_ID  
    ,CASE ac.PrincipalType_ID WHEN 1 /*User*/ THEN u.UserName ELSE ug.Name END Principal_Name  
  
    ,ra.FunctionalPrivilege_ID  Function_ID  
    ,f.Name                     Function_Name  
  
    --Auditing  
    ,ra.EnterDTM  
    ,ra.EnterUserID  
    ,COALESCE(eu.MUID, CONVERT(UNIQUEIDENTIFIER, 0x0))  EnterUserMUID  
    ,COALESCE(eu.UserName, N'')                         EnterUserName  
    ,ra.LastChgDTM  
    ,ra.LastChgUserID  
    ,COALESCE(lcu.MUID, CONVERT(UNIQUEIDENTIFIER, 0x0)) LastChgUserMUID  
    ,COALESCE(lcu.UserName, N'')                        LastChgUserName  
FROM mdm.tblSecurityRoleAccessFunctional ra  
INNER JOIN mdm.tblSecurityPrivilegeFunctional f  
ON ra.FunctionalPrivilege_ID = f.ID  
INNER JOIN  mdm.tblSecurityAccessControl ac  
ON ra.Role_ID = ac.Role_ID  
LEFT JOIN mdm.tblUserGroup ug  
ON      ac.PrincipalType_ID = 2 -- Group  
    AND ac.Principal_ID = ug.ID  
    AND ug.Status_ID = 1 -- Active  
LEFT JOIN mdm.tblUser u  
ON      ac.PrincipalType_ID = 1 -- User  
    AND ac.Principal_ID = u.ID  
    AND u.Status_ID = 1 -- Active  
LEFT JOIN  mdm.tblUser eu  
ON ra.EnterUserID = eu.ID  
LEFT JOIN  mdm.tblUser lcu  
ON ra.LastChgUserID = lcu.ID
go

