/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    EXEC mdm.udpModelDelete '5'  
*/  
CREATE PROCEDURE mdm.udpModelDelete  
(  
    @Model_ID INT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON  
  
    --Start transaction, being careful to check if we are nested  
    DECLARE @TranCounter INT;   
    SET @TranCounter = @@TRANCOUNT;  
    IF @TranCounter > 0 SAVE TRANSACTION TX;  
    ELSE BEGIN TRANSACTION;  
  
    BEGIN TRY  
  
        DECLARE @tblEntityID    TABLE (  
                                RowNumber INT IDENTITY (1, 1) PRIMARY KEY CLUSTERED NOT NULL   
                                ,ID INT NOT NULL  
                                ,Name NVARCHAR(50) NOT NULL);  
        DECLARE @DeleteBRs      mdm.IdList;  
  
        DECLARE @TempID         INT  
        DECLARE @TempEntityName NVARCHAR(50);  
  
        --Delete all derived hierarchies  
        INSERT INTO @tblEntityID   
            SELECT D.ID, N'' FROM mdm.tblDerivedHierarchy D WHERE D.Model_ID = @Model_ID;  
        DECLARE @Counter INT = 1 ;  
        DECLARE @MaxCounter INT = (SELECT MAX(RowNumber) FROM @tblEntityID);  
          
        WHILE @Counter <= @MaxCounter  
            BEGIN  
            SELECT @TempID = ID FROM @tblEntityID WHERE [RowNumber] = @Counter ;;  
            EXEC mdm.udpDerivedHierarchyDelete @TempID;  
            SET @Counter = @Counter+1  
        END; --while  
          
        --Delete the subscription views associated with the model  
        EXEC mdm.udpSubscriptionViewsDelete   
            @Model_ID               = @Model_ID,  
            @Version_ID             = NULL,  
            @Entity_ID              = NULL,  
            @DerivedHierarchy_ID    = NULL;  
  
        --Delete business rules  
        INSERT INTO @DeleteBRs (ID) SELECT br.BusinessRule_ID FROM mdm.viw_SYSTEM_SCHEMA_BUSINESSRULES br WHERE br.Model_ID = @Model_ID;  
        EXEC mdm.udpBusinessRulesDelete @RuleIDs = @DeleteBRs  
  
        --Delete any explicitly assigned security privileges  
        DELETE FROM mdm.tblSecurityRoleAccess WHERE Model_ID = @Model_ID;  
  
  
        --Delete any indexes on model's entities. We need to do this before deleting entities since if we have an index on a dba attribute and the  
        --related entity of that attribute is going to be deleted first, the existing index have to be deleted first before deleting the entity.  
        DELETE FROM @tblEntityID;  
        INSERT INTO @tblEntityID SELECT E.ID, E.Name FROM mdm.tblEntity E WHERE E.Model_ID = @Model_ID;  
        SET @Counter = 0;  
        SET @MaxCounter = 0;  
        SELECT   
             @Counter = MIN(RowNumber)--reused table variable so the row won't start at 1.  
            ,@MaxCounter = MAX(RowNumber)  
        FROM @tblEntityID  
          
        DECLARE @tblIndexID TABLE(  
                            ID INT NOT NULL);  
        DECLARE @IndexID    INT;  
        WHILE @Counter <= @MaxCounter  
        BEGIN  
            SELECT   
                 @TempID = ID   
            FROM @tblEntityID WHERE [RowNumber] = @Counter ;  
            DELETE FROM @tblIndexID;  
            INSERT INTO @tblIndexID SELECT I.ID FROM mdm.tblIndex I WHERE I.Entity_ID = @TempID  
            PRINT CONCAT(SYSDATETIME(), ': Removing INDEXES ON Entity:', @TempEntityName, N' (ID =', @TempID, N')')  
            WHILE EXISTS(SELECT 1 FROM @tblIndexID)  
            BEGIN  
                SELECT TOP 1      
                    @IndexID = ID  
                FROM @tblIndexID  
                EXEC mdm.udpIndexDelete @ID = @IndexID;  
                DELETE FROM @tblIndexID WHERE ID = @IndexID;  
            END  
            SET @Counter = @Counter+1  
        END; --while  
  
        DELETE FROM @tblEntityID;      
        --Delete all entities within the Model  
        INSERT INTO @tblEntityID SELECT E.ID, E.Name FROM mdm.tblEntity E WHERE E.Model_ID = @Model_ID;  
        SET @Counter = 0;  
        SET @MaxCounter = 0;  
        SELECT   
             @Counter = MIN(RowNumber)--reused table variable so the row won't start at 1.  
            ,@MaxCounter = MAX(RowNumber)  
        FROM @tblEntityID  
          
        WHILE @Counter <= @MaxCounter  
        BEGIN  
            SELECT   
                 @TempID = ID   
                ,@TempEntityName = Name  
            FROM @tblEntityID WHERE [RowNumber] = @Counter ;  
            PRINT CONCAT(SYSDATETIME(), ': Removing Entity:', @TempEntityName, N' (ID = ', @TempID, N')')  
            EXEC mdm.udpEntityDelete @Entity_ID = @TempID, @CreateViewsInd = 0;  
            SET @Counter = @Counter+1  
        END; --while  
  
        --Delete all notification queue related items  
        DELETE FROM mdm.tblNotificationUsers WHERE Notification_ID IN (SELECT ID FROM mdm.tblNotificationQueue WHERE Model_ID = @Model_ID);          
        DELETE FROM mdm.tblNotificationQueue WHERE Model_ID = @Model_ID  
  
        --Delete the version record(s)  
        DELETE FROM mdm.tblModelVersion WHERE Model_ID = @Model_ID;  
        DELETE FROM mdm.tblModelVersionFlag WHERE Model_ID = @Model_ID;  
  
        --Delete the model tables  
        EXEC mdm.udpDeleteModelTablesAndViews @Model_ID = @Model_ID;  
  
        --Delete the Model record  
        DELETE FROM mdm.tblModel WHERE ID = @Model_ID;  
  
        --Commit only if we are not nested  
        IF @TranCounter = 0 COMMIT TRANSACTION;  
  
    END TRY  
    --Compensate as necessary  
    BEGIN CATCH  
  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        IF @TranCounter = 0 ROLLBACK TRANSACTION;  
        ELSE IF XACT_STATE() <> -1 ROLLBACK TRANSACTION TX;  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
  
        --On error, return NULL results  
        --SELECT @Return_ID = NULL;  
        RETURN(1);  
  
    END CATCH;  
  
    SET NOCOUNT OFF;  
END; --proc
go

