/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE FUNCTION mdm.udfBusinessRuleIsItemTypeCompatible  
(  
    @AttributeType int,  
    @Datatype int,  
    @BRItemType_ID int  
)   
RETURNS BIT  
/*WITH SCHEMABINDING*/  
AS BEGIN  
  
    RETURN CASE WHEN EXISTS(  
        SELECT 1  
        FROM mdm.tblBRItemTypeAppliesTo a   
        INNER JOIN mdm.tblListRelationship l   
        ON  a.ApplyTo_ID = l.ID AND   
            l.ListRelationshipType_ID = 3 AND -- DataType  
            l.Parent_ID = @AttributeType AND   
            l.Child_ID = @Datatype AND  
            a.BRItemType_ID = @BRItemType_ID  
        )  
        THEN 1 ELSE 0 END;  
  
END --fn
go

