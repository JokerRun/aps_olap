/*  
exec mdm.udpValidationLogClearByMemberID 7,5,191,1  
select * from mdm.tbl_7_VL  
*/  
/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpValidationLogClearByMemberID  
(  
    @Version_ID	INT,  
    @Entity_ID	INT,  
    @Member_ID	INT,  
    @MemberType_ID	INT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
/*WITH*/  
AS BEGIN  
    SET NOCOUNT ON  
  
    DECLARE @Model_ID               INT,  
            @SQL                    NVARCHAR(MAX),  
            @ValidationLogTableName sysname,  
            @ValidationLogViewName  sysname;  
  
    --Figure out the model ID  
    SELECT @Model_ID = Model_ID  
    FROM mdm.tblModelVersion  
    WHERE ID = @Version_ID;  
  
    SET @ValidationLogTableName = mdm.udfGetValidationLogTableName(@Model_ID);  
    SET @ValidationLogViewName = mdm.udfGetValidationLogViewName(@Model_ID);  
  
    SET @SQL = N'  
    DELETE   
    FROM 	[mdm].' + QUOTENAME(@ValidationLogTableName) + N'  
    WHERE	ID IN  
        (SELECT	vl.ID  
        FROM 	[mdm].' + QUOTENAME(@ValidationLogViewName) + N' vl   
        WHERE	vl.Member_ID = @Member_ID AND  
            vl.MemberType_ID = @MemberType_ID AND  
            vl.Version_ID = @Version_ID AND  
            vl.Entity_ID = @Entity_ID);  
    ';  
    EXEC sp_executesql @SQL, N'@Member_ID INT, @MemberType_ID INT, @Version_ID INT, @Entity_ID INT',  
                               @Member_ID,     @MemberType_ID,     @Version_ID,     @Entity_ID;  
  
    SET NOCOUNT OFF  
END --proc
go

