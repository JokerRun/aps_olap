/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE mdm.udpAttributeGet  
(  
     @User_ID       INT  
  
    ,@Model_MUID    UNIQUEIDENTIFIER = NULL  
    ,@Model_Name    NVARCHAR(50) = NULL  
    ,@Model_ID      INT = NULL -- set internally only  
  
    ,@Entity_MUID   UNIQUEIDENTIFIER = NULL  
    ,@Entity_Name   NVARCHAR(50) = NULL  
    ,@Entity_ID     INT = NULL -- set internally only  
  
    ,@MemberType_ID TINYINT = NULL  
  
    ,@AttributeGroup_MUID   UNIQUEIDENTIFIER = NULL  
    ,@AttributeGroup_Name   NVARCHAR(50) = NULL  
    ,@AttributeGroup_ID     INT = NULL -- set internally only  
  
    ,@Attribute_MUID    UNIQUEIDENTIFIER = NULL  
    ,@Attribute_Name    NVARCHAR(100) = NULL  
  
    ,@IncludeParentIdentifiers BIT = 1 -- Return results sets for parent Model and Entity identifiers. Set to 0 when getting attributes as part of a parent object (because the parent identifiers will already have been looked up).  
  
    ,@AttributeIds      mdm.IdList READONLY  
  
    ,@Debug                     BIT = 0  
    ,@CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
  
    SET NOCOUNT ON  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': begin udpAttributeGet, @Model_ID = ', @Model_ID, N', @Entity_ID = ', @Entity_ID, N', @MemberType_ID = ', @MemberType_ID, N', @AttributeGroup_ID = ', @AttributeGroup_ID, N', @Attribute_Name = ', @Attribute_Name)  
    -- Get model ID  
    IF @Model_ID IS NULL -- If the ID was already provided, don't bother looking it up again  
        AND (@Model_Name IS NOT NULL OR @Model_MUID IS NOT NULL)  
    BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': lookup @Model_ID')  
        SELECT   
             @Model_ID = ID  
            ,@Model_MUID = MUID  
            ,@Model_Name = Name  
        FROM mdm.tblModel  
        WHERE   MUID = ISNULL(@Model_MUID, MUID)  
            AND Name = ISNULL(@Model_Name, Name)  
  
        SET @Model_ID = COALESCE(@Model_ID, 0)  
    END  
  
    -- Get entity ID  
    IF @Entity_ID IS NULL -- If the ID was already provided, don't bother looking it up again  
        AND (@Entity_Name IS NOT NULL OR @Entity_MUID IS NOT NULL)  
    BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': lookup @Entity_ID')  
        SELECT  
             @Model_ID = Model_ID  
            ,@Entity_ID = ID  
            ,@Entity_MUID = MUID  
            ,@Entity_Name = Name  
        FROM mdm.tblEntity  
        WHERE   MUID = ISNULL(@Entity_MUID, MUID)  
            AND Name = ISNULL(@Entity_Name, Name)  
            AND Model_ID = ISNULL(@Model_ID, Model_ID) -- If a model filter is specified, use it  
  
        SET @Entity_ID = COALESCE(@Entity_ID, 0)  
    END  
  
    -- Get attribute group ID  
    IF @AttributeGroup_ID IS NULL -- If the ID was already provided, don't bother looking it up again  
        AND (@AttributeGroup_Name IS NOT NULL OR @AttributeGroup_MUID IS NOT NULL)  
    BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': lookup @AttributeGroup_ID')  
        SELECT @AttributeGroup_ID = ID  
        FROM mdm.tblAttributeGroup  
        WHERE   MUID = ISNULL(@AttributeGroup_MUID, MUID)  
            AND Name = ISNULL(@AttributeGroup_Name, Name)  
            AND MemberType_ID = ISNULL(@MemberType_ID, MemberType_ID)  
            AND Entity_ID = ISNULL(@Entity_ID, Entity_ID) -- If an entity filter is specified, use it  
  
        SET @AttributeGroup_ID = COALESCE(@AttributeGroup_ID, 0)  
    END  
  
    -- Get attribute ID  
    DECLARE @Attribute_ID INT = NULL;  
    IF @Attribute_Name IS NOT NULL OR @Attribute_MUID IS NOT NULL  
    BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': lookup @Attribute_ID')  
        SELECT @Attribute_ID = ID  
        FROM mdm.tblAttribute  
        WHERE   MUID = ISNULL(@Attribute_MUID, MUID)  
            AND Name = ISNULL(@Attribute_Name, Name)              
            AND MemberType_ID = ISNULL(@MemberType_ID, MemberType_ID)  
            AND Entity_ID = ISNULL(@Entity_ID, Entity_ID) -- If an entity filter is specified, use it  
  
        SET @Attribute_ID = COALESCE(@Attribute_ID, 0)  
    END  
  
    DECLARE @SelectedAttribute TABLE   
    (  
         ID                 INT PRIMARY KEY  
        ,Entity_ID          INT  
        ,Privilege_ID       TINYINT  
        ,AccessPermission   TINYINT  
    )  
  
    IF @AttributeGroup_ID IS NOT NULL  
    BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': caller has specified an AttributeGroup, using it to get selected attributes')  
        -- Get all attributes under the specified attribute group  
        INSERT INTO @SelectedAttribute  
        SELECT  
             a.ID  
            ,a.Entity_ID  
            ,acl.Privilege_ID  
            ,acl.AccessPermission  
        FROM mdm.tblAttribute a  
        INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ATTRIBUTE acl  
        ON a.ID = acl.ID  
        INNER JOIN mdm.tblAttributeGroupDetail agd  
        ON      a.ID = agd.Attribute_ID  
        WHERE   acl.User_ID = @User_ID  
            AND a.AttributeType_ID <> 3 -- System (except Name and Code)  
            AND agd.AttributeGroup_ID = @AttributeGroup_ID  
            AND a.ID = ISNULL(@Attribute_ID, a.ID)  
    END ELSE  
    BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': getting selected attributes from criteria')  
        INSERT INTO @SelectedAttribute  
        SELECT  
             a.Attribute_ID AS ID  
            ,a.Entity_ID  
            ,acl.Privilege_ID  
            ,acl.AccessPermission  
        FROM mdm.viw_SYSTEM_SCHEMA_ATTRIBUTES a  
        INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ATTRIBUTE acl  
        ON a.Attribute_ID = acl.ID  
        WHERE   acl.User_ID = @User_ID  
            AND a.Attribute_Type_ID <> 3 -- System (except Name and Code)  
            AND a.Model_ID = ISNULL(@Model_ID, a.Model_ID)  
            AND a.Entity_ID = ISNULL(@Entity_ID, a.Entity_ID)  
            AND a.Attribute_MemberType_ID = ISNULL(@MemberType_ID, a.Attribute_MemberType_ID)  
            AND a.Attribute_ID = ISNULL(@Attribute_ID, a.Attribute_ID)  
    END  
  
    IF EXISTS (SELECT 1 FROM @AttributeIds)  
    BEGIN  
        -- The caller has specified which attributes to return in a temp table  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': caller has defined #Attribute, using it to further filter selected attributes')  
  
        DELETE sa  
        FROM @SelectedAttribute sa  
        LEFT JOIN @AttributeIds a  
        ON sa.ID = a.ID  
        WHERE a.ID IS NULL  
    END  
  
    IF @IncludeParentIdentifiers = 1  
    BEGIN  
        IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': returning parent identifiers')  
        -- Return model Identifier(s)  
        IF @Model_ID IS NOT NULL  
        BEGIN  
            IF @Model_Name IS NULL OR @Model_MUID IS NULL  
            BEGIN  
                SELECT   
                     @Model_MUID = MUID  
                    ,@Model_Name = Name  
                FROM mdm.tblModel  
                WHERE ID = @Model_ID  
            END  
  
            -- A single model was specified, and its info has already been looked up, so simply return it  
            SELECT   
                 @Model_MUID    AS Model_MUID  
                ,@Model_Name    AS Model_Name  
                ,@Model_ID      AS Model_ID  
        END ELSE  
        BEGIN  
            SELECT DISTINCT  
                 m.MUID AS Model_MUID  
                ,m.Name AS Model_Name  
                ,m.ID   AS Model_ID  
            FROM @SelectedAttribute a  
            INNER JOIN mdm.tblEntity e  
            ON a.Entity_ID = e.ID  
            INNER JOIN mdm.tblModel m  
            ON e.Model_ID = m.ID  
        END  
  
        -- Return entity Identifier(s)  
        IF @Entity_ID IS NOT NULL  
        BEGIN  
            -- A single entity was specified, and its info has already been looked up, so simply return it  
            SELECT   
                 @Model_ID      AS Model_ID  
                ,@Entity_MUID   AS Entity_MUID  
                ,@Entity_Name   AS Entity_Name  
                ,@Entity_ID     AS Entity_ID  
        END ELSE  
        BEGIN  
            SELECT DISTINCT  
                 e.Model_ID AS Model_ID  
                ,e.MUID AS Entity_MUID  
                ,e.Name AS Entity_Name  
                ,e.ID   AS Entity_ID  
            FROM @SelectedAttribute a  
            INNER JOIN mdm.tblEntity e  
            ON a.Entity_ID = e.ID  
        END  
    END  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': returning attribute info')  
    SELECT  
         a.Attribute_MUID  
        ,a.Attribute_Name  
        ,a.Attribute_ID  
        ,sa.Privilege_ID  
        ,sa.AccessPermission  
  
        ,a.Attribute_MemberType_ID AS MemberType_ID  
  
        ,a.Entity_ID  
  
        ,a.Attribute_Type_ID                AS AttributeType_ID  
        ,a.Attribute_ChangeTrackingGroup    AS ChangeTrackingGroup  
        ,a.Attribute_DataType_ID            AS DataType_ID  
        ,a.Attribute_DataType_Information   AS DataTypeInformation  
        ,a.Attribute_Description            AS Description  
        ,a.Attribute_DisplayName            AS DisplayName  
        ,a.Attribute_DisplayWidth           AS DisplayWidth  
  
        ,NULLIF(a.Attribute_DBAEntity_MUID, 0x0)    AS DomainEntity_MUID  
        ,NULLIF(a.Attribute_DBAEntity_Name, N'')    AS DomainEntity_Name  
        ,NULLIF(a.Attribute_DBAEntity_ID, 0)        AS DomainEntity_ID  
        ,CONVERT(BIT, a.Attribute_DBAEntity_IsHierarchyEnabled)         AS DomainEntity_IsHierarchyEnabled  
        ,CONVERT(TINYINT, COALESCE(DBAMemberTypeSec.Privilege_ID, 0))   AS DomainEntity_Privilege_ID  
        ,CONVERT(TINYINT, DBAMemberTypeSec.AccessPermission)            AS DomainEntity_AccessPermission -- We use memberType leaf effective permission instead of entity effective permission  
  
        ,NULLIF(a.FilterParentHierarchy_MUID, 0x0)  AS FilterParentHierarchy_MUID  
        ,NULLIF(a.FilterParentHierarchy_Name, N'')  AS FilterParentHierarchy_Name  
        ,NULLIF(a.FilterParentHierarchy_ID, 0)      AS FilterParentHierarchy_ID  
        ,NULLIF(a.FilterParentHierarchy_LevelNumber, -1)    AS FilterParentHierarchy_LevelNumber  
        ,NULLIF(a.FilterParentAttribute_MUID, 0x0)  AS FilterParentAttribute_MUID  
        ,NULLIF(a.FilterParentAttribute_Name, N'')  AS FilterParentAttribute_Name  
        ,NULLIF(a.FilterParentAttribute_ID, 0)      AS FilterParentAttribute_ID  
  
        ,a.Attribute_DataMask_Name      AS InputMask_Name  
        ,a.Attribute_DataMask_ID        AS InputMask_ID  
        ,a.Attribute_IsReadOnly         AS IsReadOnly -- Always 0? Except for LevelNumber (MemberType 4)  
        ,a.Attribute_IsSystem           AS IsSystem  
        ,a.Attribute_SortOrder          AS SortOrder  
  
        ,a.EnteredUser_DTM  
        ,a.EnteredUser_MUID  
        ,a.EnteredUser_UserName  
        ,a.EnteredUser_ID  
        ,a.LastChgUser_DTM  
        ,a.LastChgUser_MUID  
        ,a.LastChgUser_UserName  
        ,a.LastChgUser_ID  
    FROM @SelectedAttribute sa  
    INNER JOIN mdm.viw_SYSTEM_SCHEMA_ATTRIBUTES a  
    ON sa.ID = a.Attribute_ID  
    LEFT JOIN mdm.viw_SYSTEM_SECURITY_USER_MEMBERTYPE DBAMemberTypeSec  
    ON      a.Attribute_DBAEntity_ID = DBAMemberTypeSec.Entity_ID   
        AND DBAMemberTypeSec.ID = 1 -- DBA always reference leaf  
        AND DBAMemberTypeSec.User_ID = @User_ID  
    ORDER BY   
         a.Model_ID  
        ,a.Entity_ID  
        ,a.Attribute_MemberType_ID  
        ,a.Attribute_SortOrder  
        ,a.Attribute_ID  
  
    IF @Debug = 1 PRINT CONCAT(SYSDATETIME(), ': end udpAttributeGet')  
  
    SET NOCOUNT OFF  
END --proc
go

