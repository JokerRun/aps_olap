/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Helper method called by udpMetadataSave and udpAttributeChange that looks up attribute filter IDs and loads them into the temp table,  
#AttributesToProcess, that is defined there.   
  
Note: Because this sproc references a temp table that is defined elsewhere, had to suppress on this file TSQL warning 71502.  
*/  
CREATE PROCEDURE mdm.udpMetadataSaveHelper_LookupAttributeFilterIds  
(  
    @AttributeFilters       mdm.AttributeFilter READONLY  
)  
AS BEGIN  
  
    DECLARE  
         @HierarchyItemType_DBA         TINYINT = 1  
        ,@HierarchyItemType_ManyToMany  TINYINT = 5  
  
        ,@MemberType_Leaf               TINYINT = 1  
    /*  
    -- schema of temp table defined in caller (udpMetadataSave). In it useful to uncomment this when modifying the below query, to enable intellisense.  
    CREATE TABLE #AttributesToProcess  
    (  
        Row_ID              INT NOT NULL PRIMARY KEY,  
        Model_ID            INT NULL,  
        Model_MUID          UNIQUEIDENTIFIER NULL,  
        ModelName           NVARCHAR(50) COLLATE DATABASE_DEFAULT NULL,  
        Version_ID          INT NULL,  
        Entity_ID           INT NULL,  
        Entity_MUID         UNIQUEIDENTIFIER NULL,  
        EntityName          NVARCHAR(50) COLLATE DATABASE_DEFAULT NULL,  
        IsHierarchyEnabled  BIT NULL,  
        IsCollectionEnabled BIT NULL,  
        DataCompression     TINYINT NULL,  
        TableName           SYSNAME NULL,  
        StagingTableName    SYSNAME NULL,  
        MemberType_ID       TINYINT NOT NULL,  
        ID                  INT NULL,  
        MUID                UNIQUEIDENTIFIER NULL,  
        Name                NVARCHAR(100) COLLATE DATABASE_DEFAULT NOT NULL,  
        [Description]       NVARCHAR(500) COLLATE DATABASE_DEFAULT NULL,  
        AttributeType_ID    TINYINT NULL,  
        DisplayName         NVARCHAR(250) COLLATE DATABASE_DEFAULT NULL,  
        DisplayWidth        INT NOT NULL,  
        DomainEntity_ID     INT NULL,  
        FilterParentAttribute_ID    INT NULL,  
        FilterHierarchyDetail_ID    INT NULL,  
        DataType_ID         TINYINT NULL,  
        DataTypeInformation INT NULL,  
        InputMask_ID        INT NULL,  
        ChangeTrackingGroup INT DEFAULT 0,  
        SortOrder           INT NULL,  
        DidNameChange       BIT NULL,  
        Error               NVARCHAR(MAX) COLLATE DATABASE_DEFAULT NULL  
    );  
    --*/  
  
    UPDATE atp  
    SET  
        FilterParentAttribute_ID = filterParent.ID,  
        FilterHierarchyDetail_ID = dhl.ID,  
        Error = CASE   
            WHEN Error IS NOT NULL                                      THEN Error -- Don't overwrite an existing error message  
            WHEN atp.MemberType_ID <> @MemberType_Leaf                  THEN N'MDSERR200114|The attribute cannot be saved. An attribute filter can only be added to a leaf attribute.'  
            WHEN atp.DomainEntity_ID IS NULL                            THEN N'MDSERR200115|The attribute cannot be saved. An attribute filter can only be added to a domain-based attribute.'  
            WHEN filterParent.ID IS NULL   
                OR atp.ID = filterParent.ID /*Cannot filter itself*/    THEN N'MDSERR200116|The attribute cannot be saved. The attribute filter parent is not valid.'  
            WHEN filterParent.DomainEntity_ID IS NULL                   THEN N'MDSERR200118|The attribute cannot be saved. The attribute filter parent must be a domain-based attribute.'  
  
            WHEN filterHierarchy.ID IS NULL                             THEN N'MDSERR200119|The attribute cannot be saved. The attribute filter hierarchy is not valid.'  
  
            WHEN dhl.ID IS NULL                                         THEN N'MDSERR200120|The attribute cannot be saved. The attribute filter hierarchy level is not valid.'  
            WHEN dhl.ForeignType_ID NOT IN   
                (@HierarchyItemType_DBA, @HierarchyItemType_ManyToMany) THEN N'MDSERR200121|The attribute cannot be saved. The attribute filter hierarchy level type must be Domain or ManyToMany.'  
            WHEN dhl.Entity_ID <> filterParent.DomainEntity_ID          THEN N'MDSERR200122|The attribute cannot be saved. The attribute filter hierarchy level entity must be the parent attribute domain entity.'  
            WHEN atp.DomainEntity_ID <> COALESCE(m2mChild.DomainEntity_ID, dhl.ForeignEntity_ID)    
                                                                        THEN N'MDSERR200123|The attribute cannot be saved. The filter hierarchy child level entity must be the same as the attribute domain entity.'  
            WHEN dhl.IsLevelVisible = 0                                 THEN N'MDSERR200125|The attribute cannot be saved. The attribute filter hierarchy level must be visible.'  
            END  
    FROM @AttributeFilters af  
    INNER JOIN #AttributesToProcess atp -- temp table defined in caller (udpMetadataSave)  
    ON af.AttributeRow_ID = atp.Row_ID  
    -- Note: looking up ids in a batch here is more efficient that doing it one row at a time in updAttributeSave  
    LEFT JOIN mdm.tblAttribute filterParent  
    ON      (af.ParentAttribute_MUID IS NOT NULL OR af.ParentAttributeName IS NOT NULL)  
        AND (af.ParentAttribute_MUID IS NULL OR af.ParentAttribute_MUID = filterParent.MUID)  
        AND (af.ParentAttributeName  IS NULL OR af.ParentAttributeName  = filterParent.Name)  
        AND atp.Entity_ID = filterParent.Entity_ID  
        AND atp.MemberType_ID = filterParent.MemberType_ID  
    LEFT JOIN mdm.tblDerivedHierarchy filterHierarchy  
    ON      (af.Hierarchy_MUID IS NOT NULL OR af.HierarchyName IS NOT NULL)  
        AND (af.Hierarchy_MUID IS NULL OR af.Hierarchy_MUID = filterHierarchy.MUID)  
        AND (af.HierarchyName  IS NULL OR af.HierarchyName  = filterHierarchy.Name)  
        AND atp.Model_ID = filterHierarchy.Model_ID  
    LEFT JOIN mdm.viw_SYSTEM_SCHEMA_HIERARCHY_DERIVED_LEVELS dhl  
    ON      filterHierarchy.ID = dhl.Hierarchy_ID  
        AND af.HierarchyLevelNumber = dhl.LevelNumber  
    LEFT JOIN mdm.tblAttribute m2mChild  
    ON  dhl.ManyToManyChildAttribute_ID = m2mChild.ID  
END
go

