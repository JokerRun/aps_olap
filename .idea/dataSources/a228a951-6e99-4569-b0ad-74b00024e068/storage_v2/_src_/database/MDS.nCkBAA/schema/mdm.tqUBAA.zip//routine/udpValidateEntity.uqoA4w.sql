/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
EXEC mdm.udpValidateEntity 1, 20, 32  
*/  
CREATE PROCEDURE mdm.udpValidateEntity  
(  
   @User_ID        INT,      
   @Version_ID  INT,      
   @Entity_ID      INT,      
   @RunSingleBatch BIT = 0,      
   @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability      
)      
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN      
    SET NOCOUNT ON      
      
    DECLARE @entityTableName        sysname;      
    DECLARE @IsHierarchyEnabled     INT;      
    DECLARE @parentChildView        sysname;      
    DECLARE @sql                    NVARCHAR(MAX);      
      
    DECLARE @tblHierarchy           TABLE (HierarchyID INT);      
    DECLARE @Hierarchy_ID           INT;      
    DECLARE @BatchSize              NVARCHAR(10) = '200000';      
    DECLARE @Model_ID               INT;      
    DECLARE @EventStatus_Running    TINYINT = 1;      
    DECLARE @EventStatus_NotRunning TINYINT = 2;    
    
    BEGIN TRY      
        IF EXISTS (SELECT 1 FROM mdm.tblSyncRelationship WHERE TargetEntity_ID = @Entity_ID AND TargetVersion_ID = @Version_ID)  
        BEGIN  
            RAISERROR (N'MDSERR200226|The entity version cannot be validated. It is the target of a sync relationship.', 16, 1);  
            RETURN;  
        END  
  
        -- Store validation entity event      
        SELECT @Model_ID = Model_ID FROM [mdm].tblEntity WHERE ID = @Entity_ID;  
          
        EXEC [mdm].udpSystemEventSave @User_ID=@User_ID,@Version_ID=@Version_ID,@Entity_ID=@Entity_ID,@EventName=N'ValidateEntity',@EventStatus_ID=@EventStatus_Running      
      
        SET @RunSingleBatch = COALESCE(@RunSingleBatch, 0);      
      
        SELECT      
            @entityTableName = QUOTENAME(EntityTable),      
            @IsHierarchyEnabled = CASE WHEN HierarchyTable IS NULL THEN 0 ELSE 1 END      
        FROM mdm.tblEntity      
        WHERE ID = @Entity_ID;      
      
        --Calculate the level number for the corresponding hierarchies within the version and entities.      
        INSERT INTO @tblHierarchy SELECT ID FROM mdm.tblHierarchy WHERE Entity_ID = @Entity_ID;      
      
        WHILE EXISTS(SELECT 1 FROM @tblHierarchy)      
        BEGIN      
            SET @Hierarchy_ID = (SELECT TOP 1 HierarchyID FROM @tblHierarchy);      
      
            --Recalculate system hierarchy attributes (level number, sort order, and index code)      
            EXEC mdm.udpHierarchySystemAttributesSave @Version_ID, @Hierarchy_ID;      
      
            DELETE FROM @tblHierarchy WHERE HierarchyID = @Hierarchy_ID;      
        END      
      
        --Validate the Member Type 2s (HP), hierarchy parent, if needed.      
        --These must be validated before Type 1s because of possible hierarchy parent inheritance business rules.      
        IF @IsHierarchyEnabled = 1      
        BEGIN      
            SELECT @parentChildView = QUOTENAME(mdm.udfViewNameGetByID(@Entity_ID, 4, 0, 0));      
      
            SELECT @sql = N'      
                DECLARE @MemberIdList              AS mdm.IdList;      
                DECLARE @MemberType_Consolidated   TINYINT = 2;      
      
                WHILE (1 = 1)      
                BEGIN      
                    INSERT INTO @MemberIdList (ID)      
                        SELECT TOP ' + @BatchSize + N' Child_ID      
                        FROM mdm.' + @parentChildView + N'      
                        WHERE Version_ID = @Version_ID      
                            AND Child_ValidationStatus_ID IN (SELECT OptionID FROM mdm.tblList WHERE ListCode = N''lstValidationStatus'' AND Group_ID = 1)      
                            AND ChildType_ID = 2;      
      
                    IF (@@ROWCOUNT = 0)      
                    BEGIN      
                        BREAK;          
                    END;      
      
                    EXEC mdm.udpValidateMembers @User_ID=@User_ID, @Version_ID=@Version_ID, @Entity_ID=@Entity_ID, @MemberIdList=@MemberIdList, @MemberType_ID=@MemberType_Consolidated, @ProcessUIRulesOnly=0, @ReturnChangedIds=0;      
      
                    DELETE FROM @MemberIdList;      
      
                    IF @RunSingleBatch = 1      
                    BEGIN      
                        BREAK;      
                    END;      
                END;';      
            --print @sql;      
            EXEC sp_executesql @sql, N'@User_ID INT,    @Version_ID INT,    @Entity_ID INT, @RunSingleBatch BIT',       
                                       @User_ID,        @Version_ID,        @Entity_ID,     @RunSingleBatch;      
        END      
      
        --Validate the Member Type 1s (EN), leaf      
        SELECT @sql = N'      
                DECLARE @MemberIdList           AS mdm.IdList;      
                DECLARE @EventStatus_NotRunning TINYINT = 2;      
                DECLARE @MemberType_Leaf        TINYINT = 1;      
      
                WHILE (1 = 1)      
                BEGIN      
                    INSERT INTO @MemberIdList (ID)      
                        SELECT TOP ' + @BatchSize + N' ID      
                        FROM mdm.' + @entityTableName + N'      
                        WHERE Status_ID = 1      
                          AND Version_ID = @Version_ID      
                          AND ValidationStatus_ID IN (SELECT OptionID FROM mdm.tblList WHERE ListCode = N''lstValidationStatus'' AND Group_ID = 1);      
      
                    IF (@@ROWCOUNT = 0)      
                    BEGIN      
                        EXEC [mdm].udpSystemEventSave @User_ID=@User_ID,@Version_ID=@Version_ID,@Entity_ID=@Entity_ID,@EventName=N''ValidateEntity'',@EventStatus_ID=@EventStatus_NotRunning      
                        BREAK;      
                    END;      
      
                    EXEC mdm.udpValidateMembers @User_ID=@User_ID, @Version_ID=@Version_ID, @Entity_ID=@Entity_ID, @MemberIdList=@MemberIdList, @MemberType_ID=@MemberType_Leaf, @ProcessUIRulesOnly=0, @ReturnChangedIds=0;      
      
                    DELETE FROM @MemberIdList;      
      
                    IF @RunSingleBatch = 1      
                    BEGIN      
                        BREAK;      
                    END;      
                END;';      
        --print @sql;      
        EXEC sp_executesql @sql, N'@User_ID INT,    @Version_ID INT,    @Entity_ID INT, @RunSingleBatch BIT',       
                                   @User_ID,        @Version_ID,        @Entity_ID,     @RunSingleBatch;      
    END TRY      
    --Compensate as necessary      
    BEGIN CATCH      
      
        -- Get error info.      
        DECLARE      
            @ErrorMessage NVARCHAR(4000),      
            @ErrorSeverity INT,      
            @ErrorState INT,      
            @ErrorNumber INT,      
            @ErrorLine INT,      
            @ErrorProcedure NVARCHAR(126);      
        EXEC mdm.udpGetErrorInfo      
            @ErrorMessage = @ErrorMessage OUTPUT,      
            @ErrorSeverity = @ErrorSeverity OUTPUT,      
            @ErrorState = @ErrorState OUTPUT,      
            @ErrorNumber = @ErrorNumber OUTPUT,      
            @ErrorLine = @ErrorLine OUTPUT,      
            @ErrorProcedure = @ErrorProcedure OUTPUT      
            
        -- Save the error message and change the event status    
    
        EXEC [mdm].udpSystemEventSave     
            @User_ID=@User_ID,    
            @Version_ID=@Version_ID,    
            @Entity_ID=@Entity_ID,    
            @EventName=N'ValidateEntity',    
            @EventStatus_ID=@EventStatus_NotRunning,    
            @CorrelationID = @CorrelationID,    
            @ErrorMsg = @ErrorMessage    
          
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);      
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);      
      
        
      
    END CATCH;     
    SET NOCOUNT OFF;      
END; --proc
go

