/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
SELECT mdm.udfUseMemberSecurity(65,1,null,23,1,298)  
*/  
CREATE FUNCTION mdm.udfUseMemberSecurity  
(  
    @User_ID            INT,  
    @Entity_ID          INT,  
    @Version_ID         INT,  
    @MemberType_ID      TINYINT = NULL  
)   
RETURNS BIT  
/*WITH SCHEMABINDING*/  
AS BEGIN  
    DECLARE @Ret                                    BIT = 0,  
            @MemberType_Leaf                        TINYINT = 1,  
            @MemberType_Consolidated                TINYINT = 2,  
            @MemberType_Collection                  TINYINT = 3;  
  
    IF @MemberType_ID = @MemberType_Collection  
    BEGIN  
        SET @Ret = 0;  
    END  
    ELSE IF EXISTS(  
        SELECT 1  
        FROM mdm.viw_SYSTEM_SECURITY_USER_ENTITY  
        WHERE [User_ID] = @User_ID  
            AND ID = @Entity_ID  
            AND Privilege_ID = 5 /*Admin*/)  
    BEGIN  
        SET @Ret = 0;  
    END  
    ELSE IF EXISTS(  
        SELECT 1  
        FROM mdm.viw_SYSTEM_SECURITY_ROLE_MEMBER srm  
        INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ROLE ur  
        ON ur.Role_ID = srm.Role_ID  
        WHERE srm.IsInitialized != 0  
            AND srm.Version_ID = @Version_ID  
            AND ur.[User_ID] = @User_ID  
            AND srm.[Entity_ID] = @Entity_ID  
            AND (@MemberType_ID IS NULL OR @MemberType_ID = @MemberType_Leaf OR LeafOnly != 1))  
    BEGIN  
        SET @Ret = 1;  
    END  
    ELSE  
    BEGIN  
        SET @Ret = 0;  
    END  
    RETURN @Ret;  
END
go

