/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Returns all sync relationships, filtered by the given user's permissions.  
*/  
CREATE PROCEDURE mdm.udpSyncRelationshipsGet  
(  
     @User_ID           INT -- -- Must have permission to see source and target entities  
    ,@CorrelationID     UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS  
BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE @PermissionType_Deny TINYINT = 1;  
  
    SELECT  
         sm.ID SourceModel_ID  
        ,sm.MUID SourceModel_MUID  
        ,sm.Name SourceModelName  
  
        ,sr.SourceVersion_ID  
        ,sv.MUID SourceVersion_MUID  
        ,sv.Name SourceVersionName  
  
        ,sr.SourceEntity_ID  
        ,se.MUID SourceEntity_MUID  
        ,se.Name SourceEntity_Name  
      
        ,tm.ID TargetModel_ID  
        ,tm.MUID TargetModel_MUID  
        ,tm.Name TargetModelName  
  
        ,sr.TargetVersion_ID  
        ,tv.MUID TargetVersion_MUID  
        ,tv.Name TargetVersionName  
  
        ,sr.TargetEntity_ID  
        ,te.MUID TargetEntity_MUID  
        ,te.Name TargetEntityName  
  
        --,sr.TargetEntityNameIsAliased  
        ,sr.RefreshFrequencyInHours  
  
        ,sr.LastSuccessfulSyncDTM  
        ,sr.LastSyncAttemptDTM  
        ,sr.LastSyncAttemptStatus  
        ,sr.LastSyncAttemptErrorInfo  
  
        ,sr.EnterDTM  
        ,sr.EnterUserID  
        ,eu.MUID EnterUserMUID  
        ,eu.UserName EnterUserName  
        ,sr.LastChgDTM  
        ,sr.LastChgUserID  
        ,lcu.MUID LastChgUserMUID  
        ,lcu.UserName LastChgUserName  
        --,LastChgTS  
  
    FROM mdm.tblSyncRelationship sr  
    INNER JOIN mdm.tblModelVersion sv  
    ON sr.SourceVersion_ID = sv.ID  
    INNER JOIN mdm.tblModel sm  
    ON sv.Model_ID = sm.ID  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ENTITY ses  
    ON      sr.SourceEntity_ID = ses.ID  
        AND ses.User_ID = @User_ID  
        AND ses.Privilege_ID > @PermissionType_Deny  
    INNER JOIN mdm.tblEntity se  
    ON sr.SourceEntity_ID = se.ID  
    INNER JOIN mdm.tblModelVersion tv  
    ON sr.TargetVersion_ID = tv.ID  
    INNER JOIN mdm.tblModel tm  
    ON tv.Model_ID = tm.ID  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ENTITY tes  
    ON  sr.TargetEntity_ID = tes.ID  
        AND tes.User_ID = @User_ID  
        AND tes.Privilege_ID > @PermissionType_Deny  
    INNER JOIN mdm.tblEntity te  
    ON sr.TargetEntity_ID = te.ID  
    LEFT JOIN mdm.tblUser eu  
    ON sr.EnterUserID = eu.ID  
    LEFT JOIN mdm.tblUser lcu  
    ON sr.LastChgUserID = lcu.ID  
  
  
    SET NOCOUNT OFF;  
END -- Proc
go

