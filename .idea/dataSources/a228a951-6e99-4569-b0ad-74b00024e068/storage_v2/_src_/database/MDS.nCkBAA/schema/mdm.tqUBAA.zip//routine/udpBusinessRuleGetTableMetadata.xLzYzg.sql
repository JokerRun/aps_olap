/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    EXEC mdm.udpBusinessRuleGetTableMetadata 1,1,31  
    EXEC mdm.udpBusinessRuleGetTableMetadata 1,2,31  
*/  
CREATE PROCEDURE mdm.udpBusinessRuleGetTableMetadata  
(  
     @Entity_ID      INT  
    ,@MemberType_ID  TINYINT  
    ,@CorrelationID  UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    DECLARE  
        @FactTableName              SYSNAME,  
        @ParentFactTableName        SYSNAME,  
        @PublishableStatus          mdm.IdList,  
        @ChangeValueActions         mdm.IdList,  
        @RecursiveInheritanceAttributes mdm.IdList,  
        @AttributeProperty          INT = 2,  
        @DbaAttributeProperty       INT = 4,  
        @ParentAttributeProperty    INT = 3,  
        @ValuePropertyName_ID       INT = 1,  
  
        @MemberType_Leaf           TINYINT = 1,  
        @MemberType_Consolidated   TINYINT = 2,  
  
        @Model_ID                   INT,  
        @ValidationLogTableName     SYSNAME,  
        @ValidationLogViewName      SYSNAME;  
  
    SET @FactTableName = mdm.udfViewNameGetByID(@Entity_ID, @MemberType_ID, 0, 0)  
    SET @ParentFactTableName = mdm.udfViewNameGetByID(@Entity_ID, @MemberType_Consolidated, 0, 0)  
  
    INSERT INTO @PublishableStatus (ID)  
        SELECT OptionID FROM mdm.tblList  
        WHERE ListCode = CAST(N'lstBRStatus' AS NVARCHAR(50)) AND Group_ID = 1  -- Group_ID = 1 indicates publishable.  
  
  
    INSERT INTO @ChangeValueActions (ID)  
        SELECT AppliesTo_ID FROM mdm.viw_SYSTEM_SCHEMA_BUSINESSRULE_ITEMTYPES WHERE ApplyToCategoryID = 2/*BRItemTypeCategory*/ AND BRTypeID = 2/*Actions*/ AND (BRSubTypeID = 2/*Default value*/ OR BRSubTypeID = 3/*Change value*/)  
  
    INSERT INTO @RecursiveInheritanceAttributes  
        SELECT DISTINCT Attribute_ID FROM (  
            SELECT BusinessRule_ID, Attribute_ID  
            FROM mdm.viw_SYSTEM_SCHEMA_BUSINESSRULE_PROPERTIES_ATTRIBUTES a  
            INNER JOIN @PublishableStatus ps ON a.BusinessRule_Status = ps.ID  
            INNER JOIN @ChangeValueActions cva ON a.Item_AppliesTo_ID = cva.ID  
            WHERE   a.Attribute_Entity_ID = @Entity_ID  
                AND a.Attribute_MemberType_ID = @MemberType_Consolidated  
                AND a.Property_IsLeftHandSide = 1  
            INTERSECT  
            SELECT BusinessRule_ID, Attribute_ID  
            FROM mdm.viw_SYSTEM_SCHEMA_BUSINESSRULE_PROPERTIES_ATTRIBUTES a  
            INNER JOIN @PublishableStatus ps ON a.BusinessRule_Status = ps.ID  
            INNER JOIN @ChangeValueActions cva ON a.Item_AppliesTo_ID = cva.ID  
            WHERE   a.Attribute_Entity_ID = @Entity_ID  
                AND a.Attribute_MemberType_ID = @MemberType_Consolidated  
                AND a.Property_IsLeftHandSide = 0  
                AND a.Property_Parent_PropertyType_ID = @ParentAttributeProperty  
        ) r  
  
    --Get the model ID  
    SELECT @Model_ID = Model_ID  
    FROM mdm.tblEntity  
    WHERE ID = @Entity_ID;  
  
    --Get validation log table and view names  
    SET @ValidationLogTableName = mdm.udfGetValidationLogTableName(@Model_ID);  
    SET @ValidationLogViewName = mdm.udfGetValidationLogViewName(@Model_ID);  
  
    /* FACT TABLE */ -- This will only ever return one row, for the specified entity member type  
    SELECT  
         @Entity_ID AS ID  
        ,@FactTableName AS [Name]  
        ,N'' AS ColumnPrefix  
        ,@MemberType_ID AS MemberTypeID  
        ,N'Fact' AS Type  
        ,N'fact' AS Alias  
        ,N'' AS JoinTableName  
        ,N'' AS JoinTableColumn  
        ,N'' AS JoinTableAlias  
        ,CASE @MemberType_ID  
            WHEN @MemberType_Leaf THEN EntityTable  
            WHEN @MemberType_Consolidated THEN HierarchyParentTable  
         END AS PhysicalTableName  
        ,CASE @MemberType_ID  
            WHEN @MemberType_Leaf THEN StagingLeafName  
            WHEN @MemberType_Consolidated THEN StagingConsolidatedName  
         END AS StagingName  
        ,@ValidationLogTableName AS ValidationLogTableName  
        ,@ValidationLogViewName AS ValidationLogViewName  
        ,CASE @MemberType_ID  
            WHEN @MemberType_Leaf THEN EntityTable + N'_AN'  
            WHEN @MemberType_Consolidated THEN HierarchyParentTable + N'_AN'  
         END AS AnnotationTableName  
    FROM mdm.tblEntity  
    WHERE ID = @Entity_ID;  
  
    /* FACT TABLE ATTRIBUTES */  
    SELECT DISTINCT  
        @Entity_ID AS ParentFactID,  
        col.COLUMN_NAME As [Name],  
        a.DisplayName,  
        a.ID AS TableColumnID,  
        a.AttributeType_ID AS AttributeTypeID,  
        a.DomainEntity_ID AS DomainEntityID,  
        CASE WHEN dbaRefresh.Attribute_ID IS NULL THEN 0 ELSE 1 END AS IsDomainEntityRefreshRequired,  
        CASE WHEN recur.ID IS NULL THEN 0 ELSE 1 END AS IsRecursiveInheritance,  
        a.SortOrder AS Ordinal,  
        col.DATA_TYPE AS SQLType,  
        CASE col.CHARACTER_MAXIMUM_LENGTH WHEN -1 THEN N'MAX' ELSE CONVERT(NVARCHAR(MAX), col.CHARACTER_MAXIMUM_LENGTH) END AS MaxLength,  
        col.NUMERIC_PRECISION AS NumericPrecision,  
        col.NUMERIC_SCALE AS NumericScale  
    FROM mdm.tblBRItemProperties p  
    LEFT JOIN mdm.tblBRItemProperties pp ON  
        p.Parent_ID =  pp.ID  
    INNER JOIN mdm.tblBRItem i ON  
        p.BRItem_ID = i.ID  
    INNER JOIN mdm.tblBRLogicalOperatorGroup g ON  
        i.BRLogicalOperatorGroup_ID = g.ID  
    INNER JOIN mdm.tblBRBusinessRule br ON  
        g.BusinessRule_ID = br.ID  
    INNER JOIN @PublishableStatus ps  
        ON br.Status_ID = ps.ID  
    INNER JOIN mdm.tblAttribute a ON  
        a.ID = cast(p.[Value] AS INT) and  
        p.PropertyType_ID IN (@AttributeProperty, @DbaAttributeProperty) and  
        (p.Parent_ID is null  OR pp.PropertyType_ID = 8)  
    INNER JOIN INFORMATION_SCHEMA.COLUMNS col ON  
        col.TABLE_NAME = @FactTableName AND col.TABLE_SCHEMA = 'mdm' AND col.COLUMN_NAME = a.Name COLLATE database_default  
    LEFT JOIN (  
        -- Find any DBAs that are getting set (left-hand side) and their attributes are referenced in the right-hand side of other rules  
        -- These DBA attribute values will need to be refreshed during business rule processing.  
        -- Find the DBAs getting set  
        SELECT Attribute_ID  
        FROM mdm.viw_SYSTEM_SCHEMA_BUSINESSRULE_PROPERTIES_ATTRIBUTES a  
        INNER JOIN @PublishableStatus ps ON a.BusinessRule_Status = ps.ID  
        INNER JOIN @ChangeValueActions cva ON a.Item_AppliesTo_ID = cva.ID  
        WHERE  
            a.Attribute_Entity_ID = @Entity_ID  
        AND a.Attribute_MemberType_ID = @MemberType_ID  
        AND a.Attribute_DBAEntity_ID IS NOT NULL  
        AND a.Property_IsLeftHandSide = 1  
        INTERSECT  
        -- Find the DBA attribute values being referenced.  
        SELECT Attribute_ID  
        FROM mdm.viw_SYSTEM_SCHEMA_BUSINESSRULE_PROPERTIES_ATTRIBUTES a  
        INNER JOIN @PublishableStatus ps ON a.BusinessRule_Status = ps.ID  
        INNER JOIN @ChangeValueActions cva ON a.Item_AppliesTo_ID = cva.ID  
        WHERE  
            a.Attribute_Entity_ID = @Entity_ID  
        AND a.Attribute_MemberType_ID = @MemberType_ID  
        AND a.Attribute_DBAEntity_ID IS NOT NULL  
        AND a.Property_IsLeftHandSide = 0  
        AND a.Property_Parent_ID IS NULL  
        AND a.PropertyType_ID = @DbaAttributeProperty  
    ) dbaRefresh  
    ON a.ID = dbaRefresh.Attribute_ID  
    LEFT JOIN @RecursiveInheritanceAttributes recur  
        ON a.ID = recur.ID  
    WHERE   br.Entity_ID = @Entity_ID  
        AND br.MemberType_ID = @MemberType_ID  
  
    UNION -- not UNION ALL because deduplication is needed  
    --Ensure the Code attribute is returned  
    SELECT DISTINCT  
        @Entity_ID AS ParentFactID,  
        col.COLUMN_NAME AS [Name],  
        a.DisplayName,  
        a.ID AS TableColumnID,  
        a.AttributeType_ID AS AttributeTypeID,  
        a.DomainEntity_ID AS DomainEntityID,  
        0 AS IsDomainEntityRefreshRequired,  
        0 AS IsRecursiveInheritance,  
        a.SortOrder AS Ordinal,  
        col.DATA_TYPE AS SQLType,  
        CASE col.CHARACTER_MAXIMUM_LENGTH WHEN -1 THEN N'MAX' ELSE CONVERT(NVARCHAR(MAX), col.CHARACTER_MAXIMUM_LENGTH) END AS MaxLength,  
        col.NUMERIC_PRECISION AS NumericPrecision,  
        col.NUMERIC_SCALE AS NumericScale  
    FROM mdm.tblAttribute a  
    INNER JOIN INFORMATION_SCHEMA.COLUMNS col  
    ON      a.Entity_ID = @Entity_ID  
        AND a.MemberType_ID = @MemberType_ID  
        AND a.Name = 'Code'  
        AND col.TABLE_NAME = @FactTableName  
        AND col.TABLE_SCHEMA = 'mdm'  
        AND col.COLUMN_NAME = a.Name COLLATE database_default  
    ORDER BY  
        a.SortOrder;  
  
    /* DBA SUPPORTING FACT TABLES */  
    SELECT DISTINCT  
         e.ID  
        ,mdm.udfViewNameGetByID(DomainEntity_ID, @MemberType_Leaf, 0, 0) AS [Name]  
        ,N'DBA.' + a.Name AS ColumnPrefix  
        ,@MemberType_Leaf AS MemberTypeID  
        ,N'SupportingFactDBA' AS Type  
        ,N'[dba' + a.Name + N']' AS Alias  
        ,@FactTableName AS JoinTableName  
        ,a.Name AS JoinTableColumn  
        ,N'fact' AS JoinTableAlias  
        ,mdm.udfTableNameGetByID(DomainEntity_ID, @MemberType_Leaf) AS PhysicalTableName  
    FROM mdm.tblBRItemProperties p  
    LEFT JOIN mdm.tblBRItemProperties pp ON  
        p.Parent_ID =  pp.ID  
    INNER JOIN mdm.tblBRItem i  
    ON p.BRItem_ID = i.ID  
    INNER JOIN mdm.tblBRLogicalOperatorGroup g  
    ON i.BRLogicalOperatorGroup_ID = g.ID  
    INNER JOIN mdm.tblBRBusinessRule br  
    ON g.BusinessRule_ID = br.ID  
    INNER JOIN @PublishableStatus ps  
    ON br.Status_ID = ps.ID  
    INNER JOIN mdm.tblAttribute a  
    ON      p.[Value] = CONVERT(NVARCHAR, a.ID)  
        AND p.PropertyType_ID = @DbaAttributeProperty  
        AND (p.Parent_ID is null  OR pp.PropertyType_ID = 8) --No parent or the parent is UserDefinedScript  
    INNER JOIN mdm.tblEntity e  
    ON a.DomainEntity_ID = e.ID  
    WHERE   br.Entity_ID = @Entity_ID  
        AND br.MemberType_ID = @MemberType_ID  
    ORDER BY [Type];  
  
    /* DBA SUPPORTING FACT TABLE ATTRIBUTES */  
    SELECT DISTINCT  
        a.Entity_ID AS ParentFactID,  
        col.COLUMN_NAME As [Name],  
        a.DisplayName,  
        a.ID AS TableColumnID,  
        a.AttributeType_ID AS AttributeTypeID,  
        a.DomainEntity_ID AS DomainEntityID,  
        0 AS IsDomainEntityRefreshRequired,  
        0 AS IsRecursiveInheritance,  
        a.SortOrder AS Ordinal,  
        col.DATA_TYPE AS SQLType,  
        col.CHARACTER_MAXIMUM_LENGTH AS MaxLength,  
        col.NUMERIC_PRECISION AS NumericPrecision,  
        col.NUMERIC_SCALE AS NumericScale  
    FROM mdm.tblBRItemProperties p  
    INNER JOIN mdm.tblBRItem i  
    ON p.BRItem_ID = i.ID  
    INNER JOIN mdm.tblBRLogicalOperatorGroup g  
    ON i.BRLogicalOperatorGroup_ID = g.ID  
    INNER JOIN mdm.tblBRBusinessRule br  
    ON g.BusinessRule_ID = br.ID  
    INNER JOIN @PublishableStatus ps  
    ON br.Status_ID = ps.ID  
    INNER JOIN mdm.tblAttribute a  
    ON      p.[Value] = CONVERT(NVARCHAR, a.ID)  
        AND p.PropertyType_ID = @AttributeProperty  
        AND p.Parent_ID IS NOT NULL  
    INNER JOIN mdm.tblBRItemProperties p_dba  
    ON      p.Parent_ID = p_dba.ID  
        AND p_dba.PropertyType_ID = @DbaAttributeProperty  
    INNER JOIN INFORMATION_SCHEMA.COLUMNS col  
    ON      col.TABLE_NAME = mdm.udfViewNameGetByID(a.Entity_ID, @MemberType_Leaf, 0, 0)  
        AND col.TABLE_SCHEMA = 'mdm'  
        AND col.COLUMN_NAME = a.Name COLLATE database_default  
    WHERE   br.Entity_ID = @Entity_ID  
        AND br.MemberType_ID = @MemberType_ID  
    ORDER BY  
        ParentFactID, a.SortOrder;  
  
    /* PARENT (HIERARCHY) SUPPORTING FACT TABLES */  
    SELECT DISTINCT  
         h.ID  
        ,@ParentFactTableName AS [Name]  
        ,N'Parent.' + h.Name AS ColumnPrefix  
        ,@MemberType_Consolidated AS MemberTypeID  
        ,N'SupportingFactParent' AS Type  
        ,N'[hp' + h.Name + N']' AS Alias  
        ,mdm.udfTableNameGetByID(@Entity_ID, 4) AS JoinTableName  
        ,N'' AS JoinTableColumn  
        ,N'hr' AS JoinTableAlias  
        ,mdm.udfTableNameGetByID(@Entity_ID, 4) AS PhysicalTableName  
    FROM mdm.tblBRItemProperties p  
    INNER JOIN mdm.tblBRItem i  
    ON p.BRItem_ID = i.ID  
    INNER JOIN mdm.tblBRLogicalOperatorGroup g  
    ON i.BRLogicalOperatorGroup_ID = g.ID  
    INNER JOIN mdm.tblBRBusinessRule br  
    ON g.BusinessRule_ID = br.ID  
    INNER JOIN @PublishableStatus ps  
    ON br.Status_ID = ps.ID  
    INNER JOIN mdm.tblHierarchy h  
    ON      p.[Value] = CONVERT(NVARCHAR, h.ID)  
        AND p.PropertyType_ID = @ParentAttributeProperty  
        AND p.Parent_ID is null  
    WHERE   br.Entity_ID = @Entity_ID  
        AND br.MemberType_ID = @MemberType_ID  
  
    ORDER BY  
        h.ID;  
  
    /* PARENT (HIERARCHY) SUPPORTING FACT TABLE ATTRIBUTES */  
    SELECT DISTINCT  
        cast(p_parent.[Value] AS INT) AS ParentFactID,  
        col.COLUMN_NAME As [Name],  
        a.DisplayName,  
        a.ID AS TableColumnID,  
        a.AttributeType_ID AS AttributeTypeID,  
        a.DomainEntity_ID AS DomainEntityID,  
        0 AS IsDomainEntityRefreshRequired,  
        CASE WHEN recur.ID IS NULL THEN 0 ELSE 1 END AS IsRecursiveInheritance,  
        a.SortOrder AS Ordinal,  
        col.DATA_TYPE AS SQLType,  
        col.CHARACTER_MAXIMUM_LENGTH AS MaxLength,  
        col.NUMERIC_PRECISION AS NumericPrecision,  
        col.NUMERIC_SCALE AS NumericScale  
    FROM mdm.tblBRItemProperties p  
    INNER JOIN mdm.tblBRItem i  
    ON p.BRItem_ID = i.ID  
    INNER JOIN mdm.tblBRLogicalOperatorGroup g  
    ON i.BRLogicalOperatorGroup_ID = g.ID  
    INNER JOIN mdm.tblBRBusinessRule br  
    ON g.BusinessRule_ID = br.ID  
    INNER JOIN @PublishableStatus ps  
    ON br.Status_ID = ps.ID  
    INNER JOIN mdm.tblAttribute a  
    ON      p.[Value] = CONVERT(NVARCHAR, a.ID)  
        AND p.PropertyType_ID = @AttributeProperty  
        AND p.Parent_ID IS NOT NULL  
    INNER JOIN mdm.tblBRItemProperties p_parent  
    ON      p.Parent_ID = p_parent.ID  
        AND p_parent.PropertyType_ID = @ParentAttributeProperty  
    INNER JOIN INFORMATION_SCHEMA.COLUMNS col  
    ON      col.TABLE_NAME = @ParentFactTableName  
        AND col.TABLE_SCHEMA = 'mdm'  
        AND col.COLUMN_NAME = a.Name COLLATE database_default  
    LEFT JOIN @RecursiveInheritanceAttributes recur  
    ON a.ID = recur.ID  
    WHERE   br.Entity_ID = @Entity_ID  
        AND br.MemberType_ID = @MemberType_ID  
    ORDER BY  
        a.SortOrder;  
  
    -- Business rule attribute value properties  
    SELECT  
         bri.ID AS RuleItemID  
        ,attributes.Name AS AttributeName  
    FROM mdm.tblBRBusinessRule br  
    INNER JOIN @PublishableStatus ps  
    ON br.Status_ID = ps.ID  
    INNER JOIN mdm.tblBRLogicalOperatorGroup grp  
    ON br.ID = grp.BusinessRule_ID  
    INNER JOIN mdm.tblBRItem bri  
    ON grp.ID = bri.BRLogicalOperatorGroup_ID  
    INNER JOIN mdm.tblBRItemProperties brip  
    ON bri.ID = brip.BRItem_ID  
    INNER JOIN mdm.tblAttribute attributes  
    ON      br.Entity_ID = attributes.Entity_ID  
        AND brip.Value = CONVERT(NVARCHAR, attributes.ID)  
        AND br.MemberType_ID = attributes.MemberType_ID  
    WHERE   brip.PropertyType_ID = @AttributeProperty  
        AND brip.PropertyName_ID = @ValuePropertyName_ID  
        AND br.Entity_ID = @Entity_ID  
        AND br.MemberType_ID = @MemberType_ID  
    ORDER BY attributes.ID  
  
  
  
    SET NOCOUNT OFF;  
END; --proc
go

