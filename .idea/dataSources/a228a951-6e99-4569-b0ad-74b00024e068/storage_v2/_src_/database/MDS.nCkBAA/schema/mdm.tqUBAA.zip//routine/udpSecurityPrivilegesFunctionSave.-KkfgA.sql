/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
Saves a functional privilege for a principal (user or group).  
*/  
CREATE PROCEDURE mdm.udpSecurityPrivilegesFunctionSave  
(  
     @SystemUser_ID             INT -- The ID of the user who is executing this action (not to be confused with the principal to which the saved permission applies)  
    ,@Principal_MUID            UNIQUEIDENTIFIER = NULL  
    ,@Principal_Name            NVARCHAR(355) = NULL  
    ,@PrincipalType_ID          TINYINT  
    ,@MUID                      UNIQUEIDENTIFIER = NULL  
    ,@FunctionalPrivilege_ID    TINYINT  
    ,@SaveType                  TINYINT = 0 --default behavior is create.  
    ,@Return_ID                 INT = NULL OUTPUT  
    ,@Return_MUID               UNIQUEIDENTIFIER = NULL OUTPUT  
    ,@CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON;  
  
    DECLARE   
         @Principal_ID          INT  
        ,@Role_ID               INT  
  
        ,@PrincipalType_User    TINYINT = 1  
        ,@PrincipalType_Group   TINYINT = 2  
  
        ,@SaveType_Create       TINYINT = 0  
        ,@SaveType_Clone        TINYINT = 1  
        ,@SaveType_Update       TINYINT = 2  
        ;  
  
    SET @Principal_MUID = NULLIF(@Principal_MUID, CONVERT(UNIQUEIDENTIFIER, 0x0));  
    SET @Principal_Name = NULLIF(LTRIM(RTRIM(@Principal_Name)), N'');  
    DECLARE @Principal_NameUpper NVARCHAR(355) = UPPER(@Principal_Name);  
    SET @MUID = NULLIF(@MUID, CONVERT(UNIQUEIDENTIFIER, 0x0));  
    SET @Return_ID = NULL;  
    SET @Return_MUID = NULL;  
  
    -- Lookup the Principal ID from the provided Name and/or MUID.  
    IF(@PrincipalType_ID = @PrincipalType_User)  
    BEGIN  
        SELECT   
             @Principal_ID = ID  
            ,@Principal_MUID = MUID  
            ,@Principal_Name = UserName  
        FROM mdm.tblUser  
        WHERE   (@Principal_MUID IS NOT NULL OR @Principal_Name IS NOT NULL)  
            AND (@Principal_MUID IS NULL OR MUID = @Principal_MUID)  
            AND (@Principal_Name IS NULL OR UPPER(UserName) = @Principal_NameUpper);  
    END  
    ELSE IF(@PrincipalType_ID = @PrincipalType_Group)  
    BEGIN  
        SELECT   
             @Principal_ID = ID  
            ,@Principal_MUID = MUID  
            ,@Principal_Name = Name  
        FROM mdm.tblUserGroup  
        WHERE   (@Principal_MUID IS NOT NULL OR @Principal_Name IS NOT NULL)  
            AND (@Principal_MUID IS NULL OR MUID = @Principal_MUID)  
            AND (@Principal_Name IS NULL OR UPPER(Name) = @Principal_NameUpper);  
    END  
      
    IF COALESCE(@Principal_ID, 0) = 0  
    BEGIN  
        RAISERROR('MDSERR500023|The function privilege cannot be saved. The Principal ID is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    -- Lookup/create Role_ID from principal info.  
    SELECT @Role_ID = Role_ID  
    FROM mdm.tblSecurityAccessControl  
    WHERE   Principal_ID = @Principal_ID  
        AND PrincipalType_ID = @PrincipalType_ID  
    IF @Role_ID IS NULL   
    BEGIN  
        DECLARE @PrincipalType_Name NVARCHAR(MAX) = CASE @PrincipalType_ID WHEN @PrincipalType_User THEN N'User' ELSE N'Group' END;  
  
        --Create a new user account role for this user.  
        INSERT INTO mdm.tblSecurityRole  
        (    [Name]  
            ,EnterUserID  
            ,LastChgUserID  
        )  
        VALUES  
        (   N'Role for ' + @PrincipalType_Name + N' ' + COALESCE(@Principal_Name, N'')  
            ,@SystemUser_ID  
            ,@SystemUser_ID  
        );  
        SET @Role_ID = SCOPE_IDENTITY();  
  
        INSERT INTO mdm.tblSecurityAccessControl  
        (    PrincipalType_ID  
            ,Principal_ID  
            ,Role_ID  
            ,[Description]  
            ,EnterUserID  
            ,LastChgUserID  
        )  
        VALUES  
        (    @PrincipalType_ID  
            ,@Principal_ID  
            ,@Role_ID  
            ,CONCAT(LEFT(@Principal_Name, 89), N' ', @PrincipalType_Name)  
            ,@SystemUser_ID  
            ,@SystemUser_ID  
        );  
    END;  
  
  
    -- Check for MUID errors.  
    IF @SaveType = @SaveType_Create  
    BEGIN  
        -- Create.  
        IF @MUID IS NULL -- If a MUID wasn't provided, then create one.  
        BEGIN  
            SET @MUID = NEWID();  
        END;  
          
        IF EXISTS (SELECT 1 FROM mdm.tblSecurityRoleAccessFunctional WHERE MUID = @MUID) -- Ensure the MUID isn't being used by another row.  
        BEGIN  
            RAISERROR('MDSERR500064|The function privilege cannot be created because the GUID already exists.', 16, 1);  
            RETURN;  
        END;  
    END ELSE  
    BEGIN   
        -- Clone or Update.  
  
        -- See if the MUID already exists.  
        SELECT @Return_ID = ID  
        FROM mdm.tblSecurityRoleAccessFunctional  
        WHERE MUID = @MUID;  
  
        IF @SaveType = @SaveType_Clone  
        BEGIN   
            --Clone  
            IF @MUID IS NULL -- Ensure a MUID was provided.  
            BEGIN  
                -- Clone failed. No Muid was supplied.   
                RAISERROR('MDSERR500008|The function privilege cannot be cloned because the GUID is missing or not valid.', 16, 1);  
                RETURN;  
            END;  
  
            SET @SaveType = CASE WHEN @Return_ID IS NULL   
                THEN @SaveType_Create      -- The MUID doesn't already exist, so add a new row  
                ELSE @SaveType_Update END; -- The MUID already exists, so update the existing row.  
        END   
        ELSE IF @SaveType = @SaveType_Update  
        BEGIN  
            -- Update  
            IF @Return_ID IS NULL -- Ensure the MUID already exists  
            BEGIN  
                RAISERROR('MDSERR500009|The function privilege cannot be updated because an existing identifier GUID is missing.', 16, 1);  
                RETURN;  
            END;  
        END;  
    END;  
  
    -- Update the functional permission table.  
    IF @SaveType = @SaveType_Create  
    BEGIN  
        -- Ensure a dupicate permission does not already exist.  
        IF EXISTS (SELECT 1   
                   FROM mdm.tblSecurityRoleAccessFunctional   
                   WHERE    Role_ID = @Role_ID   
                        AND FunctionalPrivilege_ID = @FunctionalPrivilege_ID)  
        BEGIN  
            RAISERROR('MDSERR500003|The function privilege cannot be saved. The permission already exists.', 16, 1);  
            RETURN;  
        END;  
  
        -- Create new row.  
        INSERT INTO mdm.tblSecurityRoleAccessFunctional   
        (  
             MUID  
            ,Role_ID  
            ,FunctionalPrivilege_ID  
            ,EnterUserID  
            ,LastChgUserID  
        )  
        SELECT   
             @MUID  
            ,@Role_ID  
            ,@FunctionalPrivilege_ID  
            ,@SystemUser_ID  
            ,@SystemUser_ID  
    END   
    ELSE IF @SaveType = @SaveType_Update  
    BEGIN  
        -- Update existing row.  
        UPDATE mdm.tblSecurityRoleAccessFunctional   
        SET  Role_ID                = @Role_ID  
            ,FunctionalPrivilege_ID = @FunctionalPrivilege_ID  
            ,LastChgDTM             = GETUTCDATE()  
            ,LastChgUserID          = @SystemUser_ID  
        WHERE MUID = @MUID  
    END;  
  
    SET @Return_ID = SCOPE_IDENTITY();  
    SET @Return_MUID = @MUID;  
  
    SET NOCOUNT OFF;  
END --proc
go

