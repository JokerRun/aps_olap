CREATE PROCEDURE [mdm].[udpValidateFunctionArguments]    
(    
    @ScriptName   SYSNAME,       
    @IsSproc    BIT,       
    @Arguments mdm.ScriptArgument READONLY,      
    @ThrowException BIT = 0,     
    @BRID INT = NULL,  -- This parameter is only used in error message    
    @IsValid BIT OUT,    
    @ScriptArguments NVARCHAR(MAX) = NULL OUT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability        
)        
/*WITH*/        
AS BEGIN        
    SET NOCOUNT ON        
    DECLARE @NvarcharTypeId INT = TYPE_ID('nvarchar')      
        ,@BitTypeId INT = TYPE_ID('bit')      
        ,@DecimalTypeId INT = TYPE_ID('decimal')      
        ,@DateTimeTypeId INT = TYPE_ID('datetime2')    
        ,@BRName NVARCHAR(50) = ''     
        ,@ErrorMsg NVARCHAR(MAX);    
      
    SET @ScriptArguments = ''  
    IF @ThrowException = 1 AND @BRID IS NOT NULL  
    BEGIN    
        SELECT @BRName = Name FROM mdm.tblBRBusinessRule WHERE ID = @BRID    
    END    
    
    SET @IsValid = 1      
    IF @IsSproc = 1       
    BEGIN      
        IF mdm.udfScriptExists(@ScriptName, 2 , 'usr') = 0          
        BEGIN              
            IF @ThrowException = 1      
            BEGIN      
                SET @ErrorMsg = 'MDSERR400068|Business Rule {0} is corrupted. Could not find SQL Stored Procedure {1} in usr schema. |' + @BRName +'|'+ @ScriptName    
                SET @ErrorMsg = REPLACE(@ErrorMsg, '%', '%%')-- escape out format specifier  
                RAISERROR(@ErrorMsg, 16, 1);                  
            END      
            ELSE      
            BEGIN      
                SET @IsValid = 0;      
            END      
            RETURN      
        END                 
    END      
    ELSE      
    BEGIN      
        IF mdm.udfScriptExists(@ScriptName, 1 , 'usr') = 0          
        BEGIN              
            IF @ThrowException = 1      
            BEGIN      
                SET @ErrorMsg = 'MDSERR400069|Business Rule {0} is corrupted. Could not find SQL Function {1} in usr schema. |' + @BRName+'|'+ @ScriptName;    
                SET @ErrorMsg = REPLACE(@ErrorMsg, '%', '%%')-- escape out format specifier  
                RAISERROR(@ErrorMsg, 16, 1);                  
            END      
            ELSE      
            BEGIN      
                SET @IsValid = 0;      
            END      
            RETURN      
        END                  
        CREATE TABLE #ParameterPair      
        (      
            Id INT IDENTITY(1,1),      
            ParaIndex INT NULL,      
            ParaName SYSNAME NULL,      
            ParaDataType INT NULL,      
            ParaDataTypeInformation INT NULL,      
            ArgumentType INT NULL, -- 1 VALUE 2 ATTRIBUTE 3 NULL      
            ArgumentValue NVARCHAR(999) NULL ,  
            ArgumentScript NVARCHAR(MAX) NULL    
        );      
      
       with cte      
       AS      
       (      
          SELECT       
          p.parameter_id AS ParaIndex,       
          p.name AS ParaName,      
          p.user_type_id AS ParaDataType,      
          CASE p.user_type_id      
              WHEN @NvarcharTypeId THEN p.max_length      
              WHEN @BitTypeId THEN p.scale      
              WHEN @DecimalTypeId THEN p.scale      
              WHEN @DateTimeTypeId THEN p.scale      
              ELSE NULL END as ParaDataTypeInformation                   
                
          FROM sys.objects o      
          INNER JOIN sys.parameters p ON p.object_id = o.object_id      
          WHERE o.schema_id = SCHEMA_ID('usr')       
          AND o.name = @ScriptName      
          AND o.type ='FN'      
       )      
        INSERT INTO #ParameterPair      
        SELECT p.ParaIndex, p.ParaName,p.ParaDataType, p.ParaDataTypeInformation,a.ArgumentType,a.ArgumentValue,a.ArgumentScript FROM cte p      
        FULL OUTER JOIN @Arguments a ON a.Name = p.ParaName      
          
       Declare @Id int      
            ,@ParaIndex INT      
            ,@ParaName SYSNAME      
            ,@ParaDataType INT -- 1 STRING 2 NUMBER 3 DATE 4 DBA 5 FILE      
            ,@ParaDataTypeInformation INT      
            ,@ArgumentType INT -- 1 VALUE 2 ATTRIBUTE 3 NULL/BLANK      
            ,@ArgumentValue NVARCHAR(999)    
            ,@ArgumentScript NVARCHAR(MAX)    
            ,@SQL NVARCHAR(MAX)      
            ,@ArgDataType_ID INT      
            ,@ArgDataTypeInformation INT      
              
         
          
        While (Select Count(*) From #ParameterPair) > 0 AND @IsValid = 1     
        Begin      
      
            Select Top 1 @Id = Id, @ParaIndex = ParaIndex, @ParaName = ParaName, @ParaDataType = ParaDataType, @ParaDataTypeInformation = ParaDataTypeInformation      
            , @ArgumentValue = ArgumentValue, @ArgumentType = ArgumentType , @ArgumentScript = ArgumentScript From #ParameterPair      
              
            IF @ParaIndex IS NULL -- HAVE AN EXTRA ARGUMENT      
            BEGIN                  
                IF @ThrowException = 1      
                BEGIN      
                    SET @ErrorMsg = 'MDSERR400066|Business Rule {0} is corrupted. There is an extra argument assigned to SQL Function {1}. |'+ @BRName+'|'+ @ScriptName;    
                    SET @ErrorMsg = REPLACE(@ErrorMsg, '%', '%%')-- escape out format specifier  
                    RAISERROR(@ErrorMsg, 16, 1);      
                END      
                ELSE      
                BEGIN      
                    SET @IsValid = 0;                      
                END      
                RETURN                  
            END      
            ELSE      
            BEGIN                  
                IF(@ParaIndex <> 0) -- IS NOT RETURN VALUE      
                BEGIN      
                    IF @ArgumentType = 1 -- VALUE      
                    BEGIN       
                        IF @ParaDataType = @NvarcharTypeId -- STRING      
                        BEGIN      
                            IF(@ParaDataTypeInformation <> -1 AND LEN(@ArgumentValue) > @ParaDataTypeInformation/2)      
                            BEGIN      
                                SET @IsValid = 0;       
                            END      
                        END      
                        ELSE IF @ParaDataType = @DecimalTypeId -- DECIMAL      
                        BEGIN      
                            SET @SQL  = N'        
                            IF TRY_CONVERT(DECIMAL(38,'+ CONVERT(NVARCHAR(2),@ParaDataTypeInformation)+') ,@ArgumentValue) IS NULL       
                                 OR ( CHARINDEX(''.'', @ArgumentValue,0) <>0 AND LEN(@ArgumentValue)- CHARINDEX(''.'', @ArgumentValue,0)>'+ CONVERT(NVARCHAR(2),@ParaDataTypeInformation) +')      
                            BEGIN      
                                SET @IsValid = 0      
                            END';               
                            EXEC sp_executesql @SQL,   N'@ArgumentValue NVARCHAR(999), @IsValid BIT OUTPUT', @ArgumentValue, @IsValid OUTPUT;                     
                        END      
                        ELSE IF @ParaDataType = @DateTimeTypeId --DateTime      
                        BEGIN      
                            IF mdq.IsDateTime2(@ArgumentValue) = 0     
                            BEGIN      
                                SET @IsValid = 0       
                            END      
                        END                         
                    END -- END FREE FORM ARGUMENT VALUE CHECK      
                    ELSE IF @ArgumentType = 2 -- ATTRIBUTE      
                    BEGIN      
                        -- GET CORRESPONDING ATTRIBUTE INFOMATION      
                        SELECT @ArgDataType_ID = [DataType_ID], @ArgDataTypeInformation = [DataTypeInformation] FROM mdm.tblAttribute WHERE ID = CAST(@ArgumentValue AS INT)      
                        IF @ArgDataType_ID IS NULL      
                        BEGIN      
                            SET @IsValid = 0      
                        END      
                        IF @ParaDataType = @NvarcharTypeId -- STRING      
                        BEGIN      
                            IF(@ArgDataType_ID <>1 OR ( @ParaDataTypeInformation <> -1 AND @ArgDataTypeInformation > @ParaDataTypeInformation/2))      
                            BEGIN      
                                SET @IsValid = 0;       
                            END      
                        END      
                        ELSE IF @ParaDataType = @DecimalTypeId -- DECIMAL      
                      BEGIN      
                            IF(@ArgDataType_ID <>2 OR (@ArgDataTypeInformation <> @ParaDataTypeInformation))         
                            BEGIN      
                                SET @IsValid = 0;      
                            END        
                        END      
                        ELSE IF @ParaDataType = @DateTimeTypeId --Datetime      
                        BEGIN      
                            IF @ArgDataType_ID <>3      
                            BEGIN      
                                SET @IsValid = 0       
                            END      
                        END        
                    END  -- END ATTRIBUTE ARGUMENT CHECK      
                    ELSE IF @ArgumentType IS NULL  
                    BEGIN  
                        SET @IsValid = 0  
                    END  
                     
                    -- SKIP BLANK ARGUMENT      
                    IF @ThrowException = 1 AND @IsValid = 0      
                    BEGIN      
                        SET @ErrorMsg = 'MDSERR400067|Business Rule {0} is corrupted.The parameter {1} in [usr].{2} either has not assigned or does not match the type of the argument. |'+@BRName+'|'+ @ParaName+'|'+@ScriptName;    
                        SET @ErrorMsg = REPLACE(@ErrorMsg, '%', '%%')-- escape out format specifier  
                        RAISERROR(@ErrorMsg, 16, 1);      
                        RETURN      
                    END   
                    IF @IsValid = 1  
                    BEGIN  
                        IF @ScriptArguments <> ''  
                        BEGIN  
                            SET @ScriptArguments = @ScriptArguments + ' , '  
                        END  
                        SET @ScriptArguments = @ScriptArguments + @ArgumentScript  
                    END  
                            
                END      
            END              
            Delete #ParameterPair Where Id = @Id      
      
        End      
    END      
    SET NOCOUNT OFF       
        
END --proc
go

