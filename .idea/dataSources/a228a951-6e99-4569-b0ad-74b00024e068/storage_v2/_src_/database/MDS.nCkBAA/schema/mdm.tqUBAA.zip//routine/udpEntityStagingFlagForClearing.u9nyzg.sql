/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
*/  
CREATE PROCEDURE [mdm].[udpEntityStagingFlagForClearing]  
	@Batch_ID       INT,  
    @UserID         INT,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
WITH EXECUTE AS 'mds_schema_user'  
AS  
BEGIN  
    DECLARE  
		@QueuedToRun				TINYINT = 1,  
 		@Running					TINYINT = 3,  
  		@QueueToClear				TINYINT = 4,  
 		@Cleared					TINYINT = 5,  
        @IsInvalidState             BIT = 1  
  
    SELECT   
        @IsInvalidState =  
        CASE  
            WHEN (Status_ID IN (@Running, @QueuedToRun, @Cleared)) THEN     1  
            ELSE                                                            0  
        END  
    FROM  
        mdm.tblStgBatch  
    WHERE  
        ID = @Batch_ID  
  
    -- No need to update batch information if it is currently queued to run or running or already cleared  
    IF (@IsInvalidState = 1)  
    BEGIN  
        RAISERROR('MDSERR310029|The status of the specified batch is not valid.', 16, 1);  
        RETURN;    			  
    END -- IF  
  
  
    EXEC	[mdm].[udpStagingBatchSave]  
		        @UserID = @UserID,  
		        @StatusID = @QueueToClear,  
                @BatchID = @Batch_ID  
  
END;
go

