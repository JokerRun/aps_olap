/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
    EXEC mdm.udpEntityStagingBatchTableCleanup 7, '2014-10-24';  
    SELECT * FROM mdm.tbl_7_TR where LastChgDTM,  '2014-10-24';  
*/  
CREATE PROCEDURE mdm.udpEntityStagingBatchTableCleanup  
(  
    @Model_ID    INT,  
    @CleanupOlderThanDate  DATE,  
    @CorrelationID UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS N'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    DECLARE  
        @SQL                    NVARCHAR(MAX)  
        ,@Entity_ID             INT  
  
    BEGIN TRY  
  
        --Temporary table to hold all batches we want to clean  
        CREATE TABLE #BatchTable  
        (  
            RowNumber INT IDENTITY(1, 1) NOT NULL PRIMARY KEY  
            ,Batch_ID INT NOT NULL  
            ,Entity_ID INT NOT NULL  
        );  
  
       --Get all the batches you want to delete  
  
        INSERT INTO #BatchTable  
        SELECT sb.ID  
            ,sb.Entity_ID  
        FROM [mdm].tblStgBatch sb  
            INNER JOIN [mdm].tblEntity ent  
            ON sb.Entity_ID = ent.ID  
            WHERE ent.Model_ID = @Model_ID  
            AND sb.LastRunEndDTM <= @CleanupOlderThanDate  
  
        DECLARE @Batch_ID INT,  
                @LeafStagingTable sysname,  
                @ConsolidatedStagingTable sysname,  
                @RelationshipStagingTable sysname;  
  
        DECLARE c CURSOR FOR SELECT DISTINCT Entity_ID From #BatchTable GROUP BY Entity_ID  
                OPEN c  
                FETCH NEXT FROM c INTO @Entity_ID  
  
            WHILE @@Fetch_Status=0  
            BEGIN  
  
                SELECT  
                @LeafStagingTable = CASE WHEN StagingLeafTable IS NULL THEN N''  
                                        ELSE '[stg].' + QUOTENAME(StagingLeafTable)  
                                    END,  
                @ConsolidatedStagingTable = CASE WHEN StagingConsolidatedTable IS NULL THEN N''  
                                                ELSE 'stg.' + QUOTENAME(StagingConsolidatedTable)  
                                            END,  
                @RelationshipStagingTable = CASE WHEN StagingRelationshipTable IS NULL THEN N''  
                                                ELSE 'stg.' + QUOTENAME(StagingRelationshipTable)  
                                            END  
                FROM  
                    mdm.viw_SYSTEM_SCHEMA_ENTITY WHERE ID = @Entity_ID;  
  
                SET @SQL = 'DELETE FROM '+ @LeafStagingTable + ' FROM '+ @LeafStagingTable + ' sTbl INNER JOIN #BatchTable bt  
                    ON sTbl.Batch_ID = bt.Batch_ID  
                    WHERE bt.Entity_ID = @Entity_ID';  
                    print @SQL  
                EXEC sp_executesql @SQL, N'@Entity_ID INT', @Entity_ID  
  
                IF LEN(ISNULL(@ConsolidatedStagingTable, N'')) <> 0  
                BEGIN  
                    SET @SQL = 'DELETE FROM '+ @ConsolidatedStagingTable + ' FROM '+ @ConsolidatedStagingTable + ' sTbl INNER JOIN #BatchTable bt  
                    ON sTbl.Batch_ID = bt.Batch_ID  
                    WHERE bt.Entity_ID = @Entity_ID';  
                    print @SQL  
                    EXEC sp_executesql @SQL, N'@Entity_ID INT', @Entity_ID  
                END  
  
                IF LEN(ISNULL(@RelationshipStagingTable, N'')) <> 0  
                BEGIN  
                    SET @SQL = 'DELETE FROM '+ @RelationshipStagingTable + ' FROM '+ @RelationshipStagingTable + ' sTbl INNER JOIN #BatchTable bt  
                    ON sTbl.Batch_ID = bt.Batch_ID  
                    WHERE bt.Entity_ID = @Entity_ID';  
                    print @SQL  
                    EXEC sp_executesql @SQL, N'@Entity_ID INT', @Entity_ID  
                END  
  
                SET @SQL = 'DELETE FROM [mdm].tblStgBatch FROM [mdm].tblStgBatch sTbl INNER JOIN #BatchTable bt  
                    ON sTbl.ID = bt.Batch_ID  
                    WHERE bt.Entity_ID = @Entity_ID';  
                    print @SQL  
                    EXEC sp_executesql @SQL, N'@Entity_ID INT', @Entity_ID  
  
  
                FETCH NEXT FROM c INTO @Entity_ID  
            END  
  
        CLOSE c  
        DEALLOCATE c  
    RETURN(0);  
    END TRY  
    --Compensate as necessary  
    BEGIN CATCH  
  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
  
        RETURN(1);  
  
    END CATCH;  
  
    SET NOCOUNT OFF  
END --proc
go

