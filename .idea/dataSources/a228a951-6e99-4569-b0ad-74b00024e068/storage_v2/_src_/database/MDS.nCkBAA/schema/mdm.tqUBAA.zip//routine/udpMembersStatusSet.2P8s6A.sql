/*  
==============================================================================  
 Copyright (c) Microsoft Corporation. All Rights Reserved.  
==============================================================================  
  
DECLARE @MemberIdList mdm.IdList;  
INSERT INTO @MemberIdList  
VALUES (1), (2), (3)  
  
EXEC mdm.udpMembersStatusSet @User_ID=1, @Version_ID=20, @Entity_ID=37, @MemberIds = @MemberIds, @Status_ID=2  
  
SELECT * FROM mdm.tblAttribute WHERE DomainEntity_ID=37  
  
**********************************************************  
The below code can be used to help troubleshoot issues and measure perf.  
  
-- Create a log table for measuring perf  
CREATE TABLE mdm.tblPerfLog  
(  
     ID INT IDENTITY(1,1) NOT NULL  
    ,SPID INT NOT NULL  
    ,[Message] NVARCHAR(MAX)  
    ,[Time]   DATETIME2  
)  
  
-- Create a sproc to write messages to the log table.  
CREATE PROC mdm.udpLogMessage  
(  
    @Message NVARCHAR(MAX) = NULL  
)  
AS  
BEGIN  
    PRINT CONVERT(NVARCHAR, GETDATE()) + N': ' + @Message  
    INSERT INTO mdm.tblPerfLog  
        (SPID, [Message], [Time])  
    VALUES  
        (@@SPID, @Message, GETDATE());  
END;  
  
  
-- Get the items from the perf log table, and compute duration between entries. This is useful for identifying  
-- bottlenecks in the sproc. Run this query after changing all of the "IF @Debug = 1" lines to call udpLogMessage  
-- instead of calling PRINT, and then set the @Debug flag when running this sproc.  
SELECT  
     msg.*  
    ,DATEDIFF(ms, msg.[Time], nextMessage.[Time]) AS DurationInMs  -- How much time passed between when this message and the very next message were logged.  
FROM mdm.tblPerfLog msg  
LEFT JOIN mdm.tblPerfLog nextMessage  
ON msg.ID + 1 = nextMessage.ID  
ORDER BY msg.ID  
  
*/  
  
CREATE PROCEDURE mdm.udpMembersStatusSet  
(  
   @User_ID             INT,  
   @Model_ID            INT = NULL,  
   @ModelName           NVARCHAR(50) = NULL,  
   @ModelMuid           UNIQUEIDENTIFIER = NULL,  
   @Entity_ID           INT = NULL,  
   @EntityName          NVARCHAR(50) = NULL,  
   @EntityMuid          UNIQUEIDENTIFIER = NULL,  
   @Version_ID          INT = NULL,  
   @VersionName         NVARCHAR(50) = NULL,  
   @VersionMuid         UNIQUEIDENTIFIER = NULL,  
   @MemberIds           mdm.MemberId READONLY, -- ID and MemberType are always required. MUID and Code should also be provided unless @LogFlag is 0.  
   @MemberType_ID       TINYINT,  
   @Status_ID           TINYINT,  
   @ChangesetName       NVARCHAR(250) = NULL,  
   @ChangesetMuid       UNIQUEIDENTIFIER = NULL,  
   @Approved            BIT = 0, -- Called by udpEntityMemberChangesetSave  
   @ResetDbaReferences  BIT = 0,  
   @LogFlag             BIT = 1,  
   @RaiseFirstError     BIT = 0, -- When 1, the first error will be raised. Otherwise, all errors will be included in the result set.  
   @TransactionBehavior TINYINT = 0, -- 0 = BestEffort,  
                                     -- 1 = AllOrNothingByMember Same as BestEffort in this sp  
                                     -- 2 = AllOrNothingByBatch  (if any part of any member has an error, then all changes in the entire batch will be aborted)  
   @Debug               BIT = 0,  
   @CorrelationID       UNIQUEIDENTIFIER = NULL  -- This parameter is populated from the c# layer and provides end to end traceability  
)  
WITH EXECUTE AS 'mds_schema_user'  
AS BEGIN  
    SET NOCOUNT ON  
  
    DECLARE  
        @MemberTableName               SYSNAME  
  
        ,@MemberType_Leaf               TINYINT = 1  
        ,@MemberType_Consolidated       TINYINT = 2  
        ,@MemberType_Collection         TINYINT = 3  
        ,@MemberType_Hierarchy          TINYINT = 4  
        ,@MemberType_CollectionMember   TINYINT = 5  
  
        ,@MemberSecurity                INT = 0  
  
        --Permission  
        ,@ModelPermission               INT  
        ,@MemberTypePermission          INT = NULL  
        ,@Permission_None               INT = 0  
        ,@Permission_Deny               INT = 1  
        ,@Permission_Access             INT = 4  
        ,@Permission_Admin              INT = 5  
        ,@Permission_Inferred           INT = 99  
  
        ,@MemberTypeAccessPermission    TINYINT = NULL  
        ,@RequiredAccessPermission      TINYINT = NULL  
        ,@AccessPermission_Create       TINYINT = 1  
        ,@AccessPermission_Delete       TINYINT = 4  
  
        ,@VersionStatus                 TINYINT  
        ,@VersionStatus_NotSpecified    TINYINT = 0  
        ,@VersionStatus_Open            TINYINT = 1  
        ,@VersionStatus_Locked          TINYINT = 2  
        ,@VersionStatus_Committed       TINYINT = 3  
  
        ,@RequireApproval               BIT  
        ,@PendingTableName              SYSNAME -- E.g. "tbl_7_31_EN_PD"  
        ,@ChangesetTableName            SYSNAME -- E.g. "tbl_7_CS"  
        ,@Changeset_ID                  INT = NULL  
        ,@ChangesetStatus               TINYINT  
        ,@ChangesetStatus_Open          TINYINT = 1  
        ,@ChangesetStatus_Pending       TINYINT = 2  
        ,@ChangesetStatus_Approved      TINYINT = 3  
        ,@ChangesetStatus_Rejected      TINYINT = 4  
        ,@ChangesetStatus_Committed     TINYINT = 5  
  
        ,@TransactionLogType            TINYINT  
        ,@TransactionLogType_Attribute  TINYINT = 1  
        ,@TransactionLogType_Member     TINYINT = 2  
        ,@TransactionLogType_None       TINYINT = 3  
  
        ,@Status_Active                 TINYINT = 1  
        ,@Status_Deactivated            TINYINT = 2  
  
        ,@ObjectType_MemberId           TINYINT = 19  
  
        ,@TransactionBehavior_AllOrNothingByBatch   TINYINT = 2  
  
        ,@ValidationStatus_AwaitingRevalidation TINYINT = 4  
  
        ,@TransactionType_ChangeMemberStatus    TINYINT = 2  
  
        ,@ErrorCode_InvalidIdError              INT = 120003 -- MDSERR120003|The user does not have permission or the object ID is not valid  
        ,@ErrorCode_MemberCodeExistsError       INT = 300003 -- MDSERR300003|The member code already exists  
  
        -- This pseudo-constant is for use in string concatenation operations to prevent string truncation. When concatenating two or more strings,  
        -- if none of the strings is an NVARCHAR(MAX) or an NVARCHAR constant that is longer than 4,000 characters, then the resulting string  
        -- will be silently truncated to 4,000 characters. Concatenating with this empty NVARCHAR(MAX), is sufficient to prevent truncation.  
        -- See http://connect.microsoft.com/SQLServer/feedback/details/283368/nvarchar-max-concatenation-yields-silent-truncation.  
        ,@TruncationGuard               NVARCHAR(MAX) = N''  
        ,@ID                            INT  
        ,@ReferringEntity_ID            INT  
        ,@ReferringAttributeColumnName  SYSNAME  
        ,@ReferringMemberType_ID        TINYINT  
        ,@ReferringEntityTableName      SYSNAME  
        ,@ReferringEntityPendingTableName       SYSNAME  
        ,@ReferringEntityName           NVARCHAR(MAX)  
        ,@Attribute_ID                  INT  
        ,@SQL                           NVARCHAR(MAX)  
        ,@GuidEmpty                     UNIQUEIDENTIFIER = CAST(0x0 AS UNIQUEIDENTIFIER)  
        ;  
  
    SET @Model_ID  = NULLIF(@Model_ID, 0);  
    SET @Entity_ID  = NULLIF(@Entity_ID, 0);  
    SET @Version_ID  = NULLIF(@Version_ID, 0);  
    SET @ModelName  = NULLIF(@ModelName, N'');  
    SET @EntityName = NULLIF(@EntityName, N'');  
    SET @VersionName = NULLIF(@VersionName, N'');  
    SET @ChangesetName = NULLIF(@ChangesetName, N'');  
    SET @ModelMuid = NULLIF(@ModelMuid, @GuidEmpty);  
    SET @EntityMuid = NULLIF(@EntityMuid, @GuidEmpty);  
    SET @VersionMuid = NULLIF(@VersionMuid, @GuidEmpty);  
    SET @ChangesetMuid = NULLIF(@ChangesetMuid, @GuidEmpty);  
  
    -- Validate @Model_ID and the user's permission to see the model.  
    IF @Debug = 1 PRINT N'validate model.'  
    SELECT  
         @Model_ID = m.ID  
        ,@ModelName = m.Name  
        ,@ModelMuid = m.MUID  
        ,@ModelPermission = s.Privilege_ID  
    FROM mdm.tblModel m  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_MODEL s  
    ON m.ID = s.ID  
        AND COALESCE(s.Privilege_ID, @Permission_Deny) <> @Permission_Deny  
        AND s.User_ID = @User_ID  
    WHERE (@ModelMuid IS NOT NULL OR @ModelName IS NOT NULL OR @Model_ID IS NOT NULL) -- At least one Identifier param must be provided.  
        AND (@ModelMuid IS NULL OR @ModelMuid = m.MUID)  
        AND (@ModelName IS NULL OR @ModelName = m.Name)  
        AND (@Model_ID  IS NULL OR @Model_ID  = m.ID)  
  
    IF @Model_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300005|The supplied model is not valid.', 16, 1);  
        RETURN;  
    END  
  
    SET @ChangesetTableName = CONCAT(N'tbl_', @Model_ID, N'_CS');  
  
    -- Validate @Version_ID  
    IF @Debug = 1 PRINT N'validate version.'  
    SELECT  
         @Version_ID = ID  
        ,@VersionName = Name  
        ,@VersionMuid = MUID  
        ,@VersionStatus = Status_ID  
    FROM mdm.tblModelVersion  
    WHERE (@VersionMuid IS NOT NULL OR @VersionName IS NOT NULL OR @Version_ID IS NOT NULL) -- At least one Identifier param must be provided.  
        AND (@VersionMuid IS NULL OR @VersionMuid = MUID)  
        AND (@VersionName IS NULL OR @VersionName = Name)  
        AND (@Version_ID  IS NULL OR @Version_ID  = ID)  
        AND Model_ID = @Model_ID  
  
    IF @Version_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300006|The supplied version is not valid.', 16, 1);  
        RETURN;  
    END;  
  
    SET @VersionStatus = COALESCE(@VersionStatus, @VersionStatus_NotSpecified);  
    IF @VersionStatus = @VersionStatus_Committed  
        OR (@VersionStatus = @VersionStatus_Locked AND @ModelPermission <> @Permission_Admin)  
    BEGIN  
        RAISERROR(N'MDSERR300012|The version is read-only. You do not have permission to update the version.', 16, 1);  
        RETURN;  
    END;  
  
    -- Lookup @Entity_ID and related info, validating that it exists and (if applicable) that the user has permissions to see it.  
    IF @Debug = 1 PRINT N'Validate entity.'  
    SELECT  
         @Entity_ID = e.ID  
        ,@PendingTableName = CAST(e.EntityTable + '_PD' AS SYSNAME)  
        ,@RequireApproval = RequireApproval  
        ,@TransactionLogType = CASE @LogFlag WHEN 1 THEN TransactionLogType ELSE @TransactionLogType_None END  
        ,@MemberTableName =  
            CASE @MemberType_ID  
                WHEN @MemberType_Leaf           THEN e.EntityTable  
                WHEN @MemberType_Consolidated   THEN e.HierarchyParentTable  
                WHEN @MemberType_Collection     THEN e.CollectionTable  
                WHEN @MemberType_Hierarchy      THEN e.HierarchyTable  
                WHEN @MemberType_CollectionMember   THEN e.CollectionMemberTable  
            END  
    FROM mdm.tblEntity e  
    INNER JOIN mdm.viw_SYSTEM_SECURITY_USER_ENTITY s  
    ON e.ID = s.ID  
        AND COALESCE(s.Privilege_ID, @Permission_Deny) <> @Permission_Deny  
        AND s.User_ID = @User_ID  
    WHERE (@EntityMuid IS NOT NULL OR @EntityName IS NOT NULL OR @Entity_ID IS NOT NULL) -- At least one Identifier param must be provided.  
        AND (@EntityMuid IS NULL OR @EntityMuid = e.MUID)  
        AND (@EntityName IS NULL OR @EntityName = e.Name)  
        AND (@Entity_ID  IS NULL OR @Entity_ID  = e.ID)  
        AND e.Model_ID = @Model_ID;  
  
    IF @Entity_ID IS NULL  
    BEGIN  
        RAISERROR('MDSERR300008|The supplied entity is not valid..', 16, 1);  
        RETURN;  
    END;  
  
    -- Verify the entity version is not a sync target.  
    IF EXISTS(SELECT 1 FROM mdm.tblSyncRelationship  
              WHERE TargetEntity_ID = @Entity_ID  
                AND TargetVersion_ID = @Version_ID)  
    BEGIN  
        RAISERROR('MDSERR200220|The entity member(s) cannot be saved. The entity version is the target of a sync relationship.', 16, 1);  
        RETURN;  
    END  
  
    IF @ChangesetName IS NOT NULL OR @ChangesetMuid IS NOT NULL  
    BEGIN  
        SET @SQL = CONCAT(N'  
                SELECT @Changeset_ID = ID, @ChangesetStatus = Status, @ChangesetMuid = MUID  
                FROM [mdm].', @ChangesetTableName, N'  
                WHERE Version_ID = @Version_ID  
                    AND Entity_ID = @Entity_ID  
                    AND EnterUserID = @User_ID  
                    AND (@ChangesetMuid IS NOT NULL OR @ChangesetName IS NOT NULL)  
                    AND (@ChangesetMuid IS NULL OR MUID = @ChangesetMuid)  
                    AND (@ChangesetName IS NULL OR Name = @ChangesetName)');  
        EXEC sp_executesql @SQL, N'@Version_ID INT, @Entity_ID INT, @User_ID INT, @ChangesetName NVARCHAR(250), @ChangesetMuid UNIQUEIDENTIFIER OUTPUT, @Changeset_ID INT OUTPUT, @ChangesetStatus TINYINT OUTPUT',  
                @Version_ID, @Entity_ID, @User_ID, @ChangesetName, @ChangesetMuid OUTPUT, @Changeset_ID OUTPUT, @ChangesetStatus OUTPUT;  
  
        IF @Changeset_ID IS NULL OR @ChangesetStatus NOT IN (@ChangesetStatus_Open, @ChangesetStatus_Rejected)  
        BEGIN  
            RAISERROR(N'MDSERR300028|The changeset id is invalid or you don''t have the permission to update pending changes of this changeset.', 16, 1);  
            RETURN;  
        END  
  
        IF @ChangesetStatus = @ChangesetStatus_Rejected  
        BEGIN  
            EXEC mdm.udpEntityMemberChangesetSave  
                @User_ID = @User_ID,  
                @Model_Name = @ModelName,  
                @Model_MUID = @ModelMuid,  
                @Entity_Name = @EntityName,  
                @Entity_MUID = @EntityMuid,  
                @Version_Name = @VersionName,  
                @Version_MUID = @VersionMuid,  
                @ChangesetMUID = @ChangesetMuid,  
                @ChangesetStatus = @ChangesetStatus_Open;  
        END  
    END  
  
    IF @RequireApproval = 1 AND @MemberType_ID = @MemberType_Leaf AND @Approved = 0 AND @Changeset_ID IS NULL  
    BEGIN  
        RAISERROR(N'MDSERR300023|The entity requires approval for leaf member changes.', 16, 1);  
        RETURN;  
    END;  
  
    IF @Debug = 1 PRINT N'Check member type permission.'  
    -- Check the object permission on the Entity Member Type.  
    SELECT @MemberTypePermission = Privilege_ID,  
        @MemberTypeAccessPermission = AccessPermission  
    FROM mdm.viw_SYSTEM_SECURITY_USER_MEMBERTYPE  
    WHERE [User_ID] = @User_ID  
        AND [Entity_ID] = @Entity_ID  
        AND ID = @MemberType_ID;  
  
    SET @MemberTypePermission = COALESCE(@MemberTypePermission, @Permission_Deny);  
    IF @MemberTypePermission = @Permission_Deny  
    BEGIN  
        RAISERROR(N'MDSERR120002|The user does not have permission to perform this operation.', 16, 1);  
        RETURN;  
    END;  
  
    CREATE TABLE #ReferringMemberIds (RowID INT IDENTITY (1,1), MemberCode NVARCHAR(MAX));  
    DECLARE @ReferringMembers mdm.MemberSaveList;  
    DECLARE @ReferringMemberAttributes mdm.MemberAttributeValues;  
  
    --Check to make sure that the members are not referenced by a DBA (Leaf members only. Consolidated members can't be referenced by a DBA).  
    DECLARE @ReferringEntities TABLE  
    (  
         ID                         INT IDENTITY(1, 1)  
        ,Entity_ID                  INT  
        ,MemberType_ID              TINYINT  
        ,AttributeColumnName        NVARCHAR(128) COLLATE DATABASE_DEFAULT  
        ,ReferringEntityName        NVARCHAR(MAX)  
        ,ReferringEntityTableName   SYSNAME  
        ,Attribute_ID               INT  
    )  
  
    --Convert nulls to 0  
    SET @ResetDbaReferences = ISNULL(@ResetDbaReferences, 0);  
  
    IF @Debug = 1 PRINT N'Load members into #MemberWorkingSet.'  
    -- Create a temp table as a staging area for members being processed. A temp table is used instead of a table var so that it can  
    --    1. Have a multi-column index, and  
    --    2. Be used within dynamic SQL statements.  
    CREATE TABLE #MemberWorkingSet  
    (  
        Row_ID              INT IDENTITY(1,1) NOT NULL,  
        MemberID            INT NULL,  
        MemberMUID          UNIQUEIDENTIFIER NULL,  
        MemberCode          NVARCHAR(250) COLLATE DATABASE_DEFAULT NULL,  
        PendingChange_ID    INT NULL,  
        OldStatus           TINYINT,  
        ErrorCode           INT NULL,  
        ErrorParameters     NVARCHAR(MAX)  
    );  
    CREATE INDEX #ix_MemberWorkingSet_MemberCode_MemberCode ON #MemberWorkingSet(MemberMUID, MemberCode);  
    INSERT INTO #MemberWorkingSet (MemberID, MemberMUID, MemberCode)  
    SELECT  
         NULLIF(ID, 0)  
        ,NULLIF(MUID, @GuidEmpty)  
        ,NULLIF(Code, N'')  
    FROM @MemberIds  
  
    -- !!!The following queries (to load existing members based on codes and MUID) have been separated on purpose.  
    -- Combining the two results in significantly worse performance!!!  
    -- Search on member MUID before Code, because MUID is guaranteed to be globally unique while Code may be duplicated among inactive members  
  
    IF @Debug = 1 PRINT N'Lookup pre-existing member MUIDs and IDs from the member table based on input MUIDs'  
    SET @SQL = CONCAT(@TruncationGuard, N'  
        UPDATE ws  
        SET ws.MemberID = m.ID,  
            ws.MemberCode = m.Code,  
            ws.MemberMUID = m.MUID  
        FROM #MemberWorkingSet ws  
        INNER JOIN mdm.', @MemberTableName, N' m  
        ON ws.MemberMUID = m.MUID AND m.Version_ID = @Version_ID  
        WHERE   ws.ErrorCode IS NULL  
            AND ws.MemberID IS NULL --Only look for members that have not already been looked up  
            AND ws.MemberMUID IS NOT NULL --We are only looking for members that have MUID set up');  
    IF @Debug = 1 PRINT @SQL  
    EXEC sp_executesql @SQL, N'@Version_ID INT', @Version_ID;  
  
    IF @Debug = 1 PRINT N'Lookup pre-existing member MUIDs and IDs from the member table based on input codes'  
    SET @SQL = CONCAT(@TruncationGuard, N'  
        UPDATE ws  
        SET ws.MemberID = m.ID,  
            ws.MemberCode = m.Code,  
            ws.MemberMUID = m.MUID  
        FROM #MemberWorkingSet ws  
        INNER JOIN mdm.', @MemberTableName, N' m  
        ON ws.MemberCode = m.Code AND m.Version_ID = @Version_ID  
        WHERE   ws.ErrorCode IS NULL  
            AND ws.MemberID IS NULL --Only look for members that have not already been looked up  
            AND ws.MemberCode IS NOT NULL --We are only looking for members that have MemberCode set up',  
            CASE WHEN @Status_ID = @Status_Deactivated THEN CONCAT(N'  
            AND m.Status_ID = ', @Status_Active, N' -- when soft-deleting a member, only look for matches among active members (there could be multiple code matches among already-deleted members') END);  
    IF @Debug = 1 PRINT @SQL  
    EXEC sp_executesql @SQL, N'@Version_ID INT', @Version_ID  
  
    --IF it is for pending changes, set a dummy MemberID  
    IF @Changeset_ID IS NOT NULL  
    BEGIN  
        SET @SQL = CONCAT(@TruncationGuard, N'  
            UPDATE ws  
            SET ws.MemberID = COALESCE(ws.MemberID, 0),  
                ws.MemberMUID = COALESCE(ws.MemberMUID, pd.MUID),  
                ws.PendingChange_ID = pd.ID  
            FROM #MemberWorkingSet ws  
            LEFT JOIN mdm.', @PendingTableName, N' pd  
            ON ws.MemberMUID = pd.MUID AND pd.CS_ID = @Changeset_ID AND pd.Version_ID = @Version_ID  
            WHERE ws.ErrorCode IS NULL');  
        IF @Debug = 1 PRINT @SQL  
        EXEC sp_executesql @SQL, N'@Version_ID INT, @Changeset_ID INT', @Version_ID, @Changeset_ID;  
    END  
  
    UPDATE #MemberWorkingSet  
    SET ErrorCode = @ErrorCode_InvalidIdError  
    WHERE MemberID IS NULL  
        AND ErrorCode IS NULL;  
  
    -- Check member type permission  
    SET @RequiredAccessPermission =  
        CASE @Status_ID  
            WHEN @Status_Active THEN @AccessPermission_Create  
            WHEN @Status_Deactivated THEN @AccessPermission_Delete  
        END  
  
    IF NOT(@MemberTypePermission = @Permission_Access  
        AND @MemberTypeAccessPermission & @RequiredAccessPermission = @RequiredAccessPermission)  
    BEGIN  
        RAISERROR(N'MDSERR120002|The user does not have permission to perform this operation.', 16, 1);  
        RETURN;  
    END;  
  
    --Check Member Permissions.  
    IF @Status_ID = @Status_Deactivated  
    BEGIN  
        IF @ModelPermission != @Permission_Admin  
        BEGIN  
            SET @MemberSecurity = mdm.udfUseMemberSecurity(@User_ID, @Entity_ID, @Version_ID, @MemberType_ID);  
            IF @MemberSecurity = 1  
            BEGIN  
                DECLARE @ExistingMemberIds mdm.MemberId;  
                INSERT INTO @ExistingMemberIds (ID, MemberType_ID)  
                SELECT DISTINCT  
                    ws.MemberID,  
                    @MemberType_ID  
                FROM #MemberWorkingSet ws  
                WHERE   ws.PendingChange_ID IS NULL -- Exclude pending changes  
                    AND ws.ErrorCode IS NULL;  
  
                IF EXISTS (SELECT 1 FROM @ExistingMemberIds)  
                BEGIN  
                    DECLARE @MemberPermissions AS TABLE (ID INT PRIMARY KEY, MemberType_ID INT, Privilege_ID INT, AccessPermission TINYINT);  
                    INSERT INTO @MemberPermissions  
                    EXEC mdm.udpSecurityMembersResolverGet @User_ID, @Version_ID, @Entity_ID, @ExistingMemberIds;  
  
                    UPDATE ws  
                    SET ErrorCode = @ErrorCode_InvalidIdError  
                    FROM #MemberWorkingSet ws  
                    INNER JOIN @MemberPermissions prm  
                    ON  ws.MemberID = prm.ID  
                    WHERE NOT (    prm.Privilege_ID = @Permission_Access   
                               AND prm.AccessPermission & @AccessPermission_Delete = @AccessPermission_Delete);  
                END;  
            END  
        END;  
    END  
  
    --Start transaction, being careful to check if we are nested  
    DECLARE @TranCounter INT = @@TRANCOUNT;  
    IF @TranCounter > 0  
    BEGIN  
        SAVE TRANSACTION TX;  
    END ELSE  
    BEGIN  
        BEGIN TRANSACTION;  
    END;  
  
    BEGIN TRY  
        -- If soft-deleting members, then check to see if the members are being referenced by any DBAs.  
        IF @Status_ID = @Status_Deactivated AND @Changeset_ID IS NULL AND @MemberType_ID = @MemberType_Leaf  
        BEGIN  
            IF @Debug = 1 PRINT N'Get a list of all referring entities'  
  
            -- Get Entities which referencing to this entity  
            INSERT INTO @ReferringEntities (Entity_ID, MemberType_ID, AttributeColumnName, ReferringEntityName, ReferringEntityTableName, Attribute_ID)  
            SELECT DISTINCT  
                 Attribute.Entity_ID  
                ,Attribute.MemberType_ID  
                ,Attribute.TableColumn  
                ,Entity.Name  
                ,CASE Attribute.MemberType_ID  
                    WHEN @MemberType_Leaf           THEN Entity.EntityTable  
                    WHEN @MemberType_Consolidated   THEN Entity.HierarchyParentTable  
                    WHEN @MemberType_Collection     THEN Entity.CollectionTable  
                 END  
                ,Attribute.ID  
            FROM mdm.tblAttribute Attribute  
            INNER JOIN mdm.tblEntity Entity ON Entity.ID = Attribute.Entity_ID  
            WHERE Attribute.DomainEntity_ID = @Entity_ID  
            ORDER BY Attribute.Entity_ID;  
            -- Go through each ReferringEntity  
            WHILE EXISTS(SELECT 1 FROM @ReferringEntities)  
            BEGIN  
                SELECT TOP 1  
                     @ID = ID  
                    ,@ReferringEntity_ID = Entity_ID  
                    ,@ReferringAttributeColumnName = AttributeColumnName  
                    ,@ReferringMemberType_ID = MemberType_ID  
                    ,@ReferringEntityName = ReferringEntityName  
                    ,@ReferringEntityTableName = ReferringEntityTableName  
                    ,@Attribute_ID = Attribute_ID  
                FROM @ReferringEntities;  
  
                IF @Debug = 1 PRINT @ReferringEntityName  
  
                --If we are okay with resetting DBA references to the members being deleted  
                IF @ResetDbaReferences = 1  
                BEGIN  
                    IF @Debug = 1 PRINT N'Null out DBA reference in referring entity,'  
                    --Empty the member temp tables  
                    DELETE FROM #ReferringMemberIds;  
                    DELETE FROM @ReferringMembers;  
                    DELETE FROM @ReferringMemberAttributes;  
  
                    SET @SQL = @TruncationGuard + N'  
                    INSERT INTO #ReferringMemberIds(MemberCode)  
                    SELECT ref.Code  
                    FROM #MemberWorkingSet ws  
                    INNER JOIN mdm.' + QUOTENAME(@ReferringEntityTableName) + N' ref  
                        ON ws.MemberID = ref.' + QUOTENAME(@ReferringAttributeColumnName) + N'  
                    WHERE  
                            ws.ErrorCode IS NULL  
                        AND ref.Status_ID = ' + CONVERT(NVARCHAR, @Status_Active) + '  
                        AND ref.Version_ID = @Version_ID --This is only for perf benefit';  
                    EXEC sp_executesql @SQL, N'@Version_ID INT', @Version_ID;  
  
                    INSERT INTO @ReferringMembers(RowID, MemberCode)  
                    SELECT RowID, MemberCode  
                    FROM #ReferringMemberIds  
  
                    INSERT INTO @ReferringMemberAttributes(MemberRowID, AttributeID, AttributeValue)  
                    SELECT RowID, @Attribute_ID, NULL FROM @ReferringMembers;  
  
                    EXEC mdm.udpEntityMembersSave  
                                @User_ID = @User_ID  
                                ,@Model_ID = @Model_ID  
                                ,@Entity_ID = @ReferringEntity_ID  
                                ,@Version_ID = @Version_ID  
                                ,@MemberType_ID = @ReferringMemberType_ID  
                                ,@Members = @ReferringMembers  
                                ,@MemberAttributes = @ReferringMemberAttributes  
                                ,@SaveMode = 3 -- Update  
                                ,@LogFlag = @LogFlag  
                                ,@ValidateDataTypes = 1  
                                ,@DoInheritanceRuleCheck = 0  
                                ,@ErrorReportingType = 4; --Raise any errors as an exception so everything is rolled back  
                END  
                --If DBA references are not being removed then members referenced by other members can not be deleted  
                ELSE  
                BEGIN  
                    IF @Debug = 1 PRINT N'Check for referring members'  
                    SET @SQL = CONCAT(@TruncationGuard, N'  
                    UPDATE ws  
                    SET  
                         ErrorCode = 300004  
                        ,ErrorParameters = CONCAT(REPLACE(ws.MemberCode, N''|'', N''_''), N''|'', ', QUOTENAME(REPLACE(@ReferringEntityName, N'|', N'_'), N''''), N', N''|'', REPLACE(ref.Code, N''|'', N''_''))  
                    FROM #MemberWorkingSet ws  
                    INNER JOIN mdm.', QUOTENAME(@ReferringEntityTableName), N' ref  
                        ON ws.MemberID = ref.', QUOTENAME(@ReferringAttributeColumnName), N'  
                    WHERE  
                            ws.ErrorCode IS NULL  
                        AND ref.Status_ID = ', @Status_Active, N'  
                        AND ref.Version_ID = @Version_ID --This is only for perf benefit');  
                   EXEC sp_executesql @SQL, N'@Version_ID INT', @Version_ID;  
                END  
  
                -- Reset DBA references on PD table  
                SET @ReferringEntityPendingTableName = CAST(@ReferringEntityTableName + N'_PD' AS SYSNAME)  
                  
                -- Change to pending/approved changeset to open  
                SET @SQL = CONCAT(@TruncationGuard, N'  
                    UPDATE cs  
                    SET cs.Status = ', @ChangesetStatus_Open, N'  
                    FROM mdm.', @ChangesetTableName, ' cs  
                    INNER JOIN mdm.', @ReferringEntityPendingTableName, ' pd  
                        ON cs.ID = pd.CS_ID AND cs.Version_ID = pd.Version_ID  
                    INNER JOIN #MemberWorkingSet ws  
                        ON ws.MemberID = pd.' + QUOTENAME(@ReferringAttributeColumnName) + N' AND @Version_ID = pd.Version_ID  
                    WHERE ws.ErrorCode IS NULL  
                        AND cs.Status IN (', @ChangesetStatus_Pending, N', ', @ChangesetStatus_Approved, N')');  
                EXEC sp_executesql @SQL, N'@Version_ID INT', @Version_ID;  
  
                -- Set PD DBA to null  
                SET @SQL = CONCAT(@TruncationGuard, N'  
                    UPDATE pd  
                    SET pd.', QUOTENAME(@ReferringAttributeColumnName) ,N' = NULL  
                    FROM mdm.', @ReferringEntityPendingTableName, ' pd  
                    INNER JOIN mdm.', @ChangesetTableName, ' cs  
                        ON cs.ID = pd.CS_ID AND cs.Version_ID = pd.Version_ID  
                    INNER JOIN #MemberWorkingSet ws  
                        ON ws.MemberID = pd.' + QUOTENAME(@ReferringAttributeColumnName) + N' AND @Version_ID = pd.Version_ID  
                    WHERE ws.ErrorCode IS NULL AND cs.Status <> ', @ChangesetStatus_Committed);  
                EXEC sp_executesql @SQL, N'@Version_ID INT', @Version_ID;  
                DELETE FROM @ReferringEntities WHERE ID = @ID;  
            END -- WHILE  
  
            -- Change to pending/approved changeset to open  
            SET @SQL = CONCAT(@TruncationGuard, N'  
                UPDATE cs  
                SET cs.Status = ', @ChangesetStatus_Open, N'  
                FROM mdm.', @ChangesetTableName, ' cs  
                INNER JOIN mdm.', @PendingTableName, ' pd  
                    ON cs.ID = pd.CS_ID AND cs.Version_ID = pd.Version_ID  
                INNER JOIN #MemberWorkingSet ws  
                    ON ws.MemberID = pd.EN_ID AND @Version_ID = pd.Version_ID  
                WHERE ws.ErrorCode IS NULL  
                    AND cs.Status IN (', @ChangesetStatus_Pending, N', ', @ChangesetStatus_Approved, N')');  
            EXEC sp_executesql @SQL, N'@Version_ID INT', @Version_ID;  
  
            -- Delete changes for this member  
            SET @SQL = CONCAT(@TruncationGuard, N'  
                DELETE pd  
                FROM mdm.', @PendingTableName, ' pd  
                INNER JOIN mdm.', @ChangesetTableName, ' cs  
                    ON cs.ID = pd.CS_ID AND cs.Version_ID = pd.Version_ID  
                INNER JOIN #MemberWorkingSet ws  
                    ON ws.MemberID = pd.EN_ID AND @Version_ID = pd.Version_ID  
                WHERE ws.ErrorCode IS NULL AND cs.Status <> ', @ChangesetStatus_Committed);  
            EXEC sp_executesql @SQL, N'@Version_ID INT', @Version_ID;  
  
        END -- IF deactivating members  
  
        DECLARE @MemberIdList   mdm.IdList;  
  
        IF @Changeset_ID IS NULL  
        BEGIN  
            SET @SQL = @TruncationGuard;  
  
            IF @Status_ID = @Status_Active  
            BEGIN  
                -- If reactivating members, ensure there is no active member with the same code.  
                SELECT @SQL = N'  
                WITH existingActiveCodesCte AS  
                (  
                    SELECT Code, ID  
                    FROM mdm.' + QUOTENAME(EntityTable) + N'  
                    WHERE Status_ID = ' + CONVERT(NVARCHAR, @Status_Active) + N'  
                        AND Version_ID = @Version_ID' +  
                    -- Only look at Consolidated and Collection tables if they exist  
                    CASE WHEN NULLIF(HierarchyParentTable, N'') IS NOT NULL THEN N'  
                    UNION -- not UNION ALL because deduplication is needed  
                    SELECT Code, ID  
                    FROM mdm.' + HierarchyParentTable + N'  
                    WHERE Status_ID = ' + CONVERT(NVARCHAR, @Status_Active) + N'  
                        AND Version_ID = @Version_ID'  
                        ELSE N'' END +  
                    CASE WHEN NULLIF(CollectionTable, N'') IS NOT NULL THEN N'  
                    UNION -- not UNION ALL because deduplication is needed  
                    SELECT Code, ID  
                    FROM mdm.' + CollectionTable + N'  
                    WHERE Status_ID = ' + CONVERT(NVARCHAR, @Status_Active) + N'  
                        AND Version_ID = @Version_ID'  
                        ELSE N'' END + N'  
                )'  
                FROM mdm.tblEntity  
                WHERE ID = @Entity_ID  
            END;  
  
            SET @SQL += CONCAT(N'  
            -- Add an error if the member does not exist or is reactivating using an existing code, and record the previous Status_ID value, for use in logging a transaction.  
            UPDATE ws  
            SET  
                    ws.OldStatus = mem.Status_ID  
                ,ws.ErrorCode = CASE WHEN mem.ID IS NULL THEN N''', @ErrorCode_InvalidIdError, N'''',  
            CASE WHEN @Status_ID = @Status_Active THEN CONCAT(N'  
                                        WHEN dup.ID IS NOT NULL THEN N''', @ErrorCode_MemberCodeExistsError, N'''') ELSE N'' END, N'  
                    ELSE NULL END  
            FROM #MemberWorkingSet ws  
            LEFT JOIN mdm.', QUOTENAME(@MemberTableName), N' mem  
            ON ws.MemberID = mem.ID',  
  
            CASE WHEN @Status_ID = @Status_Active THEN N'  
            LEFT JOIN existingActiveCodesCte dup  
            ON      mem.Code = dup.Code  
                AND mem.ID <> dup.ID' ELSE N'' END  
  
            , N'  
            WHERE  
                    ws.ErrorCode IS NULL  
                AND mem.Version_ID = @Version_ID;  
  
            -- Update the Status_ID in the member table.  
            DECLARE @Now DATETIME2 = GETUTCDATE();  
            UPDATE mem  
            SET  
                mem.Status_ID = @Status_ID,  
                mem.LastChgDTM = @Now,  
                mem.LastChgUserID = @User_ID,  
                mem.LastChgVersionID = @Version_ID', CASE @TransactionLogType WHEN @TransactionLogType_Member THEN mdm.udfGetHistoryOutputQuery(@Entity_ID, @MemberType_ID, NULL, NULL) ELSE N'' END, N'  
            FROM #MemberWorkingSet ws  
            INNER JOIN mdm.', QUOTENAME(@MemberTableName), N' mem  
                ON ws.MemberID = mem.ID  
            WHERE  
                    ws.ErrorCode IS NULL  
                AND mem.Version_ID = @Version_ID;  
            ');  
  
            IF @Debug = 1 PRINT N'Change member status'  
            EXEC sp_executesql @SQL, N'@Version_ID INT, @MemberType_ID TINYINT, @Status_ID TINYINT, @User_ID INT', @Version_ID, @MemberType_ID, @Status_ID, @User_ID;  
  
            IF @Debug = 1 PRINT N'Create a list of all updated member ids'  
            -- Create a list of all updated member ids.  
            INSERT INTO @MemberIdList  
            SELECT MemberID  
            FROM #MemberWorkingSet  
            WHERE ErrorCode IS NULL  
  
            -- Update validation issues or status.  
            IF @Status_ID = @Status_Deactivated  
            BEGIN  
                IF @Debug = 1 PRINT N'Delete any validation issues for deactivated members'  
                --If deleting then delete any validation issues.  
                EXEC mdm.udpValidationLogClearByMemberIDs  
                        @Version_ID = @Version_ID  
                    ,@Entity_ID = @Entity_ID  
                    ,@MemberType_ID = @MemberType_ID  
                    ,@MemberIdList = @MemberIdList;  
            END ELSE IF @Status_ID = @Status_Active  
            BEGIN  
                IF @Debug = 1 PRINT N'Set the validation status to Awaiting Revalidation for re-activated members'  
                --If reactivating then set the validation status to 'Awaiting Revalidation'.  
                EXEC mdm.udpMembersValidationStatusUpdate  
                        @Version_ID = @Version_ID  
                    ,@Entity_ID = @Entity_ID  
                    ,@MemberType_ID = @MemberType_ID  
                    ,@ValidationStatus_ID = @ValidationStatus_AwaitingRevalidation  
                    ,@MemberIdList = @MemberIdList;  
            END  
  
            -- Clear the list of updated members ids, to prepare it for reuse in the next loop iteration.  
            DELETE FROM @MemberIdList;  
        END  
        ELSE IF @MemberType_ID = @MemberType_Leaf  
        BEGIN  
            SET @SQL = CONCAT(N'  
                DECLARE @Now DATETIME2 = GETUTCDATE();  
                MERGE mdm.', @PendingTableName, N' pd  
                USING #MemberWorkingSet mws  
                ON mws.MemberMUID = pd.MUID  
                    AND pd.Version_ID = @Version_ID  
                    AND pd.CS_ID = @Changeset_ID  
                    AND mws.ErrorCode IS NULL  
                -- existing pending changes  
                WHEN MATCHED AND @Status_ID = ', @Status_Deactivated, N'  
                    THEN DELETE  
                WHEN NOT MATCHED BY TARGET  
                    THEN  
                        INSERT  
                        (  
                            Version_ID,  
                            CS_ID,  
                            EN_ID,  
                            Status_ID,  
                            MUID,  
                            EnterDTM,  
                            EnterUserID,  
                            LastChgDTM,  
                            LastChgUserID,  
                            Revision_ID  
                        )  
                        VALUES  
                        (  
                            @Version_ID,  
                            @Changeset_ID,  
                            mws.MemberID,  
                            @Status_ID,  
                            mws.MemberMUID,  
                            @Now,  
                            @User_ID,  
                            @Now,  
                            @User_ID,  
                            MIN_ACTIVE_ROWVERSION() + mws.Row_ID - 1  
                        );');  
            EXEC sp_executesql @SQL, N'@Version_ID INT, @Status_ID TINYINT, @User_ID INT, @Changeset_ID INT', @Version_ID, @Status_ID, @User_ID, @Changeset_ID;  
        END  
  
        IF @Changeset_ID IS NULL  
        BEGIN  
            DECLARE @HierarchyTableName SYSNAME = mdm.udfTableNameGetByID(@Entity_ID, @MemberType_Hierarchy),  
                    @GetHistoryOutputQuery NVARCHAR(MAX);  
  
            IF @TransactionLogType = @TransactionLogType_Member  
            BEGIN  
                SET @GetHistoryOutputQuery = mdm.udfGetHistoryOutputQuery(@Entity_ID, @MemberType_Hierarchy, NULL, NULL);  
            END;  
  
            IF LEN(@HierarchyTableName) > 0  
            BEGIN  
                DECLARE @SqlLevelString NVARCHAR(MAX) = CASE @Status_ID WHEN @Status_Deactivated THEN N'  
                        ,hr.LevelNumber = -1 ' ELSE N'' END;  
                IF @Debug = 1 PRINT N'Update The hierarchy relationship record and reset level number for recalculation'  
                SET @SQL = N'DECLARE @Now DATETIME2 = GETUTCDATE();'  
                IF @MemberType_ID = @MemberType_Leaf  
                BEGIN  
                    SET @SQL += @TruncationGuard + N'  
                    UPDATE hr  
                    SET Status_ID = @Status_ID,  
                        LastChgDTM = @Now,  
                        LastChgUserID = @User_ID,  
                        LastChgVersionID = @Version_ID' + @SqlLevelString + CASE @TransactionLogType WHEN @TransactionLogType_Member THEN @GetHistoryOutputQuery ELSE N'' END + N'  
                    FROM #MemberWorkingSet ws  
                    INNER JOIN mdm.' + QUOTENAME(@HierarchyTableName) + N' hr  
                    ON ws.MemberID = hr.Child_EN_ID  
                    WHERE   ws.ErrorCode IS NULL  
                        AND hr.Version_ID = @Version_ID;';  
                END  
              
                IF @MemberType_ID = @MemberType_Consolidated  
                BEGIN  
                    SET @SQL += @TruncationGuard + N'  
                    UPDATE hr  
                    SET Status_ID = @Status_ID,  
                        LastChgDTM = GETUTCDATE(),  
                        LastChgUserID = @User_ID,  
                        LastChgVersionID = @Version_ID' + @SqlLevelString + CASE @TransactionLogType WHEN @TransactionLogType_Member THEN @GetHistoryOutputQuery ELSE N'' END + N'  
                    FROM #MemberWorkingSet ws  
                    INNER JOIN mdm.' + QUOTENAME(@HierarchyTableName) + N' hr  
                    ON ws.MemberID = hr.Child_HP_ID  
                    WHERE   ws.ErrorCode IS NULL  
                        AND hr.Version_ID = @Version_ID  
  
                    --Update children of consolidated nodes to Root and reset level number for recalculation  
                    UPDATE hr  
                    SET Parent_HP_ID = NULL' + @SqlLevelString + CASE @TransactionLogType WHEN @TransactionLogType_Member THEN @GetHistoryOutputQuery ELSE N'' END + '  
                    FROM #MemberWorkingSet ws  
                    INNER JOIN mdm.' + QUOTENAME(@HierarchyTableName) + N' hr  
                        ON ws.MemberID = hr.Parent_HP_ID  
                    WHERE ws.ErrorCode IS NULL  
                        AND hr.Version_ID = @Version_ID;'  
                END  
  
                IF @Debug = 1 PRINT @SQL  
                EXEC sp_executesql @SQL, N'@Version_ID INT, @Status_ID TINYINT, @User_ID INT', @Version_ID, @Status_ID, @User_ID;  
            END  
  
            DECLARE @CurrentTime DATETIME2(3) = GETUTCDATE();  
  
           --Log the transactions only log it if the logging flag is set.  
           IF @TransactionLogType = @TransactionLogType_Attribute  
           BEGIN  
                IF @Debug = 1 PRINT N'Log the transactions'  
  
                DECLARE @TransactionTableName sysname = mdm.udfGetTransactionTableName(@Model_ID);  
                SET @SQL = N'  
                INSERT INTO mdm.' + QUOTENAME(@TransactionTableName) + N'  
                (  
                     TransactionType_ID  
                    ,OriginalTransaction_ID  
                    ,Hierarchy_ID  
                    ,Version_ID  
                    ,[Entity_ID]  
                    ,Attribute_ID  
                    ,Member_ID  
                    ,Member_MUID  
                    ,MemberType_ID  
                    ,MemberCode  
                    ,OldValue  
                    ,OldCode  
                    ,NewValue  
                    ,NewCode  
                    ,EnterDTM  
                    ,EnterUserID  
                    ,LastChgDTM  
                    ,LastChgUserID  
                )  
                SELECT  
                     @TransactionType_ChangeMemberStatus --TransactionType_ID  
                    ,0 --OriginalTransaction_ID  
                    ,NULL-- Hierarchy_ID  
                    ,@Version_ID  
                    ,@Entity_ID  
                    ,NULL -- Attribute_ID  
                    ,MemberID  
                    ,MemberMUID  
                    ,@MemberType_ID  
                    ,MemberCode  
                    ,CONVERT(NVARCHAR, OldStatus) --OldValue  
                    ,N'''' --OldCode  
                    ,CONVERT(NVARCHAR, @Status_ID) --NewValue  
                    ,N'''' --NewCode  
                    ,@CurrentTime  
                    ,@User_ID  
                    ,@CurrentTime  
                    ,@User_ID  
                FROM #MemberWorkingSet  
                WHERE ErrorCode IS NULL;  
                ';  
                EXEC sp_executesql @SQL, N'@TransactionType_ChangeMemberStatus INT, @Entity_ID INT, @Version_ID INT, @Status_ID INT, @CurrentTime DATETIME2(3), @User_ID INT, @MemberType_ID TINYINT',  
                                           @TransactionType_ChangeMemberStatus,     @Entity_ID,     @Version_ID,     @Status_ID,     @CurrentTime,              @User_ID,     @MemberType_ID;  
  
            END; -- IF @TransactionType = @TransactionType_Column  
        END;  
  
        IF EXISTS (SELECT 1 FROM #MemberWorkingSet WHERE ErrorCode IS NOT NULL)  
        BEGIN  
            IF @RaiseFirstError = 1  
            BEGIN  
                DECLARE @FirstError NVARCHAR(MAX);  
                SELECT TOP 1  
                    @FirstError = CONCAT('MDSERR', ErrorCode, N'|<error message placeholder, will be replaced by localized string in C# layer>',CASE WHEN ErrorParameters IS NOT NULL THEN CONCAT(N'|', ErrorParameters, N'|') END)  
                FROM #MemberWorkingSet  
                WHERE ErrorCode IS NOT NULL;  
  
                IF LEN(@FirstError) > 0  
                BEGIN  
                    RAISERROR(@FirstError, 16, 1);  
                END  
            END ELSE  
            BEGIN  
  
                -- Return error rows.  
                SELECT  
                    ErrorCode,  
                    ErrorParameters,  
                    @ObjectType_MemberId AS ErrorObjectType,  
                    MemberID,  
                    MemberMUID,  
                    MemberCode,  
                    NULL AS MemberName,  
                    NULL AS AttributeMUID,  
                    NULL AS AttributeName  
                FROM #MemberWorkingSet  
                WHERE ErrorCode IS NOT NULL;  
            END;  
        END;  
  
        --Commit only if we are not nested.  
          
        IF @TransactionBehavior = @TransactionBehavior_AllOrNothingByBatch  
            AND EXISTS(SELECT 1 FROM #MemberWorkingSet WHERE ErrorCode IS NOT NULL)  
        BEGIN  
            IF @TranCounter = 0  
            BEGIN  
                ROLLBACK TRANSACTION;  
            END  
  
            RETURN 0;  
        END  
        ELSE  
        BEGIN  
            IF @TranCounter = 0  
            BEGIN  
                COMMIT TRANSACTION;  
            END  
  
            RETURN 1;  
        END;  
  
        IF @Debug = 1 PRINT N'udpMembersStatusSet DONE'  
  
    END TRY  
    --Compensate as necessary  
    BEGIN CATCH  
  
        -- Get error info.  
        DECLARE  
            @ErrorMessage NVARCHAR(4000),  
            @ErrorSeverity INT,  
            @ErrorState INT,  
            @ErrorNumber INT,  
            @ErrorLine INT,  
            @ErrorProcedure NVARCHAR(126);  
        EXEC mdm.udpGetErrorInfo  
            @ErrorMessage = @ErrorMessage OUTPUT,  
            @ErrorSeverity = @ErrorSeverity OUTPUT,  
            @ErrorState = @ErrorState OUTPUT,  
            @ErrorNumber = @ErrorNumber OUTPUT,  
            @ErrorLine = @ErrorLine OUTPUT,  
            @ErrorProcedure = @ErrorProcedure OUTPUT  
  
        SET @ErrorMessage = CONCAT(@ErrorMessage, N', @ErrorNumber = ', @ErrorNumber, N', @ErrorProcedure = "', @ErrorProcedure, N'", line ', @ErrorLine);  
  
        IF @TranCounter = 0  
        BEGIN  
            ROLLBACK TRANSACTION;  
        END ELSE IF XACT_STATE() <> -1  
        BEGIN  
            ROLLBACK TRANSACTION TX;  
        END;  
  
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);  
  
        RETURN;  
  
    END CATCH;  
  
    SET NOCOUNT OFF;  
END; --proc
go

