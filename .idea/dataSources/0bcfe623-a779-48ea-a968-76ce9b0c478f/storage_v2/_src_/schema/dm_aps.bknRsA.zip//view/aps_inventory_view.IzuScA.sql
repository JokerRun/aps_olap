create view aps_inventory_view as
select `itmh`.`item_nr`                   AS `item_id`,
       `loch`.`location_nr`               AS `location_id`,
       `invs`.`type`                      AS `type`,
       `invs`.`onhand`                    AS `onhand`,
       ifnull(`invs`.`available`, 'true') AS `available`,
       `invs`.`category`                  AS `category`,
       `invs`.`subcategory`               AS `subcategory`,
       `invs`.`description`               AS `description`,
       `invs`.`created_at`                AS `created_at`,
       `invs`.`updated_at`                AS `updated_at`,
       `invs`.`load_date`                 AS `load_date`,
       `invs`.`load_end_date`             AS `load_end_date`
from (((`raw_data_vault`.`link_inventory` `invl` join `raw_data_vault`.`l_sat_inventory` `invs` on ((`invl`.`l_inventory_hk` = `invs`.`l_inventory_hk`))) join `raw_data_vault`.`hub_location` `loch` on ((`invl`.`h_location_hk` = `loch`.`h_location_hk`)))
         join `raw_data_vault`.`hub_item` `itmh` on ((`invl`.`h_item_hk` = `itmh`.`h_item_hk`)));

