create
    definer = root@`%` procedure spcom_idsequence(IN IN_LANGUAGE varchar(50), IN IN_IDNAME varchar(50),
                                                  IN IN_SEQUENCE_NAME varchar(50), OUT OUT_RETURNNO varchar(50))
BEGIN
	DECLARE
		R_I INT;
	DECLARE
		R_IDNAME VARCHAR ( 20 );
	DECLARE
		R_PROJECTNO VARCHAR ( 20 );
	DECLARE
		R_PREFIX VARCHAR ( 20 );
	
	SET R_IDNAME = TRIM( IN_IDNAME );
	SET R_PROJECTNO = TRIM( IN_SEQUENCE_NAME );

	BEGIN
		SELECT
			MAX_ID_SEQUENCE,
			PREFIX INTO R_I,
			R_PREFIX 
		FROM
			apqp_sys_idesequence_project 
		WHERE
			project_no = R_PROJECTNO 
			AND IDNAME = R_IDNAME FOR UPDATE;
		
	END;
	IF
		R_I IS NULL THEN
			
			SET R_I = 0;
		IF R_IDNAME = 'PROJECTNR' THEN
				SET R_PREFIX = 'ZLXM';
		ELSEIF  	R_IDNAME = 'TEMPLATENR' THEN		
				SET R_PREFIX = 'TL';
			ELSEIF  	R_IDNAME = 'TASKNR' THEN		
				SET R_PREFIX = 'ZLRW';
		END IF;
		INSERT INTO apqp_sys_idesequence_project ( project_no, IDNAME, MAX_ID_SEQUENCE, PREFIX )
		VALUES
			( R_PROJECTNO, R_IDNAME, R_I, R_PREFIX );
		
	END IF;
	
	SET R_I = R_I + 1;
	IF
		IN_LANGUAGE IS NULL || IN_LANGUAGE = '' THEN
			
			SET OUT_RETURNNO = CONCAT( TRIM( R_PREFIX ), TRIM( R_PROJECTNO ), SUBSTR( '0000', 1, 4 - LENGTH( R_I ) ), R_I );
		ELSE 
			SET OUT_RETURNNO = CONCAT( TRIM( IN_LANGUAGE ), TRIM( R_PROJECTNO ), SUBSTR( '0000', 1, 4 - LENGTH( R_I ) ), R_I );
		
	END IF;
	UPDATE apqp_sys_idesequence_project 
	SET MAX_ID_SEQUENCE = R_I 
	WHERE
		project_no = R_PROJECTNO 
		AND IDNAME = R_IDNAME;
	COMMIT;

END;

