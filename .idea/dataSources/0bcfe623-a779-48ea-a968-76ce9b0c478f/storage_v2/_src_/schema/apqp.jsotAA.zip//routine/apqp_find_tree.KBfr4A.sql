create
    definer = root@`%` procedure apqp_find_tree(IN parentId bigint, IN nDepth int)
BEGIN
DECLARE done INT DEFAULT 0;
DECLARE b int;
DECLARE cur1 CURSOR FOR SELECT id FROM apqp_pm_task where parent_id=parentId and disabled=1;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
insert into tempTask values (null,parentId,nDepth);
SET @@max_sp_recursion_depth = 10;
OPEN cur1;

FETCH cur1 INTO b;
WHILE done=0 DO
CALL apqp_find_tree(b,nDepth+1);
FETCH cur1 INTO b;
END WHILE;

CLOSE cur1;
END;

