create
    definer = root@`%` procedure apqp_show_child(IN pid bigint)
BEGIN
CREATE TEMPORARY TABLE IF NOT EXISTS tempTask
(sno int primary key auto_increment,task_id bigint(20),depth int);
DELETE FROM tempTask;

CALL apqp_find_tree(pid,0);

select apqp_pm_task.* from tempTask,apqp_pm_task where tempTask.task_id=apqp_pm_task.id order by tempTask.sno;
END;

