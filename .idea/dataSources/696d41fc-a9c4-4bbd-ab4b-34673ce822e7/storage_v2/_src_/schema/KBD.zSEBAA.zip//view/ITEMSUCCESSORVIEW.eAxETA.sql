create view ITEMSUCCESSORVIEW as
SELECT '' ID,bmd01 item_id,bmd04 item_successor_id,bmd08 bom_item_id, bmd02 relation_type,bmd03 priority,'' ratio,bmdud03 used_qty,

bmdud02 change_qty,bmd05 effective_start,

bmd06 effective_end,'' created_at,'' updated_at FROM bmd_file
/

