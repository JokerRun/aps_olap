create view CALENDERVIEW as
SELECT
	'' "name",
	'' "source",
	'' "defaultvalue",
	'' "category",
	'' "subcategory",
	'' "description",
	'' "lastmodified",
	'' "created_at",
	'' "updated_at"
FROM
	dual
/

