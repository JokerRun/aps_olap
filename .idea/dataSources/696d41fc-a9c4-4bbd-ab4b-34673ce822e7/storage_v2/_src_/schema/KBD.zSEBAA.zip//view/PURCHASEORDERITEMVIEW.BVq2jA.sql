create view PURCHASEORDERITEMVIEW as
SELECT '' "id",pmn02	"line_no",pmn04	"item_id",pmn01	"purchase_order_id",''	"order_at",pmn20	"qty",''	"open_qty",pmn20-pmn50+pmn55+pmn58	"git_qty",
pmn51	"check_qty",pmn53	"instock_qty",pmn16	"status",pmn33	"due",'' "schedule_arrive_at",''	"start_ship_at",''	"actual_arrive_at",''	"delay",
'' "warning_delay",''	"created_at",''	"updated_at" FROM pmn_file
/

