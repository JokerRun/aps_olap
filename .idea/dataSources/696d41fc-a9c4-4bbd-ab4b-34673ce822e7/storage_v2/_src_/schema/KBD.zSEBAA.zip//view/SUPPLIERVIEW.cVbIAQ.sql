create view SUPPLIERVIEW as
SELECT
	'' "lft",
	'' "rght",
	'' "lvl",
	pmc01 "nr",
	pmc03 "name",
	pmc908 "area",
	pmc091 "address",
	'' "ship_address",
	pmc07 "country",
	'' "city",
	'' "phone",
	'' "telephone",
	'' "contact",
	'' "email",
	'' "available_id",
	'' "owner_id",
	'' "category",
	'' "subcategory",
	'' "description",
	'' "lastmodified",
	'' "created_at",
	'' "updated_at"
FROM
	pmc_file
/

