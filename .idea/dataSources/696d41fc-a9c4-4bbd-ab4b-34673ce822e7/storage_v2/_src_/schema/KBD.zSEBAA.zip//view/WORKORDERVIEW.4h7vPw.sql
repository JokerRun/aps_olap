create view WORKORDERVIEW as
SELECT '' "id",sfb01	"nr",''	"location_id",sfb05 "item_id",sfb08 "qty",sfb09 "finished_qty",sfb04	"status",sfb81	"order_at",sfb13	"schedule_start_at",sfb25	"actual_start_at",
''	"schedule_end_at",''	"actual_end_at",''	"delay",''	"created_at",''	"updated_at" FROM sfb_file
/

