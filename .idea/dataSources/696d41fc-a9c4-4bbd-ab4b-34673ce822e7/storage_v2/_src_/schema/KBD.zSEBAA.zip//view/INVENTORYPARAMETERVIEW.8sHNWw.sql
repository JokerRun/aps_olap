create view INVENTORYPARAMETERVIEW as
SELECT '' "id",img01	"item_id",img02	"location_id",''	"rop_cover_period",''	"rop",''	"rop_by_system",''	"safetystock_cover_period",
''	"safetystock_min_qty",''	"safetystock_max_qty",''	"safetystock_qty_by_system",''	"has_rop",''	"has_safetystock",''	"service_level",
''	"created_at",''	"updated_at" FROM img_file
/

