create view FORECASTVIEW as
SELECT '' "id",ta_opd03	"item_id",''	"location_id",''	"customer_id",ta_opd04	"date",''	"date_type",''	"priority",''	"ratio",ta_opd06	"normal_qty",
''	"new_product_plan_qty",''	"promotion_qty",''	"status",''	"create_user_id",ta_opd01	"version_id",''	"parsed_date",''	"created_at",
''	"updated_at" FROM ta_opd_file
/

