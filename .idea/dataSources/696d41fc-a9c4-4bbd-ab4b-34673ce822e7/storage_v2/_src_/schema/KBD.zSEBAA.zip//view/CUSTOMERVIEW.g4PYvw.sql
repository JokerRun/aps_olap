create view CUSTOMERVIEW as
SELECT
	'' "lft",
	'' "rght",
	'' "lvl",
	occ01 "nr",
	occ02 "name",
	'' "area",
	'' "address",
	'' "ship_address",
	'' "source",
	'' "available_id",
	'' "owner_id",
	'' "category",
	'' "subcategory",
	'' "description",
	'' "lastmodified",
	'' "created_at",
	'' "updated_at"
FROM
	occ_file
/

