create view FORECASTVERSIONVIEW as
SELECT '' "id",ta_opc01	"nr",ta_opc07	"status",ta_opc05	"create_user_id",ta_opc02	"created_at",''	"updated_at"  FROM ta_opc_file
/

