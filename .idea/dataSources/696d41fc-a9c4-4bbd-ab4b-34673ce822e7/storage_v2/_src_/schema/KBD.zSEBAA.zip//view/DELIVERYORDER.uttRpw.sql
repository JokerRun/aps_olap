create view DELIVERYORDER as
SELECT '' "id",imm01	"nr",''	"source_location_id",immud02	"destination_location_id",''	"type",immud02	"deliver_id",''	"deliver_source_id",
imm03	"status",''	"schedule_arrive_at",''	"start_ship_at",''	"actual_arrive_at",''	"delay",''	"created_at",''	"updated_at" FROM imm_file
/

