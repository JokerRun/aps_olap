create view ITEMSUPPLIERVIEW as
SELECT
-- TODO: \"status\":[\"\\\"N\\\" is not a valid choice.\"],
-- \"cost\":[\"This field may not be null.\"],
-- \"monetary_unit\":[\"This field may not be null.\"],
-- \"cost_unit\":[\"This field may not be null.\"],
-- \"priority\":[\"This field may not be null.\"],
-- \"order_max_qty\":[\"This field may not be null.\"]}

	ima01 "item_id",
	pmc01 "supplier_id",
	'WCTZ' "location_id",
	'' "supplier_item_nr",
	imaacti "status",
	'' "cost",
	'' "monetary_unit",
	'' "cost_unit",
	'' "priority",
	'' "ratio",
	ima46 "moq",
	ima45 "order_unit_qty",
	'' "order_max_qty",
	'' "product_time",
	ima48 "load_time",
	ima49 "transit_time",
	ima491 "receive_time",
	ima45 "mpq",
	'' "earliest_order_date",
	'' "plan_supplier_date",
	'' "plan_load_date",
	'' "plan_receive_date",
	'' "outer_package_num",
	'' "pallet_num",
	'' "outer_package_gross_weight",
	'' "pallet_gross_weight",
	'' "outer_package_volume",
	'' "pallet_volume",
	'' "plan_list_date",
	'' "plan_delist_date",
	'' "origin_country",
	'' "effective_start",
	'' "effective_end",
	'' "description",
	'' "lastmodified",
	'' "created_at",
	'' "updated_at"
FROM
	ima_file
LEFT JOIN pmc_file ON pmc01 = ima54
/

