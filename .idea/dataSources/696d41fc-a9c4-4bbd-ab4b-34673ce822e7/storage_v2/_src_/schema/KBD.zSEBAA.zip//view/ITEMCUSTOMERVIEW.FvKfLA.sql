create view ITEMCUSTOMERVIEW as
SELECT
--  "message": "FieldError at /api/basics/itemcustomer\nCannot resolve keyword 'client' into field. 
-- Choices are: created_at, customer, customer_id, customer_item_nr, effective_end, effective_start, 
--id, lastmodified, location, location_id, lock_expire_at, lock_type, plan_delist_date, plan_list_date,
-- product_item, product_item_id, sale_item, sale_item_id, source, status, updated_at
	obk01 "sale_item_id",
	obk01 "product_item_id",
	obk02 "customer_id",
	'WCTZ' "location_id",
	obk03 "customer_item_nr",
	'' "status",
	'' "lock_type",
	'' "lock_expire_at",
	'' "plan_list_date",
	'' "plan_delist_date",
	'' "effective_start",
	'' "effective_end",
	'' "created_at",
	'' "updated_at"
FROM
	obk_file
/

