create view WORKORDERITEM as
SELECT '' "id",sfa01	"workorder_id",sfa03	"item_id",sfa05	"total_qty",sfa06	"delivered_qty",sfa05-sfa06	"notdelivered_qty",
''	"status",''	"order_at",''	"schedule_start_at",''	"actual_start_at",''	"schedule_end_at",''	"actual_end_at",''	"delay",
''	"created_at",''	"updated_at" FROM sfa_file
/

