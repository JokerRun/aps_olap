create view DEMANDORDERVIEW as
SELECT '' "id",oea01	"nr",''	"location_id",oea03	"destination_location_id",oea03	"customer_id",oeaconf	"status",''	"max_lateness",
''	"min_shipment",''	"category",''	"subcategory",''	"description",''	"created_at",''	"updated_at" FROM oea_file
/

