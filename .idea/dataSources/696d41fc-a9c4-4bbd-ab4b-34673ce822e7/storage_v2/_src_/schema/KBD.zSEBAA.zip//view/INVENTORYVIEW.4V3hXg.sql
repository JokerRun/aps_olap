create view INVENTORYVIEW as
SELECT '' "id",img01	"item_id",img02	"location_id",''	"type",img10	"onhand",''	"available",''	"category",''	"subcategory",''	"description",
''	"created_at",''	"updated_at" FROM img_file
/

