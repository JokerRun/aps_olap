create view DEMANDORDERITEM as
SELECT '' "id",oeb03	"line_no",oeb01	"demand_order_id",oeb04	"item_id",oeb12	"qty",oeb12	"schedule_qty",''	"deliver_qty",
''	"order_at",oeb16	"due",''	"priority",''	"status",''	"max_lateness",''	"min_shipment",''	"delay",
''	"closed_at",''	"created_at",''	"updated_at" FROM oeb_file
/

