create view CALENDARBUCKETVIEW as
SELECT
	'' "calendar",
	MIN (sme01) "startdate",
	MAX (sme01) "enddate",
	'' "value",
	'' "priority",
	'Y' "monday",
	'Y' "tuesday",
	'Y' "wednesday",
	'Y' "thursday",
	'Y' "friday",
	'Y' "saturday",
	'N' "sunday",
	'' "starttime",
	'' "endtime",
	'' "source",
	'' "lastmodified",
	'' "created_at",
	'' "updated_at"
FROM
	sme_file
/

