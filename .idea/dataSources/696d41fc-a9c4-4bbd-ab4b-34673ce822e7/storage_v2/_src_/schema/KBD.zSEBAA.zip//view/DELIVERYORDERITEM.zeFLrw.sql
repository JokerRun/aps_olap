create view DELIVERYORDERITEM as
SELECT '' "id",imn02	"line_no",imn03	"item_id",imn01	"delivery_order_id",imnud03	"deliver_source_id",imn10	"deliver_qty",
imn10	"actual_deliver_qty",''	"not_deliver_qty",''	"git_qty",''	"check_qty",''	"instock_qty",''	"status",''	"start_ship_at",
''	"actual_arrive_at",''	"delay",''	"created_at",''	"updated_at" FROM imn_file
/

