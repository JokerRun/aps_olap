create view PURCHASEORDERVIEW as
SELECT '' "id",pmm01	"nr",''	"location_id",pmm09	"supplier_id",pmm25	"status",pmm04	"order_at",''	"schedule_arrive_at",''	"start_ship_at",
''	"actual_arrive_at",''	"delay",''	"created_at",''	"updated_at"  FROM pmm_file
/

