create view INVENTORYMOVEMENTVIEW as
SELECT '' "id",tlf10	"qty",	tlf021 "source_location_nr",tlf031	"destination_location_nr",'' "location",tlf01	"item_nr",
tlf02	"operate_type",tlf026	"operate_doc_nr",
''	"operate_doc_line_nr",tlf02	"operate_doc_type",tlf02	"origin_doc_type",tlf026	"operate_doc_entity_nr",tlf07	"operated_at"
FROM tlf_file
/

