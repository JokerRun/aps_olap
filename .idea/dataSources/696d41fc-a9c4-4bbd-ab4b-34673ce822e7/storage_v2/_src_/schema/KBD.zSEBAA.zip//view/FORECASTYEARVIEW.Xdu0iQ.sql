create view FORECASTYEARVIEW as
SELECT '' "id",''	"item_id",''	"location_id",''	"customer_id",''	"date",''	"date_type",''	"ratio",''	"normal_qty",''	"new_product_plan_qty",
''	"promotion_qty",''	"parsed_date",''	"created_at",''	"updated_at" FROM dual
/

