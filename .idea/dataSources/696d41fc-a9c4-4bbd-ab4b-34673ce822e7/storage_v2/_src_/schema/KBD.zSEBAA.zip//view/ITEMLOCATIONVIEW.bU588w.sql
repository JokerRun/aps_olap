create view ITEMLOCATIONVIEW as
SELECT
-- \"status\":[\"\\\"N\\\" is not a valid choice.\"],\"order_max_qty\":[\"This field may not be null.\"]
	ima01 "item_id",
	'WCTZ' "location_id",
-- TODO： 待讨论：ima09 改为 ima 06是否合理？ 
	ima09 "type",
-- TODO： 在Item中，status字段默认给的是空值，此处用的是 imaacti 字段，需要怎么处理该字段与APS的映射关系？？？

	imaacti "status",
	'' "plan_strategy",
	'' "lock_type",
	'' "lock_expire_at",
	'' "inventory_qty",
	'' "available_inventory",
	'' "inventory_cost",
	ima07 "price_abc",
	'' "qty_abc",
	'' "cost",
	'' "gross_weight",
	'' "net_weight",
	ima25 "physical_unit",
	ima021 "project_nr",
	ima46 "moq",
	ima45 "order_unit_qty",
	'' "order_max_qty",
	ima59 + ima61 "product_time",
	ima48 "load_time",
	ima49 "transit_time",
	ima491 "receive_time",
	ima45 "mpq",
	'' "earliest_order_date",
	'' "plan_supplier_date",
	'' "plan_load_date",
	'' "plan_receive_date",
	'' "outer_package_num",
	'' "pallet_num",
	'' "outer_package_gross_weight",
	'' "pallet_gross_weight",
	'' "outer_package_volume",
	'' "pallet_volume",
	'' "plan_list_date",
	'' "plan_delist_date",
	ima109 "category",
	'' "subcategory",
	ima02 "description"
FROM
	ima_file
/

