create view LOCATIONVIEW as
SELECT
	'' "id",
	'' "lft",
	'' "rght",
	'' "lvl",
	imd01 "nr",
	'' "name",
	'' "area",
	'' "source",
	'' "available_id",
	imd11 "available",
	'' "owner_id",
	'' "category",
	'' "subcategory",
	'' "description",
	'' "lastmodified",
	'' "created_at",
	'' "updated_at"
FROM
	imd_file
/

