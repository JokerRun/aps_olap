create view ITEMBOMVIEW as
SELECT
-- TODO: aps中nr字段要求不为空，此处nr如何处理？ 可否直接拼接 itemid+owner id 作为nr??
-- TODO：aps接口要求传item、parent,而非id，该接口是否需要改造？
	bmb01||bmb03 "nr",
	bmb03 "item_id",
	'WCTZ' "itemlocation_id",
	bmb01 "owner_id",
	bmb06 "qty",
	bmb10 "unit",
	bmb04 "effective_start",
	bmb05 "effective_end",
	'' "created_at",
	'' "updated_at"
FROM
	bmb_file
/

