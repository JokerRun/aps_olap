create definer = root@`%` view fact_inventory_daily_snapshot_view as
select `invl`.`l_inventory_hk`                   AS `inventory_key`,
       date_format(`invl`.`load_date`, '%Y%m%d') AS `date_key`,
       `invl`.`h_location_hk`                    AS `location_key`,
       `invl`.`h_item_hk`                        AS `item_key`,
       `invl`.`storage_location`                 AS `storage_location`,
       `invl`.`batch_nr`                         AS `batch_nr`,
       `invs`.`onhand`                           AS `onhand`
from (((`dw_raw`.`link_inventory` `invl` join `dw_raw`.`l_sat_inventory` `invs` on ((`invl`.`l_inventory_hk` = `invs`.`l_inventory_hk`))) join `dw_raw`.`hub_location` `loch` on ((`invl`.`h_location_hk` = `loch`.`h_location_hk`)))
         join `dw_raw`.`hub_item` `itmh` on ((`invl`.`h_item_hk` = `itmh`.`h_item_hk`)));

