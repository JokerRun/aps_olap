create definer = root@`%` view req_purchase as
select `req`.`fld1`                                             AS `req_no`,
       `req`.`fld4`                                             AS `req_person`,
       `req`.`fld3`                                             AS `req_date`,
       `req`.`fld5`                                             AS `req_item_code`,
       `req`.`fld23`                                            AS `req_audit_date`,
       `req`.`fld22`                                            AS `req_auditor`,
       `pur`.`fld3`                                             AS `po_no`,
       `pur`.`fld4`                                             AS `po_date`,
       `pur`.`fld7`                                             AS `po_buyer`,
       (to_days(`pur`.`fld4`) - to_days(`req`.`fld23`))         AS `date_diff`,
       ((to_days(`pur`.`fld4`) - to_days(`req`.`fld23`)) <= 14) AS `satified`
from (`supplychain`.`requisition` `req`
         left join `supplychain`.`purchase` `pur`
                   on (((`req`.`fld1` = `pur`.`fld2`) and (`req`.`fld5` = `pur`.`fld13`))));

