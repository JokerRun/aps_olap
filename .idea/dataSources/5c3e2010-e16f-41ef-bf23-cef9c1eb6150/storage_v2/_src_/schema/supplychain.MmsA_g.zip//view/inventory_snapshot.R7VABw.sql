create definer = root@`%` view inventory_snapshot as
select `supplychain`.`ito`.`fld1`    AS `snapshot_date`,
       `supplychain`.`ito`.`fld2`    AS `item_code`,
       `supplychain`.`ito`.`fld3`    AS `item_name`,
       `supplychain`.`ito`.`fld4`    AS `spec`,
       `supplychain`.`ito`.`fld5`    AS `warehouse`,
       `supplychain`.`ito`.`fld6`    AS `wh_name`,
       `supplychain`.`ito`.`fld7`    AS `batch`,
       `supplychain`.`ito`.`fld8`    AS `inventory`,
       `supplychain`.`ito`.`fld9`    AS `unit`,
       `supplychain`.`ito`.`fld10`   AS `idle_day`,
       (case
            when (`supplychain`.`ito`.`fld11` > 0) then '0-0.5年'
            when (`supplychain`.`ito`.`fld13` > 0) then '0.5-1年'
            when (`supplychain`.`ito`.`fld15` > 0) then '1-2年'
            when (`supplychain`.`ito`.`fld17` > 0) then '2-3年'
            when (`supplychain`.`ito`.`fld19` > 0) then '3-4年'
            when (`supplychain`.`ito`.`fld21` > 0) then '4-5年'
            else '5年以上' end)         AS `item_age`,
       ((((((`supplychain`.`ito`.`fld12` + `supplychain`.`ito`.`fld14`) + `supplychain`.`ito`.`fld16`) +
           `supplychain`.`ito`.`fld18`) + `supplychain`.`ito`.`fld20`) + `supplychain`.`ito`.`fld22`) +
        `supplychain`.`ito`.`fld24`) AS `item_value`,
       `supplychain`.`ito`.`fld25`   AS `item_subject`,
       `supplychain`.`ito`.`fld26`   AS `item_subject_name`
from `supplychain`.`ito`;

