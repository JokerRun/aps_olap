create definer = root@`%` view po_receipt as
select `pur`.`fld7`                                                 AS `po_buyer`,
       `pur`.`fld3`                                                 AS `po_no`,
       `pur`.`fld5`                                                 AS `po_patch`,
       `pur`.`fld13`                                                AS `po_item_code`,
       `pur`.`fld19`                                                AS `po_num`,
       `pur`.`fld11`                                                AS `po_deadline`,
       `pur`.`fld32`                                                AS `po_return_num`,
       (`bs`.`fld9` * `pur`.`fld31`)                                AS `base_price`,
       ((`bs`.`fld9` * `pur`.`fld31`) * `pur`.`fld19`)              AS `base_amount`,
       (`pur`.`fld33` * `pur`.`fld31`)                              AS `po_price`,
       ((`pur`.`fld33` * `pur`.`fld31`) * `pur`.`fld19`)            AS `po_amount`,
       `rec`.`fld6`                                                 AS `rc_no`,
       `rec`.`fld7`                                                 AS `rc_patch`,
       `rec`.`fld15`                                                AS `rc_num`,
       `rec`.`fld8`                                                 AS `rc_date`,
       (`rec`.`fld31` * ifnull(`rec`.`fld39`, 1))                   AS `rc_price`,
       ((`rec`.`fld31` * ifnull(`rec`.`fld39`, 1)) * `rec`.`fld15`) AS `rc_amount`,
       (`pur`.`fld11` < now())                                      AS `overdue`,
       (to_days(`rec`.`fld8`) - to_days(`pur`.`fld11`))             AS `time_diff`,
       (-(14) > (to_days(`rec`.`fld8`) - to_days(`pur`.`fld11`)))   AS `lead`,
       (3 < (to_days(`rec`.`fld8`) - to_days(`pur`.`fld11`)))       AS `lag`,
       (((to_days(`rec`.`fld8`) - to_days(`pur`.`fld11`)) >= -(14)) and
        ((to_days(`rec`.`fld8`) - to_days(`pur`.`fld11`)) <= 3))    AS `intime`,
       (`rec`.`fld15` < 0)                                          AS `po_rc_rejected`
from ((`supplychain`.`purchase` `pur` left join `supplychain`.`receipt` `rec` on (((`pur`.`fld3` = `rec`.`fld4`) and (`pur`.`fld5` = `rec`.`fld5`))))
         left join `supplychain`.`base` `bs` on ((`pur`.`fld13` = `bs`.`fld4`)));

