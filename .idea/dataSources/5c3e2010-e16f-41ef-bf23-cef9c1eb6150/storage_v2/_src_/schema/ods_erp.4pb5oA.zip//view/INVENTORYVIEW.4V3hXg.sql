create definer = root@`%` view INVENTORYVIEW as
select `ods_erp`.`IMG_FILE`.`IMG01` AS `item_nr`,
       `ods_erp`.`IMG_FILE`.`IMG02` AS `location_nr`,
       `ods_erp`.`IMG_FILE`.`IMG03` AS `storage_location`,
       `ods_erp`.`IMG_FILE`.`IMG04` AS `batch_nr`,
       NULL                         AS `source`,
       NULL                         AS `lastmodified`,
       NULL                         AS `type`,
       `ods_erp`.`IMG_FILE`.`IMG10` AS `onhand`,
       NULL                         AS `available`,
       NULL                         AS `category`,
       NULL                         AS `subcategory`,
       NULL                         AS `description`,
       NULL                         AS `created_at`,
       NULL                         AS `updated_at`
from `ods_erp`.`IMG_FILE`;

