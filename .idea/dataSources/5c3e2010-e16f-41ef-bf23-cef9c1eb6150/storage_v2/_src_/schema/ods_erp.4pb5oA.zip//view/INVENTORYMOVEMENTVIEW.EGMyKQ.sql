create definer = root@`%` view INVENTORYMOVEMENTVIEW as
select NULL                          AS `id`,
       `ods_erp`.`TLF_FILE`.`TLF10`  AS `qty`,
       `ods_erp`.`TLF_FILE`.`TLF026` AS `source_location_nr`,
       `ods_erp`.`TLF_FILE`.`TLF036` AS `destination_location_nr`,
       NULL                          AS `location`,
       `ods_erp`.`TLF_FILE`.`TLF01`  AS `item_nr`,
       `ods_erp`.`TLF_FILE`.`TLF02`  AS `operate_type`,
       `ods_erp`.`TLF_FILE`.`TLF026` AS `operate_doc_nr`,
       NULL                          AS `operate_doc_line_nr`,
       `ods_erp`.`TLF_FILE`.`TLF02`  AS `operate_doc_type`,
       `ods_erp`.`TLF_FILE`.`TLF02`  AS `origin_doc_type`,
       `ods_erp`.`TLF_FILE`.`TLF026` AS `operate_doc_entity_nr`,
       `ods_erp`.`TLF_FILE`.`TLF07`  AS `operated_at`
from `ods_erp`.`TLF_FILE`;

