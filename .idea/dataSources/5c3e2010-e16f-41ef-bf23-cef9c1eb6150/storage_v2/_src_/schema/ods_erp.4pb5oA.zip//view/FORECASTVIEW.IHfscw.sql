create definer = root@`%` view FORECASTVIEW as
select NULL                               AS `id`,
       `ods_erp`.`TA_OPD_FILE`.`TA_OPD03` AS `item_id`,
       NULL                               AS `location_id`,
       NULL                               AS `customer_id`,
       `ods_erp`.`TA_OPD_FILE`.`TA_OPD04` AS `date`,
       NULL                               AS `date_type`,
       NULL                               AS `priority`,
       NULL                               AS `ratio`,
       `ods_erp`.`TA_OPD_FILE`.`TA_OPD06` AS `normal_qty`,
       NULL                               AS `new_product_plan_qty`,
       NULL                               AS `promotion_qty`,
       NULL                               AS `status`,
       NULL                               AS `create_user_id`,
       `ods_erp`.`TA_OPD_FILE`.`TA_OPD01` AS `version_id`,
       NULL                               AS `parsed_date`,
       NULL                               AS `created_at`,
       NULL                               AS `updated_at`
from `ods_erp`.`TA_OPD_FILE`;

