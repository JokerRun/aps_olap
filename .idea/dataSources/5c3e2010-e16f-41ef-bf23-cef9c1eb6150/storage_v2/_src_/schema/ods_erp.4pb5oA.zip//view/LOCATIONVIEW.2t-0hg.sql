create definer = root@`%` view LOCATIONVIEW as
select NULL                         AS `id`,
       NULL                         AS `lft`,
       NULL                         AS `rght`,
       NULL                         AS `lvl`,
       `ods_erp`.`IMD_FILE`.`IMD01` AS `nr`,
       `ods_erp`.`IMD_FILE`.`IMD02` AS `name`,
       NULL                         AS `area`,
       NULL                         AS `source`,
       NULL                         AS `available_id`,
       `ods_erp`.`IMD_FILE`.`IMD11` AS `available`,
       NULL                         AS `owner_id`,
       NULL                         AS `category`,
       NULL                         AS `subcategory`,
       NULL                         AS `description`,
       NULL                         AS `lastmodified`,
       NULL                         AS `created_at`,
       NULL                         AS `updated_at`
from `ods_erp`.`IMD_FILE`;

