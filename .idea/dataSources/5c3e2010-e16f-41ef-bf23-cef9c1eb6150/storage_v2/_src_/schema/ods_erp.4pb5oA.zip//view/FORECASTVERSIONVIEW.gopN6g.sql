create definer = root@`%` view FORECASTVERSIONVIEW as
select NULL                               AS `id`,
       `ods_erp`.`TA_OPC_FILE`.`TA_OPC01` AS `nr`,
       `ods_erp`.`TA_OPC_FILE`.`TA_OPC07` AS `status`,
       `ods_erp`.`TA_OPC_FILE`.`TA_OPC05` AS `create_user_id`,
       `ods_erp`.`TA_OPC_FILE`.`TA_OPC02` AS `created_at`,
       NULL                               AS `updated_at`
from `ods_erp`.`TA_OPC_FILE`;

