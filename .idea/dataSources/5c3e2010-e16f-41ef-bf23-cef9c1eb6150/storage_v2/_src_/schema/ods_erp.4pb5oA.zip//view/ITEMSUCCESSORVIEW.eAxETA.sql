create definer = root@`%` view ITEMSUCCESSORVIEW as
select NULL                           AS `ID`,
       `ods_erp`.`BMD_FILE`.`BMD01`   AS `item_id`,
       `ods_erp`.`BMD_FILE`.`BMD04`   AS `item_successor_id`,
       `ods_erp`.`BMD_FILE`.`BMD08`   AS `bom_item_id`,
       `ods_erp`.`BMD_FILE`.`BMD02`   AS `relation_type`,
       `ods_erp`.`BMD_FILE`.`BMD03`   AS `priority`,
       NULL                           AS `ratio`,
       `ods_erp`.`BMD_FILE`.`BMDUD03` AS `used_qty`,
       `ods_erp`.`BMD_FILE`.`BMDUD02` AS `change_qty`,
       `ods_erp`.`BMD_FILE`.`BMD05`   AS `effective_start`,
       `ods_erp`.`BMD_FILE`.`BMD06`   AS `effective_end`,
       NULL                           AS `created_at`,
       NULL                           AS `updated_at`
from `ods_erp`.`BMD_FILE`;

