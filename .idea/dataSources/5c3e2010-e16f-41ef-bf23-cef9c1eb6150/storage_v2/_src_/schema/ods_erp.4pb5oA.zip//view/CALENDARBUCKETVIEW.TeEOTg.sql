create definer = root@`%` view CALENDARBUCKETVIEW as
select NULL                              AS `calendar`,
       min(`ods_erp`.`SME_FILE`.`SME01`) AS `startdate`,
       max(`ods_erp`.`SME_FILE`.`SME01`) AS `enddate`,
       NULL                              AS `value`,
       NULL                              AS `priority`,
       'Y'                               AS `monday`,
       'Y'                               AS `tuesday`,
       'Y'                               AS `wednesday`,
       'Y'                               AS `thursday`,
       'Y'                               AS `friday`,
       'Y'                               AS `saturday`,
       'N'                               AS `sunday`,
       NULL                              AS `starttime`,
       NULL                              AS `endtime`,
       NULL                              AS `source`,
       NULL                              AS `lastmodified`,
       NULL                              AS `created_at`,
       NULL                              AS `updated_at`
from `ods_erp`.`SME_FILE`;

