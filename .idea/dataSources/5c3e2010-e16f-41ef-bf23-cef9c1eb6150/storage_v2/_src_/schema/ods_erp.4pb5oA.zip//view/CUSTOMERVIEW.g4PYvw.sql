create definer = root@`%` view CUSTOMERVIEW as
select NULL                         AS `lft`,
       NULL                         AS `rght`,
       NULL                         AS `lvl`,
       `ods_erp`.`OCC_FILE`.`OCC01` AS `nr`,
       `ods_erp`.`OCC_FILE`.`OCC02` AS `name`,
       NULL                         AS `area`,
       NULL                         AS `address`,
       NULL                         AS `ship_address`,
       NULL                         AS `source`,
       NULL                         AS `available_id`,
       NULL                         AS `owner_id`,
       NULL                         AS `category`,
       NULL                         AS `subcategory`,
       NULL                         AS `description`,
       NULL                         AS `lastmodified`,
       NULL                         AS `created_at`,
       NULL                         AS `updated_at`
from `ods_erp`.`OCC_FILE`;

