create definer = root@`%` view ITEMCUSTOMERVIEW as
select `ods_erp`.`OBK_FILE`.`OBK01` AS `sale_item_id`,
       `ods_erp`.`OBK_FILE`.`OBK01` AS `product_item_id`,
       `ods_erp`.`OBK_FILE`.`OBK02` AS `customer_id`,
       'WCTZ'                       AS `location_id`,
       `ods_erp`.`OBK_FILE`.`OBK03` AS `customer_item_nr`,
       NULL                         AS `status`,
       NULL                         AS `lock_type`,
       NULL                         AS `lock_expire_at`,
       NULL                         AS `plan_list_date`,
       NULL                         AS `plan_delist_date`,
       NULL                         AS `effective_start`,
       NULL                         AS `effective_end`,
       NULL                         AS `created_at`,
       NULL                         AS `updated_at`
from `ods_erp`.`OBK_FILE`;

