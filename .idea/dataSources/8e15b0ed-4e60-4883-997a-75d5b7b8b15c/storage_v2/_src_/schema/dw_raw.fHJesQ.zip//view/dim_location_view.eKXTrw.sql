create definer = root@`%` view dim_location_view as
select `hub`.`h_location_hk`      AS `h_location_hk`,
       `hub`.`load_date`          AS `load_date`,
       `hub`.`record_source`      AS `record_source`,
       `hub`.`location_nr`        AS `location_nr`,
       `sat`.`load_end_date`      AS `load_end_date`,
       `sat`.`location_hash_diff` AS `location_hash_diff`,
       `sat`.`storage_location`   AS `storage_location`,
       `sat`.`region`             AS `region`,
       `sat`.`organisation`       AS `organisation`,
       `sat`.`business_unit`      AS `business_unit`,
       `sat`.`id`                 AS `id`,
       `sat`.`lft`                AS `lft`,
       `sat`.`rght`               AS `rght`,
       `sat`.`lvl`                AS `lvl`,
       `sat`.`nr`                 AS `nr`,
       `sat`.`name`               AS `name`,
       `sat`.`area`               AS `area`,
       `sat`.`source`             AS `source`,
       `sat`.`available_id`       AS `available_id`,
       `sat`.`available`          AS `available`,
       `sat`.`owner_id`           AS `owner_id`,
       `sat`.`category`           AS `category`,
       `sat`.`subcategory`        AS `subcategory`,
       `sat`.`description`        AS `description`,
       `sat`.`lastmodified`       AS `lastmodified`,
       `sat`.`created_at`         AS `created_at`,
       `sat`.`updated_at`         AS `updated_at`,
       `sat`.`company`            AS `company`,
       `sat`.`type`               AS `type`
from (`dw_raw`.`hub_location` `hub`
         left join `dw_raw`.`h_sat_location` `sat`
                   on (((convert(`hub`.`h_location_hk` using utf8mb4) = `sat`.`h_location_hk`) and
                        isnull(`sat`.`load_end_date`))));

