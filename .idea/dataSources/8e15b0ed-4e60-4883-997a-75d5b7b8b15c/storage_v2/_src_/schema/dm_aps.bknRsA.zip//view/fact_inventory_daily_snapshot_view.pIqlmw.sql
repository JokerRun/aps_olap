create definer = root@`%` view fact_inventory_daily_snapshot_view as
select `invl`.`l_inventory_hk`                   AS `inventory_key`,
       date_format(`invl`.`load_date`, '%Y%m%d') AS `date_key`,
       `invl`.`h_location_hk`                    AS `location_key`,
       `invl`.`h_item_hk`                        AS `item_key`,
       `invl`.`storage_location`                 AS `storage_location`,
       `invl`.`batch_nr`                         AS `batch_nr`,
       date_format(`invs`.`dull_date`, '%Y%m%d') AS `dull_date_key`,
       `invs`.`receipt_doc`                      AS `receipt_doc`,
       `invs`.`receipt_seq`                      AS `receipt_seq`,
       `invs`.`receipt_unit`                     AS `receipt_unit`,
       `invs`.`receipt_qty`                      AS `receipt_qty`,
       `invs`.`dull_date`                        AS `dull_date`,
       `invs`.`source`                           AS `source`,
       `invs`.`type`                             AS `type`,
       `invs`.`onhand`                           AS `onhand`,
       `invs`.`available`                        AS `available`,
       `invs`.`mrp_available`                    AS `mrp_available`,
       `invs`.`category`                         AS `category`,
       `invs`.`subcategory`                      AS `subcategory`,
       `invs`.`description`                      AS `description`,
       `itms`.`unit`                             AS `unit`,
       `itms`.`unit_price`                       AS `unit_price`,
       (`invs`.`onhand` * `itms`.`unit_price`)   AS `onhand_value`
from ((((`dw_raw`.`link_inventory` `invl` join `dw_raw`.`l_sat_inventory` `invs` on ((
        convert(`invl`.`l_inventory_hk` using utf8mb4) =
        `invs`.`l_inventory_hk`))) join `dw_raw`.`hub_location` `loch` on ((`invl`.`h_location_hk` = `loch`.`h_location_hk`))) join `dw_raw`.`hub_item` `itmh` on ((`invl`.`h_item_hk` = `itmh`.`h_item_hk`)))
         left join `dw_raw`.`h_sat_item` `itms`
                   on (((convert(`invl`.`h_item_hk` using utf8mb4) = `itms`.`h_item_hk`) and
                        isnull(`itms`.`load_end_date`))));

