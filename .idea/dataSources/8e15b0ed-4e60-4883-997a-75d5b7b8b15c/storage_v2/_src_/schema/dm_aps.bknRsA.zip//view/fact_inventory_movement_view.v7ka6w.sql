create definer = root@`%` view fact_inventory_movement_view as
select `link`.`l_inventory_movement_hk`                                                  AS `l_inventory_movement_hk`,
       `link`.`h_item_hk`                                                                AS `h_item_hk`,
       `link`.`h_location_hk`                                                            AS `h_location_hk`,
       `link`.`h_inventory_doc_hk`                                                       AS `h_inventory_doc_hk`,
       date_format(`sat`.`movement_date`, '%Y%m%d')                                      AS `move_date_key`,
       date_format(`sat`.`inventory_doc_date`, '%Y%m%d')                                 AS `inventory_doc_date_key`,
       `sat`.`movement_time`                                                             AS `movement_time`,
       `sat`.`describsion`                                                               AS `describsion`,
       `sat`.`movement_department`                                                       AS `movement_department`,
       `sat`.`reason_code`                                                               AS `reason_code`,
       `sat`.`movement_org`                                                              AS `movement_org`,
       `sat`.`movement_unit`                                                             AS `movement_unit`,
       `item`.`unit_price`                                                               AS `unit_price`,
       `sat`.`operate_type`                                                              AS `operate_type`,
       `sat`.`movement_amount`                                                           AS `move_count`,
       (case `sat`.`operate_type`
            when 'inbound' then `sat`.`movement_amount`
            when 'outbound' then -(`sat`.`movement_amount`) end)                         AS `inventory_affected_count`,
       (`item`.`unit_price` * (case `sat`.`operate_type`
                                   when 'inbound' then `sat`.`movement_amount`
                                   when 'outbound' then -(`sat`.`movement_amount`) end)) AS `inventory_affected_amount`
from `dw_raw`.`link_inventory_movement` `link`
         join `dw_raw`.`l_sat_inventory_movement` `sat`
         join `dw_raw`.`h_sat_item` `item`
where ((`link`.`l_inventory_movement_hk` = `sat`.`l_inventory_movement_hk`) and
       ((`sat`.`load_end_date` = '9999-12-31') or isnull(`sat`.`load_end_date`)) and
       (`link`.`h_item_hk` = `item`.`h_item_hk`) and
       ((`item`.`load_end_date` = '9999-12-31') or isnull(`item`.`load_end_date`)));

