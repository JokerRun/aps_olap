create definer = root@`%` view dim_inventory_doc_view as
select distinct `link`.`h_inventory_doc_hk`    AS `h_inventory_doc_hk`,
                `sat`.`inventory_doc_nr`       AS `inventory_doc_nr`,
                `sat`.`inventory_doc_line`     AS `inventory_doc_line`,
                `sat`.`operate_type`           AS `operate_type`,
                `sat`.`movement_code`          AS `movement_code`,
                `sat`.`inventory_doc_operator` AS `inventory_doc_operator`
from `dw_raw`.`link_inventory_movement` `link`
         join `dw_raw`.`l_sat_inventory_movement` `sat`
where ((`link`.`l_inventory_movement_hk` = `sat`.`l_inventory_movement_hk`) and
       ((`sat`.`load_end_date` = '9999-12-31') or isnull(`sat`.`load_end_date`)));

