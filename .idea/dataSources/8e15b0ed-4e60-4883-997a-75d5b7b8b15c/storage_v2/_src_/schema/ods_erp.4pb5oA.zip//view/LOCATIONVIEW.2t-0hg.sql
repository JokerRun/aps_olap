create definer = root@`%` view LOCATIONVIEW as
select `ods_erp`.`IMD_FILE`.`IMD01` AS `storage_location`,
       `ods_erp`.`IMD_FILE`.`IMD20` AS `region`,
       `ods_erp`.`IMD_FILE`.`IMD20` AS `organisation`,
       `ods_erp`.`IMD_FILE`.`IMD08` AS `business_unit`,
       NULL                         AS `id`,
       NULL                         AS `lft`,
       NULL                         AS `rght`,
       NULL                         AS `lvl`,
       `ods_erp`.`IMD_FILE`.`IMD01` AS `nr`,
       `ods_erp`.`IMD_FILE`.`IMD02` AS `name`,
       `ods_erp`.`IMD_FILE`.`IMD03` AS `area`,
       NULL                         AS `source`,
       NULL                         AS `available_id`,
       `ods_erp`.`IMD_FILE`.`IMD11` AS `available`,
       `ods_erp`.`IMD_FILE`.`IMD20` AS `owner_id`,
       `ods_erp`.`IMD_FILE`.`IMD10` AS `category`,
       `ods_erp`.`IMD_FILE`.`IMD12` AS `subcategory`,
       NULL                         AS `description`,
       NULL                         AS `lastmodified`,
       NULL                         AS `created_at`,
       NULL                         AS `updated_at`
from `ods_erp`.`IMD_FILE`;

