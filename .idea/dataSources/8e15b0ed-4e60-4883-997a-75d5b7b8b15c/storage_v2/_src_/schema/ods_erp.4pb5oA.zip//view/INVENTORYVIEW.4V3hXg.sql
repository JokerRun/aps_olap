create definer = root@`%` view INVENTORYVIEW as
select `ods_erp`.`IMG_FILE`.`IMG05` AS `receipt_doc`,
       `ods_erp`.`IMG_FILE`.`IMG06` AS `receipt_seq`,
       `ods_erp`.`IMG_FILE`.`IMG07` AS `receipt_unit`,
       `ods_erp`.`IMG_FILE`.`IMG08` AS `receipt_qty`,
       `ods_erp`.`IMG_FILE`.`IMG37` AS `dull_date`,
       `ods_erp`.`IMG_FILE`.`IMG01` AS `item_nr`,
       `ods_erp`.`IMG_FILE`.`IMG02` AS `location_nr`,
       `ods_erp`.`IMG_FILE`.`IMG03` AS `storage_location`,
       `ods_erp`.`IMG_FILE`.`IMG04` AS `batch_nr`,
       `ods_erp`.`IMG_FILE`.`IMG05` AS `source`,
       `ods_erp`.`IMG_FILE`.`IMG17` AS `lastmodified`,
       `ods_erp`.`IMG_FILE`.`IMG22` AS `type`,
       `ods_erp`.`IMG_FILE`.`IMG10` AS `onhand`,
       `ods_erp`.`IMG_FILE`.`IMG23` AS `available`,
       `ods_erp`.`IMG_FILE`.`IMG24` AS `mrp_available`,
       `ods_erp`.`IMG_FILE`.`IMG19` AS `category`,
       `ods_erp`.`IMG_FILE`.`IMG22` AS `subcategory`,
       `ods_erp`.`IMG_FILE`.`IMG38` AS `description`,
       `ods_erp`.`IMG_FILE`.`IMG37` AS `created_at`,
       `ods_erp`.`IMG_FILE`.`IMG17` AS `updated_at`
from `ods_erp`.`IMG_FILE`;

