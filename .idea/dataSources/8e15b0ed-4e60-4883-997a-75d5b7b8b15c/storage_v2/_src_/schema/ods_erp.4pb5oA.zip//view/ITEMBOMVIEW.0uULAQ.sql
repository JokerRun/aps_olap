create definer = root@`%` view ITEMBOMVIEW as
select (`ods_erp`.`BMB_FILE`.`BMB01` or `ods_erp`.`BMB_FILE`.`BMB03`) AS `nr`,
       `ods_erp`.`BMB_FILE`.`BMB03`                                   AS `item_id`,
       'WCTZ'                                                         AS `itemlocation_id`,
       `ods_erp`.`BMB_FILE`.`BMB01`                                   AS `owner_id`,
       `ods_erp`.`BMB_FILE`.`BMB06`                                   AS `qty`,
       `ods_erp`.`BMB_FILE`.`BMB10`                                   AS `unit`,
       `ods_erp`.`BMB_FILE`.`BMB04`                                   AS `effective_start`,
       `ods_erp`.`BMB_FILE`.`BMB05`                                   AS `effective_end`,
       NULL                                                           AS `created_at`,
       NULL                                                           AS `updated_at`
from `ods_erp`.`BMB_FILE`;

